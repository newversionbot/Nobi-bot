module.exports = {
  apps: [
    {
      name: 'ali-trader-web',
      script: 'npx',
      args: 'tsx server.ts',
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_memory_restart: '512M',
      env_production: {
        NODE_ENV: 'production',
        PORT: 3000,
        WORKER_MODE: 'standalone',
      },
    },
    {
      name: 'ali-trader-worker',
      script: 'npx',
      args: 'tsx server/worker.ts',
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      max_memory_restart: '512M',
      env_production: {
        NODE_ENV: 'production',
        WORKER_MODE: 'standalone',
      },
    },
  ],
};
