import 'dotenv/config';
import cors from 'cors';
import express, { type NextFunction, type Request, type Response } from 'express';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { z, ZodError } from 'zod';
import type {
  ApiConnectionStatus,
  BotMonitoringTelegramMode,
  ExecutionMode,
  QuoteCurrency,
  TelegramManualReportKind,
  Timeframe,
} from './src/types/trading.ts';
import { appConfig } from './server/config.ts';
import { closeDatabase, initDatabase, pingDatabase } from './server/db/index.ts';
import { logger, redactSensitiveText } from './server/logger.ts';
import {
  cancelNobitexLiveOrder,
  fetchNobitexKlines,
  fetchNobitexLiveBalances,
  fetchNobitexLiveOpenOrders,
  fetchNobitexOrderBook,
  fetchNobitexRecentTrades,
  fetchNobitexUnifiedMarkets,
  placeNobitexLiveOrder,
  validateNobitexCredentialsFormat,
  verifyNobitexCredentials,
} from './server/nobitexClient.ts';
import {
  analyzeCandles,
  runDcaBacktest,
  runGridBacktest,
  runStrategyBacktest,
} from './server/indicators.ts';
import {
  GeminiServiceError,
  askAiTradingBuddy,
  generateAiBotManagerReport,
  generateAiCoinAnalysis,
  generateCoinSentimentAnalysis,
} from './server/aiAnalyzer.ts';
import {
  computeUnifiedBotsDashboard,
  createDcaBot,
  createGridBot,
  deleteDcaBot,
  deleteGridBot,
  evaluateDcaBot,
  evaluateGridBot,
  getLatestAiManagerReports,
  getUserBotRiskSettings,
  getUserDcaBotById,
  getUserDcaBots,
  getUserGridBotById,
  getUserGridBots,
  listPendingConfirmations,
  resolvePendingConfirmation,
  saveAiManagerReport,
  startDcaBot,
  startGridBot,
  stopDcaBot,
  stopGridBot,
  updateDcaBot,
  updateGridBot,
  updateUserBotRiskSettings,
} from './server/smartBotManager.ts';
import {
  cancelPaperOrder,
  clearAssetCostBasis,
  computePortfolioPerformance,
  createBot,
  createFeatureIdea,
  createPriceAlert,
  createPriceWatcher,
  deleteBot,
  deleteFeatureIdea,
  deletePriceAlert,
  deletePriceWatcher,
  emergencyStopAllBots,
  emergencyStopUserBots,
  evaluatePriceAlerts,
  evaluatePriceWatchers,
  evaluateSingleBot,
  getBotLogs,
  getFeatureIdeas,
  getGlobalRuntimeStats,
  getPaperBalances,
  getPaperOpenOrders,
  getPaperOrders,
  getPriceAlerts,
  getPricePulses,
  getPriceWatchers,
  getUserBotById,
  getUserBots,
  getUserOrdersAndTrades,
  matchPaperLimitOrders,
  placePaperOrder,
  rearmPriceAlert,
  recordLiveOrderAndTrade,
  resetPaperWallet,
  setAssetCostBasis,
  startBotLoop,
  stopBotLoop,
  togglePriceWatcherStatus,
  triggerPriceWatcherNow,
  updateBotFixedTargets,
  updateBotMode,
  updateBotStatus,
  updateBotTelegramSetting,
  updateFeatureIdeaStatus,
} from './server/botEngine.ts';
import {
  clearTelegramBotConfig,
  generateAppApiKey,
  getActiveExchangeCredentialsForUser,
  getActiveTelegramCredentials,
  getTelegramBotSummary,
  hasActiveExchangeCredentialsForUser,
  listUserAppKeys,
  listUserExchangeCredentials,
  markUserExchangeCredentialVerified,
  requireAuth,
  requireFirebaseSession,
  requireScope,
  revokeAppApiKey,
  revokeUserExchangeCredential,
  rotateAllEncryptedSecretsInDb,
  saveTelegramBotConfig,
  saveUserExchangeCredential,
  updateTelegramPreferences,
  verifyFirebaseIdToken,
  type RequestWithUser,
} from './server/securityVault.ts';
import {
  detectTelegramChats,
  notifyTelegramSpotOrder,
  sendManualTelegramReport,
  sendTelegramTestMessage,
  verifyTelegramBotToken,
} from './server/telegramClient.ts';
import {
  activateUserProSubscription,
  claimReferralCode,
  createBroadcastMessage,
  deleteBroadcastMessage,
  deleteDirectMessage,
  getActiveBroadcasts,
  getAdminBillingOverview,
  getPublicAppControl,
  getPublicBillingConfig,
  getUserDirectMessages,
  getUserEntitlement,
  getUserPaymentRequests,
  getUserReferralSummary,
  importHistoricalUsers,
  markAllDirectMessagesRead,
  markDirectMessageRead,
  recordAuditLog,
  requestZarinpalPayment,
  requireAdmin,
  requireModuleAccess,
  requireProSubscription,
  reviewPaymentRequestAsAdmin,
  revokeUserSubscription,
  sendDirectMessageToUser,
  submitCryptoPaymentRequest,
  touchUserAccount,
  updateAdminAppControl,
  updateAdminBillingConfig,
  updateBroadcastStatus,
  updateUserAdminControl,
  verifyZarinpalPayment,
} from './server/billingVault.ts';
import {
  createProfitBot,
  deleteProfitBot,
  evaluateProfitBot,
  getUserProfitBotById,
  getUserProfitBotCycles,
  getUserProfitBotLogs,
  getUserProfitBots,
  manualSellProfitBotPosition,
  startProfitBot,
  stopProfitBot,
  updateProfitBotSettings,
} from './server/profitBotEngine.ts';
import {
  buildProfitBotMarketPreview,
  DEFAULT_NOBITEX_FEE_RATE,
} from './src/utils/profitBotMath.ts';
import {
  createAiCycleProBot,
  deleteAiCycleProBot,
  evaluateAiCycleProBot,
  getUserAiCycleProBotById,
  getUserAiCycleProBots,
  getUserAiCycleProCycles,
  getUserAiCycleProLogs,
  manualSellAiCycleProBot,
  previewAiCycleProMarket,
  startAiCycleProBot,
  stopAiCycleProBot,
  updateAiCycleProBot,
} from './server/aiCycleProEngine.ts';

export interface CreateAppOptions {
  enableViteOrStatic?: boolean;
  startWorker?: boolean;
  generalRateLimitMax?: number;
  tradeRateLimitMax?: number;
}

const AlertCreateSchema = z.object({
  baseAsset: z.string().trim().min(1).max(20).default('BTC'),
  quoteCurrency: z.enum(['IRT', 'USDT']).default('IRT'),
  condition: z.enum(['ABOVE', 'BELOW']).default('ABOVE'),
  targetPrice: z.coerce.number().positive(),
  sendTelegram: z.boolean().optional().default(true),
  note: z.string().trim().max(300).optional(),
});

const OrderCreateSchema = z.object({
  mode: z.enum(['paper', 'live']).default('paper'),
  confirmLive: z.boolean().optional(),
  baseAsset: z.string().trim().min(1).max(20),
  quoteCurrency: z.enum(['IRT', 'USDT']).default('IRT'),
  side: z.enum(['BUY', 'SELL']),
  type: z.enum(['LIMIT', 'MARKET']),
  quantity: z.coerce.number().positive(),
  price: z.coerce.number().nonnegative().optional(),
  stopLossPrice: z.coerce.number().positive().optional(),
  takeProfitPrice: z.coerce.number().positive().optional(),
  clientOrderId: z.string().trim().max(64).optional(),
});

const TakeProfitTargetSchema = z
  .object({
    id: z.string().trim().max(40).optional(),
    risePercent: z.coerce.number().positive().max(1000).optional(),
    targetPercent: z.coerce.number().positive().max(1000).optional(),
    sellPercent: z.coerce.number().positive().max(100),
  })
  .transform((v, idx) => ({
    id: v.id && v.id.length > 0 ? v.id : `tp-${Date.now()}-${idx}`,
    risePercent: Number(v.risePercent ?? v.targetPercent ?? 5),
    sellPercent: Number(v.sellPercent),
  }));

const StrategyRuleSchema = z.object({
  id: z.string().min(1).max(80),
  type: z.string().min(1).max(60),
  action: z.enum(['BUY', 'SELL']),
  enabled: z.boolean(),
  params: z
    .object({
      period: z.number().finite().optional(),
      threshold: z.number().finite().optional(),
      fastPeriod: z.number().finite().optional(),
      slowPeriod: z.number().finite().optional(),
      multiplier: z.number().finite().optional(),
      lookback: z.number().finite().optional(),
      minVolumeRatio: z.number().finite().optional(),
      maxAtrPercent: z.number().finite().optional(),
      trendEmaPeriod: z.number().finite().optional(),
      targetPrice: z.number().positive().finite().optional(),
      repeatCycle: z.boolean().optional(),
      maxCycles: z.number().int().min(1).max(10000).nullable().optional(),
      pollSeconds: z.number().int().min(2).max(300).optional(),
    })
    .default({}),
});

const BotCreateSchema = z
  .object({
    name: z.string().trim().min(1, 'نام ربات الزامی است.').max(100),
    strategyKind: z.enum(['INDICATOR', 'FIXED_PRICE']).optional().default('INDICATOR'),
    strategyStyle: z.enum(['DAY_TRADING', 'MEDIUM_TERM']).optional().default('MEDIUM_TERM'),
    executionConfirmationMode: z.enum(['AUTO', 'MANUAL_CONFIRM']).optional().default('AUTO'),
    maxAllocatedCapital: z.coerce.number().min(0).finite().optional(),
    feeRate: z.coerce.number().min(0).max(0.05).optional(),
    estimatedSlippagePercent: z.coerce.number().min(0).max(10).optional(),
    volumeConfirmationEnabled: z.boolean().optional().default(false),
    minVolumeRatio: z.coerce.number().min(0.5).max(10).optional().default(1.2),
    volatilityFilterEnabled: z.boolean().optional().default(false),
    volatilityFilterMaxAtrPercent: z.coerce.number().min(0.5).max(30).optional().default(4.5),
    minSignalScore: z.coerce.number().int().min(1).max(10).optional().default(1),
    takeProfitTargets: z.array(TakeProfitTargetSchema).max(5).optional(),
    trailingTakeProfitEnabled: z.boolean().optional().default(false),
    trailingTakeProfitActivationPercent: z.coerce.number().min(0.2).max(200).optional().default(3),
    trailingTakeProfitCallbackPercent: z.coerce.number().min(0.1).max(50).optional().default(1),
    keepRunnerPercent: z.coerce.number().min(0).max(60).optional().default(0),
    targetBuyPrice: z.coerce.number().min(0).finite().optional(),
    targetSellPrice: z.coerce.number().positive('قیمت فروش هدف باید مثبت باشد.').finite().optional(),
    repeatCycle: z.boolean().optional().default(true),
    maxCycles: z.coerce.number().int().min(1).max(10000).nullable().optional(),
    pollIntervalSeconds: z.coerce.number().int().min(2).max(300).optional().default(5),
    fundingMode: z
      .enum(['QUOTE_BUY', 'EXISTING_ASSET', 'AUTO_PREFER_EXISTING'])
      .optional()
      .default('QUOTE_BUY'),
    existingBalancePercent: z.coerce.number().min(1).max(100).optional().default(50),
    baseAsset: z.string().trim().min(1).max(20),
    quoteCurrency: z.enum(['IRT', 'USDT']).default('IRT'),
    timeframe: z.enum(['1m', '5m', '15m', '1h', '4h', '1d']).default('15m'),
    mode: z.enum(['paper', 'live']).default('paper'),
    confirmLive: z.boolean().optional(),
    status: z.enum(['RUNNING', 'PAUSED']).default('PAUSED'),
    orderAmount: z.coerce.number().min(0, 'مبلغ معامله نمی‌تواند منفی باشد.').finite().optional().default(0),
    stopLossPercent: z.coerce.number().min(0).max(95).default(2.5),
    takeProfitPercent: z.coerce.number().min(0).max(500).default(5.0),
    trailingStopEnabled: z.boolean().default(false),
    trailingStopPercent: z.coerce.number().min(0.1).max(90).default(1.5),
    cooldownMinutes: z.coerce.number().int().min(0).max(10080).default(15),
    logicOperator: z.enum(['AND', 'OR']).default('AND'),
    entryRules: z.array(StrategyRuleSchema).max(20).optional().default([]),
    exitRules: z.array(StrategyRuleSchema).max(20).optional().default([]),
    notifyTelegram: z.boolean().optional().default(true),
  })
  .superRefine((val, ctx) => {
    if (val.fundingMode !== 'EXISTING_ASSET' && !(val.orderAmount > 0)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'مبلغ هر معامله ربات باید بزرگ‌تر از صفر باشد.',
        path: ['orderAmount'],
      });
    }
    const hasFixedRule =
      val.strategyKind === 'FIXED_PRICE' ||
      val.entryRules.some((r) => r.type === 'FIXED_BUY_PRICE');
    if (hasFixedRule) {
      const buyRulePrice = val.entryRules.find((r) => r.type === 'FIXED_BUY_PRICE')?.params
        ?.targetPrice;
      const sellRulePrice = val.exitRules.find((r) => r.type === 'FIXED_SELL_PRICE')?.params
        ?.targetPrice;
      const buyP = val.targetBuyPrice ?? buyRulePrice ?? 0;
      const sellP = val.targetSellPrice ?? sellRulePrice ?? 0;
      if (val.fundingMode !== 'EXISTING_ASSET' && !(buyP > 0)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'قیمت خرید هدف باید بزرگ‌تر از صفر باشد.',
          path: ['targetBuyPrice'],
        });
      }
      if (!(sellP > 0)) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'قیمت فروش هدف باید بزرگ‌تر از صفر باشد.',
          path: ['targetSellPrice'],
        });
      } else if (buyP > 0 && sellP <= buyP) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'قیمت فروش هدف باید بیشتر از قیمت خرید هدف باشد.',
          path: ['targetSellPrice'],
        });
      }
    } else if (val.fundingMode !== 'EXISTING_ASSET' && val.entryRules.length === 0) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'حداقل یک شرط ورود الزامی است.',
        path: ['entryRules'],
      });
    }
  });

const BotFixedTargetsUpdateSchema = z
  .object({
    targetBuyPrice: z.coerce.number().min(0).finite().optional(),
    targetSellPrice: z.coerce.number().positive('قیمت فروش باید مثبت باشد.').finite(),
    orderAmount: z.coerce.number().min(0).finite().optional(),
    repeatCycle: z.boolean().optional(),
    maxCycles: z.coerce.number().int().min(1).max(10000).nullable().optional(),
    pollIntervalSeconds: z.coerce.number().int().min(2).max(300).optional(),
    fundingMode: z.enum(['QUOTE_BUY', 'EXISTING_ASSET', 'AUTO_PREFER_EXISTING']).optional(),
    existingBalancePercent: z.coerce.number().min(1).max(100).optional(),
  })
  .superRefine((val, ctx) => {
    const buyP = val.targetBuyPrice ?? 0;
    if (val.fundingMode !== 'EXISTING_ASSET' && val.fundingMode !== undefined && !(buyP > 0)) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'قیمت هدف خرید باید بزرگ‌تر از صفر باشد.',
        path: ['targetBuyPrice'],
      });
    }
    if (buyP > 0 && val.targetSellPrice <= buyP) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'قیمت هدف فروش باید بیشتر از قیمت هدف خرید باشد.',
        path: ['targetSellPrice'],
      });
    }
  });

const TelegramSaveSchema = z.object({
  botToken: z.string().trim().max(200).optional(),
  chatId: z.string().trim().min(1, 'شناسه چت (Chat ID) الزامی است.').max(120),
  enabled: z.boolean().optional().default(true),
  sendPriceAlerts: z.boolean().optional().default(true),
  sendPeriodicWatchers: z.boolean().optional().default(true),
  sendTradeReports: z.boolean().optional().default(true),
  sendBotTrades: z.boolean().optional().default(true),
  sendBotMonitoring: z.boolean().optional().default(true),
  botMonitorMode: z
    .enum(['MANUAL_ONLY', 'EVENTS_AND_STATUS', 'INTERVAL', 'EVERY_CYCLE'])
    .optional()
    .default('EVENTS_AND_STATUS'),
  botMonitorIntervalMinutes: z.coerce.number().int().min(1).max(1440).optional().default(15),
});

const ExchangeKeySchema = z
  .object({
    label: z.string().trim().max(80).optional(),
    authType: z.enum(['KEY_PAIR', 'TOKEN']).optional(),
    apiToken: z.string().trim().max(500).optional(),
    apiKey: z.string().trim().max(500).optional(),
    secretKey: z.string().trim().max(2048).optional(),
    verifyFirst: z.boolean().optional().default(true),
  })
  .superRefine((val, ctx) => {
    const wantsKeyPair =
      val.authType === 'KEY_PAIR' ||
      (Boolean(val.apiKey?.trim()) && !val.apiToken?.trim());

    if (wantsKeyPair) {
      if (!val.apiKey || val.apiKey.trim().length < 8) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'کلید API نوبیتکس (API Key) الزامی است.',
          path: ['apiKey'],
        });
      }
      if (!val.secretKey || val.secretKey.trim().length < 16) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: 'کلید مخفی نوبیتکس (Secret Key) الزامی است.',
          path: ['secretKey'],
        });
      }
    } else if (!val.apiToken || val.apiToken.trim().length < 12) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'توکن API شخصی نوبیتکس (یا API Key و Secret Key) الزامی است.',
        path: ['apiToken'],
      });
    }
  });

const ProfitBotBaseSchema = z.object({
  name: z.string().trim().max(100).optional(),
  baseAsset: z.string().trim().min(1, 'انتخاب ارز دیجیتال الزامی است.').max(20),
  quoteCurrency: z.enum(['IRT', 'USDT']).default('IRT'),
  mode: z.enum(['paper', 'live']).default('paper'),
  confirmLive: z.boolean().optional(),
  startImmediately: z.boolean().optional().default(false),
  fundingMode: z
    .enum(['QUOTE_BUY', 'EXISTING_ASSET', 'AUTO_PREFER_EXISTING'])
    .optional()
    .default('QUOTE_BUY'),
  existingBalancePercent: z.coerce.number().min(1).max(100).optional().default(50),
  existingEntryPrice: z.coerce.number().min(0).finite().nullable().optional(),
  entryAmount: z.coerce.number().min(0).finite().optional().default(0),
  targetNetProfit: z.coerce.number().positive('سود خالص هدف باید بزرگ‌تر از صفر باشد.').finite(),
  pollIntervalSeconds: z.coerce.number().int().min(2).max(300).optional().default(10),
  maxWaitMinutes: z.coerce.number().int().min(1).max(43200).nullable().optional(),
  stopLossEnabled: z.boolean().optional().default(false),
  stopLossPercent: z.coerce.number().min(0.2).max(90).optional().default(3),
  stopLossAction: z.enum(['STOP_AND_SELL', 'STOP_ONLY']).optional().default('STOP_AND_SELL'),
  maxCapitalInvolved: z.coerce.number().min(0).finite().optional(),
  maxDailyTrades: z.coerce.number().int().min(1).max(500).optional().default(10),
  maxDailyLoss: z.coerce.number().min(0).finite().optional().default(0),
  orderType: z.enum(['LIMIT', 'MARKET']).optional().default('MARKET'),
  maxSlippagePercent: z.coerce.number().min(0.05).max(20).optional().default(0.5),
  maxSpreadPercent: z.coerce.number().min(0.05).max(20).optional().default(2.5),
  limitOrderTimeoutSeconds: z.coerce.number().int().min(10).max(86400).optional().default(120),
  limitUnfilledPolicy: z
    .enum(['KEEP_WAITING', 'CANCEL_AND_REPRICE', 'STOP_BOT'])
    .optional()
    .default('KEEP_WAITING'),
  sequenceMode: z
    .enum(['SINGLE', 'PREPARE_NEXT', 'CYCLE_REPEAT'])
    .optional()
    .default('CYCLE_REPEAT'),
  reentryTargetPrice: z.coerce.number().min(0).finite().nullable().optional(),
  reentryPolicy: z.enum(['WAIT_ENTRY_PRICE', 'IMMEDIATE']).optional().default('WAIT_ENTRY_PRICE'),
  waitEntryPriceOnFirstBuy: z.boolean().optional().default(false),
  targetSellPrice: z.coerce.number().min(0).finite().nullable().optional(),
  executionConfirmationMode: z.enum(['AUTO', 'MANUAL_CONFIRM']).optional().default('AUTO'),
  feeRate: z.coerce.number().min(0).max(0.05).optional().default(DEFAULT_NOBITEX_FEE_RATE),
  otherFeesQuote: z.coerce.number().min(0).finite().optional().default(0),
  notifyTelegram: z.boolean().optional().default(true),
});

const ProfitBotCreateSchema = ProfitBotBaseSchema.superRefine((val, ctx) => {
  if (val.fundingMode !== 'EXISTING_ASSET' && !(val.entryAmount > 0)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: 'مبلغ ورود به معامله باید مثبت باشد.',
      path: ['entryAmount'],
    });
  }
});

const ProfitBotUpdateSchema = ProfitBotBaseSchema.partial();

const GridBotCreateSchema = z.object({
  name: z.string().trim().max(100).optional(),
  baseAsset: z.string().trim().min(1).max(20),
  quoteCurrency: z.enum(['IRT', 'USDT']).default('IRT'),
  mode: z.enum(['paper', 'live']).default('paper'),
  confirmLive: z.boolean().optional(),
  startImmediately: z.boolean().optional().default(false),
  lowerPrice: z.coerce.number().positive(),
  upperPrice: z.coerce.number().positive(),
  gridLevels: z.coerce.number().int().min(3).max(30).default(8),
  stepMode: z.enum(['ARITHMETIC', 'GEOMETRIC']).optional().default('ARITHMETIC'),
  totalCapital: z.coerce.number().positive(),
  maxCapitalInvolved: z.coerce.number().min(0).optional(),
  stopOnBreakout: z.boolean().optional().default(true),
  alertOnBreakout: z.boolean().optional().default(true),
  feeRate: z.coerce.number().min(0).max(0.05).optional(),
  estimatedSlippagePercent: z.coerce.number().min(0).max(10).optional(),
  executionConfirmationMode: z.enum(['AUTO', 'MANUAL_CONFIRM']).optional().default('AUTO'),
  notifyTelegram: z.boolean().optional().default(true),
});

const DcaBotCreateSchema = z.object({
  name: z.string().trim().max(100).optional(),
  baseAsset: z.string().trim().min(1).max(20),
  quoteCurrency: z.enum(['IRT', 'USDT']).default('IRT'),
  mode: z.enum(['paper', 'live']).default('paper'),
  confirmLive: z.boolean().optional(),
  startImmediately: z.boolean().optional().default(false),
  totalCapital: z.coerce.number().positive(),
  stagesCount: z.coerce.number().int().min(2).max(25).optional(),
  totalStages: z.coerce.number().int().min(2).max(25).optional(),
  stepValue: z.coerce.number().positive().default(2.5),
  stepUnit: z.enum(['PERCENT', 'PRICE']).optional().default('PERCENT'),
  triggerMode: z
    .enum(['TIME', 'MARKET_DROP', 'INDICATOR', 'MARKET_DIP', 'TIME_INTERVAL'])
    .optional()
    .default('MARKET_DROP'),
  intervalMinutes: z.coerce.number().int().min(5).max(43200).optional().default(120),
  stopLossEnabled: z.boolean().optional().default(true),
  stopLossPercent: z.coerce.number().min(0).max(90).optional().default(8),
  takeProfitEnabled: z.boolean().optional().default(true),
  takeProfitPercent: z.coerce.number().min(0.2).max(500).optional().default(5),
  takeProfitTargets: z.array(TakeProfitTargetSchema).max(5).optional(),
  trailingTpEnabled: z.boolean().optional(),
  trailingTakeProfitEnabled: z.boolean().optional().default(false),
  trailingTpActivationPercent: z.coerce.number().min(0.2).max(200).optional(),
  trailingTakeProfitActivationPercent: z.coerce.number().min(0.2).max(200).optional().default(4),
  trailingTpCallbackPercent: z.coerce.number().min(0.1).max(50).optional(),
  trailingTakeProfitCallbackPercent: z.coerce.number().min(0.1).max(50).optional().default(1.2),
  keepRunnerPercent: z.coerce.number().min(0).max(60).optional().default(0),
  maxInvolvedCapital: z.coerce.number().min(0).optional(),
  maxCapitalInvolved: z.coerce.number().min(0).optional(),
  pauseNewBuys: z.boolean().optional().default(false),
  feeRate: z.coerce.number().min(0).max(0.05).optional(),
  estimatedSlippagePercent: z.coerce.number().min(0).max(10).optional(),
  executionConfirmationMode: z.enum(['AUTO', 'MANUAL_CONFIRM']).optional().default('AUTO'),
  notifyTelegram: z.boolean().optional().default(true),
});

const AiCycleProCreateSchema = z.object({
  name: z.string().trim().max(100).optional(),
  baseAsset: z.string().trim().min(1).max(20),
  quoteCurrency: z.enum(['IRT', 'USDT']).default('IRT'),
  capitalAmount: z.coerce.number().positive(),
  mode: z.enum(['paper', 'live']).default('paper'),
  confirmLive: z.boolean().optional(),
  startImmediately: z.boolean().optional().default(false),
  capitalUsageMode: z.enum(['FULL', 'PARTIAL']).optional().default('FULL'),
  capitalPortionPercent: z.coerce.number().min(10).max(100).optional().default(100),
  executionConfirmationMode: z.enum(['AUTO', 'MANUAL_CONFIRM']).optional().default('AUTO'),
  autoRepeatCycles: z.boolean().optional().default(true),
  stopLossPercent: z.coerce.number().min(0.5).max(30).optional().default(3.0),
  maxDailyLoss: z.coerce.number().min(0).optional(),
  maxSlippagePercent: z.coerce.number().min(0.05).max(10).optional().default(0.6),
  maxSpreadPercent: z.coerce.number().min(0.05).max(15).optional().default(2.5),
  minTargetNetProfitPercent: z.coerce.number().min(0.4).max(15).optional().default(1.2),
  pollIntervalSeconds: z.coerce.number().int().min(5).max(300).optional().default(15),
  feeRate: z.coerce.number().min(0).max(0.05).optional().default(DEFAULT_NOBITEX_FEE_RATE),
  notifyTelegram: z.boolean().optional().default(true),
});

const AiCycleProUpdateSchema = AiCycleProCreateSchema.partial();

const AiCycleProPreviewSchema = z.object({
  baseAsset: z.string().trim().min(1).max(20),
  quoteCurrency: z.enum(['IRT', 'USDT']).default('IRT'),
  capitalAmount: z.coerce.number().positive(),
  capitalUsageMode: z.enum(['FULL', 'PARTIAL']).optional().default('FULL'),
  capitalPortionPercent: z.coerce.number().min(10).max(100).optional().default(100),
  minTargetNetProfitPercent: z.coerce.number().min(0.4).max(15).optional().default(1.2),
  stopLossPercent: z.coerce.number().min(0.5).max(30).optional().default(3.0),
  maxSlippagePercent: z.coerce.number().min(0.05).max(10).optional().default(0.6),
  maxSpreadPercent: z.coerce.number().min(0.05).max(15).optional().default(2.5),
});

const RiskSettingsUpdateSchema = z.object({
  totalBotsBudgetIrt: z.coerce.number().min(0).optional(),
  totalBotsBudgetUsdt: z.coerce.number().min(0).optional(),
  maxPerBotCapitalIrt: z.coerce.number().min(0).optional(),
  maxPerBotCapitalUsdt: z.coerce.number().min(0).optional(),
  maxDailyLossIrt: z.coerce.number().min(0).optional(),
  maxDailyLossUsdt: z.coerce.number().min(0).optional(),
  maxTotalLossIrt: z.coerce.number().min(0).optional(),
  maxTotalLossUsdt: z.coerce.number().min(0).optional(),
  enableSymbolConflictLock: z.boolean().optional(),
  allowAiAdvisoryOnly: z.boolean().optional(),
  killSwitchActive: z.boolean().optional(),
});

export async function createApp(options: CreateAppOptions = {}) {
  const app = express();
  app.set('trust proxy', 1);

  app.use(
    helmet({
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
      frameguard: false,
    })
  );

  app.use(
    cors((req, callback) => {
      const origin = req.headers.origin;
      if (!origin) return callback(null, { origin: true, credentials: true });
      const cleanOrigin = origin.replace(/\/+$/, '');
      const requestHost = (req.headers['x-forwarded-host'] || req.headers.host || '')
        .toString()
        .split(',')[0]
        .trim();
      const matchesRequestHost =
        Boolean(requestHost) &&
        (cleanOrigin === `https://${requestHost}` || cleanOrigin === `http://${requestHost}`);

      if (
        !appConfig.isProduction ||
        matchesRequestHost ||
        appConfig.allowedOrigins.includes(cleanOrigin)
      ) {
        return callback(null, { origin: true, credentials: true });
      }
      return callback(new Error('Origin not allowed by CORS policy'));
    })
  );

  app.use(express.json({ limit: '256kb' }));

  const generalLimiter = rateLimit({
    windowMs: 60_000,
    max: options.generalRateLimitMax ?? appConfig.RATE_LIMIT_MAX_GENERAL,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: 'تعداد درخواست‌های شما از حد مجاز بیشتر شده است. لطفاً کمی بعد تلاش کنید.',
      code: 'RATE_LIMITED',
    },
  });

  const tradeLimiter = rateLimit({
    windowMs: 60_000,
    max: options.tradeRateLimitMax ?? appConfig.RATE_LIMIT_MAX_TRADE,
    standardHeaders: true,
    legacyHeaders: false,
    message: {
      error: 'محدودیت نرخ ارسال سفارش فعال شده است. لطفاً چند ثانیه صبر کنید.',
      code: 'TRADE_RATE_LIMITED',
    },
  });

  app.use('/api', generalLimiter);

  // =========================================================================
  // Health & Readiness Probes
  // =========================================================================
  app.get('/api/health', (_req, res) => {
    res.json({
      ok: true,
      service: 'ali-trader',
      uptimeSec: Math.round(process.uptime()),
      workerMode: appConfig.WORKER_MODE,
    });
  });

  app.get('/api/ready', async (_req, res) => {
    const dbReady = await pingDatabase();
    if (!dbReady) {
      return res.status(503).json({ ok: false, db: 'unavailable' });
    }
    return res.json({ ok: true, db: 'ready' });
  });

  // =========================================================================
  // Public Market Data & Connection Status
  // =========================================================================
  app.get('/api/status', async (req, res) => {
    let publicFeedReachable = false;
    let usdtTomanRate = 0;
    try {
      const data = await fetchNobitexUnifiedMarkets();
      usdtTomanRate = data.usdtTomanRate;
      publicFeedReachable = data.markets.length > 0;
    } catch {
      publicFeedReachable = false;
    }

    let uid: string | undefined;
    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith('Bearer ')) {
      const user = await verifyFirebaseIdToken(authHeader.slice(7).trim());
      uid = user?.uid;
    }

    const hasCreds = uid ? await hasActiveExchangeCredentialsForUser(uid) : false;
    const bots = uid ? await getUserBots(uid) : [];

    const payload: ApiConnectionStatus = {
      exchange: 'Nobitex (نوبیتکس)',
      baseUrl: appConfig.NOBITEX_BASE_URL,
      publicFeedReachable,
      hasPersonalCredentials: hasCreds,
      defaultMode: hasCreds ? 'live' : 'paper',
      usdtTomanRate,
      activeBotsCount: bots.filter((b) => b.status === 'RUNNING').length,
    };
    res.json(payload);
  });

  app.get('/api/market/tickers', async (req, res) => {
    try {
      const data = await fetchNobitexUnifiedMarkets();
      let uid: string | undefined;
      const authHeader = req.headers.authorization;
      if (authHeader?.startsWith('Bearer ')) {
        const user = await verifyFirebaseIdToken(authHeader.slice(7).trim());
        uid = user?.uid;
      }
      const triggeredAlerts = uid ? await evaluatePriceAlerts(data.markets, uid) : [];
      const triggeredPulses = uid ? await evaluatePriceWatchers(data.markets, uid) : [];
      res.json({ ...data, triggeredAlerts, triggeredPulses });
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : 'خطا در دریافت لیست بازار نوبیتکس',
      });
    }
  });

  // =========================================================================
  // Price Alerts (Strictly Authenticated & User-Isolated)
  // =========================================================================
  app.get('/api/alerts', requireAuth, requireScope('market:read'), async (req: RequestWithUser, res) => {
    const uid = req.authUser!.uid;
    try {
      const { markets } = await fetchNobitexUnifiedMarkets();
      await evaluatePriceAlerts(markets, uid);
      res.json({ alerts: await getPriceAlerts(uid) });
    } catch {
      res.json({ alerts: await getPriceAlerts(uid) });
    }
  });

  app.post('/api/alerts', requireAuth, requireScope('market:read'), async (req: RequestWithUser, res) => {
    try {
      const uid = req.authUser!.uid;
      const parsed = AlertCreateSchema.parse(req.body || {});
      const upperBase = parsed.baseAsset.toUpperCase();
      const { markets } = await fetchNobitexUnifiedMarkets();
      const match = markets.find((m) => m.baseAsset === upperBase);
      const createdPrice = match
        ? parsed.quoteCurrency === 'IRT'
          ? match.priceToman
          : match.priceUsdt
        : 0;

      const alert = await createPriceAlert(uid, {
        baseAsset: upperBase,
        quoteCurrency: parsed.quoteCurrency,
        condition: parsed.condition,
        targetPrice: parsed.targetPrice,
        createdPrice,
        persianName: match?.persianName,
        sendTelegram: parsed.sendTelegram,
        note: parsed.note,
      });
      res.json(alert);
    } catch (err) {
      if (err instanceof ZodError) {
        return res.status(400).json({ error: 'اطلاعات هشدار قیمت نامعتبر است.', issues: err.issues });
      }
      res.status(400).json({
        error: err instanceof Error ? err.message : 'خطا در ثبت هشدار قیمت',
      });
    }
  });

  app.post('/api/alerts/:alertId/rearm', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const updated = await rearmPriceAlert(req.authUser!.uid, req.params.alertId);
      res.json(updated);
    } catch (err) {
      res.status(404).json({
        error: err instanceof Error ? err.message : 'هشدار قیمت یافت نشد',
      });
    }
  });

  app.delete('/api/alerts/:alertId', requireAuth, async (req: RequestWithUser, res) => {
    await deletePriceAlert(req.authUser!.uid, req.params.alertId);
    res.json({ deleted: true });
  });

  // =========================================================================
  // Features Hub: Periodic Watchers & Future Ideas (User-Isolated)
  // =========================================================================
  app.get('/api/features/watchers', requireAuth, async (req: RequestWithUser, res) => {
    const uid = req.authUser!.uid;
    try {
      const { markets } = await fetchNobitexUnifiedMarkets();
      await evaluatePriceWatchers(markets, uid);
      res.json({
        watchers: await getPriceWatchers(uid),
        pulses: await getPricePulses(uid),
      });
    } catch {
      res.json({
        watchers: await getPriceWatchers(uid),
        pulses: await getPricePulses(uid),
      });
    }
  });

  app.post(
    '/api/features/watchers',
    requireAuth,
    requireModuleAccess('watchers'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const {
          baseAsset = 'BTC',
          quoteMode = 'BOTH',
          intervalMinutes = 5,
          notifyBrowser = true,
          playSound = true,
          sendTelegram = true,
          webhookUrl,
        } = req.body as {
          baseAsset?: string;
          quoteMode?: 'IRT' | 'USDT' | 'BOTH';
          intervalMinutes?: number;
          notifyBrowser?: boolean;
          playSound?: boolean;
          sendTelegram?: boolean;
          webhookUrl?: string;
        };

        const upperBase = String(baseAsset || '').toUpperCase().trim();
        const { markets } = await fetchNobitexUnifiedMarkets();
        const match = markets.find((m) => m.baseAsset === upperBase) || null;

        const result = await createPriceWatcher(uid, {
          baseAsset: upperBase,
          persianName: match?.persianName,
          quoteMode,
          intervalMinutes: Number(intervalMinutes),
          notifyBrowser,
          playSound,
          sendTelegram: sendTelegram !== false,
          webhookUrl,
          initialMarket: match,
        });
        res.json(result);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ثبت ارسال دوره‌ای قیمت',
        });
      }
    }
  );

  app.patch(
    '/api/features/watchers/:watcherId/status',
    requireAuth,
    requireModuleAccess('watchers'),
    async (req: RequestWithUser, res) => {
      try {
        const { status } = req.body as { status: 'ACTIVE' | 'PAUSED' };
        const updated = await togglePriceWatcherStatus(
          req.authUser!.uid,
          req.params.watcherId,
          status === 'PAUSED' ? 'PAUSED' : 'ACTIVE'
        );
        res.json(updated);
      } catch (err) {
        res.status(404).json({
          error: err instanceof Error ? err.message : 'ارسال دوره‌ای یافت نشد',
        });
      }
    }
  );

  app.post(
    '/api/features/watchers/:watcherId/send-now',
    requireAuth,
    requireModuleAccess('watchers'),
    async (req: RequestWithUser, res) => {
      try {
        const { markets } = await fetchNobitexUnifiedMarkets();
        const pulse = await triggerPriceWatcherNow(req.authUser!.uid, req.params.watcherId, markets);
        res.json({ pulse });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'ارسال فوری قیمت ناموفق بود',
        });
      }
    }
  );

  app.delete(
    '/api/features/watchers/:watcherId',
    requireAuth,
    requireModuleAccess('watchers'),
    async (req: RequestWithUser, res) => {
      await deletePriceWatcher(req.authUser!.uid, req.params.watcherId);
      res.json({ deleted: true });
    }
  );

  app.get('/api/features/ideas', requireAuth, async (req: RequestWithUser, res) => {
    res.json({ ideas: await getFeatureIdeas(req.authUser!.uid) });
  });

  app.post('/api/features/ideas', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const { title, description, category } = req.body as {
        title?: string;
        description?: string;
        category?: 'TRADING' | 'ALERTS' | 'AI' | 'BOT' | 'GENERAL';
      };
      const idea = await createFeatureIdea(req.authUser!.uid, {
        title: title || '',
        description,
        category,
      });
      res.json(idea);
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'خطا در ثبت ایده',
      });
    }
  });

  app.patch('/api/features/ideas/:ideaId/status', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const { status } = req.body as { status: 'IDEA' | 'PLANNED' | 'DONE' };
      const updated = await updateFeatureIdeaStatus(req.authUser!.uid, req.params.ideaId, status);
      res.json(updated);
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'خطا در تغییر وضعیت ایده',
      });
    }
  });

  app.delete('/api/features/ideas/:ideaId', requireAuth, async (req: RequestWithUser, res) => {
    await deleteFeatureIdea(req.authUser!.uid, req.params.ideaId);
    res.json({ deleted: true });
  });

  // =========================================================================
  // Telegram Bot Integration (Strictly Per-User)
  // =========================================================================
  app.get('/api/features/telegram', requireAuth, async (req: RequestWithUser, res) => {
    res.json({ telegram: await getTelegramBotSummary(req.authUser!.uid) });
  });

  app.post(
    '/api/features/telegram',
    requireAuth,
    requireFirebaseSession,
    requireModuleAccess('telegram'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const parsed = TelegramSaveSchema.parse(req.body || {});
        let botUsername: string | undefined;
        let botFirstName: string | undefined;

        if (parsed.botToken) {
          const info = await verifyTelegramBotToken(parsed.botToken);
          botUsername = info.username;
          botFirstName = info.firstName;
        }

        const summary = await saveTelegramBotConfig(uid, {
          botToken: parsed.botToken,
          botUsername,
          botFirstName,
          chatId: parsed.chatId,
          enabled: parsed.enabled,
          sendPriceAlerts: parsed.sendPriceAlerts,
          sendPeriodicWatchers: parsed.sendPeriodicWatchers,
          sendTradeReports: parsed.sendTradeReports,
          sendBotTrades: parsed.sendBotTrades,
          sendBotMonitoring: parsed.sendBotMonitoring,
          botMonitorMode: parsed.botMonitorMode,
          botMonitorIntervalMinutes: parsed.botMonitorIntervalMinutes,
        });

        res.json({ telegram: summary });
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({ error: err.issues[0]?.message || 'اطلاعات تلگرام نامعتبر است.' });
        }
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در اتصال و ذخیره تنظیمات ربات تلگرام',
        });
      }
    }
  );

  app.post(
    '/api/features/telegram/detect-chat',
    requireAuth,
    requireFirebaseSession,
    requireModuleAccess('telegram'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const { botToken } = req.body as { botToken?: string };
        const existingCreds = botToken?.trim()
          ? null
          : await getActiveTelegramCredentials(uid, false);
        const tokenToUse = botToken?.trim() || existingCreds?.botToken;
        if (!tokenToUse) {
          return res.status(400).json({
            error: 'ابتدا توکن ربات تلگرام (از @BotFather) را وارد کنید.',
          });
        }
        const chats = await detectTelegramChats(tokenToUse);
        res.json({ chats });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در دریافت لیست چت‌های ربات تلگرام',
        });
      }
    }
  );

  app.post(
    '/api/features/telegram/test',
    requireAuth,
    requireFirebaseSession,
    requireModuleAccess('telegram'),
    async (req: RequestWithUser, res) => {
      const uid = req.authUser!.uid;
      try {
        const { botToken, chatId } = (req.body || {}) as {
          botToken?: string;
          chatId?: string;
        };
        const result = await sendTelegramTestMessage(uid, botToken, chatId);
        res.json({
          ok: true,
          sentAt: result.sentAt,
          telegram: await getTelegramBotSummary(uid),
        });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'ارسال پیام تست به تلگرام ناموفق بود',
          telegram: await getTelegramBotSummary(uid),
        });
      }
    }
  );

  app.post(
    '/api/features/telegram/send-report',
    requireAuth,
    requireModuleAccess('telegram'),
    async (req: RequestWithUser, res) => {
      const uid = req.authUser!.uid;
      try {
        const {
          kind = 'FULL_SUMMARY',
          botId,
          mode = 'paper',
        } = (req.body || {}) as {
          kind?: TelegramManualReportKind;
          botId?: string;
          mode?: ExecutionMode;
        };

        const { markets, usdtTomanRate } = await fetchNobitexUnifiedMarkets();
        const bots = await getUserBots(uid);
        const botLogs = await getBotLogs(uid);

        let balances = await getPaperBalances(uid, markets, usdtTomanRate);
        let orders = await getPaperOrders(uid);

        if (mode === 'live') {
          const creds = await getActiveExchangeCredentialsForUser(uid);
          if (creds) {
            const [liveBalances, liveOpenOrders] = await Promise.all([
              fetchNobitexLiveBalances(markets, usdtTomanRate, creds),
              fetchNobitexLiveOpenOrders(creds),
            ]);
            balances = liveBalances;
            if (liveOpenOrders.length > 0) {
              orders = [...liveOpenOrders, ...orders];
            }
          }
        }

        const result = await sendManualTelegramReport(uid, {
          kind,
          botId,
          bots,
          botLogs,
          orders,
          balances,
          markets,
          usdtTomanRate,
        });

        res.json({
          ok: true,
          ...result,
          telegram: await getTelegramBotSummary(uid),
        });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'ارسال دستی گزارش به تلگرام ناموفق بود',
          telegram: await getTelegramBotSummary(uid),
        });
      }
    }
  );

  app.patch(
    '/api/features/telegram/preferences',
    requireAuth,
    requireFirebaseSession,
    requireModuleAccess('telegram'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const {
          enabled,
          sendPriceAlerts,
          sendPeriodicWatchers,
          sendTradeReports,
          sendBotTrades,
          sendBotMonitoring,
          botMonitorMode,
          botMonitorIntervalMinutes,
        } = req.body as {
          enabled?: boolean;
          sendPriceAlerts?: boolean;
          sendPeriodicWatchers?: boolean;
          sendTradeReports?: boolean;
          sendBotTrades?: boolean;
          sendBotMonitoring?: boolean;
          botMonitorMode?: BotMonitoringTelegramMode;
          botMonitorIntervalMinutes?: number;
        };
        const summary = await updateTelegramPreferences(uid, {
          enabled,
          sendPriceAlerts,
          sendPeriodicWatchers,
          sendTradeReports,
          sendBotTrades,
          sendBotMonitoring,
          botMonitorMode,
          botMonitorIntervalMinutes,
        });
        res.json({ telegram: summary });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در به‌روزرسانی تنظیمات تلگرام',
        });
      }
    }
  );

  app.delete(
    '/api/features/telegram',
    requireAuth,
    requireFirebaseSession,
    requireModuleAccess('telegram'),
    async (req: RequestWithUser, res) => {
      const summary = await clearTelegramBotConfig(req.authUser!.uid);
      res.json({ telegram: summary });
    }
  );

  // =========================================================================
  // Market Charting & Technical Analysis
  // =========================================================================
  app.get('/api/market/klines', async (req, res) => {
    try {
      const symbol = String(req.query.symbol || 'BTCIRT').toUpperCase();
      const interval = (String(req.query.interval || '1h') as Timeframe) || '1h';
      const limit = Number(req.query.limit || 160);
      const candles = await fetchNobitexKlines(symbol, interval, limit);
      const analysis = analyzeCandles(symbol, interval, candles);
      res.json({ candles, analysis });
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : 'خطا در دریافت کندل‌های نمودار نوبیتکس',
      });
    }
  });

  app.get('/api/market/depth', async (req, res) => {
    try {
      const symbol = String(req.query.symbol || 'BTCIRT').toUpperCase();
      const limit = Number(req.query.limit || 16);
      const depth = await fetchNobitexOrderBook(symbol, limit);
      res.json(depth);
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : 'خطا در دریافت دفتر سفارشات نوبیتکس',
      });
    }
  });

  app.get('/api/market/trades', async (req, res) => {
    try {
      const symbol = String(req.query.symbol || 'BTCIRT').toUpperCase();
      const limit = Number(req.query.limit || 25);
      const trades = await fetchNobitexRecentTrades(symbol, limit);
      res.json(trades);
    } catch (err) {
      res.status(502).json({
        error: err instanceof Error ? err.message : 'خطا در دریافت معاملات اخیر نوبیتکس',
      });
    }
  });

  app.get(
    '/api/market/multi-analysis',
    requireAuth,
    requireScope('market:read'),
    requireModuleAccess('analysis'),
    async (req, res) => {
      try {
        const symbol = String(req.query.symbol || 'BTCIRT').toUpperCase();
        const timeframes: Timeframe[] = ['15m', '1h', '4h', '1d'];
        const results = await Promise.all(
          timeframes.map(async (tf) => {
            const candles = await fetchNobitexKlines(symbol, tf, 210);
            return analyzeCandles(symbol, tf, candles);
          })
        );
        res.json(results);
      } catch (err) {
        res.status(502).json({
          error: err instanceof Error ? err.message : 'خطا در تحلیل چندتایم‌فریمی نوبیتکس',
        });
      }
    }
  );

  // =========================================================================
  // Gemini AI Market Analysis & Sentiment
  // =========================================================================
  app.post(
    '/api/ai/analyze',
    requireAuth,
    requireModuleAccess('analysis'),
    async (req, res) => {
      try {
        const { symbol = 'BTCIRT', question } = (req.body || {}) as {
          symbol?: string;
          question?: string;
        };
        const upper = String(symbol).toUpperCase();
        const baseAsset = upper.replace(/(IRT|USDT|RLS)$/, '') || 'BTC';

        const { markets, usdtTomanRate } = await fetchNobitexUnifiedMarkets();
        const market = markets.find((m) => m.baseAsset === baseAsset) || null;
        const preferredSymbol = market
          ? market.hasIrtMarket
            ? market.symbolIrt
            : market.symbolUsdt
          : upper;

        const timeframes: Timeframe[] = ['15m', '1h', '4h', '1d'];
        let snapshots = await Promise.all(
          timeframes.map(async (tf) => {
            const candles = await fetchNobitexKlines(preferredSymbol, tf, 150);
            return analyzeCandles(preferredSymbol, tf, candles);
          })
        );

        if (snapshots.every((s) => s.price === 0) && market?.hasUsdtMarket) {
          snapshots = await Promise.all(
            timeframes.map(async (tf) => {
              const candles = await fetchNobitexKlines(market.symbolUsdt, tf, 150);
              return analyzeCandles(market.symbolUsdt, tf, candles);
            })
          );
        }

        if (!market && snapshots.every((s) => s.price === 0)) {
          return res
            .status(404)
            .json({ error: `اطلاعات بازار برای ${symbol} در نوبیتکس یافت نشد.` });
        }

        const aiResult = await generateAiCoinAnalysis({
          symbol: preferredSymbol,
          baseAsset,
          market,
          usdtTomanRate,
          snapshots,
          question,
        });

        res.json(aiResult);
      } catch (err) {
        const status = err instanceof GeminiServiceError ? err.statusCode : 500;
        res.status(status).json({
          error: err instanceof Error ? err.message : 'خطا در تولید تحلیل هوشمند AI',
        });
      }
    }
  );

  app.post(
    '/api/ai/ask',
    requireAuth,
    requireModuleAccess('analysis'),
    async (req, res) => {
      try {
        const body = (req.body || {}) as {
          symbol?: string;
          question?: string;
          history?: Array<{ role?: string; text?: string; timestamp?: number }>;
        };
        const question = String(body.question || '').trim();
        if (!question || question.length < 2) {
          return res.status(400).json({ error: 'یه سوال یا جمله کوتاه بنویس تا جوابتو بدم رفیق!' });
        }

        const upper = String(body.symbol || 'BTCIRT').toUpperCase();
        const baseAsset = upper.replace(/(IRT|USDT|RLS)$/, '') || 'BTC';
        const { markets, usdtTomanRate } = await fetchNobitexUnifiedMarkets();
        const market = markets.find((m) => m.baseAsset === baseAsset) || markets[0] || null;
        const preferredSymbol = market
          ? market.hasIrtMarket
            ? market.symbolIrt
            : market.symbolUsdt
          : upper;

        // Detect any additional coins mentioned in the user's casual Persian/English question
        const qLower = question.toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک');
        const mentionedMarkets = markets
          .filter((m) => {
            if (m.baseAsset === baseAsset) return false;
            const tickerMatch =
              m.baseAsset.length >= 2 &&
              new RegExp(`\\b${m.baseAsset.toLowerCase()}\\b`, 'i').test(qLower);
            const faClean = m.persianName.toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک');
            const faMatch = faClean.length >= 2 && qLower.includes(faClean);
            return tickerMatch || faMatch;
          })
          .slice(0, 4);

        const timeframes: Timeframe[] = ['15m', '1h', '4h', '1d'];
        let snapshots = await Promise.all(
          timeframes.map(async (tf) => {
            const candles = await fetchNobitexKlines(preferredSymbol, tf, 120).catch(() => []);
            return analyzeCandles(preferredSymbol, tf, candles);
          })
        );

        if (snapshots.every((s) => s.price === 0) && market?.hasUsdtMarket) {
          snapshots = await Promise.all(
            timeframes.map(async (tf) => {
              const candles = await fetchNobitexKlines(market.symbolUsdt, tf, 120).catch(() => []);
              return analyzeCandles(market.symbolUsdt, tf, candles);
            })
          );
        }

        const safeHistory = Array.isArray(body.history)
          ? body.history
              .slice(-10)
              .filter((item) => item && typeof item.text === 'string' && item.text.trim())
              .map((item) => ({
                role: (item.role === 'assistant' ? 'assistant' : 'user') as 'user' | 'assistant',
                text: String(item.text).trim().slice(0, 1200),
                timestamp: Number(item.timestamp) || Date.now(),
              }))
          : [];

        const reply = await askAiTradingBuddy({
          question: question.slice(0, 1000),
          history: safeHistory,
          symbol: preferredSymbol,
          baseAsset,
          market,
          usdtTomanRate,
          snapshots,
          topMarkets: markets,
          mentionedMarkets,
        });

        res.json(reply);
      } catch (err) {
        const status = err instanceof GeminiServiceError ? err.statusCode : 500;
        res.status(status).json({
          error: err instanceof Error ? err.message : 'الان مغز هوش مصنوعی یه لحظه هنگ کرد، دوباره بپرس!',
        });
      }
    }
  );

  app.get(
    '/api/ai/sentiment',
    requireAuth,
    requireModuleAccess('analysis'),
    async (req, res) => {
      try {
        const symbolParam = String(req.query.symbol || 'BTCIRT').toUpperCase();
        const forceRefresh = req.query.refresh === '1' || req.query.refresh === 'true';
        const baseAsset = symbolParam.replace(/(IRT|USDT|RLS)$/, '') || 'BTC';

        const { markets } = await fetchNobitexUnifiedMarkets();
        const market = markets.find((m) => m.baseAsset === baseAsset) || null;
        const preferredSymbol = market
          ? market.hasIrtMarket
            ? market.symbolIrt
            : market.symbolUsdt
          : symbolParam;

        const sentiment = await generateCoinSentimentAnalysis({
          symbol: preferredSymbol,
          baseAsset,
          persianName: market?.persianName || baseAsset,
          market,
          forceRefresh,
        });

        res.json(sentiment);
      } catch (err) {
        res.status(500).json({
          error:
            err instanceof Error
              ? err.message
              : 'خطا در دریافت تحلیل اخبار و احساسات بازار',
        });
      }
    }
  );

  // =========================================================================
  // Authenticated API Key Management & Encrypted Nobitex Token Vault
  // =========================================================================
  app.get('/api/keys', requireAuth, requireFirebaseSession, async (req: RequestWithUser, res) => {
    const uid = req.authUser!.uid;
    res.json({
      appKeys: await listUserAppKeys(uid),
      exchangeLinks: await listUserExchangeCredentials(uid),
      hasEnvFallback: false,
    });
  });

  app.post(
    '/api/keys/app',
    requireAuth,
    requireFirebaseSession,
    requireProSubscription,
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const { label, scopes } = (req.body || {}) as { label?: string; scopes?: string[] };
        const result = await generateAppApiKey(
          uid,
          label || 'ربات و وب‌هوک ترید',
          Array.isArray(scopes) ? scopes : ['market:read', 'trade:spot', 'bot:manage']
        );
        res.json(result);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در تولید کلید API',
        });
      }
    }
  );

  app.post(
    '/api/keys/app/:keyId/revoke',
    requireAuth,
    requireFirebaseSession,
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const updated = await revokeAppApiKey(uid, req.params.keyId);
        res.json(updated);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در لغو کلید API',
        });
      }
    }
  );

  app.post(
    '/api/keys/exchange',
    requireAuth,
    requireFirebaseSession,
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const parsed = ExchangeKeySchema.parse(req.body || {});

        const wantsKeyPair =
          parsed.authType === 'KEY_PAIR' ||
          (Boolean(parsed.apiKey?.trim()) && !parsed.apiToken?.trim());

        const credInput = wantsKeyPair
          ? {
              authType: 'KEY_PAIR' as const,
              apiKey: parsed.apiKey!.trim(),
              secretKey: parsed.secretKey!.trim(),
            }
          : {
              authType: 'TOKEN' as const,
              apiToken: parsed.apiToken!.trim(),
            };

        validateNobitexCredentialsFormat(credInput);

        let verified = false;
        if (parsed.verifyFirst) {
          await verifyNobitexCredentials(credInput);
          verified = true;
        }

        const saved = await saveUserExchangeCredential(
          uid,
          parsed.label || 'حساب اصلی نوبیتکس',
          credInput,
          verified
        );
        res.json({ credential: saved, verified });
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({
            error: err.issues[0]?.message || 'مشخصات API نوبیتکس نامعتبر است.',
          });
        }
        res.status(400).json({
          error:
            err instanceof Error
              ? err.message
              : 'خطا در اتصال کلیدهای صرافی نوبیتکس',
        });
      }
    }
  );

  app.post(
    '/api/keys/exchange/test',
    requireAuth,
    requireFirebaseSession,
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const creds = await getActiveExchangeCredentialsForUser(uid);
        if (!creds) {
          return res.status(404).json({ error: 'هیچ کلید یا توکن فعالی برای صرافی نوبیتکس ثبت نشده است.' });
        }
        const info = await verifyNobitexCredentials(creds);
        await markUserExchangeCredentialVerified(uid);
        res.json({
          ok: true,
          canTrade: true,
          balancesCount: info.walletsCount,
          authType: info.authType,
        });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'اتصال به حساب نوبیتکس برقرار نشد.',
        });
      }
    }
  );

  app.delete(
    '/api/keys/exchange/:credId',
    requireAuth,
    requireFirebaseSession,
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        await revokeUserExchangeCredential(uid, req.params.credId);
        res.json({ revoked: true });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در لغو اتصال نوبیتکس',
        });
      }
    }
  );

  // =========================================================================
  // Account, Wallets & Orders (Strictly Authenticated & User-Isolated)
  // =========================================================================
  app.get('/api/account', requireAuth, requireScope('market:read'), async (req: RequestWithUser, res) => {
    try {
      const uid = req.authUser!.uid;
      const requestedMode = (String(req.query.mode || 'paper') as ExecutionMode) || 'paper';
      const symbol = req.query.symbol ? String(req.query.symbol).toUpperCase() : undefined;
      const { markets, usdtTomanRate } = await fetchNobitexUnifiedMarkets();

      if (symbol) {
        const isUsdt = symbol.endsWith('USDT');
        const base = symbol.replace(/(IRT|USDT)$/, '');
        const match = markets.find((m) => m.baseAsset === base);
        if (match) {
          const px = isUsdt ? match.priceUsdt : match.priceToman;
          await matchPaperLimitOrders(symbol, px, uid);
        }
      }

      if (requestedMode === 'live') {
        const creds = await getActiveExchangeCredentialsForUser(uid);
        if (!creds) {
          return res.status(400).json({
            error:
              'برای مشاهده موجودی واقعی نوبیتکس، وارد حساب شوید و توکن API نوبیتکس خود را متصل کنید.',
          });
        }
        const [balances, openOrders] = await Promise.all([
          fetchNobitexLiveBalances(markets, usdtTomanRate, creds),
          fetchNobitexLiveOpenOrders(creds),
        ]);
        const portfolioPerformance = await computePortfolioPerformance({
          userId: uid,
          balances,
          markets,
          usdtTomanRate,
          mode: 'live',
        });
        return res.json({
          mode: 'live',
          balances,
          openOrders,
          orderHistory: [],
          portfolioPerformance,
        });
      }

      const balances = await getPaperBalances(uid, markets, usdtTomanRate);
      const openOrders = await getPaperOpenOrders(uid, symbol);
      const orderHistory = (await getPaperOrders(uid, symbol)).filter((o) => o.status !== 'NEW');
      const portfolioPerformance = await computePortfolioPerformance({
        userId: uid,
        balances,
        markets,
        usdtTomanRate,
        mode: 'paper',
      });
      return res.json({
        mode: 'paper',
        balances,
        openOrders,
        orderHistory,
        portfolioPerformance,
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'خطا در دریافت اطلاعات حساب',
      });
    }
  });

  app.get('/api/orders', requireAuth, requireScope('market:read'), async (req: RequestWithUser, res) => {
    const uid = req.authUser!.uid;
    const { orders, trades } = await getUserOrdersAndTrades(uid, 120);
    res.json({ orders, trades });
  });

  app.post('/api/account/cost-basis', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const uid = req.authUser!.uid;
      const {
        asset,
        price,
        quoteCurrency = 'IRT',
        mode = 'paper',
      } = (req.body || {}) as {
        asset?: string;
        price?: number;
        quoteCurrency?: QuoteCurrency;
        mode?: ExecutionMode;
      };

      const { usdtTomanRate } = await fetchNobitexUnifiedMarkets();
      await setAssetCostBasis(uid, {
        asset: String(asset || ''),
        price: Number(price),
        quoteCurrency: quoteCurrency === 'USDT' ? 'USDT' : 'IRT',
        mode: mode === 'live' ? 'live' : 'paper',
        usdtTomanRate,
      });
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'خطا در ثبت قیمت خرید اولیه',
      });
    }
  });

  app.delete('/api/account/cost-basis/:asset', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const mode: ExecutionMode = req.query.mode === 'live' ? 'live' : 'paper';
      await clearAssetCostBasis(req.authUser!.uid, req.params.asset, mode);
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'خطا در بازنشانی قیمت خرید اولیه',
      });
    }
  });

  app.post('/api/account/paper-reset', requireAuth, async (req: RequestWithUser, res) => {
    const uid = req.authUser!.uid;
    try {
      const { usdtTomanRate } = await fetchNobitexUnifiedMarkets();
      const balances = await resetPaperWallet(uid, usdtTomanRate);
      res.json({ balances });
    } catch {
      const balances = await resetPaperWallet(uid);
      res.json({ balances });
    }
  });

  app.post(
    '/api/orders',
    tradeLimiter,
    requireAuth,
    requireScope('trade:spot'),
    requireModuleAccess('terminal'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const parsed = OrderCreateSchema.parse(req.body || {});
        const upperBase = parsed.baseAsset.toUpperCase();

        if (parsed.mode === 'live') {
          if (parsed.confirmLive !== true) {
            return res.status(400).json({
              error: 'برای ثبت سفارش واقعی روی صرافی نوبیتکس، تأیید صریح معامله واقعی (confirmLive) الزامی است.',
              code: 'LIVE_CONFIRMATION_REQUIRED',
            });
          }
          const creds = await getActiveExchangeCredentialsForUser(uid);
          if (!creds) {
            return res.status(400).json({
              error: 'توکن فعال صرافی نوبیتکس برای حساب شما یافت نشد.',
            });
          }
          const order = await placeNobitexLiveOrder(
            {
              baseAsset: upperBase,
              quoteCurrency: parsed.quoteCurrency,
              side: parsed.side,
              type: parsed.type,
              quantity: parsed.quantity,
              price: parsed.price,
              source: 'MANUAL',
              clientOrderId: parsed.clientOrderId,
            },
            creds
          );
          await recordLiveOrderAndTrade(uid, order, {
            idempotencyKey: parsed.clientOrderId,
          });
          void notifyTelegramSpotOrder(uid, order, 'CREATED');
          return res.json(order);
        }

        let execPrice = Number(parsed.price || 0);
        if (parsed.type === 'MARKET' || execPrice <= 0) {
          const { markets } = await fetchNobitexUnifiedMarkets();
          const match = markets.find((m) => m.baseAsset === upperBase);
          if (!match) {
            return res.status(404).json({ error: `نرخ لحظه‌ای ${upperBase} در نوبیتکس یافت نشد.` });
          }
          execPrice = parsed.quoteCurrency === 'IRT' ? match.priceToman : match.priceUsdt;
        }

        const order = await placePaperOrder(uid, {
          baseAsset: upperBase,
          quoteCurrency: parsed.quoteCurrency,
          side: parsed.side,
          type: parsed.type,
          quantity: parsed.quantity,
          price: execPrice,
          stopLossPrice: parsed.stopLossPrice,
          takeProfitPrice: parsed.takeProfitPrice,
          source: 'MANUAL',
          idempotencyKey: parsed.clientOrderId,
        });
        void notifyTelegramSpotOrder(uid, order, 'CREATED');
        return res.json(order);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({
            error: 'ساختار یا مقادیر سفارش نامعتبر است.',
            issues: err.issues,
          });
        }
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ثبت سفارش',
        });
      }
    }
  );

  app.delete(
    '/api/orders/:orderId',
    tradeLimiter,
    requireAuth,
    requireScope('trade:spot'),
    requireModuleAccess('terminal'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const { orderId } = req.params;
        const mode = (String(req.query.mode || 'paper') as ExecutionMode) || 'paper';

        if (mode === 'live') {
          const creds = await getActiveExchangeCredentialsForUser(uid);
          if (!creds) {
            return res.status(400).json({ error: 'توکن فعال صرافی نوبیتکس یافت نشد.' });
          }
          await cancelNobitexLiveOrder(orderId, creds);
          return res.json({ canceled: true, orderId });
        }
        const order = await cancelPaperOrder(uid, orderId);
        void notifyTelegramSpotOrder(uid, order, 'CANCELED');
        return res.json({ canceled: true, order });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در لغو سفارش',
        });
      }
    }
  );

  // =========================================================================
  // Automated Trading Bots (Strictly Authenticated & Owner-Isolated)
  // =========================================================================
  app.get('/api/bots', requireAuth, requireScope('market:read'), async (req: RequestWithUser, res) => {
    const uid = req.authUser!.uid;
    res.json({
      bots: await getUserBots(uid),
      logs: await getBotLogs(uid),
    });
  });

  app.post(
    '/api/bots',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const parsed = BotCreateSchema.parse(req.body || {});
        if (parsed.mode === 'live' && parsed.confirmLive !== true) {
          return res.status(400).json({
            error: 'برای فعال‌سازی ربات در حالت واقعی (Live)، تایید صریح کاربر الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        const qc = parsed.quoteCurrency;
        const base = parsed.baseAsset.toUpperCase();
        const bot = await createBot(uid, {
          name: parsed.name,
          strategyKind: parsed.strategyKind,
          strategyStyle: parsed.strategyStyle,
          executionConfirmationMode: parsed.executionConfirmationMode,
          maxAllocatedCapital: parsed.maxAllocatedCapital,
          feeRate: parsed.feeRate,
          estimatedSlippagePercent: parsed.estimatedSlippagePercent,
          volumeConfirmationEnabled: parsed.volumeConfirmationEnabled,
          minVolumeRatio: parsed.minVolumeRatio,
          volatilityFilterEnabled: parsed.volatilityFilterEnabled,
          volatilityFilterMaxAtrPercent: parsed.volatilityFilterMaxAtrPercent,
          minSignalScore: parsed.minSignalScore,
          takeProfitTargets: parsed.takeProfitTargets as any,
          trailingTakeProfitEnabled: parsed.trailingTakeProfitEnabled,
          trailingTakeProfitActivationPercent: parsed.trailingTakeProfitActivationPercent,
          trailingTakeProfitCallbackPercent: parsed.trailingTakeProfitCallbackPercent,
          keepRunnerPercent: parsed.keepRunnerPercent,
          targetBuyPrice: parsed.targetBuyPrice,
          targetSellPrice: parsed.targetSellPrice,
          repeatCycle: parsed.repeatCycle,
          maxCycles: parsed.maxCycles,
          pollIntervalSeconds: parsed.pollIntervalSeconds,
          fundingMode: parsed.fundingMode,
          existingBalancePercent: parsed.existingBalancePercent,
          baseAsset: base,
          quoteCurrency: qc,
          symbol: `${base}${qc}`,
          timeframe: parsed.timeframe,
          mode: parsed.mode,
          status: parsed.status,
          orderAmount: parsed.orderAmount,
          stopLossPercent: parsed.stopLossPercent,
          takeProfitPercent: parsed.takeProfitPercent,
          trailingStopEnabled: parsed.trailingStopEnabled,
          trailingStopPercent: parsed.trailingStopPercent,
          cooldownMinutes: parsed.cooldownMinutes,
          logicOperator: parsed.logicOperator,
          entryRules: parsed.entryRules as any,
          exitRules: parsed.exitRules as any,
          notifyTelegram: parsed.notifyTelegram,
        });
        res.json(bot);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({
            error: err.issues[0]?.message || 'اطلاعات ساخت ربات نامعتبر است.',
            issues: err.issues,
          });
        }
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ایجاد ربات معاملاتی',
        });
      }
    }
  );

  app.post('/api/bots/emergency-stop', requireAuth, requireScope('bot:manage'), async (req: RequestWithUser, res) => {
    const stoppedCount = await emergencyStopUserBots(req.authUser!.uid);
    res.json({ ok: true, stoppedCount });
  });

  app.patch(
    '/api/bots/:botId/status',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const { status } = (req.body || {}) as { status?: 'RUNNING' | 'PAUSED' };
        if (status !== 'RUNNING' && status !== 'PAUSED') {
          return res.status(400).json({ error: 'وضعیت ربات باید RUNNING یا PAUSED باشد.' });
        }
        let bot = await updateBotStatus(uid, req.params.botId, status, false);
        if (status === 'RUNNING') {
          bot = await evaluateSingleBot(bot);
        }
        res.json(bot);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در تغییر وضعیت ربات',
        });
      }
    }
  );

  app.patch(
    '/api/bots/:botId/mode',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const { mode, confirmLive } = (req.body || {}) as {
          mode?: ExecutionMode;
          confirmLive?: boolean;
        };
        if (mode !== 'paper' && mode !== 'live') {
          return res.status(400).json({ error: 'حالت اجرای ربات نامعتبر است.' });
        }
        if (mode === 'live' && confirmLive !== true) {
          return res.status(400).json({
            error: 'برای تغییر حالت ربات به معاملات واقعی، تایید صریح (confirmLive) الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        const bot = await updateBotMode(uid, req.params.botId, mode);
        res.json(bot);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در تغییر حالت اجرای ربات',
        });
      }
    }
  );

  app.patch(
    '/api/bots/:botId/telegram',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const { notifyTelegram } = (req.body || {}) as { notifyTelegram?: boolean };
        const bot = await updateBotTelegramSetting(
          req.authUser!.uid,
          req.params.botId,
          notifyTelegram !== false
        );
        res.json(bot);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در تغییر تنظیم تلگرام ربات',
        });
      }
    }
  );

  app.patch(
    '/api/bots/:botId/fixed-targets',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const parsed = BotFixedTargetsUpdateSchema.parse(req.body || {});
        const updated = await updateBotFixedTargets(
          req.authUser!.uid,
          req.params.botId,
          parsed
        );
        res.json(updated);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({
            error: err.issues[0]?.message || 'مقادیر ویرایش قیمت هدف نامعتبر است.',
            issues: err.issues,
          });
        }
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ویرایش قیمت‌های هدف ربات',
        });
      }
    }
  );

  app.post(
    '/api/bots/:botId/evaluate',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const bot = await getUserBotById(uid, req.params.botId);
        if (!bot) return res.status(404).json({ error: 'ربات یافت نشد.' });
        const updated = await evaluateSingleBot(bot);
        res.json({ bot: updated, logs: await getBotLogs(uid) });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ارزیابی فوری ربات',
        });
      }
    }
  );

  app.delete(
    '/api/bots/:botId',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      await deleteBot(req.authUser!.uid, req.params.botId);
      res.json({ deleted: true });
    }
  );

  app.post(
    '/api/bots/backtest',
    requireAuth,
    requireModuleAccess('bots'),
    async (req, res) => {
      try {
        const body = req.body || {};
        const {
          botType = 'STRATEGY',
          baseAsset = 'BTC',
          quoteCurrency = 'IRT',
          symbol,
          timeframe = '1h',
          orderAmount = 10_000_000,
          stopLossPercent = 2.5,
          takeProfitPercent = 5.0,
          trailingStopEnabled = false,
          trailingStopPercent = 1.5,
          logicOperator = 'AND',
          entryRules = [],
          exitRules = [],
          limit = 300,
          takeProfitTargets,
          trailingTakeProfitEnabled = false,
          trailingTakeProfitActivationPercent = 3,
          trailingTakeProfitCallbackPercent = 1,
          keepRunnerPercent = 0,
          feeRate,
          estimatedSlippagePercent = 0.15,
          volumeConfirmationEnabled = false,
          minVolumeRatio = 1.2,
          volatilityFilterEnabled = false,
          volatilityFilterMaxAtrPercent = 4.5,
          minSignalScore = 1,
          // Grid params
          lowerPrice = 0,
          upperPrice = 0,
          gridLevels = 8,
          stepMode = 'ARITHMETIC',
          totalCapital = 15_000_000,
          stopOnBreakout = true,
          // DCA params
          totalStages = 5,
          stepValue = 2.5,
          stepUnit = 'PERCENT',
          triggerMode = 'MARKET_DIP',
        } = body;

        const qc: QuoteCurrency = quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
        const targetSymbol = symbol
          ? String(symbol).toUpperCase()
          : `${String(baseAsset).toUpperCase()}${qc}`;

        const candles = await fetchNobitexKlines(targetSymbol, timeframe, Number(limit));
        if (candles.length < 30) {
          return res.status(400).json({
            error: `داده کندل تاریخی کافی برای ${targetSymbol} در تایم‌فریم ${timeframe} در نوبیتکس موجود نیست.`,
          });
        }

        if (botType === 'GRID') {
          const lo = Number(lowerPrice) > 0 ? Number(lowerPrice) : Math.min(...candles.map((c) => c.low)) * 0.99;
          const hi = Number(upperPrice) > lo ? Number(upperPrice) : Math.max(...candles.map((c) => c.high)) * 1.01;
          const gridRes = runGridBacktest(candles, {
            symbol: targetSymbol,
            quoteCurrency: qc,
            timeframe,
            lowerPrice: lo,
            upperPrice: hi,
            gridLevels: Number(gridLevels),
            stepMode: stepMode === 'GEOMETRIC' ? 'GEOMETRIC' : 'ARITHMETIC',
            totalCapital: Number(totalCapital),
            stopOnBreakout: Boolean(stopOnBreakout),
            feeRate: feeRate !== undefined ? Number(feeRate) : undefined,
            estimatedSlippagePercent: Number(estimatedSlippagePercent),
          });
          return res.json(gridRes);
        }

        if (botType === 'DCA') {
          const normalizedTrigger =
            triggerMode === 'TIME' || triggerMode === 'TIME_INTERVAL'
              ? 'TIME'
              : triggerMode === 'INDICATOR'
                ? 'INDICATOR'
                : 'MARKET_DROP';
          const dcaRes = runDcaBacktest(candles, {
            symbol: targetSymbol,
            quoteCurrency: qc,
            timeframe,
            totalCapital: Number(totalCapital),
            stagesCount: Number(body.stagesCount ?? totalStages ?? 5),
            stepValue: Number(stepValue),
            stepUnit: stepUnit === 'PRICE' ? 'PRICE' : 'PERCENT',
            triggerMode: normalizedTrigger,
            intervalMinutes: Number(body.intervalMinutes ?? 120),
            stopLossEnabled: Number(stopLossPercent) > 0,
            stopLossPercent: Number(stopLossPercent),
            takeProfitEnabled: true,
            takeProfitPercent: Number(body.takeProfitPercent ?? 5),
            takeProfitTargets: Array.isArray(takeProfitTargets) ? takeProfitTargets : undefined,
            trailingTpEnabled: Boolean(body.trailingTpEnabled ?? trailingTakeProfitEnabled),
            trailingTpActivationPercent: Number(
              body.trailingTpActivationPercent ?? trailingTakeProfitActivationPercent
            ),
            trailingTpCallbackPercent: Number(
              body.trailingTpCallbackPercent ?? trailingTakeProfitCallbackPercent
            ),
            feeRate: feeRate !== undefined ? Number(feeRate) : undefined,
            estimatedSlippagePercent: Number(estimatedSlippagePercent),
          });
          return res.json(dcaRes);
        }

        const result = runStrategyBacktest(candles, {
          symbol: targetSymbol,
          quoteCurrency: qc,
          timeframe,
          orderAmount: Number(orderAmount),
          stopLossPercent: Number(stopLossPercent),
          takeProfitPercent: Number(takeProfitPercent),
          trailingStopEnabled: Boolean(trailingStopEnabled),
          trailingStopPercent: Number(trailingStopPercent),
          logicOperator,
          entryRules,
          exitRules,
          takeProfitTargets: Array.isArray(takeProfitTargets) ? takeProfitTargets : undefined,
          trailingTakeProfitEnabled: Boolean(trailingTakeProfitEnabled),
          trailingTakeProfitActivationPercent: Number(trailingTakeProfitActivationPercent),
          trailingTakeProfitCallbackPercent: Number(trailingTakeProfitCallbackPercent),
          keepRunnerPercent: Number(keepRunnerPercent),
          feeRate: feeRate !== undefined ? Number(feeRate) : undefined,
          estimatedSlippagePercent: Number(estimatedSlippagePercent),
          volumeConfirmationEnabled: Boolean(volumeConfirmationEnabled),
          minVolumeRatio: Number(minVolumeRatio),
          volatilityFilterEnabled: Boolean(volatilityFilterEnabled),
          volatilityFilterMaxAtrPercent: Number(volatilityFilterMaxAtrPercent),
          minSignalScore: Number(minSignalScore),
        });
        res.json(result);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در اجرای بک‌تست استراتژی',
        });
      }
    }
  );

  // =========================================================================
  // Profit Bot (ربات سود خالص مستقل)
  // =========================================================================
  app.get('/api/profit-bots', requireAuth, requireScope('market:read'), async (req: RequestWithUser, res) => {
    const uid = req.authUser!.uid;
    const [bots, cycles, logs] = await Promise.all([
      getUserProfitBots(uid),
      getUserProfitBotCycles(uid),
      getUserProfitBotLogs(uid),
    ]);
    res.json({ bots, cycles, logs });
  });

  app.get(
    '/api/profit-bots/preview',
    requireAuth,
    requireScope('market:read'),
    requireModuleAccess('bots'),
    async (req, res) => {
      try {
        const quoteCurrency: QuoteCurrency =
          String(req.query.quoteCurrency || 'IRT').toUpperCase() === 'USDT' ? 'USDT' : 'IRT';
        const baseAsset = String(req.query.baseAsset || 'BTC')
          .toUpperCase()
          .trim();
        const symbol = String(req.query.symbol || `${baseAsset}${quoteCurrency}`).toUpperCase();
        const entryAmount = Number(req.query.entryAmount || (quoteCurrency === 'IRT' ? 10_000_000 : 100));
        const targetNetProfit = Number(
          req.query.targetNetProfit || (quoteCurrency === 'IRT' ? 100_000 : 5)
        );
        const feeRate = Number(req.query.feeRate ?? DEFAULT_NOBITEX_FEE_RATE);
        const otherFeesQuote = Number(req.query.otherFeesQuote ?? 0);
        const fundingModeRaw = String(req.query.fundingMode || 'QUOTE_BUY');
        const fundingMode =
          fundingModeRaw === 'EXISTING_ASSET' || fundingModeRaw === 'AUTO_PREFER_EXISTING'
            ? fundingModeRaw
            : 'QUOTE_BUY';
        const existingBalancePercent = Number(req.query.existingBalancePercent ?? 50);
        const existingQty = Number(req.query.existingQty ?? 0);
        const existingEntryPrice = Number(req.query.existingEntryPrice ?? 0) || null;

        const orderBook = await fetchNobitexOrderBook(symbol, 40);
        const preview = buildProfitBotMarketPreview(
          orderBook,
          entryAmount,
          targetNetProfit,
          feeRate,
          otherFeesQuote,
          {
            fundingMode,
            freeBaseBalance: existingQty,
            existingBalancePercent,
            existingEntryPrice,
          }
        );
        res.json(preview);
      } catch (err) {
        res.status(502).json({
          error: err instanceof Error ? err.message : 'خطا در دریافت پیش‌نمایش دفتر سفارش نوبیتکس',
        });
      }
    }
  );

  app.post(
    '/api/profit-bots',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const parsed = ProfitBotCreateSchema.parse(req.body || {});
        if (parsed.mode === 'live' && parsed.confirmLive !== true) {
          return res.status(400).json({
            error: 'برای ساخت ربات سود در حالت واقعی (Live)، تأیید صریح کاربر الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        let bot = await createProfitBot(uid, parsed);
        if (parsed.startImmediately) {
          bot = await evaluateProfitBot(bot);
        }
        res.json(bot);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({
            error: err.issues[0]?.message || 'اطلاعات ربات سود نامعتبر است.',
            issues: err.issues,
          });
        }
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ایجاد ربات سود',
        });
      }
    }
  );

  app.patch(
    '/api/profit-bots/:botId',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const existing = await getUserProfitBotById(uid, req.params.botId);
        if (!existing) {
          return res.status(404).json({ error: 'ربات سود مورد نظر یافت نشد.' });
        }
        const parsed = ProfitBotUpdateSchema.parse(req.body || {});
        if (parsed.mode === 'live' && existing.mode !== 'live' && parsed.confirmLive !== true) {
          return res.status(400).json({
            error: 'برای انتقال ربات سود به حالت واقعی (Live)، تأیید صریح کاربر الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        const updated = await updateProfitBotSettings(uid, req.params.botId, parsed);
        res.json(updated);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({
            error: err.issues[0]?.message || 'مقادیر ویرایش ربات سود نامعتبر است.',
            issues: err.issues,
          });
        }
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در به‌روزرسانی تنظیمات ربات سود',
        });
      }
    }
  );

  app.post(
    '/api/profit-bots/:botId/start',
    tradeLimiter,
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const existing = await getUserProfitBotById(uid, req.params.botId);
        if (!existing) {
          return res.status(404).json({ error: 'ربات سود مورد نظر یافت نشد.' });
        }
        const confirmLive = Boolean((req.body || {})?.confirmLive);
        if (existing.mode === 'live' && !existing.startedAt && !confirmLive) {
          return res.status(400).json({
            error: 'قبل از اولین معامله واقعی ربات سود، تأیید صریح کاربر الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        let bot = await startProfitBot(uid, req.params.botId);
        bot = await evaluateProfitBot(bot);
        res.json(bot);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در شروع ربات سود',
        });
      }
    }
  );

  app.post(
    '/api/profit-bots/:botId/stop',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const bot = await stopProfitBot(uid, req.params.botId, { cancelPending: true });
        res.json(bot);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در توقف ربات سود',
        });
      }
    }
  );

  app.post(
    '/api/profit-bots/:botId/evaluate',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const bot = await getUserProfitBotById(uid, req.params.botId);
        if (!bot) {
          return res.status(404).json({ error: 'ربات سود یافت نشد.' });
        }
        const updated = bot.isActive ? await evaluateProfitBot(bot) : bot;
        const [cycles, logs] = await Promise.all([
          getUserProfitBotCycles(uid),
          getUserProfitBotLogs(uid),
        ]);
        res.json({ bot: updated, cycles, logs });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در بررسی فوری ربات سود',
        });
      }
    }
  );

  app.post(
    '/api/profit-bots/:botId/manual-sell',
    tradeLimiter,
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const updated = await manualSellProfitBotPosition(uid, req.params.botId);
        const [cycles, logs] = await Promise.all([
          getUserProfitBotCycles(uid),
          getUserProfitBotLogs(uid),
        ]);
        res.json({ bot: updated, cycles, logs });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در فروش دستی پوزیشن ربات سود',
        });
      }
    }
  );

  app.delete(
    '/api/profit-bots/:botId',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        await deleteProfitBot(req.authUser!.uid, req.params.botId);
        res.json({ deleted: true });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در حذف ربات سود',
        });
      }
    }
  );

  // =========================================================================
  // AI Cycle Pro | ربات چرخه هوشمند
  // =========================================================================
  app.get('/api/ai-cycle-pro', requireAuth, requireScope('market:read'), async (req: RequestWithUser, res) => {
    const uid = req.authUser!.uid;
    const [bots, cycles, logs] = await Promise.all([
      getUserAiCycleProBots(uid),
      getUserAiCycleProCycles(uid),
      getUserAiCycleProLogs(uid),
    ]);
    res.json({ bots, cycles, logs });
  });

  app.post(
    '/api/ai-cycle-pro/preview',
    requireAuth,
    requireScope('market:read'),
    requireModuleAccess('bots'),
    async (req, res) => {
      try {
        const parsed = AiCycleProPreviewSchema.parse(req.body || {});
        const preview = await previewAiCycleProMarket(parsed);
        res.json(preview);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({
            error: err.issues[0]?.message || 'اطلاعات پیش‌نمایش AI Cycle Pro نامعتبر است.',
            issues: err.issues,
          });
        }
        res.status(502).json({
          error: err instanceof Error ? err.message : 'خطا در دریافت تحلیل هوشمند بازار نوبیتکس',
        });
      }
    }
  );

  app.post(
    '/api/ai-cycle-pro',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const parsed = AiCycleProCreateSchema.parse(req.body || {});
        if (parsed.mode === 'live' && parsed.confirmLive !== true) {
          return res.status(400).json({
            error: 'برای ایجاد AI Cycle Pro در حالت واقعی (Live)، تأیید صریح کاربر الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        let bot = await createAiCycleProBot(uid, parsed);
        if (parsed.startImmediately) {
          bot = await evaluateAiCycleProBot(bot);
        }
        res.json(bot);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({
            error: err.issues[0]?.message || 'اطلاعات ربات AI Cycle Pro نامعتبر است.',
            issues: err.issues,
          });
        }
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ایجاد ربات AI Cycle Pro',
        });
      }
    }
  );

  app.patch(
    '/api/ai-cycle-pro/:botId',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const existing = await getUserAiCycleProBotById(uid, req.params.botId);
        if (!existing) {
          return res.status(404).json({ error: 'ربات AI Cycle Pro مورد نظر یافت نشد.' });
        }
        const parsed = AiCycleProUpdateSchema.parse(req.body || {});
        if (parsed.mode === 'live' && existing.mode !== 'live' && parsed.confirmLive !== true) {
          return res.status(400).json({
            error: 'برای انتقال ربات به حالت واقعی (Live)، تأیید صریح کاربر الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        const updated = await updateAiCycleProBot(uid, req.params.botId, parsed);
        res.json(updated);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({
            error: err.issues[0]?.message || 'مقادیر ویرایش AI Cycle Pro نامعتبر است.',
            issues: err.issues,
          });
        }
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در به‌روزرسانی ربات AI Cycle Pro',
        });
      }
    }
  );

  app.post(
    '/api/ai-cycle-pro/:botId/start',
    tradeLimiter,
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const existing = await getUserAiCycleProBotById(uid, req.params.botId);
        if (!existing) {
          return res.status(404).json({ error: 'ربات AI Cycle Pro مورد نظر یافت نشد.' });
        }
        const confirmLive = Boolean((req.body || {})?.confirmLive);
        if (existing.mode === 'live' && !existing.startedAt && !confirmLive) {
          return res.status(400).json({
            error: 'قبل از اولین معامله واقعی AI Cycle Pro، تأیید صریح کاربر الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        let bot = await startAiCycleProBot(uid, req.params.botId, confirmLive);
        bot = await evaluateAiCycleProBot(bot);
        res.json(bot);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در شروع AI Cycle Pro',
        });
      }
    }
  );

  app.post(
    '/api/ai-cycle-pro/:botId/stop',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const bot = await stopAiCycleProBot(req.authUser!.uid, req.params.botId);
        res.json(bot);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در توقف AI Cycle Pro',
        });
      }
    }
  );

  app.post(
    '/api/ai-cycle-pro/:botId/evaluate',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const bot = await getUserAiCycleProBotById(uid, req.params.botId);
        if (!bot) {
          return res.status(404).json({ error: 'ربات AI Cycle Pro یافت نشد.' });
        }
        const updated = bot.isActive ? await evaluateAiCycleProBot(bot) : bot;
        const [cycles, logs] = await Promise.all([
          getUserAiCycleProCycles(uid),
          getUserAiCycleProLogs(uid),
        ]);
        res.json({ bot: updated, cycles, logs });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در بررسی فوری AI Cycle Pro',
        });
      }
    }
  );

  app.post(
    '/api/ai-cycle-pro/:botId/manual-sell',
    tradeLimiter,
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const updated = await manualSellAiCycleProBot(uid, req.params.botId);
        const [cycles, logs] = await Promise.all([
          getUserAiCycleProCycles(uid),
          getUserAiCycleProLogs(uid),
        ]);
        res.json({ bot: updated, cycles, logs });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در فروش دستی پوزیشن AI Cycle Pro',
        });
      }
    }
  );

  app.delete(
    '/api/ai-cycle-pro/:botId',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        await deleteAiCycleProBot(req.authUser!.uid, req.params.botId);
        res.json({ deleted: true });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در حذف ربات AI Cycle Pro',
        });
      }
    }
  );

  // =========================================================================
  // Shared Risk Governance, Manual Confirmations, Unified Dashboard & Kill Switch
  // =========================================================================
  app.get('/api/bots/risk-settings', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const settings = await getUserBotRiskSettings(req.authUser!.uid);
      res.json(settings);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'خطا در دریافت تنظیمات ریسک ربات‌ها',
      });
    }
  });

  app.put(
    '/api/bots/risk-settings',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const parsed = RiskSettingsUpdateSchema.parse(req.body || {});
        const updated = await updateUserBotRiskSettings(req.authUser!.uid, parsed);
        res.json(updated);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({ error: err.issues[0]?.message || 'مقادیر ریسک نامعتبر است.' });
        }
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ذخیره تنظیمات ریسک مشترک',
        });
      }
    }
  );

  app.post(
    '/api/bots/kill-switch',
    requireAuth,
    requireScope('bot:manage'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const active = Boolean((req.body || {})?.active);
        const stoppedCount = active ? await emergencyStopUserBots(uid) : 0;
        const settings = await updateUserBotRiskSettings(uid, { killSwitchActive: active });
        res.json({ ok: true, stoppedCount, settings });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در اجرای کلید توقف اضطراری',
        });
      }
    }
  );

  app.get('/api/bots/pending-confirmations', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const items = await listPendingConfirmations(req.authUser!.uid);
      res.json({ items });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'خطا در دریافت صف تأیید دستی',
      });
    }
  });

  app.post(
    '/api/bots/pending-confirmations/:id/resolve',
    tradeLimiter,
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const { decision, confirmLive } = (req.body || {}) as {
          decision?: 'APPROVE' | 'REJECT';
          confirmLive?: boolean;
        };
        if (decision !== 'APPROVE' && decision !== 'REJECT') {
          return res.status(400).json({ error: 'تصمیم باید APPROVE یا REJECT باشد.' });
        }
        const resolved = await resolvePendingConfirmation({
          userId: req.authUser!.uid,
          confirmationId: req.params.id,
          decision,
          confirmLive: Boolean(confirmLive),
        });
        res.json(resolved);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در تعیین تکلیف معامله',
        });
      }
    }
  );

  app.get('/api/bots/unified-dashboard', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const summary = await computeUnifiedBotsDashboard(req.authUser!.uid);
      res.json(summary);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'خطا در محاسبه گزارش یکپارچه ربات‌ها',
      });
    }
  });

  // =========================================================================
  // Grid Bots (ربات گرید)
  // =========================================================================
  app.get('/api/grid-bots', requireAuth, async (req: RequestWithUser, res) => {
    res.json({ bots: await getUserGridBots(req.authUser!.uid) });
  });

  app.post(
    '/api/grid-bots',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const parsed = GridBotCreateSchema.parse(req.body || {});
        if (parsed.mode === 'live' && parsed.confirmLive !== true) {
          return res.status(400).json({
            error: 'برای فعال‌سازی ربات گرید واقعی، تأیید صریح کاربر الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        let bot = await createGridBot(uid, parsed);
        if (parsed.startImmediately) {
          bot = await evaluateGridBot(bot);
        }
        res.json(bot);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({ error: err.issues[0]?.message || 'اطلاعات ربات گرید نامعتبر است.' });
        }
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در ساخت ربات گرید' });
      }
    }
  );

  app.patch(
    '/api/grid-bots/:botId',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const updated = await updateGridBot(req.authUser!.uid, req.params.botId, req.body || {});
        res.json(updated);
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در ویرایش ربات گرید' });
      }
    }
  );

  app.post(
    '/api/grid-bots/:botId/start',
    tradeLimiter,
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        let bot = await startGridBot(req.authUser!.uid, req.params.botId, Boolean(req.body?.confirmLive));
        bot = await evaluateGridBot(bot);
        res.json(bot);
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در شروع ربات گرید' });
      }
    }
  );

  app.post(
    '/api/grid-bots/:botId/stop',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        res.json(await stopGridBot(req.authUser!.uid, req.params.botId));
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در توقف ربات گرید' });
      }
    }
  );

  app.post(
    '/api/grid-bots/:botId/evaluate',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const bot = await getUserGridBotById(req.authUser!.uid, req.params.botId);
        if (!bot) return res.status(404).json({ error: 'ربات گرید یافت نشد.' });
        res.json(await evaluateGridBot(bot));
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در پایش ربات گرید' });
      }
    }
  );

  app.delete(
    '/api/grid-bots/:botId',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        await deleteGridBot(req.authUser!.uid, req.params.botId);
        res.json({ deleted: true });
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در حذف ربات گرید' });
      }
    }
  );

  // =========================================================================
  // DCA Bots (ربات خرید پله‌ای)
  // =========================================================================
  app.get('/api/dca-bots', requireAuth, async (req: RequestWithUser, res) => {
    res.json({ bots: await getUserDcaBots(req.authUser!.uid) });
  });

  app.post(
    '/api/dca-bots',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const parsed = DcaBotCreateSchema.parse(req.body || {});
        if (parsed.mode === 'live' && parsed.confirmLive !== true) {
          return res.status(400).json({
            error: 'برای فعال‌سازی ربات خرید پله‌ای واقعی، تأیید صریح الزامی است.',
            code: 'LIVE_CONFIRMATION_REQUIRED',
          });
        }
        const normalizedTrigger: 'TIME' | 'MARKET_DROP' | 'INDICATOR' =
          parsed.triggerMode === 'TIME' || parsed.triggerMode === 'TIME_INTERVAL'
            ? 'TIME'
            : parsed.triggerMode === 'INDICATOR'
              ? 'INDICATOR'
              : 'MARKET_DROP';
        let bot = await createDcaBot(uid, {
          ...parsed,
          stagesCount: parsed.stagesCount ?? parsed.totalStages ?? 5,
          maxInvolvedCapital: parsed.maxInvolvedCapital ?? parsed.maxCapitalInvolved,
          triggerMode: normalizedTrigger,
          trailingTpEnabled: parsed.trailingTpEnabled ?? parsed.trailingTakeProfitEnabled,
          trailingTpActivationPercent:
            parsed.trailingTpActivationPercent ?? parsed.trailingTakeProfitActivationPercent,
          trailingTpCallbackPercent:
            parsed.trailingTpCallbackPercent ?? parsed.trailingTakeProfitCallbackPercent,
        });
        if (parsed.startImmediately) {
          bot = await evaluateDcaBot(bot);
        }
        res.json(bot);
      } catch (err) {
        if (err instanceof ZodError) {
          return res.status(400).json({ error: err.issues[0]?.message || 'اطلاعات ربات خرید پله‌ای نامعتبر است.' });
        }
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در ساخت ربات خرید پله‌ای' });
      }
    }
  );

  app.patch(
    '/api/dca-bots/:botId',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        res.json(await updateDcaBot(req.authUser!.uid, req.params.botId, req.body || {}));
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در ویرایش ربات خرید پله‌ای' });
      }
    }
  );

  app.post(
    '/api/dca-bots/:botId/start',
    tradeLimiter,
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        let bot = await startDcaBot(req.authUser!.uid, req.params.botId, Boolean(req.body?.confirmLive));
        bot = await evaluateDcaBot(bot);
        res.json(bot);
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در شروع ربات خرید پله‌ای' });
      }
    }
  );

  app.post(
    '/api/dca-bots/:botId/stop',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        res.json(await stopDcaBot(req.authUser!.uid, req.params.botId));
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در توقف ربات خرید پله‌ای' });
      }
    }
  );

  app.post(
    '/api/dca-bots/:botId/evaluate',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const bot = await getUserDcaBotById(req.authUser!.uid, req.params.botId);
        if (!bot) return res.status(404).json({ error: 'ربات خرید پله‌ای یافت نشد.' });
        res.json(await evaluateDcaBot(bot));
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در بررسی ربات خرید پله‌ای' });
      }
    }
  );

  app.delete(
    '/api/dca-bots/:botId',
    requireAuth,
    requireScope('bot:manage'),
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        await deleteDcaBot(req.authUser!.uid, req.params.botId);
        res.json({ deleted: true });
      } catch (err) {
        res.status(400).json({ error: err instanceof Error ? err.message : 'خطا در حذف ربات خرید پله‌ای' });
      }
    }
  );

  // =========================================================================
  // AI Central Bot Manager (مدیر هوشمند مرکزی ربات‌ها)
  // =========================================================================
  app.get('/api/ai/bot-manager', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const reports = await getLatestAiManagerReports(req.authUser!.uid);
      res.json({ latest: reports[0] || null, reports });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'خطا در دریافت گزارش مدیر هوشمند',
      });
    }
  });

  app.post(
    '/api/ai/bot-manager',
    requireAuth,
    requireModuleAccess('bots'),
    async (req: RequestWithUser, res) => {
      try {
        const uid = req.authUser!.uid;
        const [{ markets, usdtTomanRate }, dashboard, riskSettings] = await Promise.all([
          fetchNobitexUnifiedMarkets(),
          computeUnifiedBotsDashboard(uid),
          getUserBotRiskSettings(uid),
        ]);
        const report = await generateAiBotManagerReport({
          markets,
          usdtTomanRate,
          botSummaries: dashboard.rows,
          riskSettings,
        });
        await saveAiManagerReport(uid, report);
        res.json({ report, dashboard });
      } catch (err) {
        res.status(500).json({
          error: err instanceof Error ? err.message : 'خطا در اجرای تحلیل مدیر هوشمند مرکزی',
        });
      }
    }
  );

  // =========================================================================
  // Subscription, Referrals, Messages & Admin Panel
  // =========================================================================
  app.get('/api/billing/status', async (req, res) => {
    let usdtTomanRate = 0;
    try {
      const data = await fetchNobitexUnifiedMarkets();
      usdtTomanRate = data.usdtTomanRate;
    } catch {
      usdtTomanRate = 0;
    }

    let authUser = null;
    const authHeader = req.headers.authorization;
    if (authHeader?.startsWith('Bearer ')) {
      authUser = await verifyFirebaseIdToken(authHeader.slice(7).trim());
      if (authUser) {
        await touchUserAccount(authUser);
      }
    }

    const [
      config,
      entitlement,
      myRequests,
      appControl,
      broadcasts,
      directMessages,
      referral,
    ] = await Promise.all([
      getPublicBillingConfig(usdtTomanRate),
      getUserEntitlement(authUser),
      authUser ? getUserPaymentRequests(authUser.uid) : Promise.resolve([]),
      getPublicAppControl(),
      getActiveBroadcasts(),
      authUser ? getUserDirectMessages(authUser.uid) : Promise.resolve([]),
      authUser ? getUserReferralSummary(authUser.uid) : Promise.resolve(null),
    ]);

    const unreadDirectCount = directMessages.filter((m) => !m.readByUser).length;

    res.json({
      config,
      entitlement,
      myRequests,
      appControl,
      broadcasts,
      directMessages,
      unreadDirectCount,
      referral,
    });
  });

  app.post('/api/referrals/claim', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const { code } = (req.body || {}) as { code?: string };
      if (!code || typeof code !== 'string') {
        return res.status(400).json({ error: 'کد دعوت ارسال نشده است.' });
      }
      const result = await claimReferralCode(req.authUser!, code);
      const summary = await getUserReferralSummary(req.authUser!.uid);
      res.json({ ...result, summary });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'خطا در ثبت کد دعوت',
      });
    }
  });

  app.post('/api/messages/:messageId/read', requireAuth, async (req: RequestWithUser, res) => {
    const updated = await markDirectMessageRead(req.authUser!.uid, req.params.messageId);
    res.json({ message: updated });
  });

  app.post('/api/messages/read-all', requireAuth, async (req: RequestWithUser, res) => {
    const count = await markAllDirectMessagesRead(req.authUser!.uid);
    res.json({ markedCount: count });
  });

  app.post('/api/billing/crypto/submit', requireAuth, async (req: RequestWithUser, res) => {
    try {
      let usdtTomanRate = 0;
      try {
        const data = await fetchNobitexUnifiedMarkets();
        usdtTomanRate = data.usdtTomanRate;
      } catch {
        usdtTomanRate = 0;
      }
      const { txHash, network, walletAddress, note } = (req.body || {}) as {
        txHash?: string;
        network?: string;
        walletAddress?: string;
        note?: string;
      };
      const record = await submitCryptoPaymentRequest({
        user: req.authUser!,
        txHash: txHash || '',
        network,
        walletAddress,
        usdtTomanRate,
        note,
      });
      res.json({ request: record });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'خطا در ثبت فیش پرداخت دلاری (USDT)',
      });
    }
  });

  app.post('/api/billing/zarinpal/request', requireAuth, async (req: RequestWithUser, res) => {
    try {
      let usdtTomanRate = 0;
      try {
        const data = await fetchNobitexUnifiedMarkets();
        usdtTomanRate = data.usdtTomanRate;
      } catch {
        usdtTomanRate = 0;
      }

      const proto =
        String(req.headers['x-forwarded-proto'] || '').split(',')[0].trim() ||
        req.protocol ||
        'https';
      const host =
        String(req.headers['x-forwarded-host'] || '').split(',')[0].trim() || req.get('host');
      const origin = appConfig.APP_URL?.trim() || `${proto}://${host}`;
      const callbackUrl = `${origin.replace(/\/+$/, '')}/?zarinpal=callback`;

      const result = await requestZarinpalPayment({
        user: req.authUser!,
        callbackUrl,
        usdtTomanRate,
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'خطا در ایجاد تراکنش زرین‌پال',
      });
    }
  });

  app.post('/api/billing/zarinpal/verify', requireAuth, async (req: RequestWithUser, res) => {
    try {
      const { authority, status } = (req.body || {}) as {
        authority?: string;
        status?: string;
      };
      if (!authority) {
        return res.status(400).json({ error: 'کد پیگیری (Authority) زرین‌پال ارسال نشده است.' });
      }
      const result = await verifyZarinpalPayment({
        user: req.authUser!,
        authority,
        status: status || 'NOK',
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'خطا در تایید پرداخت زرین‌پال',
      });
    }
  });

  // Admin endpoints (Strict RBAC + Firebase session)
  app.get(
    '/api/billing/admin/overview',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (_req, res) => {
      let usdtTomanRate = 0;
      try {
        const data = await fetchNobitexUnifiedMarkets();
        usdtTomanRate = data.usdtTomanRate;
      } catch {
        usdtTomanRate = 0;
      }
      const metrics = await getGlobalRuntimeStats();
      res.json(await getAdminBillingOverview(usdtTomanRate, metrics));
    }
  );

  app.put(
    '/api/billing/admin/config',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      try {
        let usdtTomanRate = 0;
        try {
          const data = await fetchNobitexUnifiedMarkets();
          usdtTomanRate = data.usdtTomanRate;
        } catch {
          usdtTomanRate = 0;
        }
        await updateAdminBillingConfig(req.body || {}, usdtTomanRate, req.authUser?.email);
        const metrics = await getGlobalRuntimeStats();
        res.json(await getAdminBillingOverview(usdtTomanRate, metrics));
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ذخیره تنظیمات پنل مدیریت',
        });
      }
    }
  );

  app.post(
    '/api/billing/admin/payments/:requestId/review',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      try {
        const { action, adminNote } = (req.body || {}) as {
          action?: 'APPROVE' | 'REJECT';
          adminNote?: string;
        };
        if (action !== 'APPROVE' && action !== 'REJECT') {
          return res.status(400).json({ error: 'عملیات نامعتبر است.' });
        }
        const result = await reviewPaymentRequestAsAdmin({
          requestId: req.params.requestId,
          action,
          adminNote,
          actorEmail: req.authUser?.email,
        });
        res.json(result);
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در بررسی درخواست پرداخت',
        });
      }
    }
  );

  app.post(
    '/api/billing/admin/subscriptions/manage',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      try {
        const { userId, email, displayName, action, days } = (req.body || {}) as {
          userId?: string;
          email?: string;
          displayName?: string;
          action?: 'ACTIVATE' | 'REVOKE';
          days?: number;
        };
        const cleanId = String(userId || '').trim();
        if (!cleanId) {
          return res.status(400).json({ error: 'شناسه کاربر (UID) الزامی است.' });
        }
        if (action === 'REVOKE') {
          const revoked = await revokeUserSubscription(cleanId, req.authUser?.email);
          return res.json({ subscription: revoked });
        }
        const sub = await activateUserProSubscription(
          {
            userId: cleanId,
            email: String(email || '').trim(),
            displayName: String(displayName || email || cleanId).trim(),
            paymentMethod: 'ADMIN_GRANT',
            days: Number(days || 30),
          },
          req.authUser?.email
        );
        return res.json({ subscription: sub });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در تغییر وضعیت اشتراک کاربر',
        });
      }
    }
  );

  app.post(
    '/api/billing/admin/users/import',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req, res) => {
      const users = Array.isArray(req.body?.users) ? req.body.users : [];
      const added = await importHistoricalUsers(users);
      res.json({ added });
    }
  );

  app.patch(
    '/api/billing/admin/users/:userId',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      try {
        const { isBanned, banReason, adminNote } = (req.body || {}) as {
          isBanned?: boolean;
          banReason?: string;
          adminNote?: string;
        };
        const updated = await updateUserAdminControl({
          userId: req.params.userId,
          isBanned,
          banReason,
          adminNote,
          actorEmail: req.authUser!.email,
        });
        res.json({ user: updated });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در بروزرسانی وضعیت کاربر',
        });
      }
    }
  );

  app.post(
    '/api/billing/admin/broadcasts',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      try {
        const { title, body, severity, pinned, expiresInHours, sendTelegram } = (req.body ||
          {}) as {
          title?: string;
          body?: string;
          severity?: 'INFO' | 'SUCCESS' | 'WARNING' | 'URGENT';
          pinned?: boolean;
          expiresInHours?: number;
          sendTelegram?: boolean;
        };
        const broadcast = await createBroadcastMessage({
          title: title || '',
          body: body || '',
          severity: severity || 'INFO',
          pinned,
          expiresInHours,
          sendTelegram,
          actorEmail: req.authUser!.email,
        });
        res.json({ broadcast });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در انتشار پیام عمومی',
        });
      }
    }
  );

  app.patch(
    '/api/billing/admin/broadcasts/:broadcastId',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      try {
        const { active, pinned } = (req.body || {}) as { active?: boolean; pinned?: boolean };
        const broadcast = await updateBroadcastStatus({
          broadcastId: req.params.broadcastId,
          active,
          pinned,
          actorEmail: req.authUser!.email,
        });
        res.json({ broadcast });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ویرایش پیام عمومی',
        });
      }
    }
  );

  app.delete(
    '/api/billing/admin/broadcasts/:broadcastId',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      await deleteBroadcastMessage(req.params.broadcastId, req.authUser!.email);
      res.json({ deleted: true });
    }
  );

  app.post(
    '/api/billing/admin/messages',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      try {
        const { targetUserId, subject, body, severity } = (req.body || {}) as {
          targetUserId?: string;
          subject?: string;
          body?: string;
          severity?: 'INFO' | 'SUCCESS' | 'WARNING' | 'URGENT';
        };
        const message = await sendDirectMessageToUser({
          targetUserId: targetUserId || '',
          subject: subject || '',
          body: body || '',
          severity: severity || 'INFO',
          actorEmail: req.authUser!.email,
        });
        res.json({ message });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ارسال پیام تکی به کاربر',
        });
      }
    }
  );

  app.delete(
    '/api/billing/admin/messages/:messageId',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      await deleteDirectMessage(req.params.messageId, req.authUser!.email);
      res.json({ deleted: true });
    }
  );

  app.put(
    '/api/billing/admin/app-control',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      try {
        const appControl = await updateAdminAppControl(req.body || {}, req.authUser!.email);
        res.json({ appControl });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در ذخیره تنظیمات کلی برنامه',
        });
      }
    }
  );

  app.post(
    '/api/billing/admin/bots/:botId/status',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      try {
        const { status } = (req.body || {}) as { status?: 'RUNNING' | 'PAUSED' };
        const bot = await updateBotStatus(
          null,
          req.params.botId,
          status === 'RUNNING' ? 'RUNNING' : 'PAUSED',
          true
        );
        await recordAuditLog(
          req.authUser!.email,
          'ADMIN_BOT_STATUS',
          `تغییر وضعیت ربات ${bot.name} به ${bot.status}`,
          bot.id
        );
        res.json({ bot });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'خطا در تغییر وضعیت ربات توسط مدیر',
        });
      }
    }
  );

  app.post(
    '/api/billing/admin/bots/emergency-stop',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      const stoppedCount = await emergencyStopAllBots(req.authUser!.email);
      await recordAuditLog(
        req.authUser!.email,
        'ADMIN_GLOBAL_EMERGENCY_STOP',
        `توقف اضطراری همه ربات‌های فعال (${stoppedCount} ربات متوقف شد)`
      );
      res.json({ ok: true, stoppedCount });
    }
  );

  app.post(
    '/api/billing/admin/security/rotate-keys',
    requireAuth,
    requireFirebaseSession,
    requireAdmin,
    async (req: RequestWithUser, res) => {
      const result = await rotateAllEncryptedSecretsInDb();
      await recordAuditLog(
        req.authUser!.email,
        'SECURITY_KEY_ROTATION',
        `چرخش کلید رمزنگاری: ${result.rotatedExchangeCount} کلید صرافی، ${result.rotatedTelegramCount} تلگرام، ${result.rotatedMerchantCount} درگاه`
      );
      res.json({ ok: true, ...result });
    }
  );

  // Ensure unmatched /api/* paths always return JSON instead of SPA index.html
  app.use('/api', (req, res) => {
    res.status(404).json({
      error: `مسیر API یافت نشد (${req.method} ${req.originalUrl}).`,
      code: 'API_ROUTE_NOT_FOUND',
    });
  });

  // Sanitized global API error handler (never leaks tokens or stack traces)
  app.use((err: unknown, req: Request, res: Response, _next: NextFunction) => {
    const safeMsg = redactSensitiveText(
      err instanceof Error ? err.message : 'خطای داخلی سرور رخ داد.'
    );
    logger.error('http.unhandled_error', {
      path: req.path,
      method: req.method,
      error: safeMsg,
    });
    if (res.headersSent) return;
    const statusCode =
      err && typeof err === 'object' && 'status' in err && typeof err.status === 'number'
        ? err.status
        : 500;
    res.status(statusCode).json({
      error: statusCode >= 500 ? 'خطای داخلی سرور رخ داد.' : safeMsg,
    });
  });

  if (options.enableViteOrStatic !== false) {
    if (appConfig.isProduction) {
      const distPath = path.resolve(process.cwd(), 'dist');
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    } else {
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa',
      });
      app.use(vite.middlewares);
    }
  }

  const shouldStartWorker =
    options.startWorker !== undefined
      ? options.startWorker
      : appConfig.WORKER_MODE === 'embedded';

  if (shouldStartWorker) {
    startBotLoop(appConfig.WORKER_POLL_MS);
  }

  return app;
}

export async function startServer() {
  await initDatabase();
  const app = await createApp();
  const server = app.listen(appConfig.PORT, '0.0.0.0', () => {
    logger.info('server.listening', {
      port: appConfig.PORT,
      env: appConfig.NODE_ENV,
      workerMode: appConfig.WORKER_MODE,
    });
  });

  const shutdown = async (signal: string) => {
    logger.info('server.shutting_down', { signal });
    stopBotLoop();
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
    await closeDatabase().catch(() => {});
    process.exit(0);
  };

  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  return server;
}

const isDirectEntry =
  typeof process !== 'undefined' &&
  Array.isArray(process.argv) &&
  process.argv[1] &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;

if (isDirectEntry && process.env.NODE_ENV !== 'test') {
  startServer().catch((err) => {
    logger.error('server.fatal_startup', { error: err });
    process.exit(1);
  });
}
