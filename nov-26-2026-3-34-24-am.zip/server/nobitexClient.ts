import crypto from 'node:crypto';
import type {
  KlineCandle,
  NobitexAuthType,
  OrderBookSnapshot,
  QuoteCurrency,
  RecentTrade,
  SpotBalance,
  SpotOrder,
  Timeframe,
  UnifiedMarketTicker,
} from '../src/types/trading.ts';
import { redactSensitiveText, logger } from './logger.ts';
import {
  getMinimumOrderNotional,
  roundQuantityToStep,
} from '../src/utils/profitBotMath.ts';

function getNobitexBase(): string {
  return (process.env.NOBITEX_BASE_URL || 'https://apiv2.nobitex.ir').replace(/\/$/, '');
}

export type FetchLike = typeof fetch;
let activeFetch: FetchLike = globalThis.fetch;

export interface NobitexOptionsCache {
  minIrt: number;
  minUsdt: number;
  amountPrecisions: Record<string, number>;
  fetchedAt: number;
}

let cachedOptions: NobitexOptionsCache | null = null;
let inFlightOptionsFetch: Promise<NobitexOptionsCache> | null = null;

export function setNobitexFetchForTest(customFetch: FetchLike | null): void {
  if (process.env.NODE_ENV === 'production' && customFetch) {
    throw new Error('Cannot override Nobitex fetch in production.');
  }
  activeFetch = customFetch || globalThis.fetch;
  cachedUnified = null;
  cachedOptions = null;
  inFlightOptionsFetch = null;
  nobitexRateLimitUntil = 0;
  consecutiveRateLimits = 0;
  walletCache.clear();
  inFlightWallets.clear();
  openOrdersCache.clear();
  inFlightOpenOrders.clear();
}

const PERSIAN_COIN_NAMES: Record<string, string> = {
  BTC: 'بیت‌کوین',
  ETH: 'اتریوم',
  USDT: 'تتر',
  BNB: 'بایننس کوین',
  SOL: 'سولانا',
  XRP: 'ریپل',
  TON: 'تون‌کوین',
  TRX: 'ترون',
  DOGE: 'دوج‌کوین',
  ADA: 'کاردانو',
  SHIB: 'شیبا اینو',
  AVAX: 'آوالانچ',
  DOT: 'پولکادات',
  LINK: 'چین‌لینک',
  LTC: 'لایت‌کوین',
  BCH: 'بیت‌کوین کش',
  POL: 'پالیگان',
  MATIC: 'پالیگان',
  UNI: 'یونی‌سواپ',
  ATOM: 'کازماس',
  XLM: 'استلار',
  ETC: 'اتریوم کلاسیک',
  NEAR: 'نیر پروتکل',
  APT: 'آپتوس',
  ARB: 'آربیتروم',
  OP: 'اپتیمیزم',
  SUI: 'سویی',
  PEPE: 'پپه',
  NOT: 'نات‌کوین',
  DOGS: 'داگز',
  HMSTR: 'همستر کامبت',
  S: 'سونیک',
  FIL: 'فایل‌کوین',
  ALGO: 'الگورند',
  VET: 'وی‌چین',
  AAVE: 'آوه',
  MKR: 'میکر',
  SAND: 'سندباکس',
  MANA: 'دیسنترالند',
  AXS: 'اکسی اینفینیتی',
  EOS: 'ایاس',
  XTZ: 'تزوس',
  GRT: 'گراف',
  INJ: 'اینجکتیو',
  RENDER: 'رندر',
  FET: 'فچ‌ای‌آی',
  WLD: 'ورلدکوین',
  XMR: 'مونرو',
  DASH: 'دش',
  ZEC: 'زی‌کش',
  PAXG: 'پکس گلد (طلا)',
  XAUT: 'تتر گلد (طلا)',
  DAI: 'دای',
  USDC: 'یواس‌دی کوین',
  FLOKI: 'فلوکی',
  BONK: 'بونک',
  WIF: 'داگ‌ویف‌هت',
  GALA: 'گالا',
  CHZ: 'چیلیز',
  CAKE: 'پنکیک‌سواپ',
  LDO: 'لیدو',
  STX: 'استکس',
  TIA: 'سلستیا',
  SEI: 'سی',
  JUP: 'ژوپیتر',
  ONDO: 'اوندو',
  KAS: 'کاسپا',
  TAO: 'بیت‌تنسور',
  MAJOR: 'میجر',
  CATI: 'کتیزن',
  TRUMP: 'ترامپ',
  MELANIA: 'ملانیا',
  PENGU: 'پاجی پنگوئن',
  BOME: 'بوک آو میم',
  PNUT: 'پینات',
  TURBO: 'توربو',
  NEIRO: 'نیرو',
  MEME: 'میم‌کوین',
  ENA: 'اتنا',
  EIGEN: 'ایگن‌لیر',
  ETHFI: 'اتر‌فای',
  PENDLE: 'پندل',
  JTO: 'جیتو',
  PYTH: 'پایت نتورک',
  STRK: 'استارک‌نت',
  ZK: 'زدکی‌سینک',
  ZRO: 'لیرزیرو',
  MNT: 'منتل',
  IMX: 'ایمیوتبل ایکس',
  BEAM: 'بیم',
  BLUR: 'بلور',
  DYDX: 'دی‌وای‌دی‌ایکس',
  GMX: 'جی‌ام‌ایکس',
  CRV: 'کرو دائو',
  COMP: 'کامپاند',
  SNX: 'سینتتیکس',
  SUSHI: 'سوشی‌سواپ',
  '1INCH': 'وان‌اینچ',
  RUNE: 'تورچین',
  ARKM: 'آرکهام',
  ICP: 'اینترنت کامپیوتر',
  AR: 'آرویو',
  STORJ: 'استورج',
  HBAR: 'هدرا',
  FLOW: 'فلو',
  ROSE: 'اوسیس نتورک',
  MINA: 'مینا پروتکل',
  CELO: 'سلو',
  KAVA: 'کاوا',
  KSM: 'کوزاما',
  OM: 'مانترا',
  MASK: 'ماسک نتورک',
  ENJ: 'انجین کوین',
  BAT: 'بیسیک اتنشن',
  ZIL: 'زیلیکا',
  ANKR: 'انکر',
  RVN: 'ریون‌کوین',
  HOT: 'هولو',
  BTT: 'بیت‌تورنت',
  XEC: 'ای‌کش',
  EGLD: 'مولتی‌ورس‌ایکس',
  IOTA: 'آیوتا',
  NEO: 'نئو',
  QTUM: 'کیوتوم',
  ONT: 'آنتولوژی',
  ONE: 'هارمونی',
  THETA: 'تتا',
  TWT: 'تراست ولت',
  ORDI: 'اوردینالز',
  RPL: 'راکت‌پول',
  SSV: 'اس‌اس‌وی',
  LPT: 'لایوپیر',
  LRC: 'لوپرینگ',
  GLM: 'گولم',
  GMT: 'استپن',
  APE: 'ایپ‌کوین',
  MAGIC: 'مجیک',
  YGG: 'ییلد گیلد',
  ILV: 'ایلویوم',
  SLP: 'اسموت لاو پوشن',
  ALICE: 'مای نیبر آلیس',
  JASMY: 'جاسمی',
  IOTX: 'آیوتکس',
  AKT: 'آکاش نتورک',
  HNT: 'هلیوم',
  W: 'ورم‌هول',
  WOO: 'وو نتورک',
  USUAL: 'یوژوال',
  MORPHO: 'مورفو',
  VIRTUAL: 'ویرچوالز',
  AIXBT: 'ای‌آی‌ایکس‌بی‌تی',
  CGPT: 'چین‌جی‌پی‌تی',
  BERA: 'براچین',
  KAITO: 'کایتو',
  MOVE: 'موومنت',
  ME: 'مجیک ادن',
  USDE: 'یواس‌دی‌ای',
  FDUSD: 'اف‌دی‌یواس‌دی',
  GNO: 'گنوسیس',
  QNT: 'کوانت',
  CVX: 'کانوکس',
  BAL: 'بالانسر',
  BAND: 'بند پروتکل',
  AUDIO: 'آدیوس',
  API3: 'ای‌پی‌آی۳',
  BICO: 'بیکونومی',
  CKB: 'نرووس نتورک',
  KDA: 'کادنا',
  NMR: 'نومرآیر',
  SKL: 'اسکیل',
  SXP: 'سولار',
  TRB: 'تلور',
  UMA: 'اوما',
  YFI: 'یرن فایننس',
  OMG: 'اومی‌سه‌گو',
  ALT: 'آلت‌لیر',
  MANTA: 'مانتا نتورک',
  DYM: 'دایمنشن',
  PIXEL: 'پیکسلز',
  PORTAL: 'پورتال',
  AEVO: 'ائوو',
  TNSR: 'تنسور',
  XAI: 'زای',
  RON: 'رونین',
  SUPER: 'سوپروورس',
  VANRY: 'وانارچین',
  ACE: 'فیوژنیست',
  BIO: 'بیو پروتکل',
  LINEA: 'لینیا',
  PUMP: 'پامپ',
  SONIC: 'سونیک',
  PI: 'پای نتورک',
};

export function getPersianCoinName(baseAsset: string): string {
  return PERSIAN_COIN_NAMES[baseAsset.toUpperCase()] || baseAsset.toUpperCase();
}

interface RawNobitexStat {
  isClosed?: boolean;
  bestSell?: string;
  bestBuy?: string;
  volumeSrc?: string;
  volumeDst?: string;
  latest?: string;
  dayLow?: string;
  dayHigh?: string;
  dayOpen?: string;
  dayChange?: string;
}

let cachedUnified: { data: { usdtTomanRate: number; markets: UnifiedMarketTicker[] }; at: number } | null =
  null;
let inFlightUnified: Promise<{ usdtTomanRate: number; markets: UnifiedMarketTicker[] }> | null =
  null;
const klineCache = new Map<string, { data: KlineCandle[]; at: number }>();
const inFlightKlines = new Map<string, Promise<KlineCandle[]>>();
const orderBookCache = new Map<string, { data: OrderBookSnapshot; at: number }>();
const inFlightOrderBooks = new Map<string, Promise<OrderBookSnapshot>>();
let lastKnownUsdtTomanRate = 269000;

export function getLastKnownUsdtTomanRate(): number {
  return cachedUnified?.data.usdtTomanRate || lastKnownUsdtTomanRate;
}

const walletCache = new Map<
  string,
  { wallets: Array<{ currency: string; balance: string; blockedBalance?: string }>; at: number }
>();
const inFlightWallets = new Map<
  string,
  Promise<Array<{ currency: string; balance: string; blockedBalance?: string }>>
>();
const openOrdersCache = new Map<string, { orders: RawNobitexOrderPayload[]; at: number }>();
const inFlightOpenOrders = new Map<string, Promise<RawNobitexOrderPayload[]>>();

let nobitexRateLimitUntil = 0;
let consecutiveRateLimits = 0;

export function getNobitexRateLimitRemainingMs(): number {
  return Math.max(0, nobitexRateLimitUntil - Date.now());
}

function getCredentialCacheKey(credentials?: NobitexCredentials | null): string {
  const raw = `${credentials?.authType || ''}:${credentials?.apiKey || ''}:${credentials?.apiToken || ''}`;
  return crypto.createHash('sha256').update(raw).digest('hex').slice(0, 16);
}

export function invalidateNobitexAccountCaches(credentials?: NobitexCredentials | null): void {
  if (!credentials) {
    walletCache.clear();
    openOrdersCache.clear();
    return;
  }
  const key = getCredentialCacheKey(credentials);
  walletCache.delete(key);
  openOrdersCache.delete(key);
}

export class NobitexRateLimitError extends Error {
  statusCode: number;
  retryAfterMs: number;
  constructor(message: string, retryAfterMs = 25_000) {
    super(message);
    this.name = 'NobitexRateLimitError';
    this.statusCode = 429;
    this.retryAfterMs = retryAfterMs;
  }
}

function isRateLimitText(text: string): boolean {
  const lower = text.toLowerCase();
  return (
    text.includes('تعداد درخواست') ||
    lower.includes('toomanyrequests') ||
    lower.includes('too many requests') ||
    lower.includes('rate limit')
  );
}

function recordNobitexRateLimit(retryAfterHeader?: string | null): number {
  if (process.env.NODE_ENV === 'test') {
    nobitexRateLimitUntil = Date.now() + 25;
    return 25;
  }
  const headerSec = Number(retryAfterHeader || '0');
  const cooldownMs =
    Number.isFinite(headerSec) && headerSec > 0
      ? Math.min(120_000, Math.max(15_000, headerSec * 1000))
      : Math.min(90_000, 20_000 * 2 ** Math.min(2, consecutiveRateLimits));
  consecutiveRateLimits = Math.min(4, consecutiveRateLimits + 1);
  nobitexRateLimitUntil = Math.max(nobitexRateLimitUntil, Date.now() + cooldownMs);
  logger.warn('nobitex.cooldown_activated', {
    cooldownMs,
    consecutiveRateLimits,
  });
  return cooldownMs;
}

// Serialized FIFO rate limiter & retry helper for Nobitex HTTP calls
let lastRequestAt = 0;
let throttleChain: Promise<void> = Promise.resolve();

function throttleNobitexCall(minSpacingMs = 180): Promise<void> {
  if (process.env.NODE_ENV === 'test') return Promise.resolve();
  const next = throttleChain.then(async () => {
    const now = Date.now();
    const wait = lastRequestAt + minSpacingMs - now;
    if (wait > 0) {
      await new Promise((r) => setTimeout(r, wait));
    }
    lastRequestAt = Date.now();
  });
  throttleChain = next.catch(() => {});
  return next;
}

function sleep(ms: number): Promise<void> {
  if (process.env.NODE_ENV === 'test') {
    return new Promise((r) => setTimeout(r, Math.min(ms, 25)));
  }
  return new Promise((r) => setTimeout(r, ms));
}

async function fetchWithRetry(
  url: string,
  init: RequestInit,
  options?: {
    maxRetries?: number;
    retryOn5xx?: boolean;
    retryOn429?: boolean;
    timeoutMs?: number;
    minSpacingMs?: number;
    bypassCooldown?: boolean;
  }
): Promise<Response> {
  const maxRetries = options?.maxRetries ?? 2;
  const retryOn5xx = options?.retryOn5xx !== false;
  const retryOn429 = options?.retryOn429 !== false;
  const timeoutMs = options?.timeoutMs ?? 10_000;
  const minSpacingMs = options?.minSpacingMs ?? 180;

  if (
    activeFetch === globalThis.fetch &&
    !options?.bypassCooldown &&
    nobitexRateLimitUntil > Date.now()
  ) {
    const remainingMs = Math.max(1000, nobitexRateLimitUntil - Date.now());
    const remainingSec = Math.ceil(remainingMs / 1000);
    throw new NobitexRateLimitError(
      `نوبیتکس به طور موقت تعداد درخواست را محدود کرده است؛ ربات به صورت خودکار ${remainingSec} ثانیه صبر می‌کند.`,
      remainingMs
    );
  }

  let lastErr: unknown;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    await throttleNobitexCall(minSpacingMs);
    try {
      const res = await activeFetch(url, {
        ...init,
        signal: init.signal || AbortSignal.timeout(timeoutMs),
      });

      if (res.status === 429) {
        const retryAfterSec = Number(res.headers.get('retry-after') || '0');
        if (!retryOn429 || attempt >= maxRetries || retryAfterSec > 4) {
          recordNobitexRateLimit(res.headers.get('retry-after'));
          return res;
        }
        const backoff = retryAfterSec > 0 ? retryAfterSec * 1000 : 800 * 2 ** attempt;
        logger.warn('nobitex.rate_limited', { attempt, backoff });
        await sleep(Math.min(backoff, 3000));
        continue;
      }

      if (retryOn5xx && res.status >= 500 && attempt < maxRetries) {
        await sleep(250 * 2 ** attempt);
        continue;
      }

      if (res.ok) {
        consecutiveRateLimits = 0;
      }

      return res;
    } catch (err) {
      lastErr = err;
      if (!retryOn5xx || attempt >= maxRetries) {
        throw err;
      }
      await sleep(250 * 2 ** attempt);
    }
  }
  throw lastErr instanceof Error ? lastErr : new Error('خطا در ارتباط با نوبیتکس');
}

export async function fetchNobitexUnifiedMarkets(): Promise<{
  usdtTomanRate: number;
  markets: UnifiedMarketTicker[];
}> {
  if (activeFetch === globalThis.fetch && cachedUnified && Date.now() - cachedUnified.at < 4000) {
    return cachedUnified.data;
  }
  if (activeFetch === globalThis.fetch && cachedUnified && getNobitexRateLimitRemainingMs() > 0 && Date.now() - cachedUnified.at < 60_000) {
    return cachedUnified.data;
  }
  if (activeFetch === globalThis.fetch && inFlightUnified) {
    return inFlightUnified;
  }

  const runFetch = async (): Promise<{
    usdtTomanRate: number;
    markets: UnifiedMarketTicker[];
  }> => {
    const base = getNobitexBase();
    const [rlsRes, usdtRes] = await Promise.all([
      fetchWithRetry(`${base}/market/stats?dstCurrency=rls`, {
        headers: { Accept: 'application/json' },
      }, { timeoutMs: 9000, minSpacingMs: 180 }),
      fetchWithRetry(`${base}/market/stats?dstCurrency=usdt`, {
        headers: { Accept: 'application/json' },
      }, { timeoutMs: 9000, minSpacingMs: 180 }),
    ]);

    if (!rlsRes.ok) {
      if (cachedUnified && Date.now() - cachedUnified.at < 60_000) {
        return cachedUnified.data;
      }
      throw new Error(`خطا در دریافت قیمت‌های تومانی نوبیتکس (HTTP ${rlsRes.status})`);
    }

  const rlsJson = (await rlsRes.json()) as { stats?: Record<string, RawNobitexStat> };
  const usdtJson = usdtRes.ok
    ? ((await usdtRes.json()) as { stats?: Record<string, RawNobitexStat> })
    : { stats: {} };

  const rlsStats = rlsJson.stats || {};
  const usdtStats = usdtJson.stats || {};

  const usdtRls = rlsStats['usdt-rls'];
  const usdtTomanRate = usdtRls ? Number(usdtRls.latest || usdtRls.bestBuy || 0) / 10 : 0;

  const assetsSet = new Set<string>();
  for (const k of Object.keys(rlsStats)) {
    if (k.endsWith('-rls')) assetsSet.add(k.slice(0, -4).toUpperCase());
  }
  for (const k of Object.keys(usdtStats)) {
    if (k.endsWith('-usdt')) assetsSet.add(k.slice(0, -5).toUpperCase());
  }

  const now = Date.now();
  const markets: UnifiedMarketTicker[] = [];

  for (const baseAsset of assetsSet) {
    const lower = baseAsset.toLowerCase();
    const rlsItem = rlsStats[`${lower}-rls`];
    const usdtItem = usdtStats[`${lower}-usdt`];

    const rlsFallbackRaw = Number(
      rlsItem?.latest || rlsItem?.bestSell || rlsItem?.bestBuy || rlsItem?.dayOpen || 0
    );
    const usdtFallbackRaw = Number(
      usdtItem?.latest || usdtItem?.bestSell || usdtItem?.bestBuy || usdtItem?.dayOpen || 0
    );

    const hasIrtMarket = Boolean(rlsItem && !rlsItem.isClosed && rlsFallbackRaw > 0);
    const hasUsdtMarket = Boolean(usdtItem && !usdtItem.isClosed && usdtFallbackRaw > 0);

    if (!hasIrtMarket && !hasUsdtMarket && baseAsset !== 'USDT') continue;

    let priceToman = hasIrtMarket ? rlsFallbackRaw / 10 : 0;
    let priceUsdt = hasUsdtMarket ? usdtFallbackRaw : 0;

    if (baseAsset === 'USDT') {
      priceUsdt = 1;
    } else {
      if (priceUsdt <= 0 && priceToman > 0 && usdtTomanRate > 0) {
        priceUsdt = priceToman / usdtTomanRate;
      }
      if (priceToman <= 0 && priceUsdt > 0 && usdtTomanRate > 0) {
        priceToman = priceUsdt * usdtTomanRate;
      }
    }

    if (priceToman <= 0 && priceUsdt <= 0) continue;

    const bestBuyToman = rlsItem ? Number(rlsItem.bestBuy || 0) / 10 : priceToman;
    const bestSellToman = rlsItem ? Number(rlsItem.bestSell || 0) / 10 : priceToman;

    const bestBuyUsdt = usdtItem
      ? Number(usdtItem.bestBuy || 0)
      : usdtTomanRate > 0
        ? bestBuyToman / usdtTomanRate
        : priceUsdt;
    const bestSellUsdt = usdtItem
      ? Number(usdtItem.bestSell || 0)
      : usdtTomanRate > 0
        ? bestSellToman / usdtTomanRate
        : priceUsdt;

    const high24hToman = rlsItem
      ? Number(rlsItem.dayHigh || 0) / 10
      : Number(usdtItem?.dayHigh || 0) * usdtTomanRate;
    const low24hToman = rlsItem
      ? Number(rlsItem.dayLow || 0) / 10
      : Number(usdtItem?.dayLow || 0) * usdtTomanRate;

    const high24hUsdt = usdtItem
      ? Number(usdtItem.dayHigh || 0)
      : usdtTomanRate > 0
        ? high24hToman / usdtTomanRate
        : 0;
    const low24hUsdt = usdtItem
      ? Number(usdtItem.dayLow || 0)
      : usdtTomanRate > 0
        ? low24hToman / usdtTomanRate
        : 0;

    const change24hPercent = rlsItem
      ? Number(rlsItem.dayChange || 0)
      : Number(usdtItem?.dayChange || 0);

    const volumeToman = rlsItem ? Number(rlsItem.volumeDst || 0) / 10 : 0;
    const volumeUsdt = usdtItem
      ? Number(usdtItem.volumeDst || 0)
      : usdtTomanRate > 0
        ? volumeToman / usdtTomanRate
        : 0;
    const volumeSrc = Number(rlsItem?.volumeSrc || usdtItem?.volumeSrc || 0);

    markets.push({
      baseAsset,
      persianName: getPersianCoinName(baseAsset),
      symbolIrt: `${baseAsset}IRT`,
      symbolUsdt: `${baseAsset}USDT`,
      hasIrtMarket,
      hasUsdtMarket,
      priceToman,
      priceUsdt,
      bestBuyToman,
      bestSellToman,
      bestBuyUsdt,
      bestSellUsdt,
      high24hToman,
      low24hToman,
      high24hUsdt,
      low24hUsdt,
      change24hPercent,
      volumeToman,
      volumeUsdt,
      volumeSrc,
      usdtTomanRate,
      timestamp: now,
    });
  }

  markets.sort(
    (a, b) => b.volumeToman + b.volumeUsdt * usdtTomanRate - (a.volumeToman + a.volumeUsdt * usdtTomanRate)
  );

  if (usdtTomanRate > 0) {
    lastKnownUsdtTomanRate = usdtTomanRate;
  }
  const payload = { usdtTomanRate, markets };
  cachedUnified = { data: payload, at: now };
  return payload;
  };

  if (activeFetch !== globalThis.fetch) {
    return runFetch();
  }

  inFlightUnified = runFetch().finally(() => {
    inFlightUnified = null;
  });
  return inFlightUnified;
}

const TIMEFRAME_TO_UDF: Record<Timeframe, { resolution: string; secondsPerBar: number }> = {
  '1m': { resolution: '1', secondsPerBar: 60 },
  '5m': { resolution: '5', secondsPerBar: 300 },
  '15m': { resolution: '15', secondsPerBar: 900 },
  '1h': { resolution: '60', secondsPerBar: 3600 },
  '4h': { resolution: '240', secondsPerBar: 14400 },
  '1d': { resolution: 'D', secondsPerBar: 86400 },
};

export async function fetchNobitexKlines(
  symbol: string,
  timeframe: Timeframe = '1h',
  limit = 160
): Promise<KlineCandle[]> {
  const cleanSymbol = symbol.toUpperCase();
  const cacheKey = `${cleanSymbol}:${timeframe}:${limit}`;
  const ttlMs = timeframe === '1m' ? 6000 : timeframe === '5m' ? 10_000 : 15_000;
  if (activeFetch === globalThis.fetch) {
    const cached = klineCache.get(cacheKey);
    if (cached && Date.now() - cached.at < ttlMs) {
      return cached.data;
    }
    const existing = inFlightKlines.get(cacheKey);
    if (existing) return existing;
  }

  const runFetch = async (): Promise<KlineCandle[]> => {
    const cfg = TIMEFRAME_TO_UDF[timeframe] || TIMEFRAME_TO_UDF['1h'];
    const toSec = Math.floor(Date.now() / 1000);
    const fromSec = toSec - cfg.secondsPerBar * Math.max(limit, 120);

    const url = `${getNobitexBase()}/market/udf/history?symbol=${encodeURIComponent(cleanSymbol)}&resolution=${encodeURIComponent(cfg.resolution)}&from=${fromSec}&to=${toSec}`;
    const res = await fetchWithRetry(
      url,
      { headers: { Accept: 'application/json' } },
      { timeoutMs: 9000 }
    );

    if (!res.ok) {
      throw new Error(`دریافت کندل‌های نوبیتکس ناموفق بود (HTTP ${res.status})`);
    }

    const data = (await res.json()) as {
      s?: string;
      t?: number[];
      o?: number[];
      h?: number[];
      l?: number[];
      c?: number[];
      v?: number[];
    };

    if (data.s !== 'ok' || !Array.isArray(data.t) || data.t.length === 0) {
      return [];
    }

    const candles: KlineCandle[] = [];
    for (let i = 0; i < data.t.length; i++) {
      const openTime = Number(data.t[i]) * 1000;
      candles.push({
        openTime,
        open: Number(data.o?.[i] ?? 0),
        high: Number(data.h?.[i] ?? 0),
        low: Number(data.l?.[i] ?? 0),
        close: Number(data.c?.[i] ?? 0),
        volume: Number(data.v?.[i] ?? 0),
        closeTime: openTime + cfg.secondsPerBar * 1000,
        quoteVolume: Number(data.v?.[i] ?? 0) * Number(data.c?.[i] ?? 0),
        trades: 0,
      });
    }

    const result = candles.slice(-limit);
    klineCache.set(cacheKey, { data: result, at: Date.now() });
    if (klineCache.size > 150) {
      const oldestKey = klineCache.keys().next().value;
      if (oldestKey) klineCache.delete(oldestKey);
    }
    return result;
  };

  if (activeFetch !== globalThis.fetch) {
    return runFetch();
  }
  const p = runFetch().finally(() => {
    inFlightKlines.delete(cacheKey);
  });
  inFlightKlines.set(cacheKey, p);
  return p;
}

export async function fetchNobitexOrderBook(symbol: string, limit = 16): Promise<OrderBookSnapshot> {
  const clean = symbol.toUpperCase();
  const cacheKey = `${clean}:${limit}`;
  if (activeFetch === globalThis.fetch) {
    const cached = orderBookCache.get(cacheKey);
    if (cached && Date.now() - cached.at < 1500) {
      return cached.data;
    }
    const existing = inFlightOrderBooks.get(cacheKey);
    if (existing) return existing;
  }

  const runFetch = async (): Promise<OrderBookSnapshot> => {
    const quoteCurrency: QuoteCurrency = clean.endsWith('USDT') ? 'USDT' : 'IRT';
    const divisor = quoteCurrency === 'IRT' ? 10 : 1;

    // CRITICAL: Nobitex /v2/orderbook returns bids & asks swapped relative to standard conventions.
    // /v3/orderbook returns canonical bids (buyers, lower prices) and asks (sellers, higher prices).
    const res = await fetchWithRetry(
      `${getNobitexBase()}/v3/orderbook/${encodeURIComponent(clean)}`,
      { headers: { Accept: 'application/json' } },
      { timeoutMs: 7000 }
    );
    if (!res.ok) {
      throw new Error(`خطا در دریافت دفتر سفارشات نوبیتکس (HTTP ${res.status})`);
    }

    const data = (await res.json()) as {
      lastUpdate?: number;
      lastTradePrice?: string;
      asks?: Array<[string, string]>;
      bids?: Array<[string, string]>;
    };

    const parsedBids = (data.bids || [])
      .map(([p, q]) => ({ price: Number(p) / divisor, quantity: Number(q) }))
      .filter((lvl) => Number.isFinite(lvl.price) && lvl.price > 0 && Number.isFinite(lvl.quantity) && lvl.quantity > 0)
      .sort((a, b) => b.price - a.price)
      .slice(0, limit);

    let bidAcc = 0;
    const bids = parsedBids.map((lvl) => {
      bidAcc += lvl.quantity;
      return { price: lvl.price, quantity: lvl.quantity, total: bidAcc };
    });

    const parsedAsks = (data.asks || [])
      .map(([p, q]) => ({ price: Number(p) / divisor, quantity: Number(q) }))
      .filter((lvl) => Number.isFinite(lvl.price) && lvl.price > 0 && Number.isFinite(lvl.quantity) && lvl.quantity > 0)
      .sort((a, b) => a.price - b.price)
      .slice(0, limit);

    let askAcc = 0;
    const asks = parsedAsks.map((lvl) => {
      askAcc += lvl.quantity;
      return { price: lvl.price, quantity: lvl.quantity, total: askAcc };
    });

    const bestBid = bids[0]?.price || 0;
    const bestAsk = asks[0]?.price || 0;
    const spread = bestAsk > 0 && bestBid > 0 ? Math.max(0, bestAsk - bestBid) : 0;
    const spreadPercent = bestAsk > 0 ? (spread / bestAsk) * 100 : 0;

    const snap: OrderBookSnapshot = {
      symbol: clean,
      quoteCurrency,
      timestamp: data.lastUpdate || Date.now(),
      lastTradePrice: Number(data.lastTradePrice || 0) / divisor,
      bids,
      asks,
      spread,
      spreadPercent,
    };
    orderBookCache.set(cacheKey, { data: snap, at: Date.now() });
    if (orderBookCache.size > 150) {
      const oldestKey = orderBookCache.keys().next().value;
      if (oldestKey) orderBookCache.delete(oldestKey);
    }
    return snap;
  };

  if (activeFetch !== globalThis.fetch) {
    return runFetch();
  }
  const p = runFetch().finally(() => {
    inFlightOrderBooks.delete(cacheKey);
  });
  inFlightOrderBooks.set(cacheKey, p);
  return p;
}

export async function fetchNobitexRecentTrades(symbol: string, limit = 25): Promise<RecentTrade[]> {
  const clean = symbol.toUpperCase();
  const divisor = clean.endsWith('USDT') ? 1 : 10;

  const res = await fetchWithRetry(
    `${getNobitexBase()}/v2/trades/${encodeURIComponent(clean)}`,
    { headers: { Accept: 'application/json' } },
    { timeoutMs: 7000 }
  );
  if (!res.ok) {
    throw new Error(`خطا در دریافت معاملات اخیر نوبیتکس (HTTP ${res.status})`);
  }
  const data = (await res.json()) as {
    trades?: Array<{
      time: number;
      price: string;
      volume: string;
      type: 'buy' | 'sell';
    }>;
  };

  return (data.trades || []).slice(0, limit).map((tr, idx) => ({
    id: `${tr.time}-${idx}`,
    price: Number(tr.price) / divisor,
    quantity: Number(tr.volume),
    time: tr.time,
    isBuyerMaker: tr.type === 'sell',
  }));
}

// =========================================================================
// Nobitex Private Authenticated API (STRICT per-user credentials — zero env fallback!)
// Supports both Nobitex Ed25519 Key Pair (API Key + Secret Key) and Legacy Token
// =========================================================================
export interface NobitexCredentials {
  authType?: NobitexAuthType;
  apiToken?: string;
  apiKey?: string;
  secretKey?: string;
}

export class NobitexAuthError extends Error {
  statusCode: number;
  constructor(message: string, statusCode = 401) {
    super(message);
    this.name = 'NobitexAuthError';
    this.statusCode = statusCode;
  }
}

const ED25519_PKCS8_PREFIX = Buffer.from('302e020100300506032b657004220420', 'hex');

function stripKeyNoise(raw: string): string {
  return raw
    .trim()
    .replace(/^['"`]+|['"`]+$/g, '')
    .replace(/\\n/g, '\n')
    .trim();
}

export function resolveNobitexAuthType(credentials?: NobitexCredentials | null): NobitexAuthType {
  if (!credentials) return 'TOKEN';
  if (credentials.authType === 'KEY_PAIR') return 'KEY_PAIR';
  if (credentials.apiKey?.trim() || credentials.secretKey?.trim()) return 'KEY_PAIR';
  return 'TOKEN';
}

export function parseEd25519PrivateKey(rawSecret: string): crypto.KeyObject {
  const cleaned = stripKeyNoise(rawSecret);
  if (!cleaned) {
    throw new NobitexAuthError('کلید مخفی (Secret Key) نوبیتکس وارد نشده است.', 400);
  }
  if (/BEGIN\s+PUBLIC\s+KEY/i.test(cleaned)) {
    throw new NobitexAuthError(
      'کلید عمومی (Public Key) در فیلد Secret Key وارد شده است؛ لطفاً کلید خصوصی/مخفی (Secret Key) را وارد کنید.',
      400
    );
  }

  try {
    if (/BEGIN\s+(?:ENCRYPTED\s+)?PRIVATE\s+KEY/i.test(cleaned)) {
      const keyObj = crypto.createPrivateKey({ key: cleaned, format: 'pem' });
      if (keyObj.asymmetricKeyType !== 'ed25519') {
        throw new Error('کلید از نوع Ed25519 نیست.');
      }
      return keyObj;
    }

    const compact = cleaned.replace(/\s+/g, '');
    let buf: Buffer | null = null;

    if (/^[0-9a-fA-F]+$/.test(compact) && (compact.length === 64 || compact.length === 128 || compact.length === 96)) {
      buf = Buffer.from(compact, 'hex');
    } else {
      const stdB64 = compact.replace(/-/g, '+').replace(/_/g, '/');
      const padded = stdB64 + '='.repeat((4 - (stdB64.length % 4)) % 4);
      const decoded = Buffer.from(padded, 'base64');
      if (decoded.length > 0) {
        buf = decoded;
      }
    }

    if (!buf) {
      throw new Error('فرمت کلید قابل رمزگشایی نیست.');
    }

    let keyObj: crypto.KeyObject;
    if (buf.length === 32) {
      keyObj = crypto.createPrivateKey({
        key: Buffer.concat([ED25519_PKCS8_PREFIX, buf]),
        format: 'der',
        type: 'pkcs8',
      });
    } else if (buf.length === 64) {
      // TweetNaCl / libsodium 64-byte secretKey (32-byte seed + 32-byte public key)
      keyObj = crypto.createPrivateKey({
        key: Buffer.concat([ED25519_PKCS8_PREFIX, buf.subarray(0, 32)]),
        format: 'der',
        type: 'pkcs8',
      });
    } else if (buf.length === 48 || buf[0] === 0x30) {
      keyObj = crypto.createPrivateKey({
        key: buf,
        format: 'der',
        type: 'pkcs8',
      });
    } else {
      throw new Error(`طول کلید خصوصی نوبیتکس نامعتبر است (${buf.length} بایت).`);
    }

    if (keyObj.asymmetricKeyType !== 'ed25519') {
      throw new Error('الگوریتم کلید خصوصی با Ed25519 نوبیتکس مطابقت ندارد.');
    }
    return keyObj;
  } catch (err) {
    if (err instanceof NobitexAuthError) throw err;
    throw new NobitexAuthError(
      'فرمت Secret Key نوبیتکس معتبر نیست. کلید خصوصی Ed25519 باید به صورت Base64، Base64URL، Hex (۶۴ کاراکتر) یا PEM باشد.',
      400
    );
  }
}

export function validateNobitexCredentialsFormat(credentials?: NobitexCredentials | null): NobitexAuthType {
  const authType = resolveNobitexAuthType(credentials);
  if (authType === 'KEY_PAIR') {
    const apiKey = stripKeyNoise(credentials?.apiKey || '');
    const secretKey = stripKeyNoise(credentials?.secretKey || '');
    if (apiKey.length < 8) {
      throw new NobitexAuthError('کلید API نوبیتکس (API Key) نامعتبر یا کوتاه است.', 400);
    }
    parseEd25519PrivateKey(secretKey);
    return 'KEY_PAIR';
  }

  const token = stripKeyNoise(credentials?.apiToken || '');
  if (token.length < 12) {
    throw new NobitexAuthError('توکن شخصی API نوبیتکس برای این حساب ثبت یا نامعتبر است.', 401);
  }
  return 'TOKEN';
}

function buildNobitexAuthHeaders(
  method: string,
  pathWithQuery: string,
  rawBody: string,
  credentials?: NobitexCredentials | null
): Record<string, string> {
  const authType = validateNobitexCredentialsFormat(credentials);
  const baseHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    Accept: 'application/json',
    'User-Agent': 'TraderBot/ALITrader-1.0',
  };

  if (authType === 'KEY_PAIR') {
    const apiKey = stripKeyNoise(credentials!.apiKey || '');
    const privateKey = parseEd25519PrivateKey(credentials!.secretKey || '');
    const timestamp = Math.floor(Date.now() / 1000).toString();
    const payload = `${timestamp}${method.toUpperCase()}${pathWithQuery}${rawBody}`;
    const signature = crypto
      .sign(null, Buffer.from(payload, 'utf8'), privateKey)
      .toString('base64url');

    return {
      ...baseHeaders,
      'Nobitex-Key': apiKey,
      'Nobitex-Timestamp': timestamp,
      'Nobitex-Signature': signature,
    };
  }

  const token = stripKeyNoise(credentials!.apiToken || '');
  return {
    ...baseHeaders,
    Authorization: `Token ${token}`,
  };
}

function formatNobitexErrorMessage(
  status: number,
  parsed: Record<string, unknown> | null,
  rawText: string
): string {
  const code = String(parsed?.code || '').trim();
  const detail = String(parsed?.detail || '').trim();
  const message = String(parsed?.message || '').trim();
  const combined = `${code} ${detail} ${message}`.toLowerCase();

  if (!parsed) {
    if (status === 403) {
      return 'درخواست توسط فایروال یا محدودیت آی‌پی نوبیتکس مسدود شد (HTTP 403). سرور باید با آی‌پی ایران یا آی‌پی ثبت‌شده در لیست سفید (IP Whitelist) کلید نوبیتکس متصل شود.';
    }
    if (status === 429) {
      return 'محدودیت تعداد درخواست نوبیتکس (HTTP 429). لطفاً چند لحظه بعد دوباره تلاش کنید.';
    }
    if (status >= 500) {
      return `سرور نوبیتکس موقتاً در دسترس نیست (HTTP ${status}).`;
    }
    return `پاسخ غیرمنتظره از سرور نوبیتکس (HTTP ${status})${rawText ? `: ${redactSensitiveText(rawText.slice(0, 120))}` : ''}`;
  }

  if (status === 429 || isRateLimitText(combined) || isRateLimitText(rawText)) {
    return 'محدودیت موقت تعداد درخواست نوبیتکس (تعداد درخواست بیش از حد مجاز). ربات کمی صبر کرده و به صورت خودکار ادامه می‌دهد.';
  }

  if (combined.includes('signature') && combined.includes('invalid')) {
    return 'امضای درخواست توسط نوبیتکس رد شد (Invalid Signature). لطفاً مطمئن شوید Secret Key متعلق به همین API Key بوده و کامل کپی شده است.';
  }
  if (combined.includes('api key is invalid') || combined.includes('invalid api key')) {
    return 'API Key نوبیتکس نامعتبر یا غیرفعال است. در پنل نوبیتکس وضعیت کلید را بررسی کنید.';
  }
  if (combined.includes('invalidtoken') || combined.includes('invalid token')) {
    return 'توکن نوبیتکس نامعتبر یا منقضی شده است. اگر نوبیتکس به شما API Key و Secret Key داده، از بخش «API Key + Secret Key» وارد کنید.';
  }
  if (combined.includes('timestamp')) {
    return 'اختلاف زمان سرور با ساعت جهانی نوبیتکس بیش از حد مجاز (۳۰ ثانیه) است.';
  }
  if (combined.includes('ip') && (combined.includes('allow') || combined.includes('whitelist') || combined.includes('forbidden'))) {
    return 'آی‌پی سرور در لیست سفید (IP Whitelist) کلید نوبیتکس مجاز نیست یا دسترسی محدود به آی‌پی ایران است.';
  }
  if (status === 403 || combined.includes('permission') || combined.includes('forbidden')) {
    return `عدم مجوز کافی روی کلید نوبیتکس (HTTP 403): دسترسی‌های Read و Trade را روی کلید API در پنل نوبیتکس فعال کنید.${detail ? ` (${redactSensitiveText(detail)})` : ''}`;
  }

  return redactSensitiveText(message || detail || `خطای نوبیتکس (HTTP ${status})`);
}

async function nobitexAuthRequest<T>(
  path: string,
  body: Record<string, unknown> = {},
  credentials?: NobitexCredentials | null,
  options?: {
    retryOn5xx?: boolean;
    retryOn429?: boolean;
    maxRetries?: number;
    timeoutMs?: number;
    minSpacingMs?: number;
  }
): Promise<T> {
  // CRITICAL MULTI-TENANT GUARD: Never fall back to process.env.NOBITEX_API_TOKEN!
  const rawBody = JSON.stringify(body);
  const headers = buildNobitexAuthHeaders('POST', path, rawBody, credentials);

  const res = await fetchWithRetry(
    `${getNobitexBase()}${path}`,
    {
      method: 'POST',
      headers,
      body: rawBody,
    },
    {
      maxRetries: options?.maxRetries ?? 1,
      retryOn5xx: options?.retryOn5xx ?? true,
      retryOn429: options?.retryOn429 ?? false,
      timeoutMs: options?.timeoutMs ?? 10_000,
      minSpacingMs: options?.minSpacingMs ?? 320,
    }
  );

  const text = await res.text();
  let parsed: Record<string, unknown> | null = null;
  try {
    parsed = JSON.parse(text) as Record<string, unknown>;
  } catch {
    const errText = formatNobitexErrorMessage(res.status, null, text);
    if (res.status === 401 || res.status === 403) {
      throw new NobitexAuthError(errText, res.status);
    }
    if (res.status === 429 || isRateLimitText(text)) {
      const waitMs = recordNobitexRateLimit(res.headers.get('retry-after'));
      throw new NobitexRateLimitError(errText, waitMs);
    }
    throw new Error(errText);
  }

  if (
    res.status === 401 ||
    res.status === 403 ||
    parsed.code === 'InvalidToken' ||
    parsed.code === 'InvalidSignature'
  ) {
    throw new NobitexAuthError(formatNobitexErrorMessage(res.status, parsed, text), res.status);
  }

  const msgCombined = `${String(parsed.code || '')} ${String(parsed.detail || '')} ${String(parsed.message || '')}`;
  if (res.status === 429 || isRateLimitText(msgCombined)) {
    const waitMs = recordNobitexRateLimit(res.headers.get('retry-after'));
    throw new NobitexRateLimitError(formatNobitexErrorMessage(res.status, parsed, text), waitMs);
  }

  if (!res.ok || parsed.status === 'failed') {
    throw new Error(formatNobitexErrorMessage(res.status, parsed, text));
  }

  return parsed as T;
}

export async function verifyNobitexCredentials(
  credentials: NobitexCredentials
): Promise<{
  walletsCount: number;
  authType: NobitexAuthType;
}> {
  const authType = validateNobitexCredentialsFormat(credentials);
  const data = await nobitexAuthRequest<{
    wallets?: Array<{ currency: string; balance: string }>;
  }>('/users/wallets/list', {}, credentials, {
    maxRetries: 0,
    retryOn5xx: false,
    timeoutMs: 8_000,
  });

  return {
    walletsCount: (data.wallets || []).filter((w) => Number(w.balance) > 0).length,
    authType,
  };
}

export async function verifyNobitexToken(apiToken: string): Promise<{
  walletsCount: number;
}> {
  const res = await verifyNobitexCredentials({ authType: 'TOKEN', apiToken });
  return { walletsCount: res.walletsCount };
}

async function fetchNobitexWalletsCached(
  credentials?: NobitexCredentials | null,
  forceRefresh = false
): Promise<Array<{ currency: string; balance: string; blockedBalance?: string }>> {
  const key = getCredentialCacheKey(credentials);
  const cached = walletCache.get(key);
  const now = Date.now();
  if (!forceRefresh && activeFetch === globalThis.fetch && cached) {
    if (now - cached.at < 4500) return cached.wallets;
    if (getNobitexRateLimitRemainingMs() > 0 && now - cached.at < 60_000) {
      return cached.wallets;
    }
  }
  const existingFlight = inFlightWallets.get(key);
  if (activeFetch === globalThis.fetch && existingFlight) {
    return existingFlight;
  }

  const run = (async () => {
    try {
      const data = await nobitexAuthRequest<{
        wallets?: Array<{
          currency: string;
          balance: string;
          blockedBalance?: string;
        }>;
      }>('/users/wallets/list', {}, credentials);
      const wallets = data.wallets || [];
      walletCache.set(key, { wallets, at: Date.now() });
      return wallets;
    } catch (err) {
      if (err instanceof NobitexRateLimitError && cached && Date.now() - cached.at < 60_000) {
        return cached.wallets;
      }
      throw err;
    } finally {
      inFlightWallets.delete(key);
    }
  })();

  if (activeFetch === globalThis.fetch) {
    inFlightWallets.set(key, run);
  }
  return run;
}

export async function fetchNobitexLiveBalances(
  markets: UnifiedMarketTicker[],
  usdtTomanRate: number,
  credentials?: NobitexCredentials | null
): Promise<SpotBalance[]> {
  const wallets = await fetchNobitexWalletsCached(credentials);

  const tomanPriceMap = new Map<string, number>();
  const usdtPriceMap = new Map<string, number>();
  tomanPriceMap.set('IRT', 1);
  usdtPriceMap.set('IRT', usdtTomanRate > 0 ? 1 / usdtTomanRate : 0);
  usdtPriceMap.set('USDT', 1);
  tomanPriceMap.set('USDT', usdtTomanRate);

  for (const m of markets) {
    tomanPriceMap.set(m.baseAsset, m.priceToman);
    usdtPriceMap.set(m.baseAsset, m.priceUsdt);
  }

  return wallets
    .map((w) => {
      const rawCurrency = w.currency.toUpperCase();
      const isRls = rawCurrency === 'RLS';
      const asset = isRls ? 'IRT' : rawCurrency;
      const divisor = isRls ? 10 : 1;
      const total = Number(w.balance || 0) / divisor;
      const locked = Number(w.blockedBalance || 0) / divisor;
      const free = Math.max(0, total - locked);

      const unitToman = tomanPriceMap.get(asset) || 0;
      const unitUsdt = usdtPriceMap.get(asset) || 0;

      return {
        asset,
        persianName: asset === 'IRT' ? 'تومان' : getPersianCoinName(asset),
        free,
        locked,
        total,
        tomanValue: total * unitToman,
        usdtValue: total * unitUsdt,
      };
    })
    .filter((b) => b.total > 0)
    .sort((a, b) => b.tomanValue - a.tomanValue);
}

function toPositiveFinite(value: unknown): number {
  if (value === null || value === undefined || value === '') return 0;
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? n : 0;
}

interface RawNobitexOrderPayload {
  id: number | string;
  type: string;
  execution: string;
  market?: string;
  srcCurrency?: string;
  dstCurrency?: string;
  price?: string;
  averagePrice?: string;
  amount?: string;
  matchedAmount?: string;
  totalPrice?: string;
  status?: string;
  created_at?: string;
}

export async function fetchNobitexLiveOpenOrders(
  credentials?: NobitexCredentials | null
): Promise<SpotOrder[]> {
  const key = getCredentialCacheKey(credentials);
  const cached = openOrdersCache.get(key);
  const now = Date.now();
  if (activeFetch === globalThis.fetch && cached) {
    if (now - cached.at < 4500) {
      return cached.orders.map((o) => mapRawNobitexOrder(o));
    }
    if (getNobitexRateLimitRemainingMs() > 0 && now - cached.at < 60_000) {
      return cached.orders.map((o) => mapRawNobitexOrder(o));
    }
  }
  const existingFlight = inFlightOpenOrders.get(key);
  if (activeFetch === globalThis.fetch && existingFlight) {
    const orders = await existingFlight;
    return orders.map((o) => mapRawNobitexOrder(o));
  }

  const run = (async () => {
    try {
      const data = await nobitexAuthRequest<{
        orders?: RawNobitexOrderPayload[];
      }>('/market/orders/list', { status: 'active' }, credentials);
      const orders = data.orders || [];
      openOrdersCache.set(key, { orders, at: Date.now() });
      return orders;
    } catch (err) {
      if (err instanceof NobitexRateLimitError && cached && Date.now() - cached.at < 60_000) {
        return cached.orders;
      }
      throw err;
    } finally {
      inFlightOpenOrders.delete(key);
    }
  })();

  if (activeFetch === globalThis.fetch) {
    inFlightOpenOrders.set(key, run);
  }
  const orders = await run;
  return orders.map((o) => mapRawNobitexOrder(o));
}

export function mapRawNobitexOrder(
  o: RawNobitexOrderPayload,
  expectedQuoteCurrency?: QuoteCurrency
): SpotOrder {
  const marketStr = (o.market || '').toUpperCase().trim();
  const dstRaw = (o.dstCurrency || '').trim();
  const dstLower = dstRaw.toLowerCase();
  const isUsdtExplicit =
    dstLower === 'usdt' || marketStr.endsWith('-USDT') || marketStr.endsWith('USDT');
  const isIrt =
    !isUsdtExplicit &&
    (dstLower === 'rls' ||
      dstLower === 'irt' ||
      dstRaw === '﷼' ||
      dstRaw.includes('ریال') ||
      dstRaw.includes('تومان') ||
      marketStr.endsWith('-RLS') ||
      marketStr.endsWith('-IRT') ||
      marketStr.endsWith('RLS') ||
      marketStr.endsWith('IRT') ||
      expectedQuoteCurrency === 'IRT');

  const quoteCurrency: QuoteCurrency = isIrt ? 'IRT' : 'USDT';
  const divisor = isIrt ? 10 : 1;

  const baseFromMarket = marketStr.includes('-') ? marketStr.split('-')[0].trim() : '';
  const baseAsset = baseFromMarket || (o.srcCurrency || '').trim().toUpperCase();

  const quantity = toPositiveFinite(o.amount);
  const matchedQty = toPositiveFinite(o.matchedAmount);
  const rawStatus = (o.status || '').toLowerCase();
  const status: SpotOrder['status'] =
    rawStatus === 'done'
      ? 'FILLED'
      : rawStatus === 'canceled'
        ? 'CANCELED'
        : matchedQty > 0 && matchedQty < quantity
          ? 'PARTIALLY_FILLED'
          : 'NEW';

  const executedQty = status === 'FILLED' && matchedQty <= 0 ? quantity : matchedQty;
  const effectiveQty = executedQty > 0 ? executedQty : quantity;
  const avgRaw = toPositiveFinite(o.averagePrice);
  const limitRaw = toPositiveFinite(o.price);
  const totalRaw = toPositiveFinite(o.totalPrice);

  const totalQuoteAmount =
    totalRaw > 0
      ? totalRaw / divisor
      : avgRaw > 0 && effectiveQty > 0
        ? (avgRaw / divisor) * effectiveQty
        : limitRaw > 0 && effectiveQty > 0
          ? (limitRaw / divisor) * effectiveQty
          : 0;

  const price =
    avgRaw > 0
      ? avgRaw / divisor
      : totalQuoteAmount > 0 && effectiveQty > 0
        ? totalQuoteAmount / effectiveQty
        : limitRaw > 0
          ? limitRaw / divisor
          : 0;

  return {
    orderId: String(o.id),
    symbol: `${baseAsset}${quoteCurrency}`,
    baseAsset,
    quoteCurrency,
    side: (o.type || '').toLowerCase() === 'buy' ? 'BUY' : 'SELL',
    type: (o.execution || '').toLowerCase() === 'market' ? 'MARKET' : 'LIMIT',
    price,
    quantity,
    executedQty,
    totalQuoteAmount,
    status,
    mode: 'live',
    source: 'MANUAL',
    createdAt: o.created_at ? Date.parse(o.created_at) : Date.now(),
  };
}

export async function fetchNobitexOrderStatus(
  orderId: string,
  credentials?: NobitexCredentials | null,
  expectedQuoteCurrency?: QuoteCurrency
): Promise<SpotOrder | null> {
  const data = await nobitexAuthRequest<{
    order?: RawNobitexOrderPayload;
  }>('/market/orders/status', { id: orderId }, credentials);

  if (!data.order) return null;
  return mapRawNobitexOrder(data.order, expectedQuoteCurrency);
}

const OPTIONS_TTL_MS = 10 * 60_000;
const OPTIONS_FALLBACK_TTL_MS = 60_000;

export async function getNobitexMarketRules(symbol: string): Promise<{
  minNotional: number;
  amountStep: number;
}> {
  const cleanSymbol = symbol.toUpperCase().trim();
  const quoteCurrency: QuoteCurrency = cleanSymbol.endsWith('USDT') ? 'USDT' : 'IRT';
  const now = Date.now();

  if (!cachedOptions || now - cachedOptions.fetchedAt > OPTIONS_TTL_MS) {
    if (!inFlightOptionsFetch) {
      inFlightOptionsFetch = (async () => {
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), 3000);
        try {
          const res = await activeFetch(`${getNobitexBase()}/v2/options`, {
            headers: { Accept: 'application/json' },
            signal: controller.signal,
          });
          if (!res.ok) {
            throw new Error(`HTTP ${res.status}`);
          }
          const json = (await res.json()) as {
            nobitex?: {
              minOrders?: { rls?: string | number; usdt?: string | number };
              amountPrecisions?: Record<string, string | number>;
            };
          };
          const minRls = Number(json.nobitex?.minOrders?.rls || 500_000);
          const minIrt = Number.isFinite(minRls) && minRls > 0 ? minRls / 10 : getMinimumOrderNotional('IRT');
          const minUsdtRaw = Number(json.nobitex?.minOrders?.usdt || 0.5);
          const minUsdt =
            Number.isFinite(minUsdtRaw) && minUsdtRaw > 0
              ? minUsdtRaw
              : getMinimumOrderNotional('USDT');
          const amountPrecisions: Record<string, number> = {};
          for (const [k, v] of Object.entries(json.nobitex?.amountPrecisions || {})) {
            const parsed = Number(v);
            if (Number.isFinite(parsed) && parsed > 0) {
              amountPrecisions[k.toUpperCase()] = parsed;
            }
          }
          cachedOptions = {
            minIrt,
            minUsdt,
            amountPrecisions,
            fetchedAt: Date.now(),
          };
          return cachedOptions;
        } catch {
          const fallback: NobitexOptionsCache = {
            minIrt: cachedOptions?.minIrt ?? getMinimumOrderNotional('IRT'),
            minUsdt: cachedOptions?.minUsdt ?? getMinimumOrderNotional('USDT'),
            amountPrecisions: cachedOptions?.amountPrecisions ?? {},
            fetchedAt: Date.now() - OPTIONS_TTL_MS + OPTIONS_FALLBACK_TTL_MS,
          };
          cachedOptions = fallback;
          return fallback;
        } finally {
          clearTimeout(timer);
          inFlightOptionsFetch = null;
        }
      })();
    }
    await inFlightOptionsFetch;
  }

  const minNotional =
    quoteCurrency === 'IRT'
      ? cachedOptions?.minIrt ?? getMinimumOrderNotional('IRT')
      : cachedOptions?.minUsdt ?? getMinimumOrderNotional('USDT');
  const amountStep = cachedOptions?.amountPrecisions[cleanSymbol] || 1e-6;
  return { minNotional, amountStep };
}

/**
 * Nobitex strictly enforces `clientOrderId` length <= 32 characters.
 * Preserves valid short IDs (<= 32 chars) and deterministically compacts longer
 * idempotency keys using a SHA-256 suffix so retries remain idempotent without
 * ever exceeding 32 characters.
 */
export function formatNobitexClientOrderId(raw?: string | null): string | undefined {
  const cleaned = (raw || '').trim();
  if (!cleaned) return undefined;
  if (cleaned.length <= 32 && /^[A-Za-z0-9_-]+$/.test(cleaned)) {
    return cleaned;
  }
  const safePrefix =
    cleaned
      .replace(/[^A-Za-z0-9_-]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 10) || 'ord';
  const hashLen = Math.max(8, 32 - safePrefix.length - 1);
  const hash = crypto.createHash('sha256').update(cleaned).digest('hex').slice(0, hashLen);
  return `${safePrefix}-${hash}`.slice(0, 32);
}

export async function placeNobitexLiveOrder(
  input: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    side: 'BUY' | 'SELL';
    type: 'LIMIT' | 'MARKET';
    quantity: number;
    price?: number;
    estimatedPrice?: number;
    clientOrderId?: string;
    skipBalanceCheck?: boolean;
    source?: 'MANUAL' | 'BOT';
    botId?: string;
  },
  credentials?: NobitexCredentials | null
): Promise<SpotOrder> {
  validateNobitexCredentialsFormat(credentials);

  const baseAsset = input.baseAsset.toUpperCase().trim();
  const quoteCurrency = input.quoteCurrency;
  const symbol = `${baseAsset}${quoteCurrency}`;
  const marketRules = await getNobitexMarketRules(symbol).catch(() => ({
    minNotional: getMinimumOrderNotional(quoteCurrency),
    amountStep: 1e-6,
  }));
  const cleanQty = roundQuantityToStep(Number(input.quantity), marketRules.amountStep, 'floor');
  if (!Number.isFinite(cleanQty) || cleanQty <= 0) {
    throw new Error('مقدار سفارش نامعتبر است.');
  }

  const refPrice =
    input.type === 'LIMIT' ? Number(input.price || 0) : Number(input.price || input.estimatedPrice || 0);

  if (input.type === 'LIMIT' && (!Number.isFinite(refPrice) || refPrice <= 0)) {
    throw new Error('برای سفارش لیمیت باید قیمت معتبر وارد کنید.');
  }

  if (refPrice > 0) {
    const estNotional = cleanQty * refPrice;
    if (estNotional + 1e-6 < marketRules.minNotional) {
      throw new Error(
        quoteCurrency === 'IRT'
          ? `حداقل ارزش سفارش تومانی در نوبیتکس ${Math.round(marketRules.minNotional).toLocaleString('en-US')} تومان است.`
          : `حداقل ارزش سفارش تتری ${marketRules.minNotional} USDT است.`
      );
    }
  }

  // Pre-order balance sufficiency verification (unless skipped by unit harness)
  if (!input.skipBalanceCheck) {
    const wallets = await fetchNobitexWalletsCached(credentials);

    if (Array.isArray(wallets) && wallets.length > 0) {
      const targetWalletCode =
        input.side === 'BUY'
          ? quoteCurrency === 'IRT'
            ? 'RLS'
            : 'USDT'
          : baseAsset;
      const divisor = targetWalletCode === 'RLS' ? 10 : 1;
      const wallet = wallets.find(
        (w) => w.currency.toUpperCase() === targetWalletCode
      );
      const totalBal = wallet ? Number(wallet.balance || 0) / divisor : 0;
      const blockedBal = wallet ? Number(wallet.blockedBalance || 0) / divisor : 0;
      const freeBal = Math.max(0, totalBal - blockedBal);

      if (input.side === 'SELL' && freeBal + 1e-8 < cleanQty) {
        throw new Error(
          `موجودی آزاد ${baseAsset} در حساب نوبیتکس کافی نیست (نیاز: ${cleanQty}، موجود: ${freeBal}).`
        );
      }
      if (input.side === 'BUY' && refPrice > 0 && freeBal + 1e-6 < cleanQty * refPrice) {
        throw new Error(
          `موجودی آزاد ${quoteCurrency === 'IRT' ? 'تومان' : 'تتر'} در نوبیتکس کافی نیست.`
        );
      }
    }
  }

  const dstCurrency = quoteCurrency === 'IRT' ? 'rls' : 'usdt';
  const multiplier = quoteCurrency === 'IRT' ? 10 : 1;

  const body: Record<string, unknown> = {
    type: input.side === 'BUY' ? 'buy' : 'sell',
    srcCurrency: baseAsset.toLowerCase(),
    dstCurrency,
    execution: input.type === 'MARKET' ? 'market' : 'limit',
    amount: String(cleanQty),
  };

  const formattedClientOrderId = formatNobitexClientOrderId(input.clientOrderId);
  if (formattedClientOrderId) {
    body.clientOrderId = formattedClientOrderId;
  }

  if (input.type === 'LIMIT') {
    body.price = String(Math.round(refPrice * multiplier * 100) / 100);
  }

  const submitStartedAt = Date.now();
  let data: {
    order?: RawNobitexOrderPayload;
  };

  try {
    // CRITICAL: Never automatically retry order submission on 5xx/timeout without checking status first!
    invalidateNobitexAccountCaches(credentials);
    data = await nobitexAuthRequest('/market/orders/add', body, credentials, {
      retryOn5xx: false,
      retryOn429: false,
      maxRetries: 0,
      minSpacingMs: 500,
    });
    invalidateNobitexAccountCaches(credentials);
  } catch (err) {
    // Reconcile recent orders ONLY on ambiguous network/5xx/timeout errors (never on auth, rate-limit, or 4xx rejections)
    const msg = err instanceof Error ? err.message : '';
    const isClientRejection =
      err instanceof NobitexAuthError ||
      err instanceof NobitexRateLimitError ||
      isRateLimitText(msg) ||
      msg.includes('موجودی') ||
      msg.includes('حداقل') ||
      msg.includes('نامعتبر') ||
      msg.includes('BadRequest');
    if (!isClientRejection) {
      try {
        const recentRes = await nobitexAuthRequest<{
          orders?: RawNobitexOrderPayload[];
        }>('/market/orders/list', { status: 'all' }, credentials, { maxRetries: 0, retryOn429: false });

        const matched = (recentRes.orders || []).find((o) => {
          const ts = o.created_at ? Date.parse(o.created_at) : 0;
          const mktBase =
            o.market && o.market.includes('-') ? o.market.split('-')[0].trim().toUpperCase() : '';
          const orderBase = mktBase || (o.srcCurrency || '').trim().toUpperCase();
          return (
            orderBase === baseAsset &&
            (o.type || '').toLowerCase() === (input.side === 'BUY' ? 'buy' : 'sell') &&
            Math.abs(toPositiveFinite(o.amount) - cleanQty) < Math.max(1e-6, cleanQty * 0.01) &&
            (ts === 0 || ts >= submitStartedAt - 15_000)
          );
        });
        if (matched) {
          const reconciled = mapRawNobitexOrder(matched, quoteCurrency);
          reconciled.source = input.source || 'MANUAL';
          reconciled.botId = input.botId;
          logger.info('nobitex.order_reconciled_after_timeout', {
            orderId: reconciled.orderId,
            symbol: reconciled.symbol,
          });
          return reconciled;
        }
      } catch {
        // Ignore reconciliation lookup failure and surface original error
      }
    }
    throw err;
  }

  const ord = data.order;
  const qty = toPositiveFinite(ord?.amount) || cleanQty;
  const matchedQty = toPositiveFinite(ord?.matchedAmount);
  const rawStatus = (ord?.status || '').toLowerCase();
  const resolvedStatus: SpotOrder['status'] =
    rawStatus === 'done'
      ? 'FILLED'
      : rawStatus === 'canceled'
        ? 'CANCELED'
        : input.type === 'MARKET' && rawStatus !== 'active' && rawStatus !== 'new'
          ? 'FILLED'
          : matchedQty > 0 && matchedQty < qty
            ? 'PARTIALLY_FILLED'
            : 'NEW';

  const executedQty = resolvedStatus === 'FILLED' && matchedQty <= 0 ? qty : matchedQty;
  const effectiveQty = executedQty > 0 ? executedQty : qty;
  const avgRaw = toPositiveFinite(ord?.averagePrice);
  const limitRaw = toPositiveFinite(ord?.price);
  const totalRaw = toPositiveFinite(ord?.totalPrice);

  const execPrice =
    avgRaw > 0
      ? avgRaw / multiplier
      : totalRaw > 0 && effectiveQty > 0
        ? totalRaw / multiplier / effectiveQty
        : limitRaw > 0
          ? limitRaw / multiplier
          : refPrice || 0;

  const totalQuoteAmount =
    totalRaw > 0
      ? totalRaw / multiplier
      : execPrice > 0 && effectiveQty > 0
        ? execPrice * effectiveQty
        : 0;

  return {
    orderId: String(ord?.id || `nbt-${Date.now()}`),
    symbol: `${baseAsset}${quoteCurrency}`,
    baseAsset,
    quoteCurrency,
    side: input.side,
    type: input.type,
    price: execPrice,
    quantity: qty,
    executedQty,
    totalQuoteAmount,
    status: resolvedStatus,
    mode: 'live',
    source: input.source || 'MANUAL',
    botId: input.botId,
    createdAt: Date.now(),
  };
}

export async function cancelNobitexLiveOrder(
  orderId: string,
  credentials?: NobitexCredentials | null
): Promise<void> {
  invalidateNobitexAccountCaches(credentials);
  await nobitexAuthRequest(
    '/market/orders/update-status',
    { order: orderId, status: 'canceled' },
    credentials
  );
  invalidateNobitexAccountCaches(credentials);
}
