import crypto from 'node:crypto';
import { and, desc, eq } from 'drizzle-orm';
import * as schema from '../src/db/schema.ts';
import type {
  BotExecutionConfirmationMode,
  BotFundingMode,
  ExecutionMode,
  OrderBookSnapshot,
  ProfitBotConfig,
  ProfitBotCycleRecord,
  ProfitBotDailyStats,
  ProfitBotDecisionLog,
  ProfitBotLimitUnfilledPolicy,
  ProfitBotOrderType,
  ProfitBotPendingOrder,
  ProfitBotPosition,
  ProfitBotReentryPolicy,
  ProfitBotSequenceMode,
  ProfitBotStats,
  ProfitBotStatus,
  ProfitBotStopLossAction,
  QuoteCurrency,
  SpotBalance,
  SpotOrder,
} from '../src/types/trading.ts';
import {
  DEFAULT_NOBITEX_FEE_RATE,
  computeExistingBalanceAllocation,
  computeProfitProgressPercent,
  computeRequiredSellPrice,
  getMinimumOrderNotional,
  resolveOrderQuantityForNotional,
  roundQuantityToStep,
  roundQuoteValue,
  simulateOrderBookBuy,
  simulateOrderBookSell,
} from '../src/utils/profitBotMath.ts';
import {
  acquireWorkerLock,
  ensureUserRecord,
  getDb,
  releaseWorkerLock,
  withTransaction,
} from './db/index.ts';
import {
  getPaperBalances,
  matchPaperLimitOrders,
  placePaperOrder,
  recordLiveOrderAndTrade,
} from './botEngine.ts';
import { logger } from './logger.ts';
import {
  NobitexAuthError,
  cancelNobitexLiveOrder,
  fetchNobitexLiveBalances,
  fetchNobitexOrderBook,
  fetchNobitexOrderStatus,
  fetchNobitexUnifiedMarkets,
  formatNobitexClientOrderId,
  getNobitexMarketRules,
  placeNobitexLiveOrder,
} from './nobitexClient.ts';
import {
  getActiveExchangeCredentialsForUser,
  hasActiveExchangeCredentialsForUser,
} from './securityVault.ts';
import { sendTelegramMessageForUser } from './telegramClient.ts';

const PROFIT_BOT_LOCK_NAME = 'ali_trader_profit_bot_lock';
const PROFIT_BOT_WORKER_ID = `pbot-worker-${process.pid}-${crypto.randomBytes(3).toString('hex')}`;
let isEvaluatingProfitBotsLocally = false;

export interface ProfitBotRuntimeDeps {
  fetchOrderBook: (symbol: string, limit?: number) => Promise<OrderBookSnapshot>;
  getBalances: (userId: string, mode: ExecutionMode) => Promise<SpotBalance[]>;
  placeOrder: (
    userId: string,
    bot: ProfitBotConfig,
    input: {
      side: 'BUY' | 'SELL';
      type: ProfitBotOrderType;
      quantity: number;
      price: number;
      idempotencyKey: string;
      realizedPnlQuote?: number;
    }
  ) => Promise<SpotOrder>;
  getOrderStatus: (
    userId: string,
    orderId: string,
    exchangeOrderId: string | undefined,
    mode: ExecutionMode,
    symbol: string,
    referencePrice: number
  ) => Promise<SpotOrder | null>;
  cancelOrder: (
    userId: string,
    orderId: string,
    exchangeOrderId: string | undefined,
    mode: ExecutionMode
  ) => Promise<void>;
  now: () => number;
}

function getTodayDateKey(ts = Date.now()): string {
  const d = new Date(ts);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, '0');
  const day = String(d.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function formatQuoteShort(amount: number, quoteCurrency: QuoteCurrency): string {
  const abs = Math.abs(amount);
  if (quoteCurrency === 'IRT') {
    const maxDec = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
    return `${amount.toLocaleString('en-US', { maximumFractionDigits: maxDec })} تومان`;
  }
  const maxDec = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
  return `${amount.toLocaleString('en-US', { minimumFractionDigits: abs >= 1 ? 2 : 0, maximumFractionDigits: maxDec })} USDT`;
}

function defaultDailyStats(now = Date.now()): ProfitBotDailyStats {
  return {
    dateKey: getTodayDateKey(now),
    tradesCount: 0,
    lossQuote: 0,
    netProfitQuote: 0,
  };
}

function defaultStats(): ProfitBotStats {
  return {
    completedCycles: 0,
    winningCycles: 0,
    losingCycles: 0,
    totalNetProfitQuote: 0,
    totalFeesPaidQuote: 0,
    currentCapitalInvolved: 0,
    lastBuyPrice: null,
  };
}

interface PersistedProfitBotStatsJson extends ProfitBotStats {
  __reentryTargetPrice?: number | null;
  __reentryPolicy?: ProfitBotReentryPolicy;
  __waitEntryPriceOnFirstBuy?: boolean;
  __targetSellPrice?: number | null;
  __fundingMode?: BotFundingMode;
  __existingBalancePercent?: number;
  __existingEntryPrice?: number | null;
  __executionConfirmationMode?: BotExecutionConfirmationMode;
}

function normalizeFundingMode(mode?: unknown): BotFundingMode {
  if (mode === 'EXISTING_ASSET' || mode === 'AUTO_PREFER_EXISTING') return mode;
  return 'QUOTE_BUY';
}

function clampBalancePercent(pct?: unknown): number {
  const num = Number(pct);
  if (!Number.isFinite(num) || num <= 0) return 50;
  return Math.min(100, Math.max(1, num));
}

function buildPersistedStatsJson(
  bot: Pick<
    ProfitBotConfig,
    | 'stats'
    | 'reentryTargetPrice'
    | 'reentryPolicy'
    | 'waitEntryPriceOnFirstBuy'
    | 'targetSellPrice'
    | 'fundingMode'
    | 'existingBalancePercent'
    | 'existingEntryPrice'
    | 'executionConfirmationMode'
  >
): PersistedProfitBotStatsJson {
  return {
    ...bot.stats,
    lastBuyPrice: bot.stats.lastBuyPrice ?? null,
    __reentryTargetPrice:
      bot.reentryTargetPrice && bot.reentryTargetPrice > 0 ? bot.reentryTargetPrice : null,
    __reentryPolicy: bot.reentryPolicy === 'IMMEDIATE' ? 'IMMEDIATE' : 'WAIT_ENTRY_PRICE',
    __waitEntryPriceOnFirstBuy: Boolean(bot.waitEntryPriceOnFirstBuy),
    __targetSellPrice: bot.targetSellPrice && bot.targetSellPrice > 0 ? bot.targetSellPrice : null,
    __fundingMode: normalizeFundingMode(bot.fundingMode),
    __existingBalancePercent: clampBalancePercent(bot.existingBalancePercent),
    __existingEntryPrice:
      bot.existingEntryPrice && bot.existingEntryPrice > 0 ? bot.existingEntryPrice : null,
    __executionConfirmationMode:
      bot.executionConfirmationMode === 'MANUAL_CONFIRM' ? 'MANUAL_CONFIRM' : 'AUTO',
  };
}

function normalizeDailyStats(
  raw: unknown,
  now = Date.now()
): ProfitBotDailyStats {
  const today = getTodayDateKey(now);
  const obj = (raw || {}) as Partial<ProfitBotDailyStats>;
  if (obj.dateKey !== today) {
    return defaultDailyStats(now);
  }
  return {
    dateKey: today,
    tradesCount: Math.max(0, Number(obj.tradesCount || 0)),
    lossQuote: Math.max(0, Number(obj.lossQuote || 0)),
    netProfitQuote: Number(obj.netProfitQuote || 0),
  };
}

function mapProfitBotRow(row: typeof schema.profitBots.$inferSelect): ProfitBotConfig {
  const rawStats = (row.statsJson || {}) as Partial<PersistedProfitBotStatsJson>;
  return {
    id: row.id,
    ownerId: row.userId,
    name: row.name,
    baseAsset: row.baseAsset,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    symbol: row.symbol,
    mode: (row.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    isActive: Boolean(row.isActive),
    botStatus: (row.botStatus || 'READY_TO_BUY') as ProfitBotStatus,
    entryAmount: row.entryAmount,
    targetNetProfit: row.targetNetProfit,
    pollIntervalSeconds: row.pollIntervalSeconds,
    maxWaitMinutes: row.maxWaitMinutes ?? null,
    stopLossEnabled: Boolean(row.stopLossEnabled),
    stopLossPercent: row.stopLossPercent,
    stopLossAction: (row.stopLossAction === 'STOP_ONLY'
      ? 'STOP_ONLY'
      : 'STOP_AND_SELL') as ProfitBotStopLossAction,
    maxCapitalInvolved: row.maxCapitalInvolved,
    maxDailyTrades: row.maxDailyTrades,
    maxDailyLoss: row.maxDailyLoss,
    orderType: (row.orderType === 'MARKET' ? 'MARKET' : 'LIMIT') as ProfitBotOrderType,
    maxSlippagePercent: row.maxSlippagePercent,
    maxSpreadPercent: row.maxSpreadPercent,
    limitOrderTimeoutSeconds: row.limitOrderTimeoutSeconds,
    limitUnfilledPolicy: (row.limitUnfilledPolicy === 'CANCEL_AND_REPRICE' ||
    row.limitUnfilledPolicy === 'STOP_BOT'
      ? row.limitUnfilledPolicy
      : 'KEEP_WAITING') as ProfitBotLimitUnfilledPolicy,
    sequenceMode: (row.sequenceMode === 'PREPARE_NEXT' || row.sequenceMode === 'CYCLE_REPEAT'
      ? row.sequenceMode
      : 'SINGLE') as ProfitBotSequenceMode,
    reentryTargetPrice:
      rawStats.__reentryTargetPrice && Number(rawStats.__reentryTargetPrice) > 0
        ? Number(rawStats.__reentryTargetPrice)
        : null,
    reentryPolicy:
      rawStats.__reentryPolicy === 'IMMEDIATE' ? 'IMMEDIATE' : 'WAIT_ENTRY_PRICE',
    waitEntryPriceOnFirstBuy: Boolean(rawStats.__waitEntryPriceOnFirstBuy),
    targetSellPrice:
      rawStats.__targetSellPrice && Number(rawStats.__targetSellPrice) > 0
        ? Number(rawStats.__targetSellPrice)
        : null,
    fundingMode: normalizeFundingMode(rawStats.__fundingMode),
    existingBalancePercent: clampBalancePercent(rawStats.__existingBalancePercent),
    existingEntryPrice:
      rawStats.__existingEntryPrice && Number(rawStats.__existingEntryPrice) > 0
        ? Number(rawStats.__existingEntryPrice)
        : null,
    executionConfirmationMode:
      rawStats.__executionConfirmationMode === 'MANUAL_CONFIRM' ? 'MANUAL_CONFIRM' : 'AUTO',
    feeRate: row.feeRate ?? DEFAULT_NOBITEX_FEE_RATE,
    otherFeesQuote: row.otherFeesQuote ?? 0,
    notifyTelegram: row.notifyTelegram !== false,
    activePosition: (row.activePositionJson as ProfitBotPosition | null) ?? null,
    pendingOrder: (row.pendingOrderJson as ProfitBotPendingOrder | null) ?? null,
    dailyStats: normalizeDailyStats(row.dailyStatsJson),
    stats: {
      completedCycles: Number(rawStats.completedCycles || 0),
      winningCycles: Number(rawStats.winningCycles || 0),
      losingCycles: Number(rawStats.losingCycles || 0),
      totalNetProfitQuote: Number(rawStats.totalNetProfitQuote || 0),
      totalFeesPaidQuote: Number(rawStats.totalFeesPaidQuote || 0),
      currentCapitalInvolved: Number(rawStats.currentCapitalInvolved || 0),
      lastBuyPrice:
        rawStats.lastBuyPrice && Number(rawStats.lastBuyPrice) > 0
          ? Number(rawStats.lastBuyPrice)
          : null,
    },
    lastStatusReason: row.lastStatusReason || '',
    lastError: row.lastError ?? null,
    lastCheckedAt: row.lastCheckedAt ?? null,
    startedAt: row.startedAt ?? null,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

function mapCycleRow(row: typeof schema.profitBotCycles.$inferSelect): ProfitBotCycleRecord {
  return {
    id: row.id,
    botId: row.botId,
    cycleIndex: row.cycleIndex,
    symbol: row.symbol,
    baseAsset: row.baseAsset,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    mode: (row.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    orderType: (row.orderType === 'MARKET' ? 'MARKET' : 'LIMIT') as ProfitBotOrderType,
    entryAmountQuote: row.entryAmountQuote,
    actualBuyAvgPrice: row.actualBuyAvgPrice,
    boughtQty: row.boughtQty,
    buyFeeQuote: row.buyFeeQuote,
    totalBuyCostQuote: row.totalBuyCostQuote,
    actualSellAvgPrice: row.actualSellAvgPrice,
    soldQty: row.soldQty,
    grossSellProceedsQuote: row.grossSellProceedsQuote,
    sellFeeQuote: row.sellFeeQuote,
    otherFeesQuote: row.otherFeesQuote,
    finalNetProfitQuote: row.finalNetProfitQuote,
    targetNetProfitQuote: row.targetNetProfitQuote,
    exitReason: row.exitReason as ProfitBotCycleRecord['exitReason'],
    startedAt: row.startedAt,
    completedAt: row.completedAt,
  };
}

function mapDecisionLogRow(row: typeof schema.profitBotLogs.$inferSelect): ProfitBotDecisionLog {
  return {
    id: row.id,
    botId: row.botId,
    cycleIndex: row.cycleIndex,
    status: row.status as ProfitBotStatus,
    event: row.event as ProfitBotDecisionLog['event'],
    price: row.price,
    netProfitQuote: row.netProfitQuote ?? null,
    message: row.message,
    timestamp: row.timestamp,
  };
}

async function appendProfitBotLog(
  userId: string,
  entry: Omit<ProfitBotDecisionLog, 'id' | 'timestamp'> & { timestamp?: number }
): Promise<void> {
  const db = getDb();
  const id = `plog-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  await db.insert(schema.profitBotLogs).values({
    id,
    botId: entry.botId,
    userId,
    cycleIndex: entry.cycleIndex,
    status: entry.status,
    event: entry.event,
    price: entry.price,
    netProfitQuote: entry.netProfitQuote ?? null,
    message: entry.message.slice(0, 600),
    timestamp: entry.timestamp ?? Date.now(),
  });
}

async function notifyProfitBotTelegram(
  userId: string,
  bot: ProfitBotConfig,
  title: string,
  summary: string
): Promise<void> {
  if (!bot.notifyTelegram) return;
  try {
    const html = [
      `💰 <b>${title}</b>`,
      `• ربات: <b>${bot.name}</b> (${bot.symbol})`,
      `• حالت: ${bot.mode === 'live' ? 'حساب واقعی' : 'حساب تمرینی'}`,
      `• ${summary}`,
    ].join('\n');
    await sendTelegramMessageForUser(userId, html, {
      kind: 'BOT_EVENT',
      title: `${title} · ${bot.name}`,
      preview: summary,
    });
  } catch {
    // Non-blocking telegram delivery
  }
}

async function persistProfitBotState(
  bot: ProfitBotConfig,
  extra?: { consecutiveFailures?: number; nextRetryAt?: number | null }
): Promise<void> {
  const db = getDb();
  const now = Date.now();
  await db
    .update(schema.profitBots)
    .set({
      isActive: bot.isActive,
      botStatus: bot.botStatus,
      activePositionJson: bot.activePosition,
      pendingOrderJson: bot.pendingOrder,
      dailyStatsJson: bot.dailyStats,
      statsJson: buildPersistedStatsJson(bot),
      lastStatusReason: bot.lastStatusReason.slice(0, 600),
      lastError: bot.lastError ? bot.lastError.slice(0, 400) : null,
      lastCheckedAt: bot.lastCheckedAt,
      startedAt: bot.startedAt,
      updatedAt: now,
      ...(extra?.consecutiveFailures !== undefined
        ? { consecutiveFailures: extra.consecutiveFailures }
        : {}),
      ...(extra?.nextRetryAt !== undefined ? { nextRetryAt: extra.nextRetryAt } : {}),
    })
    .where(eq(schema.profitBots.id, bot.id));
  bot.updatedAt = now;
}

function createDefaultRuntimeDeps(): ProfitBotRuntimeDeps {
  return {
    fetchOrderBook: (symbol, limit = 40) => fetchNobitexOrderBook(symbol, limit),
    getBalances: async (userId, mode) => {
      const { markets, usdtTomanRate } = await fetchNobitexUnifiedMarkets();
      if (mode === 'live') {
        const creds = await getActiveExchangeCredentialsForUser(userId);
        if (!creds) {
          throw new NobitexAuthError('کلید API نوبیتکس برای این حساب یافت نشد.');
        }
        return fetchNobitexLiveBalances(markets, usdtTomanRate, creds);
      }
      return getPaperBalances(userId, markets, usdtTomanRate);
    },
    placeOrder: async (userId, bot, input) => {
      if (bot.mode === 'live') {
        const creds = await getActiveExchangeCredentialsForUser(userId);
        if (!creds) {
          throw new NobitexAuthError('کلید API نوبیتکس برای ثبت سفارش واقعی یافت نشد.');
        }
        const ord = await placeNobitexLiveOrder(
          {
            baseAsset: bot.baseAsset,
            quoteCurrency: bot.quoteCurrency,
            side: input.side,
            type: input.type,
            quantity: input.quantity,
            price: input.type === 'LIMIT' ? input.price : undefined,
            estimatedPrice: input.price,
            clientOrderId: formatNobitexClientOrderId(input.idempotencyKey),
            source: 'BOT',
            botId: bot.id,
          },
          creds
        );
        await recordLiveOrderAndTrade(userId, ord, {
          idempotencyKey: input.idempotencyKey,
          realizedPnlQuote: input.realizedPnlQuote,
        });
        return ord;
      }

      const paperOrd = await placePaperOrder(userId, {
        baseAsset: bot.baseAsset,
        quoteCurrency: bot.quoteCurrency,
        side: input.side,
        type: input.type,
        quantity: input.quantity,
        price: input.price,
        source: 'BOT',
        botId: bot.id,
        idempotencyKey: input.idempotencyKey,
        realizedPnlQuote: input.realizedPnlQuote,
      });
      if (input.type === 'LIMIT' && input.price > 0) {
        await matchPaperLimitOrders(bot.symbol, input.price, userId);
        const db = getDb();
        const rows = await db
          .select()
          .from(schema.orders)
          .where(and(eq(schema.orders.orderId, paperOrd.orderId), eq(schema.orders.userId, userId)))
          .limit(1);
        if (rows[0]) {
          return {
            ...paperOrd,
            status: rows[0].status as SpotOrder['status'],
            executedQty: rows[0].executedQty,
          };
        }
      }
      return paperOrd;
    },
    getOrderStatus: async (userId, orderId, exchangeOrderId, mode, symbol, referencePrice) => {
      if (mode === 'live') {
        const creds = await getActiveExchangeCredentialsForUser(userId);
        if (!creds) {
          throw new NobitexAuthError('کلید API نوبیتکس برای استعلام سفارش یافت نشد.');
        }
        const expectedQuote: QuoteCurrency = symbol.toUpperCase().endsWith('USDT') ? 'USDT' : 'IRT';
        return fetchNobitexOrderStatus(exchangeOrderId || orderId, creds, expectedQuote);
      }
      if (referencePrice > 0) {
        await matchPaperLimitOrders(symbol, referencePrice, userId);
      }
      const db = getDb();
      const rows = await db
        .select()
        .from(schema.orders)
        .where(and(eq(schema.orders.orderId, orderId), eq(schema.orders.userId, userId)))
        .limit(1);
      const r = rows[0];
      if (!r) return null;
      return {
        orderId: r.orderId,
        symbol: r.symbol,
        baseAsset: r.baseAsset,
        quoteCurrency: (r.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
        side: r.side as 'BUY' | 'SELL',
        type: r.type as 'LIMIT' | 'MARKET',
        price: r.price,
        quantity: r.quantity,
        executedQty: r.executedQty,
        totalQuoteAmount: r.totalQuoteAmount,
        status: r.status as SpotOrder['status'],
        mode: 'paper',
        source: 'BOT',
        botId: r.botId ?? undefined,
        createdAt: r.createdAt,
      };
    },
    cancelOrder: async (userId, orderId, exchangeOrderId, mode) => {
      if (mode === 'live') {
        const creds = await getActiveExchangeCredentialsForUser(userId);
        if (!creds) {
          throw new NobitexAuthError('کلید API نوبیتکس برای لغو سفارش یافت نشد.');
        }
        await cancelNobitexLiveOrder(exchangeOrderId || orderId, creds);
        return;
      }
      const db = getDb();
      const rows = await db
        .select()
        .from(schema.orders)
        .where(and(eq(schema.orders.orderId, orderId), eq(schema.orders.userId, userId)))
        .limit(1);
      const ord = rows[0];
      if (!ord || ord.status !== 'NEW') return;
      await withTransaction(async (tx) => {
        const updated = await tx
          .update(schema.orders)
          .set({ status: 'CANCELED', updatedAt: Date.now() })
          .where(and(eq(schema.orders.orderId, orderId), eq(schema.orders.status, 'NEW')))
          .returning();
        if (updated.length === 0) return;
        const refundAsset = ord.side === 'BUY' ? ord.quoteCurrency : ord.baseAsset;
        const refundAmount = ord.side === 'BUY' ? ord.price * ord.quantity : ord.quantity;
        const balRows = await tx
          .select()
          .from(schema.paperTradingBalances)
          .where(
            and(
              eq(schema.paperTradingBalances.userId, userId),
              eq(schema.paperTradingBalances.asset, refundAsset)
            )
          )
          .limit(1);
        if (balRows[0]) {
          await tx
            .update(schema.paperTradingBalances)
            .set({
              balance: balRows[0].balance + refundAmount,
              updatedAt: Date.now(),
            })
            .where(eq(schema.paperTradingBalances.id, balRows[0].id));
        }
      });
    },
    now: () => Date.now(),
  };
}

// ===========================================================================
// Public CRUD & Management Operations (Strictly Per-User Multi-Tenant)
// ===========================================================================
export async function getUserProfitBots(userId: string): Promise<ProfitBotConfig[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.profitBots)
    .where(eq(schema.profitBots.userId, userId))
    .orderBy(desc(schema.profitBots.createdAt));
  return rows.map(mapProfitBotRow);
}

export async function getUserProfitBotById(
  userId: string,
  botId: string
): Promise<ProfitBotConfig | null> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.profitBots)
    .where(and(eq(schema.profitBots.id, botId), eq(schema.profitBots.userId, userId)))
    .limit(1);
  return rows[0] ? mapProfitBotRow(rows[0]) : null;
}

export async function getUserProfitBotCycles(
  userId: string,
  botId?: string,
  limit = 100
): Promise<ProfitBotCycleRecord[]> {
  const db = getDb();
  const conditions = [eq(schema.profitBotCycles.userId, userId)];
  if (botId) conditions.push(eq(schema.profitBotCycles.botId, botId));
  const rows = await db
    .select()
    .from(schema.profitBotCycles)
    .where(and(...conditions))
    .orderBy(desc(schema.profitBotCycles.completedAt))
    .limit(limit);
  return rows.map(mapCycleRow);
}

export async function getUserProfitBotLogs(
  userId: string,
  botId?: string,
  limit = 150
): Promise<ProfitBotDecisionLog[]> {
  const db = getDb();
  const conditions = [eq(schema.profitBotLogs.userId, userId)];
  if (botId) conditions.push(eq(schema.profitBotLogs.botId, botId));
  const rows = await db
    .select()
    .from(schema.profitBotLogs)
    .where(and(...conditions))
    .orderBy(desc(schema.profitBotLogs.timestamp))
    .limit(limit);
  return rows.map(mapDecisionLogRow);
}

export interface CreateProfitBotInput {
  name?: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  mode?: ExecutionMode;
  startImmediately?: boolean;
  entryAmount: number;
  targetNetProfit: number;
  pollIntervalSeconds?: number;
  maxWaitMinutes?: number | null;
  stopLossEnabled?: boolean;
  stopLossPercent?: number;
  stopLossAction?: ProfitBotStopLossAction;
  maxCapitalInvolved?: number;
  maxDailyTrades?: number;
  maxDailyLoss?: number;
  orderType?: ProfitBotOrderType;
  maxSlippagePercent?: number;
  maxSpreadPercent?: number;
  limitOrderTimeoutSeconds?: number;
  limitUnfilledPolicy?: ProfitBotLimitUnfilledPolicy;
  sequenceMode?: ProfitBotSequenceMode;
  reentryTargetPrice?: number | null;
  reentryPolicy?: ProfitBotReentryPolicy;
  waitEntryPriceOnFirstBuy?: boolean;
  targetSellPrice?: number | null;
  fundingMode?: BotFundingMode;
  existingBalancePercent?: number;
  existingEntryPrice?: number | null;
  executionConfirmationMode?: BotExecutionConfirmationMode;
  feeRate?: number;
  otherFeesQuote?: number;
  notifyTelegram?: boolean;
}

export async function createProfitBot(
  userId: string,
  input: CreateProfitBotInput
): Promise<ProfitBotConfig> {
  await ensureUserRecord({ uid: userId });

  const baseAsset = input.baseAsset.toUpperCase().trim();
  const quoteCurrency: QuoteCurrency = input.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
  const symbol = `${baseAsset}${quoteCurrency}`;
  const mode: ExecutionMode = input.mode === 'live' ? 'live' : 'paper';
  const fundingMode = normalizeFundingMode(input.fundingMode);
  const existingBalancePercent = clampBalancePercent(input.existingBalancePercent);
  const existingEntryPrice =
    input.existingEntryPrice && Number(input.existingEntryPrice) > 0
      ? Number(input.existingEntryPrice)
      : null;

  if (!baseAsset) {
    throw new Error('انتخاب ارز دیجیتال الزامی است.');
  }
  if (mode === 'live' && !(await hasActiveExchangeCredentialsForUser(userId))) {
    throw new Error(
      'برای اجرای ربات سود روی حساب واقعی، ابتدا کلید API نوبیتکس خود را در بخش «تنظیمات حساب» متصل کنید.'
    );
  }

  const minNotional = getMinimumOrderNotional(quoteCurrency);
  const rawEntryAmount = Number(input.entryAmount ?? 0);
  const entryAmount = Number.isFinite(rawEntryAmount) && rawEntryAmount >= 0 ? rawEntryAmount : 0;
  if (fundingMode !== 'EXISTING_ASSET' && (!Number.isFinite(rawEntryAmount) || entryAmount + 1e-6 < minNotional)) {
    throw new Error(
      `حداقل مبلغ ورود در بازار ${quoteCurrency === 'IRT' ? 'تومانی ۵۰,۰۰۰ تومان' : 'تتری ۰.۵ USDT'} است.`
    );
  }

  const targetNetProfit = Number(input.targetNetProfit);
  if (!Number.isFinite(targetNetProfit) || targetNetProfit <= 0) {
    throw new Error('مبلغ سود خالص هدف باید بزرگ‌تر از صفر باشد.');
  }

  const maxCapitalInvolved = Math.max(
    entryAmount,
    Number(input.maxCapitalInvolved || entryAmount || (quoteCurrency === 'IRT' ? 20_000_000 : 200))
  );
  const pollIntervalSeconds = Math.min(
    300,
    Math.max(2, Math.round(Number(input.pollIntervalSeconds || 10)))
  );
  const maxWaitMinutes =
    input.maxWaitMinutes && Number(input.maxWaitMinutes) > 0
      ? Math.min(43_200, Math.round(Number(input.maxWaitMinutes)))
      : null;

  const feeRate = Math.min(
    0.05,
    Math.max(0, Number(input.feeRate ?? DEFAULT_NOBITEX_FEE_RATE))
  );
  const reentryTargetPrice =
    input.reentryTargetPrice && Number(input.reentryTargetPrice) > 0
      ? Number(input.reentryTargetPrice)
      : null;
  const reentryPolicy: ProfitBotReentryPolicy =
    input.reentryPolicy === 'IMMEDIATE' ? 'IMMEDIATE' : 'WAIT_ENTRY_PRICE';
  const waitEntryPriceOnFirstBuy = Boolean(input.waitEntryPriceOnFirstBuy);
  const targetSellPrice =
    input.targetSellPrice && Number(input.targetSellPrice) > 0
      ? Number(input.targetSellPrice)
      : null;
  const now = Date.now();
  const id = `pbot-${now}-${crypto.randomBytes(3).toString('hex')}`;
  const isActive = Boolean(input.startImmediately);
  const botStatus: ProfitBotStatus = isActive ? 'CHECKING_MARKET' : 'READY_TO_BUY';
  const name =
    (input.name || '').trim() ||
    `ربات سود ${baseAsset}/${quoteCurrency === 'IRT' ? 'تومان' : 'تتر'}`;

  const config: ProfitBotConfig = {
    id,
    ownerId: userId,
    name,
    baseAsset,
    quoteCurrency,
    symbol,
    mode,
    isActive,
    botStatus,
    entryAmount,
    targetNetProfit,
    pollIntervalSeconds,
    maxWaitMinutes,
    stopLossEnabled: Boolean(input.stopLossEnabled),
    stopLossPercent: Math.min(90, Math.max(0.2, Number(input.stopLossPercent || 3))),
    stopLossAction: input.stopLossAction === 'STOP_ONLY' ? 'STOP_ONLY' : 'STOP_AND_SELL',
    maxCapitalInvolved,
    maxDailyTrades: Math.min(500, Math.max(1, Math.round(Number(input.maxDailyTrades || 10)))),
    maxDailyLoss: Math.max(0, Number(input.maxDailyLoss || 0)),
    orderType: input.orderType === 'LIMIT' ? 'LIMIT' : 'MARKET',
    maxSlippagePercent: Math.min(20, Math.max(0.05, Number(input.maxSlippagePercent || 0.5))),
    maxSpreadPercent: Math.min(20, Math.max(0.05, Number(input.maxSpreadPercent || 2.5))),
    limitOrderTimeoutSeconds: Math.min(
      86_400,
      Math.max(10, Math.round(Number(input.limitOrderTimeoutSeconds || 120)))
    ),
    limitUnfilledPolicy:
      input.limitUnfilledPolicy === 'CANCEL_AND_REPRICE' ||
      input.limitUnfilledPolicy === 'STOP_BOT'
        ? input.limitUnfilledPolicy
        : 'KEEP_WAITING',
    sequenceMode:
      input.sequenceMode === 'SINGLE' || input.sequenceMode === 'PREPARE_NEXT'
        ? input.sequenceMode
        : 'CYCLE_REPEAT',
    reentryTargetPrice,
    reentryPolicy,
    waitEntryPriceOnFirstBuy,
    targetSellPrice,
    fundingMode,
    existingBalancePercent,
    existingEntryPrice,
    executionConfirmationMode:
      input.executionConfirmationMode === 'MANUAL_CONFIRM' ? 'MANUAL_CONFIRM' : 'AUTO',
    feeRate,
    otherFeesQuote: Math.max(0, Number(input.otherFeesQuote || 0)),
    notifyTelegram: input.notifyTelegram !== false,
    activePosition: null,
    pendingOrder: null,
    dailyStats: defaultDailyStats(now),
    stats: defaultStats(),
    lastStatusReason: isActive
      ? fundingMode === 'EXISTING_ASSET'
        ? `ربات سود فعال شد و از ${existingBalancePercent}٪ موجودی فعلی ${baseAsset} برای کسب سود استفاده می‌کند.`
        : 'ربات سود فعال شد و آماده خرید و بررسی بازار نوبیتکس است.'
      : 'ربات سود ذخیره شد و آماده شروع است.',
    lastError: null,
    lastCheckedAt: null,
    startedAt: isActive ? now : null,
    createdAt: now,
    updatedAt: now,
  };

  const db = getDb();
  await db.insert(schema.profitBots).values({
    id: config.id,
    userId,
    name: config.name,
    baseAsset: config.baseAsset,
    quoteCurrency: config.quoteCurrency,
    symbol: config.symbol,
    mode: config.mode,
    isActive: config.isActive,
    botStatus: config.botStatus,
    entryAmount: config.entryAmount,
    targetNetProfit: config.targetNetProfit,
    pollIntervalSeconds: config.pollIntervalSeconds,
    maxWaitMinutes: config.maxWaitMinutes,
    stopLossEnabled: config.stopLossEnabled,
    stopLossPercent: config.stopLossPercent,
    stopLossAction: config.stopLossAction,
    maxCapitalInvolved: config.maxCapitalInvolved,
    maxDailyTrades: config.maxDailyTrades,
    maxDailyLoss: config.maxDailyLoss,
    orderType: config.orderType,
    maxSlippagePercent: config.maxSlippagePercent,
    maxSpreadPercent: config.maxSpreadPercent,
    limitOrderTimeoutSeconds: config.limitOrderTimeoutSeconds,
    limitUnfilledPolicy: config.limitUnfilledPolicy,
    sequenceMode: config.sequenceMode,
    feeRate: config.feeRate,
    otherFeesQuote: config.otherFeesQuote,
    notifyTelegram: config.notifyTelegram,
    activePositionJson: null,
    pendingOrderJson: null,
    dailyStatsJson: config.dailyStats,
    statsJson: buildPersistedStatsJson(config),
    lastStatusReason: config.lastStatusReason,
    consecutiveFailures: 0,
    nextRetryAt: null,
    lastError: null,
    lastCheckedAt: null,
    startedAt: config.startedAt,
    createdAt: now,
    updatedAt: now,
  });

  await appendProfitBotLog(userId, {
    botId: config.id,
    cycleIndex: 0,
    status: config.botStatus,
    event: 'INFO',
    price: 0,
    message: `ربات سود «${config.name}» ساخته شد · ورود: ${formatQuoteShort(
      config.entryAmount,
      config.quoteCurrency
    )} · سود خالص هدف: ${formatQuoteShort(config.targetNetProfit, config.quoteCurrency)}`,
  });

  return config;
}

export async function updateProfitBotSettings(
  userId: string,
  botId: string,
  updates: Partial<CreateProfitBotInput>
): Promise<ProfitBotConfig> {
  const existing = await getUserProfitBotById(userId, botId);
  if (!existing) throw new Error('ربات سود مورد نظر یافت نشد.');

  if (updates.mode === 'live' && !(await hasActiveExchangeCredentialsForUser(userId))) {
    throw new Error('برای انتقال به حالت واقعی، ابتدا کلید API نوبیتکس خود را متصل کنید.');
  }

  const nextBase = updates.baseAsset ? updates.baseAsset.toUpperCase().trim() : existing.baseAsset;
  const nextQuote: QuoteCurrency = updates.quoteCurrency
    ? updates.quoteCurrency === 'USDT'
      ? 'USDT'
      : 'IRT'
    : existing.quoteCurrency;
  const nextSymbol = `${nextBase}${nextQuote}`;

  if (
    nextSymbol !== existing.symbol &&
    (existing.activePosition || existing.pendingOrder)
  ) {
    throw new Error(
      'هنگامی که پوزیشن یا سفارش باز فعال وجود دارد امکان تغییر جفت‌ارز نیست.'
    );
  }

  const nextFundingMode =
    updates.fundingMode !== undefined
      ? normalizeFundingMode(updates.fundingMode)
      : normalizeFundingMode(existing.fundingMode);
  const nextExistingBalancePercent =
    updates.existingBalancePercent !== undefined
      ? clampBalancePercent(updates.existingBalancePercent)
      : clampBalancePercent(existing.existingBalancePercent);
  const nextExistingEntryPrice =
    updates.existingEntryPrice !== undefined
      ? updates.existingEntryPrice && Number(updates.existingEntryPrice) > 0
        ? Number(updates.existingEntryPrice)
        : null
      : existing.existingEntryPrice ?? null;

  const rawNextEntry =
    updates.entryAmount !== undefined ? Number(updates.entryAmount) : existing.entryAmount;
  const nextEntry = Number.isFinite(rawNextEntry) && rawNextEntry >= 0 ? rawNextEntry : 0;
  const minNotional = getMinimumOrderNotional(nextQuote);
  if (
    nextFundingMode !== 'EXISTING_ASSET' &&
    (!Number.isFinite(rawNextEntry) || nextEntry + 1e-6 < minNotional)
  ) {
    throw new Error(
      `حداقل مبلغ ورود در بازار ${nextQuote === 'IRT' ? 'تومانی ۵۰,۰۰۰ تومان' : 'تتری ۰.۵ USDT'} است.`
    );
  }

  const nextTarget =
    updates.targetNetProfit !== undefined
      ? Number(updates.targetNetProfit)
      : existing.targetNetProfit;
  if (!Number.isFinite(nextTarget) || nextTarget <= 0) {
    throw new Error('مبلغ سود خالص هدف باید بزرگ‌تر از صفر باشد.');
  }

  const nextMaxCapital = Math.max(
    nextEntry,
    updates.maxCapitalInvolved !== undefined
      ? Number(updates.maxCapitalInvolved)
      : existing.maxCapitalInvolved
  );

  const nextReentryTargetPrice =
    updates.reentryTargetPrice !== undefined
      ? updates.reentryTargetPrice && Number(updates.reentryTargetPrice) > 0
        ? Number(updates.reentryTargetPrice)
        : null
      : existing.reentryTargetPrice ?? null;
  const nextReentryPolicy: ProfitBotReentryPolicy =
    updates.reentryPolicy !== undefined
      ? updates.reentryPolicy === 'IMMEDIATE'
        ? 'IMMEDIATE'
        : 'WAIT_ENTRY_PRICE'
      : existing.reentryPolicy ?? 'WAIT_ENTRY_PRICE';
  const nextWaitEntryPriceOnFirstBuy =
    updates.waitEntryPriceOnFirstBuy !== undefined
      ? Boolean(updates.waitEntryPriceOnFirstBuy)
      : Boolean(existing.waitEntryPriceOnFirstBuy);
  const nextTargetSellPrice =
    updates.targetSellPrice !== undefined
      ? updates.targetSellPrice && Number(updates.targetSellPrice) > 0
        ? Number(updates.targetSellPrice)
        : null
      : existing.targetSellPrice ?? null;

  const now = Date.now();
  const db = getDb();
  const [updatedRow] = await db
    .update(schema.profitBots)
    .set({
      name: updates.name !== undefined ? updates.name.trim() || existing.name : existing.name,
      baseAsset: nextBase,
      quoteCurrency: nextQuote,
      symbol: nextSymbol,
      mode: updates.mode ? (updates.mode === 'live' ? 'live' : 'paper') : existing.mode,
      entryAmount: nextEntry,
      targetNetProfit: nextTarget,
      pollIntervalSeconds:
        updates.pollIntervalSeconds !== undefined
          ? Math.min(300, Math.max(2, Math.round(Number(updates.pollIntervalSeconds))))
          : existing.pollIntervalSeconds,
      maxWaitMinutes:
        updates.maxWaitMinutes !== undefined
          ? updates.maxWaitMinutes && updates.maxWaitMinutes > 0
            ? Math.min(43_200, Math.round(updates.maxWaitMinutes))
            : null
          : existing.maxWaitMinutes,
      stopLossEnabled:
        updates.stopLossEnabled !== undefined
          ? Boolean(updates.stopLossEnabled)
          : existing.stopLossEnabled,
      stopLossPercent:
        updates.stopLossPercent !== undefined
          ? Math.min(90, Math.max(0.2, Number(updates.stopLossPercent)))
          : existing.stopLossPercent,
      stopLossAction:
        updates.stopLossAction === 'STOP_ONLY' || updates.stopLossAction === 'STOP_AND_SELL'
          ? updates.stopLossAction
          : existing.stopLossAction,
      maxCapitalInvolved: nextMaxCapital,
      maxDailyTrades:
        updates.maxDailyTrades !== undefined
          ? Math.min(500, Math.max(1, Math.round(Number(updates.maxDailyTrades))))
          : existing.maxDailyTrades,
      maxDailyLoss:
        updates.maxDailyLoss !== undefined
          ? Math.max(0, Number(updates.maxDailyLoss))
          : existing.maxDailyLoss,
      orderType:
        updates.orderType === 'MARKET' || updates.orderType === 'LIMIT'
          ? updates.orderType
          : existing.orderType,
      maxSlippagePercent:
        updates.maxSlippagePercent !== undefined
          ? Math.min(20, Math.max(0.05, Number(updates.maxSlippagePercent)))
          : existing.maxSlippagePercent,
      maxSpreadPercent:
        updates.maxSpreadPercent !== undefined
          ? Math.min(20, Math.max(0.05, Number(updates.maxSpreadPercent)))
          : existing.maxSpreadPercent,
      limitOrderTimeoutSeconds:
        updates.limitOrderTimeoutSeconds !== undefined
          ? Math.min(86_400, Math.max(10, Math.round(Number(updates.limitOrderTimeoutSeconds))))
          : existing.limitOrderTimeoutSeconds,
      limitUnfilledPolicy:
        updates.limitUnfilledPolicy || existing.limitUnfilledPolicy,
      sequenceMode: updates.sequenceMode || existing.sequenceMode,
      feeRate:
        updates.feeRate !== undefined
          ? Math.min(0.05, Math.max(0, Number(updates.feeRate)))
          : existing.feeRate,
      otherFeesQuote:
        updates.otherFeesQuote !== undefined
          ? Math.max(0, Number(updates.otherFeesQuote))
          : existing.otherFeesQuote,
      notifyTelegram:
        updates.notifyTelegram !== undefined
          ? Boolean(updates.notifyTelegram)
          : existing.notifyTelegram,
      statsJson: buildPersistedStatsJson({
        stats: existing.stats,
        reentryTargetPrice: nextReentryTargetPrice,
        reentryPolicy: nextReentryPolicy,
        waitEntryPriceOnFirstBuy: nextWaitEntryPriceOnFirstBuy,
        targetSellPrice: nextTargetSellPrice,
        fundingMode: nextFundingMode,
        existingBalancePercent: nextExistingBalancePercent,
        existingEntryPrice: nextExistingEntryPrice,
        executionConfirmationMode:
          updates.executionConfirmationMode !== undefined
            ? updates.executionConfirmationMode === 'MANUAL_CONFIRM'
              ? 'MANUAL_CONFIRM'
              : 'AUTO'
            : existing.executionConfirmationMode,
      }),
      updatedAt: now,
    })
    .where(and(eq(schema.profitBots.id, botId), eq(schema.profitBots.userId, userId)))
    .returning();

  const mapped = mapProfitBotRow(updatedRow);
  await appendProfitBotLog(userId, {
    botId,
    cycleIndex: mapped.stats.completedCycles,
    status: mapped.botStatus,
    event: 'INFO',
    price: 0,
    message: `تنظیمات ربات سود به‌روزرسانی شد · سود هدف: ${formatQuoteShort(
      mapped.targetNetProfit,
      mapped.quoteCurrency
    )}`,
  });
  return mapped;
}

export async function startProfitBot(
  userId: string,
  botId: string,
  deps?: Partial<ProfitBotRuntimeDeps>
): Promise<ProfitBotConfig> {
  const existing = await getUserProfitBotById(userId, botId);
  if (!existing) throw new Error('ربات سود مورد نظر یافت نشد.');

  if (existing.mode === 'live' && !(await hasActiveExchangeCredentialsForUser(userId))) {
    throw new Error('کلید API نوبیتکس برای اجرای واقعی روی این حساب ثبت نشده است.');
  }

  const now = deps?.now ? deps.now() : Date.now();
  const nextStatus: ProfitBotStatus = existing.pendingOrder
    ? existing.pendingOrder.side === 'BUY'
      ? 'PLACING_BUY'
      : 'PLACING_SELL'
    : existing.activePosition
      ? 'WAITING_FOR_PROFIT'
      : 'CHECKING_MARKET';

  const nextReason = existing.activePosition
    ? 'ربات دوباره فعال شد و در انتظار رسیدن به سود خالص هدف است.'
    : 'ربات فعال شد و بررسی لحظه‌ای بازار نوبیتکس آغاز گردید.';

  const db = getDb();
  const [updatedRow] = await db
    .update(schema.profitBots)
    .set({
      isActive: true,
      botStatus: nextStatus,
      lastStatusReason: nextReason,
      lastError: null,
      consecutiveFailures: 0,
      nextRetryAt: null,
      startedAt: existing.startedAt || now,
      updatedAt: now,
    })
    .where(and(eq(schema.profitBots.id, botId), eq(schema.profitBots.userId, userId)))
    .returning();

  const updated = mapProfitBotRow(updatedRow);
  await appendProfitBotLog(userId, {
    botId,
    cycleIndex: updated.stats.completedCycles,
    status: updated.botStatus,
    event: 'INFO',
    price: 0,
    message: 'ربات سود با دستور کاربر شروع به کار کرد.',
  });
  void notifyProfitBotTelegram(userId, updated, 'شروع ربات سود', nextReason);
  return updated;
}

export async function stopProfitBot(
  userId: string,
  botId: string,
  options?: { reason?: string; cancelPending?: boolean; deps?: Partial<ProfitBotRuntimeDeps> }
): Promise<ProfitBotConfig> {
  const existing = await getUserProfitBotById(userId, botId);
  if (!existing) throw new Error('ربات سود مورد نظر یافت نشد.');

  const runtime = { ...createDefaultRuntimeDeps(), ...(options?.deps || {}) };
  const reason = options?.reason || 'ربات سود فوراً به دستور کاربر متوقف شد.';

  if (existing.pendingOrder && options?.cancelPending !== false) {
    try {
      const latestOrder = await runtime.getOrderStatus(
        userId,
        existing.pendingOrder.orderId,
        existing.pendingOrder.exchangeOrderId,
        existing.mode,
        existing.symbol,
        existing.pendingOrder.price
      );

      if (latestOrder && latestOrder.status === 'FILLED') {
        await reconcileOrderCompletion(existing, latestOrder, runtime, 'MANUAL_STOP_RECONCILE');
      } else {
        await runtime.cancelOrder(
          userId,
          existing.pendingOrder.orderId,
          existing.pendingOrder.exchangeOrderId,
          existing.mode
        );
        const rechecked = await runtime
          .getOrderStatus(
            userId,
            existing.pendingOrder.orderId,
            existing.pendingOrder.exchangeOrderId,
            existing.mode,
            existing.symbol,
            existing.pendingOrder.price
          )
          .catch(() => latestOrder);

        if (
          rechecked &&
          rechecked.executedQty > 0 &&
          existing.pendingOrder.side === 'BUY' &&
          !existing.activePosition
        ) {
          promoteBuyExecutionToPosition(existing, rechecked, true, runtime.now());
        }
        existing.pendingOrder = null;
      }
    } catch (err) {
      logger.warn('profit_bot.stop_cancel_recheck_failed', {
        botId,
        error: err instanceof Error ? err.message : String(err),
      });
    }
  }

  existing.isActive = false;
  existing.botStatus = 'STOPPED';
  existing.lastStatusReason = reason;
  await persistProfitBotState(existing, { consecutiveFailures: 0, nextRetryAt: null });

  await appendProfitBotLog(userId, {
    botId,
    cycleIndex: existing.stats.completedCycles,
    status: 'STOPPED',
    event: 'STOPPED',
    price: 0,
    message: reason,
  });
  void notifyProfitBotTelegram(userId, existing, 'توقف ربات سود', reason);
  return existing;
}

export async function deleteProfitBot(userId: string, botId: string): Promise<void> {
  const existing = await getUserProfitBotById(userId, botId);
  if (!existing) return;
  if (existing.isActive || existing.pendingOrder) {
    await stopProfitBot(userId, botId, {
      reason: 'لغو خودکار پیش از حذف ربات سود',
      cancelPending: true,
    });
  }
  const db = getDb();
  await db
    .delete(schema.profitBots)
    .where(and(eq(schema.profitBots.id, botId), eq(schema.profitBots.userId, userId)));
}

export async function emergencyStopUserProfitBots(userId: string): Promise<number> {
  const bots = await getUserProfitBots(userId);
  const activeBots = bots.filter((b) => b.isActive || b.pendingOrder);
  for (const b of activeBots) {
    await stopProfitBot(userId, b.id, {
      reason: 'توقف اضطراری سراسری (Kill Switch) توسط کاربر',
      cancelPending: true,
    });
  }
  return activeBots.length;
}

export async function emergencyStopAllProfitBots(actorEmail: string): Promise<number> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.profitBots)
    .where(eq(schema.profitBots.isActive, true));

  const now = Date.now();
  await db
    .update(schema.profitBots)
    .set({
      isActive: false,
      botStatus: 'STOPPED',
      lastStatusReason: `توقف اضطراری سراسری توسط مدیر (${actorEmail})`,
      updatedAt: now,
    })
    .where(eq(schema.profitBots.isActive, true));

  return rows.length;
}

// ===========================================================================
// Core Accounting Helpers (Zero Buy-Fee Double Counting)
// ===========================================================================
function promoteBuyExecutionToPosition(
  bot: ProfitBotConfig,
  order: SpotOrder,
  partialFill: boolean,
  filledAt: number
): ProfitBotPosition {
  const filledGrossQty = order.executedQty > 0 ? order.executedQty : order.quantity;
  const rawOrderPrice = Number.isFinite(order.price) && order.price > 0 ? order.price : 0;
  const rawTotalQuote =
    Number.isFinite(order.totalQuoteAmount) && order.totalQuoteAmount > 0
      ? order.totalQuoteAmount
      : 0;
  const actualBuyAvgPrice =
    rawOrderPrice > 0
      ? rawOrderPrice
      : rawTotalQuote > 0 && filledGrossQty > 0
        ? rawTotalQuote / filledGrossQty
        : filledGrossQty > 0
          ? bot.entryAmount / filledGrossQty
          : 0;
  const buyPrincipalQuote =
    rawTotalQuote > 0 && !partialFill
      ? rawTotalQuote
      : filledGrossQty * actualBuyAvgPrice;
  const feeRate = bot.feeRate ?? DEFAULT_NOBITEX_FEE_RATE;
  const buyFeeQuote = buyPrincipalQuote * feeRate;
  const netOwnedQty = filledGrossQty * (1 - feeRate);
  // IMPORTANT: Nobitex spot buy charges fee from received base asset.
  // Therefore totalBuyCostQuote = buyPrincipalQuote already embeds the buy fee via reduced netOwnedQty.
  const totalBuyCostQuote = buyPrincipalQuote;
  const cycleIndex = bot.stats.completedCycles + 1;

  const pos: ProfitBotPosition = {
    cycleIndex,
    buyOrderId: order.orderId,
    buyExchangeOrderId: order.mode === 'live' ? order.orderId : undefined,
    buyOrderType: order.type,
    requestedQuoteAmount: bot.entryAmount,
    requestedQty: order.quantity,
    filledGrossQty,
    netOwnedQty,
    actualBuyAvgPrice,
    buyPrincipalQuote,
    buyFeeQuote,
    buyFeeAsset: bot.baseAsset,
    totalBuyCostQuote,
    otherFeesQuote: bot.otherFeesQuote || 0,
    buyFilledAt: filledAt,
    partialFill,
    lastRequiredSellPrice:
      bot.targetSellPrice && bot.targetSellPrice > 0
        ? bot.targetSellPrice
        : computeRequiredSellPrice(
            netOwnedQty,
            totalBuyCostQuote,
            bot.targetNetProfit,
            feeRate,
            bot.otherFeesQuote || 0
          ),
  };

  bot.activePosition = pos;
  bot.stats.currentCapitalInvolved = totalBuyCostQuote;
  bot.stats.lastBuyPrice = actualBuyAvgPrice;
  return pos;
}

function promoteExistingBalanceToPosition(
  bot: ProfitBotConfig,
  allocatedQty: number,
  referencePrice: number,
  filledAt: number
): ProfitBotPosition {
  const feeRate = bot.feeRate ?? DEFAULT_NOBITEX_FEE_RATE;
  const buyPrincipalQuote = allocatedQty * referencePrice;
  const totalBuyCostQuote = buyPrincipalQuote;
  const cycleIndex = bot.stats.completedCycles + 1;

  const pos: ProfitBotPosition = {
    cycleIndex,
    buyOrderId: `existing-${filledAt}`,
    buyOrderType: bot.orderType,
    requestedQuoteAmount: totalBuyCostQuote,
    requestedQty: allocatedQty,
    filledGrossQty: allocatedQty,
    netOwnedQty: allocatedQty,
    actualBuyAvgPrice: referencePrice,
    buyPrincipalQuote,
    buyFeeQuote: 0,
    buyFeeAsset: bot.baseAsset,
    totalBuyCostQuote,
    otherFeesQuote: bot.otherFeesQuote || 0,
    buyFilledAt: filledAt,
    partialFill: false,
    fromExistingBalance: true,
    lastRequiredSellPrice:
      bot.targetSellPrice && bot.targetSellPrice > 0
        ? bot.targetSellPrice
        : computeRequiredSellPrice(
            allocatedQty,
            totalBuyCostQuote,
            bot.targetNetProfit,
            feeRate,
            bot.otherFeesQuote || 0
          ),
  };

  bot.activePosition = pos;
  bot.stats.currentCapitalInvolved = totalBuyCostQuote;
  bot.stats.lastBuyPrice = referencePrice;
  return pos;
}

async function finalizeSellPositionAndCycle(
  bot: ProfitBotConfig,
  pos: ProfitBotPosition,
  sellOrder: SpotOrder,
  exitReason: ProfitBotCycleRecord['exitReason'],
  completedAt: number
): Promise<ProfitBotCycleRecord> {
  const userId = bot.ownerId || '';
  const feeRate = bot.feeRate ?? DEFAULT_NOBITEX_FEE_RATE;
  const soldQty = sellOrder.executedQty > 0 ? sellOrder.executedQty : pos.netOwnedQty;
  const actualSellAvgPrice = sellOrder.price;
  const grossSellProceedsQuote = soldQty * actualSellAvgPrice;
  const sellFeeQuote = grossSellProceedsQuote * feeRate;
  const otherFeesQuote = pos.otherFeesQuote || bot.otherFeesQuote || 0;
  const finalNetProfitQuote = roundQuoteValue(
    grossSellProceedsQuote - pos.totalBuyCostQuote - sellFeeQuote - otherFeesQuote,
    bot.quoteCurrency
  );

  const cycleRecord: ProfitBotCycleRecord = {
    id: `pcyc-${completedAt}-${crypto.randomBytes(3).toString('hex')}`,
    botId: bot.id,
    cycleIndex: pos.cycleIndex,
    symbol: bot.symbol,
    baseAsset: bot.baseAsset,
    quoteCurrency: bot.quoteCurrency,
    mode: bot.mode,
    orderType: sellOrder.type,
    entryAmountQuote: pos.buyPrincipalQuote,
    actualBuyAvgPrice: pos.actualBuyAvgPrice,
    boughtQty: pos.netOwnedQty,
    buyFeeQuote: pos.buyFeeQuote,
    totalBuyCostQuote: pos.totalBuyCostQuote,
    actualSellAvgPrice,
    soldQty,
    grossSellProceedsQuote,
    sellFeeQuote,
    otherFeesQuote,
    finalNetProfitQuote,
    targetNetProfitQuote: bot.targetNetProfit,
    exitReason,
    startedAt: pos.buyFilledAt,
    completedAt,
  };

  const db = getDb();
  await db.insert(schema.profitBotCycles).values({
    id: cycleRecord.id,
    botId: cycleRecord.botId,
    userId,
    cycleIndex: cycleRecord.cycleIndex,
    symbol: cycleRecord.symbol,
    baseAsset: cycleRecord.baseAsset,
    quoteCurrency: cycleRecord.quoteCurrency,
    mode: cycleRecord.mode,
    orderType: cycleRecord.orderType,
    entryAmountQuote: cycleRecord.entryAmountQuote,
    actualBuyAvgPrice: cycleRecord.actualBuyAvgPrice,
    boughtQty: cycleRecord.boughtQty,
    buyFeeQuote: cycleRecord.buyFeeQuote,
    totalBuyCostQuote: cycleRecord.totalBuyCostQuote,
    actualSellAvgPrice: cycleRecord.actualSellAvgPrice,
    soldQty: cycleRecord.soldQty,
    grossSellProceedsQuote: cycleRecord.grossSellProceedsQuote,
    sellFeeQuote: cycleRecord.sellFeeQuote,
    otherFeesQuote: cycleRecord.otherFeesQuote,
    finalNetProfitQuote: cycleRecord.finalNetProfitQuote,
    targetNetProfitQuote: cycleRecord.targetNetProfitQuote,
    exitReason: cycleRecord.exitReason,
    startedAt: cycleRecord.startedAt,
    completedAt: cycleRecord.completedAt,
  });

  bot.stats.completedCycles += 1;
  if (finalNetProfitQuote >= 0) bot.stats.winningCycles += 1;
  else bot.stats.losingCycles += 1;
  bot.stats.totalNetProfitQuote = roundQuoteValue(
    bot.stats.totalNetProfitQuote + finalNetProfitQuote,
    bot.quoteCurrency
  );
  bot.stats.totalFeesPaidQuote = roundQuoteValue(
    bot.stats.totalFeesPaidQuote + pos.buyFeeQuote + sellFeeQuote + otherFeesQuote,
    bot.quoteCurrency
  );
  bot.stats.currentCapitalInvolved = 0;

  bot.dailyStats = normalizeDailyStats(bot.dailyStats, completedAt);
  bot.dailyStats.tradesCount += 1;
  bot.dailyStats.netProfitQuote = roundQuoteValue(
    bot.dailyStats.netProfitQuote + finalNetProfitQuote,
    bot.quoteCurrency
  );
  if (finalNetProfitQuote < 0) {
    bot.dailyStats.lossQuote = roundQuoteValue(
      bot.dailyStats.lossQuote + Math.abs(finalNetProfitQuote),
      bot.quoteCurrency
    );
  }

  bot.activePosition = null;
  bot.pendingOrder = null;

  await appendProfitBotLog(userId, {
    botId: bot.id,
    cycleIndex: cycleRecord.cycleIndex,
    status: 'SELL_FILLED',
    event: 'SELL_FILLED',
    price: actualSellAvgPrice,
    netProfitQuote: finalNetProfitQuote,
    message: `فروش تکمیل شد (${exitReason}) · سود خالص واقعی: ${
      finalNetProfitQuote >= 0 ? '+' : ''
    }${formatQuoteShort(finalNetProfitQuote, bot.quoteCurrency)} · مجموع کارمزد: ${formatQuoteShort(
      pos.buyFeeQuote + sellFeeQuote,
      bot.quoteCurrency
    )}`,
    timestamp: completedAt,
  });

  if (exitReason === 'STOP_LOSS') {
    bot.isActive = false;
    bot.botStatus = 'STOPPED';
    bot.lastStatusReason = `فروش با حد ضرر انجام شد (${formatQuoteShort(
      finalNetProfitQuote,
      bot.quoteCurrency
    )}) و ربات متوقف گردید.`;
  } else if (bot.sequenceMode === 'SINGLE') {
    bot.isActive = false;
    bot.botStatus = 'SELL_FILLED';
    bot.lastStatusReason = `تک‌معامله کامل شد · سود خالص: ${
      finalNetProfitQuote >= 0 ? '+' : ''
    }${formatQuoteShort(finalNetProfitQuote, bot.quoteCurrency)}`;
  } else if (bot.sequenceMode === 'PREPARE_NEXT') {
    bot.isActive = false;
    bot.botStatus = 'READY_TO_BUY';
    bot.lastStatusReason = `چرخه ${cycleRecord.cycleIndex} با سود ${formatQuoteShort(
      finalNetProfitQuote,
      bot.quoteCurrency
    )} بسته شد · آماده خرید بعدی (منتظر تأیید شما).`;
  } else {
    const hitTradeCap = bot.dailyStats.tradesCount >= bot.maxDailyTrades;
    const hitLossCap = bot.maxDailyLoss > 0 && bot.dailyStats.lossQuote >= bot.maxDailyLoss;
    if (hitTradeCap || hitLossCap) {
      bot.isActive = false;
      bot.botStatus = 'STOPPED';
      bot.lastStatusReason = hitTradeCap
        ? `سقف تعداد معاملات مجاز روزانه (${bot.maxDailyTrades}) تکمیل شد.`
        : `سقف مجاز ضرر روزانه پر شد و چرخه متوقف گردید.`;
    } else if (bot.fundingMode === 'EXISTING_ASSET') {
      bot.isActive = true;
      bot.botStatus = 'CHECKING_MARKET';
      bot.lastStatusReason = `چرخه ${cycleRecord.cycleIndex} با سود ${formatQuoteShort(
        finalNetProfitQuote,
        bot.quoteCurrency
      )} بسته شد · بررسی موجودی باقیمانده ${bot.baseAsset} (${clampBalancePercent(
        bot.existingBalancePercent
      )}٪) برای چرخه بعدی.`;
    } else {
      const reentryPrice =
        bot.reentryTargetPrice && bot.reentryTargetPrice > 0
          ? bot.reentryTargetPrice
          : bot.stats.lastBuyPrice || pos.actualBuyAvgPrice;
      const waitReentry = bot.reentryPolicy !== 'IMMEDIATE' && reentryPrice > 0;
      bot.isActive = true;
      bot.botStatus = waitReentry ? 'CHECKING_MARKET' : 'READY_TO_BUY';
      bot.lastStatusReason = waitReentry
        ? `چرخه ${cycleRecord.cycleIndex} با سود ${formatQuoteShort(
            finalNetProfitQuote,
            bot.quoteCurrency
          )} بسته شد · در انتظار بازگشت قیمت به ${formatQuoteShort(
            reentryPrice,
            bot.quoteCurrency
          )} برای خرید مجدد.`
        : `چرخه ${cycleRecord.cycleIndex} با سود ${formatQuoteShort(
            finalNetProfitQuote,
            bot.quoteCurrency
          )} تکمیل شد · آماده ورود به چرخه بعدی.`;
    }
  }

  void notifyProfitBotTelegram(
    userId,
    bot,
    'تکمیل معامله ربات سود',
    bot.lastStatusReason
  );

  return cycleRecord;
}

async function reconcileOrderCompletion(
  bot: ProfitBotConfig,
  order: SpotOrder,
  runtime: ProfitBotRuntimeDeps,
  sellExitReason: ProfitBotCycleRecord['exitReason'] | 'MANUAL_STOP_RECONCILE' = 'TARGET_PROFIT'
): Promise<void> {
  const userId = bot.ownerId || '';
  const now = runtime.now();
  const pending = bot.pendingOrder;
  if (!pending) return;

  if (pending.side === 'BUY') {
    const pos = promoteBuyExecutionToPosition(bot, order, false, now);
    bot.pendingOrder = null;
    bot.botStatus = 'BUY_FILLED';
    bot.lastStatusReason = `خرید تکمیل شد · میانگین: ${formatQuoteShort(
      pos.actualBuyAvgPrice,
      bot.quoteCurrency
    )} · قیمت فروش هدف: ${formatQuoteShort(pos.lastRequiredSellPrice || 0, bot.quoteCurrency)}`;

    await appendProfitBotLog(userId, {
      botId: bot.id,
      cycleIndex: pos.cycleIndex,
      status: 'BUY_FILLED',
      event: 'BUY_FILLED',
      price: pos.actualBuyAvgPrice,
      message: bot.lastStatusReason,
      timestamp: now,
    });
    void notifyProfitBotTelegram(userId, bot, 'تکمیل خرید ربات سود', bot.lastStatusReason);
  } else if (bot.activePosition) {
    const resolvedExit: ProfitBotCycleRecord['exitReason'] =
      sellExitReason === 'MANUAL_STOP_RECONCILE' ? 'TARGET_PROFIT' : sellExitReason;
    await finalizeSellPositionAndCycle(bot, bot.activePosition, order, resolvedExit, now);
  } else {
    bot.pendingOrder = null;
  }
}

// ===========================================================================
// State Machine Evaluator (Single Bot)
// ===========================================================================
export async function evaluateProfitBot(
  bot: ProfitBotConfig,
  customDeps?: Partial<ProfitBotRuntimeDeps>
): Promise<ProfitBotConfig> {
  const userId = bot.ownerId || '';
  if (!userId) return bot;
  if (!bot.isActive) return bot;

  const runtime: ProfitBotRuntimeDeps = { ...createDefaultRuntimeDeps(), ...(customDeps || {}) };
  const db = getDb();
  const now = runtime.now();
  bot.dailyStats = normalizeDailyStats(bot.dailyStats, now);

  try {
    // -------------------------------------------------------------------------
    // STEP A: Reconcile any pending LIMIT / open order FIRST (anti-duplicate!)
    // -------------------------------------------------------------------------
    if (bot.pendingOrder) {
      const pending = bot.pendingOrder;
      let orderBook: OrderBookSnapshot | null = null;
      try {
        orderBook = await runtime.fetchOrderBook(bot.symbol, 40);
      } catch {
        // Order status lookup can still work without orderBook
      }

      const refPrice =
        pending.side === 'BUY'
          ? orderBook?.asks?.[0]?.price || orderBook?.lastTradePrice || pending.price
          : orderBook?.bids?.[0]?.price || orderBook?.lastTradePrice || pending.price;

      const latest = await runtime.getOrderStatus(
        userId,
        pending.orderId,
        pending.exchangeOrderId,
        bot.mode,
        bot.symbol,
        refPrice
      );

      bot.lastCheckedAt = now;

      if (!latest) {
        bot.botStatus = 'NEEDS_USER_REVIEW';
        bot.isActive = false;
        bot.lastStatusReason =
          'اطلاعات سفارش در صرافی یافت نشد؛ برای جلوگیری از ثبت سفارش تکراری ربات نیازمند بررسی کاربر است.';
        await persistProfitBotState(bot);
        await appendProfitBotLog(userId, {
          botId: bot.id,
          cycleIndex: pending.cycleIndex,
          status: 'NEEDS_USER_REVIEW',
          event: 'NEEDS_REVIEW',
          price: pending.price,
          message: bot.lastStatusReason,
          timestamp: now,
        });
        return bot;
      }

      if (latest.status === 'FILLED') {
        await reconcileOrderCompletion(bot, latest, runtime, 'TARGET_PROFIT');
        if (bot.activePosition && bot.isActive && orderBook) {
          // Move smoothly into WAITING_FOR_PROFIT with fresh snapshot
          await evaluateActivePosition(bot, orderBook, runtime, true);
        } else {
          await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
        }
        return bot;
      }

      const elapsedSec = (now - pending.placedAt) / 1000;
      const timedOut = elapsedSec >= bot.limitOrderTimeoutSeconds;

      if (latest.status === 'PARTIALLY_FILLED') {
        pending.executedQty = latest.executedQty;
        pending.lastCheckedAt = now;
        bot.botStatus = 'PARTIAL_ORDER';

        if (!timedOut) {
          bot.lastStatusReason = `سفارش ${
            pending.side === 'BUY' ? 'خرید' : 'فروش'
          } به‌صورت ناقص انجام شده (${latest.executedQty.toFixed(6)} از ${latest.quantity.toFixed(
            6
          )}) · در انتظار تکمیل باقی‌مانده.`;
          await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
          return bot;
        }

        // Timed out on partial fill -> cancel remaining unfilled portion and re-verify
        await runtime.cancelOrder(userId, pending.orderId, pending.exchangeOrderId, bot.mode);
        const rechecked = await runtime
          .getOrderStatus(
            userId,
            pending.orderId,
            pending.exchangeOrderId,
            bot.mode,
            bot.symbol,
            refPrice
          )
          .catch(() => latest);

        const actualFilled = rechecked?.executedQty || latest.executedQty;
        if (pending.side === 'BUY' && actualFilled > 0) {
          const filledNotional = actualFilled * (rechecked?.price || pending.price);
          const marketRules = await getNobitexMarketRules(bot.symbol).catch(() => ({
            minNotional: getMinimumOrderNotional(bot.quoteCurrency),
            amountStep: 1e-6,
          }));

          const pos = promoteBuyExecutionToPosition(
            bot,
            { ...(rechecked || latest), executedQty: actualFilled, price: rechecked?.price || pending.price },
            true,
            now
          );
          bot.pendingOrder = null;

          if (filledNotional + 1e-6 < marketRules.minNotional) {
            bot.isActive = false;
            bot.botStatus = 'NEEDS_USER_REVIEW';
            bot.lastStatusReason = `سفارش خرید ناقص لغو شد؛ مقدار واقعی پرشده (${actualFilled.toFixed(
              6
            )} ${bot.baseAsset}) کمتر از حداقل مجاز نوبیتکس برای فروش خودکار است.`;
            await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
            await appendProfitBotLog(userId, {
              botId: bot.id,
              cycleIndex: pos.cycleIndex,
              status: 'NEEDS_USER_REVIEW',
              event: 'PARTIAL_FILL',
              price: pos.actualBuyAvgPrice,
              message: bot.lastStatusReason,
              timestamp: now,
            });
            return bot;
          }

          bot.botStatus = 'WAITING_FOR_PROFIT';
          bot.lastStatusReason = `بخش باقی‌مانده سفارش خرید لغو شد · مدیریت فروش فقط برای مقدار واقعی خریداری‌شده (${pos.netOwnedQty.toFixed(
            6
          )} ${bot.baseAsset}) فعال شد.`;
          await appendProfitBotLog(userId, {
            botId: bot.id,
            cycleIndex: pos.cycleIndex,
            status: 'PARTIAL_ORDER',
            event: 'PARTIAL_FILL',
            price: pos.actualBuyAvgPrice,
            message: bot.lastStatusReason,
            timestamp: now,
          });
          await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
          return bot;
        }

        if (pending.side === 'SELL' && bot.activePosition && actualFilled > 0) {
          const soldAll = actualFilled >= bot.activePosition.netOwnedQty * 0.999;
          if (soldAll) {
            await finalizeSellPositionAndCycle(
              bot,
              bot.activePosition,
              { ...(rechecked || latest), executedQty: actualFilled },
              'PARTIAL_EXIT',
              now
            );
            await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
            return bot;
          }
          // Reduce remaining position strictly by actual sold qty
          const soldFraction = Math.min(1, actualFilled / bot.activePosition.netOwnedQty);
          bot.activePosition.netOwnedQty = Math.max(0, bot.activePosition.netOwnedQty - actualFilled);
          bot.activePosition.totalBuyCostQuote *= 1 - soldFraction;
          bot.activePosition.buyFeeQuote *= 1 - soldFraction;
          bot.activePosition.partialFill = true;
          bot.activePosition.lastRequiredSellPrice = computeRequiredSellPrice(
            bot.activePosition.netOwnedQty,
            bot.activePosition.totalBuyCostQuote,
            bot.targetNetProfit,
            bot.feeRate,
            bot.otherFeesQuote
          );
          bot.pendingOrder = null;
          bot.botStatus = 'PARTIAL_ORDER';
          bot.lastStatusReason = `بخشی از فروش (${actualFilled.toFixed(
            6
          )} ${bot.baseAsset}) انجام شد · باقی‌مانده در حال پایش برای ادامه فروش.`;
          await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
          return bot;
        }
      }

      if (latest.status === 'CANCELED') {
        if (latest.executedQty > 0 && pending.side === 'BUY' && !bot.activePosition) {
          promoteBuyExecutionToPosition(bot, latest, true, now);
          bot.pendingOrder = null;
          bot.botStatus = 'WAITING_FOR_PROFIT';
          bot.lastStatusReason = `سفارش خرید در صرافی لغو شد اما مقدار ${latest.executedQty.toFixed(
            6
          )} پر شده بود؛ مدیریت سود برای همین مقدار ادامه دارد.`;
        } else {
          bot.pendingOrder = null;
          bot.isActive = false;
          bot.botStatus = 'STOPPED';
          bot.lastStatusReason = 'سفارش باز در صرافی لغو شده است؛ ربات متوقف گردید.';
        }
        await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
        return bot;
      }

      // Still NEW (0 filled)
      if (!timedOut) {
        pending.lastCheckedAt = now;
        bot.botStatus = pending.side === 'BUY' ? 'PLACING_BUY' : 'PLACING_SELL';
        bot.lastStatusReason = `سفارش لیمیت ${
          pending.side === 'BUY' ? 'خرید' : 'فروش'
        } با قیمت ${formatQuoteShort(pending.price, bot.quoteCurrency)} در دفتر سفارش منتظر تطبیق است.`;
        await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
        return bot;
      }

      // Timed out & still NEW -> apply limitUnfilledPolicy
      if (bot.limitUnfilledPolicy === 'KEEP_WAITING') {
        pending.lastCheckedAt = now;
        bot.botStatus = pending.side === 'BUY' ? 'PLACING_BUY' : 'PLACING_SELL';
        bot.lastStatusReason = `زمان انتظار لیمیت گذشت؛ طبق سیاست «ادامه انتظار» سفارش باز حفظ شد.`;
        await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
        return bot;
      }

      // Cancel and re-query before resetting/stopping!
      await runtime.cancelOrder(userId, pending.orderId, pending.exchangeOrderId, bot.mode);
      const afterCancel = await runtime
        .getOrderStatus(
          userId,
          pending.orderId,
          pending.exchangeOrderId,
          bot.mode,
          bot.symbol,
          refPrice
        )
        .catch(() => null);

      if (afterCancel && afterCancel.status === 'FILLED') {
        await reconcileOrderCompletion(bot, afterCancel, runtime, 'TARGET_PROFIT');
        await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
        return bot;
      }
      if (afterCancel && afterCancel.executedQty > 0 && pending.side === 'BUY' && !bot.activePosition) {
        promoteBuyExecutionToPosition(bot, afterCancel, true, now);
        bot.pendingOrder = null;
        bot.botStatus = 'WAITING_FOR_PROFIT';
        bot.lastStatusReason = `سفارش خرید حین لغو به‌صورت ناقص پر شد؛ مدیریت فروش برای مقدار واقعی فعال شد.`;
        await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
        return bot;
      }

      bot.pendingOrder = null;
      if (bot.limitUnfilledPolicy === 'STOP_BOT') {
        bot.isActive = false;
        bot.botStatus = 'STOPPED';
        bot.lastStatusReason = `زمان سفارش لیمیت پایان یافت و سفارش لغو شد؛ ربات متوقف گردید.`;
        await appendProfitBotLog(userId, {
          botId: bot.id,
          cycleIndex: pending.cycleIndex,
          status: 'STOPPED',
          event: 'CANCELED',
          price: pending.price,
          message: bot.lastStatusReason,
          timestamp: now,
        });
      } else {
        // CANCEL_AND_REPRICE
        bot.botStatus = bot.activePosition ? 'WAITING_FOR_PROFIT' : 'CHECKING_MARKET';
        bot.lastStatusReason = `سفارش لیمیت منقضی‌شده لغو شد؛ قیمت در چرخه جدید مجدداً بررسی می‌شود.`;
        await appendProfitBotLog(userId, {
          botId: bot.id,
          cycleIndex: pending.cycleIndex,
          status: bot.botStatus,
          event: 'CANCELED',
          price: pending.price,
          message: bot.lastStatusReason,
          timestamp: now,
        });
      }
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    // -------------------------------------------------------------------------
    // STEP B: Manage Active Position (Phase 2 & 3: Monitor bids + Sell at target)
    // -------------------------------------------------------------------------
    const orderBook = await runtime.fetchOrderBook(bot.symbol, 40);
    bot.lastCheckedAt = now;

    if (bot.activePosition) {
      await evaluateActivePosition(bot, orderBook, runtime, false);
      return bot;
    }

    // -------------------------------------------------------------------------
    // STEP C: Phase 1 — Check Market & Enter Buy Position
    // -------------------------------------------------------------------------
    bot.botStatus = 'CHECKING_MARKET';

    // Daily & Capital risk caps
    if (bot.dailyStats.tradesCount >= bot.maxDailyTrades) {
      bot.isActive = false;
      bot.botStatus = 'STOPPED';
      bot.lastStatusReason = `سقف تعداد معاملات مجاز در روز (${bot.maxDailyTrades}) به پایان رسیده است.`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    if (bot.maxDailyLoss > 0 && bot.dailyStats.lossQuote >= bot.maxDailyLoss) {
      bot.isActive = false;
      bot.botStatus = 'STOPPED';
      bot.lastStatusReason = `سقف ضرر روزانه (${formatQuoteShort(
        bot.maxDailyLoss,
        bot.quoteCurrency
      )}) پر شده و ربات متوقف گردید.`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    const marketRules = await getNobitexMarketRules(bot.symbol).catch(() => ({
      minNotional: getMinimumOrderNotional(bot.quoteCurrency),
      amountStep: 1e-6,
    }));
    const minNotional = marketRules.minNotional;
    const fundingMode = normalizeFundingMode(bot.fundingMode);
    const existingPct = clampBalancePercent(bot.existingBalancePercent);

    let cachedBalances: SpotBalance[] | null = null;

    if (fundingMode === 'EXISTING_ASSET' || fundingMode === 'AUTO_PREFER_EXISTING') {
      cachedBalances = await runtime.getBalances(userId, bot.mode);
      const baseWallet = cachedBalances.find((b) => b.asset.toUpperCase() === bot.baseAsset);
      const freeBase = baseWallet?.free ?? 0;
      const marketBidPrice =
        orderBook.bids?.[0]?.price || orderBook.lastTradePrice || orderBook.asks?.[0]?.price || 0;
      const refEntryPrice =
        bot.existingEntryPrice && bot.existingEntryPrice > 0
          ? bot.existingEntryPrice
          : marketBidPrice;

      const alloc = computeExistingBalanceAllocation({
        freeBase,
        percent: existingPct,
        referencePrice: refEntryPrice,
        minNotional,
        step: marketRules.amountStep,
        baseAsset: bot.baseAsset,
        quoteCurrency: bot.quoteCurrency,
      });

      if (alloc.ok) {
        const pos = promoteExistingBalanceToPosition(bot, alloc.allocatedQty, refEntryPrice, now);
        bot.botStatus = 'WAITING_FOR_PROFIT';
        bot.lastStatusReason = `ورود مستقیم با ${existingPct}٪ موجودی فعلی (${alloc.allocatedQty} ${
          bot.baseAsset
        } ≈ ${formatQuoteShort(
          pos.totalBuyCostQuote,
          bot.quoteCurrency
        )}) · نرخ مرجع: ${formatQuoteShort(refEntryPrice, bot.quoteCurrency)} · هدف فروش: ${formatQuoteShort(
          pos.lastRequiredSellPrice || 0,
          bot.quoteCurrency
        )}`;

        await appendProfitBotLog(userId, {
          botId: bot.id,
          cycleIndex: pos.cycleIndex,
          status: 'BUY_FILLED',
          event: 'BUY_FILLED',
          price: refEntryPrice,
          message: bot.lastStatusReason,
          timestamp: now,
        });
        void notifyProfitBotTelegram(userId, bot, 'ورود از موجودی فعلی ربات سود', bot.lastStatusReason);

        await evaluateActivePosition(bot, orderBook, runtime, true);
        return bot;
      }

      if (fundingMode === 'EXISTING_ASSET') {
        bot.isActive = false;
        bot.botStatus = 'NEEDS_USER_REVIEW';
        bot.lastStatusReason =
          alloc.reason ||
          `موجودی آزاد ${bot.baseAsset} برای ورود با ${existingPct}٪ کافی نیست یا کمتر از حداقل مجاز نوبیتکس است.`;
        await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
        await appendProfitBotLog(userId, {
          botId: bot.id,
          cycleIndex: bot.stats.completedCycles + 1,
          status: 'NEEDS_USER_REVIEW',
          event: 'NEEDS_REVIEW',
          price: marketBidPrice,
          message: bot.lastStatusReason,
          timestamp: now,
        });
        return bot;
      }
    }

    if (bot.stats.currentCapitalInvolved + bot.entryAmount > bot.maxCapitalInvolved + 1e-6) {
      bot.isActive = false;
      bot.botStatus = 'STOPPED';
      bot.lastStatusReason = `سرمایه درگیر فعلی اجازه ورود جدید تا سقف ${formatQuoteShort(
        bot.maxCapitalInvolved,
        bot.quoteCurrency
      )} را نمی‌دهد.`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    if (bot.entryAmount + 1e-6 < minNotional) {
      bot.isActive = false;
      bot.botStatus = 'NEEDS_USER_REVIEW';
      bot.lastStatusReason = `مبلغ ورود کمتر از حداقل مجاز سفارش در نوبیتکس (${formatQuoteShort(
        minNotional,
        bot.quoteCurrency
      )}) است.`;
      await persistProfitBotState(bot);
      return bot;
    }

    const buySim = simulateOrderBookBuy(orderBook, bot.entryAmount, bot.feeRate);
    if (buySim.bestAsk <= 0 || !buySim.canFillFull) {
      bot.lastStatusReason = `عمق فروش (Ask) در دفتر سفارش نوبیتکس برای خرید ${formatQuoteShort(
        bot.entryAmount,
        bot.quoteCurrency
      )} کافی نیست؛ در انتظار نقدینگی.`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    // Enforce pre-determined entry / re-entry price wait policy
    const isRepeatCycle = bot.stats.completedCycles > 0;
    const configuredReentryPrice =
      bot.reentryTargetPrice && bot.reentryTargetPrice > 0
        ? bot.reentryTargetPrice
        : bot.stats.lastBuyPrice && bot.stats.lastBuyPrice > 0
          ? bot.stats.lastBuyPrice
          : 0;
    const shouldWaitForEntryPrice = isRepeatCycle
      ? bot.reentryPolicy !== 'IMMEDIATE' && configuredReentryPrice > 0
      : Boolean(bot.waitEntryPriceOnFirstBuy && bot.reentryTargetPrice && bot.reentryTargetPrice > 0);
    const activeTargetEntryPrice = isRepeatCycle
      ? configuredReentryPrice
      : bot.reentryTargetPrice || 0;

    if (shouldWaitForEntryPrice && activeTargetEntryPrice > 0 && buySim.bestAsk > activeTargetEntryPrice) {
      bot.botStatus = 'CHECKING_MARKET';
      bot.lastStatusReason = `در انتظار رسیدن قیمت بازار به مبلغ ورود تعیین‌شده (${formatQuoteShort(
        activeTargetEntryPrice,
        bot.quoteCurrency
      )}) · قیمت لحظه‌ای خرید: ${formatQuoteShort(buySim.bestAsk, bot.quoteCurrency)}`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    if (buySim.spreadPercent > bot.maxSpreadPercent) {
      bot.lastStatusReason = `اختلاف قیمت خرید و فروش (${buySim.spreadPercent.toFixed(
        2
      )}٪) بیشتر از حد مجاز (${bot.maxSpreadPercent.toFixed(2)}٪) است؛ خرید به تعویق افتاد.`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    if (bot.orderType === 'MARKET' && buySim.slippagePercent > bot.maxSlippagePercent) {
      bot.lastStatusReason = `لغزش قیمت خرید بازار (${buySim.slippagePercent.toFixed(
        2
      )}٪) بیش از سقف مجاز (${bot.maxSlippagePercent.toFixed(2)}٪) است؛ منتظر تعادل دفتر سفارش.`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    // Balance verification before placing buy order
    const balances = cachedBalances || (await runtime.getBalances(userId, bot.mode));
    const quoteWallet = balances.find((b) => b.asset.toUpperCase() === bot.quoteCurrency);
    const freeQuote = quoteWallet?.free ?? 0;
    if (freeQuote + 1e-6 < bot.entryAmount) {
      bot.isActive = false;
      bot.botStatus = 'NEEDS_USER_REVIEW';
      bot.lastStatusReason = `موجودی آزاد ${
        bot.quoteCurrency === 'IRT' ? 'تومان' : 'تتر'
      } کافی نیست (نیاز: ${formatQuoteShort(
        bot.entryAmount,
        bot.quoteCurrency
      )}، موجود: ${formatQuoteShort(freeQuote, bot.quoteCurrency)}).`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      await appendProfitBotLog(userId, {
        botId: bot.id,
        cycleIndex: bot.stats.completedCycles + 1,
        status: 'NEEDS_USER_REVIEW',
        event: 'NEEDS_REVIEW',
        price: buySim.bestAsk,
        message: bot.lastStatusReason,
        timestamp: now,
      });
      return bot;
    }

    const cycleIndex = bot.stats.completedCycles + 1;
    const buyPrice = bot.orderType === 'LIMIT' ? buySim.bestAsk : buySim.avgBuyPrice;
    const maxCapitalHeadroom = Math.max(
      0,
      bot.maxCapitalInvolved - bot.stats.currentCapitalInvolved
    );
    const qtyRes = resolveOrderQuantityForNotional({
      entryAmount: bot.entryAmount,
      buyPrice,
      minNotional,
      step: marketRules.amountStep,
      freeQuote,
      maxCapitalHeadroom,
    });
    const quantity = qtyRes.quantity;
    if (!qtyRes.ok || quantity <= 0 || qtyRes.notional + 1e-6 < minNotional) {
      const minStepQty = roundQuantityToStep(
        minNotional / buyPrice,
        marketRules.amountStep,
        'ceil'
      );
      const minSteppedQuote = minStepQty * buyPrice;
      bot.isActive = false;
      bot.botStatus = 'NEEDS_USER_REVIEW';
      bot.lastStatusReason =
        minSteppedQuote > freeQuote + 1e-6
          ? `به دلیل گام اعشار بازار (${marketRules.amountStep} ${bot.baseAsset})، حداقل سفارش مجاز حدود ${formatQuoteShort(
              minSteppedQuote,
              bot.quoteCurrency
            )} است اما موجودی آزاد شما (${formatQuoteShort(freeQuote, bot.quoteCurrency)}) کافی نیست.`
          : `مقدار محاسبه‌شده خرید (${quantity} ${bot.baseAsset} ≈ ${formatQuoteShort(
              qtyRes.notional,
              bot.quoteCurrency
            )}) به دلیل گام اعشار بازار (${marketRules.amountStep}) کمتر از حداقل مجاز نوبیتکس (${formatQuoteShort(
              minNotional,
              bot.quoteCurrency
            )}) است؛ مبلغ ورود را حداقل به ${formatQuoteShort(
              minSteppedQuote,
              bot.quoteCurrency
            )} افزایش دهید.`;
      await persistProfitBotState(bot);
      return bot;
    }

    const smartMgr = await import('./smartBotManager.ts');
    const guard = await smartMgr.validateSharedExecutionGuards({
      userId,
      botId: bot.id,
      botType: 'PROFIT',
      symbol: bot.symbol,
      quoteCurrency: bot.quoteCurrency,
      side: 'BUY',
      requestedQuoteAmount: bot.entryAmount,
    });
    if (!guard.ok) {
      bot.lastStatusReason = guard.reasonFa;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
      await smartMgr.createPendingConfirmation({
        userId,
        botId: bot.id,
        botType: 'PROFIT',
        botName: bot.name,
        symbol: bot.symbol,
        baseAsset: bot.baseAsset,
        quoteCurrency: bot.quoteCurrency,
        mode: bot.mode,
        side: 'BUY',
        orderType: bot.orderType,
        suggestedPrice: buyPrice,
        quantity,
        quoteAmount: quantity * buyPrice,
        estimatedFeeQuote: quantity * buyPrice * bot.feeRate,
        reasonFa: `شرایط خرید ربات سود مهیاست (${quantity.toFixed(6)} ${bot.baseAsset} با قیمت ${formatQuoteShort(buyPrice, bot.quoteCurrency)})`,
        riskSummaryFa: `سود خالص هدف: +${formatQuoteShort(bot.targetNetProfit, bot.quoteCurrency)} · حداکثر سرمایه درگیر: ${formatQuoteShort(bot.entryAmount, bot.quoteCurrency)}`,
        metaJson: { cycleIndex, feeRate: bot.feeRate },
      });
      bot.lastStatusReason = `در انتظار تأیید دستی شما برای خرید در قیمت ${formatQuoteShort(
        buyPrice,
        bot.quoteCurrency
      )}.`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return bot;
    }

    const idempotencyKey = `pbot:${bot.id}:c${cycleIndex}:BUY`;
    bot.botStatus = 'PLACING_BUY';
    bot.lastStatusReason = `شرایط خرید تایید شد · ثبت سفارش ${
      bot.orderType === 'LIMIT' ? 'لیمیت' : 'بازار'
    } در ${formatQuoteShort(buyPrice, bot.quoteCurrency)}...`;
    await persistProfitBotState(bot);

    const buyOrder = await runtime.placeOrder(userId, bot, {
      side: 'BUY',
      type: bot.orderType,
      quantity,
      price: buyPrice,
      idempotencyKey,
    });

    await appendProfitBotLog(userId, {
      botId: bot.id,
      cycleIndex,
      status: buyOrder.status === 'FILLED' ? 'BUY_FILLED' : 'PLACING_BUY',
      event: 'BUY_PLACED',
      price: buyOrder.price || buyPrice,
      message: `سفارش خرید ثبت شد (${buyOrder.type}) · مقدار: ${quantity.toFixed(
        6
      )} ${bot.baseAsset} · قیمت: ${formatQuoteShort(buyOrder.price || buyPrice, bot.quoteCurrency)}`,
      timestamp: now,
    });

    if (buyOrder.status === 'FILLED') {
      const pos = promoteBuyExecutionToPosition(bot, buyOrder, false, now);
      bot.botStatus = 'BUY_FILLED';
      bot.lastStatusReason = `خرید تکمیل شد · میانگین: ${formatQuoteShort(
        pos.actualBuyAvgPrice,
        bot.quoteCurrency
      )} · قیمت فروش هدف: ${formatQuoteShort(pos.lastRequiredSellPrice || 0, bot.quoteCurrency)}`;

      await appendProfitBotLog(userId, {
        botId: bot.id,
        cycleIndex: pos.cycleIndex,
        status: 'BUY_FILLED',
        event: 'BUY_FILLED',
        price: pos.actualBuyAvgPrice,
        message: bot.lastStatusReason,
        timestamp: now,
      });
      void notifyProfitBotTelegram(userId, bot, 'خرید ربات سود تکمیل شد', bot.lastStatusReason);

      // Immediately move to monitoring phase with live metrics populated
      await evaluateActivePosition(bot, orderBook, runtime, true);
      return bot;
    }

    bot.pendingOrder = {
      orderId: buyOrder.orderId,
      exchangeOrderId: bot.mode === 'live' ? buyOrder.orderId : undefined,
      side: 'BUY',
      type: buyOrder.type,
      price: buyOrder.price || buyPrice,
      requestedQty: buyOrder.quantity,
      executedQty: buyOrder.executedQty || 0,
      totalQuoteAmount: buyOrder.totalQuoteAmount || quantity * buyPrice,
      cycleIndex,
      placedAt: now,
      lastCheckedAt: now,
    };
    bot.botStatus = buyOrder.executedQty > 0 ? 'PARTIAL_ORDER' : 'PLACING_BUY';
    bot.lastStatusReason =
      buyOrder.executedQty > 0
        ? `بخشی از سفارش خرید انجام شد (${buyOrder.executedQty.toFixed(6)}) و باقی‌مانده باز است.`
        : `سفارش خرید لیمیت در قیمت ${formatQuoteShort(
            buyPrice,
            bot.quoteCurrency
          )} ثبت شد و منتظر تکمیل است.`;
    await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
    return bot;
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'خطای نامشخص در ارتباط با صرافی نوبیتکس';
    const isAuthErr = err instanceof NobitexAuthError;

    const rows = await db
      .select({ consecutiveFailures: schema.profitBots.consecutiveFailures })
      .from(schema.profitBots)
      .where(eq(schema.profitBots.id, bot.id))
      .limit(1);
    const nextFailures = (rows[0]?.consecutiveFailures ?? 0) + 1;
    const backoffMs = Math.min(300_000, 10_000 * Math.pow(2, nextFailures - 1));

    bot.lastCheckedAt = now;
    bot.lastError = msg;
    if (isAuthErr) {
      bot.isActive = false;
      bot.botStatus = 'NEEDS_USER_REVIEW';
      bot.lastStatusReason = `خطای احراز هویت نوبیتکس: ${msg}`;
    } else {
      bot.botStatus = 'CONNECTION_ERROR';
      bot.lastStatusReason = `اختلال اتصال (${msg}) · بدون ثبت سفارش تکراری، تلاش مجدد خودکار زمان‌بندی شد.`;
    }

    await persistProfitBotState(bot, {
      consecutiveFailures: nextFailures,
      nextRetryAt: isAuthErr ? null : now + backoffMs,
    });

    await appendProfitBotLog(userId, {
      botId: bot.id,
      cycleIndex: bot.activePosition?.cycleIndex || bot.stats.completedCycles + 1,
      status: bot.botStatus,
      event: isAuthErr ? 'NEEDS_REVIEW' : 'ERROR',
      price: 0,
      message: msg,
      timestamp: now,
    });
    return bot;
  }
}

async function evaluateActivePosition(
  bot: ProfitBotConfig,
  orderBook: OrderBookSnapshot,
  runtime: ProfitBotRuntimeDeps,
  justBought: boolean
): Promise<void> {
  const userId = bot.ownerId || '';
  const now = runtime.now();
  const pos = bot.activePosition;
  if (!pos) return;

  const sellSim = simulateOrderBookSell(
    orderBook,
    pos.netOwnedQty,
    pos.totalBuyCostQuote,
    bot.targetNetProfit,
    bot.feeRate,
    pos.otherFeesQuote ?? bot.otherFeesQuote,
    bot.targetSellPrice
  );

  pos.lastExecutableSellPrice = sellSim.executableAvgSellPrice;
  pos.lastExecutableProceedsQuote = sellSim.grossProceedsQuote;
  pos.lastEstimatedSellFeeQuote = sellSim.sellFeeQuote;
  pos.lastEstimatedNetProfitQuote = sellSim.netProfitQuote;
  pos.lastHasSufficientDepth = sellSim.hasSufficientDepth;
  pos.lastSpreadPercent = sellSim.spreadPercent;
  pos.lastSlippagePercent = sellSim.slippagePercent;
  pos.lastRequiredSellPrice = sellSim.requiredSellPrice;
  pos.lastProgressPercent = computeProfitProgressPercent(sellSim.netProfitQuote, bot.targetNetProfit);
  pos.lastEvaluatedAt = now;

  // 1) Check Max Wait Time expiration -> NEEDS_USER_REVIEW
  if (
    !justBought &&
    bot.maxWaitMinutes &&
    bot.maxWaitMinutes > 0 &&
    now - pos.buyFilledAt >= bot.maxWaitMinutes * 60_000
  ) {
    bot.isActive = false;
    bot.botStatus = 'NEEDS_USER_REVIEW';
    bot.lastStatusReason = `حداکثر زمان انتظار (${bot.maxWaitMinutes} دقیقه) به پایان رسید و سود هدف محقق نشد؛ نیازمند بررسی کاربر.`;
    await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
    await appendProfitBotLog(userId, {
      botId: bot.id,
      cycleIndex: pos.cycleIndex,
      status: 'NEEDS_USER_REVIEW',
      event: 'NEEDS_REVIEW',
      price: sellSim.bestBid,
      netProfitQuote: sellSim.netProfitQuote,
      message: bot.lastStatusReason,
      timestamp: now,
    });
    void notifyProfitBotTelegram(userId, bot, 'نیازمند بررسی کاربر (اتمام زمان)', bot.lastStatusReason);
    return;
  }

  // 2) Check Optional Stop-Loss
  if (!justBought && bot.stopLossEnabled && bot.stopLossPercent > 0 && sellSim.bestBid > 0) {
    const slPrice = pos.actualBuyAvgPrice * (1 - bot.stopLossPercent / 100);
    if (sellSim.bestBid <= slPrice) {
      if (bot.stopLossAction === 'STOP_ONLY') {
        bot.isActive = false;
        bot.botStatus = 'STOPPED';
        bot.lastStatusReason = `حد ضرر (-${bot.stopLossPercent}٪) لمس شد؛ طبق تنظیمات، ربات متوقف و دارایی حفظ گردید.`;
        await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
        await appendProfitBotLog(userId, {
          botId: bot.id,
          cycleIndex: pos.cycleIndex,
          status: 'STOPPED',
          event: 'STOP_LOSS',
          price: sellSim.bestBid,
          netProfitQuote: sellSim.netProfitQuote,
          message: bot.lastStatusReason,
          timestamp: now,
        });
        void notifyProfitBotTelegram(userId, bot, 'توقف با حد ضرر', bot.lastStatusReason);
        return;
      }

      // STOP_AND_SELL: guard against completely empty/flash-crash orderbook
      if (!sellSim.hasSufficientDepth || sellSim.slippagePercent > Math.max(bot.maxSlippagePercent * 4, 8)) {
        bot.isActive = false;
        bot.botStatus = 'NEEDS_USER_REVIEW';
        bot.lastStatusReason =
          'حد ضرر لمس شد اما عمق خرید دفتر سفارش بسیار کم یا لغزش شدید است؛ فروش برای حفاظت از سرمایه به تایید کاربر موکول شد.';
        await persistProfitBotState(bot);
        await appendProfitBotLog(userId, {
          botId: bot.id,
          cycleIndex: pos.cycleIndex,
          status: 'NEEDS_USER_REVIEW',
          event: 'NEEDS_REVIEW',
          price: sellSim.bestBid,
          netProfitQuote: sellSim.netProfitQuote,
          message: bot.lastStatusReason,
          timestamp: now,
        });
        return;
      }

      await executeProfitBotSellOrder(bot, pos, sellSim.executableAvgSellPrice, 'STOP_LOSS', runtime, now);
      return;
    }
  }

  // 3) Check Phase 3: Profit Target Reached with REAL Depth & Slippage & Spread verification
  if (sellSim.canTriggerTarget) {
    if (sellSim.spreadPercent > bot.maxSpreadPercent) {
      bot.botStatus = 'WAITING_FOR_PROFIT';
      bot.lastStatusReason = `سود به هدف رسید اما اسپرد بازار (${sellSim.spreadPercent.toFixed(
        2
      )}٪) بیش از حد مجاز (${bot.maxSpreadPercent.toFixed(2)}٪) است؛ منتظر ثبات قیمت.`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return;
    }

    if (bot.orderType === 'MARKET' && sellSim.slippagePercent > bot.maxSlippagePercent) {
      bot.botStatus = 'WAITING_FOR_PROFIT';
      bot.lastStatusReason = `سود به هدف رسید اما لغزش فروش (${sellSim.slippagePercent.toFixed(
        2
      )}٪) بیش از سقف مجاز (${bot.maxSlippagePercent.toFixed(2)}٪) است.`;
      await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
      return;
    }

    bot.botStatus = 'PROFIT_TARGET_REACHED';
    await appendProfitBotLog(userId, {
      botId: bot.id,
      cycleIndex: pos.cycleIndex,
      status: 'PROFIT_TARGET_REACHED',
      event: 'TARGET_REACHED',
      price: sellSim.executableAvgSellPrice,
      netProfitQuote: sellSim.netProfitQuote,
      message:
        bot.targetSellPrice && bot.targetSellPrice > 0
          ? `قیمت به هدف فروش (${formatQuoteShort(
              bot.targetSellPrice,
              bot.quoteCurrency
            )}) رسید · فروش فوری در ${formatQuoteShort(
              sellSim.executableAvgSellPrice,
              bot.quoteCurrency
            )} (سود خالص: ${sellSim.netProfitQuote >= 0 ? '+' : ''}${formatQuoteShort(
              sellSim.netProfitQuote,
              bot.quoteCurrency
            )})`
          : `هدف سود خالص محقق شد (+${formatQuoteShort(
              sellSim.netProfitQuote,
              bot.quoteCurrency
            )}) · فروش فوری در ${formatQuoteShort(
              sellSim.executableAvgSellPrice,
              bot.quoteCurrency
            )}`,
      timestamp: now,
    });

    const sellOrderPrice =
      bot.orderType === 'LIMIT' ? sellSim.bestBid : sellSim.executableAvgSellPrice;
    await executeProfitBotSellOrder(bot, pos, sellOrderPrice, 'TARGET_PROFIT', runtime, now);
    return;
  }

  // Still Waiting for Profit Target
  bot.botStatus = 'WAITING_FOR_PROFIT';
  if (!sellSim.hasSufficientDepth) {
    bot.lastStatusReason =
      'عمق دفتر سفارش (Bids) برای فروش کامل مقدار خریداری‌شده کافی نیست؛ تا تکمیل نقدینگی هدف سود فعال نمی‌شود.';
  } else if (bot.targetSellPrice && bot.targetSellPrice > 0) {
    const priceGap = Math.max(0, bot.targetSellPrice - sellSim.executableAvgSellPrice);
    bot.lastStatusReason = `در انتظار رسیدن قیمت به ${formatQuoteShort(
      bot.targetSellPrice,
      bot.quoteCurrency
    )} (فاصله: ${formatQuoteShort(priceGap, bot.quoteCurrency)}) · سود لحظه‌ای: ${
      sellSim.netProfitQuote >= 0 ? '+' : ''
    }${formatQuoteShort(sellSim.netProfitQuote, bot.quoteCurrency)}`;
  } else {
    const remaining = Math.max(0, bot.targetNetProfit - sellSim.netProfitQuote);
    bot.lastStatusReason = `در انتظار سود خالص هدف · سود لحظه‌ای پس از کارمزد: ${
      sellSim.netProfitQuote >= 0 ? '+' : ''
    }${formatQuoteShort(sellSim.netProfitQuote, bot.quoteCurrency)} (فاصله تا هدف: ${formatQuoteShort(
      remaining,
      bot.quoteCurrency
    )})`;
  }

  await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
}

async function executeProfitBotSellOrder(
  bot: ProfitBotConfig,
  pos: ProfitBotPosition,
  sellPrice: number,
  exitReason: ProfitBotCycleRecord['exitReason'],
  runtime: ProfitBotRuntimeDeps,
  now: number
): Promise<void> {
  const userId = bot.ownerId || '';
  const marketRules = await getNobitexMarketRules(bot.symbol).catch(() => ({
    minNotional: getMinimumOrderNotional(bot.quoteCurrency),
    amountStep: 1e-6,
  }));
  const minNotional = marketRules.minNotional;

  // Re-verify base balance before sending sell order
  const balances = await runtime.getBalances(userId, bot.mode);
  const baseWallet = balances.find((b) => b.asset.toUpperCase() === bot.baseAsset);
  const freeBase = baseWallet?.free ?? 0;
  const sellQty = roundQuantityToStep(
    Math.min(pos.netOwnedQty, freeBase),
    marketRules.amountStep,
    'floor'
  );

  if (sellQty <= 0 || sellQty * sellPrice + 1e-6 < minNotional) {
    bot.isActive = false;
    bot.botStatus = 'NEEDS_USER_REVIEW';
    bot.lastStatusReason = `موجودی آزاد ${bot.baseAsset} برای فروش (${freeBase.toFixed(
      6
    )}) کافی نیست یا کمتر از حداقل مجاز سفارش نوبیتکس است.`;
    await persistProfitBotState(bot);
    await appendProfitBotLog(userId, {
      botId: bot.id,
      cycleIndex: pos.cycleIndex,
      status: 'NEEDS_USER_REVIEW',
      event: 'NEEDS_REVIEW',
      price: sellPrice,
      message: bot.lastStatusReason,
      timestamp: now,
    });
    return;
  }

  const estProceeds = sellQty * sellPrice;
  const estSellFee = estProceeds * bot.feeRate;
  const estNetPnl = roundQuoteValue(
    estProceeds - pos.totalBuyCostQuote - estSellFee - (pos.otherFeesQuote ?? bot.otherFeesQuote),
    bot.quoteCurrency
  );

  if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
    const smartMgr = await import('./smartBotManager.ts');
    await smartMgr.createPendingConfirmation({
      userId,
      botId: bot.id,
      botType: 'PROFIT',
      botName: bot.name,
      symbol: bot.symbol,
      baseAsset: bot.baseAsset,
      quoteCurrency: bot.quoteCurrency,
      mode: bot.mode,
      side: 'SELL',
      orderType: bot.orderType,
      suggestedPrice: sellPrice,
      quantity: sellQty,
      quoteAmount: estProceeds,
      estimatedFeeQuote: estSellFee,
      reasonFa: `هدف سود ربات محقق شد (${exitReason}) · فروش ${sellQty.toFixed(6)} ${bot.baseAsset}`,
      riskSummaryFa: `سود خالص تخمینی پس از کارمزد: ${estNetPnl >= 0 ? '+' : ''}${formatQuoteShort(estNetPnl, bot.quoteCurrency)}`,
      metaJson: { cycleIndex: pos.cycleIndex, exitReason },
    });
    bot.lastStatusReason = `هدف فروش رسید · منتظر تأیید دستی شما برای ثبت سفارش فروش.`;
    await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
    return;
  }

  const idempotencyKey = `pbot:${bot.id}:c${pos.cycleIndex}:SELL`;
  bot.botStatus = 'PLACING_SELL';
  await persistProfitBotState(bot);

  const sellOrder = await runtime.placeOrder(userId, bot, {
    side: 'SELL',
    type: bot.orderType,
    quantity: sellQty,
    price: sellPrice,
    idempotencyKey,
    realizedPnlQuote: estNetPnl,
  });

  await appendProfitBotLog(userId, {
    botId: bot.id,
    cycleIndex: pos.cycleIndex,
    status: sellOrder.status === 'FILLED' ? 'SELL_FILLED' : 'PLACING_SELL',
    event: 'SELL_PLACED',
    price: sellOrder.price || sellPrice,
    netProfitQuote: estNetPnl,
    message: `سفارش فروش ثبت شد (${sellOrder.type}) · مقدار: ${sellQty.toFixed(
      6
    )} ${bot.baseAsset} · قیمت: ${formatQuoteShort(sellOrder.price || sellPrice, bot.quoteCurrency)}`,
    timestamp: now,
  });

  if (sellOrder.status === 'FILLED') {
    await finalizeSellPositionAndCycle(bot, pos, sellOrder, exitReason, now);
    await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
    return;
  }

  bot.pendingOrder = {
    orderId: sellOrder.orderId,
    exchangeOrderId: bot.mode === 'live' ? sellOrder.orderId : undefined,
    side: 'SELL',
    type: sellOrder.type,
    price: sellOrder.price || sellPrice,
    requestedQty: sellOrder.quantity,
    executedQty: sellOrder.executedQty || 0,
    totalQuoteAmount: sellOrder.totalQuoteAmount || sellQty * sellPrice,
    cycleIndex: pos.cycleIndex,
    placedAt: now,
    lastCheckedAt: now,
  };
  bot.botStatus = sellOrder.executedQty > 0 ? 'PARTIAL_ORDER' : 'PLACING_SELL';
  bot.lastStatusReason = `سفارش فروش لیمیت در قیمت ${formatQuoteShort(
    sellPrice,
    bot.quoteCurrency
  )} ثبت شد و منتظر تکمیل است.`;
  await persistProfitBotState(bot, { consecutiveFailures: 0, nextRetryAt: null });
}

export async function manualSellProfitBotPosition(
  userId: string,
  botId: string,
  deps?: Partial<ProfitBotRuntimeDeps>
): Promise<ProfitBotConfig> {
  const bot = await getUserProfitBotById(userId, botId);
  if (!bot) throw new Error('ربات سود مورد نظر یافت نشد.');
  if (!bot.activePosition) {
    throw new Error('این ربات در حال حاضر پوزیشن خریداری‌شده بازی برای فروش ندارد.');
  }
  if (bot.pendingOrder) {
    throw new Error('ابتدا سفارش باز فعلی باید تعیین تکلیف شود.');
  }
  const runtime = { ...createDefaultRuntimeDeps(), ...(deps || {}) };
  const orderBook = await runtime.fetchOrderBook(bot.symbol, 40);
  const sellSim = simulateOrderBookSell(
    orderBook,
    bot.activePosition.netOwnedQty,
    bot.activePosition.totalBuyCostQuote,
    bot.targetNetProfit,
    bot.feeRate,
    bot.otherFeesQuote
  );
  if (sellSim.bestBid <= 0 || !sellSim.hasSufficientDepth) {
    throw new Error('عمق خرید دفتر سفارش برای فروش دستی کامل کافی نیست.');
  }
  const price = bot.orderType === 'LIMIT' ? sellSim.bestBid : sellSim.executableAvgSellPrice;
  await executeProfitBotSellOrder(bot, bot.activePosition, price, 'MANUAL_SELL', runtime, runtime.now());
  return bot;
}

// ===========================================================================
// Scheduler Helper (Called by Background Worker & Server Loop)
// ===========================================================================
export async function countActiveProfitBots(): Promise<number> {
  const db = getDb();
  const rows = await db
    .select({ id: schema.profitBots.id })
    .from(schema.profitBots)
    .where(eq(schema.profitBots.isActive, true));
  return rows.length;
}

export async function runAllActiveProfitBotsCycle(options?: {
  respectSchedule?: boolean;
  ownerOverride?: string;
}): Promise<{ evaluated: number }> {
  if (isEvaluatingProfitBotsLocally) return { evaluated: 0 };

  const db = getDb();
  const rows = await db
    .select()
    .from(schema.profitBots)
    .where(eq(schema.profitBots.isActive, true));
  if (rows.length === 0) return { evaluated: 0 };

  const now = Date.now();
  const respectSchedule = Boolean(options?.respectSchedule);
  const dueBots: ProfitBotConfig[] = [];

  for (const row of rows) {
    if (row.nextRetryAt && row.nextRetryAt > now) continue;
    const mapped = mapProfitBotRow(row);
    if (respectSchedule && mapped.lastCheckedAt) {
      const intervalMs = Math.max(2_000, (mapped.pollIntervalSeconds || 10) * 1000);
      if (now - mapped.lastCheckedAt < intervalMs - 250) {
        continue;
      }
    }
    dueBots.push(mapped);
  }

  if (dueBots.length === 0) return { evaluated: 0 };

  const lockOwner = options?.ownerOverride || PROFIT_BOT_WORKER_ID;
  const acquired = await acquireWorkerLock(PROFIT_BOT_LOCK_NAME, lockOwner, 30_000);
  if (!acquired) return { evaluated: 0 };

  isEvaluatingProfitBotsLocally = true;
  let evaluated = 0;
  try {
    for (const bot of dueBots) {
      await evaluateProfitBot(bot);
      evaluated += 1;
    }
    return { evaluated };
  } finally {
    isEvaluatingProfitBotsLocally = false;
    await releaseWorkerLock(PROFIT_BOT_LOCK_NAME, lockOwner);
  }
}
