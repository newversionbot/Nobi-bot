import crypto from 'node:crypto';
import type {
  BotExecutionLog,
  BotStrategyConfig,
  PriceAlert,
  PricePulseNotification,
  QuoteCurrency,
  SpotBalance,
  SpotOrder,
  TelegramDiscoveredChat,
  TelegramManualReportKind,
  TelegramSentLogEntry,
  UnifiedMarketTicker,
} from '../src/types/trading.ts';
import {
  getActiveTelegramCredentials,
  recordBotMonitorSent,
  recordTelegramDeliveryResult,
} from './securityVault.ts';
import { getLastKnownUsdtTomanRate } from './nobitexClient.ts';
import { logger, redactSensitiveText } from './logger.ts';

export type TelegramFetchLike = typeof fetch;
let activeTelegramFetch: TelegramFetchLike = globalThis.fetch;

export function setTelegramFetchForTest(customFetch: TelegramFetchLike | null): void {
  if (process.env.NODE_ENV === 'production' && customFetch) {
    throw new Error('Cannot override Telegram fetch in production.');
  }
  activeTelegramFetch = customFetch || globalThis.fetch;
  recentDedupeMap.clear();
}

const recentDedupeMap = new Map<string, number>();

export function clearTelegramDedupeForTest(): void {
  recentDedupeMap.clear();
}

interface TelegramApiResponse<T> {
  ok: boolean;
  result?: T;
  description?: string;
  error_code?: number;
  parameters?: {
    retry_after?: number;
  };
}

interface TelegramGetMeResult {
  id: number;
  is_bot: boolean;
  first_name: string;
  username?: string;
}

interface TelegramChat {
  id: number;
  type: string;
  title?: string;
  username?: string;
  first_name?: string;
  last_name?: string;
}

interface TelegramUpdate {
  update_id: number;
  message?: {
    chat?: TelegramChat;
  };
  channel_post?: {
    chat?: TelegramChat;
  };
}

function escapeHtml(raw: string): string {
  return String(raw || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

function formatTehranTime(ts: number): string {
  try {
    return new Date(ts).toLocaleString('fa-IR', {
      timeZone: 'Asia/Tehran',
      month: '2-digit',
      day: '2-digit',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
    });
  } catch {
    return new Date(ts).toISOString();
  }
}

function formatQuoteValue(value: number, quoteCurrency: QuoteCurrency): string {
  if (quoteCurrency === 'IRT') {
    return `${Math.round(value).toLocaleString('en-US')} تومان`;
  }
  return `$${value.toLocaleString('en-US', {
    minimumFractionDigits: value < 1 ? 4 : 2,
    maximumFractionDigits: value < 1 ? 6 : 2,
  })} USDT`;
}

export interface BotRealizedPnlMetrics {
  realizedPnlQuote: number;
  realizedPnlToman: number;
  realizedPnlUsdt: number;
  realizedPnlPercent: number;
  tomanText: string;
  usdtText: string;
  percentText: string;
  dualCurrencyText: string;
  formattedMessageText: string;
}

function formatSignedToman(val: number): string {
  const rounded = Math.round(val);
  if (rounded === 0) return '0 تومان';
  const sign = rounded > 0 ? '+' : '-';
  return `${sign}${Math.abs(rounded).toLocaleString('en-US')} تومان`;
}

function formatSignedUsdt(val: number): string {
  const abs = Math.abs(val);
  if (abs < 0.0001) return '$0.00 تتر';
  const decimals = abs < 1 ? 4 : 2;
  const sign = val >= 0 ? '+' : '-';
  return `${sign}$${abs.toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  })} تتر`;
}

function formatSignedPercent(pct: number): string {
  if (!Number.isFinite(pct) || Math.abs(pct) < 0.0001) return '0.00%';
  const sign = pct > 0 ? '+' : '';
  return `${sign}${pct.toFixed(2)}%`;
}

export function calculateBotRealizedPnlMetrics(
  bot: Pick<BotStrategyConfig, 'quoteCurrency' | 'orderAmount' | 'stats'>,
  usdtTomanRate?: number,
  overrideQuotePnl?: number
): BotRealizedPnlMetrics {
  const rate =
    usdtTomanRate && usdtTomanRate > 0 ? usdtTomanRate : getLastKnownUsdtTomanRate();
  const realizedPnlQuote =
    typeof overrideQuotePnl === 'number'
      ? overrideQuotePnl
      : Number(bot.stats?.realizedPnl || 0);
  const capitalBase = Math.max(0, Number(bot.orderAmount || 0));
  const realizedPnlPercent = capitalBase > 0 ? (realizedPnlQuote / capitalBase) * 100 : 0;

  let realizedPnlToman = 0;
  let realizedPnlUsdt = 0;

  if (bot.quoteCurrency === 'IRT') {
    realizedPnlToman = realizedPnlQuote;
    realizedPnlUsdt = rate > 0 ? realizedPnlQuote / rate : 0;
  } else {
    realizedPnlUsdt = realizedPnlQuote;
    realizedPnlToman = rate > 0 ? realizedPnlQuote * rate : 0;
  }

  const tomanText = formatSignedToman(realizedPnlToman);
  const usdtText = formatSignedUsdt(realizedPnlUsdt);
  const percentText = formatSignedPercent(realizedPnlPercent);

  const dualCurrencyText =
    rate > 0
      ? bot.quoteCurrency === 'IRT'
        ? `${tomanText} (${usdtText})`
        : `${usdtText} (${tomanText})`
      : bot.quoteCurrency === 'IRT'
        ? tomanText
        : usdtText;

  return {
    realizedPnlQuote,
    realizedPnlToman,
    realizedPnlUsdt,
    realizedPnlPercent,
    tomanText,
    usdtText,
    percentText,
    dualCurrencyText,
    formattedMessageText: `${dualCurrencyText} · ${percentText}`,
  };
}

function translateTelegramError(desc?: string): string {
  const msg = redactSensitiveText(String(desc || '').trim());
  const lower = msg.toLowerCase();
  if (lower.includes('unauthorized')) {
    return 'توکن ربات تلگرام نامعتبر است. لطفاً توکن دریافتی از @BotFather را دقیق بررسی کنید.';
  }
  if (lower.includes('chat not found')) {
    return 'چت یافت نشد. ابتدا در تلگرام وارد ربات خود شوید و دکمه Start (/start) را بزنید یا Chat ID را بررسی کنید.';
  }
  if (lower.includes('bot was blocked by the user')) {
    return 'ربات توسط کاربر در تلگرام مسدود (Block) شده است. لطفاً در تلگرام ربات را Unblock کنید.';
  }
  if (lower.includes('need administrator rights') || lower.includes('not enough rights')) {
    return 'ربات برای ارسال پیام در کانال/گروه نیاز به دسترسی ادمین دارد.';
  }
  return msg || 'خطا در ارتباط با سرور تلگرام';
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function makeDedupeKey(chatId: string, htmlText: string): string {
  // Normalize timestamp line out so identical repeated monitor/alert events dedupe cleanly
  const normalized = htmlText.replace(/🕒 زمان: <code>[^<]+<\/code>/g, '');
  return crypto.createHash('sha256').update(`${chatId}::${normalized}`).digest('hex');
}

function pruneDedupeMap(now: number): void {
  if (recentDedupeMap.size < 200) return;
  for (const [key, exp] of recentDedupeMap.entries()) {
    if (exp <= now) recentDedupeMap.delete(key);
  }
}

export async function verifyTelegramBotToken(botToken: string): Promise<{
  id: number;
  username: string;
  firstName: string;
}> {
  const clean = botToken.trim();
  if (!clean || !clean.includes(':')) {
    throw new Error('فرمت توکن ربات تلگرام صحیح نیست (مثال: 123456789:ABCdef...).');
  }

  const res = await activeTelegramFetch(`https://api.telegram.org/bot${clean}/getMe`, {
    method: 'GET',
    signal: AbortSignal.timeout(8000),
  });
  const data = (await res.json()) as TelegramApiResponse<TelegramGetMeResult>;
  if (!res.ok || !data.ok || !data.result) {
    throw new Error(translateTelegramError(data.description));
  }
  return {
    id: data.result.id,
    username: data.result.username || '',
    firstName: data.result.first_name || 'AI NobiBot',
  };
}

export async function detectTelegramChats(botToken: string): Promise<TelegramDiscoveredChat[]> {
  const clean = botToken.trim();
  const res = await activeTelegramFetch(
    `https://api.telegram.org/bot${clean}/getUpdates?limit=25&allowed_updates=${encodeURIComponent(
      JSON.stringify(['message', 'channel_post'])
    )}`,
    {
      method: 'GET',
      signal: AbortSignal.timeout(8000),
    }
  );
  const data = (await res.json()) as TelegramApiResponse<TelegramUpdate[]>;
  if (!res.ok || !data.ok) {
    throw new Error(translateTelegramError(data.description));
  }

  const seen = new Map<string, TelegramDiscoveredChat>();
  for (const upd of data.result || []) {
    const chat = upd.message?.chat || upd.channel_post?.chat;
    if (!chat) continue;
    const chatId = String(chat.id);
    const fullName = [chat.first_name, chat.last_name].filter(Boolean).join(' ').trim();
    const title = chat.title || fullName || (chat.username ? `@${chat.username}` : chatId);
    seen.set(chatId, {
      chatId,
      title,
      username: chat.username,
      type: chat.type,
    });
  }

  return Array.from(seen.values()).reverse();
}

export async function sendTelegramHtmlMessage(
  botToken: string,
  chatId: string,
  htmlText: string,
  options?: { dedupeWindowMs?: number; skipDedupe?: boolean }
): Promise<{ sent: boolean; deduped?: boolean }> {
  const cleanToken = botToken.trim();
  const cleanChat = chatId.trim();
  const dedupeMs = options?.skipDedupe ? 0 : options?.dedupeWindowMs ?? 20_000;

  if (dedupeMs > 0) {
    const now = Date.now();
    pruneDedupeMap(now);
    const key = makeDedupeKey(cleanChat, htmlText);
    const exp = recentDedupeMap.get(key);
    if (exp && exp > now) {
      return { sent: false, deduped: true };
    }
    recentDedupeMap.set(key, now + dedupeMs);
  }

  const maxAttempts = 3;
  let lastError = 'خطا در ارتباط با سرور تلگرام';

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      const res = await activeTelegramFetch(`https://api.telegram.org/bot${cleanToken}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          chat_id: cleanChat,
          text: htmlText,
          parse_mode: 'HTML',
          disable_web_page_preview: true,
        }),
        signal: AbortSignal.timeout(8000),
      });

      const data = (await res.json()) as TelegramApiResponse<unknown>;
      if (res.ok && data.ok) {
        return { sent: true };
      }

      if (res.status === 429 || res.status >= 500) {
        const retryAfterSec = Number(data?.parameters?.retry_after || 0);
        const backoffMs =
          retryAfterSec > 0
            ? Math.min(3000, retryAfterSec * 1000)
            : Math.min(2000, 150 * Math.pow(2, attempt - 1));
        lastError = translateTelegramError(data.description || `HTTP ${res.status}`);
        if (attempt < maxAttempts) {
          logger.warn('telegram.retry', { attempt, status: res.status, backoffMs });
          await sleep(backoffMs);
          continue;
        }
      } else {
        throw new Error(translateTelegramError(data.description));
      }
    } catch (err) {
      const msg = redactSensitiveText(err instanceof Error ? err.message : String(err));
      lastError = msg;
      if (attempt < maxAttempts && !msg.includes('نامعتبر است') && !msg.includes('چت یافت نشد')) {
        await sleep(Math.min(1500, 150 * Math.pow(2, attempt - 1)));
        continue;
      }
      throw new Error(msg);
    }
  }

  throw new Error(lastError);
}

export async function sendTelegramTestMessage(
  userId: string,
  overrideBotToken?: string,
  overrideChatId?: string
): Promise<{ sentAt: number }> {
  let token = overrideBotToken?.trim();
  let chatId = overrideChatId?.trim();

  if (!token || !chatId) {
    const creds = await getActiveTelegramCredentials(userId, false);
    if (!token) token = creds?.botToken;
    if (!chatId) chatId = creds?.chatId;
  }

  if (!token || !chatId) {
    throw new Error('برای ارسال پیام تست، توکن ربات و Chat ID الزامی است.');
  }

  const now = Date.now();
  const message = [
    '✅ <b>اتصال ربات تلگرام با موفقیت برقرار شد</b>',
    '',
    '🤖 پلتفرم معاملاتی <b>AI NobiBot</b> (ainobibot.ir)',
    '🔔 از این پس هشدارهای رسیدن قیمت به هدف و گزارش‌های اختصاصی حساب شما مستقیماً به این گفتگو ارسال می‌شوند.',
    `🕒 زمان تست: <code>${escapeHtml(formatTehranTime(now))}</code>`,
  ].join('\n');

  try {
    await sendTelegramHtmlMessage(token, chatId, message, { skipDedupe: true });
    if (!overrideBotToken && !overrideChatId) {
      await recordTelegramDeliveryResult(userId, true, undefined, {
        kind: 'TEST',
        title: 'پیام تست اتصال',
        preview: 'اتصال ربات تلگرام با موفقیت بررسی شد',
      });
    }
    return { sentAt: now };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'خطا در ارسال پیام تست به تلگرام';
    if (!overrideBotToken && !overrideChatId) {
      await recordTelegramDeliveryResult(userId, false, msg, {
        kind: 'TEST',
        title: 'خطا در پیام تست',
        preview: msg.slice(0, 120),
      });
    }
    throw new Error(msg);
  }
}

export async function notifyTelegramPriceAlert(userId: string, alert: PriceAlert): Promise<void> {
  if (!userId || alert.sendTelegram === false) return;
  const creds = await getActiveTelegramCredentials(userId, true);
  if (!creds || !creds.sendPriceAlerts) return;

  const conditionText =
    alert.condition === 'ABOVE'
      ? '📈 عبور به بالا یا مساوی هدف'
      : '📉 رسیدن به پایین یا مساوی هدف';

  const lines = [
    '🎯 <b>هشدار قیمت هدف فعال شد!</b>',
    '',
    `🪙 ارز دیجیتال: <b>${escapeHtml(alert.persianName)} (${escapeHtml(alert.baseAsset)})</b>`,
    `💱 بازار نوبیتکس: <code>${escapeHtml(alert.symbol)}</code>`,
    conditionText,
    `🏁 قیمت هدف: <b>${escapeHtml(formatQuoteValue(alert.targetPrice, alert.quoteCurrency))}</b>`,
    alert.triggeredPrice
      ? `💰 قیمت لحظه‌ای: <b>${escapeHtml(
          formatQuoteValue(alert.triggeredPrice, alert.quoteCurrency)
        )}</b>`
      : '',
    alert.note ? `📝 یادداشت: ${escapeHtml(alert.note)}` : '',
    `🕒 زمان: <code>${escapeHtml(formatTehranTime(alert.triggeredAt || Date.now()))}</code>`,
  ].filter(Boolean);

  try {
    await sendTelegramHtmlMessage(creds.botToken, creds.chatId, lines.join('\n'));
    await recordTelegramDeliveryResult(userId, true, undefined, {
      kind: 'PRICE_ALERT',
      title: `هشدار قیمت ${alert.baseAsset}`,
      preview: `${conditionText} · هدف ${formatQuoteValue(alert.targetPrice, alert.quoteCurrency)}`,
    });
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : 'ارسال هشدار قیمت به تلگرام ناموفق بود';
    await recordTelegramDeliveryResult(userId, false, errMsg, {
      kind: 'PRICE_ALERT',
      title: `هشدار قیمت ${alert.baseAsset}`,
      preview: `${conditionText} · هدف ${formatQuoteValue(alert.targetPrice, alert.quoteCurrency)}`,
    });
  }
}

export async function notifyTelegramPricePulse(
  userId: string,
  pulse: PricePulseNotification
): Promise<void> {
  if (!userId) return;
  const creds = await getActiveTelegramCredentials(userId, true);
  if (!creds || !creds.sendPeriodicWatchers) return;

  const changeEmoji = pulse.change24hPercent >= 0 ? '🟢' : '🔴';
  const changeText = `${pulse.change24hPercent >= 0 ? '+' : ''}${pulse.change24hPercent.toFixed(2)}%`;

  const lines = [
    `⏱ <b>گزارش دوره‌ای قیمت لحظه‌ای (هر ${pulse.intervalMinutes} دقیقه)</b>`,
    '',
    `🪙 ارز دیجیتال: <b>${escapeHtml(pulse.persianName)} (${escapeHtml(pulse.baseAsset)})</b>`,
    pulse.quoteMode === 'IRT' || pulse.quoteMode === 'BOTH'
      ? `🇮🇷 قیمت تومانی: <b>${escapeHtml(formatQuoteValue(pulse.priceToman, 'IRT'))}</b>`
      : '',
    pulse.quoteMode === 'USDT' || pulse.quoteMode === 'BOTH'
      ? `💵 قیمت تتری: <b>${escapeHtml(formatQuoteValue(pulse.priceUsdt, 'USDT'))}</b>`
      : '',
    `${changeEmoji} تغییر ۲۴ ساعته: <code>${escapeHtml(changeText)}</code>`,
    `🕒 زمان: <code>${escapeHtml(formatTehranTime(pulse.sentAt))}</code>`,
  ].filter(Boolean);

  try {
    await sendTelegramHtmlMessage(creds.botToken, creds.chatId, lines.join('\n'));
    await recordTelegramDeliveryResult(userId, true, undefined, {
      kind: 'PRICE_PULSE',
      title: `گزارش دوره‌ای ${pulse.baseAsset}`,
      preview: `تومانی ${formatQuoteValue(pulse.priceToman, 'IRT')} · ${changeText}`,
    });
  } catch (err) {
    const errMsg = err instanceof Error ? err.message : 'ارسال گزارش قیمت دوره‌ای به تلگرام ناموفق بود';
    await recordTelegramDeliveryResult(userId, false, errMsg, {
      kind: 'PRICE_PULSE',
      title: `گزارش دوره‌ای ${pulse.baseAsset}`,
      preview: `هر ${pulse.intervalMinutes} دقیقه`,
    });
  }
}

function formatQtySimple(val: number): string {
  if (!Number.isFinite(val)) return '0';
  if (val >= 100) return val.toLocaleString('en-US', { maximumFractionDigits: 2 });
  if (val >= 1) return val.toLocaleString('en-US', { maximumFractionDigits: 4 });
  return val.toLocaleString('en-US', { maximumFractionDigits: 6 });
}

export async function sendTelegramMessageForUser(
  userId: string,
  htmlText: string,
  meta?: {
    kind?: TelegramSentLogEntry['kind'];
    title?: string;
    preview?: string;
  }
): Promise<void> {
  if (!userId) return;
  const creds = await getActiveTelegramCredentials(userId, true);
  if (!creds || !creds.sendBotTrades) return;

  const title = meta?.title || 'گزارش ربات معامله‌گر';
  const preview = meta?.preview || '';
  const kind: TelegramSentLogEntry['kind'] = meta?.kind || 'BOT_EVENT';

  try {
    await sendTelegramHtmlMessage(creds.botToken, creds.chatId, htmlText, { skipDedupe: true });
    await recordTelegramDeliveryResult(userId, true, undefined, {
      kind,
      title,
      preview,
    });
  } catch (err) {
    await recordTelegramDeliveryResult(
      userId,
      false,
      err instanceof Error ? err.message : 'ارسال پیام به تلگرام ناموفق بود',
      {
        kind,
        title,
        preview,
      }
    );
  }
}

export async function notifyTelegramSpotOrder(
  userId: string,
  order: SpotOrder,
  action: 'CREATED' | 'FILLED' | 'CANCELED'
): Promise<void> {
  if (!userId) return;
  const creds = await getActiveTelegramCredentials(userId, true);
  if (!creds || !creds.sendTradeReports) return;

  const isBuy = order.side === 'BUY';
  const sideLabel = isBuy ? '🟢 خرید (BUY)' : '🔴 فروش (SELL)';
  const typeLabel = order.type === 'MARKET' ? 'آنی (Market)' : 'لیمیت (Limit)';
  const modeLabel = order.mode === 'live' ? 'حساب واقعی نوبیتکس' : 'حساب تمرینی';
  const header =
    action === 'CANCELED'
      ? '❌ <b>سفارش معاملاتی لغو شد</b>'
      : action === 'FILLED'
        ? '✅ <b>سفارش لیمیت تکمیل و انجام شد</b>'
        : order.status === 'FILLED'
          ? '💹 <b>گزارش خرید/فروش انجام‌شده (ترمینال)</b>'
          : '📌 <b>سفارش جدید ثبت شد (ترمینال)</b>';

  const lines = [
    header,
    '',
    `📊 جهت معامله: <b>${sideLabel}</b> · ${escapeHtml(typeLabel)}`,
    `🪙 بازار: <code>${escapeHtml(order.symbol)}</code> (${escapeHtml(modeLabel)})`,
    `📦 مقدار: <b>${escapeHtml(formatQtySimple(order.quantity))} ${escapeHtml(order.baseAsset)}</b>`,
    `💰 قیمت: <b>${escapeHtml(formatQuoteValue(order.price, order.quoteCurrency))}</b>`,
    `💵 ارزش کل: <b>${escapeHtml(formatQuoteValue(order.totalQuoteAmount, order.quoteCurrency))}</b>`,
    order.stopLossPrice
      ? `🛡 حد ضرر: <code>${escapeHtml(formatQuoteValue(order.stopLossPrice, order.quoteCurrency))}</code>`
      : '',
    order.takeProfitPrice
      ? `🎯 حد سود: <code>${escapeHtml(formatQuoteValue(order.takeProfitPrice, order.quoteCurrency))}</code>`
      : '',
    `🕒 زمان: <code>${escapeHtml(formatTehranTime(Date.now()))}</code>`,
  ].filter(Boolean);

  const shortTitle = `${isBuy ? 'خرید' : 'فروش'} ${order.baseAsset} (${action === 'CANCELED' ? 'لغو' : order.status === 'FILLED' ? 'انجام‌شده' : 'سفارش باز'})`;
  const shortPreview = `${formatQtySimple(order.quantity)} ${order.baseAsset} @ ${formatQuoteValue(order.price, order.quoteCurrency)}`;

  try {
    await sendTelegramHtmlMessage(creds.botToken, creds.chatId, lines.join('\n'), { skipDedupe: true });
    await recordTelegramDeliveryResult(userId, true, undefined, {
      kind: 'TRADE',
      title: shortTitle,
      preview: shortPreview,
    });
  } catch (err) {
    await recordTelegramDeliveryResult(
      userId,
      false,
      err instanceof Error ? err.message : 'ارسال گزارش معامله به تلگرام ناموفق بود',
      {
        kind: 'TRADE',
        title: shortTitle,
        preview: shortPreview,
      }
    );
  }
}

export async function notifyTelegramBotTrade(
  userId: string,
  input: {
    bot: BotStrategyConfig;
    event: BotExecutionLog['event'];
    price: number;
    quantity: number;
    pnlQuote?: number;
    usdtTomanRate?: number;
    reason: string;
  }
): Promise<void> {
  if (!userId || input.bot.notifyTelegram === false) return;
  const creds = await getActiveTelegramCredentials(userId, true);
  if (!creds || !creds.sendBotTrades) return;

  const isBuy = input.event === 'BUY_EXECUTED';
  const eventTitleMap: Record<string, string> = {
    BUY_EXECUTED: '🤖🟢 <b>خرید خودکار ربات انجام شد</b>',
    SELL_TP: '🤖🎯 <b>فروش ربات با حد سود (Take-Profit)</b>',
    SELL_SL: '🤖🛡 <b>فروش ربات با حد ضرر (Stop-Loss)</b>',
    SELL_TRAILING: '🤖📉 <b>فروش ربات با حد ضرر متحرک (Trailing Stop)</b>',
    SELL_SIGNAL: '🤖🔴 <b>فروش ربات بر اساس سیگنال خروج</b>',
  };

  const tradePnlMetrics =
    typeof input.pnlQuote === 'number'
      ? calculateBotRealizedPnlMetrics(input.bot, input.usdtTomanRate, input.pnlQuote)
      : null;
  const totalRealizedMetrics = calculateBotRealizedPnlMetrics(input.bot, input.usdtTomanRate);

  const pnlLine = tradePnlMetrics
    ? `📈 سود/زیان این معامله: <b>${escapeHtml(tradePnlMetrics.formattedMessageText)}</b>`
    : '';
  const totalRealizedLine = `💼 سود/زیان تحقق‌یافته کل ربات (Realized PnL): <b>${escapeHtml(
    totalRealizedMetrics.formattedMessageText
  )}</b>`;

  const lines = [
    eventTitleMap[input.event] || '🤖 <b>گزارش معامله ربات</b>',
    '',
    `⚙️ نام ربات: <b>${escapeHtml(input.bot.name)}</b>`,
    `🪙 بازار: <code>${escapeHtml(input.bot.symbol)}</code> (${escapeHtml(input.bot.timeframe)} · ${
      input.bot.mode === 'live' ? 'واقعی' : 'تمرینی'
    })`,
    `📦 مقدار: <b>${escapeHtml(formatQtySimple(input.quantity))} ${escapeHtml(input.bot.baseAsset)}</b>`,
    `💰 قیمت اجرا: <b>${escapeHtml(formatQuoteValue(input.price, input.bot.quoteCurrency))}</b>`,
    pnlLine,
    totalRealizedLine,
    `📝 دلیل: ${escapeHtml(input.reason)}`,
    `🕒 زمان: <code>${escapeHtml(formatTehranTime(Date.now()))}</code>`,
  ].filter(Boolean);

  const preview = `${input.bot.name} · ${isBuy ? 'خرید' : 'فروش'} ${formatQuoteValue(
    input.price,
    input.bot.quoteCurrency
  )} · Realized PnL: ${totalRealizedMetrics.percentText}`;

  try {
    await sendTelegramHtmlMessage(creds.botToken, creds.chatId, lines.join('\n'), { skipDedupe: true });
    await recordTelegramDeliveryResult(userId, true, undefined, {
      kind: 'BOT_TRADE',
      title: `${isBuy ? 'خرید ربات' : 'فروش ربات'} ${input.bot.baseAsset}`,
      preview,
    });
  } catch (err) {
    await recordTelegramDeliveryResult(
      userId,
      false,
      err instanceof Error ? err.message : 'ارسال گزارش معامله ربات به تلگرام ناموفق بود',
      {
        kind: 'BOT_TRADE',
        title: `${isBuy ? 'خرید ربات' : 'فروش ربات'} ${input.bot.baseAsset}`,
        preview,
      }
    );
  }
}

export async function notifyTelegramBotActivity(
  userId: string,
  input: {
    bot: BotStrategyConfig;
    eventType:
      | 'CREATED'
      | 'STARTED'
      | 'PAUSED'
      | 'MODE_CHANGED'
      | 'DELETED'
      | 'ERROR'
      | 'MONITOR_CYCLE';
    title: string;
    summary: string;
    currentPrice?: number;
    rsi14?: number;
    usdtTomanRate?: number;
    force?: boolean;
  }
): Promise<void> {
  if (!userId) return;
  if (!input.force && input.bot.notifyTelegram === false) return;
  const creds = await getActiveTelegramCredentials(userId, true);
  if (!creds) return;
  if (!input.force && !creds.sendBotMonitoring) return;

  if (!input.force) {
    if (creds.botMonitorMode === 'MANUAL_ONLY') return;
    if (input.eventType === 'MONITOR_CYCLE') {
      if (creds.botMonitorMode === 'EVENTS_AND_STATUS') return;
      if (creds.botMonitorMode === 'INTERVAL') {
        const lastAt = creds.lastBotMonitorSentAt || 0;
        const waitMs = Math.max(1, creds.botMonitorIntervalMinutes) * 60_000;
        if (Date.now() - lastAt < waitMs) return;
      }
    }
  }

  const icon =
    input.eventType === 'ERROR'
      ? '⚠️'
      : input.eventType === 'STARTED' || input.eventType === 'CREATED'
        ? '▶️'
        : input.eventType === 'PAUSED'
          ? '⏸'
          : input.eventType === 'DELETED'
            ? '🗑'
            : '📡';

  const posText = input.bot.activePosition
    ? `📌 پوزیشن باز: ${formatQtySimple(input.bot.activePosition.quantity)} ${input.bot.baseAsset} @ ${formatQuoteValue(
        input.bot.activePosition.entryPrice,
        input.bot.quoteCurrency
      )}`
    : '📭 بدون پوزیشن باز';

  const realizedMetrics = calculateBotRealizedPnlMetrics(input.bot, input.usdtTomanRate);

  const lines = [
    `${icon} <b>${escapeHtml(input.title)}</b>`,
    '',
    `🤖 ربات: <b>${escapeHtml(input.bot.name)}</b>`,
    `🪙 بازار: <code>${escapeHtml(input.bot.symbol)}</code> (${
      input.bot.strategyKind === 'FIXED_PRICE'
        ? `هدف قیمتی هر ${input.bot.pollIntervalSeconds || 5} ثانیه`
        : escapeHtml(input.bot.timeframe)
    } · ${input.bot.mode === 'live' ? 'حساب واقعی' : 'حساب تمرینی'})`,
    input.bot.strategyKind === 'FIXED_PRICE' &&
    input.bot.targetBuyPrice &&
    input.bot.targetSellPrice
      ? `🎯 هدف خرید: <code>${escapeHtml(
          formatQuoteValue(input.bot.targetBuyPrice, input.bot.quoteCurrency)
        )}</code> | هدف فروش: <code>${escapeHtml(
          formatQuoteValue(input.bot.targetSellPrice, input.bot.quoteCurrency)
        )}</code>`
      : '',
    input.currentPrice && input.currentPrice > 0
      ? `💰 قیمت فعلی: <b>${escapeHtml(formatQuoteValue(input.currentPrice, input.bot.quoteCurrency))}</b>${
          typeof input.rsi14 === 'number' ? ` · RSI(14): <code>${input.rsi14.toFixed(1)}</code>` : ''
        }`
      : '',
    `📝 وضعیت: ${escapeHtml(input.summary)}`,
    posText,
    `📊 عملکرد کل: <b>${input.bot.stats.totalTrades}</b> معامله (${input.bot.stats.winningTrades} برد / ${input.bot.stats.losingTrades} باخت)`,
    `💹 سود/زیان تحقق‌یافته (Realized PnL): <b>${escapeHtml(
      realizedMetrics.formattedMessageText
    )}</b>`,
    `🕒 زمان: <code>${escapeHtml(formatTehranTime(Date.now()))}</code>`,
  ].filter(Boolean);

  try {
    await sendTelegramHtmlMessage(creds.botToken, creds.chatId, lines.join('\n'));
    if (input.eventType === 'MONITOR_CYCLE') {
      await recordBotMonitorSent(userId);
    }
    await recordTelegramDeliveryResult(userId, true, undefined, {
      kind: input.eventType === 'MONITOR_CYCLE' ? 'BOT_MONITOR' : 'BOT_EVENT',
      title: input.title,
      preview: `${input.bot.name} · ${input.summary}`,
    });
  } catch (err) {
    await recordTelegramDeliveryResult(
      userId,
      false,
      err instanceof Error ? err.message : 'ارسال گزارش وضعیت ربات به تلگرام ناموفق بود',
      {
        kind: input.eventType === 'MONITOR_CYCLE' ? 'BOT_MONITOR' : 'BOT_EVENT',
        title: input.title,
        preview: input.bot.name,
      }
    );
  }
}

export async function sendManualTelegramReport(
  userId: string,
  input: {
    kind: TelegramManualReportKind;
    botId?: string;
    bots: BotStrategyConfig[];
    botLogs: BotExecutionLog[];
    orders: SpotOrder[];
    balances: SpotBalance[];
    markets: UnifiedMarketTicker[];
    usdtTomanRate: number;
  }
): Promise<{ sentAt: number; title: string; preview: string }> {
  const creds = await getActiveTelegramCredentials(userId, false);
  if (!creds) {
    throw new Error('ابتدا توکن ربات تلگرام و Chat ID را در بخش ربات تلگرام متصل و ذخیره کنید.');
  }

  const now = Date.now();
  const lines: string[] = [];
  let title = 'گزارش دستی تلگرام';

  if (input.kind === 'SINGLE_BOT') {
    const bot = input.bots.find((b) => b.id === input.botId);
    if (!bot) {
      throw new Error('ربات انتخاب‌شده یافت نشد.');
    }
    const market = input.markets.find((m) => m.baseAsset === bot.baseAsset);
    const livePrice =
      bot.quoteCurrency === 'IRT' ? market?.priceToman ?? 0 : market?.priceUsdt ?? 0;
    const recentBotLogs = input.botLogs.filter((l) => l.botId === bot.id).slice(0, 4);

    title = `گزارش دستی ربات ${bot.name}`;
    lines.push(`🤖 <b>گزارش کامل ربات معامله‌گر</b>`, '');
    lines.push(`⚙️ نام ربات: <b>${escapeHtml(bot.name)}</b>`);
    lines.push(
      `📌 وضعیت: <b>${bot.status === 'RUNNING' ? 'فعال و در حال پایش' : 'متوقف'}</b> (${
        bot.mode === 'live' ? 'حساب واقعی' : 'حساب تمرینی'
      })`
    );
    lines.push(`🪙 بازار: <code>${escapeHtml(bot.symbol)}</code> (${escapeHtml(bot.timeframe)})`);
    if (livePrice > 0) {
      lines.push(
        `💰 قیمت لحظه‌ای: <b>${escapeHtml(formatQuoteValue(livePrice, bot.quoteCurrency))}</b>`
      );
    }
    lines.push(`📡 آخرین نتیجه پایش: ${escapeHtml(bot.lastSignalSummary)}`);
    if (bot.activePosition) {
      lines.push(
        `📈 پوزیشن باز: <b>${escapeHtml(formatQtySimple(bot.activePosition.quantity))} ${escapeHtml(
          bot.baseAsset
        )}</b> @ ${escapeHtml(formatQuoteValue(bot.activePosition.entryPrice, bot.quoteCurrency))}`
      );
      if (bot.strategyKind === 'FIXED_PRICE' && bot.targetSellPrice) {
        lines.push(
          `🎯 هدف فروش پیش‌تنظیم: <code>${escapeHtml(
            formatQuoteValue(bot.targetSellPrice, bot.quoteCurrency)
          )}</code>`
        );
      } else {
        lines.push(
          `🎯 حد سود: <code>${escapeHtml(
            formatQuoteValue(bot.activePosition.takeProfitPrice, bot.quoteCurrency)
          )}</code> | 🛡 حد ضرر: <code>${escapeHtml(
            formatQuoteValue(bot.activePosition.stopLossPrice, bot.quoteCurrency)
          )}</code>`
        );
      }
    } else {
      lines.push('📭 پوزیشن باز: ندارد');
    }
    const realizedMetrics = calculateBotRealizedPnlMetrics(bot, input.usdtTomanRate);
    lines.push(
      `📊 آمار کلی: <b>${bot.stats.totalTrades}</b> معامله (${bot.stats.winningTrades} برد / ${bot.stats.losingTrades} باخت)`
    );
    lines.push(
      `💹 سود/زیان تحقق‌یافته (Realized PnL): <b>${escapeHtml(
        realizedMetrics.formattedMessageText
      )}</b>`
    );
    if (recentBotLogs.length > 0) {
      lines.push('', '📜 <b>آخرین عملیات این ربات:</b>');
      for (const l of recentBotLogs) {
        lines.push(`• <code>${escapeHtml(formatTehranTime(l.timestamp))}</code> — ${escapeHtml(l.message)}`);
      }
    }
  } else if (input.kind === 'TRADES') {
    title = 'گزارش دستی خرید و فروش‌ها';
    const openOrders = input.orders.filter((o) => o.status === 'NEW').slice(0, 6);
    const closedOrders = input.orders.filter((o) => o.status !== 'NEW').slice(0, 8);
    lines.push('💹 <b>گزارش خرید و فروش‌ها و سفارش‌ها (AI NobiBot)</b>', '');
    lines.push(`📌 سفارش‌های باز: <b>${input.orders.filter((o) => o.status === 'NEW').length}</b>`);
    if (openOrders.length > 0) {
      for (const o of openOrders) {
        lines.push(
          `• [باز] ${o.side === 'BUY' ? '🟢 خرید' : '🔴 فروش'} <code>${escapeHtml(
            o.symbol
          )}</code> · ${escapeHtml(formatQtySimple(o.quantity))} @ ${escapeHtml(
            formatQuoteValue(o.price, o.quoteCurrency)
          )}`
        );
      }
    } else {
      lines.push('• سفارش بازی وجود ندارد.');
    }
    lines.push('', '📜 <b>آخرین معاملات ثبت‌شده:</b>');
    if (closedOrders.length > 0) {
      for (const o of closedOrders) {
        lines.push(
          `• ${o.side === 'BUY' ? '🟢 خرید' : '🔴 فروش'} (${
            o.source === 'BOT' ? 'ربات' : 'دستی'
          }) <code>${escapeHtml(o.symbol)}</code> · ${escapeHtml(
            formatQtySimple(o.quantity)
          )} @ ${escapeHtml(formatQuoteValue(o.price, o.quoteCurrency))} [${
            o.status === 'FILLED' ? 'تکمیل' : 'لغو'
          }]`
        );
      }
    } else {
      lines.push('• هنوز معامله‌ای ثبت نشده است.');
    }
  } else if (input.kind === 'BOTS_MONITOR') {
    title = 'گزارش دستی پایش و کارهای ربات';
    const runningCount = input.bots.filter((b) => b.status === 'RUNNING').length;
    lines.push('📡 <b>گزارش کامل پایش و وضعیت ربات‌های معامله‌گر</b>', '');
    lines.push(`🤖 کل ربات‌ها: <b>${input.bots.length}</b> · فعال: <b>${runningCount}</b>`);
    let aggregateToman = 0;
    let aggregateUsdt = 0;
    let aggregateCapitalToman = 0;

    if (input.bots.length === 0) {
      lines.push('• هیچ رباتی تعریف نشده است.');
    } else {
      for (const b of input.bots.slice(0, 10)) {
        const statusTag = b.status === 'RUNNING' ? '🟢 فعال' : '⏸ متوقف';
        const metrics = calculateBotRealizedPnlMetrics(b, input.usdtTomanRate);
        aggregateToman += metrics.realizedPnlToman;
        aggregateUsdt += metrics.realizedPnlUsdt;
        aggregateCapitalToman +=
          b.quoteCurrency === 'IRT'
            ? b.orderAmount
            : b.orderAmount *
              (input.usdtTomanRate > 0 ? input.usdtTomanRate : getLastKnownUsdtTomanRate());
        lines.push(
          `• <b>${escapeHtml(b.name)}</b> (<code>${escapeHtml(b.symbol)}</code>) — ${statusTag}`
        );
        lines.push(`  ↳ پایش: ${escapeHtml(b.lastSignalSummary)}`);
        lines.push(
          `  ↳ آمار: ${b.stats.totalTrades} معامله · Realized PnL: <b>${escapeHtml(
            metrics.formattedMessageText
          )}</b>`
        );
      }
      const totalPct = aggregateCapitalToman > 0 ? (aggregateToman / aggregateCapitalToman) * 100 : 0;
      lines.push(
        '',
        `💰 جمع کل سود/زیان تحقق‌یافته ربات‌ها: <b>${escapeHtml(
          formatSignedToman(aggregateToman)
        )} (${escapeHtml(formatSignedUsdt(aggregateUsdt))}) · ${escapeHtml(
          formatSignedPercent(totalPct)
        )}</b>`
      );
    }
    if (input.botLogs.length > 0) {
      lines.push('', '🧾 <b>آخرین رویدادها و عملیات ربات‌ها:</b>');
      for (const l of input.botLogs.slice(0, 6)) {
        lines.push(
          `• [${escapeHtml(l.symbol)}] ${escapeHtml(l.message)} (<code>${escapeHtml(
            formatTehranTime(l.timestamp)
          )}</code>)`
        );
      }
    }
  } else if (input.kind === 'PORTFOLIO') {
    title = 'گزارش دستی کیف پول و دارایی‌ها';
    const totalToman = input.balances.reduce((s, b) => s + b.tomanValue, 0);
    const totalUsdt = input.balances.reduce((s, b) => s + b.usdtValue, 0);
    lines.push('💼 <b>گزارش موجودی کیف پول و دارایی‌ها</b>', '');
    lines.push(
      `💰 ارزش کل پرتفوی: <b>${escapeHtml(formatQuoteValue(totalToman, 'IRT'))}</b> (≈ <b>$${totalUsdt.toFixed(
        2
      )}</b>)`
    );
    lines.push('');
    for (const b of input.balances.slice(0, 12)) {
      lines.push(
        `• <b>${escapeHtml(b.asset)}</b> (${escapeHtml(b.persianName || b.asset)}): <code>${escapeHtml(
          formatQtySimple(b.total)
        )}</code> — ${escapeHtml(formatQuoteValue(b.tomanValue, 'IRT'))}`
      );
    }
  } else {
    title = 'گزارش جامع کامل (سبد + معاملات + ربات‌ها)';
    const totalToman = input.balances.reduce((s, b) => s + b.tomanValue, 0);
    const totalUsdt = input.balances.reduce((s, b) => s + b.usdtValue, 0);
    const runningBots = input.bots.filter((b) => b.status === 'RUNNING');
    const btc = input.markets.find((m) => m.baseAsset === 'BTC');
    lines.push('📊 <b>گزارش جامع وضعیت حساب و ربات‌ها — AI NobiBot (ainobibot.ir)</b>', '');
    lines.push(
      `💵 نرخ لحظه‌ای تتر: <b>${escapeHtml(formatQuoteValue(input.usdtTomanRate, 'IRT'))}</b>`
    );
    if (btc) {
      lines.push(
        `🪙 بیت‌کوین: <b>${escapeHtml(formatQuoteValue(btc.priceToman, 'IRT'))}</b> ($${btc.priceUsdt.toLocaleString(
          'en-US',
          { maximumFractionDigits: 2 }
        )})`
      );
    }
    lines.push(
      `💼 ارزش کل سبد: <b>${escapeHtml(formatQuoteValue(totalToman, 'IRT'))}</b> (≈ $${totalUsdt.toFixed(2)})`
    );
    lines.push(
      `🤖 ربات‌ها: <b>${runningBots.length}</b> فعال از <b>${input.bots.length}</b> ربات`
    );
    lines.push(
      `💹 سفارش‌ها: <b>${input.orders.filter((o) => o.status === 'NEW').length}</b> باز · <b>${
        input.orders.filter((o) => o.status === 'FILLED').length
      }</b> تکمیل‌شده`
    );
    if (input.bots.length > 0) {
      let sumPnlToman = 0;
      let sumPnlUsdt = 0;
      let sumCapToman = 0;
      lines.push('', '📡 <b>خلاصه پایش و سود/زیان ربات‌ها:</b>');
      for (const b of input.bots.slice(0, 5)) {
        const metrics = calculateBotRealizedPnlMetrics(b, input.usdtTomanRate);
        sumPnlToman += metrics.realizedPnlToman;
        sumPnlUsdt += metrics.realizedPnlUsdt;
        sumCapToman +=
          b.quoteCurrency === 'IRT'
            ? b.orderAmount
            : b.orderAmount *
              (input.usdtTomanRate > 0 ? input.usdtTomanRate : getLastKnownUsdtTomanRate());
        lines.push(
          `• <b>${escapeHtml(b.name)}</b> [${b.status === 'RUNNING' ? 'فعال' : 'متوقف'}]: ${escapeHtml(
            b.lastSignalSummary
          )} · Realized PnL: <b>${escapeHtml(metrics.formattedMessageText)}</b>`
        );
      }
      const sumPct = sumCapToman > 0 ? (sumPnlToman / sumCapToman) * 100 : 0;
      lines.push(
        `💰 جمع Realized PnL ربات‌ها: <b>${escapeHtml(
          formatSignedToman(sumPnlToman)
        )} (${escapeHtml(formatSignedUsdt(sumPnlUsdt))}) · ${escapeHtml(
          formatSignedPercent(sumPct)
        )}</b>`
      );
    }
    if (input.orders.length > 0) {
      lines.push('', '🧾 <b>۳ معامله آخر:</b>');
      for (const o of input.orders.slice(0, 3)) {
        lines.push(
          `• ${o.side === 'BUY' ? 'خرید' : 'فروش'} <code>${escapeHtml(o.symbol)}</code> @ ${escapeHtml(
            formatQuoteValue(o.price, o.quoteCurrency)
          )}`
        );
      }
    }
  }

  lines.push('', `🕒 زمان گزارش: <code>${escapeHtml(formatTehranTime(now))}</code>`);
  const preview = `${title} · ${input.bots.length} ربات · ${input.orders.length} سفارش`;

  try {
    await sendTelegramHtmlMessage(creds.botToken, creds.chatId, lines.join('\n'), { skipDedupe: true });
    await recordTelegramDeliveryResult(userId, true, undefined, {
      kind: 'MANUAL_REPORT',
      title,
      preview,
    });
    return { sentAt: now, title, preview };
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'ارسال دستی گزارش به تلگرام ناموفق بود';
    await recordTelegramDeliveryResult(userId, false, msg, {
      kind: 'MANUAL_REPORT',
      title,
      preview,
    });
    throw new Error(msg);
  }
}
