import crypto from 'node:crypto';
import { and, desc, eq } from 'drizzle-orm';
import * as schema from '../src/db/schema.ts';
import type {
  AiCycleProCapitalUsageMode,
  AiCycleProConfig,
  AiCycleProCycleRecord,
  AiCycleProDailyStats,
  AiCycleProDecision,
  AiCycleProLog,
  AiCycleProMarketPreview,
  AiCycleProPendingOrder,
  AiCycleProPosition,
  AiCycleProStats,
  AiCycleProStatus,
  BotExecutionConfirmationMode,
  ExecutionMode,
  KlineCandle,
  OrderBookSnapshot,
  QuoteCurrency,
  SpotBalance,
  SpotOrder,
  UnifiedMarketTicker,
} from '../src/types/trading.ts';
import {
  DEFAULT_NOBITEX_FEE_RATE,
  getMinimumOrderNotional,
  resolveOrderQuantityForNotional,
  roundQuantityToStep,
  roundQuoteValue,
  simulateOrderBookBuy,
  simulateOrderBookSell,
} from '../src/utils/profitBotMath.ts';
import {
  acquireWorkerLock,
  ensureUserRecord,
  getDb,
  releaseWorkerLock,
} from './db/index.ts';
import {
  getPaperBalances,
  placePaperOrder,
  recordLiveOrderAndTrade,
} from './botEngine.ts';
import { analyzeCandles } from './indicators.ts';
import {
  analyzeAiCycleProMarket,
  type AnalyzeAiCycleProInput,
} from './aiAnalyzer.ts';
import {
  fetchNobitexKlines,
  fetchNobitexLiveBalances,
  fetchNobitexOrderBook,
  fetchNobitexUnifiedMarkets,
  formatNobitexClientOrderId,
  getNobitexMarketRules,
  getNobitexRateLimitRemainingMs,
  NobitexAuthError,
  NobitexRateLimitError,
  placeNobitexLiveOrder,
} from './nobitexClient.ts';
import {
  getActiveExchangeCredentialsForUser,
  hasActiveExchangeCredentialsForUser,
} from './securityVault.ts';
import { sendTelegramMessageForUser } from './telegramClient.ts';

const AI_CYCLE_LOCK_NAME = 'ali_trader_ai_cycle_pro_lock';
const AI_CYCLE_WORKER_ID = `aicp-worker-${process.pid}-${crypto.randomBytes(3).toString('hex')}`;
let isEvaluatingAiCycleLocally = false;

const aicpLastRunMap = new Map<string, number>();
const aicpRetryAfterMap = new Map<string, { until: number; failures: number }>();

export interface AiCycleProRuntimeDeps {
  fetchOrderBook: (symbol: string, limit?: number) => Promise<OrderBookSnapshot>;
  fetchMarkets: () => Promise<{ markets: UnifiedMarketTicker[]; usdtTomanRate: number }>;
  fetchKlines: (symbol: string, timeframe: '15m' | '1h', count?: number) => Promise<KlineCandle[]>;
  getMarketRules: (symbol: string) => Promise<{ minNotional: number; amountStep: number }>;
  getBalances: (
    userId: string,
    mode: ExecutionMode,
    markets?: UnifiedMarketTicker[],
    usdtTomanRate?: number
  ) => Promise<SpotBalance[]>;
  placeOrder: (
    userId: string,
    bot: AiCycleProConfig,
    input: {
      side: 'BUY' | 'SELL';
      quantity: number;
      price: number;
      idempotencyKey: string;
      realizedPnlQuote?: number;
    }
  ) => Promise<SpotOrder>;
  analyzeMarket: (input: AnalyzeAiCycleProInput) => Promise<AiCycleProDecision>;
  now: () => number;
}

export function createAiCycleProRuntimeDeps(): AiCycleProRuntimeDeps {
  return {
    fetchOrderBook: (symbol, limit = 35) => fetchNobitexOrderBook(symbol, limit),
    fetchMarkets: () => fetchNobitexUnifiedMarkets(),
    fetchKlines: (symbol, tf, count = 120) => fetchNobitexKlines(symbol, tf, count),
    getMarketRules: (symbol) => getNobitexMarketRules(symbol),
    getBalances: async (userId, mode, markets = [], usdtTomanRate = 0) => {
      if (mode === 'live') {
        const creds = await getActiveExchangeCredentialsForUser(userId);
        if (!creds) throw new NobitexAuthError('کلید API نوبیتکس برای معاملات واقعی ثبت نشده است.');
        return fetchNobitexLiveBalances(markets, usdtTomanRate, creds);
      }
      return getPaperBalances(userId, markets, usdtTomanRate);
    },
    placeOrder: async (userId, bot, input) => {
      if (bot.mode === 'live') {
        const creds = await getActiveExchangeCredentialsForUser(userId);
        if (!creds) throw new NobitexAuthError('کلید API نوبیتکس برای معاملات واقعی ثبت نشده است.');
        const order = await placeNobitexLiveOrder(
          {
            baseAsset: bot.baseAsset,
            quoteCurrency: bot.quoteCurrency,
            side: input.side,
            type: 'MARKET',
            quantity: input.quantity,
            source: 'BOT',
            botId: bot.id,
            clientOrderId: formatNobitexClientOrderId(input.idempotencyKey),
          },
          creds
        );
        await recordLiveOrderAndTrade(userId, order, {
          idempotencyKey: input.idempotencyKey,
          realizedPnlQuote: input.realizedPnlQuote,
        });
        return order;
      }

      return placePaperOrder(userId, {
        baseAsset: bot.baseAsset,
        quoteCurrency: bot.quoteCurrency,
        side: input.side,
        type: 'MARKET',
        quantity: input.quantity,
        price: input.price,
        source: 'BOT',
        botId: bot.id,
        idempotencyKey: input.idempotencyKey,
        realizedPnlQuote: input.realizedPnlQuote,
      });
    },
    analyzeMarket: (input) => analyzeAiCycleProMarket(input),
    now: () => Date.now(),
  };
}

function getTodayDateKey(ts = Date.now()): string {
  const d = new Date(ts);
  const y = d.getUTCFullYear();
  const m = String(d.getUTCMonth() + 1).padStart(2, '0');
  const day = String(d.getUTCDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
}

function formatQuoteShort(amount: number, quoteCurrency: QuoteCurrency): string {
  const abs = Math.abs(amount);
  const maxDec = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
  if (quoteCurrency === 'IRT') {
    return `${amount.toLocaleString('en-US', { maximumFractionDigits: maxDec })} تومان`;
  }
  return `${amount.toLocaleString('en-US', {
    minimumFractionDigits: abs >= 1 ? 2 : 0,
    maximumFractionDigits: maxDec,
  })} USDT`;
}

function defaultDailyStats(now = Date.now()): AiCycleProDailyStats {
  return {
    dateKey: getTodayDateKey(now),
    tradesCount: 0,
    lossQuote: 0,
    netProfitQuote: 0,
  };
}

function normalizeDailyStats(raw: unknown, now = Date.now()): AiCycleProDailyStats {
  const today = getTodayDateKey(now);
  const obj = (raw || {}) as Partial<AiCycleProDailyStats>;
  if (obj.dateKey !== today) {
    return defaultDailyStats(now);
  }
  return {
    dateKey: today,
    tradesCount: Math.max(0, Number(obj.tradesCount || 0)),
    lossQuote: Math.max(0, Number(obj.lossQuote || 0)),
    netProfitQuote: Number(obj.netProfitQuote || 0),
  };
}

function defaultStats(): AiCycleProStats {
  return {
    completedCycles: 0,
    winningCycles: 0,
    losingCycles: 0,
    totalNetProfitQuote: 0,
    totalFeesPaidQuote: 0,
    currentCapitalInvolved: 0,
    lastBuyPrice: null,
  };
}

function mapAiCycleProRow(
  row: typeof schema.aiCycleProBots.$inferSelect
): AiCycleProConfig {
  const rawStats = (row.statsJson || {}) as Partial<AiCycleProStats>;
  return {
    id: row.id,
    ownerId: row.userId,
    name: row.name,
    baseAsset: row.baseAsset,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    symbol: row.symbol,
    mode: (row.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    isActive: Boolean(row.isActive),
    status: (row.status || 'IDLE') as AiCycleProStatus,
    capitalAmount: Number(row.capitalAmount || 0),
    capitalUsageMode: (row.capitalUsageMode === 'PARTIAL'
      ? 'PARTIAL'
      : 'FULL') as AiCycleProCapitalUsageMode,
    capitalPortionPercent: Number(row.capitalPortionPercent || 100),
    executionConfirmationMode: (row.executionConfirmationMode === 'MANUAL_CONFIRM'
      ? 'MANUAL_CONFIRM'
      : 'AUTO') as BotExecutionConfirmationMode,
    autoRepeatCycles: Boolean(row.autoRepeatCycles),
    stopLossPercent: Number(row.stopLossPercent || 3),
    maxDailyLoss: Number(row.maxDailyLoss || 0),
    maxSlippagePercent: Number(row.maxSlippagePercent || 0.6),
    maxSpreadPercent: Number(row.maxSpreadPercent || 2.5),
    minTargetNetProfitPercent: Number(row.minTargetNetProfitPercent || 1.2),
    pollIntervalSeconds: Number(row.pollIntervalSeconds || 15),
    feeRate: Number(row.feeRate || DEFAULT_NOBITEX_FEE_RATE),
    notifyTelegram: Boolean(row.notifyTelegram),
    activePosition: (row.activePositionJson as AiCycleProPosition | null) || null,
    pendingOrder: (row.pendingOrderJson as AiCycleProPendingOrder | null) || null,
    lastDecision: (row.lastDecisionJson as AiCycleProDecision | null) || null,
    dailyStats: normalizeDailyStats(row.dailyStatsJson),
    stats: {
      completedCycles: Number(rawStats.completedCycles || 0),
      winningCycles: Number(rawStats.winningCycles || 0),
      losingCycles: Number(rawStats.losingCycles || 0),
      totalNetProfitQuote: Number(rawStats.totalNetProfitQuote || 0),
      totalFeesPaidQuote: Number(rawStats.totalFeesPaidQuote || 0),
      currentCapitalInvolved: Number(rawStats.currentCapitalInvolved || 0),
      lastBuyPrice: rawStats.lastBuyPrice ?? null,
    },
    lastPrice: Number(row.lastPrice || 0),
    lastStatusReason: row.lastStatusReason || '',
    lastError: row.lastError ?? null,
    lastCheckedAt: row.lastCheckedAt ?? null,
    startedAt: row.startedAt ?? null,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

function mapAiCycleRecordRow(
  row: typeof schema.aiCycleProCycles.$inferSelect
): AiCycleProCycleRecord {
  return {
    id: row.id,
    botId: row.botId,
    cycleIndex: row.cycleIndex,
    symbol: row.symbol,
    baseAsset: row.baseAsset,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    mode: (row.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    entryAmountQuote: row.entryAmountQuote,
    actualBuyAvgPrice: row.actualBuyAvgPrice,
    boughtQty: row.boughtQty,
    buyFeeQuote: row.buyFeeQuote,
    totalBuyCostQuote: row.totalBuyCostQuote,
    actualSellAvgPrice: row.actualSellAvgPrice,
    soldQty: row.soldQty,
    grossSellProceedsQuote: row.grossSellProceedsQuote,
    sellFeeQuote: row.sellFeeQuote,
    finalNetProfitQuote: row.finalNetProfitQuote,
    targetNetProfitPercent: row.targetNetProfitPercent,
    slippagePercent: row.slippagePercent,
    exitReason: row.exitReason as AiCycleProCycleRecord['exitReason'],
    aiEntrySummaryFa: row.aiEntrySummaryFa,
    aiExitSummaryFa: row.aiExitSummaryFa,
    startedAt: row.startedAt,
    completedAt: row.completedAt,
  };
}

function mapAiCycleLogRow(
  row: typeof schema.aiCycleProLogs.$inferSelect
): AiCycleProLog {
  return {
    id: row.id,
    botId: row.botId,
    cycleIndex: row.cycleIndex,
    status: row.status as AiCycleProStatus,
    event: row.event as AiCycleProLog['event'],
    price: row.price,
    netProfitQuote: row.netProfitQuote ?? null,
    message: row.message,
    timestamp: row.timestamp,
  };
}

async function appendAiCycleLog(
  userId: string,
  entry: {
    botId: string;
    cycleIndex: number;
    status: AiCycleProStatus;
    event: AiCycleProLog['event'];
    price: number;
    netProfitQuote?: number | null;
    message: string;
    timestamp?: number;
  }
): Promise<void> {
  const db = getDb();
  const ts = entry.timestamp ?? Date.now();
  await db.insert(schema.aiCycleProLogs).values({
    id: `aicplog-${ts}-${crypto.randomBytes(3).toString('hex')}`,
    botId: entry.botId,
    userId,
    cycleIndex: entry.cycleIndex,
    status: entry.status,
    event: entry.event,
    price: entry.price,
    netProfitQuote: entry.netProfitQuote ?? null,
    message: entry.message.slice(0, 600),
    timestamp: ts,
  });
}

async function notifyAiCycleTelegram(
  userId: string,
  bot: AiCycleProConfig,
  title: string,
  summary: string
): Promise<void> {
  if (!bot.notifyTelegram) return;
  try {
    await sendTelegramMessageForUser(
      userId,
      `🤖 <b>AI Cycle Pro | ${bot.name}</b>\n${title}\nنماد: <code>${bot.symbol}</code> (${
        bot.mode === 'live' ? 'واقعی' : 'تمرینی'
      })\n${summary}`
    );
  } catch {
    // Never fail bot execution if Telegram fails
  }
}

export async function getUserAiCycleProBots(userId: string): Promise<AiCycleProConfig[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.aiCycleProBots)
    .where(eq(schema.aiCycleProBots.userId, userId))
    .orderBy(desc(schema.aiCycleProBots.createdAt));
  return rows.map(mapAiCycleProRow);
}

export async function getUserAiCycleProBotById(
  userId: string,
  botId: string
): Promise<AiCycleProConfig | null> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.aiCycleProBots)
    .where(and(eq(schema.aiCycleProBots.id, botId), eq(schema.aiCycleProBots.userId, userId)))
    .limit(1);
  return rows[0] ? mapAiCycleProRow(rows[0]) : null;
}

export async function getUserAiCycleProCycles(
  userId: string,
  botId?: string
): Promise<AiCycleProCycleRecord[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.aiCycleProCycles)
    .where(
      botId
        ? and(eq(schema.aiCycleProCycles.userId, userId), eq(schema.aiCycleProCycles.botId, botId))
        : eq(schema.aiCycleProCycles.userId, userId)
    )
    .orderBy(desc(schema.aiCycleProCycles.completedAt))
    .limit(100);
  return rows.map(mapAiCycleRecordRow);
}

export async function getUserAiCycleProLogs(
  userId: string,
  botId?: string
): Promise<AiCycleProLog[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.aiCycleProLogs)
    .where(
      botId
        ? and(eq(schema.aiCycleProLogs.userId, userId), eq(schema.aiCycleProLogs.botId, botId))
        : eq(schema.aiCycleProLogs.userId, userId)
    )
    .orderBy(desc(schema.aiCycleProLogs.timestamp))
    .limit(120);
  return rows.map(mapAiCycleLogRow);
}

export interface CreateAiCycleProInput {
  name?: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  capitalAmount: number;
  mode?: ExecutionMode;
  confirmLive?: boolean;
  startImmediately?: boolean;
  capitalUsageMode?: AiCycleProCapitalUsageMode;
  capitalPortionPercent?: number;
  executionConfirmationMode?: BotExecutionConfirmationMode;
  autoRepeatCycles?: boolean;
  stopLossPercent?: number;
  maxDailyLoss?: number;
  maxSlippagePercent?: number;
  maxSpreadPercent?: number;
  minTargetNetProfitPercent?: number;
  pollIntervalSeconds?: number;
  feeRate?: number;
  notifyTelegram?: boolean;
}

export async function createAiCycleProBot(
  userId: string,
  input: CreateAiCycleProInput
): Promise<AiCycleProConfig> {
  const mode: ExecutionMode = input.mode === 'live' ? 'live' : 'paper';
  if (mode === 'live') {
    if (!input.confirmLive) {
      throw new Error('برای ایجاد AI Cycle Pro در حالت واقعی، تأیید صریح الزامی است.');
    }
    if (!(await hasActiveExchangeCredentialsForUser(userId))) {
      throw new Error('توکن API نوبیتکس برای معاملات واقعی ثبت نشده است.');
    }
  }

  const baseAsset = input.baseAsset.toUpperCase().trim();
  const quoteCurrency: QuoteCurrency = input.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
  const symbol = `${baseAsset}${quoteCurrency}`;
  const minNotional = getMinimumOrderNotional(quoteCurrency);
  const capitalAmount = Number(input.capitalAmount);
  if (!Number.isFinite(capitalAmount) || capitalAmount + 1e-6 < minNotional) {
    throw new Error(
      `حداقل سرمایه برای بازار ${quoteCurrency === 'IRT' ? 'تومانی ۵۰,۰۰۰ تومان' : 'تتری ۰.۵ USDT'} است.`
    );
  }

  await ensureUserRecord({ uid: userId });
  const now = Date.now();
  const id = `aicp-${now}-${crypto.randomBytes(3).toString('hex')}`;
  const isActive = Boolean(input.startImmediately);
  const capitalUsageMode: AiCycleProCapitalUsageMode =
    input.capitalUsageMode === 'PARTIAL' ? 'PARTIAL' : 'FULL';
  const capitalPortionPercent =
    capitalUsageMode === 'PARTIAL'
      ? Math.min(100, Math.max(10, Number(input.capitalPortionPercent ?? 50)))
      : 100;
  const maxDailyLoss =
    input.maxDailyLoss !== undefined
      ? Math.max(0, Number(input.maxDailyLoss))
      : roundQuoteValue(capitalAmount * 0.08, quoteCurrency);

  const config: AiCycleProConfig = {
    id,
    ownerId: userId,
    name: (input.name || `چرخه هوشمند ${baseAsset}`).trim().slice(0, 100),
    baseAsset,
    quoteCurrency,
    symbol,
    mode,
    isActive,
    status: isActive ? 'ANALYZING' : 'IDLE',
    capitalAmount,
    capitalUsageMode,
    capitalPortionPercent,
    executionConfirmationMode:
      input.executionConfirmationMode === 'MANUAL_CONFIRM' ? 'MANUAL_CONFIRM' : 'AUTO',
    autoRepeatCycles: input.autoRepeatCycles !== false,
    stopLossPercent: Math.min(30, Math.max(0.5, Number(input.stopLossPercent ?? 3.0))),
    maxDailyLoss,
    maxSlippagePercent: Math.min(10, Math.max(0.05, Number(input.maxSlippagePercent ?? 0.6))),
    maxSpreadPercent: Math.min(15, Math.max(0.05, Number(input.maxSpreadPercent ?? 2.5))),
    minTargetNetProfitPercent: Math.min(
      15,
      Math.max(0.4, Number(input.minTargetNetProfitPercent ?? 1.2))
    ),
    pollIntervalSeconds: Math.min(
      300,
      Math.max(5, Math.round(Number(input.pollIntervalSeconds ?? 15)))
    ),
    feeRate: Math.min(0.05, Math.max(0, Number(input.feeRate ?? DEFAULT_NOBITEX_FEE_RATE))),
    notifyTelegram: input.notifyTelegram !== false,
    activePosition: null,
    pendingOrder: null,
    lastDecision: null,
    dailyStats: defaultDailyStats(now),
    stats: defaultStats(),
    lastPrice: 0,
    lastStatusReason: isActive
      ? 'ربات AI Cycle Pro فعال شد و در حال تحلیل شرایط بازار نوبیتکس است.'
      : 'ربات آماده است؛ برای آغاز چرخه هوشمند دکمه شروع را بزنید.',
    lastError: null,
    lastCheckedAt: null,
    startedAt: isActive ? now : null,
    createdAt: now,
    updatedAt: now,
  };

  const db = getDb();
  await db.insert(schema.aiCycleProBots).values({
    id: config.id,
    userId,
    name: config.name,
    baseAsset: config.baseAsset,
    quoteCurrency: config.quoteCurrency,
    symbol: config.symbol,
    mode: config.mode,
    isActive: config.isActive,
    status: config.status,
    capitalAmount: config.capitalAmount,
    capitalUsageMode: config.capitalUsageMode,
    capitalPortionPercent: config.capitalPortionPercent,
    executionConfirmationMode: config.executionConfirmationMode,
    autoRepeatCycles: config.autoRepeatCycles,
    stopLossPercent: config.stopLossPercent,
    maxDailyLoss: config.maxDailyLoss,
    maxSlippagePercent: config.maxSlippagePercent,
    maxSpreadPercent: config.maxSpreadPercent,
    minTargetNetProfitPercent: config.minTargetNetProfitPercent,
    pollIntervalSeconds: config.pollIntervalSeconds,
    feeRate: config.feeRate,
    notifyTelegram: config.notifyTelegram,
    activePositionJson: null,
    pendingOrderJson: null,
    lastDecisionJson: null,
    dailyStatsJson: config.dailyStats,
    statsJson: config.stats,
    lastPrice: 0,
    lastStatusReason: config.lastStatusReason,
    lastError: null,
    lastCheckedAt: null,
    startedAt: config.startedAt,
    createdAt: now,
    updatedAt: now,
  });

  await appendAiCycleLog(userId, {
    botId: config.id,
    cycleIndex: 0,
    status: config.status,
    event: 'INFO',
    price: 0,
    message: `ربات AI Cycle Pro ساخته شد · سقف سرمایه: ${formatQuoteShort(
      config.capitalAmount,
      config.quoteCurrency
    )} (${config.capitalUsageMode === 'PARTIAL' ? `${config.capitalPortionPercent}٪ بخشی` : '۱۰۰٪ کل'})`,
  });

  return config;
}

export async function updateAiCycleProBot(
  userId: string,
  botId: string,
  updates: Partial<CreateAiCycleProInput>
): Promise<AiCycleProConfig> {
  const existing = await getUserAiCycleProBotById(userId, botId);
  if (!existing) throw new Error('ربات AI Cycle Pro مورد نظر یافت نشد.');

  if (updates.mode === 'live' && existing.mode !== 'live') {
    if (!updates.confirmLive) {
      throw new Error('برای انتقال به حساب واقعی نوبیتکس، تأیید صریح الزامی است.');
    }
    if (!(await hasActiveExchangeCredentialsForUser(userId))) {
      throw new Error('کلید API نوبیتکس برای معاملات واقعی ثبت نشده است.');
    }
  }

  const nextCapital =
    updates.capitalAmount !== undefined ? Number(updates.capitalAmount) : existing.capitalAmount;
  const minNotional = getMinimumOrderNotional(existing.quoteCurrency);
  if (!Number.isFinite(nextCapital) || nextCapital + 1e-6 < minNotional) {
    throw new Error(
      `حداقل سرمایه برای بازار ${
        existing.quoteCurrency === 'IRT' ? 'تومانی ۵۰,۰۰۰ تومان' : 'تتری ۰.۵ USDT'
      } است.`
    );
  }

  const nextUsageMode: AiCycleProCapitalUsageMode =
    updates.capitalUsageMode !== undefined
      ? updates.capitalUsageMode === 'PARTIAL'
        ? 'PARTIAL'
        : 'FULL'
      : existing.capitalUsageMode;
  const nextPortion =
    nextUsageMode === 'PARTIAL'
      ? Math.min(
          100,
          Math.max(10, Number(updates.capitalPortionPercent ?? existing.capitalPortionPercent))
        )
      : 100;

  const now = Date.now();
  const db = getDb();
  const [updated] = await db
    .update(schema.aiCycleProBots)
    .set({
      name: updates.name?.trim() ? updates.name.trim().slice(0, 100) : existing.name,
      mode: updates.mode ? (updates.mode === 'live' ? 'live' : 'paper') : existing.mode,
      capitalAmount: nextCapital,
      capitalUsageMode: nextUsageMode,
      capitalPortionPercent: nextPortion,
      executionConfirmationMode:
        updates.executionConfirmationMode !== undefined
          ? updates.executionConfirmationMode === 'MANUAL_CONFIRM'
            ? 'MANUAL_CONFIRM'
            : 'AUTO'
          : existing.executionConfirmationMode,
      autoRepeatCycles:
        updates.autoRepeatCycles !== undefined
          ? Boolean(updates.autoRepeatCycles)
          : existing.autoRepeatCycles,
      stopLossPercent:
        updates.stopLossPercent !== undefined
          ? Math.min(30, Math.max(0.5, Number(updates.stopLossPercent)))
          : existing.stopLossPercent,
      maxDailyLoss:
        updates.maxDailyLoss !== undefined
          ? Math.max(0, Number(updates.maxDailyLoss))
          : existing.maxDailyLoss,
      maxSlippagePercent:
        updates.maxSlippagePercent !== undefined
          ? Math.min(10, Math.max(0.05, Number(updates.maxSlippagePercent)))
          : existing.maxSlippagePercent,
      maxSpreadPercent:
        updates.maxSpreadPercent !== undefined
          ? Math.min(15, Math.max(0.05, Number(updates.maxSpreadPercent)))
          : existing.maxSpreadPercent,
      minTargetNetProfitPercent:
        updates.minTargetNetProfitPercent !== undefined
          ? Math.min(15, Math.max(0.4, Number(updates.minTargetNetProfitPercent)))
          : existing.minTargetNetProfitPercent,
      pollIntervalSeconds:
        updates.pollIntervalSeconds !== undefined
          ? Math.min(300, Math.max(5, Math.round(Number(updates.pollIntervalSeconds))))
          : existing.pollIntervalSeconds,
      notifyTelegram:
        updates.notifyTelegram !== undefined
          ? Boolean(updates.notifyTelegram)
          : existing.notifyTelegram,
      updatedAt: now,
    })
    .where(and(eq(schema.aiCycleProBots.id, botId), eq(schema.aiCycleProBots.userId, userId)))
    .returning();

  return mapAiCycleProRow(updated);
}

export async function startAiCycleProBot(
  userId: string,
  botId: string,
  confirmLive?: boolean
): Promise<AiCycleProConfig> {
  const existing = await getUserAiCycleProBotById(userId, botId);
  if (!existing) throw new Error('ربات AI Cycle Pro مورد نظر یافت نشد.');

  if (existing.mode === 'live') {
    if (!existing.startedAt && !confirmLive) {
      throw new Error('برای شروع ربات AI Cycle Pro در حساب واقعی، تأیید صریح کاربر الزامی است.');
    }
    if (!(await hasActiveExchangeCredentialsForUser(userId))) {
      throw new Error('کلید API نوبیتکس برای معاملات واقعی ثبت نشده است.');
    }
  }

  aicpRetryAfterMap.delete(botId);
  aicpLastRunMap.delete(botId);

  const now = Date.now();
  const nextStatus: AiCycleProStatus = existing.activePosition ? 'HOLDING_POSITION' : 'ANALYZING';
  const nextReason = existing.activePosition
    ? 'ربات دوباره فعال شد و مدیریت معامله باز ادامه دارد.'
    : 'ربات فعال شد و در حال تحلیل بازار نوبیتکس برای یافتن نقطه ورود مناسب است.';

  const db = getDb();
  const [updated] = await db
    .update(schema.aiCycleProBots)
    .set({
      isActive: true,
      status: nextStatus,
      lastError: null,
      lastStatusReason: nextReason,
      startedAt: existing.startedAt || now,
      updatedAt: now,
    })
    .where(and(eq(schema.aiCycleProBots.id, botId), eq(schema.aiCycleProBots.userId, userId)))
    .returning();

  const mapped = mapAiCycleProRow(updated);
  await appendAiCycleLog(userId, {
    botId,
    cycleIndex: mapped.stats.completedCycles,
    status: nextStatus,
    event: 'INFO',
    price: mapped.lastPrice,
    message: nextReason,
    timestamp: now,
  });
  return mapped;
}

export async function stopAiCycleProBot(
  userId: string,
  botId: string,
  reason?: string
): Promise<AiCycleProConfig> {
  const existing = await getUserAiCycleProBotById(userId, botId);
  if (!existing) throw new Error('ربات AI Cycle Pro مورد نظر یافت نشد.');

  const now = Date.now();
  const nextReason = reason || 'ربات AI Cycle Pro به دستور کاربر متوقف شد.';
  const db = getDb();
  const [updated] = await db
    .update(schema.aiCycleProBots)
    .set({
      isActive: false,
      status: 'STOPPED',
      lastStatusReason: nextReason,
      updatedAt: now,
    })
    .where(and(eq(schema.aiCycleProBots.id, botId), eq(schema.aiCycleProBots.userId, userId)))
    .returning();

  const mapped = mapAiCycleProRow(updated);
  await appendAiCycleLog(userId, {
    botId,
    cycleIndex: mapped.stats.completedCycles,
    status: 'STOPPED',
    event: 'STOPPED',
    price: mapped.lastPrice,
    message: nextReason,
    timestamp: now,
  });
  return mapped;
}

export async function deleteAiCycleProBot(userId: string, botId: string): Promise<void> {
  const db = getDb();
  await db
    .delete(schema.aiCycleProBots)
    .where(and(eq(schema.aiCycleProBots.id, botId), eq(schema.aiCycleProBots.userId, userId)));
}

export async function emergencyStopUserAiCycleProBots(userId: string): Promise<number> {
  const db = getDb();
  const now = Date.now();
  const updated = await db
    .update(schema.aiCycleProBots)
    .set({
      isActive: false,
      status: 'STOPPED',
      lastStatusReason: 'توقف اضطراری سراسری (Kill Switch)',
      updatedAt: now,
    })
    .where(
      and(eq(schema.aiCycleProBots.userId, userId), eq(schema.aiCycleProBots.isActive, true))
    )
    .returning();
  return updated.length;
}

export async function emergencyStopAllAiCycleProBots(actorEmail: string): Promise<number> {
  const db = getDb();
  const now = Date.now();
  const updated = await db
    .update(schema.aiCycleProBots)
    .set({
      isActive: false,
      status: 'STOPPED',
      lastStatusReason: `توقف اضطراری سراسری توسط مدیر (${actorEmail})`,
      updatedAt: now,
    })
    .where(eq(schema.aiCycleProBots.isActive, true))
    .returning();
  return updated.length;
}

export async function previewAiCycleProMarket(
  params: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    capitalAmount: number;
    capitalUsageMode?: AiCycleProCapitalUsageMode;
    capitalPortionPercent?: number;
    minTargetNetProfitPercent?: number;
    stopLossPercent?: number;
    maxSlippagePercent?: number;
    maxSpreadPercent?: number;
    feeRate?: number;
  },
  depsOverride?: Partial<AiCycleProRuntimeDeps>
): Promise<AiCycleProMarketPreview> {
  const deps = { ...createAiCycleProRuntimeDeps(), ...(depsOverride || {}) };
  const baseAsset = params.baseAsset.toUpperCase().trim();
  const quoteCurrency: QuoteCurrency = params.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
  const symbol = `${baseAsset}${quoteCurrency}`;
  const feeRate = params.feeRate ?? DEFAULT_NOBITEX_FEE_RATE;

  const [marketRes, orderBook, candles15, candles1h] = await Promise.all([
    deps.fetchMarkets().catch(() => ({ markets: [], usdtTomanRate: 0 })),
    deps.fetchOrderBook(symbol, 35),
    deps.fetchKlines(symbol, '15m', 120).catch(() => []),
    deps.fetchKlines(symbol, '1h', 120).catch(() => []),
  ]);

  const market =
    marketRes.markets.find((m) => m.baseAsset.toUpperCase() === baseAsset) || null;
  const snap15 = candles15.length >= 26 ? analyzeCandles(symbol, '15m', candles15) : null;
  const snap1h = candles1h.length >= 26 ? analyzeCandles(symbol, '1h', candles1h) : null;

  const capitalAmount = Math.max(
    getMinimumOrderNotional(quoteCurrency),
    Number(params.capitalAmount || 0)
  );
  const capitalUsageMode: AiCycleProCapitalUsageMode =
    params.capitalUsageMode === 'PARTIAL' ? 'PARTIAL' : 'FULL';
  const capitalPortionPercent =
    capitalUsageMode === 'PARTIAL'
      ? Math.min(100, Math.max(10, Number(params.capitalPortionPercent ?? 50)))
      : 100;
  const effectiveEntryQuote = roundQuoteValue(
    (capitalAmount * capitalPortionPercent) / 100,
    quoteCurrency
  );

  const buySim = simulateOrderBookBuy(orderBook, effectiveEntryQuote, feeRate);
  const bestAsk = orderBook.asks[0]?.price || orderBook.lastTradePrice || 0;
  const bestBid = orderBook.bids[0]?.price || orderBook.lastTradePrice || 0;
  const currentPrice =
    (quoteCurrency === 'IRT' ? market?.priceToman : market?.priceUsdt) ||
    orderBook.lastTradePrice ||
    bestAsk ||
    bestBid ||
    0;

  const estBoughtNetQty =
    buySim.netQtyReceived > 0
      ? buySim.netQtyReceived
      : buySim.avgBuyPrice > 0
        ? (effectiveEntryQuote / buySim.avgBuyPrice) * (1 - feeRate)
        : 0;
  const sellSim = simulateOrderBookSell(
    orderBook,
    estBoughtNetQty,
    effectiveEntryQuote,
    0,
    feeRate
  );
  const bidDepthQuote = orderBook.bids.reduce((s, b) => s + b.price * b.quantity, 0);
  const askDepthQuote = orderBook.asks.reduce((s, a) => s + a.price * a.quantity, 0);

  const decision = await deps.analyzeMarket({
    symbol,
    baseAsset,
    quoteCurrency,
    capitalAmount,
    capitalUsageMode,
    capitalPortionPercent,
    minTargetNetProfitPercent: params.minTargetNetProfitPercent ?? 1.2,
    stopLossPercent: params.stopLossPercent ?? 3.0,
    maxSlippagePercent: params.maxSlippagePercent ?? 0.6,
    maxSpreadPercent: params.maxSpreadPercent ?? 2.5,
    feeRate,
    market,
    snapshot15m: snap15,
    snapshot1h: snap1h,
    orderBook,
    bidDepthQuote,
    askDepthQuote,
    buySlippagePercent: buySim.slippagePercent,
    sellSlippagePercent: sellSim.slippagePercent,
    canFillBuyFull: buySim.canFillFull,
    hasSufficientSellDepth: sellSim.hasSufficientDepth,
    executableBuyPrice: buySim.avgBuyPrice || bestAsk || currentPrice,
    executableSellPrice: sellSim.executableAvgSellPrice || bestBid || currentPrice,
    now: deps.now(),
  });

  return {
    symbol,
    baseAsset,
    quoteCurrency,
    currentPrice,
    bestBid,
    bestAsk,
    spreadPercent: orderBook.spreadPercent,
    bidDepthQuote,
    askDepthQuote,
    estimatedBuySlippagePercent: buySim.slippagePercent,
    estimatedSellSlippagePercent: sellSim.slippagePercent,
    decision,
  };
}

function isRateLimitErr(err: unknown): boolean {
  if (err instanceof NobitexRateLimitError) return true;
  const msg = err instanceof Error ? err.message : String(err || '');
  return (
    msg.includes('429') ||
    msg.includes('تعداد درخواست') ||
    msg.includes('محدودیت موقت') ||
    msg.toLowerCase().includes('too many requests')
  );
}

function computeTargetSellPriceForPct(
  netOwnedQty: number,
  totalBuyCostQuote: number,
  targetNetProfitPercent: number,
  feeRate: number,
  quoteCurrency: QuoteCurrency
): number {
  if (netOwnedQty <= 0 || totalBuyCostQuote <= 0) return 0;
  const feeFactor = Math.max(0.85, 1 - feeRate);
  const grossProceedsNeeded =
    (totalBuyCostQuote * (1 + targetNetProfitPercent / 100)) / feeFactor;
  const raw = grossProceedsNeeded / netOwnedQty;
  return quoteCurrency === 'IRT' ? Math.ceil(raw) : Number(raw.toFixed(6));
}

export async function finalizeAiCycleProSell(input: {
  bot: AiCycleProConfig;
  pos: AiCycleProPosition;
  sellOrder: SpotOrder;
  exitReason: AiCycleProCycleRecord['exitReason'];
  aiExitSummaryFa: string;
  slippagePercent: number;
  completedAt: number;
}): Promise<{ bot: AiCycleProConfig; cycle: AiCycleProCycleRecord }> {
  const { bot, pos, sellOrder, exitReason, completedAt } = input;
  const userId = bot.ownerId || '';
  const feeRate = bot.feeRate ?? DEFAULT_NOBITEX_FEE_RATE;
  const soldQty = sellOrder.executedQty > 0 ? sellOrder.executedQty : pos.netOwnedQty;
  const actualSellAvgPrice = sellOrder.price;
  const grossSellProceedsQuote =
    sellOrder.totalQuoteAmount > 0
      ? sellOrder.totalQuoteAmount
      : soldQty * actualSellAvgPrice;
  const sellFeeQuote = roundQuoteValue(
    grossSellProceedsQuote * feeRate,
    bot.quoteCurrency
  );
  const finalNetProfitQuote = roundQuoteValue(
    grossSellProceedsQuote - sellFeeQuote - pos.totalBuyCostQuote,
    bot.quoteCurrency
  );

  const cycle: AiCycleProCycleRecord = {
    id: `aicpcyc-${completedAt}-${crypto.randomBytes(3).toString('hex')}`,
    botId: bot.id,
    cycleIndex: pos.cycleIndex,
    symbol: bot.symbol,
    baseAsset: bot.baseAsset,
    quoteCurrency: bot.quoteCurrency,
    mode: bot.mode,
    entryAmountQuote: pos.totalBuyCostQuote,
    actualBuyAvgPrice: pos.actualBuyAvgPrice,
    boughtQty: pos.netOwnedQty,
    buyFeeQuote: pos.buyFeeQuote,
    totalBuyCostQuote: pos.totalBuyCostQuote,
    actualSellAvgPrice,
    soldQty,
    grossSellProceedsQuote,
    sellFeeQuote,
    finalNetProfitQuote,
    targetNetProfitPercent: pos.targetNetProfitPercent,
    slippagePercent: Number(input.slippagePercent.toFixed(3)),
    exitReason,
    aiEntrySummaryFa: bot.lastDecision?.reasoningFa || 'ورود هوشمند تاییدشده',
    aiExitSummaryFa: input.aiExitSummaryFa,
    startedAt: pos.buyFilledAt,
    completedAt,
  };

  const db = getDb();
  await db.insert(schema.aiCycleProCycles).values({
    id: cycle.id,
    botId: cycle.botId,
    userId,
    cycleIndex: cycle.cycleIndex,
    symbol: cycle.symbol,
    baseAsset: cycle.baseAsset,
    quoteCurrency: cycle.quoteCurrency,
    mode: cycle.mode,
    entryAmountQuote: cycle.entryAmountQuote,
    actualBuyAvgPrice: cycle.actualBuyAvgPrice,
    boughtQty: cycle.boughtQty,
    buyFeeQuote: cycle.buyFeeQuote,
    totalBuyCostQuote: cycle.totalBuyCostQuote,
    actualSellAvgPrice: cycle.actualSellAvgPrice,
    soldQty: cycle.soldQty,
    grossSellProceedsQuote: cycle.grossSellProceedsQuote,
    sellFeeQuote: cycle.sellFeeQuote,
    finalNetProfitQuote: cycle.finalNetProfitQuote,
    targetNetProfitPercent: cycle.targetNetProfitPercent,
    slippagePercent: cycle.slippagePercent,
    exitReason: cycle.exitReason,
    aiEntrySummaryFa: cycle.aiEntrySummaryFa,
    aiExitSummaryFa: cycle.aiExitSummaryFa,
    startedAt: cycle.startedAt,
    completedAt: cycle.completedAt,
  });

  const nextStats: AiCycleProStats = {
    ...bot.stats,
    completedCycles: bot.stats.completedCycles + 1,
    winningCycles: bot.stats.winningCycles + (finalNetProfitQuote >= 0 ? 1 : 0),
    losingCycles: bot.stats.losingCycles + (finalNetProfitQuote < 0 ? 1 : 0),
    totalNetProfitQuote: roundQuoteValue(
      bot.stats.totalNetProfitQuote + finalNetProfitQuote,
      bot.quoteCurrency
    ),
    totalFeesPaidQuote: roundQuoteValue(
      bot.stats.totalFeesPaidQuote + pos.buyFeeQuote + sellFeeQuote,
      bot.quoteCurrency
    ),
    currentCapitalInvolved: 0,
  };

  const nextDaily = normalizeDailyStats(bot.dailyStats, completedAt);
  nextDaily.tradesCount += 1;
  nextDaily.netProfitQuote = roundQuoteValue(
    nextDaily.netProfitQuote + finalNetProfitQuote,
    bot.quoteCurrency
  );
  if (finalNetProfitQuote < 0) {
    nextDaily.lossQuote = roundQuoteValue(
      nextDaily.lossQuote + Math.abs(finalNetProfitQuote),
      bot.quoteCurrency
    );
  }

  const dailyLossBreached =
    bot.maxDailyLoss > 0 && nextDaily.lossQuote >= bot.maxDailyLoss;
  const shouldKeepRunning =
    bot.autoRepeatCycles &&
    !dailyLossBreached &&
    exitReason !== 'DAILY_LOSS_CAP' &&
    exitReason !== 'MANUAL_SELL';

  const nextStatus: AiCycleProStatus = dailyLossBreached
    ? 'PAUSED_RISK'
    : shouldKeepRunning
      ? 'ANALYZING'
      : 'STOPPED';

  const nextReason = dailyLossBreached
    ? `سقف زیان روزانه (${formatQuoteShort(bot.maxDailyLoss, bot.quoteCurrency)}) پر شد و ربات متوقف گردید.`
    : shouldKeepRunning
      ? `چرخه ${cycle.cycleIndex} کامل شد · سود/زیان خالص: ${
          finalNetProfitQuote >= 0 ? '+' : ''
        }${formatQuoteShort(finalNetProfitQuote, bot.quoteCurrency)} · در حال تحلیل برای چرخه بعدی`
      : `فروش تکمیل شد (${exitReason}) · سود/زیان خالص: ${
          finalNetProfitQuote >= 0 ? '+' : ''
        }${formatQuoteShort(finalNetProfitQuote, bot.quoteCurrency)}`;

  await db
    .update(schema.aiCycleProBots)
    .set({
      isActive: shouldKeepRunning,
      status: nextStatus,
      activePositionJson: null,
      pendingOrderJson: null,
      statsJson: nextStats,
      dailyStatsJson: nextDaily,
      lastPrice: actualSellAvgPrice,
      lastStatusReason: nextReason,
      lastError: null,
      lastCheckedAt: completedAt,
      updatedAt: completedAt,
    })
    .where(eq(schema.aiCycleProBots.id, bot.id));

  await appendAiCycleLog(userId, {
    botId: bot.id,
    cycleIndex: cycle.cycleIndex,
    status: nextStatus,
    event: exitReason === 'STOP_LOSS' ? 'STOP_LOSS' : 'SELL_FILLED',
    price: actualSellAvgPrice,
    netProfitQuote: finalNetProfitQuote,
    message: `فروش چرخه ${cycle.cycleIndex} در قیمت ${formatQuoteShort(
      actualSellAvgPrice,
      bot.quoteCurrency
    )} انجام شد · خالص: ${
      finalNetProfitQuote >= 0 ? '+' : ''
    }${formatQuoteShort(finalNetProfitQuote, bot.quoteCurrency)} · کارمزد کل: ${formatQuoteShort(
      pos.buyFeeQuote + sellFeeQuote,
      bot.quoteCurrency
    )}`,
    timestamp: completedAt,
  });

  const refreshed = (await getUserAiCycleProBotById(userId, bot.id))!;
  void notifyAiCycleTelegram(
    userId,
    refreshed,
    exitReason === 'STOP_LOSS' ? '🛡️ خروج با حد ضرر' : '💰 تکمیل چرخه هوشمند',
    nextReason
  );

  return { bot: refreshed, cycle };
}

export async function evaluateAiCycleProBot(
  bot: AiCycleProConfig,
  depsOverride?: Partial<AiCycleProRuntimeDeps>
): Promise<AiCycleProConfig> {
  const userId = bot.ownerId || '';
  if (!userId || !bot.isActive) return bot;

  const deps = { ...createAiCycleProRuntimeDeps(), ...(depsOverride || {}) };
  const now = deps.now();
  const db = getDb();
  aicpLastRunMap.set(bot.id, now);

  const dailyStats = normalizeDailyStats(bot.dailyStats, now);

  try {
    const smartMgr = await import('./smartBotManager.ts');
    const riskSettings = await smartMgr.getUserBotRiskSettings(userId);

    // 1. Kill switch check
    if (riskSettings.killSwitchActive) {
      const reason = 'کلید توقف اضطراری (Kill Switch) فعال است؛ عملیات متوقف شد.';
      await db
        .update(schema.aiCycleProBots)
        .set({
          isActive: false,
          status: 'STOPPED',
          dailyStatsJson: dailyStats,
          lastStatusReason: reason,
          lastCheckedAt: now,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));
      await appendAiCycleLog(userId, {
        botId: bot.id,
        cycleIndex: bot.stats.completedCycles,
        status: 'STOPPED',
        event: 'RISK_HALT',
        price: bot.lastPrice,
        message: reason,
        timestamp: now,
      });
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    // 2. Daily loss cap check when no open position
    if (!bot.activePosition && bot.maxDailyLoss > 0 && dailyStats.lossQuote >= bot.maxDailyLoss) {
      const reason = `سقف زیان روزانه (${formatQuoteShort(
        bot.maxDailyLoss,
        bot.quoteCurrency
      )}) تکمیل شده است؛ خرید جدید تا فردا متوقف شد.`;
      await db
        .update(schema.aiCycleProBots)
        .set({
          isActive: false,
          status: 'PAUSED_RISK',
          dailyStatsJson: dailyStats,
          lastStatusReason: reason,
          lastCheckedAt: now,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));
      await appendAiCycleLog(userId, {
        botId: bot.id,
        cycleIndex: bot.stats.completedCycles,
        status: 'PAUSED_RISK',
        event: 'RISK_HALT',
        price: bot.lastPrice,
        message: reason,
        timestamp: now,
      });
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    // 3. Fetch live market, orderbook, rules, and candles
    const [marketRes, orderBook, marketRules, candles15, candles1h] = await Promise.all([
      deps.fetchMarkets().catch(() => ({ markets: [], usdtTomanRate: 0 })),
      deps.fetchOrderBook(bot.symbol, 35),
      deps.getMarketRules(bot.symbol).catch(() => ({
        minNotional: getMinimumOrderNotional(bot.quoteCurrency),
        amountStep: 1e-6,
      })),
      deps.fetchKlines(bot.symbol, '15m', 120).catch(() => []),
      deps.fetchKlines(bot.symbol, '1h', 120).catch(() => []),
    ]);

    const market =
      marketRes.markets.find((m) => m.baseAsset.toUpperCase() === bot.baseAsset.toUpperCase()) ||
      null;
    const bestAsk = orderBook.asks[0]?.price || orderBook.lastTradePrice || 0;
    const bestBid = orderBook.bids[0]?.price || orderBook.lastTradePrice || 0;
    const currentPrice =
      (bot.quoteCurrency === 'IRT' ? market?.priceToman : market?.priceUsdt) ||
      orderBook.lastTradePrice ||
      bestAsk ||
      bestBid ||
      0;

    if (currentPrice <= 0) {
      await db
        .update(schema.aiCycleProBots)
        .set({
          lastCheckedAt: now,
          dailyStatsJson: dailyStats,
          lastStatusReason: 'در انتظار دریافت قیمت زنده و دفتر سفارش از نوبیتکس',
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    const snap15 = candles15.length >= 26 ? analyzeCandles(bot.symbol, '15m', candles15) : null;
    const snap1h = candles1h.length >= 26 ? analyzeCandles(bot.symbol, '1h', candles1h) : null;
    const bidDepthQuote = orderBook.bids.reduce((s, b) => s + b.price * b.quantity, 0);
    const askDepthQuote = orderBook.asks.reduce((s, a) => s + a.price * a.quantity, 0);
    const feeRate = bot.feeRate ?? DEFAULT_NOBITEX_FEE_RATE;

    // -------------------------------------------------------------------
    // CASE A: ACTIVE POSITION (MANAGE & EXIT)
    // -------------------------------------------------------------------
    if (bot.activePosition) {
      const pos: AiCycleProPosition = { ...bot.activePosition };
      if (currentPrice > pos.highestPrice) {
        pos.highestPrice = currentPrice;
      }

      const sellQty = roundQuantityToStep(pos.netOwnedQty, marketRules.amountStep, 'floor');
      const targetNetQuote = pos.totalBuyCostQuote * (pos.targetNetProfitPercent / 100);
      const sellSim = simulateOrderBookSell(
        orderBook,
        sellQty > 0 ? sellQty : pos.netOwnedQty,
        pos.totalBuyCostQuote,
        targetNetQuote,
        feeRate
      );
      const execSellPrice = sellSim.executableAvgSellPrice || bestBid || currentPrice;
      const estGrossProceeds = (sellQty > 0 ? sellQty : pos.netOwnedQty) * execSellPrice;
      const estSellFee = estGrossProceeds * feeRate;
      const estNetPnl = roundQuoteValue(
        estGrossProceeds - estSellFee - pos.totalBuyCostQuote,
        bot.quoteCurrency
      );
      const estNetPct =
        pos.totalBuyCostQuote > 0 ? (estNetPnl / pos.totalBuyCostQuote) * 100 : 0;

      pos.lastEstimatedExecutableSellPrice = execSellPrice;
      pos.lastEstimatedNetProfitQuote = estNetPnl;
      pos.lastEstimatedSlippagePercent = sellSim.slippagePercent;
      pos.lastSpreadPercent = orderBook.spreadPercent;
      pos.lastEvaluatedAt = now;

      let exitReason: AiCycleProCycleRecord['exitReason'] | null = null;
      let aiDecision: AiCycleProDecision | null = bot.lastDecision;

      // 1) Hard Stop-Loss guard
      if (pos.stopLossPrice > 0 && currentPrice <= pos.stopLossPrice) {
        exitReason = 'STOP_LOSS';
      }
      // 2) Daily Loss Cap protection while holding
      else if (
        bot.maxDailyLoss > 0 &&
        estNetPnl < 0 &&
        dailyStats.lossQuote + Math.abs(estNetPnl) >= bot.maxDailyLoss
      ) {
        exitReason = 'DAILY_LOSS_CAP';
      }
      // 3) Target Net Profit reached (verified against live orderbook & fees)
      else if (estNetPct >= pos.targetNetProfitPercent && sellSim.hasSufficientDepth) {
        exitReason = 'AI_TARGET_PROFIT';
      }
      // 4) Ask Gemini / AI Analyzer if market deteriorated enough to take available profit
      else {
        aiDecision = await deps.analyzeMarket({
          symbol: bot.symbol,
          baseAsset: bot.baseAsset,
          quoteCurrency: bot.quoteCurrency,
          capitalAmount: bot.capitalAmount,
          capitalUsageMode: bot.capitalUsageMode,
          capitalPortionPercent: bot.capitalPortionPercent,
          minTargetNetProfitPercent: bot.minTargetNetProfitPercent,
          stopLossPercent: bot.stopLossPercent,
          maxSlippagePercent: bot.maxSlippagePercent,
          maxSpreadPercent: bot.maxSpreadPercent,
          feeRate,
          market,
          snapshot15m: snap15,
          snapshot1h: snap1h,
          orderBook,
          bidDepthQuote,
          askDepthQuote,
          buySlippagePercent: 0,
          sellSlippagePercent: sellSim.slippagePercent,
          canFillBuyFull: true,
          hasSufficientSellDepth: sellSim.hasSufficientDepth,
          executableBuyPrice: bestAsk || currentPrice,
          executableSellPrice: execSellPrice,
          activePosition: pos,
          now,
        });
        if (aiDecision.action === 'SELL' && sellSim.hasSufficientDepth) {
          exitReason = 'AI_TARGET_PROFIT';
        }
      }

      if (exitReason && sellQty > 0 && sellQty * execSellPrice >= marketRules.minNotional) {
        if (
          bot.executionConfirmationMode === 'MANUAL_CONFIRM' &&
          exitReason !== 'STOP_LOSS' &&
          exitReason !== 'DAILY_LOSS_CAP'
        ) {
          await smartMgr.createPendingConfirmation({
            userId,
            botId: bot.id,
            botType: 'AI_CYCLE_PRO',
            botName: bot.name,
            symbol: bot.symbol,
            baseAsset: bot.baseAsset,
            quoteCurrency: bot.quoteCurrency,
            mode: bot.mode,
            side: 'SELL',
            orderType: 'MARKET',
            suggestedPrice: execSellPrice,
            quantity: sellQty,
            quoteAmount: estGrossProceeds,
            estimatedFeeQuote: estSellFee,
            reasonFa:
              aiDecision?.reasoningFa ||
              `تحقق هدف فروش چرخه ${pos.cycleIndex} (بازده خالص +${estNetPct.toFixed(2)}٪)`,
            riskSummaryFa: `سود/زیان خالص برآوردی پس از کارمزد و لغزش: ${
              estNetPnl >= 0 ? '+' : ''
            }${formatQuoteShort(estNetPnl, bot.quoteCurrency)}`,
            metaJson: {
              cycleIndex: pos.cycleIndex,
              exitReason,
              slippagePercent: sellSim.slippagePercent,
              aiExitSummaryFa: aiDecision?.reasoningFa || 'خروج با تأیید دستی کاربر',
            },
          });

          const reason = `در انتظار تأیید دستی شما برای فروش چرخه ${pos.cycleIndex} در قیمت ${formatQuoteShort(
            execSellPrice,
            bot.quoteCurrency
          )}`;
          await db
            .update(schema.aiCycleProBots)
            .set({
              status: 'HOLDING_POSITION',
              activePositionJson: pos,
              lastDecisionJson: aiDecision,
              dailyStatsJson: dailyStats,
              lastPrice: currentPrice,
              lastStatusReason: reason,
              lastCheckedAt: now,
              updatedAt: now,
            })
            .where(eq(schema.aiCycleProBots.id, bot.id));
          return (await getUserAiCycleProBotById(userId, bot.id))!;
        }

        const sellOrder = await deps.placeOrder(userId, bot, {
          side: 'SELL',
          quantity: sellQty,
          price: execSellPrice,
          idempotencyKey: `aicp:${bot.id}:c${pos.cycleIndex}:sell`,
          realizedPnlQuote: estNetPnl,
        });

        const exitSummary =
          exitReason === 'STOP_LOSS'
            ? `حد ضرر (-${bot.stopLossPercent}٪) فعال شد.`
            : exitReason === 'DAILY_LOSS_CAP'
              ? 'خروج حفاظتی به دلیل نزدیکی به سقف زیان روزانه.'
              : aiDecision?.reasoningFa || 'تحقق هدف سود خالص پس از کارمزد و لغزش دفتر سفارش.';

        const finalized = await finalizeAiCycleProSell({
          bot: { ...bot, lastDecision: aiDecision, dailyStats },
          pos,
          sellOrder,
          exitReason,
          aiExitSummaryFa: exitSummary,
          slippagePercent: sellSim.slippagePercent,
          completedAt: now,
        });
        aicpRetryAfterMap.delete(bot.id);
        return finalized.bot;
      }

      // Still holding position
      const holdReason = `پوزیشن چرخه ${pos.cycleIndex} باز است · بازده خالص فعلی: ${
        estNetPct >= 0 ? '+' : ''
      }${estNetPct.toFixed(2)}٪ (هدف: +${pos.targetNetProfitPercent.toFixed(
        2
      )}٪ | حد ضرر: ${formatQuoteShort(pos.stopLossPrice, bot.quoteCurrency)})`;

      await db
        .update(schema.aiCycleProBots)
        .set({
          status: 'HOLDING_POSITION',
          activePositionJson: pos,
          lastDecisionJson: aiDecision,
          dailyStatsJson: dailyStats,
          lastPrice: currentPrice,
          lastStatusReason: holdReason,
          lastError: null,
          lastCheckedAt: now,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));

      aicpRetryAfterMap.delete(bot.id);
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    // -------------------------------------------------------------------
    // CASE B: NO ACTIVE POSITION (ANALYZE MARKET & ENTER ONLY IF FAVORABLE)
    // -------------------------------------------------------------------
    if (bot.pendingOrder) {
      // Do not consume reserved capital if a pending order exists
      await db
        .update(schema.aiCycleProBots)
        .set({
          lastCheckedAt: now,
          dailyStatsJson: dailyStats,
          lastStatusReason: 'سفارش باز در حال پیگیری است؛ سرمایه جدید مصرف نمی‌شود.',
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    const basePortion =
      bot.capitalUsageMode === 'PARTIAL' ? Math.min(100, Math.max(10, bot.capitalPortionPercent)) : 100;
    const probeQuote = roundQuoteValue((bot.capitalAmount * basePortion) / 100, bot.quoteCurrency);
    const buySim = simulateOrderBookBuy(orderBook, probeQuote, feeRate);
    const estBoughtNet =
      buySim.netQtyReceived > 0
        ? buySim.netQtyReceived
        : buySim.avgBuyPrice > 0
          ? (probeQuote / buySim.avgBuyPrice) * (1 - feeRate)
          : 0;
    const sellDepthSim = simulateOrderBookSell(orderBook, estBoughtNet, probeQuote, 0, feeRate);

    const decision = await deps.analyzeMarket({
      symbol: bot.symbol,
      baseAsset: bot.baseAsset,
      quoteCurrency: bot.quoteCurrency,
      capitalAmount: bot.capitalAmount,
      capitalUsageMode: bot.capitalUsageMode,
      capitalPortionPercent: bot.capitalPortionPercent,
      minTargetNetProfitPercent: bot.minTargetNetProfitPercent,
      stopLossPercent: bot.stopLossPercent,
      maxSlippagePercent: bot.maxSlippagePercent,
      maxSpreadPercent: bot.maxSpreadPercent,
      feeRate,
      market,
      snapshot15m: snap15,
      snapshot1h: snap1h,
      orderBook,
      bidDepthQuote,
      askDepthQuote,
      buySlippagePercent: buySim.slippagePercent,
      sellSlippagePercent: sellDepthSim.slippagePercent,
      canFillBuyFull: buySim.canFillFull,
      hasSufficientSellDepth: sellDepthSim.hasSufficientDepth,
      executableBuyPrice: buySim.avgBuyPrice || bestAsk || currentPrice,
      executableSellPrice: sellDepthSim.executableAvgSellPrice || bestBid || currentPrice,
      now,
    });

    // If AI says HOLD_CASH or market condition is UNFAVORABLE => Keep funds in cash!
    if (decision.action !== 'BUY' || decision.marketCondition === 'UNFAVORABLE') {
      const waitMsg = decision.reasoningFa || 'شرایط بازار فعلاً مناسب ورود نیست؛ سرمایه نقد ماند.';
      const shouldAppendWaitLog =
        bot.status !== 'WAITING_CASH' || bot.lastStatusReason !== waitMsg;

      await db
        .update(schema.aiCycleProBots)
        .set({
          status: 'WAITING_CASH',
          lastDecisionJson: decision,
          dailyStatsJson: dailyStats,
          lastPrice: currentPrice,
          lastStatusReason: waitMsg,
          lastError: null,
          lastCheckedAt: now,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));

      if (shouldAppendWaitLog) {
        await appendAiCycleLog(userId, {
          botId: bot.id,
          cycleIndex: bot.stats.completedCycles + 1,
          status: 'WAITING_CASH',
          event: 'WAIT_CASH',
          price: currentPrice,
          message: waitMsg,
          timestamp: now,
        });
      }

      aicpRetryAfterMap.delete(bot.id);
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    // Capital & Exchange Minimum Constraints
    const effectivePortion =
      bot.capitalUsageMode === 'PARTIAL'
        ? Math.min(basePortion, decision.recommendedCapitalPortionPercent || basePortion)
        : Math.min(100, decision.recommendedCapitalPortionPercent || 100);
    const targetBuyQuote = Math.min(
      bot.capitalAmount,
      roundQuoteValue((bot.capitalAmount * Math.max(10, effectivePortion)) / 100, bot.quoteCurrency)
    );

    const execBuyPrice = buySim.avgBuyPrice || bestAsk || currentPrice;
    const minNotional = Math.max(
      getMinimumOrderNotional(bot.quoteCurrency),
      marketRules.minNotional || 0
    );
    if (targetBuyQuote + 1e-6 < minNotional) {
      const reason = `مبلغ اختصاص‌یافته کمتر از حداقل سفارش صرافی (${formatQuoteShort(
        minNotional,
        bot.quoteCurrency
      )}) است؛ سرمایه نقد ماند.`;
      await db
        .update(schema.aiCycleProBots)
        .set({
          status: 'WAITING_CASH',
          lastDecisionJson: decision,
          dailyStatsJson: dailyStats,
          lastPrice: currentPrice,
          lastStatusReason: reason,
          lastCheckedAt: now,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    // Shared Risk Governance check
    const guard = await smartMgr.validateSharedExecutionGuards({
      userId,
      botId: bot.id,
      botType: 'AI_CYCLE_PRO',
      symbol: bot.symbol,
      quoteCurrency: bot.quoteCurrency,
      side: 'BUY',
      requestedQuoteAmount: targetBuyQuote,
    });
    if (!guard.ok) {
      await db
        .update(schema.aiCycleProBots)
        .set({
          status: 'WAITING_CASH',
          lastDecisionJson: decision,
          dailyStatsJson: dailyStats,
          lastPrice: currentPrice,
          lastStatusReason: guard.reasonFa,
          lastCheckedAt: now,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    // Free wallet balance check
    const balances = await deps.getBalances(
      userId,
      bot.mode,
      marketRes.markets,
      marketRes.usdtTomanRate
    );
    const quoteBal = balances.find(
      (b) => b.asset.toUpperCase() === bot.quoteCurrency.toUpperCase()
    );
    const freeQuote = Number(quoteBal?.free || 0);
    if (freeQuote + 1e-6 < targetBuyQuote) {
      const reason = `موجودی آزاد ${
        bot.quoteCurrency === 'IRT' ? 'تومانی' : 'USDT'
      } کافی نیست (آزاد: ${formatQuoteShort(freeQuote, bot.quoteCurrency)} / نیاز: ${formatQuoteShort(
        targetBuyQuote,
        bot.quoteCurrency
      )}).`;
      await db
        .update(schema.aiCycleProBots)
        .set({
          status: 'WAITING_CASH',
          lastDecisionJson: decision,
          dailyStatsJson: dailyStats,
          lastPrice: currentPrice,
          lastStatusReason: reason,
          lastCheckedAt: now,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    const qtyRes = resolveOrderQuantityForNotional({
      entryAmount: targetBuyQuote,
      buyPrice: execBuyPrice,
      minNotional,
      step: marketRules.amountStep,
      freeQuote,
    });
    if (!qtyRes.ok || qtyRes.quantity <= 0) {
      const reason =
        qtyRes.reason || 'مقدار محاسبه‌شده برای ثبت سفارش با قوانین حجم صرافی سازگار نبود.';
      await db
        .update(schema.aiCycleProBots)
        .set({
          status: 'WAITING_CASH',
          lastDecisionJson: decision,
          dailyStatsJson: dailyStats,
          lastPrice: currentPrice,
          lastStatusReason: reason,
          lastCheckedAt: now,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    const cycleIndex = bot.stats.completedCycles + 1;
    const targetNetPct = Math.max(
      bot.minTargetNetProfitPercent,
      decision.recommendedTargetNetProfitPercent || bot.minTargetNetProfitPercent
    );
    const slPct = Math.min(bot.stopLossPercent, decision.recommendedStopLossPercent || bot.stopLossPercent);

    if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
      const estBuyFee = qtyRes.notional * feeRate;
      await smartMgr.createPendingConfirmation({
        userId,
        botId: bot.id,
        botType: 'AI_CYCLE_PRO',
        botName: bot.name,
        symbol: bot.symbol,
        baseAsset: bot.baseAsset,
        quoteCurrency: bot.quoteCurrency,
        mode: bot.mode,
        side: 'BUY',
        orderType: 'MARKET',
        suggestedPrice: execBuyPrice,
        quantity: qtyRes.quantity,
        quoteAmount: qtyRes.notional,
        estimatedFeeQuote: estBuyFee,
        reasonFa: decision.reasoningFa,
        riskSummaryFa: `مبلغ ورود: ${formatQuoteShort(
          qtyRes.notional,
          bot.quoteCurrency
        )} · هدف سود خالص: +${targetNetPct.toFixed(2)}٪ · حد ضرر: -${slPct.toFixed(2)}٪`,
        metaJson: {
          cycleIndex,
          targetNetProfitPercent: targetNetPct,
          stopLossPercent: slPct,
        },
      });

      const reason = `فرصت مناسب خرید شناسایی شد · در انتظار تأیید دستی شما برای چرخه ${cycleIndex}`;
      await db
        .update(schema.aiCycleProBots)
        .set({
          status: 'WAITING_CASH',
          lastDecisionJson: decision,
          dailyStatsJson: dailyStats,
          lastPrice: currentPrice,
          lastStatusReason: reason,
          lastCheckedAt: now,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.id, bot.id));
      await appendAiCycleLog(userId, {
        botId: bot.id,
        cycleIndex,
        status: 'WAITING_CASH',
        event: 'MANUAL_CONFIRM',
        price: execBuyPrice,
        message: reason,
        timestamp: now,
      });
      return (await getUserAiCycleProBotById(userId, bot.id))!;
    }

    // Place BUY order
    const buyOrder = await deps.placeOrder(userId, bot, {
      side: 'BUY',
      quantity: qtyRes.quantity,
      price: execBuyPrice,
      idempotencyKey: `aicp:${bot.id}:c${cycleIndex}:buy`,
    });

    const filledGrossQty = buyOrder.executedQty > 0 ? buyOrder.executedQty : buyOrder.quantity;
    const actualBuyAvgPrice =
      buyOrder.price > 0
        ? buyOrder.price
        : buyOrder.totalQuoteAmount > 0 && filledGrossQty > 0
          ? buyOrder.totalQuoteAmount / filledGrossQty
          : execBuyPrice;
    const totalBuyCostQuote = roundQuoteValue(
      buyOrder.totalQuoteAmount > 0
        ? buyOrder.totalQuoteAmount
        : filledGrossQty * actualBuyAvgPrice,
      bot.quoteCurrency
    );
    const buyFeeQuote = roundQuoteValue(totalBuyCostQuote * feeRate, bot.quoteCurrency);
    const netOwnedQty = filledGrossQty * (1 - feeRate);
    const targetSellPrice = computeTargetSellPriceForPct(
      netOwnedQty,
      totalBuyCostQuote,
      targetNetPct,
      feeRate,
      bot.quoteCurrency
    );
    const stopLossPrice = roundQuoteValue(
      actualBuyAvgPrice * (1 - slPct / 100),
      bot.quoteCurrency
    );

    const pos: AiCycleProPosition = {
      cycleIndex,
      buyOrderId: buyOrder.orderId,
      buyExchangeOrderId: buyOrder.mode === 'live' ? buyOrder.orderId : undefined,
      requestedQuoteAmount: qtyRes.notional,
      requestedQty: qtyRes.quantity,
      filledGrossQty,
      netOwnedQty,
      actualBuyAvgPrice,
      buyFeeQuote,
      totalBuyCostQuote,
      targetNetProfitPercent: targetNetPct,
      targetSellPrice,
      stopLossPrice,
      highestPrice: actualBuyAvgPrice,
      buyFilledAt: now,
      lastEstimatedExecutableSellPrice: actualBuyAvgPrice,
      lastEstimatedNetProfitQuote: roundQuoteValue(
        -(buyFeeQuote + totalBuyCostQuote * feeRate),
        bot.quoteCurrency
      ),
      lastEstimatedSlippagePercent: buySim.slippagePercent,
      lastSpreadPercent: orderBook.spreadPercent,
      lastEvaluatedAt: now,
    };

    const nextStats: AiCycleProStats = {
      ...bot.stats,
      currentCapitalInvolved: totalBuyCostQuote,
      lastBuyPrice: actualBuyAvgPrice,
    };
    const buySummary = `خرید چرخه ${cycleIndex} در ${formatQuoteShort(
      actualBuyAvgPrice,
      bot.quoteCurrency
    )} انجام شد · هدف فروش: ${formatQuoteShort(
      targetSellPrice,
      bot.quoteCurrency
    )} (+${targetNetPct.toFixed(2)}٪ خالص)`;

    await db
      .update(schema.aiCycleProBots)
      .set({
        status: 'HOLDING_POSITION',
        activePositionJson: pos,
        pendingOrderJson: null,
        lastDecisionJson: decision,
        dailyStatsJson: dailyStats,
        statsJson: nextStats,
        lastPrice: actualBuyAvgPrice,
        lastStatusReason: buySummary,
        lastError: null,
        lastCheckedAt: now,
        updatedAt: now,
      })
      .where(eq(schema.aiCycleProBots.id, bot.id));

    await appendAiCycleLog(userId, {
      botId: bot.id,
      cycleIndex,
      status: 'HOLDING_POSITION',
      event: 'BUY_FILLED',
      price: actualBuyAvgPrice,
      message: `${buySummary} · دلیل هوش مصنوعی: ${decision.reasoningFa}`,
      timestamp: now,
    });

    const updatedBot = (await getUserAiCycleProBotById(userId, bot.id))!;
    void notifyAiCycleTelegram(userId, updatedBot, '🟢 خرید هوشمند اجرا شد', buySummary);
    aicpRetryAfterMap.delete(bot.id);
    return updatedBot;
  } catch (err) {
    const rawMsg = err instanceof Error ? err.message : 'خطا در اجرای ربات AI Cycle Pro';
    const rateLimited = isRateLimitErr(err);
    const prev = aicpRetryAfterMap.get(bot.id);
    const failures = (prev?.failures || 0) + 1;
    const backoffMs = rateLimited
      ? err instanceof NobitexRateLimitError
        ? Math.max(25_000, err.retryAfterMs)
        : Math.min(90_000, 30_000 * 2 ** Math.min(2, failures - 1))
      : Math.min(60_000, 10_000 * 2 ** Math.min(2, failures - 1));
    aicpRetryAfterMap.set(bot.id, { until: Date.now() + backoffMs, failures });

    const friendlyMsg = rateLimited
      ? `محدودیت موقت تعداد درخواست نوبیتکس (429) — تلاش مجدد خودکار تا ${Math.ceil(
          backoffMs / 1000
        )} ثانیه دیگر`
      : rawMsg;

    await db
      .update(schema.aiCycleProBots)
      .set({
        lastError: friendlyMsg.slice(0, 400),
        lastStatusReason: rateLimited ? friendlyMsg : `خطا: ${friendlyMsg}`,
        lastCheckedAt: Date.now(),
        updatedAt: Date.now(),
      })
      .where(eq(schema.aiCycleProBots.id, bot.id));

    await appendAiCycleLog(userId, {
      botId: bot.id,
      cycleIndex: bot.stats.completedCycles,
      status: bot.status,
      event: 'ERROR',
      price: bot.lastPrice,
      message: friendlyMsg,
      timestamp: Date.now(),
    });
  }

  return (await getUserAiCycleProBotById(userId, bot.id))!;
}

export async function manualSellAiCycleProBot(
  userId: string,
  botId: string,
  depsOverride?: Partial<AiCycleProRuntimeDeps>
): Promise<AiCycleProConfig> {
  const bot = await getUserAiCycleProBotById(userId, botId);
  if (!bot) throw new Error('ربات AI Cycle Pro مورد نظر یافت نشد.');
  if (!bot.activePosition) {
    throw new Error('این ربات در حال حاضر پوزیشن خرید فعالی برای فروش ندارد.');
  }

  const deps = { ...createAiCycleProRuntimeDeps(), ...(depsOverride || {}) };
  const now = deps.now();
  const [orderBook, marketRules] = await Promise.all([
    deps.fetchOrderBook(bot.symbol, 35),
    deps.getMarketRules(bot.symbol).catch(() => ({
      minNotional: getMinimumOrderNotional(bot.quoteCurrency),
      amountStep: 1e-6,
    })),
  ]);

  const pos = bot.activePosition;
  const feeRate = bot.feeRate ?? DEFAULT_NOBITEX_FEE_RATE;
  const sellQty = roundQuantityToStep(pos.netOwnedQty, marketRules.amountStep, 'floor');
  const sellSim = simulateOrderBookSell(
    orderBook,
    sellQty > 0 ? sellQty : pos.netOwnedQty,
    pos.totalBuyCostQuote,
    pos.totalBuyCostQuote * (pos.targetNetProfitPercent / 100),
    feeRate
  );
  const execPrice =
    sellSim.executableAvgSellPrice || orderBook.bids[0]?.price || orderBook.lastTradePrice || bot.lastPrice;
  if (!(execPrice > 0)) {
    throw new Error('قیمت معتبر برای فروش دستی در دفتر سفارش یافت نشد.');
  }

  const gross = (sellQty > 0 ? sellQty : pos.netOwnedQty) * execPrice;
  const estPnl = roundQuoteValue(
    gross * (1 - feeRate) - pos.totalBuyCostQuote,
    bot.quoteCurrency
  );

  const sellOrder = await deps.placeOrder(userId, bot, {
    side: 'SELL',
    quantity: sellQty > 0 ? sellQty : pos.netOwnedQty,
    price: execPrice,
    idempotencyKey: `aicp:${bot.id}:c${pos.cycleIndex}:manual:${now}`,
    realizedPnlQuote: estPnl,
  });

  const finalized = await finalizeAiCycleProSell({
    bot,
    pos,
    sellOrder,
    exitReason: 'MANUAL_SELL',
    aiExitSummaryFa: 'فروش و بستن چرخه به دستور مستقیم کاربر انجام شد.',
    slippagePercent: sellSim.slippagePercent,
    completedAt: now,
  });

  return finalized.bot;
}

export async function runAllActiveAiCycleProBotsCycle(options?: {
  respectSchedule?: boolean;
  ownerOverride?: string;
}): Promise<{ evaluated: number }> {
  if (isEvaluatingAiCycleLocally) return { evaluated: 0 };

  const db = getDb();
  const rows = await db
    .select()
    .from(schema.aiCycleProBots)
    .where(eq(schema.aiCycleProBots.isActive, true));

  if (rows.length === 0) return { evaluated: 0 };

  const now = Date.now();
  const respectSchedule = Boolean(options?.respectSchedule);
  const globalRateLimitMs = getNobitexRateLimitRemainingMs();
  const dueBots: AiCycleProConfig[] = [];

  for (const r of rows) {
    const bot = mapAiCycleProRow(r);
    if (respectSchedule) {
      const retry = aicpRetryAfterMap.get(bot.id);
      if (retry && retry.until > now) continue;
      if (bot.mode === 'live' && globalRateLimitMs > 0) continue;
      const lastRun = Math.max(aicpLastRunMap.get(bot.id) || 0, bot.lastCheckedAt || 0);
      const minIntervalMs = Math.max(
        bot.mode === 'live' ? 12_000 : 5_000,
        (bot.pollIntervalSeconds || 15) * 1000
      );
      if (lastRun > 0 && now - lastRun < minIntervalMs - 250) {
        continue;
      }
    }
    dueBots.push(bot);
  }

  if (dueBots.length === 0) return { evaluated: 0 };

  const lockOwner = options?.ownerOverride || AI_CYCLE_WORKER_ID;
  const acquired = await acquireWorkerLock(AI_CYCLE_LOCK_NAME, lockOwner, 30_000);
  if (!acquired) return { evaluated: 0 };

  isEvaluatingAiCycleLocally = true;
  let evaluated = 0;
  try {
    for (const bot of dueBots) {
      await evaluateAiCycleProBot(bot);
      evaluated += 1;
    }
    return { evaluated };
  } finally {
    isEvaluatingAiCycleLocally = false;
    await releaseWorkerLock(AI_CYCLE_LOCK_NAME, lockOwner);
  }
}
