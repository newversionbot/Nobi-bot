import crypto from 'node:crypto';
import type { NextFunction, Response } from 'express';
import { and, desc, eq, gt, sql } from 'drizzle-orm';
import * as schema from '../src/db/schema.ts';
import type {
  AdminAuditEntry,
  AdminReferralRecord,
  AdminSystemStats,
  AppControlConfig,
  AppFeatureFlags,
  BotStrategyConfig,
  BroadcastMessage,
  BroadcastSeverity,
  DirectMessageRecord,
  ManagedUserSummary,
  ModuleAccessPolicy,
  ReferralInviteItem,
  UserReferralSummary,
} from '../src/types/trading.ts';
import { ensureUserRecord, getDb, withTransaction, type AppDatabase } from './db/index.ts';
import { logger } from './logger.ts';
import {
  decryptSecretText,
  encryptSecretText,
  getActiveTelegramCredentials,
  type AuthenticatedUser,
  type RequestWithUser,
} from './securityVault.ts';

export const BOOTSTRAP_ADMIN_EMAIL = 'shivamdonyam@gmail.com';
export const REFERRAL_REWARD_DAYS = 4;

export type BillingFetchLike = typeof fetch;
let activeBillingFetch: BillingFetchLike = globalThis.fetch;

export function setBillingFetchForTest(customFetch: BillingFetchLike | null): void {
  if (process.env.NODE_ENV === 'production' && customFetch) {
    throw new Error('Cannot override billing fetch in production.');
  }
  activeBillingFetch = customFetch || globalThis.fetch;
}

export type SubscriptionPlan = 'FREE' | 'PRO_MONTHLY';
export type SubscriptionStatus = 'ACTIVE' | 'EXPIRED' | 'REVOKED' | 'NONE';
export type PaymentMethodKind = 'ZARINPAL' | 'USDT' | 'ADMIN_GRANT' | 'REFERRAL_BONUS';

export interface StoredSubscription {
  userId: string;
  email: string;
  displayName: string;
  plan: SubscriptionPlan;
  status: 'ACTIVE' | 'EXPIRED' | 'REVOKED';
  paymentMethod: PaymentMethodKind;
  startAt: number;
  expiresAt: number;
  updatedAt: number;
}

export interface StoredPaymentRequest {
  id: string;
  userId: string;
  userEmail: string;
  userDisplayName: string;
  method: 'ZARINPAL' | 'USDT';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  amountToman: number;
  amountUsdt: number;
  network?: string;
  walletAddress?: string;
  txHash?: string;
  authority?: string;
  refId?: string;
  note?: string;
  adminNote?: string;
  createdAt: number;
  updatedAt: number;
  reviewedAt?: number;
}

export interface StoredUserAccount {
  uid: string;
  email: string;
  displayName: string;
  isBanned: boolean;
  banReason?: string;
  adminNote?: string;
  referralCode?: string;
  referredByUid?: string;
  referredByCode?: string;
  referredAt?: number;
  referralBonusDaysEarned?: number;
  createdAt: number;
  lastSeenAt: number;
}

function defaultFeaturePolicies(): AppFeatureFlags {
  return {
    terminal: 'PRO',
    analysis: 'PRO',
    bots: 'PRO',
    telegram: 'PRO',
    watchers: 'PRO',
    alerts: 'FREE',
    pnlCalculator: 'FREE',
  };
}

function defaultMaintenanceMessage(): string {
  return 'سیستم موقتاً در حال به‌روزرسانی و ارتقای سرویس است. لطفاً دقایقی دیگر مجدداً تلاش کنید.';
}

async function ensureAdminSettingsRow(dbClient?: AppDatabase) {
  const db = dbClient || getDb();
  const existing = await db
    .select()
    .from(schema.adminSettings)
    .where(eq(schema.adminSettings.id, 'global'))
    .limit(1);
  if (existing[0]) return existing[0];

  const now = Date.now();
  await db
    .insert(schema.adminSettings)
    .values({
      id: 'global',
      monthlyPriceToman: 950_000,
      monthlyPriceUsdt: 15,
      autoUsdtFromRate: true,
      usdtWalletAddress: '',
      usdtNetwork: 'TRC20',
      usdtWalletAddress2: '',
      usdtNetwork2: 'BEP20',
      zarinpalSandbox: true,
      merchantKeyId: 'v1',
      encryptedMerchantJson: null,
      maskedMerchantId: '',
      maintenanceMode: false,
      maintenanceMessage: defaultMaintenanceMessage(),
      promoFreeAccess: false,
      promoBannerText: '',
      supportPhone: '09999961279',
      supportTelegram: '',
      featurePoliciesJson: defaultFeaturePolicies(),
      updatedAt: now,
    })
    .onConflictDoNothing();

  const [created] = await db
    .select()
    .from(schema.adminSettings)
    .where(eq(schema.adminSettings.id, 'global'))
    .limit(1);
  return created;
}

function mapAdminSettingsToAppControl(
  row: typeof schema.adminSettings.$inferSelect
): AppControlConfig {
  const defaults = defaultFeaturePolicies();
  const stored = (row.featurePoliciesJson || {}) as Partial<AppFeatureFlags>;
  return {
    maintenanceMode: row.maintenanceMode,
    maintenanceMessage: row.maintenanceMessage || defaultMaintenanceMessage(),
    promoFreeAccess: row.promoFreeAccess,
    promoBannerText: row.promoBannerText || '',
    supportPhone: row.supportPhone || '09999961279',
    supportTelegram: row.supportTelegram || '',
    featurePolicies: {
      terminal: stored.terminal || defaults.terminal,
      analysis: stored.analysis || defaults.analysis,
      bots: stored.bots || defaults.bots,
      telegram: stored.telegram || defaults.telegram,
      watchers: stored.watchers || defaults.watchers,
      alerts: stored.alerts || defaults.alerts,
      pnlCalculator: stored.pnlCalculator || defaults.pnlCalculator,
    },
    updatedAt: row.updatedAt,
  };
}

function mapUserRow(row: typeof schema.users.$inferSelect): StoredUserAccount {
  return {
    uid: row.uid,
    email: row.email,
    displayName: row.displayName,
    isBanned: row.isBanned,
    banReason: row.banReason ?? undefined,
    adminNote: row.adminNote ?? undefined,
    referralCode: row.referralCode,
    referredByUid: row.referredByUid ?? undefined,
    referredByCode: row.referredByCode ?? undefined,
    referredAt: row.referredAt ?? undefined,
    referralBonusDaysEarned: row.referralBonusDaysEarned,
    createdAt: row.createdAt,
    lastSeenAt: row.lastSeenAt,
  };
}

function mapSubRow(row: typeof schema.subscriptions.$inferSelect): StoredSubscription {
  return {
    userId: row.userId,
    email: row.email,
    displayName: row.displayName,
    plan: (row.plan === 'PRO_MONTHLY' ? 'PRO_MONTHLY' : 'FREE') as SubscriptionPlan,
    status: row.status as 'ACTIVE' | 'EXPIRED' | 'REVOKED',
    paymentMethod: row.paymentMethod as PaymentMethodKind,
    startAt: row.startAt,
    expiresAt: row.expiresAt,
    updatedAt: row.updatedAt,
  };
}

function mapPaymentRow(row: typeof schema.payments.$inferSelect): StoredPaymentRequest {
  return {
    id: row.id,
    userId: row.userId,
    userEmail: row.userEmail,
    userDisplayName: row.userDisplayName,
    method: (row.method === 'ZARINPAL' ? 'ZARINPAL' : 'USDT') as 'ZARINPAL' | 'USDT',
    status: row.status as 'PENDING' | 'APPROVED' | 'REJECTED',
    amountToman: row.amountToman,
    amountUsdt: row.amountUsdt,
    network: row.network ?? undefined,
    walletAddress: row.walletAddress ?? undefined,
    txHash: row.txHash ?? undefined,
    authority: row.authority ?? undefined,
    refId: row.refId ?? undefined,
    note: row.note ?? undefined,
    adminNote: row.adminNote ?? undefined,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
    reviewedAt: row.reviewedAt ?? undefined,
  };
}

function mapReferralRow(row: typeof schema.referrals.$inferSelect): AdminReferralRecord {
  return {
    id: row.id,
    referrerUid: row.referrerUid,
    referrerEmail: row.referrerEmail,
    referrerDisplayName: row.referrerDisplayName,
    referredUserUid: row.referredUserUid,
    referredUserEmail: row.referredUserEmail,
    referredUserDisplayName: row.referredUserDisplayName,
    referralCode: row.referralCode,
    status: row.status as 'REGISTERED' | 'REWARDED',
    rewardDays: row.rewardDays,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
    rewardedAt: row.rewardedAt ?? null,
  };
}

export async function recordAuditLog(
  actorEmail: string,
  action: string,
  details: string,
  target?: string,
  meta?: { actorUserId?: string; ipAddress?: string; dbClient?: AppDatabase }
): Promise<AdminAuditEntry> {
  const db = meta?.dbClient || getDb();
  const entry: AdminAuditEntry = {
    id: `aud-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
    actorEmail: actorEmail || BOOTSTRAP_ADMIN_EMAIL,
    action,
    target,
    details: details.slice(0, 400),
    createdAt: Date.now(),
  };

  await db.insert(schema.auditLogs).values({
    id: entry.id,
    actorEmail: entry.actorEmail,
    actorUserId: meta?.actorUserId ?? null,
    action: entry.action,
    target: target ?? null,
    details: entry.details,
    ipAddress: meta?.ipAddress ?? null,
    createdAt: entry.createdAt,
  });

  return entry;
}

export function isAdminUser(user?: AuthenticatedUser | null): boolean {
  if (!user || !user.emailVerified || !user.email) return false;
  const email = user.email.trim().toLowerCase();
  if (email === BOOTSTRAP_ADMIN_EMAIL) return true;
  const extraAdmins = (process.env.ADMIN_EMAILS || '')
    .split(',')
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
  return extraAdmins.includes(email);
}

export async function touchUserAccount(user?: AuthenticatedUser | null): Promise<void> {
  if (!user || !user.uid) return;
  await ensureUserRecord(user);
}

export async function importHistoricalUsers(
  list: Array<{ uid: string; email: string; displayName: string }>
): Promise<number> {
  const db = getDb();
  let added = 0;
  for (const item of list) {
    const uid = String(item.uid || '').trim();
    if (!uid) continue;
    const existing = await db
      .select({ uid: schema.users.uid })
      .from(schema.users)
      .where(eq(schema.users.uid, uid))
      .limit(1);
    if (existing.length > 0) continue;
    await ensureUserRecord({
      uid,
      email: String(item.email || '').trim().slice(0, 254),
      displayName: String(item.displayName || item.email || 'کاربر').trim().slice(0, 100),
    });
    added += 1;
  }
  return added;
}

function maskEmailAddress(email: string): string {
  const clean = email.trim();
  const atIndex = clean.indexOf('@');
  if (atIndex <= 1) return clean ? '•••@•••' : 'کاربر ثبت‌نامی';
  const local = clean.slice(0, atIndex);
  const domain = clean.slice(atIndex + 1);
  const visible = local.slice(0, Math.min(3, local.length));
  return `${visible}***@${domain}`;
}

async function hasCompletedPaidPurchase(uid: string, dbClient?: AppDatabase): Promise<boolean> {
  const db = dbClient || getDb();
  const paidReq = await db
    .select({ id: schema.payments.id })
    .from(schema.payments)
    .where(and(eq(schema.payments.userId, uid), eq(schema.payments.status, 'APPROVED')))
    .limit(1);
  if (paidReq.length > 0) return true;

  const subRows = await db
    .select({ paymentMethod: schema.subscriptions.paymentMethod })
    .from(schema.subscriptions)
    .where(eq(schema.subscriptions.userId, uid))
    .limit(1);
  const sub = subRows[0];
  return Boolean(sub && (sub.paymentMethod === 'ZARINPAL' || sub.paymentMethod === 'USDT'));
}

export async function isUserBanned(
  user?: AuthenticatedUser | null
): Promise<{ banned: boolean; reason?: string }> {
  if (!user || !user.uid) return { banned: false };
  if (isAdminUser(user)) return { banned: false };
  const db = getDb();
  const rows = await db
    .select({ isBanned: schema.users.isBanned, banReason: schema.users.banReason })
    .from(schema.users)
    .where(eq(schema.users.uid, user.uid))
    .limit(1);
  const record = rows[0];
  if (record?.isBanned) {
    return {
      banned: true,
      reason: record.banReason || 'حساب کاربری شما توسط مدیر سیستم مسدود شده است.',
    };
  }
  return { banned: false };
}

export async function claimReferralCode(
  user: AuthenticatedUser,
  rawCode: string
): Promise<{
  claimed: boolean;
  alreadyLinked: boolean;
  message: string;
  referral: AdminReferralRecord;
}> {
  await ensureUserRecord(user);
  const ban = await isUserBanned(user);
  if (ban.banned) {
    throw new Error(ban.reason || 'حساب کاربری شما مسدود است.');
  }

  const cleanCode = rawCode.trim().toUpperCase();
  if (cleanCode.length < 4 || cleanCode.length > 32) {
    throw new Error('کد دعوت وارد شده معتبر نیست.');
  }

  const db = getDb();
  const referrerRows = await db
    .select()
    .from(schema.users)
    .where(sql`UPPER(${schema.users.referralCode}) = ${cleanCode}`)
    .limit(1);
  const referrer = referrerRows[0];
  if (!referrer) {
    throw new Error('کد دعوت وارد شده در سیستم یافت نشد.');
  }
  if (referrer.uid === user.uid) {
    throw new Error('امکان استفاده از لینک یا کد دعوت خودتان وجود ندارد.');
  }

  const existingRows = await db
    .select()
    .from(schema.referrals)
    .where(eq(schema.referrals.referredUserUid, user.uid))
    .limit(1);
  const existingRecord = existingRows[0];
  if (existingRecord) {
    if (existingRecord.referrerUid === referrer.uid) {
      return {
        claimed: false,
        alreadyLinked: true,
        message: 'کد دعوت این معرف قبلاً برای حساب شما ثبت شده است.',
        referral: mapReferralRow(existingRecord),
      };
    }
    throw new Error('حساب شما قبلاً با یک کد دعوت دیگر ثبت شده است.');
  }

  if (referrer.referredByUid === user.uid) {
    throw new Error('ثبت کد دعوت متقابل بین دو حساب مجاز نیست.');
  }

  if (await hasCompletedPaidPurchase(user.uid)) {
    throw new Error('ثبت کد دعوت فقط قبل از اولین خرید اشتراک امکان‌پذیر است.');
  }

  const now = Date.now();
  const id = `ref-${now}-${crypto.randomBytes(3).toString('hex')}`;
  const rec: AdminReferralRecord = {
    id,
    referrerUid: referrer.uid,
    referrerEmail: referrer.email || '',
    referrerDisplayName: referrer.displayName || referrer.email || 'کاربر',
    referredUserUid: user.uid,
    referredUserEmail: user.email || '',
    referredUserDisplayName: user.displayName || user.email || 'کاربر',
    referralCode: referrer.referralCode || cleanCode,
    status: 'REGISTERED',
    rewardDays: REFERRAL_REWARD_DAYS,
    createdAt: now,
    updatedAt: now,
    rewardedAt: null,
  };

  await withTransaction(async (tx) => {
    await tx.insert(schema.referrals).values({
      id: rec.id,
      referrerUid: rec.referrerUid,
      referrerEmail: rec.referrerEmail,
      referrerDisplayName: rec.referrerDisplayName,
      referredUserUid: rec.referredUserUid,
      referredUserEmail: rec.referredUserEmail,
      referredUserDisplayName: rec.referredUserDisplayName,
      referralCode: rec.referralCode,
      status: 'REGISTERED',
      rewardDays: REFERRAL_REWARD_DAYS,
      createdAt: now,
      updatedAt: now,
      rewardedAt: null,
    });

    await tx
      .update(schema.users)
      .set({
        referredByUid: referrer.uid,
        referredByCode: rec.referralCode,
        referredAt: now,
      })
      .where(eq(schema.users.uid, user.uid));
  });

  return {
    claimed: true,
    alreadyLinked: false,
    message: `کد دعوت با موفقیت ثبت شد! با خرید اشتراک، ${REFERRAL_REWARD_DAYS} روز اشتراک رایگان به معرف شما هدیه داده می‌شود.`,
    referral: rec,
  };
}

export async function getUserReferralSummary(
  userId?: string | null
): Promise<UserReferralSummary | null> {
  if (!userId) return null;
  const userRec = await ensureUserRecord({ uid: userId });
  const db = getDb();

  const myInvites = await db
    .select()
    .from(schema.referrals)
    .where(eq(schema.referrals.referrerUid, userId))
    .orderBy(desc(schema.referrals.createdAt));

  const invitedUids = myInvites.map((r) => r.referredUserUid);
  const invitedUsersMap = new Map<string, typeof schema.users.$inferSelect>();
  if (invitedUids.length > 0) {
    const uRows = await db.select().from(schema.users);
    for (const u of uRows) invitedUsersMap.set(u.uid, u);
  }

  const invites: ReferralInviteItem[] = myInvites.map((r) => {
    const invitedUser = invitedUsersMap.get(r.referredUserUid);
    const displayName =
      invitedUser?.displayName || r.referredUserDisplayName || 'کاربر دعوت‌شده';
    const email = invitedUser?.email || r.referredUserEmail || '';
    return {
      id: r.id,
      referredUserUid: r.referredUserUid,
      referredDisplayName: displayName,
      referredMaskedEmail: maskEmailAddress(email),
      status: r.status as 'REGISTERED' | 'REWARDED',
      rewardDays: r.rewardDays || REFERRAL_REWARD_DAYS,
      joinedAt: r.createdAt,
      rewardedAt: r.rewardedAt ?? null,
    };
  });

  const convertedCount = myInvites.filter((r) => r.status === 'REWARDED').length;
  const pendingConversionCount = myInvites.filter((r) => r.status === 'REGISTERED').length;
  const totalBonusDaysEarned = myInvites
    .filter((r) => r.status === 'REWARDED')
    .reduce((acc, r) => acc + (r.rewardDays || REFERRAL_REWARD_DAYS), 0);

  return {
    referralCode: userRec.referralCode,
    rewardDaysPerConversion: REFERRAL_REWARD_DAYS,
    totalInvitedCount: myInvites.length,
    convertedCount,
    pendingConversionCount,
    totalBonusDaysEarned,
    referredByCode: userRec.referredByCode || null,
    canClaimManualCode: !userRec.referredByUid && !(await hasCompletedPaidPurchase(userId)),
    invites,
  };
}

async function activateUserProSubscriptionInTx(
  tx: AppDatabase,
  input: {
    userId: string;
    email: string;
    displayName: string;
    paymentMethod: PaymentMethodKind;
    days?: number;
  }
): Promise<StoredSubscription> {
  const now = Date.now();
  const days = Math.max(1, Math.min(365, Number(input.days || 30)));
  const prevRows = await tx
    .select()
    .from(schema.subscriptions)
    .where(eq(schema.subscriptions.userId, input.userId))
    .limit(1);
  const prev = prevRows[0];

  const userRows = await tx
    .select()
    .from(schema.users)
    .where(eq(schema.users.uid, input.userId))
    .limit(1);
  const userRec = userRows[0];

  const resolvedEmail = input.email || prev?.email || userRec?.email || '';
  const resolvedName =
    input.displayName || prev?.displayName || userRec?.displayName || resolvedEmail || 'کاربر';

  if (!userRec) {
    await ensureUserRecord({
      uid: input.userId,
      email: resolvedEmail,
      displayName: resolvedName,
    });
  }

  const baseTime = prev && prev.status === 'ACTIVE' && prev.expiresAt > now ? prev.expiresAt : now;
  const expiresAt = baseTime + days * 86_400_000;
  const startAt = prev && prev.status === 'ACTIVE' && prev.expiresAt > now ? prev.startAt : now;

  if (prev) {
    await tx
      .update(schema.subscriptions)
      .set({
        email: resolvedEmail,
        displayName: resolvedName,
        plan: 'PRO_MONTHLY',
        status: 'ACTIVE',
        paymentMethod: input.paymentMethod,
        startAt,
        expiresAt,
        updatedAt: now,
      })
      .where(eq(schema.subscriptions.userId, input.userId));
  } else {
    await tx.insert(schema.subscriptions).values({
      userId: input.userId,
      email: resolvedEmail,
      displayName: resolvedName,
      plan: 'PRO_MONTHLY',
      status: 'ACTIVE',
      paymentMethod: input.paymentMethod,
      startAt,
      expiresAt,
      updatedAt: now,
    });
  }

  return {
    userId: input.userId,
    email: resolvedEmail,
    displayName: resolvedName,
    plan: 'PRO_MONTHLY',
    status: 'ACTIVE',
    paymentMethod: input.paymentMethod,
    startAt,
    expiresAt,
    updatedAt: now,
  };
}

async function processReferralConversionRewardInTx(
  tx: AppDatabase,
  subscriberUid: string,
  paymentMethod: PaymentMethodKind
): Promise<{
  referral: AdminReferralRecord;
  rewardedSubscription: StoredSubscription;
} | null> {
  if (paymentMethod !== 'ZARINPAL' && paymentMethod !== 'USDT') {
    return null;
  }

  const now = Date.now();
  // Atomic state transition prevents duplicate reward grants under race conditions
  const updatedReferrals = await tx
    .update(schema.referrals)
    .set({
      status: 'REWARDED',
      rewardedAt: now,
      updatedAt: now,
    })
    .where(
      and(
        eq(schema.referrals.referredUserUid, subscriberUid),
        eq(schema.referrals.status, 'REGISTERED')
      )
    )
    .returning();

  const refRec = updatedReferrals[0];
  if (!refRec || refRec.referrerUid === subscriberUid) {
    return null;
  }

  const rewardDays = refRec.rewardDays || REFERRAL_REWARD_DAYS;
  await tx
    .update(schema.users)
    .set({
      referralBonusDaysEarned: sql`${schema.users.referralBonusDaysEarned} + ${rewardDays}`,
    })
    .where(eq(schema.users.uid, refRec.referrerUid));

  const referrerRows = await tx
    .select()
    .from(schema.users)
    .where(eq(schema.users.uid, refRec.referrerUid))
    .limit(1);
  const referrerUser = referrerRows[0];

  const rewardedSubscription = await activateUserProSubscriptionInTx(tx, {
    userId: refRec.referrerUid,
    email: referrerUser?.email || refRec.referrerEmail || '',
    displayName: referrerUser?.displayName || refRec.referrerDisplayName || 'کاربر',
    paymentMethod: 'REFERRAL_BONUS',
    days: rewardDays,
  });

  const subUserRows = await tx
    .select()
    .from(schema.users)
    .where(eq(schema.users.uid, subscriberUid))
    .limit(1);
  const invitedName =
    subUserRows[0]?.displayName ||
    refRec.referredUserDisplayName ||
    maskEmailAddress(refRec.referredUserEmail);

  await tx.insert(schema.directMessages).values({
    id: `dm-${now}-${crypto.randomBytes(3).toString('hex')}`,
    targetUserId: refRec.referrerUid,
    targetUserEmail: referrerUser?.email || refRec.referrerEmail || '',
    targetUserName: referrerUser?.displayName || refRec.referrerDisplayName || 'کاربر',
    subject: `هدیه ${rewardDays} روزه دعوت از دوستان فعال شد`,
    body: `کاربر دعوت‌شده شما (${invitedName}) اشتراک ماهانه خود را خریداری کرد. بر همین اساس ${rewardDays} روز اشتراک حرفه‌ای رایگان به حساب شما اضافه شد!`,
    severity: 'SUCCESS',
    readByUser: false,
    readAt: null,
    createdAt: now,
    updatedAt: now,
    senderEmail: 'system-referral',
  });

  await recordAuditLog(
    'system-referral',
    'REFERRAL_REWARD_GRANTED',
    `پاداش ${rewardDays} روز اشتراک رایگان بابت خرید کاربر دعوت‌شده (${invitedName})`,
    referrerUser?.email || refRec.referrerEmail || refRec.referrerUid,
    { dbClient: tx }
  );

  return {
    referral: mapReferralRow(refRec),
    rewardedSubscription,
  };
}

function getDecryptedMerchantIdFromRow(
  row: typeof schema.adminSettings.$inferSelect
): string | null {
  const envMerchant = process.env.ZARINPAL_MERCHANT_ID?.trim();
  if (row.encryptedMerchantJson) {
    try {
      const enc = row.encryptedMerchantJson as {
        encryptedToken: string;
        iv: string;
        authTag: string;
      };
      const raw = decryptSecretText(enc.encryptedToken, enc.iv, enc.authTag, row.merchantKeyId);
      const parsed = JSON.parse(raw) as { merchantId?: string };
      if (parsed.merchantId && parsed.merchantId.trim().length >= 8) {
        return parsed.merchantId.trim();
      }
    } catch {
      // Fall back cleanly
    }
  }
  if (envMerchant && envMerchant.length >= 8) return envMerchant;
  return null;
}

function maskMerchantId(id: string): string {
  const clean = id.trim();
  if (clean.length <= 10) return '••••••••';
  return `${clean.slice(0, 6)}••••••${clean.slice(-4)}`;
}

function computeEffectiveUsdtPrice(
  row: typeof schema.adminSettings.$inferSelect,
  usdtTomanRate: number
): number {
  if (row.autoUsdtFromRate && usdtTomanRate > 1000) {
    return Math.max(1, Number((row.monthlyPriceToman / usdtTomanRate).toFixed(2)));
  }
  return Math.max(1, Number(row.monthlyPriceUsdt || 15));
}

export async function getPublicBillingConfig(usdtTomanRate: number) {
  const row = await ensureAdminSettingsRow();
  const merchantId = getDecryptedMerchantIdFromRow(row);
  return {
    monthlyPriceToman: row.monthlyPriceToman,
    monthlyPriceUsdt: computeEffectiveUsdtPrice(row, usdtTomanRate),
    fixedUsdtPrice: row.monthlyPriceUsdt,
    autoUsdtFromRate: row.autoUsdtFromRate,
    usdtWalletAddress: row.usdtWalletAddress,
    usdtNetwork: row.usdtNetwork,
    usdtWalletAddress2: row.usdtWalletAddress2,
    usdtNetwork2: row.usdtNetwork2,
    zarinpalEnabled: Boolean(merchantId),
    zarinpalSandbox: row.zarinpalSandbox,
    updatedAt: row.updatedAt,
  };
}

export async function getPublicAppControl(): Promise<AppControlConfig> {
  const row = await ensureAdminSettingsRow();
  return mapAdminSettingsToAppControl(row);
}

export async function getActiveBroadcasts(): Promise<BroadcastMessage[]> {
  const db = getDb();
  const now = Date.now();
  const rows = await db
    .select()
    .from(schema.broadcasts)
    .where(eq(schema.broadcasts.active, true));

  return rows
    .filter((b) => !b.expiresAt || b.expiresAt > now)
    .sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return b.createdAt - a.createdAt;
    })
    .map((r) => ({
      id: r.id,
      title: r.title,
      body: r.body,
      severity: r.severity as BroadcastSeverity,
      active: r.active,
      pinned: r.pinned,
      createdAt: r.createdAt,
      updatedAt: r.updatedAt,
      expiresAt: r.expiresAt ?? null,
      createdByEmail: r.createdByEmail,
    }));
}

export async function getUserDirectMessages(userId?: string | null): Promise<DirectMessageRecord[]> {
  if (!userId) return [];
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.directMessages)
    .where(eq(schema.directMessages.targetUserId, userId))
    .orderBy(desc(schema.directMessages.createdAt))
    .limit(50);

  return rows.map((r) => ({
    id: r.id,
    targetUserId: r.targetUserId,
    targetUserEmail: r.targetUserEmail,
    targetUserName: r.targetUserName,
    subject: r.subject,
    body: r.body,
    severity: r.severity as BroadcastSeverity,
    readByUser: r.readByUser,
    readAt: r.readAt ?? null,
    createdAt: r.createdAt,
    updatedAt: r.updatedAt,
    senderEmail: r.senderEmail,
  }));
}

export async function getUserEntitlement(user?: AuthenticatedUser | null) {
  const settings = await ensureAdminSettingsRow();
  if (!user) {
    return {
      isAuthenticated: false,
      isAdmin: false,
      hasProAccess: Boolean(settings.promoFreeAccess),
      isBanned: false,
      banReason: undefined as string | undefined,
      promoFreeAccess: Boolean(settings.promoFreeAccess),
      plan: (settings.promoFreeAccess ? 'PRO_MONTHLY' : 'FREE') as SubscriptionPlan,
      status: 'NONE' as SubscriptionStatus,
      expiresAt: null as number | null,
      daysRemaining: 0,
      subscription: null as StoredSubscription | null,
    };
  }

  await ensureUserRecord(user);
  const db = getDb();
  const admin = isAdminUser(user);
  const ban = await isUserBanned(user);
  const subRows = await db
    .select()
    .from(schema.subscriptions)
    .where(eq(schema.subscriptions.userId, user.uid))
    .limit(1);

  const subRow = subRows[0] || null;
  const now = Date.now();
  let sub: StoredSubscription | null = subRow ? mapSubRow(subRow) : null;
  const isSubActive = Boolean(sub && sub.status === 'ACTIVE' && sub.expiresAt > now);

  if (sub && sub.status === 'ACTIVE' && sub.expiresAt <= now) {
    sub = { ...sub, status: 'EXPIRED', updatedAt: now };
    await db
      .update(schema.subscriptions)
      .set({ status: 'EXPIRED', updatedAt: now })
      .where(eq(schema.subscriptions.userId, user.uid));
  }

  const promoActive = Boolean(settings.promoFreeAccess);
  const hasProAccess = !ban.banned && (admin || isSubActive || promoActive);
  const daysRemaining =
    isSubActive && sub ? Math.max(1, Math.ceil((sub.expiresAt - now) / 86_400_000)) : 0;

  return {
    isAuthenticated: true,
    isAdmin: admin,
    hasProAccess,
    isBanned: ban.banned,
    banReason: ban.reason,
    promoFreeAccess: promoActive,
    plan: hasProAccess ? ('PRO_MONTHLY' as SubscriptionPlan) : ('FREE' as SubscriptionPlan),
    status: admin
      ? ('ACTIVE' as SubscriptionStatus)
      : isSubActive
        ? ('ACTIVE' as SubscriptionStatus)
        : ((sub?.status || 'NONE') as SubscriptionStatus),
    expiresAt: isSubActive && sub ? sub.expiresAt : sub?.expiresAt ?? null,
    daysRemaining,
    subscription: sub,
  };
}

export async function getUserPaymentRequests(userId: string): Promise<StoredPaymentRequest[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.payments)
    .where(eq(schema.payments.userId, userId))
    .orderBy(desc(schema.payments.createdAt))
    .limit(30);
  return rows.map(mapPaymentRow);
}

export async function activateUserProSubscription(
  input: {
    userId: string;
    email: string;
    displayName: string;
    paymentMethod: PaymentMethodKind;
    days?: number;
  },
  actorEmail?: string
): Promise<StoredSubscription> {
  await ensureUserRecord({
    uid: input.userId,
    email: input.email,
    displayName: input.displayName,
  });

  return withTransaction(async (tx) => {
    const updated = await activateUserProSubscriptionInTx(tx, input);
    if (actorEmail) {
      await recordAuditLog(
        actorEmail,
        'SUBSCRIPTION_ACTIVATED',
        `فعال‌سازی ${Math.max(1, Math.min(365, Number(input.days || 30)))} روز اشتراک (${input.paymentMethod})`,
        updated.email || input.userId,
        { dbClient: tx }
      );
    }
    return updated;
  });
}

export async function revokeUserSubscription(
  userId: string,
  actorEmail?: string
): Promise<StoredSubscription | null> {
  const db = getDb();
  const now = Date.now();
  const [updated] = await db
    .update(schema.subscriptions)
    .set({
      status: 'REVOKED',
      plan: 'FREE',
      updatedAt: now,
    })
    .where(eq(schema.subscriptions.userId, userId))
    .returning();

  if (!updated) return null;
  if (actorEmail) {
    await recordAuditLog(
      actorEmail,
      'SUBSCRIPTION_REVOKED',
      'لغو اشتراک حرفه‌ای کاربر',
      updated.email || userId
    );
  }
  return mapSubRow(updated);
}

export async function updateUserAdminControl(input: {
  userId: string;
  isBanned?: boolean;
  banReason?: string;
  adminNote?: string;
  actorEmail: string;
}): Promise<StoredUserAccount> {
  const cleanId = input.userId.trim();
  const db = getDb();
  const rows = await db.select().from(schema.users).where(eq(schema.users.uid, cleanId)).limit(1);
  const target = rows[0];
  if (!target) {
    throw new Error('کاربر مورد نظر یافت نشد.');
  }
  if (target.email.toLowerCase() === BOOTSTRAP_ADMIN_EMAIL && input.isBanned) {
    throw new Error('امکان مسدود کردن حساب مدیر اصلی وجود ندارد.');
  }

  const updateFields: Partial<typeof schema.users.$inferInsert> = {};
  if (typeof input.isBanned === 'boolean') {
    updateFields.isBanned = input.isBanned;
    updateFields.banReason = input.isBanned
      ? input.banReason?.trim().slice(0, 300) ||
        'دسترسی حساب کاربری شما توسط مدیر سیستم مسدود شده است.'
      : null;

    await recordAuditLog(
      input.actorEmail,
      input.isBanned ? 'USER_BANNED' : 'USER_UNBANNED',
      input.isBanned ? `مسدودسازی کاربر (${updateFields.banReason})` : 'رفع مسدودیت کاربر',
      target.email || cleanId
    );
  }

  if (typeof input.adminNote === 'string') {
    updateFields.adminNote = input.adminNote.trim().slice(0, 400);
  }

  if (Object.keys(updateFields).length === 0) {
    return mapUserRow(target);
  }

  const [updated] = await db
    .update(schema.users)
    .set(updateFields)
    .where(eq(schema.users.uid, cleanId))
    .returning();
  return mapUserRow(updated);
}

async function sendAdminTelegramNotice(htmlText: string): Promise<void> {
  try {
    const envBotToken = process.env.ADMIN_TELEGRAM_BOT_TOKEN?.trim();
    const envChatId = process.env.ADMIN_TELEGRAM_CHAT_ID?.trim();
    let botToken = envBotToken || '';
    let chatId = envChatId || '';

    if (!botToken || !chatId) {
      const db = getDb();
      const adminUsers = await db
        .select()
        .from(schema.users)
        .where(sql`LOWER(${schema.users.email}) = ${BOOTSTRAP_ADMIN_EMAIL}`)
        .limit(1);
      if (adminUsers[0]) {
        const creds = await getActiveTelegramCredentials(adminUsers[0].uid, true);
        if (creds) {
          botToken = creds.botToken;
          chatId = creds.chatId;
        }
      }
    }

    if (!botToken || !chatId) return;
    await activeBillingFetch(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: chatId,
        text: htmlText,
        parse_mode: 'HTML',
        disable_web_page_preview: true,
      }),
      signal: AbortSignal.timeout(5000),
    });
  } catch {
    // Non-fatal notification
  }
}

async function notifyAdminTelegramOfPayment(req: StoredPaymentRequest): Promise<void> {
  const text = [
    '💳 <b>درخواست پرداخت اشتراک دلاری (USDT)</b>',
    `کاربر: ${req.userDisplayName} (${req.userEmail || req.userId})`,
    `مبلغ: <b>${req.amountUsdt} USDT</b> (${req.network || 'USDT'})`,
    `TXID: <code>${req.txHash || '-'}</code>`,
    'برای تایید و فعال‌سازی ۳۰ روز اشتراک وارد «پنل مدیریت» سایت شوید.',
  ].join('\n');
  await sendAdminTelegramNotice(text);
}

export async function submitCryptoPaymentRequest(input: {
  user: AuthenticatedUser;
  txHash: string;
  network?: string;
  walletAddress?: string;
  usdtTomanRate: number;
  note?: string;
}): Promise<StoredPaymentRequest> {
  await ensureUserRecord(input.user);
  const ban = await isUserBanned(input.user);
  if (ban.banned) {
    throw new Error(ban.reason || 'حساب کاربری شما مسدود است.');
  }

  const cleanHash = input.txHash.trim();
  if (cleanHash.length < 8 || cleanHash.length > 200) {
    throw new Error('هش تراکنش (TXID) معتبر را با حداقل ۸ کاراکتر وارد کنید.');
  }

  const settings = await ensureAdminSettingsRow();
  const chosenWallet = (input.walletAddress || settings.usdtWalletAddress || '').trim();
  if (!chosenWallet) {
    throw new Error('هنوز آدرس کیف پول دلاری (USDT) توسط مدیر سایت در پنل مدیریت ثبت نشده است.');
  }

  const db = getDb();
  const dup = await db
    .select({ id: schema.payments.id })
    .from(schema.payments)
    .where(sql`LOWER(${schema.payments.txHash}) = ${cleanHash.toLowerCase()}`)
    .limit(1);
  if (dup.length > 0) {
    throw new Error('این هش تراکنش (TXID) قبلاً در سیستم ثبت شده است.');
  }

  const chosenNetwork = (input.network || settings.usdtNetwork || 'TRC20').trim().slice(0, 40);
  const amountUsdt = computeEffectiveUsdtPrice(settings, input.usdtTomanRate);
  const now = Date.now();
  const id = `pay-${now}-${crypto.randomBytes(3).toString('hex')}`;

  try {
    const [inserted] = await db
      .insert(schema.payments)
      .values({
        id,
        userId: input.user.uid,
        userEmail: input.user.email || '',
        userDisplayName: input.user.displayName || input.user.email || 'کاربر',
        method: 'USDT',
        status: 'PENDING',
        amountToman: settings.monthlyPriceToman,
        amountUsdt,
        network: chosenNetwork,
        walletAddress: chosenWallet,
        txHash: cleanHash,
        note: input.note?.trim().slice(0, 300) ?? null,
        createdAt: now,
        updatedAt: now,
      })
      .returning();

    const rec = mapPaymentRow(inserted);
    void notifyAdminTelegramOfPayment(rec);
    return rec;
  } catch (err) {
    const msg = err instanceof Error ? err.message : '';
    if (msg.toLowerCase().includes('unique') || msg.toLowerCase().includes('duplicate')) {
      throw new Error('این هش تراکنش (TXID) قبلاً در سیستم ثبت شده است.');
    }
    throw err;
  }
}

export async function requestZarinpalPayment(input: {
  user: AuthenticatedUser;
  callbackUrl: string;
  usdtTomanRate: number;
}): Promise<{
  mode: 'GATEWAY_REDIRECT' | 'READY_NOT_CONFIGURED';
  paymentUrl?: string;
  authority?: string;
  message: string;
  request: StoredPaymentRequest;
}> {
  await ensureUserRecord(input.user);
  const ban = await isUserBanned(input.user);
  if (ban.banned) {
    throw new Error(ban.reason || 'حساب کاربری شما مسدود است.');
  }

  const settings = await ensureAdminSettingsRow();
  const merchantId = getDecryptedMerchantIdFromRow(settings);
  const amountToman = Math.max(1000, Math.round(settings.monthlyPriceToman));
  const amountRials = amountToman * 10;
  const amountUsdt = computeEffectiveUsdtPrice(settings, input.usdtTomanRate);
  const now = Date.now();
  const id = `zp-${now}-${crypto.randomBytes(3).toString('hex')}`;
  const db = getDb();

  if (!merchantId) {
    const [inserted] = await db
      .insert(schema.payments)
      .values({
        id,
        userId: input.user.uid,
        userEmail: input.user.email || '',
        userDisplayName: input.user.displayName || input.user.email || 'کاربر',
        method: 'ZARINPAL',
        status: 'PENDING',
        amountToman,
        amountUsdt,
        note: 'در انتظار ثبت Merchant ID زرین‌پال توسط مدیر',
        createdAt: now,
        updatedAt: now,
      })
      .returning();

    return {
      mode: 'READY_NOT_CONFIGURED',
      message:
        'درگاه زرین‌پال آماده اتصال است؛ اما هنوز کد پذیرنده (Merchant ID) توسط مدیر سایت در پنل مدیریت ثبت نشده است. فعلاً می‌توانید از روش پرداخت دلاری (USDT) استفاده کنید یا پس از دریافت درگاه، Merchant ID را در پنل مدیریت ذخیره کنید.',
      request: mapPaymentRow(inserted),
    };
  }

  const isSandbox = settings.zarinpalSandbox;
  const apiBase = isSandbox ? 'https://sandbox.zarinpal.com' : 'https://api.zarinpal.com';
  const startPayBase = isSandbox ? 'https://sandbox.zarinpal.com' : 'https://www.zarinpal.com';

  const zpRes = await activeBillingFetch(`${apiBase}/pg/v4/payment/request.json`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({
      merchant_id: merchantId,
      amount: amountRials,
      callback_url: input.callbackUrl,
      description: `اشتراک ماهانه حرفه‌ای AI NobiBot (${amountToman.toLocaleString('en-US')} تومان)`,
      metadata: {
        email: input.user.email || undefined,
      },
    }),
    signal: AbortSignal.timeout(12_000),
  });

  const zpJson = (await zpRes.json()) as {
    data?: { code?: number; authority?: string; message?: string };
    errors?: { message?: string; code?: number };
  };

  const authority = zpJson.data?.authority;
  if (!zpRes.ok || zpJson.data?.code !== 100 || !authority) {
    const errMsg = zpJson.errors?.message || zpJson.data?.message || 'خطا در اتصال به درگاه زرین‌پال';
    throw new Error(`خطای زرین‌پال: ${errMsg}`);
  }

  const [inserted] = await db
    .insert(schema.payments)
    .values({
      id,
      userId: input.user.uid,
      userEmail: input.user.email || '',
      userDisplayName: input.user.displayName || input.user.email || 'کاربر',
      method: 'ZARINPAL',
      status: 'PENDING',
      amountToman,
      amountUsdt,
      authority,
      createdAt: now,
      updatedAt: now,
    })
    .returning();

  return {
    mode: 'GATEWAY_REDIRECT',
    authority,
    paymentUrl: `${startPayBase}/pg/StartPay/${authority}`,
    message: 'در حال انتقال به درگاه امن زرین‌پال...',
    request: mapPaymentRow(inserted),
  };
}

export async function verifyZarinpalPayment(input: {
  user: AuthenticatedUser;
  authority: string;
  status: string;
}): Promise<{
  verified: boolean;
  refId?: string;
  message: string;
  subscription?: StoredSubscription;
  referralReward?: {
    referral: AdminReferralRecord;
    rewardedSubscription: StoredSubscription;
  } | null;
}> {
  const cleanAuth = input.authority.trim();
  const db = getDb();
  const reqRows = await db
    .select()
    .from(schema.payments)
    .where(
      and(
        eq(schema.payments.method, 'ZARINPAL'),
        eq(schema.payments.authority, cleanAuth),
        eq(schema.payments.userId, input.user.uid)
      )
    )
    .limit(1);

  const reqRecord = reqRows[0];
  if (!reqRecord) {
    throw new Error('تراکنش زرین‌پال با این کد رهگیری برای حساب شما یافت نشد.');
  }

  if (reqRecord.status === 'APPROVED') {
    const subRows = await db
      .select()
      .from(schema.subscriptions)
      .where(eq(schema.subscriptions.userId, input.user.uid))
      .limit(1);
    return {
      verified: true,
      refId: reqRecord.refId ?? undefined,
      message: 'این پرداخت قبلاً تایید و اشتراک شما فعال شده است.',
      subscription: subRows[0] ? mapSubRow(subRows[0]) : undefined,
    };
  }

  if (input.status !== 'OK') {
    const now = Date.now();
    await db
      .update(schema.payments)
      .set({
        status: 'REJECTED',
        adminNote: 'تراکنش توسط کاربر لغو یا ناموفق اعلام شد.',
        updatedAt: now,
        reviewedAt: now,
      })
      .where(and(eq(schema.payments.id, reqRecord.id), eq(schema.payments.status, 'PENDING')));
    return {
      verified: false,
      message: 'پرداخت در درگاه زرین‌پال تکمیل نشد یا لغو گردید.',
    };
  }

  const settings = await ensureAdminSettingsRow();
  const merchantId = getDecryptedMerchantIdFromRow(settings);
  if (!merchantId) {
    throw new Error('کد پذیرنده زرین‌پال در سرور تنظیم نشده است.');
  }

  const apiBase = settings.zarinpalSandbox
    ? 'https://sandbox.zarinpal.com'
    : 'https://api.zarinpal.com';

  const verifyRes = await activeBillingFetch(`${apiBase}/pg/v4/payment/verify.json`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({
      merchant_id: merchantId,
      amount: reqRecord.amountToman * 10,
      authority: cleanAuth,
    }),
    signal: AbortSignal.timeout(12_000),
  });

  const verifyJson = (await verifyRes.json()) as {
    data?: { code?: number; ref_id?: number | string; message?: string };
    errors?: { message?: string };
  };

  const code = verifyJson.data?.code;
  if (verifyRes.ok && (code === 100 || code === 101)) {
    const refId = verifyJson.data?.ref_id ? String(verifyJson.data.ref_id) : undefined;
    const txResult = await withTransaction(async (tx) => {
      const now = Date.now();
      const updated = await tx
        .update(schema.payments)
        .set({
          status: 'APPROVED',
          refId: refId ?? null,
          adminNote: refId ? `تایید خودکار زرین‌پال · کد پیگیری: ${refId}` : 'تایید خودکار زرین‌پال',
          updatedAt: now,
          reviewedAt: now,
        })
        .where(and(eq(schema.payments.id, reqRecord.id), eq(schema.payments.status, 'PENDING')))
        .returning();

      if (updated.length === 0) {
        const subRows = await tx
          .select()
          .from(schema.subscriptions)
          .where(eq(schema.subscriptions.userId, input.user.uid))
          .limit(1);
        return {
          alreadyProcessed: true,
          sub: subRows[0] ? mapSubRow(subRows[0]) : undefined,
          referralReward: null,
        };
      }

      const sub = await activateUserProSubscriptionInTx(tx, {
        userId: input.user.uid,
        email: input.user.email,
        displayName: input.user.displayName,
        paymentMethod: 'ZARINPAL',
        days: 30,
      });
      const referralReward = await processReferralConversionRewardInTx(tx, input.user.uid, 'ZARINPAL');
      return { alreadyProcessed: false, sub, referralReward };
    });

    return {
      verified: true,
      refId,
      message: 'پرداخت شما با موفقیت تایید شد و اشتراک ماهانه حرفه‌ای فعال گردید.',
      subscription: txResult.sub,
      referralReward: txResult.referralReward,
    };
  }

  const now = Date.now();
  await db
    .update(schema.payments)
    .set({
      status: 'REJECTED',
      adminNote: verifyJson.errors?.message || 'تایید تراکنش از سمت زرین‌پال رد شد.',
      updatedAt: now,
      reviewedAt: now,
    })
    .where(and(eq(schema.payments.id, reqRecord.id), eq(schema.payments.status, 'PENDING')));

  return {
    verified: false,
    message: verifyJson.errors?.message || 'تراکنش توسط زرین‌پال تایید نشد.',
  };
}

export async function createBroadcastMessage(input: {
  title: string;
  body: string;
  severity: BroadcastSeverity;
  pinned?: boolean;
  expiresInHours?: number;
  sendTelegram?: boolean;
  actorEmail: string;
}): Promise<BroadcastMessage> {
  const cleanTitle = input.title.trim().slice(0, 150);
  const cleanBody = input.body.trim().slice(0, 2000);
  if (!cleanTitle || !cleanBody) {
    throw new Error('عنوان و متن پیام عمومی الزامی است.');
  }

  const db = getDb();
  const now = Date.now();
  const hours = Number(input.expiresInHours || 0);
  const expiresAt = hours > 0 && Number.isFinite(hours) ? now + hours * 3_600_000 : null;
  const severity: BroadcastSeverity = ['INFO', 'SUCCESS', 'WARNING', 'URGENT'].includes(
    input.severity
  )
    ? input.severity
    : 'INFO';

  const msg: BroadcastMessage = {
    id: `brd-${now}-${crypto.randomBytes(3).toString('hex')}`,
    title: cleanTitle,
    body: cleanBody,
    severity,
    active: true,
    pinned: Boolean(input.pinned),
    createdAt: now,
    updatedAt: now,
    expiresAt,
    createdByEmail: input.actorEmail,
  };

  await db.insert(schema.broadcasts).values(msg);
  await recordAuditLog(input.actorEmail, 'BROADCAST_CREATED', `انتشار پیام عمومی: ${cleanTitle}`);

  if (input.sendTelegram) {
    const noticeHtml = [
      `📢 <b>${cleanTitle}</b>`,
      '',
      cleanBody,
      '',
      '— اطلاعیه رسمی AI NobiBot (ainobibot.ir)',
    ].join('\n');
    void sendAdminTelegramNotice(noticeHtml);
  }

  return msg;
}

export async function updateBroadcastStatus(input: {
  broadcastId: string;
  active?: boolean;
  pinned?: boolean;
  actorEmail: string;
}): Promise<BroadcastMessage> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.broadcasts)
    .where(eq(schema.broadcasts.id, input.broadcastId))
    .limit(1);
  const found = rows[0];
  if (!found) {
    throw new Error('اطلاعیه مورد نظر یافت نشد.');
  }

  const nextActive = typeof input.active === 'boolean' ? input.active : found.active;
  const nextPinned = typeof input.pinned === 'boolean' ? input.pinned : found.pinned;
  const now = Date.now();

  const [updated] = await db
    .update(schema.broadcasts)
    .set({
      active: nextActive,
      pinned: nextPinned,
      updatedAt: now,
    })
    .where(eq(schema.broadcasts.id, input.broadcastId))
    .returning();

  await recordAuditLog(
    input.actorEmail,
    'BROADCAST_UPDATED',
    `ویرایش وضعیت اطلاعیه «${updated.title}» (فعال: ${updated.active ? 'بله' : 'خیر'})`
  );

  return {
    id: updated.id,
    title: updated.title,
    body: updated.body,
    severity: updated.severity as BroadcastSeverity,
    active: updated.active,
    pinned: updated.pinned,
    createdAt: updated.createdAt,
    updatedAt: updated.updatedAt,
    expiresAt: updated.expiresAt ?? null,
    createdByEmail: updated.createdByEmail,
  };
}

export async function deleteBroadcastMessage(
  broadcastId: string,
  actorEmail: string
): Promise<void> {
  const db = getDb();
  const [removed] = await db
    .delete(schema.broadcasts)
    .where(eq(schema.broadcasts.id, broadcastId))
    .returning();
  if (removed) {
    await recordAuditLog(actorEmail, 'BROADCAST_DELETED', `حذف اطلاعیه: ${removed.title}`);
  }
}

export async function sendDirectMessageToUser(input: {
  targetUserId: string;
  subject: string;
  body: string;
  severity: BroadcastSeverity;
  actorEmail: string;
}): Promise<DirectMessageRecord> {
  const cleanTarget = input.targetUserId.trim();
  const cleanSubject = input.subject.trim().slice(0, 150);
  const cleanBody = input.body.trim().slice(0, 2000);
  if (!cleanTarget) {
    throw new Error('انتخاب کاربر گیرنده (UID) الزامی است.');
  }
  if (!cleanSubject || !cleanBody) {
    throw new Error('موضوع و متن پیام تکی الزامی است.');
  }

  const db = getDb();
  const userRows = await db
    .select()
    .from(schema.users)
    .where(eq(schema.users.uid, cleanTarget))
    .limit(1);
  if (userRows.length === 0) {
    throw new Error('کاربر گیرنده در سیستم یافت نشد.');
  }
  const userRec = userRows[0];
  const targetEmail = userRec.email || '';
  const targetName = userRec.displayName || targetEmail || cleanTarget;

  const now = Date.now();
  const severity: BroadcastSeverity = ['INFO', 'SUCCESS', 'WARNING', 'URGENT'].includes(
    input.severity
  )
    ? input.severity
    : 'INFO';

  const dm: DirectMessageRecord = {
    id: `dm-${now}-${crypto.randomBytes(3).toString('hex')}`,
    targetUserId: cleanTarget,
    targetUserEmail: targetEmail,
    targetUserName: targetName,
    subject: cleanSubject,
    body: cleanBody,
    severity,
    readByUser: false,
    readAt: null,
    createdAt: now,
    updatedAt: now,
    senderEmail: input.actorEmail,
  };

  await db.insert(schema.directMessages).values(dm);
  await recordAuditLog(
    input.actorEmail,
    'DIRECT_MESSAGE_SENT',
    `ارسال پیام تکی «${cleanSubject}»`,
    targetEmail || cleanTarget
  );
  return dm;
}

export async function markDirectMessageRead(
  userId: string,
  messageId: string
): Promise<DirectMessageRecord | null> {
  const db = getDb();
  const now = Date.now();
  const [updated] = await db
    .update(schema.directMessages)
    .set({
      readByUser: true,
      readAt: now,
      updatedAt: now,
    })
    .where(
      and(
        eq(schema.directMessages.id, messageId),
        eq(schema.directMessages.targetUserId, userId)
      )
    )
    .returning();

  if (!updated) return null;
  return {
    id: updated.id,
    targetUserId: updated.targetUserId,
    targetUserEmail: updated.targetUserEmail,
    targetUserName: updated.targetUserName,
    subject: updated.subject,
    body: updated.body,
    severity: updated.severity as BroadcastSeverity,
    readByUser: updated.readByUser,
    readAt: updated.readAt ?? null,
    createdAt: updated.createdAt,
    updatedAt: updated.updatedAt,
    senderEmail: updated.senderEmail,
  };
}

export async function markAllDirectMessagesRead(userId: string): Promise<number> {
  const db = getDb();
  const now = Date.now();
  const updated = await db
    .update(schema.directMessages)
    .set({
      readByUser: true,
      readAt: now,
      updatedAt: now,
    })
    .where(
      and(
        eq(schema.directMessages.targetUserId, userId),
        eq(schema.directMessages.readByUser, false)
      )
    )
    .returning();

  return updated.length;
}

export async function deleteDirectMessage(messageId: string, actorEmail: string): Promise<void> {
  const db = getDb();
  const [removed] = await db
    .delete(schema.directMessages)
    .where(eq(schema.directMessages.id, messageId))
    .returning();
  if (removed) {
    await recordAuditLog(
      actorEmail,
      'DIRECT_MESSAGE_DELETED',
      `حذف پیام تکی: ${removed.subject}`,
      removed.targetUserEmail || removed.targetUserId
    );
  }
}

export async function updateAdminAppControl(
  input: Partial<AppControlConfig>,
  actorEmail: string
): Promise<AppControlConfig> {
  const prevRow = await ensureAdminSettingsRow();
  const prev = mapAdminSettingsToAppControl(prevRow);
  const validPolicy = (val: unknown, fallback: ModuleAccessPolicy): ModuleAccessPolicy =>
    val === 'FREE' || val === 'PRO' || val === 'DISABLED' ? val : fallback;

  const nextMaintenanceMode =
    typeof input.maintenanceMode === 'boolean' ? input.maintenanceMode : prev.maintenanceMode;
  const nextMaintenanceMessage =
    typeof input.maintenanceMessage === 'string'
      ? input.maintenanceMessage.trim().slice(0, 500) || defaultMaintenanceMessage()
      : prev.maintenanceMessage;
  const nextPromoFree =
    typeof input.promoFreeAccess === 'boolean' ? input.promoFreeAccess : prev.promoFreeAccess;
  const nextPromoBanner =
    typeof input.promoBannerText === 'string'
      ? input.promoBannerText.trim().slice(0, 300)
      : prev.promoBannerText;
  const nextPhone =
    typeof input.supportPhone === 'string'
      ? input.supportPhone.trim().slice(0, 40) || '09999961279'
      : prev.supportPhone;
  const nextTelegram =
    typeof input.supportTelegram === 'string'
      ? input.supportTelegram.trim().slice(0, 100)
      : prev.supportTelegram;

  const nextPolicies: AppFeatureFlags = input.featurePolicies
    ? {
        terminal: validPolicy(input.featurePolicies.terminal, prev.featurePolicies.terminal),
        analysis: validPolicy(input.featurePolicies.analysis, prev.featurePolicies.analysis),
        bots: validPolicy(input.featurePolicies.bots, prev.featurePolicies.bots),
        telegram: validPolicy(input.featurePolicies.telegram, prev.featurePolicies.telegram),
        watchers: validPolicy(input.featurePolicies.watchers, prev.featurePolicies.watchers),
        alerts: validPolicy(input.featurePolicies.alerts, prev.featurePolicies.alerts),
        pnlCalculator: validPolicy(
          input.featurePolicies.pnlCalculator,
          prev.featurePolicies.pnlCalculator
        ),
      }
    : prev.featurePolicies;

  const now = Date.now();
  const db = getDb();
  const [updated] = await db
    .update(schema.adminSettings)
    .set({
      maintenanceMode: nextMaintenanceMode,
      maintenanceMessage: nextMaintenanceMessage,
      promoFreeAccess: nextPromoFree,
      promoBannerText: nextPromoBanner,
      supportPhone: nextPhone,
      supportTelegram: nextTelegram,
      featurePoliciesJson: nextPolicies,
      updatedAt: now,
    })
    .where(eq(schema.adminSettings.id, 'global'))
    .returning();

  await recordAuditLog(
    actorEmail,
    'APP_CONTROL_UPDATED',
    `بروزرسانی تنظیمات اپ (تعمیرات: ${nextMaintenanceMode ? 'روشن' : 'خاموش'}، دسترسی آزاد: ${nextPromoFree ? 'روشن' : 'خاموش'})`
  );

  return mapAdminSettingsToAppControl(updated);
}

export async function getManagedUsersList(): Promise<ManagedUserSummary[]> {
  const db = getDb();
  const now = Date.now();
  const [userRows, subRows, payRows, dmRows, refRows] = await Promise.all([
    db.select().from(schema.users),
    db.select().from(schema.subscriptions),
    db.select().from(schema.payments),
    db.select().from(schema.directMessages).where(eq(schema.directMessages.readByUser, false)),
    db.select().from(schema.referrals),
  ]);

  const subMap = new Map(subRows.map((s) => [s.userId, mapSubRow(s)]));
  const payByUser = new Map<string, typeof payRows>();
  for (const p of payRows) {
    const arr = payByUser.get(p.userId) || [];
    arr.push(p);
    payByUser.set(p.userId, arr);
  }
  const dmCountMap = new Map<string, number>();
  for (const d of dmRows) {
    dmCountMap.set(d.targetUserId, (dmCountMap.get(d.targetUserId) || 0) + 1);
  }
  const refByReferrer = new Map<string, typeof refRows>();
  for (const r of refRows) {
    const arr = refByReferrer.get(r.referrerUid) || [];
    arr.push(r);
    refByReferrer.set(r.referrerUid, arr);
  }

  const list: ManagedUserSummary[] = userRows.map((uRec) => {
    const sub = subMap.get(uRec.uid) || null;
    const reqs = payByUser.get(uRec.uid) || [];
    const email = uRec.email || sub?.email || reqs[0]?.userEmail || '';
    const displayName =
      uRec.displayName || sub?.displayName || reqs[0]?.userDisplayName || email || 'کاربر';
    const isAdmin = email.trim().toLowerCase() === BOOTSTRAP_ADMIN_EMAIL;
    const isSubActive = Boolean(sub && sub.status === 'ACTIVE' && sub.expiresAt > now);
    const daysRemaining =
      isSubActive && sub ? Math.max(1, Math.ceil((sub.expiresAt - now) / 86_400_000)) : 0;
    const isBanned = !isAdmin && Boolean(uRec.isBanned);

    const userReferrals = refByReferrer.get(uRec.uid) || [];
    const convertedReferralsCount = userReferrals.filter((r) => r.status === 'REWARDED').length;
    const referralBonusDaysEarned = userReferrals
      .filter((r) => r.status === 'REWARDED')
      .reduce((acc, r) => acc + (r.rewardDays || REFERRAL_REWARD_DAYS), 0);

    return {
      uid: uRec.uid,
      email,
      displayName,
      isAdmin,
      isBanned,
      banReason: uRec.banReason ?? undefined,
      adminNote: uRec.adminNote ?? undefined,
      createdAt: uRec.createdAt,
      lastSeenAt: uRec.lastSeenAt,
      subscription: sub,
      hasProAccess: !isBanned && (isAdmin || isSubActive),
      daysRemaining,
      paymentRequestsCount: reqs.length,
      approvedPaymentsCount: reqs.filter((r) => r.status === 'APPROVED').length,
      unreadDirectMessagesCount: dmCountMap.get(uRec.uid) || 0,
      referralCode: uRec.referralCode,
      invitedCount: userReferrals.length,
      convertedReferralsCount,
      referralBonusDaysEarned,
      referredByUid: uRec.referredByUid ?? undefined,
    };
  });

  return list.sort((a, b) => {
    if (a.isAdmin !== b.isAdmin) return a.isAdmin ? -1 : 1;
    return b.lastSeenAt - a.lastSeenAt;
  });
}

export async function getAdminBillingOverview(
  usdtTomanRate: number,
  runtimeMetrics?: {
    bots?: BotStrategyConfig[];
    activeAlertsCount?: number;
    activeWatchersCount?: number;
    ideasCount?: number;
  }
) {
  const db = getDb();
  const now = Date.now();
  const [
    settingsRow,
    users,
    paymentRows,
    subRows,
    broadcastRows,
    dmRows,
    auditRows,
    referralRows,
  ] = await Promise.all([
    ensureAdminSettingsRow(),
    getManagedUsersList(),
    db.select().from(schema.payments).orderBy(desc(schema.payments.createdAt)).limit(100),
    db.select().from(schema.subscriptions).orderBy(desc(schema.subscriptions.updatedAt)),
    db.select().from(schema.broadcasts).orderBy(desc(schema.broadcasts.createdAt)).limit(60),
    db.select().from(schema.directMessages).orderBy(desc(schema.directMessages.createdAt)).limit(100),
    db.select().from(schema.auditLogs).orderBy(desc(schema.auditLogs.createdAt)).limit(80),
    db.select().from(schema.referrals).orderBy(desc(schema.referrals.createdAt)).limit(120),
  ]);

  const paymentRequests = paymentRows.map(mapPaymentRow);
  const subscriptions = subRows.map(mapSubRow);
  const referrals = referralRows.map(mapReferralRow);
  const bots = runtimeMetrics?.bots || [];
  const approvedRequests = paymentRequests.filter((r) => r.status === 'APPROVED');
  const rewardedReferrals = referrals.filter((r) => r.status === 'REWARDED');
  const activeBroadcasts = broadcastRows.filter(
    (b) => b.active && (!b.expiresAt || b.expiresAt > now)
  );

  const stats: AdminSystemStats = {
    totalUsers: users.length,
    activeUsers24h: users.filter((u) => now - u.lastSeenAt <= 86_400_000).length,
    activeProUsers: users.filter((u) => u.hasProAccess).length,
    bannedUsers: users.filter((u) => u.isBanned).length,
    pendingPayments: paymentRequests.filter((r) => r.status === 'PENDING').length,
    totalRevenueToman: approvedRequests
      .filter((r) => r.method === 'ZARINPAL')
      .reduce((acc, r) => acc + (r.amountToman || 0), 0),
    totalRevenueUsdt: Number(
      approvedRequests
        .filter((r) => r.method === 'USDT')
        .reduce((acc, r) => acc + (r.amountUsdt || 0), 0)
        .toFixed(2)
    ),
    runningBotsCount: bots.filter((b) => b.status === 'RUNNING').length,
    totalBotsCount: bots.length,
    activeAlertsCount: runtimeMetrics?.activeAlertsCount || 0,
    activeWatchersCount: runtimeMetrics?.activeWatchersCount || 0,
    ideasCount: runtimeMetrics?.ideasCount || 0,
    activeBroadcastsCount: activeBroadcasts.length,
    unreadDirectMessagesTotal: dmRows.filter((m) => !m.readByUser).length,
    totalReferralsCount: referrals.length,
    convertedReferralsCount: rewardedReferrals.length,
    totalReferralBonusDaysGranted: rewardedReferrals.reduce(
      (acc, r) => acc + (r.rewardDays || REFERRAL_REWARD_DAYS),
      0
    ),
  };

  return {
    config: {
      ...(await getPublicBillingConfig(usdtTomanRate)),
      maskedMerchantId:
        settingsRow.maskedMerchantId ||
        (process.env.ZARINPAL_MERCHANT_ID ? 'ENV_CONFIGURED' : ''),
    },
    appControl: mapAdminSettingsToAppControl(settingsRow),
    paymentRequests,
    subscriptions,
    users,
    broadcasts: broadcastRows.map((b) => ({
      id: b.id,
      title: b.title,
      body: b.body,
      severity: b.severity as BroadcastSeverity,
      active: b.active,
      pinned: b.pinned,
      createdAt: b.createdAt,
      updatedAt: b.updatedAt,
      expiresAt: b.expiresAt ?? null,
      createdByEmail: b.createdByEmail,
    })),
    directMessages: dmRows.map((d) => ({
      id: d.id,
      targetUserId: d.targetUserId,
      targetUserEmail: d.targetUserEmail,
      targetUserName: d.targetUserName,
      subject: d.subject,
      body: d.body,
      severity: d.severity as BroadcastSeverity,
      readByUser: d.readByUser,
      readAt: d.readAt ?? null,
      createdAt: d.createdAt,
      updatedAt: d.updatedAt,
      senderEmail: d.senderEmail,
    })),
    auditLogs: auditRows.map((a) => ({
      id: a.id,
      actorEmail: a.actorEmail,
      action: a.action,
      target: a.target ?? undefined,
      details: a.details,
      createdAt: a.createdAt,
    })),
    stats,
    bots,
    referrals,
  };
}

export async function updateAdminBillingConfig(
  input: {
    monthlyPriceToman?: number;
    monthlyPriceUsdt?: number;
    autoUsdtFromRate?: boolean;
    usdtWalletAddress?: string;
    usdtNetwork?: string;
    usdtWalletAddress2?: string;
    usdtNetwork2?: string;
    zarinpalMerchantId?: string;
    clearZarinpalMerchantId?: boolean;
    zarinpalSandbox?: boolean;
  },
  usdtTomanRate: number,
  actorEmail = BOOTSTRAP_ADMIN_EMAIL
) {
  const prev = await ensureAdminSettingsRow();
  const updateFields: Partial<typeof schema.adminSettings.$inferInsert> = {
    updatedAt: Date.now(),
  };

  if (typeof input.monthlyPriceToman === 'number' && Number.isFinite(input.monthlyPriceToman)) {
    updateFields.monthlyPriceToman = Math.max(10_000, Math.round(input.monthlyPriceToman));
  }
  if (typeof input.monthlyPriceUsdt === 'number' && Number.isFinite(input.monthlyPriceUsdt)) {
    updateFields.monthlyPriceUsdt = Math.max(1, Number(input.monthlyPriceUsdt.toFixed(2)));
  }
  if (typeof input.autoUsdtFromRate === 'boolean') {
    updateFields.autoUsdtFromRate = input.autoUsdtFromRate;
  }
  if (typeof input.usdtWalletAddress === 'string') {
    updateFields.usdtWalletAddress = input.usdtWalletAddress.trim().slice(0, 200);
  }
  if (typeof input.usdtNetwork === 'string') {
    updateFields.usdtNetwork = input.usdtNetwork.trim().slice(0, 40) || 'TRC20';
  }
  if (typeof input.usdtWalletAddress2 === 'string') {
    updateFields.usdtWalletAddress2 = input.usdtWalletAddress2.trim().slice(0, 200);
  }
  if (typeof input.usdtNetwork2 === 'string') {
    updateFields.usdtNetwork2 = input.usdtNetwork2.trim().slice(0, 40) || 'BEP20';
  }
  if (typeof input.zarinpalSandbox === 'boolean') {
    updateFields.zarinpalSandbox = input.zarinpalSandbox;
  }

  if (input.clearZarinpalMerchantId) {
    updateFields.encryptedMerchantJson = null;
    updateFields.maskedMerchantId = '';
  } else if (typeof input.zarinpalMerchantId === 'string' && input.zarinpalMerchantId.trim().length > 0) {
    const cleanId = input.zarinpalMerchantId.trim().slice(0, 128);
    if (cleanId.length < 16) {
      throw new Error('کد پذیرنده (Merchant ID) زرین‌پال باید حداقل ۱۶ کاراکتر (معمولاً ۳۶ کاراکتر) باشد.');
    }
    const enc = encryptSecretText(JSON.stringify({ merchantId: cleanId }));
    updateFields.merchantKeyId = enc.keyId;
    updateFields.encryptedMerchantJson = {
      encryptedToken: enc.encryptedToken,
      iv: enc.iv,
      authTag: enc.authTag,
    };
    updateFields.maskedMerchantId = maskMerchantId(cleanId);
  }

  const db = getDb();
  const [updated] = await db
    .update(schema.adminSettings)
    .set(updateFields)
    .where(eq(schema.adminSettings.id, 'global'))
    .returning();

  await recordAuditLog(
    actorEmail,
    'BILLING_CONFIG_UPDATED',
    `بروزرسانی تعرفه (${(updated?.monthlyPriceToman ?? prev.monthlyPriceToman).toLocaleString('en-US')} ت) و کیف‌پول‌ها/زرین‌پال`
  );

  return getAdminBillingOverview(usdtTomanRate);
}

export async function reviewPaymentRequestAsAdmin(input: {
  requestId: string;
  action: 'APPROVE' | 'REJECT';
  adminNote?: string;
  actorEmail?: string;
}): Promise<{
  request: StoredPaymentRequest;
  subscription: StoredSubscription | null;
  referralReward: {
    referral: AdminReferralRecord;
    rewardedSubscription: StoredSubscription;
  } | null;
}> {
  const actor = input.actorEmail || BOOTSTRAP_ADMIN_EMAIL;
  const nextStatus = input.action === 'APPROVE' ? 'APPROVED' : 'REJECTED';

  return withTransaction(async (tx) => {
    const existingRows = await tx
      .select()
      .from(schema.payments)
      .where(eq(schema.payments.id, input.requestId))
      .limit(1);

    if (existingRows.length === 0) {
      throw new Error('درخواست پرداخت مورد نظر یافت نشد.');
    }

    const now = Date.now();
    // Atomic CAS guard prevents double approval and duplicate subscription/referral credit
    const updatedRows = await tx
      .update(schema.payments)
      .set({
        status: nextStatus,
        adminNote: input.adminNote?.trim().slice(0, 300) ?? null,
        updatedAt: now,
        reviewedAt: now,
      })
      .where(and(eq(schema.payments.id, input.requestId), eq(schema.payments.status, 'PENDING')))
      .returning();

    if (updatedRows.length === 0) {
      throw new Error('این درخواست پرداخت قبلاً بررسی و نهایی شده است.');
    }

    const reqRecord = mapPaymentRow(updatedRows[0]);
    let subscription: StoredSubscription | null = null;
    let referralReward: {
      referral: AdminReferralRecord;
      rewardedSubscription: StoredSubscription;
    } | null = null;

    if (input.action === 'APPROVE') {
      subscription = await activateUserProSubscriptionInTx(tx, {
        userId: reqRecord.userId,
        email: reqRecord.userEmail,
        displayName: reqRecord.userDisplayName,
        paymentMethod: reqRecord.method,
        days: 30,
      });
      referralReward = await processReferralConversionRewardInTx(
        tx,
        reqRecord.userId,
        reqRecord.method
      );
      await recordAuditLog(
        actor,
        'PAYMENT_APPROVED',
        `تایید فیش ${reqRecord.method} (${reqRecord.id})`,
        reqRecord.userEmail || reqRecord.userId,
        { dbClient: tx }
      );
    } else {
      await recordAuditLog(
        actor,
        'PAYMENT_REJECTED',
        `رد فیش ${reqRecord.method} (${reqRecord.id})`,
        reqRecord.userEmail || reqRecord.userId,
        { dbClient: tx }
      );
    }

    return { request: reqRecord, subscription, referralReward };
  });
}

export async function requireAdmin(
  req: RequestWithUser,
  res: Response,
  next: NextFunction
): Promise<void> {
  if (!req.authUser || !isAdminUser(req.authUser)) {
    logger.warn('security.admin_access_denied', {
      uid: req.authUser?.uid,
      email: req.authUser?.email,
      ip: req.ip,
      path: req.path,
    });
    if (req.authUser) {
      try {
        await recordAuditLog(
          req.authUser.email || req.authUser.uid,
          'ADMIN_ACCESS_DENIED',
          `تلاش غیرمجاز برای دسترسی به مسیر مدیریتی ${req.path}`,
          req.path,
          { actorUserId: req.authUser.uid, ipAddress: req.ip }
        );
      } catch {
        // Ignore audit write failure during error response
      }
    }
    res.status(403).json({
      error: 'دسترسی به این بخش فقط برای مدیر سیستم امکان‌پذیر است.',
    });
    return;
  }
  next();
}

export async function requireProSubscription(
  req: RequestWithUser,
  res: Response,
  next: NextFunction
): Promise<void> {
  try {
    if (!req.authUser) {
      res.status(401).json({
        error: 'برای دسترسی به امکانات تخصصی ابتدا وارد حساب کاربری خود شوید.',
        code: 'AUTH_REQUIRED',
      });
      return;
    }

    const settings = await ensureAdminSettingsRow();
    const admin = isAdminUser(req.authUser);
    if (!admin && settings.maintenanceMode) {
      res.status(503).json({
        error: settings.maintenanceMessage || defaultMaintenanceMessage(),
        code: 'MAINTENANCE_MODE',
      });
      return;
    }

    const ban = await isUserBanned(req.authUser);
    if (ban.banned) {
      res.status(403).json({
        error: ban.reason || 'حساب کاربری شما توسط مدیر سیستم مسدود شده است.',
        code: 'USER_BANNED',
      });
      return;
    }

    const ent = await getUserEntitlement(req.authUser);
    if (!ent.hasProAccess) {
      res.status(403).json({
        error: `این قابلیت ویژه کاربران دارای اشتراک حرفه‌ای (${settings.monthlyPriceToman.toLocaleString('en-US')} تومان در ماه) است. لطفاً از بخش خرید اشتراک، اکانت خود را فعال کنید.`,
        code: 'SUBSCRIPTION_REQUIRED',
      });
      return;
    }
    next();
  } catch (err) {
    next(err);
  }
}

export function requireModuleAccess(moduleKey: keyof AppFeatureFlags) {
  return async (req: RequestWithUser, res: Response, next: NextFunction): Promise<void> => {
    try {
      const settings = await ensureAdminSettingsRow();
      const appControl = mapAdminSettingsToAppControl(settings);
      const admin = req.authUser ? isAdminUser(req.authUser) : false;

      if (!admin && appControl.maintenanceMode) {
        res.status(503).json({
          error: appControl.maintenanceMessage,
          code: 'MAINTENANCE_MODE',
        });
        return;
      }

      if (req.authUser) {
        const ban = await isUserBanned(req.authUser);
        if (ban.banned) {
          res.status(403).json({
            error: ban.reason || 'حساب کاربری شما توسط مدیر سیستم مسدود شده است.',
            code: 'USER_BANNED',
          });
          return;
        }
      }

      const policy = appControl.featurePolicies[moduleKey] || 'PRO';
      if (!admin && policy === 'DISABLED') {
        res.status(503).json({
          error: 'این بخش موقتاً توسط مدیر برنامه غیرفعال شده است.',
          code: 'MODULE_DISABLED',
        });
        return;
      }

      if (policy === 'FREE' || admin || appControl.promoFreeAccess) {
        next();
        return;
      }

      await requireProSubscription(req, res, next);
    } catch (err) {
      next(err);
    }
  };
}
