import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { z } from 'zod';

const EnvSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  PORT: z.coerce.number().int().min(1).max(65535).default(3000),
  APP_URL: z.string().trim().optional().default(''),
  CORS_ORIGIN: z.string().trim().optional().default(''),
  DATABASE_URL: z.string().trim().optional().default(''),
  PGLITE_DATA_DIR: z.string().trim().optional().default('./data/pglite'),
  VAULT_MASTER_KEY: z.string().trim().optional().default(''),
  VAULT_MASTER_KEY_ID: z.string().trim().optional().default('v1'),
  VAULT_MASTER_KEY_PREVIOUS: z.string().trim().optional().default(''),
  NOBITEX_VAULT_SECRET: z.string().trim().optional().default(''),
  TOOBIT_VAULT_SECRET: z.string().trim().optional().default(''),
  NOBITEX_BASE_URL: z.string().trim().optional().default('https://apiv2.nobitex.ir'),
  FIREBASE_PROJECT_ID: z.string().trim().optional().default(''),
  FIREBASE_SERVICE_ACCOUNT_JSON: z.string().trim().optional().default(''),
  ZARINPAL_MERCHANT_ID: z.string().trim().optional().default(''),
  ADMIN_EMAILS: z.string().trim().optional().default(''),
  WORKER_MODE: z.enum(['embedded', 'standalone', 'disabled']).default('embedded'),
  WORKER_POLL_MS: z.coerce.number().int().min(1000).max(300000).default(15000),
  RATE_LIMIT_MAX_GENERAL: z.coerce.number().int().min(10).max(10000).default(240),
  RATE_LIMIT_MAX_TRADE: z.coerce.number().int().min(5).max(5000).default(45),
});

export type AppConfig = z.infer<typeof EnvSchema> & {
  isProduction: boolean;
  isTest: boolean;
  allowedOrigins: string[];
};

function loadConfig(): AppConfig {
  const parsed = EnvSchema.parse(process.env);
  const isProduction = parsed.NODE_ENV === 'production';
  const isTest = parsed.NODE_ENV === 'test' || Boolean(process.env.VITEST);

  if (isProduction) {
    const rawMaster =
      parsed.VAULT_MASTER_KEY || parsed.NOBITEX_VAULT_SECRET || parsed.TOOBIT_VAULT_SECRET;
    if (!rawMaster || rawMaster.length < 32) {
      throw new Error(
        'FATAL SECURITY ERROR: VAULT_MASTER_KEY (at least 32 characters) must be set in production.'
      );
    }
    if (!parsed.DATABASE_URL) {
      throw new Error(
        'FATAL DATABASE ERROR: DATABASE_URL must be set to a PostgreSQL connection string in production.'
      );
    }
  }

  const originList = new Set<string>();
  for (const candidate of [
    ...parsed.CORS_ORIGIN.split(','),
    parsed.APP_URL,
  ]) {
    const clean = candidate.trim().replace(/\/+$/, '');
    if (clean && /^https?:\/\//i.test(clean)) {
      originList.add(clean);
    }
  }
  if (!isProduction) {
    originList.add('http://localhost:3000');
    originList.add('http://127.0.0.1:3000');
  }

  return {
    ...parsed,
    NOBITEX_BASE_URL: parsed.NOBITEX_BASE_URL.replace(/\/+$/, ''),
    isProduction,
    isTest,
    allowedOrigins: Array.from(originList),
  };
}

export const appConfig = loadConfig();

const DEV_MASTER_KEY_FILE = path.resolve(process.cwd(), '.vault-master.key');

export interface VaultKeyRing {
  primaryKeyId: string;
  primaryKey: Buffer;
  keysById: Map<string, Buffer>;
  fallbackKeys: Buffer[];
}

export function deriveAes256Key(secret: string): Buffer {
  const clean = secret.trim();
  if (/^[0-9a-f]{64}$/i.test(clean)) {
    return Buffer.from(clean, 'hex');
  }
  return crypto.createHash('sha256').update(clean, 'utf8').digest();
}

export function buildVaultKeyRing(envOverride?: {
  primaryKeyId?: string;
  primarySecret?: string;
  previousSecrets?: string;
}): VaultKeyRing {
  const isProd = process.env.NODE_ENV === 'production';
  const primaryKeyId = (
    envOverride?.primaryKeyId ||
    process.env.VAULT_MASTER_KEY_ID ||
    'v1'
  ).trim();

  const rawEnvSecret =
    envOverride?.primarySecret?.trim() ||
    process.env.VAULT_MASTER_KEY?.trim() ||
    process.env.NOBITEX_VAULT_SECRET?.trim() ||
    process.env.TOOBIT_VAULT_SECRET?.trim() ||
    '';

  let primaryKey: Buffer | null = null;
  if (rawEnvSecret) {
    if (isProd && rawEnvSecret.length < 32) {
      throw new Error('VAULT_MASTER_KEY must be at least 32 characters in production.');
    }
    if (rawEnvSecret.length >= 16) {
      primaryKey = deriveAes256Key(rawEnvSecret);
    }
  }

  if (!primaryKey) {
    if (isProd) {
      throw new Error('VAULT_MASTER_KEY is required in production mode.');
    }
    if (process.env.NODE_ENV === 'test') {
      primaryKey = deriveAes256Key('ali-trader-test-suite-master-key-32bytes!');
    } else if (fs.existsSync(DEV_MASTER_KEY_FILE)) {
      const hex = fs.readFileSync(DEV_MASTER_KEY_FILE, 'utf-8').trim();
      if (/^[0-9a-f]{64}$/i.test(hex)) {
        primaryKey = Buffer.from(hex, 'hex');
      }
    }
  }

  if (!primaryKey) {
    primaryKey = crypto.randomBytes(32);
    try {
      fs.writeFileSync(DEV_MASTER_KEY_FILE, primaryKey.toString('hex'), { mode: 0o600 });
    } catch {
      // Ignore read-only filesystem in dev fallback
    }
  }

  const keysById = new Map<string, Buffer>();
  keysById.set(primaryKeyId, primaryKey);

  const fallbackKeys: Buffer[] = [];
  const prevRaw =
    envOverride?.previousSecrets ?? process.env.VAULT_MASTER_KEY_PREVIOUS ?? '';

  for (const item of prevRaw.split(',')) {
    const clean = item.trim();
    if (!clean) continue;
    const colonIdx = clean.indexOf(':');
    if (colonIdx > 0 && colonIdx < 24) {
      const kid = clean.slice(0, colonIdx).trim();
      const sec = clean.slice(colonIdx + 1).trim();
      if (sec.length >= 16) {
        const derived = deriveAes256Key(sec);
        keysById.set(kid, derived);
        fallbackKeys.push(derived);
      }
    } else if (clean.length >= 16) {
      const derived = deriveAes256Key(clean);
      fallbackKeys.push(derived);
    }
  }

  return {
    primaryKeyId,
    primaryKey,
    keysById,
    fallbackKeys,
  };
}
