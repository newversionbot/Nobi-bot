import crypto from 'node:crypto';
import { and, desc, eq } from 'drizzle-orm';
import * as schema from '../src/db/schema.ts';
import type {
  AiCycleProCycleRecord,
  AiCycleProPosition,
  AiManagerAnalysis,
  BotExecutionConfirmationMode,
  BotType,
  DcaBotConfig,
  DcaBotState,
  DcaBotStatus,
  DcaStepUnit,
  DcaTriggerMode,
  ExecutionMode,
  GridBotConfig,
  GridBotStatus,
  GridLevelState,
  GridStepMode,
  PendingBotConfirmation,
  QuoteCurrency,
  SharedBotRiskSettings,
  SpotBalance,
  TakeProfitTarget,
  UnifiedBotSummaryRow,
  UnifiedBotsDashboardSummary,
} from '../src/types/trading.ts';
import { getMinimumOrderNotional, roundQuantityToStep } from '../src/utils/profitBotMath.ts';
import { ensureUserRecord, getDb } from './db/index.ts';
import {
  fetchNobitexKlines,
  fetchNobitexLiveBalances,
  fetchNobitexOrderStatus,
  fetchNobitexUnifiedMarkets,
  formatNobitexClientOrderId,
  getNobitexMarketRules,
  getNobitexRateLimitRemainingMs,
  NobitexAuthError,
  NobitexRateLimitError,
  placeNobitexLiveOrder,
} from './nobitexClient.ts';
import { analyzeCandles, buildGridPriceLevels } from './indicators.ts';
import {
  getActiveExchangeCredentialsForUser,
  hasActiveExchangeCredentialsForUser,
} from './securityVault.ts';
import {
  getPaperBalances,
  placePaperOrder,
  recordLiveOrderAndTrade,
} from './botEngine.ts';
import { getUserProfitBots } from './profitBotEngine.ts';

const DEFAULT_FEE_RATE = 0.0025;

// =========================================================================
// Shared Bot Risk Governance
// =========================================================================
export function defaultRiskSettings(userId: string): SharedBotRiskSettings {
  return {
    userId,
    totalBotsBudgetIrt: 100_000_000,
    totalBotsBudgetUsdt: 2_000,
    maxPerBotCapitalIrt: 35_000_000,
    maxPerBotCapitalUsdt: 1500,
    maxDailyLossIrt: 5_000_000,
    maxDailyLossUsdt: 100,
    maxTotalLossIrt: 20_000_000,
    maxTotalLossUsdt: 400,
    enableSymbolConflictLock: true,
    allowAiAdvisoryOnly: true,
    killSwitchActive: false,
    updatedAt: Date.now(),
  };
}

export async function getUserBotRiskSettings(userId: string): Promise<SharedBotRiskSettings> {
  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.botRiskSettings)
    .where(eq(schema.botRiskSettings.userId, userId))
    .limit(1);

  if (!rows[0]) {
    const def = defaultRiskSettings(userId);
    await db
      .insert(schema.botRiskSettings)
      .values({
        userId,
        totalBotsBudgetIrt: def.totalBotsBudgetIrt,
        totalBotsBudgetUsdt: def.totalBotsBudgetUsdt,
        maxPerBotCapitalIrt: def.maxPerBotCapitalIrt,
        maxPerBotCapitalUsdt: def.maxPerBotCapitalUsdt,
        maxDailyLossIrt: def.maxDailyLossIrt,
        maxDailyLossUsdt: def.maxDailyLossUsdt,
        maxTotalLossIrt: def.maxTotalLossIrt,
        maxTotalLossUsdt: def.maxTotalLossUsdt,
        enableSymbolConflictLock: def.enableSymbolConflictLock,
        allowAiAdvisoryOnly: def.allowAiAdvisoryOnly,
        killSwitchActive: def.killSwitchActive,
        updatedAt: def.updatedAt,
      })
      .onConflictDoNothing();
    return def;
  }

  const r = rows[0];
  return {
    userId: r.userId,
    totalBotsBudgetIrt: r.totalBotsBudgetIrt,
    totalBotsBudgetUsdt: r.totalBotsBudgetUsdt,
    maxPerBotCapitalIrt: r.maxPerBotCapitalIrt,
    maxPerBotCapitalUsdt: r.maxPerBotCapitalUsdt,
    maxDailyLossIrt: r.maxDailyLossIrt,
    maxDailyLossUsdt: r.maxDailyLossUsdt,
    maxTotalLossIrt: r.maxTotalLossIrt,
    maxTotalLossUsdt: r.maxTotalLossUsdt,
    enableSymbolConflictLock: r.enableSymbolConflictLock,
    allowAiAdvisoryOnly: r.allowAiAdvisoryOnly,
    killSwitchActive: r.killSwitchActive,
    updatedAt: r.updatedAt,
  };
}

export async function updateUserBotRiskSettings(
  userId: string,
  updates: Partial<SharedBotRiskSettings>
): Promise<SharedBotRiskSettings> {
  const current = await getUserBotRiskSettings(userId);
  const next: SharedBotRiskSettings = {
    ...current,
    totalBotsBudgetIrt: Math.max(0, Number(updates.totalBotsBudgetIrt ?? current.totalBotsBudgetIrt)),
    totalBotsBudgetUsdt: Math.max(0, Number(updates.totalBotsBudgetUsdt ?? current.totalBotsBudgetUsdt)),
    maxPerBotCapitalIrt: Math.max(0, Number(updates.maxPerBotCapitalIrt ?? current.maxPerBotCapitalIrt)),
    maxPerBotCapitalUsdt: Math.max(0, Number(updates.maxPerBotCapitalUsdt ?? current.maxPerBotCapitalUsdt)),
    maxDailyLossIrt: Math.max(0, Number(updates.maxDailyLossIrt ?? current.maxDailyLossIrt)),
    maxDailyLossUsdt: Math.max(0, Number(updates.maxDailyLossUsdt ?? current.maxDailyLossUsdt)),
    maxTotalLossIrt: Math.max(0, Number(updates.maxTotalLossIrt ?? current.maxTotalLossIrt)),
    maxTotalLossUsdt: Math.max(0, Number(updates.maxTotalLossUsdt ?? current.maxTotalLossUsdt)),
    enableSymbolConflictLock:
      updates.enableSymbolConflictLock !== undefined
        ? Boolean(updates.enableSymbolConflictLock)
        : current.enableSymbolConflictLock,
    allowAiAdvisoryOnly:
      updates.allowAiAdvisoryOnly !== undefined
        ? Boolean(updates.allowAiAdvisoryOnly)
        : current.allowAiAdvisoryOnly,
    killSwitchActive:
      updates.killSwitchActive !== undefined
        ? Boolean(updates.killSwitchActive)
        : current.killSwitchActive,
    updatedAt: Date.now(),
  };

  const db = getDb();
  await db
    .update(schema.botRiskSettings)
    .set({
      totalBotsBudgetIrt: next.totalBotsBudgetIrt,
      totalBotsBudgetUsdt: next.totalBotsBudgetUsdt,
      maxPerBotCapitalIrt: next.maxPerBotCapitalIrt,
      maxPerBotCapitalUsdt: next.maxPerBotCapitalUsdt,
      maxDailyLossIrt: next.maxDailyLossIrt,
      maxDailyLossUsdt: next.maxDailyLossUsdt,
      maxTotalLossIrt: next.maxTotalLossIrt,
      maxTotalLossUsdt: next.maxTotalLossUsdt,
      enableSymbolConflictLock: next.enableSymbolConflictLock,
      allowAiAdvisoryOnly: next.allowAiAdvisoryOnly,
      killSwitchActive: next.killSwitchActive,
      updatedAt: next.updatedAt,
    })
    .where(eq(schema.botRiskSettings.userId, userId));

  return next;
}

export async function validateSharedExecutionGuards(input: {
  userId: string;
  botId: string;
  botType: BotType;
  symbol: string;
  quoteCurrency: QuoteCurrency;
  side: 'BUY' | 'SELL';
  requestedQuoteAmount: number;
}): Promise<{ ok: true } | { ok: false; reasonFa: string }> {
  const settings = await getUserBotRiskSettings(input.userId);
  if (settings.killSwitchActive) {
    return {
      ok: false,
      reasonFa: 'کلید توقف اضطراری (Kill Switch) ربات‌ها فعال است. تا غیرفعال‌سازی توسط شما، سفارش جدید ثبت نمی‌شود.',
    };
  }

  const db = getDb();
  const [strategyRows, gridRows, dcaRows, profitBots, aiCycleRows, tradeRows] = await Promise.all([
    db.select().from(schema.tradingBots).where(eq(schema.tradingBots.userId, input.userId)),
    db.select().from(schema.gridBots).where(eq(schema.gridBots.userId, input.userId)),
    db.select().from(schema.dcaBots).where(eq(schema.dcaBots.userId, input.userId)),
    getUserProfitBots(input.userId),
    db.select().from(schema.aiCycleProBots).where(eq(schema.aiCycleProBots.userId, input.userId)),
    db.select().from(schema.trades).where(eq(schema.trades.userId, input.userId)),
  ]);

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const dayStartMs = startOfDay.getTime();

  let dailyLossQuote = 0;
  let totalLossQuote = 0;
  for (const tr of tradeRows) {
    if (tr.quoteCurrency !== input.quoteCurrency) continue;
    const pnl = Number(tr.realizedPnlQuote || 0);
    if (pnl < 0) {
      totalLossQuote += Math.abs(pnl);
      if (tr.executedAt >= dayStartMs) {
        dailyLossQuote += Math.abs(pnl);
      }
    }
  }

  const maxDailyLoss =
    input.quoteCurrency === 'IRT' ? settings.maxDailyLossIrt : settings.maxDailyLossUsdt;
  const maxTotalLoss =
    input.quoteCurrency === 'IRT' ? settings.maxTotalLossIrt : settings.maxTotalLossUsdt;

  if (maxDailyLoss > 0 && dailyLossQuote >= maxDailyLoss && input.side === 'BUY') {
    return {
      ok: false,
      reasonFa: `سقف ضرر روزانه (${maxDailyLoss.toLocaleString('en-US')} ${
        input.quoteCurrency === 'IRT' ? 'تومان' : 'USDT'
      }) پر شده است؛ ورود جدید مسدود شد.`,
    };
  }

  if (maxTotalLoss > 0 && totalLossQuote >= maxTotalLoss && input.side === 'BUY') {
    return {
      ok: false,
      reasonFa: `سقف ضرر کل ربات‌ها (${maxTotalLoss.toLocaleString('en-US')} ${
        input.quoteCurrency === 'IRT' ? 'تومان' : 'USDT'
      }) پر شده است؛ برای محافظت از سرمایه، خرید جدید متوقف شد.`,
    };
  }

  // Per-bot capital cap check on buys
  if (input.side === 'BUY') {
    const perBotCap =
      input.quoteCurrency === 'IRT' ? settings.maxPerBotCapitalIrt : settings.maxPerBotCapitalUsdt;
    if (perBotCap > 0 && input.requestedQuoteAmount > perBotCap + 1) {
      return {
        ok: false,
        reasonFa: `مبلغ سفارش از سقف سرمایه مجاز هر ربات (${perBotCap.toLocaleString('en-US')} ${
          input.quoteCurrency === 'IRT' ? 'تومان' : 'USDT'
        }) بیشتر است.`,
      };
    }
  }

  // Symbol conflict lock (prevent contradictory / overlapping active bots on same symbol)
  if (settings.enableSymbolConflictLock && input.side === 'BUY') {
    const cleanSym = input.symbol.toUpperCase();
    const otherActiveOnSameSymbol: string[] = [];
    for (const s of strategyRows) {
      if (s.id !== input.botId && s.symbol.toUpperCase() === cleanSym && s.status === 'RUNNING') {
        otherActiveOnSameSymbol.push(s.name);
      }
    }
    for (const p of profitBots) {
      if (p.id !== input.botId && p.symbol.toUpperCase() === cleanSym && p.isActive) {
        otherActiveOnSameSymbol.push(p.name);
      }
    }
    for (const g of gridRows) {
      if (g.id !== input.botId && g.symbol.toUpperCase() === cleanSym && g.isActive) {
        otherActiveOnSameSymbol.push(g.name);
      }
    }
    for (const d of dcaRows) {
      if (d.id !== input.botId && d.symbol.toUpperCase() === cleanSym && d.isActive) {
        otherActiveOnSameSymbol.push(d.name);
      }
    }
    for (const ac of aiCycleRows) {
      if (ac.id !== input.botId && ac.symbol.toUpperCase() === cleanSym && ac.isActive) {
        otherActiveOnSameSymbol.push(ac.name);
      }
    }
    if (otherActiveOnSameSymbol.length > 0) {
      return {
        ok: false,
        reasonFa: `قفل تداخل ارز فعال است: ربات «${otherActiveOnSameSymbol[0]}» هم‌اکنون روی نماد ${cleanSym} فعال است. برای جلوگیری از معاملات متناقض، ورود مسدود شد.`,
      };
    }
  }

  // Total shared budget guard
  if (input.side === 'BUY') {
    const budget =
      input.quoteCurrency === 'IRT' ? settings.totalBotsBudgetIrt : settings.totalBotsBudgetUsdt;
    if (budget > 0) {
      let committed = 0;
      for (const s of strategyRows) {
        if (s.quoteCurrency === input.quoteCurrency && s.id !== input.botId && s.activePositionJson) {
          committed += Number(s.orderAmount || 0);
        }
      }
      for (const p of profitBots) {
        if (p.quoteCurrency === input.quoteCurrency && p.id !== input.botId && p.activePosition) {
          committed += Number(p.activePosition.totalBuyCostQuote || p.entryAmount || 0);
        }
      }
      for (const g of gridRows) {
        if (g.quoteCurrency === input.quoteCurrency && g.id !== input.botId && g.isActive) {
          const st = (g.statsJson || {}) as { currentCapitalInvolved?: number };
          committed += Number(st.currentCapitalInvolved || 0);
        }
      }
      for (const d of dcaRows) {
        if (d.quoteCurrency === input.quoteCurrency && d.id !== input.botId && d.isActive) {
          const st = (d.stateJson || {}) as { totalInvestedQuote?: number };
          committed += Number(st.totalInvestedQuote || 0);
        }
      }
      for (const ac of aiCycleRows) {
        if (ac.quoteCurrency === input.quoteCurrency && ac.id !== input.botId && ac.activePositionJson) {
          const pos = ac.activePositionJson as Partial<AiCycleProPosition>;
          committed += Number(pos.totalBuyCostQuote || ac.capitalAmount || 0);
        }
      }

      if (committed + input.requestedQuoteAmount > budget + 1) {
        return {
          ok: false,
          reasonFa: `بودجه آزاد مشترک ربات‌ها کافی نیست (مصرف‌شده: ${Math.round(
            committed
          ).toLocaleString('en-US')} / کل بودجه: ${Math.round(budget).toLocaleString('en-US')}).`,
        };
      }
    }
  }

  return { ok: true };
}

// =========================================================================
// Pending Manual Confirmations Queue
// =========================================================================
function mapConfirmationRow(
  row: typeof schema.pendingBotConfirmations.$inferSelect
): PendingBotConfirmation {
  return {
    id: row.id,
    userId: row.userId,
    botId: row.botId,
    botType: row.botType as BotType,
    botName: row.botName,
    symbol: row.symbol,
    baseAsset: row.baseAsset,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    mode: (row.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    side: row.side === 'SELL' ? 'SELL' : 'BUY',
    orderType: row.orderType === 'LIMIT' ? 'LIMIT' : 'MARKET',
    suggestedPrice: row.suggestedPrice,
    quantity: row.quantity,
    quoteAmount: row.quoteAmount,
    estimatedFeeQuote: row.estimatedFeeQuote,
    reasonFa: row.reasonFa,
    riskSummaryFa: row.riskSummaryFa,
    metaJson: (row.metaJson as Record<string, unknown>) || undefined,
    status: row.status as PendingBotConfirmation['status'],
    createdAt: row.createdAt,
    expiresAt: row.expiresAt,
    resolvedAt: row.resolvedAt ?? null,
  };
}

export async function listPendingConfirmations(userId: string): Promise<PendingBotConfirmation[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.pendingBotConfirmations)
    .where(eq(schema.pendingBotConfirmations.userId, userId))
    .orderBy(desc(schema.pendingBotConfirmations.createdAt))
    .limit(50);

  const now = Date.now();
  const out: PendingBotConfirmation[] = [];
  for (const r of rows) {
    if (r.status === 'PENDING' && r.expiresAt < now) {
      await db
        .update(schema.pendingBotConfirmations)
        .set({ status: 'EXPIRED', resolvedAt: now })
        .where(eq(schema.pendingBotConfirmations.id, r.id));
      out.push({ ...mapConfirmationRow(r), status: 'EXPIRED', resolvedAt: now });
    } else {
      out.push(mapConfirmationRow(r));
    }
  }
  return out;
}

export async function createPendingConfirmation(input: {
  userId: string;
  botId: string;
  botType: BotType;
  botName: string;
  symbol: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  mode: ExecutionMode;
  side: 'BUY' | 'SELL';
  orderType: 'LIMIT' | 'MARKET';
  suggestedPrice: number;
  quantity: number;
  quoteAmount: number;
  estimatedFeeQuote: number;
  reasonFa: string;
  riskSummaryFa: string;
  metaJson?: Record<string, unknown>;
  ttlMinutes?: number;
}): Promise<PendingBotConfirmation> {
  const db = getDb();
  // Avoid duplicate pending confirmation for same bot + side + level/stage
  const existing = await db
    .select()
    .from(schema.pendingBotConfirmations)
    .where(
      and(
        eq(schema.pendingBotConfirmations.userId, input.userId),
        eq(schema.pendingBotConfirmations.botId, input.botId),
        eq(schema.pendingBotConfirmations.side, input.side),
        eq(schema.pendingBotConfirmations.status, 'PENDING')
      )
    );
  const now = Date.now();
  const activeExisting = existing.find((e) => e.expiresAt > now);
  if (activeExisting) {
    return mapConfirmationRow(activeExisting);
  }

  const id = `pconf-${now}-${crypto.randomBytes(3).toString('hex')}`;
  const expiresAt = now + (input.ttlMinutes ?? 30) * 60_000;

  await db.insert(schema.pendingBotConfirmations).values({
    id,
    userId: input.userId,
    botId: input.botId,
    botType: input.botType,
    botName: input.botName,
    symbol: input.symbol,
    baseAsset: input.baseAsset,
    quoteCurrency: input.quoteCurrency,
    mode: input.mode,
    side: input.side,
    orderType: input.orderType,
    suggestedPrice: input.suggestedPrice,
    quantity: input.quantity,
    quoteAmount: input.quoteAmount,
    estimatedFeeQuote: input.estimatedFeeQuote,
    reasonFa: input.reasonFa,
    riskSummaryFa: input.riskSummaryFa,
    metaJson: input.metaJson || null,
    status: 'PENDING',
    createdAt: now,
    expiresAt,
    resolvedAt: null,
  });

  const rows = await db
    .select()
    .from(schema.pendingBotConfirmations)
    .where(eq(schema.pendingBotConfirmations.id, id))
    .limit(1);
  return mapConfirmationRow(rows[0]);
}

export async function resolvePendingConfirmation(input: {
  userId: string;
  confirmationId: string;
  decision: 'APPROVE' | 'REJECT';
  confirmLive?: boolean;
}): Promise<PendingBotConfirmation> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.pendingBotConfirmations)
    .where(
      and(
        eq(schema.pendingBotConfirmations.id, input.confirmationId),
        eq(schema.pendingBotConfirmations.userId, input.userId)
      )
    )
    .limit(1);

  const row = rows[0];
  if (!row) throw new Error('درخواست تأیید معامله یافت نشد.');
  if (row.status !== 'PENDING') {
    throw new Error('این درخواست قبلاً تعیین تکلیف شده است.');
  }

  const now = Date.now();
  if (row.expiresAt < now) {
    await db
      .update(schema.pendingBotConfirmations)
      .set({ status: 'EXPIRED', resolvedAt: now })
      .where(eq(schema.pendingBotConfirmations.id, row.id));
    throw new Error('مهلت تأیید این معامله به پایان رسیده است.');
  }

  if (input.decision === 'REJECT') {
    const [updated] = await db
      .update(schema.pendingBotConfirmations)
      .set({ status: 'REJECTED', resolvedAt: now })
      .where(eq(schema.pendingBotConfirmations.id, row.id))
      .returning();
    return mapConfirmationRow(updated);
  }

  if (row.mode === 'live' && !input.confirmLive) {
    throw new Error('برای اجرای سفارش با سرمایه واقعی، تأیید صریح الزامی است.');
  }

  const idempotencyKey = `conf:${row.id}:${row.side}`;
  if (row.mode === 'live') {
    const creds = await getActiveExchangeCredentialsForUser(input.userId);
    if (!creds) throw new NobitexAuthError('کلید صرافی نوبیتکس برای این حساب یافت نشد.');
    const order = await placeNobitexLiveOrder(
      {
        baseAsset: row.baseAsset,
        quoteCurrency: row.quoteCurrency as QuoteCurrency,
        side: row.side as 'BUY' | 'SELL',
        type: row.orderType as 'LIMIT' | 'MARKET',
        quantity: row.quantity,
        price: row.orderType === 'LIMIT' ? row.suggestedPrice : undefined,
        source: 'BOT',
        botId: row.botId,
        clientOrderId: formatNobitexClientOrderId(idempotencyKey),
      },
      creds
    );
    await recordLiveOrderAndTrade(input.userId, order, { idempotencyKey });
  } else {
    await placePaperOrder(input.userId, {
      baseAsset: row.baseAsset,
      quoteCurrency: row.quoteCurrency as QuoteCurrency,
      side: row.side as 'BUY' | 'SELL',
      type: 'MARKET',
      quantity: row.quantity,
      price: row.suggestedPrice,
      source: 'BOT',
      botId: row.botId,
      idempotencyKey,
    });
  }

  // Update owning bot state if Grid or DCA
  if (row.botType === 'DCA') {
    const dca = await getUserDcaBotById(input.userId, row.botId);
    if (dca) {
      const nextState: DcaBotState = { ...dca.state };
      if (row.side === 'BUY') {
        const netQty = row.quantity * (1 - dca.feeRate);
        const totalCost = nextState.totalInvestedQuote + row.quoteAmount;
        const totalNetQty = nextState.netOwnedQty + netQty;
        nextState.stagesCompleted += 1;
        nextState.totalHoldingQty += row.quantity;
        nextState.netOwnedQty = totalNetQty;
        nextState.totalInvestedQuote = totalCost;
        nextState.totalBuyFeesQuote += row.estimatedFeeQuote;
        nextState.avgBuyPrice = totalNetQty > 0 ? totalCost / totalNetQty : row.suggestedPrice;
        nextState.lastBuyPrice = row.suggestedPrice;
        nextState.highestPriceSinceEntry = Math.max(
          nextState.highestPriceSinceEntry || 0,
          row.suggestedPrice
        );
        nextState.nextTriggerAt = now + dca.intervalMinutes * 60_000;
      } else {
        const proceeds = row.quoteAmount - row.estimatedFeeQuote;
        const pnl = proceeds - nextState.totalInvestedQuote;
        dca.stats.completedCycles += 1;
        dca.stats.realizedNetProfitQuote += pnl;
        dca.stats.totalFeesPaidQuote += row.estimatedFeeQuote + nextState.totalBuyFeesQuote;
        nextState.stagesCompleted = 0;
        nextState.totalHoldingQty = 0;
        nextState.netOwnedQty = 0;
        nextState.avgBuyPrice = 0;
        nextState.totalInvestedQuote = 0;
        nextState.totalBuyFeesQuote = 0;
        nextState.trailingTpArmed = false;
      }
      await db
        .update(schema.dcaBots)
        .set({
          stateJson: nextState,
          statsJson: dca.stats,
          lastStatusReason: `سفارش ${row.side === 'BUY' ? 'خرید' : 'فروش'} با تأیید دستی شما اجرا شد.`,
          updatedAt: now,
        })
        .where(eq(schema.dcaBots.id, dca.id));
    }
  } else if (row.botType === 'GRID') {
    const grid = await getUserGridBotById(input.userId, row.botId);
    if (grid) {
      const meta = (row.metaJson || {}) as Record<string, unknown>;
      const lvlIdx = Number(meta.levelIndex ?? -1);
      const nextLevels = grid.allocatedLevels.map((lv) => {
        if (lv.index !== lvlIdx) return lv;
        if (row.side === 'BUY') {
          return {
            ...lv,
            status: 'HOLDING' as const,
            qty: row.quantity * (1 - grid.feeRate),
            buyPrice: row.suggestedPrice,
            buyFeeQuote: row.estimatedFeeQuote,
            updatedAt: now,
          };
        }
        return {
          ...lv,
          status: 'IDLE' as const,
          qty: 0,
          buyPrice: undefined,
          buyFeeQuote: undefined,
          updatedAt: now,
        };
      });
      await db
        .update(schema.gridBots)
        .set({
          allocatedLevelsJson: nextLevels,
          lastStatusReason: `پله گرید ${lvlIdx + 1} با تأیید دستی شما (${row.side === 'BUY' ? 'خرید' : 'فروش'}) اجرا شد.`,
          updatedAt: now,
        })
        .where(eq(schema.gridBots.id, grid.id));
    }
  } else if (row.botType === 'STRATEGY' || row.botType === 'FIXED_PRICE') {
    const stratRows = await db
      .select()
      .from(schema.tradingBots)
      .where(and(eq(schema.tradingBots.id, row.botId), eq(schema.tradingBots.userId, input.userId)))
      .limit(1);
    const sb = stratRows[0];
    if (sb) {
      if (row.side === 'BUY') {
        const meta = (row.metaJson || {}) as Record<string, unknown>;
        const slPct = Number(meta.stopLossPercent || 0);
        const tpPct = Number(meta.takeProfitPercent || 0);
        const fixedTp = Number(meta.targetSellPrice || 0);
        await db
          .update(schema.tradingBots)
          .set({
            activePositionJson: {
              entryPrice: row.suggestedPrice,
              quantity: row.quantity * (1 - DEFAULT_FEE_RATE),
              initialQuantity: row.quantity * (1 - DEFAULT_FEE_RATE),
              highestPrice: row.suggestedPrice,
              stopLossPrice: slPct > 0 ? row.suggestedPrice * (1 - slPct / 100) : 0,
              takeProfitPrice:
                fixedTp > 0 ? fixedTp : tpPct > 0 ? row.suggestedPrice * (1 + tpPct / 100) : 0,
              openedAt: now,
              executedTpIds: [],
            },
            lastSignalSummary: 'سفارش خرید با تأیید دستی شما انجام شد و پوزیشن باز شد.',
            updatedAt: now,
          })
          .where(eq(schema.tradingBots.id, sb.id));
      } else {
        await db
          .update(schema.tradingBots)
          .set({
            activePositionJson: null,
            lastSignalSummary: 'فروش با تأیید دستی شما انجام شد و پوزیشن بسته شد.',
            updatedAt: now,
          })
          .where(eq(schema.tradingBots.id, sb.id));
      }
    }
  } else if (row.botType === 'PROFIT') {
    const pRows = await db
      .select()
      .from(schema.profitBots)
      .where(and(eq(schema.profitBots.id, row.botId), eq(schema.profitBots.userId, input.userId)))
      .limit(1);
    const pb = pRows[0];
    if (pb) {
      if (row.side === 'BUY') {
        const netOwnedQty = row.quantity * (1 - pb.feeRate);
        const totalCost = row.quoteAmount;
        await db
          .update(schema.profitBots)
          .set({
            botStatus: 'WAITING_FOR_PROFIT',
            activePositionJson: {
              cycleIndex: Number(
                (row.metaJson as Record<string, unknown> | null | undefined)?.cycleIndex || 1
              ),
              buyOrderId: `manual-${row.id}`,
              actualBuyAvgPrice: row.suggestedPrice,
              grossBoughtQty: row.quantity,
              netOwnedQty,
              buyFeeQuote: row.estimatedFeeQuote,
              otherFeesQuote: pb.otherFeesQuote,
              totalBuyCostQuote: totalCost,
              buyFilledAt: now,
              lastEvaluatedAt: now,
              fromExistingBalance: false,
            },
            lastStatusReason: 'سفارش خرید ربات سود با تأیید دستی شما انجام شد و در حال پایش سود هدف است.',
            updatedAt: now,
          })
          .where(eq(schema.profitBots.id, pb.id));
      } else {
        await db
          .update(schema.profitBots)
          .set({
            botStatus: 'SELL_FILLED',
            activePositionJson: null,
            pendingOrderJson: null,
            lastStatusReason: 'فروش ربات سود با تأیید دستی شما تکمیل شد.',
            updatedAt: now,
          })
          .where(eq(schema.profitBots.id, pb.id));
      }
    }
  } else if (row.botType === 'AI_CYCLE_PRO') {
    const { getUserAiCycleProBotById, finalizeAiCycleProSell } = await import(
      './aiCycleProEngine.ts'
    );
    const ac = await getUserAiCycleProBotById(input.userId, row.botId);
    if (ac) {
      if (row.side === 'BUY') {
        const meta = (row.metaJson || {}) as Record<string, unknown>;
        const targetNetPct = Math.max(
          ac.minTargetNetProfitPercent,
          Number(meta.targetNetProfitPercent || ac.minTargetNetProfitPercent)
        );
        const slPct = Math.min(ac.stopLossPercent, Number(meta.stopLossPercent || ac.stopLossPercent));
        const netOwnedQty = row.quantity * (1 - ac.feeRate);
        const totalCost = row.quoteAmount;
        const feeFactor = Math.max(0.85, 1 - ac.feeRate);
        const rawTargetPrice = (totalCost * (1 + targetNetPct / 100)) / feeFactor / Math.max(1e-12, netOwnedQty);
        const targetSellPrice =
          ac.quoteCurrency === 'IRT' ? Math.ceil(rawTargetPrice) : Number(rawTargetPrice.toFixed(6));
        const stopLossPrice = row.suggestedPrice * (1 - slPct / 100);
        await db
          .update(schema.aiCycleProBots)
          .set({
            status: 'HOLDING_POSITION',
            activePositionJson: {
              cycleIndex: Number(meta.cycleIndex || ac.stats.completedCycles + 1),
              buyOrderId: `manual-${row.id}`,
              requestedQuoteAmount: totalCost,
              requestedQty: row.quantity,
              filledGrossQty: row.quantity,
              netOwnedQty,
              actualBuyAvgPrice: row.suggestedPrice,
              buyFeeQuote: row.estimatedFeeQuote,
              totalBuyCostQuote: totalCost,
              targetNetProfitPercent: targetNetPct,
              targetSellPrice,
              stopLossPrice,
              highestPrice: row.suggestedPrice,
              buyFilledAt: now,
              lastEvaluatedAt: now,
            },
            lastPrice: row.suggestedPrice,
            lastStatusReason:
              'خرید AI Cycle Pro با تأیید دستی شما انجام شد و پایش فروش هوشمند آغاز گردید.',
            updatedAt: now,
          })
          .where(eq(schema.aiCycleProBots.id, ac.id));
      } else if (ac.activePosition) {
        const meta = (row.metaJson || {}) as Record<string, unknown>;
        const exitReason = (
          meta.exitReason === 'STOP_LOSS' ||
          meta.exitReason === 'DAILY_LOSS_CAP' ||
          meta.exitReason === 'MANUAL_SELL'
            ? meta.exitReason
            : 'AI_TARGET_PROFIT'
        ) as AiCycleProCycleRecord['exitReason'];
        await finalizeAiCycleProSell({
          bot: ac,
          pos: ac.activePosition,
          sellOrder: {
            orderId: `manual-${row.id}`,
            symbol: ac.symbol,
            baseAsset: ac.baseAsset,
            quoteCurrency: ac.quoteCurrency,
            side: 'SELL',
            type: 'MARKET',
            price: row.suggestedPrice,
            quantity: row.quantity,
            executedQty: row.quantity,
            totalQuoteAmount: row.quoteAmount,
            status: 'FILLED',
            mode: ac.mode,
            source: 'BOT',
            botId: ac.id,
            createdAt: now,
          },
          exitReason,
          aiExitSummaryFa: String(meta.aiExitSummaryFa || 'فروش با تأیید دستی کاربر تکمیل شد.'),
          slippagePercent: Number(meta.slippagePercent || 0),
          completedAt: now,
        });
      }
    }
  }

  const [updated] = await db
    .update(schema.pendingBotConfirmations)
    .set({ status: 'APPROVED', resolvedAt: now })
    .where(eq(schema.pendingBotConfirmations.id, row.id))
    .returning();
  return mapConfirmationRow(updated);
}

// =========================================================================
// Grid Bot CRUD & Evaluation Engine
// =========================================================================
function mapGridBotRow(row: typeof schema.gridBots.$inferSelect): GridBotConfig {
  const levels = Array.isArray(row.allocatedLevelsJson)
    ? (row.allocatedLevelsJson as GridLevelState[])
    : [];
  const rawStats = (row.statsJson || {}) as Partial<GridBotConfig['stats']>;
  return {
    id: row.id,
    ownerId: row.userId,
    name: row.name,
    baseAsset: row.baseAsset,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    symbol: row.symbol,
    mode: (row.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    isActive: row.isActive,
    status: row.status as GridBotStatus,
    lowerPrice: row.lowerPrice,
    upperPrice: row.upperPrice,
    gridLevels: row.gridLevels,
    stepMode: row.stepMode === 'GEOMETRIC' ? 'GEOMETRIC' : 'ARITHMETIC',
    totalCapital: row.totalCapital,
    maxCapitalInvolved: row.maxCapitalInvolved,
    stopOnBreakout: row.stopOnBreakout,
    alertOnBreakout: row.alertOnBreakout,
    feeRate: row.feeRate,
    estimatedSlippagePercent: row.estimatedSlippagePercent,
    executionConfirmationMode: (row.executionConfirmationMode === 'MANUAL_CONFIRM'
      ? 'MANUAL_CONFIRM'
      : 'AUTO') as BotExecutionConfirmationMode,
    notifyTelegram: row.notifyTelegram,
    allocatedLevels: levels,
    stats: {
      completedCycles: Number(rawStats.completedCycles || 0),
      totalNetProfitQuote: Number(rawStats.totalNetProfitQuote || 0),
      totalFeesPaidQuote: Number(rawStats.totalFeesPaidQuote || 0),
      openOrdersCount: Number(rawStats.openOrdersCount || 0),
      currentCapitalInvolved: Number(rawStats.currentCapitalInvolved || 0),
      netProfitPerCyclePercent: Number(rawStats.netProfitPerCyclePercent || 0),
    },
    lastPrice: row.lastPrice,
    lastStatusReason: row.lastStatusReason,
    lastError: row.lastError ?? null,
    lastCheckedAt: row.lastCheckedAt ?? null,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

function buildInitialGridLevels(
  lowerPrice: number,
  upperPrice: number,
  gridLevels: number,
  stepMode: GridStepMode
): { levels: GridLevelState[]; netProfitPerCyclePct: number } {
  const prices = buildGridPriceLevels(lowerPrice, upperPrice, gridLevels, stepMode);
  const levels: GridLevelState[] = prices.map((price, index) => ({
    index,
    price,
    side: index === prices.length - 1 ? 'SELL' : 'BUY',
    status: 'IDLE',
    qty: 0,
  }));

  let grossStepPct = 0;
  if (prices.length >= 2 && prices[0] > 0) {
    grossStepPct = ((prices[1] - prices[0]) / prices[0]) * 100;
  }
  const netProfitPerCyclePct = Math.max(-5, grossStepPct - DEFAULT_FEE_RATE * 200);
  return { levels, netProfitPerCyclePct: Number(netProfitPerCyclePct.toFixed(2)) };
}

export async function getUserGridBots(userId: string): Promise<GridBotConfig[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.gridBots)
    .where(eq(schema.gridBots.userId, userId))
    .orderBy(desc(schema.gridBots.createdAt));
  return rows.map(mapGridBotRow);
}

export async function getUserGridBotById(
  userId: string,
  botId: string
): Promise<GridBotConfig | null> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.gridBots)
    .where(and(eq(schema.gridBots.id, botId), eq(schema.gridBots.userId, userId)))
    .limit(1);
  return rows[0] ? mapGridBotRow(rows[0]) : null;
}

export async function createGridBot(
  userId: string,
  input: {
    name?: string;
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    mode?: ExecutionMode;
    confirmLive?: boolean;
    startImmediately?: boolean;
    lowerPrice: number;
    upperPrice: number;
    gridLevels: number;
    stepMode?: GridStepMode;
    totalCapital: number;
    maxCapitalInvolved?: number;
    stopOnBreakout?: boolean;
    alertOnBreakout?: boolean;
    feeRate?: number;
    estimatedSlippagePercent?: number;
    executionConfirmationMode?: BotExecutionConfirmationMode;
    notifyTelegram?: boolean;
  }
): Promise<GridBotConfig> {
  const mode: ExecutionMode = input.mode === 'live' ? 'live' : 'paper';
  if (mode === 'live') {
    if (!input.confirmLive) throw new Error('برای ربات گرید واقعی، تأیید صریح الزامی است.');
    if (!(await hasActiveExchangeCredentialsForUser(userId))) {
      throw new Error('توکن API نوبیتکس برای معاملات واقعی ثبت نشده است.');
    }
  }
  if (!(input.lowerPrice > 0) || !(input.upperPrice > input.lowerPrice)) {
    throw new Error('محدوده قیمت پایین و بالای گرید معتبر نیست.');
  }
  const levelsCount = Math.max(3, Math.min(30, Math.round(input.gridLevels)));
  if (!(input.totalCapital > 0)) {
    throw new Error('سرمایه کل ربات گرید باید بزرگ‌تر از صفر باشد.');
  }

  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const now = Date.now();
  const baseAsset = input.baseAsset.toUpperCase().trim();
  const quoteCurrency: QuoteCurrency = input.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
  const symbol = `${baseAsset}${quoteCurrency}`;
  const stepMode: GridStepMode = input.stepMode === 'GEOMETRIC' ? 'GEOMETRIC' : 'ARITHMETIC';
  const { levels, netProfitPerCyclePct } = buildInitialGridLevels(
    input.lowerPrice,
    input.upperPrice,
    levelsCount,
    stepMode
  );

  const id = `grid-${now}-${crypto.randomBytes(3).toString('hex')}`;
  const isActive = Boolean(input.startImmediately);

  const record = {
    id,
    userId,
    name: (input.name || `ربات گرید ${baseAsset}`).trim().slice(0, 100),
    baseAsset,
    quoteCurrency,
    symbol,
    mode,
    isActive,
    status: isActive ? 'RUNNING' : 'PAUSED',
    lowerPrice: input.lowerPrice,
    upperPrice: input.upperPrice,
    gridLevels: levelsCount,
    stepMode,
    totalCapital: input.totalCapital,
    maxCapitalInvolved: Math.max(input.totalCapital, Number(input.maxCapitalInvolved || input.totalCapital)),
    stopOnBreakout: input.stopOnBreakout !== false,
    alertOnBreakout: input.alertOnBreakout !== false,
    feeRate: input.feeRate ?? DEFAULT_FEE_RATE,
    estimatedSlippagePercent: input.estimatedSlippagePercent ?? 0.15,
    executionConfirmationMode:
      input.executionConfirmationMode === 'MANUAL_CONFIRM' ? 'MANUAL_CONFIRM' : 'AUTO',
    notifyTelegram: input.notifyTelegram !== false,
    allocatedLevelsJson: levels,
    statsJson: {
      completedCycles: 0,
      totalNetProfitQuote: 0,
      totalFeesPaidQuote: 0,
      openOrdersCount: 0,
      currentCapitalInvolved: 0,
      netProfitPerCyclePercent: netProfitPerCyclePct,
    },
    lastPrice: 0,
    lastStatusReason: isActive
      ? 'ربات گرید فعال شد و پله‌های خرید و فروش را پایش می‌کند.'
      : 'ربات گرید ذخیره شد و آماده شروع است.',
    lastError: null,
    lastCheckedAt: null,
    createdAt: now,
    updatedAt: now,
  };

  await db.insert(schema.gridBots).values(record);
  const created = await getUserGridBotById(userId, id);
  if (!created) throw new Error('خطا در ایجاد ربات گرید.');
  return created;
}

export async function updateGridBot(
  userId: string,
  botId: string,
  updates: Partial<{
    name: string;
    lowerPrice: number;
    upperPrice: number;
    gridLevels: number;
    stepMode: GridStepMode;
    totalCapital: number;
    maxCapitalInvolved: number;
    stopOnBreakout: boolean;
    alertOnBreakout: boolean;
    executionConfirmationMode: BotExecutionConfirmationMode;
    notifyTelegram: boolean;
    mode: ExecutionMode;
    confirmLive: boolean;
  }>
): Promise<GridBotConfig> {
  const existing = await getUserGridBotById(userId, botId);
  if (!existing) throw new Error('ربات گرید یافت نشد.');

  const nextLower = updates.lowerPrice ?? existing.lowerPrice;
  const nextUpper = updates.upperPrice ?? existing.upperPrice;
  if (!(nextLower > 0) || !(nextUpper > nextLower)) {
    throw new Error('بازه قیمت پایین و بالا معتبر نیست.');
  }
  const nextCount = Math.max(3, Math.min(30, Math.round(updates.gridLevels ?? existing.gridLevels)));
  const nextStepMode = updates.stepMode ?? existing.stepMode;

  const rangeChanged =
    nextLower !== existing.lowerPrice ||
    nextUpper !== existing.upperPrice ||
    nextCount !== existing.gridLevels ||
    nextStepMode !== existing.stepMode;

  let nextLevels = existing.allocatedLevels;
  let nextCyclePct = existing.stats.netProfitPerCyclePercent;
  if (rangeChanged) {
    const built = buildInitialGridLevels(nextLower, nextUpper, nextCount, nextStepMode);
    nextLevels = built.levels;
    nextCyclePct = built.netProfitPerCyclePct;
  }

  if (updates.mode === 'live') {
    if (!updates.confirmLive && existing.mode !== 'live') {
      throw new Error('برای تغییر به حساب واقعی نوبیتکس تأیید صریح لازم است.');
    }
    if (!(await hasActiveExchangeCredentialsForUser(userId))) {
      throw new Error('کلید API نوبیتکس برای معاملات واقعی ثبت نشده است.');
    }
  }

  const db = getDb();
  const nextStats = { ...existing.stats, netProfitPerCyclePercent: nextCyclePct };
  await db
    .update(schema.gridBots)
    .set({
      name: updates.name?.trim() || existing.name,
      lowerPrice: nextLower,
      upperPrice: nextUpper,
      gridLevels: nextCount,
      stepMode: nextStepMode,
      totalCapital: updates.totalCapital ?? existing.totalCapital,
      maxCapitalInvolved: updates.maxCapitalInvolved ?? existing.maxCapitalInvolved,
      stopOnBreakout: updates.stopOnBreakout ?? existing.stopOnBreakout,
      alertOnBreakout: updates.alertOnBreakout ?? existing.alertOnBreakout,
      executionConfirmationMode:
        updates.executionConfirmationMode ?? existing.executionConfirmationMode,
      notifyTelegram: updates.notifyTelegram ?? existing.notifyTelegram,
      mode: updates.mode ?? existing.mode,
      allocatedLevelsJson: nextLevels,
      statsJson: nextStats,
      updatedAt: Date.now(),
    })
    .where(and(eq(schema.gridBots.id, botId), eq(schema.gridBots.userId, userId)));

  return (await getUserGridBotById(userId, botId))!;
}

export async function startGridBot(
  userId: string,
  botId: string,
  confirmLive?: boolean
): Promise<GridBotConfig> {
  const existing = await getUserGridBotById(userId, botId);
  if (!existing) throw new Error('ربات گرید یافت نشد.');
  if (existing.mode === 'live' && !confirmLive) {
    throw new Error('برای شروع ربات گرید واقعی، تأیید صریح الزامی است.');
  }

  gridRetryAfterMap.delete(botId);
  gridLastRunMap.delete(botId);
  gridFastFollowUpSet.delete(botId);
  const db = getDb();
  await db
    .update(schema.gridBots)
    .set({
      isActive: true,
      status: 'RUNNING',
      lastError: null,
      lastStatusReason: 'ربات گرید فعال شد و در حال بررسی پله‌های قیمتی است.',
      updatedAt: Date.now(),
    })
    .where(and(eq(schema.gridBots.id, botId), eq(schema.gridBots.userId, userId)));
  return (await getUserGridBotById(userId, botId))!;
}

export async function stopGridBot(userId: string, botId: string): Promise<GridBotConfig> {
  const existing = await getUserGridBotById(userId, botId);
  if (!existing) throw new Error('ربات گرید یافت نشد.');
  const db = getDb();
  await db
    .update(schema.gridBots)
    .set({
      isActive: false,
      status: 'PAUSED',
      lastStatusReason: 'ربات گرید توسط کاربر متوقف شد.',
      updatedAt: Date.now(),
    })
    .where(and(eq(schema.gridBots.id, botId), eq(schema.gridBots.userId, userId)));
  return (await getUserGridBotById(userId, botId))!;
}

export async function deleteGridBot(userId: string, botId: string): Promise<void> {
  const db = getDb();
  await db
    .delete(schema.gridBots)
    .where(and(eq(schema.gridBots.id, botId), eq(schema.gridBots.userId, userId)));
}

const gridLastRunMap = new Map<string, number>();
const gridRetryAfterMap = new Map<string, { until: number; failures: number }>();
const gridFastFollowUpSet = new Set<string>();
let isEvaluatingGridBotsLocally = false;

function isRateLimitErr(err: unknown): boolean {
  if (err instanceof NobitexRateLimitError) return true;
  const msg = err instanceof Error ? err.message : String(err || '');
  return (
    msg.includes('429') ||
    msg.includes('تعداد درخواست') ||
    msg.includes('محدودیت موقت') ||
    msg.toLowerCase().includes('too many requests')
  );
}

export async function evaluateGridBot(bot: GridBotConfig): Promise<GridBotConfig> {
  const userId = bot.ownerId || '';
  if (!userId || !bot.isActive) return bot;

  const db = getDb();
  const now = Date.now();
  gridLastRunMap.set(bot.id, now);

  const levels = [...bot.allocatedLevels];
  const stats = { ...bot.stats };
  let liveOrdersPlacedThisCycle = 0;
  let hasMorePendingLevels = false;
  let lastSeenPrice = bot.lastPrice || 0;
  let stateDirty = false;

  const persistProgress = async (nextReason: string) => {
    stats.openOrdersCount = levels.filter((x) => x.status === 'HOLDING').length;
    stats.currentCapitalInvolved = levels.reduce(
      (s, x) => s + (x.status === 'HOLDING' ? x.qty * (x.buyPrice || x.price) : 0),
      0
    );
    await db
      .update(schema.gridBots)
      .set({
        allocatedLevelsJson: levels,
        statsJson: stats,
        lastPrice: lastSeenPrice,
        lastStatusReason: nextReason,
        lastError: null,
        lastCheckedAt: Date.now(),
        updatedAt: Date.now(),
      })
      .where(eq(schema.gridBots.id, bot.id));
    stateDirty = false;
  };

  try {
    const [{ markets }, marketRules] = await Promise.all([
      fetchNobitexUnifiedMarkets(),
      getNobitexMarketRules(bot.symbol).catch(() => ({
        minNotional: getMinimumOrderNotional(bot.quoteCurrency),
        amountStep: 1e-6,
      })),
    ]);
    const market = markets.find((m) => m.baseAsset.toUpperCase() === bot.baseAsset.toUpperCase());
    const currentPrice =
      bot.quoteCurrency === 'IRT'
        ? market?.priceToman || market?.bestSellToman || 0
        : market?.priceUsdt || market?.bestSellUsdt || 0;

    if (currentPrice <= 0) {
      await db
        .update(schema.gridBots)
        .set({ lastCheckedAt: now, lastStatusReason: 'در انتظار دریافت قیمت لحظه‌ای از نوبیتکس', updatedAt: now })
        .where(eq(schema.gridBots.id, bot.id));
      return (await getUserGridBotById(userId, bot.id))!;
    }
    lastSeenPrice = currentPrice;

    // Check out-of-range breakout
    if (currentPrice < bot.lowerPrice || currentPrice > bot.upperPrice) {
      const nextStatus: GridBotStatus = bot.stopOnBreakout ? 'OUT_OF_RANGE' : bot.status;
      const nextActive = bot.stopOnBreakout ? false : bot.isActive;
      const reason = `هشدار خروج از محدوده: قیمت فعلی (${currentPrice.toLocaleString('en-US')}) از بازه گرید [${bot.lowerPrice.toLocaleString(
        'en-US'
      )} - ${bot.upperPrice.toLocaleString('en-US')}] خارج شد.`;
      await db
        .update(schema.gridBots)
        .set({
          isActive: nextActive,
          status: nextStatus,
          lastPrice: currentPrice,
          lastCheckedAt: now,
          lastStatusReason: reason,
          updatedAt: now,
        })
        .where(eq(schema.gridBots.id, bot.id));
      gridRetryAfterMap.delete(bot.id);
      gridFastFollowUpSet.delete(bot.id);
      return (await getUserGridBotById(userId, bot.id))!;
    }

    const slotBudget = bot.totalCapital / Math.max(1, levels.length - 1);
    let reason = `پایش گرید روی قیمت ${currentPrice.toLocaleString('en-US')} · ${stats.completedCycles} چرخه تکمیل‌شده`;

    for (let i = 0; i < levels.length - 1; i++) {
      const lv = levels[i];
      const nextSellLv = levels[i + 1];

      // Buy condition: price near/below grid buy level & slot is IDLE
      if (lv.status === 'IDLE' && currentPrice <= lv.price * 1.002) {
        const involved = levels.reduce(
          (acc, x) => acc + (x.status === 'HOLDING' ? x.qty * (x.buyPrice || x.price) : 0),
          0
        );
        if (involved + slotBudget > bot.maxCapitalInvolved + 1) {
          continue;
        }

        const guard = await validateSharedExecutionGuards({
          userId,
          botId: bot.id,
          botType: 'GRID',
          symbol: bot.symbol,
          quoteCurrency: bot.quoteCurrency,
          side: 'BUY',
          requestedQuoteAmount: slotBudget,
        });
        if (!guard.ok) {
          reason = guard.reasonFa;
          break;
        }

        const qty = roundQuantityToStep(slotBudget / currentPrice, marketRules.amountStep, 'floor');
        if (qty <= 0 || qty * currentPrice < marketRules.minNotional) continue;

        if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
          await createPendingConfirmation({
            userId,
            botId: bot.id,
            botType: 'GRID',
            botName: bot.name,
            symbol: bot.symbol,
            baseAsset: bot.baseAsset,
            quoteCurrency: bot.quoteCurrency,
            mode: bot.mode,
            side: 'BUY',
            orderType: 'MARKET',
            suggestedPrice: currentPrice,
            quantity: qty,
            quoteAmount: qty * currentPrice,
            estimatedFeeQuote: qty * currentPrice * bot.feeRate,
            reasonFa: `رسیدن قیمت به پله خرید گرید شماره ${i + 1} (${lv.price.toLocaleString('en-US')})`,
            riskSummaryFa: `مبلغ پله: ${Math.round(qty * currentPrice).toLocaleString('en-US')} ${
              bot.quoteCurrency === 'IRT' ? 'تومان' : 'USDT'
            } · هدف فروش پله بعد: ${nextSellLv.price.toLocaleString('en-US')}`,
            metaJson: { levelIndex: i },
          });
          reason = `در انتظار تأیید دستی شما برای خرید پله ${i + 1}`;
          continue;
        }

        // Prevent Nobitex rate-limit bursts: place at most 1 live order per cycle and pace remaining levels
        if (bot.mode === 'live' && liveOrdersPlacedThisCycle >= 1) {
          hasMorePendingLevels = true;
          reason = `${reason} · پله‌های بعدی به‌صورت تدریجی (بدون فشار به محدودیت نوبیتکس) ثبت می‌شوند.`;
          break;
        }

        const idempotencyKey = `grid:${bot.id}:lv${i}:buy:${stats.completedCycles}:${Math.floor(now / 15000)}`;
        if (bot.mode === 'live') {
          const creds = await getActiveExchangeCredentialsForUser(userId);
          if (!creds) throw new NobitexAuthError('کلید API نوبیتکس موجود نیست.');
          const order = await placeNobitexLiveOrder(
            {
              baseAsset: bot.baseAsset,
              quoteCurrency: bot.quoteCurrency,
              side: 'BUY',
              type: 'MARKET',
              quantity: qty,
              estimatedPrice: currentPrice,
              source: 'BOT',
              botId: bot.id,
              clientOrderId: formatNobitexClientOrderId(idempotencyKey),
            },
            creds
          );
          const verified =
            order.orderId && (order.status !== 'FILLED' || order.price <= 0)
              ? await fetchNobitexOrderStatus(order.orderId, creds, bot.quoteCurrency).catch(() => order)
              : order;
          await recordLiveOrderAndTrade(userId, verified || order, { idempotencyKey });
          liveOrdersPlacedThisCycle += 1;
        } else {
          await placePaperOrder(userId, {
            baseAsset: bot.baseAsset,
            quoteCurrency: bot.quoteCurrency,
            side: 'BUY',
            type: 'MARKET',
            quantity: qty,
            price: currentPrice,
            source: 'BOT',
            botId: bot.id,
            idempotencyKey,
          });
        }

        const buyFee = qty * currentPrice * bot.feeRate;
        levels[i] = {
          ...lv,
          status: 'HOLDING',
          qty: qty * (1 - bot.feeRate),
          buyPrice: currentPrice,
          buyFeeQuote: buyFee,
          updatedAt: now,
        };
        stats.totalFeesPaidQuote += buyFee;
        reason = `خرید پله ${i + 1} در نرخ ${currentPrice.toLocaleString('en-US')} ثبت شد.`;
        stateDirty = true;
        if (bot.mode === 'live') {
          await persistProgress(reason);
        }
      }

      // Sell condition: holding slot & price >= next upper grid price
      if (lv.status === 'HOLDING' && currentPrice >= nextSellLv.price * 0.999) {
        const sellQty = roundQuantityToStep(lv.qty, marketRules.amountStep, 'floor');
        if (sellQty <= 0 || sellQty * currentPrice < marketRules.minNotional) continue;

        const grossProceeds = sellQty * currentPrice;
        const sellFee = grossProceeds * bot.feeRate;
        const buyCost = (lv.buyPrice || lv.price) * (sellQty / (1 - bot.feeRate));
        const netCycleProfit = grossProceeds - sellFee - buyCost;

        if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
          await createPendingConfirmation({
            userId,
            botId: bot.id,
            botType: 'GRID',
            botName: bot.name,
            symbol: bot.symbol,
            baseAsset: bot.baseAsset,
            quoteCurrency: bot.quoteCurrency,
            mode: bot.mode,
            side: 'SELL',
            orderType: 'MARKET',
            suggestedPrice: currentPrice,
            quantity: sellQty,
            quoteAmount: grossProceeds,
            estimatedFeeQuote: sellFee,
            reasonFa: `رسیدن قیمت به پله فروش گرید شماره ${i + 2} (${nextSellLv.price.toLocaleString('en-US')})`,
            riskSummaryFa: `سود خالص تخمینی این چرخه: ${netCycleProfit >= 0 ? '+' : ''}${Math.round(
              netCycleProfit
            ).toLocaleString('en-US')}`,
            metaJson: { levelIndex: i },
          });
          reason = `در انتظار تأیید دستی شما برای فروش پله ${i + 1}`;
          continue;
        }

        if (bot.mode === 'live' && liveOrdersPlacedThisCycle >= 1) {
          hasMorePendingLevels = true;
          reason = `${reason} · فروش پله بعدی در نوبت کوتاه بعدی ثبت می‌شود.`;
          break;
        }

        const idempotencyKey = `grid:${bot.id}:lv${i}:sell:${stats.completedCycles}:${Math.floor(now / 15000)}`;
        if (bot.mode === 'live') {
          const creds = await getActiveExchangeCredentialsForUser(userId);
          if (!creds) throw new NobitexAuthError('کلید API نوبیتکس موجود نیست.');
          const order = await placeNobitexLiveOrder(
            {
              baseAsset: bot.baseAsset,
              quoteCurrency: bot.quoteCurrency,
              side: 'SELL',
              type: 'MARKET',
              quantity: sellQty,
              estimatedPrice: currentPrice,
              source: 'BOT',
              botId: bot.id,
              clientOrderId: formatNobitexClientOrderId(idempotencyKey),
            },
            creds
          );
          await recordLiveOrderAndTrade(userId, order, {
            idempotencyKey,
            realizedPnlQuote: netCycleProfit,
          });
          liveOrdersPlacedThisCycle += 1;
        } else {
          await placePaperOrder(userId, {
            baseAsset: bot.baseAsset,
            quoteCurrency: bot.quoteCurrency,
            side: 'SELL',
            type: 'MARKET',
            quantity: sellQty,
            price: currentPrice,
            source: 'BOT',
            botId: bot.id,
            idempotencyKey,
            realizedPnlQuote: netCycleProfit,
          });
        }

        stats.completedCycles += 1;
        stats.totalNetProfitQuote += netCycleProfit;
        stats.totalFeesPaidQuote += sellFee;
        levels[i] = {
          ...lv,
          status: 'IDLE',
          qty: 0,
          buyPrice: undefined,
          buyFeeQuote: undefined,
          updatedAt: now,
        };
        reason = `چرخه گرید پله ${i + 1} با سود خالص ${netCycleProfit >= 0 ? '+' : ''}${Math.round(
          netCycleProfit
        ).toLocaleString('en-US')} بسته شد.`;
        stateDirty = true;
        if (bot.mode === 'live') {
          await persistProgress(reason);
        }
      }
    }

    if (hasMorePendingLevels) {
      gridFastFollowUpSet.add(bot.id);
    } else {
      gridFastFollowUpSet.delete(bot.id);
    }

    gridRetryAfterMap.delete(bot.id);
    if (stateDirty || liveOrdersPlacedThisCycle === 0) {
      await persistProgress(reason);
    }
  } catch (err) {
    const rawMsg = err instanceof Error ? err.message : 'خطا در اجرای ربات گرید';
    const rateLimited = isRateLimitErr(err);
    const prev = gridRetryAfterMap.get(bot.id);
    const failures = (prev?.failures || 0) + 1;
    const backoffMs = rateLimited
      ? err instanceof NobitexRateLimitError
        ? Math.max(25_000, err.retryAfterMs)
        : Math.min(90_000, 30_000 * 2 ** Math.min(2, failures - 1))
      : Math.min(60_000, 10_000 * 2 ** Math.min(2, failures - 1));
    gridRetryAfterMap.set(bot.id, { until: Date.now() + backoffMs, failures });
    gridFastFollowUpSet.delete(bot.id);

    const friendlyMsg = rateLimited
      ? `محدودیت موقت تعداد درخواست نوبیتکس (429) — تلاش مجدد خودکار تا ${Math.ceil(backoffMs / 1000)} ثانیه دیگر`
      : rawMsg;

    await db
      .update(schema.gridBots)
      .set({
        ...(stateDirty ? { allocatedLevelsJson: levels, statsJson: stats } : {}),
        lastError: friendlyMsg.slice(0, 400),
        lastStatusReason: rateLimited ? friendlyMsg : `خطا: ${friendlyMsg}`,
        lastCheckedAt: Date.now(),
        updatedAt: Date.now(),
      })
      .where(eq(schema.gridBots.id, bot.id));
  }

  return (await getUserGridBotById(userId, bot.id))!;
}

export async function runAllActiveGridBotsCycle(options?: {
  respectSchedule?: boolean;
}): Promise<number> {
  if (isEvaluatingGridBotsLocally) return 0;
  isEvaluatingGridBotsLocally = true;
  try {
    const db = getDb();
    const rows = await db
      .select()
      .from(schema.gridBots)
      .where(eq(schema.gridBots.isActive, true));

    const now = Date.now();
    const respectSchedule = Boolean(options?.respectSchedule);
    const globalRateLimitMs = getNobitexRateLimitRemainingMs();
    let count = 0;

    for (const r of rows) {
      const bot = mapGridBotRow(r);
      if (respectSchedule) {
        const retryEntry = gridRetryAfterMap.get(bot.id);
        if (retryEntry && retryEntry.until > now) {
          continue;
        }
        if (bot.mode === 'live' && globalRateLimitMs > 0) {
          continue;
        }
        const lastRun = Math.max(gridLastRunMap.get(bot.id) || 0, bot.lastCheckedAt || 0);
        const minIntervalMs =
          bot.mode === 'live'
            ? gridFastFollowUpSet.has(bot.id)
              ? 4_500
              : 12_000
            : 4_000;
        if (lastRun > 0 && now - lastRun < minIntervalMs - 250) {
          continue;
        }
      }
      await evaluateGridBot(bot);
      count += 1;
    }
    return count;
  } finally {
    isEvaluatingGridBotsLocally = false;
  }
}

export async function emergencyStopUserGridBots(userId: string): Promise<number> {
  const db = getDb();
  const res = await db
    .update(schema.gridBots)
    .set({
      isActive: false,
      status: 'PAUSED',
      lastStatusReason: 'توقف اضطراری (Kill Switch)',
      updatedAt: Date.now(),
    })
    .where(and(eq(schema.gridBots.userId, userId), eq(schema.gridBots.isActive, true)))
    .returning();
  return res.length;
}

// =========================================================================
// DCA Bot CRUD & Execution Engine
// =========================================================================
function mapDcaBotRow(row: typeof schema.dcaBots.$inferSelect): DcaBotConfig {
  const rawState = (row.stateJson || {}) as Partial<DcaBotState>;
  const rawStats = (row.statsJson || {}) as Partial<DcaBotConfig['stats']>;
  const targets = Array.isArray(row.takeProfitTargetsJson)
    ? (row.takeProfitTargetsJson as TakeProfitTarget[])
    : [];
  return {
    id: row.id,
    ownerId: row.userId,
    name: row.name,
    baseAsset: row.baseAsset,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    symbol: row.symbol,
    mode: (row.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    isActive: row.isActive,
    status: row.status as DcaBotStatus,
    totalCapital: row.totalCapital,
    maxInvolvedCapital: row.maxInvolvedCapital,
    stagesCount: row.stagesCount,
    stepUnit: row.stepUnit === 'PRICE' ? 'PRICE' : 'PERCENT',
    stepValue: row.stepValue,
    triggerMode: (row.triggerMode === 'TIME' || row.triggerMode === 'INDICATOR'
      ? row.triggerMode
      : 'MARKET_DROP') as DcaTriggerMode,
    intervalMinutes: row.intervalMinutes,
    pauseNewBuys: row.pauseNewBuys,
    stopLossEnabled: row.stopLossEnabled,
    stopLossPercent: row.stopLossPercent,
    takeProfitEnabled: row.takeProfitEnabled,
    takeProfitPercent: row.takeProfitPercent,
    trailingTpEnabled: row.trailingTpEnabled,
    trailingTpActivationPercent: row.trailingTpActivationPercent,
    trailingTpCallbackPercent: row.trailingTpCallbackPercent,
    takeProfitTargets: targets,
    keepRunnerPercent: row.keepRunnerPercent,
    feeRate: row.feeRate,
    estimatedSlippagePercent: row.estimatedSlippagePercent,
    executionConfirmationMode: (row.executionConfirmationMode === 'MANUAL_CONFIRM'
      ? 'MANUAL_CONFIRM'
      : 'AUTO') as BotExecutionConfirmationMode,
    notifyTelegram: row.notifyTelegram,
    state: {
      stagesCompleted: Number(rawState.stagesCompleted || 0),
      totalHoldingQty: Number(rawState.totalHoldingQty || 0),
      netOwnedQty: Number(rawState.netOwnedQty || 0),
      avgBuyPrice: Number(rawState.avgBuyPrice || 0),
      totalInvestedQuote: Number(rawState.totalInvestedQuote || 0),
      totalBuyFeesQuote: Number(rawState.totalBuyFeesQuote || 0),
      highestPriceSinceEntry: Number(rawState.highestPriceSinceEntry || 0),
      trailingTpArmed: Boolean(rawState.trailingTpArmed),
      lastBuyPrice: Number(rawState.lastBuyPrice || 0),
      nextTriggerAt: rawState.nextTriggerAt ?? null,
      pendingOrderId: rawState.pendingOrderId ?? null,
      executedTpIds: Array.isArray(rawState.executedTpIds) ? rawState.executedTpIds : [],
    },
    stats: {
      completedCycles: Number(rawStats.completedCycles || 0),
      realizedNetProfitQuote: Number(rawStats.realizedNetProfitQuote || 0),
      totalFeesPaidQuote: Number(rawStats.totalFeesPaidQuote || 0),
    },
    lastPrice: row.lastPrice,
    lastStatusReason: row.lastStatusReason,
    lastError: row.lastError ?? null,
    lastCheckedAt: row.lastCheckedAt ?? null,
    createdAt: row.createdAt,
    updatedAt: row.updatedAt,
  };
}

export async function getUserDcaBots(userId: string): Promise<DcaBotConfig[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.dcaBots)
    .where(eq(schema.dcaBots.userId, userId))
    .orderBy(desc(schema.dcaBots.createdAt));
  return rows.map(mapDcaBotRow);
}

export async function getUserDcaBotById(
  userId: string,
  botId: string
): Promise<DcaBotConfig | null> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.dcaBots)
    .where(and(eq(schema.dcaBots.id, botId), eq(schema.dcaBots.userId, userId)))
    .limit(1);
  return rows[0] ? mapDcaBotRow(rows[0]) : null;
}

export async function createDcaBot(
  userId: string,
  input: {
    name?: string;
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    mode?: ExecutionMode;
    confirmLive?: boolean;
    startImmediately?: boolean;
    totalCapital: number;
    maxInvolvedCapital?: number;
    stagesCount: number;
    stepUnit?: DcaStepUnit;
    stepValue: number;
    triggerMode?: DcaTriggerMode;
    intervalMinutes?: number;
    pauseNewBuys?: boolean;
    stopLossEnabled?: boolean;
    stopLossPercent?: number;
    takeProfitEnabled?: boolean;
    takeProfitPercent?: number;
    trailingTpEnabled?: boolean;
    trailingTpActivationPercent?: number;
    trailingTpCallbackPercent?: number;
    takeProfitTargets?: TakeProfitTarget[];
    keepRunnerPercent?: number;
    feeRate?: number;
    estimatedSlippagePercent?: number;
    executionConfirmationMode?: BotExecutionConfirmationMode;
    notifyTelegram?: boolean;
  }
): Promise<DcaBotConfig> {
  const mode: ExecutionMode = input.mode === 'live' ? 'live' : 'paper';
  if (mode === 'live') {
    if (!input.confirmLive) throw new Error('برای ربات DCA واقعی، تأیید صریح الزامی است.');
    if (!(await hasActiveExchangeCredentialsForUser(userId))) {
      throw new Error('کلید API نوبیتکس برای معاملات واقعی ثبت نشده است.');
    }
  }
  if (!(input.totalCapital > 0)) {
    throw new Error('سرمایه کل ربات خرید پله‌ای باید بزرگ‌تر از صفر باشد.');
  }

  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const now = Date.now();
  const baseAsset = input.baseAsset.toUpperCase().trim();
  const quoteCurrency: QuoteCurrency = input.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
  const symbol = `${baseAsset}${quoteCurrency}`;
  const id = `dca-${now}-${crypto.randomBytes(3).toString('hex')}`;
  const isActive = Boolean(input.startImmediately);

  const initialState: DcaBotState = {
    stagesCompleted: 0,
    totalHoldingQty: 0,
    netOwnedQty: 0,
    avgBuyPrice: 0,
    totalInvestedQuote: 0,
    totalBuyFeesQuote: 0,
    highestPriceSinceEntry: 0,
    trailingTpArmed: false,
    lastBuyPrice: 0,
    nextTriggerAt: isActive ? now : null,
    executedTpIds: [],
  };

  await db.insert(schema.dcaBots).values({
    id,
    userId,
    name: (input.name || `ربات خرید پله‌ای ${baseAsset}`).trim().slice(0, 100),
    baseAsset,
    quoteCurrency,
    symbol,
    mode,
    isActive,
    status: isActive ? 'RUNNING' : 'PAUSED',
    totalCapital: input.totalCapital,
    maxInvolvedCapital: Math.max(input.totalCapital, Number(input.maxInvolvedCapital || input.totalCapital)),
    stagesCount: Math.max(2, Math.min(25, Math.round(input.stagesCount))),
    stepUnit: input.stepUnit === 'PRICE' ? 'PRICE' : 'PERCENT',
    stepValue: Math.max(0.1, Number(input.stepValue || 2.5)),
    triggerMode: input.triggerMode || 'MARKET_DROP',
    intervalMinutes: Math.max(1, Math.round(input.intervalMinutes || 60)),
    pauseNewBuys: Boolean(input.pauseNewBuys),
    stopLossEnabled: Boolean(input.stopLossEnabled),
    stopLossPercent: Math.max(0.5, Number(input.stopLossPercent ?? 8)),
    takeProfitEnabled: input.takeProfitEnabled !== false,
    takeProfitPercent: Math.max(0.5, Number(input.takeProfitPercent ?? 6)),
    trailingTpEnabled: Boolean(input.trailingTpEnabled),
    trailingTpActivationPercent: Math.max(0.5, Number(input.trailingTpActivationPercent ?? 5)),
    trailingTpCallbackPercent: Math.max(0.2, Number(input.trailingTpCallbackPercent ?? 1.2)),
    takeProfitTargetsJson: input.takeProfitTargets || [],
    keepRunnerPercent: Math.max(0, Math.min(50, Number(input.keepRunnerPercent ?? 0))),
    feeRate: input.feeRate ?? DEFAULT_FEE_RATE,
    estimatedSlippagePercent: input.estimatedSlippagePercent ?? 0.15,
    executionConfirmationMode:
      input.executionConfirmationMode === 'MANUAL_CONFIRM' ? 'MANUAL_CONFIRM' : 'AUTO',
    notifyTelegram: input.notifyTelegram !== false,
    stateJson: initialState,
    statsJson: {
      completedCycles: 0,
      realizedNetProfitQuote: 0,
      totalFeesPaidQuote: 0,
    },
    lastPrice: 0,
    lastStatusReason: isActive
      ? 'ربات خرید پله‌ای فعال شد و آماده اجرای مرحله اول است.'
      : 'ربات خرید پله‌ای ذخیره شد و آماده شروع است.',
    lastError: null,
    lastCheckedAt: null,
    createdAt: now,
    updatedAt: now,
  });

  return (await getUserDcaBotById(userId, id))!;
}

export async function updateDcaBot(
  userId: string,
  botId: string,
  updates: Partial<{
    name: string;
    totalCapital: number;
    maxInvolvedCapital: number;
    stagesCount: number;
    stepUnit: DcaStepUnit;
    stepValue: number;
    triggerMode: DcaTriggerMode;
    intervalMinutes: number;
    pauseNewBuys: boolean;
    stopLossEnabled: boolean;
    stopLossPercent: number;
    takeProfitEnabled: boolean;
    takeProfitPercent: number;
    trailingTpEnabled: boolean;
    trailingTpActivationPercent: number;
    trailingTpCallbackPercent: number;
    takeProfitTargets: TakeProfitTarget[];
    keepRunnerPercent: number;
    executionConfirmationMode: BotExecutionConfirmationMode;
    notifyTelegram: boolean;
    mode: ExecutionMode;
    confirmLive: boolean;
  }>
): Promise<DcaBotConfig> {
  const existing = await getUserDcaBotById(userId, botId);
  if (!existing) throw new Error('ربات خرید پله‌ای یافت نشد.');

  if (updates.mode === 'live') {
    if (!updates.confirmLive && existing.mode !== 'live') {
      throw new Error('برای تغییر به حساب واقعی، تأیید صریح الزامی است.');
    }
    if (!(await hasActiveExchangeCredentialsForUser(userId))) {
      throw new Error('کلید API نوبیتکس برای معاملات واقعی ثبت نشده است.');
    }
  }

  const db = getDb();
  const nextPauseBuys = updates.pauseNewBuys ?? existing.pauseNewBuys;
  const nextStatus: DcaBotStatus = existing.isActive
    ? nextPauseBuys
      ? 'PAUSED_BUYS'
      : 'RUNNING'
    : 'PAUSED';

  await db
    .update(schema.dcaBots)
    .set({
      name: updates.name?.trim() || existing.name,
      totalCapital: updates.totalCapital ?? existing.totalCapital,
      maxInvolvedCapital: updates.maxInvolvedCapital ?? existing.maxInvolvedCapital,
      stagesCount: updates.stagesCount ?? existing.stagesCount,
      stepUnit: updates.stepUnit ?? existing.stepUnit,
      stepValue: updates.stepValue ?? existing.stepValue,
      triggerMode: updates.triggerMode ?? existing.triggerMode,
      intervalMinutes: updates.intervalMinutes ?? existing.intervalMinutes,
      pauseNewBuys: nextPauseBuys,
      status: nextStatus,
      stopLossEnabled: updates.stopLossEnabled ?? existing.stopLossEnabled,
      stopLossPercent: updates.stopLossPercent ?? existing.stopLossPercent,
      takeProfitEnabled: updates.takeProfitEnabled ?? existing.takeProfitEnabled,
      takeProfitPercent: updates.takeProfitPercent ?? existing.takeProfitPercent,
      trailingTpEnabled: updates.trailingTpEnabled ?? existing.trailingTpEnabled,
      trailingTpActivationPercent:
        updates.trailingTpActivationPercent ?? existing.trailingTpActivationPercent,
      trailingTpCallbackPercent:
        updates.trailingTpCallbackPercent ?? existing.trailingTpCallbackPercent,
      takeProfitTargetsJson: updates.takeProfitTargets ?? existing.takeProfitTargets,
      keepRunnerPercent: updates.keepRunnerPercent ?? existing.keepRunnerPercent,
      executionConfirmationMode:
        updates.executionConfirmationMode ?? existing.executionConfirmationMode,
      notifyTelegram: updates.notifyTelegram ?? existing.notifyTelegram,
      mode: updates.mode ?? existing.mode,
      updatedAt: Date.now(),
    })
    .where(and(eq(schema.dcaBots.id, botId), eq(schema.dcaBots.userId, userId)));

  return (await getUserDcaBotById(userId, botId))!;
}

export async function startDcaBot(
  userId: string,
  botId: string,
  confirmLive?: boolean
): Promise<DcaBotConfig> {
  const existing = await getUserDcaBotById(userId, botId);
  if (!existing) throw new Error('ربات خرید پله‌ای یافت نشد.');
  if (existing.mode === 'live' && !confirmLive) {
    throw new Error('برای شروع ربات DCA واقعی، تأیید صریح الزامی است.');
  }
  dcaRetryAfterMap.delete(botId);
  dcaLastRunMap.delete(botId);
  const db = getDb();
  await db
    .update(schema.dcaBots)
    .set({
      isActive: true,
      status: existing.pauseNewBuys ? 'PAUSED_BUYS' : 'RUNNING',
      lastError: null,
      lastStatusReason: 'ربات خرید پله‌ای فعال شد.',
      updatedAt: Date.now(),
    })
    .where(and(eq(schema.dcaBots.id, botId), eq(schema.dcaBots.userId, userId)));
  return (await getUserDcaBotById(userId, botId))!;
}

export async function stopDcaBot(userId: string, botId: string): Promise<DcaBotConfig> {
  const existing = await getUserDcaBotById(userId, botId);
  if (!existing) throw new Error('ربات خرید پله‌ای یافت نشد.');
  const db = getDb();
  await db
    .update(schema.dcaBots)
    .set({
      isActive: false,
      status: 'PAUSED',
      lastStatusReason: 'ربات خرید پله‌ای توسط کاربر متوقف شد.',
      updatedAt: Date.now(),
    })
    .where(and(eq(schema.dcaBots.id, botId), eq(schema.dcaBots.userId, userId)));
  return (await getUserDcaBotById(userId, botId))!;
}

export async function deleteDcaBot(userId: string, botId: string): Promise<void> {
  const db = getDb();
  await db
    .delete(schema.dcaBots)
    .where(and(eq(schema.dcaBots.id, botId), eq(schema.dcaBots.userId, userId)));
}

const dcaLastRunMap = new Map<string, number>();
const dcaRetryAfterMap = new Map<string, { until: number; failures: number }>();
let isEvaluatingDcaBotsLocally = false;

export async function evaluateDcaBot(bot: DcaBotConfig): Promise<DcaBotConfig> {
  const userId = bot.ownerId || '';
  if (!userId || !bot.isActive) return bot;

  const db = getDb();
  const now = Date.now();
  dcaLastRunMap.set(bot.id, now);
  try {
    const [{ markets }, marketRules] = await Promise.all([
      fetchNobitexUnifiedMarkets(),
      getNobitexMarketRules(bot.symbol).catch(() => ({
        minNotional: getMinimumOrderNotional(bot.quoteCurrency),
        amountStep: 1e-6,
      })),
    ]);
    const market = markets.find((m) => m.baseAsset.toUpperCase() === bot.baseAsset.toUpperCase());
    const currentPrice =
      bot.quoteCurrency === 'IRT'
        ? market?.priceToman || market?.bestSellToman || 0
        : market?.priceUsdt || market?.bestSellUsdt || 0;

    if (currentPrice <= 0) {
      await db
        .update(schema.dcaBots)
        .set({ lastCheckedAt: now, lastStatusReason: 'در انتظار دریافت قیمت لحظه‌ای از نوبیتکس', updatedAt: now })
        .where(eq(schema.dcaBots.id, bot.id));
      return (await getUserDcaBotById(userId, bot.id))!;
    }

    const state: DcaBotState = { ...bot.state, executedTpIds: [...(bot.state.executedTpIds || [])] };
    const stats = { ...bot.stats };
    let reason = `میانگین خرید: ${
      state.avgBuyPrice > 0 ? Math.round(state.avgBuyPrice).toLocaleString('en-US') : '—'
    } · مراحل تکمیل‌شده: ${state.stagesCompleted}/${bot.stagesCount}`;

    // 1. Evaluate sells / TP / Trailing TP / SL if holding asset
    if (state.netOwnedQty > 0 && state.avgBuyPrice > 0) {
      if (currentPrice > state.highestPriceSinceEntry) {
        state.highestPriceSinceEntry = currentPrice;
      }

      if (
        bot.trailingTpEnabled &&
        !state.trailingTpArmed &&
        currentPrice >= state.avgBuyPrice * (1 + bot.trailingTpActivationPercent / 100)
      ) {
        state.trailingTpArmed = true;
      }

      // Check staged take-profit targets first
      const sortedTargets = [...(bot.takeProfitTargets || [])]
        .filter((t) => t.risePercent > 0 && t.sellPercent > 0 && !state.executedTpIds.includes(t.id))
        .sort((a, b) => a.risePercent - b.risePercent);

      for (const tp of sortedTargets) {
        const tpPrice = state.avgBuyPrice * (1 + tp.risePercent / 100);
        if (currentPrice >= tpPrice && state.netOwnedQty > 0) {
          const desiredQty = state.netOwnedQty * (Math.min(100, tp.sellPercent) / 100);
          const sellQty = roundQuantityToStep(desiredQty, marketRules.amountStep, 'floor');
          if (sellQty > 0 && sellQty * currentPrice >= marketRules.minNotional) {
            const gross = sellQty * currentPrice;
            const sellFee = gross * bot.feeRate;
            const proportionalCost = state.totalInvestedQuote * (sellQty / state.netOwnedQty);
            const realized = gross - sellFee - proportionalCost;

            if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
              await createPendingConfirmation({
                userId,
                botId: bot.id,
                botType: 'DCA',
                botName: bot.name,
                symbol: bot.symbol,
                baseAsset: bot.baseAsset,
                quoteCurrency: bot.quoteCurrency,
                mode: bot.mode,
                side: 'SELL',
                orderType: 'MARKET',
                suggestedPrice: currentPrice,
                quantity: sellQty,
                quoteAmount: gross,
                estimatedFeeQuote: sellFee,
                reasonFa: `رسیدن به هدف فروش پله‌ای (+${tp.risePercent}٪ بالاتر از میانگین خرید)`,
                riskSummaryFa: `سود خالص تخمینی: ${realized >= 0 ? '+' : ''}${Math.round(realized).toLocaleString(
                  'en-US'
                )}`,
              });
              reason = 'در انتظار تأیید دستی شما برای فروش پله‌ای DCA';
              break;
            }

            const idempotencyKey = `dca:${bot.id}:tp:${tp.id}:${Math.floor(now / 15000)}`;
            if (bot.mode === 'live') {
              const creds = await getActiveExchangeCredentialsForUser(userId);
              if (!creds) throw new NobitexAuthError('کلید API نوبیتکس موجود نیست.');
              const order = await placeNobitexLiveOrder(
                {
                  baseAsset: bot.baseAsset,
                  quoteCurrency: bot.quoteCurrency,
                  side: 'SELL',
                  type: 'MARKET',
                  quantity: sellQty,
                  source: 'BOT',
                  botId: bot.id,
                  clientOrderId: formatNobitexClientOrderId(idempotencyKey),
                },
                creds
              );
              await recordLiveOrderAndTrade(userId, order, { idempotencyKey, realizedPnlQuote: realized });
            } else {
              await placePaperOrder(userId, {
                baseAsset: bot.baseAsset,
                quoteCurrency: bot.quoteCurrency,
                side: 'SELL',
                type: 'MARKET',
                quantity: sellQty,
                price: currentPrice,
                source: 'BOT',
                botId: bot.id,
                idempotencyKey,
                realizedPnlQuote: realized,
              });
            }

            state.executedTpIds.push(tp.id);
            state.netOwnedQty = Math.max(0, state.netOwnedQty - sellQty);
            state.totalInvestedQuote = Math.max(0, state.totalInvestedQuote - proportionalCost);
            stats.realizedNetProfitQuote += realized;
            stats.totalFeesPaidQuote += sellFee;
            reason = `فروش پله‌ای هدف +${tp.risePercent}٪ اجرا شد.`;
          }
        }
      }

      // Check full SL / Trailing TP / Single TP exit
      if (state.netOwnedQty > 0 && state.avgBuyPrice > 0) {
        let exitReason: string | null = null;
        if (bot.stopLossEnabled && currentPrice <= state.avgBuyPrice * (1 - bot.stopLossPercent / 100)) {
          exitReason = `فعال شدن حد ضرر (-${bot.stopLossPercent}٪)`;
        } else if (
          state.trailingTpArmed &&
          currentPrice <= state.highestPriceSinceEntry * (1 - bot.trailingTpCallbackPercent / 100)
        ) {
          exitReason = `فعال شدن حد سود متحرک (بازگشت ${bot.trailingTpCallbackPercent}٪ از سقف)`;
        } else if (
          bot.takeProfitEnabled &&
          (bot.takeProfitTargets || []).length === 0 &&
          currentPrice >= state.avgBuyPrice * (1 + bot.takeProfitPercent / 100)
        ) {
          exitReason = `تحقق حد سود کلی (+${bot.takeProfitPercent}٪)`;
        }

        if (exitReason) {
          const keepFraction =
            exitReason.includes('حد سود') && bot.keepRunnerPercent > 0
              ? 1 - bot.keepRunnerPercent / 100
              : 1;
          const sellQty = roundQuantityToStep(
            state.netOwnedQty * Math.max(0.1, keepFraction),
            marketRules.amountStep,
            'floor'
          );
          if (sellQty > 0 && sellQty * currentPrice >= marketRules.minNotional) {
            const gross = sellQty * currentPrice;
            const sellFee = gross * bot.feeRate;
            const proportionalCost = state.totalInvestedQuote * (sellQty / state.netOwnedQty);
            const realized = gross - sellFee - proportionalCost;

            if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
              await createPendingConfirmation({
                userId,
                botId: bot.id,
                botType: 'DCA',
                botName: bot.name,
                symbol: bot.symbol,
                baseAsset: bot.baseAsset,
                quoteCurrency: bot.quoteCurrency,
                mode: bot.mode,
                side: 'SELL',
                orderType: 'MARKET',
                suggestedPrice: currentPrice,
                quantity: sellQty,
                quoteAmount: gross,
                estimatedFeeQuote: sellFee,
                reasonFa: exitReason,
                riskSummaryFa: `سود/زیان خالص تخمینی: ${realized >= 0 ? '+' : ''}${Math.round(
                  realized
                ).toLocaleString('en-US')}`,
              });
              reason = `در انتظار تأیید دستی شما برای خروج (${exitReason})`;
            } else {
              const idempotencyKey = `dca:${bot.id}:exit:${stats.completedCycles}:${Math.floor(now / 15000)}`;
              if (bot.mode === 'live') {
                const creds = await getActiveExchangeCredentialsForUser(userId);
                if (!creds) throw new NobitexAuthError('کلید API نوبیتکس موجود نیست.');
                const order = await placeNobitexLiveOrder(
                  {
                    baseAsset: bot.baseAsset,
                    quoteCurrency: bot.quoteCurrency,
                    side: 'SELL',
                    type: 'MARKET',
                    quantity: sellQty,
                    source: 'BOT',
                    botId: bot.id,
                    clientOrderId: formatNobitexClientOrderId(idempotencyKey),
                  },
                  creds
                );
                await recordLiveOrderAndTrade(userId, order, {
                  idempotencyKey,
                  realizedPnlQuote: realized,
                });
              } else {
                await placePaperOrder(userId, {
                  baseAsset: bot.baseAsset,
                  quoteCurrency: bot.quoteCurrency,
                  side: 'SELL',
                  type: 'MARKET',
                  quantity: sellQty,
                  price: currentPrice,
                  source: 'BOT',
                  botId: bot.id,
                  idempotencyKey,
                  realizedPnlQuote: realized,
                });
              }

              stats.completedCycles += 1;
              stats.realizedNetProfitQuote += realized;
              stats.totalFeesPaidQuote += sellFee + state.totalBuyFeesQuote;
              const remainingQty = Math.max(0, state.netOwnedQty - sellQty);
              state.netOwnedQty = remainingQty;
              state.totalHoldingQty = remainingQty;
              state.totalInvestedQuote = Math.max(0, state.totalInvestedQuote - proportionalCost);
              if (remainingQty <= 1e-8) {
                state.stagesCompleted = 0;
                state.avgBuyPrice = 0;
                state.totalBuyFeesQuote = 0;
                state.highestPriceSinceEntry = 0;
                state.lastBuyPrice = 0;
                state.trailingTpArmed = false;
                state.executedTpIds = [];
              }
              reason = `${exitReason} · نتیجه خالص: ${realized >= 0 ? '+' : ''}${Math.round(
                realized
              ).toLocaleString('en-US')}`;
            }
          }
        }
      }
    }

    // 2. Evaluate next DCA stage buy if not paused
    const perStageAmount = bot.totalCapital / Math.max(1, bot.stagesCount);
    if (
      !bot.pauseNewBuys &&
      state.stagesCompleted < bot.stagesCount &&
      state.totalInvestedQuote + perStageAmount <= bot.maxInvolvedCapital + 1
    ) {
      let shouldBuy = false;
      let buyTriggerLabel = '';

      if (state.stagesCompleted === 0) {
        if (bot.triggerMode === 'INDICATOR') {
          const candles = await fetchNobitexKlines(bot.symbol, '1h', 80).catch(() => []);
          const snap = candles.length >= 20 ? analyzeCandles(bot.symbol, '1h', candles) : null;
          if (snap && snap.rsi14 <= 46) {
            shouldBuy = true;
            buyTriggerLabel = `ورود مرحله ۱ با تایید اندیکاتور (RSI=${snap.rsi14.toFixed(1)})`;
          }
        } else {
          shouldBuy = true;
          buyTriggerLabel = 'شروع مرحله اول خرید پله‌ای (DCA)';
        }
      } else if (bot.triggerMode === 'TIME') {
        if (!state.nextTriggerAt || now >= state.nextTriggerAt) {
          shouldBuy = true;
          buyTriggerLabel = `خرید زمان‌بندی‌شده مرحله ${state.stagesCompleted + 1}`;
        }
      } else {
        const dropMet =
          bot.stepUnit === 'PERCENT'
            ? currentPrice <= state.lastBuyPrice * (1 - bot.stepValue / 100)
            : currentPrice <= state.lastBuyPrice - bot.stepValue;
        if (dropMet) {
          if (bot.triggerMode === 'INDICATOR') {
            const candles = await fetchNobitexKlines(bot.symbol, '1h', 80).catch(() => []);
            const snap = candles.length >= 20 ? analyzeCandles(bot.symbol, '1h', candles) : null;
            if (!snap || snap.rsi14 <= 42) {
              shouldBuy = true;
              buyTriggerLabel = `پله ${state.stagesCompleted + 1} (اصلاح قیمت + RSI مناسب)`;
            }
          } else {
            shouldBuy = true;
            buyTriggerLabel = `پله ${state.stagesCompleted + 1} در اصلاح قیمت`;
          }
        }
      }

      if (shouldBuy) {
        const guard = await validateSharedExecutionGuards({
          userId,
          botId: bot.id,
          botType: 'DCA',
          symbol: bot.symbol,
          quoteCurrency: bot.quoteCurrency,
          side: 'BUY',
          requestedQuoteAmount: perStageAmount,
        });
        if (!guard.ok) {
          reason = guard.reasonFa;
        } else {
          const qty = roundQuantityToStep(
            perStageAmount / currentPrice,
            marketRules.amountStep,
            'floor'
          );
          if (qty > 0 && qty * currentPrice >= marketRules.minNotional) {
            if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
              await createPendingConfirmation({
                userId,
                botId: bot.id,
                botType: 'DCA',
                botName: bot.name,
                symbol: bot.symbol,
                baseAsset: bot.baseAsset,
                quoteCurrency: bot.quoteCurrency,
                mode: bot.mode,
                side: 'BUY',
                orderType: 'MARKET',
                suggestedPrice: currentPrice,
                quantity: qty,
                quoteAmount: perStageAmount,
                estimatedFeeQuote: perStageAmount * bot.feeRate,
                reasonFa: buyTriggerLabel,
                riskSummaryFa: `پله ${state.stagesCompleted + 1} از ${bot.stagesCount} · سرمایه درگیر بعد خرید: ${Math.round(
                  state.totalInvestedQuote + perStageAmount
                ).toLocaleString('en-US')}`,
              });
              reason = `در انتظار تأیید دستی شما برای خرید پله ${state.stagesCompleted + 1}`;
            } else {
              const idempotencyKey = `dca:${bot.id}:stage${state.stagesCompleted + 1}:${stats.completedCycles}:${Math.floor(now / 15000)}`;
              if (bot.mode === 'live') {
                const creds = await getActiveExchangeCredentialsForUser(userId);
                if (!creds) throw new NobitexAuthError('کلید API نوبیتکس موجود نیست.');
                const order = await placeNobitexLiveOrder(
                  {
                    baseAsset: bot.baseAsset,
                    quoteCurrency: bot.quoteCurrency,
                    side: 'BUY',
                    type: 'MARKET',
                    quantity: qty,
                    source: 'BOT',
                    botId: bot.id,
                    clientOrderId: formatNobitexClientOrderId(idempotencyKey),
                  },
                  creds
                );
                await recordLiveOrderAndTrade(userId, order, { idempotencyKey });
              } else {
                await placePaperOrder(userId, {
                  baseAsset: bot.baseAsset,
                  quoteCurrency: bot.quoteCurrency,
                  side: 'BUY',
                  type: 'MARKET',
                  quantity: qty,
                  price: currentPrice,
                  source: 'BOT',
                  botId: bot.id,
                  idempotencyKey,
                });
              }

              const buyFee = perStageAmount * bot.feeRate;
              const netQty = qty * (1 - bot.feeRate);
              state.stagesCompleted += 1;
              state.totalHoldingQty += qty;
              state.netOwnedQty += netQty;
              state.totalInvestedQuote += perStageAmount;
              state.totalBuyFeesQuote += buyFee;
              state.avgBuyPrice =
                state.netOwnedQty > 0 ? state.totalInvestedQuote / state.netOwnedQty : currentPrice;
              state.lastBuyPrice = currentPrice;
              state.highestPriceSinceEntry = Math.max(state.highestPriceSinceEntry || 0, currentPrice);
              state.nextTriggerAt = now + bot.intervalMinutes * 60_000;
              stats.totalFeesPaidQuote += buyFee;
              reason = `${buyTriggerLabel} اجرا شد · میانگین جدید: ${Math.round(
                state.avgBuyPrice
              ).toLocaleString('en-US')}`;
            }
          }
        }
      }
    } else if (bot.pauseNewBuys) {
      reason = `خریدهای جدید متوقف است · مدیریت دارایی موجود (${state.stagesCompleted} پله خریداری شده)`;
    }

    dcaRetryAfterMap.delete(bot.id);
    await db
      .update(schema.dcaBots)
      .set({
        stateJson: state,
        statsJson: stats,
        status: bot.pauseNewBuys ? 'PAUSED_BUYS' : 'RUNNING',
        lastPrice: currentPrice,
        lastStatusReason: reason,
        lastError: null,
        lastCheckedAt: now,
        updatedAt: now,
      })
      .where(eq(schema.dcaBots.id, bot.id));
  } catch (err) {
    const rawMsg = err instanceof Error ? err.message : 'خطا در اجرای ربات DCA';
    const rateLimited = isRateLimitErr(err);
    const prev = dcaRetryAfterMap.get(bot.id);
    const failures = (prev?.failures || 0) + 1;
    const backoffMs = rateLimited
      ? err instanceof NobitexRateLimitError
        ? Math.max(25_000, err.retryAfterMs)
        : Math.min(90_000, 30_000 * 2 ** Math.min(2, failures - 1))
      : Math.min(60_000, 10_000 * 2 ** Math.min(2, failures - 1));
    dcaRetryAfterMap.set(bot.id, { until: Date.now() + backoffMs, failures });
    const friendlyMsg = rateLimited
      ? `محدودیت موقت تعداد درخواست نوبیتکس (429) — تلاش مجدد خودکار تا ${Math.ceil(backoffMs / 1000)} ثانیه دیگر`
      : rawMsg;

    await db
      .update(schema.dcaBots)
      .set({
        lastError: friendlyMsg.slice(0, 400),
        lastStatusReason: rateLimited ? friendlyMsg : `خطا: ${friendlyMsg}`,
        lastCheckedAt: Date.now(),
        updatedAt: Date.now(),
      })
      .where(eq(schema.dcaBots.id, bot.id));
  }

  return (await getUserDcaBotById(userId, bot.id))!;
}

export async function runAllActiveDcaBotsCycle(options?: {
  respectSchedule?: boolean;
}): Promise<number> {
  if (isEvaluatingDcaBotsLocally) return 0;
  isEvaluatingDcaBotsLocally = true;
  try {
    const db = getDb();
    const rows = await db
      .select()
      .from(schema.dcaBots)
      .where(eq(schema.dcaBots.isActive, true));

    const now = Date.now();
    const respectSchedule = Boolean(options?.respectSchedule);
    const globalRateLimitMs = getNobitexRateLimitRemainingMs();
    let count = 0;

    for (const r of rows) {
      const bot = mapDcaBotRow(r);
      if (respectSchedule) {
        const retryEntry = dcaRetryAfterMap.get(bot.id);
        if (retryEntry && retryEntry.until > now) {
          continue;
        }
        if (bot.mode === 'live' && globalRateLimitMs > 0) {
          continue;
        }
        const lastRun = Math.max(dcaLastRunMap.get(bot.id) || 0, bot.lastCheckedAt || 0);
        const minIntervalMs = bot.mode === 'live' ? 12_000 : 4_000;
        if (lastRun > 0 && now - lastRun < minIntervalMs - 250) {
          continue;
        }
      }
      await evaluateDcaBot(bot);
      count += 1;
    }
    return count;
  } finally {
    isEvaluatingDcaBotsLocally = false;
  }
}

export async function emergencyStopUserDcaBots(userId: string): Promise<number> {
  const db = getDb();
  const res = await db
    .update(schema.dcaBots)
    .set({
      isActive: false,
      status: 'PAUSED',
      lastStatusReason: 'توقف اضطراری (Kill Switch)',
      updatedAt: Date.now(),
    })
    .where(and(eq(schema.dcaBots.userId, userId), eq(schema.dcaBots.isActive, true)))
    .returning();
  return res.length;
}

// =========================================================================
// AI Manager Saved Reports & Unified Dashboard Computation
// =========================================================================
export async function saveAiManagerReport(
  userId: string,
  report: AiManagerAnalysis
): Promise<void> {
  await ensureUserRecord({ uid: userId });
  const db = getDb();
  await db.insert(schema.aiManagerReports).values({
    id: report.id,
    userId,
    reportJson: report,
    createdAt: report.generatedAt,
  });
}

export async function getLatestAiManagerReports(userId: string): Promise<AiManagerAnalysis[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.aiManagerReports)
    .where(eq(schema.aiManagerReports.userId, userId))
    .orderBy(desc(schema.aiManagerReports.createdAt))
    .limit(10);
  return rows.map((r) => r.reportJson as AiManagerAnalysis);
}

export async function computeUnifiedBotsDashboard(
  userId: string
): Promise<UnifiedBotsDashboardSummary> {
  const db = getDb();
  const { getUserAiCycleProBots, getUserAiCycleProCycles } = await import('./aiCycleProEngine.ts');
  const [
    riskSettings,
    strategyRows,
    gridBots,
    dcaBots,
    profitBots,
    profitCycles,
    aiCycleBots,
    aiCycleCycles,
    tradeRows,
    pendingConfs,
    marketRes,
  ] = await Promise.all([
    getUserBotRiskSettings(userId),
    db.select().from(schema.tradingBots).where(eq(schema.tradingBots.userId, userId)),
    getUserGridBots(userId),
    getUserDcaBots(userId),
    getUserProfitBots(userId),
    db.select().from(schema.profitBotCycles).where(eq(schema.profitBotCycles.userId, userId)),
    getUserAiCycleProBots(userId),
    getUserAiCycleProCycles(userId),
    db.select().from(schema.trades).where(eq(schema.trades.userId, userId)),
    listPendingConfirmations(userId),
    fetchNobitexUnifiedMarkets().catch(() => ({ markets: [], usdtTomanRate: 0 })),
  ]);

  const priceMapIrt = new Map<string, number>();
  const priceMapUsdt = new Map<string, number>();
  for (const m of marketRes.markets) {
    priceMapIrt.set(m.baseAsset.toUpperCase(), m.priceToman || 0);
    priceMapUsdt.set(m.baseAsset.toUpperCase(), m.priceUsdt || 0);
  }
  const getLivePrice = (baseAsset: string, qc: QuoteCurrency) =>
    qc === 'IRT'
      ? priceMapIrt.get(baseAsset.toUpperCase()) || 0
      : priceMapUsdt.get(baseAsset.toUpperCase()) || 0;

  const now = Date.now();
  const dayMs = 86_400_000;
  let realizedPnlDailyIrt = 0;
  let realizedPnlWeeklyIrt = 0;
  let realizedPnlMonthlyIrt = 0;
  let realizedPnlDailyUsdt = 0;

  for (const cy of [...profitCycles, ...aiCycleCycles]) {
    const age = now - cy.completedAt;
    if (cy.quoteCurrency === 'IRT') {
      if (age <= dayMs) realizedPnlDailyIrt += cy.finalNetProfitQuote;
      if (age <= 7 * dayMs) realizedPnlWeeklyIrt += cy.finalNetProfitQuote;
      if (age <= 30 * dayMs) realizedPnlMonthlyIrt += cy.finalNetProfitQuote;
    } else if (age <= dayMs) {
      realizedPnlDailyUsdt += cy.finalNetProfitQuote;
    }
  }

  for (const tr of tradeRows) {
    if (!tr.botId || tr.realizedPnlQuote === null || tr.realizedPnlQuote === undefined) continue;
    const age = now - tr.executedAt;
    if (tr.quoteCurrency === 'IRT') {
      if (age <= dayMs) realizedPnlDailyIrt += tr.realizedPnlQuote;
      if (age <= 7 * dayMs) realizedPnlWeeklyIrt += tr.realizedPnlQuote;
      if (age <= 30 * dayMs) realizedPnlMonthlyIrt += tr.realizedPnlQuote;
    } else if (age <= dayMs) {
      realizedPnlDailyUsdt += tr.realizedPnlQuote;
    }
  }

  const rows: UnifiedBotSummaryRow[] = [];
  let committedCapitalIrt = 0;
  let committedCapitalUsdt = 0;
  let unrealizedPnlIrt = 0;
  let unrealizedPnlUsdt = 0;
  let totalFeesPaidIrt = 0;
  let totalFeesPaidUsdt = 0;
  let openPositionsCount = 0;
  let closedTradesCount = 0;
  let totalWins = 0;
  let totalAllTrades = 0;

  // Profit Bots
  for (const p of profitBots) {
    const px = getLivePrice(p.baseAsset, p.quoteCurrency);
    const committed = p.activePosition ? p.activePosition.totalBuyCostQuote : 0;
    const unreal = p.activePosition
      ? p.activePosition.lastEstimatedNetProfitQuote ??
        (px > 0 ? p.activePosition.netOwnedQty * px - p.activePosition.totalBuyCostQuote : 0)
      : 0;
    if (p.activePosition) openPositionsCount += 1;
    if (p.quoteCurrency === 'IRT') {
      committedCapitalIrt += committed;
      unrealizedPnlIrt += unreal;
      totalFeesPaidIrt += p.stats.totalFeesPaidQuote;
    } else {
      committedCapitalUsdt += committed;
      unrealizedPnlUsdt += unreal;
      totalFeesPaidUsdt += p.stats.totalFeesPaidQuote;
    }
    closedTradesCount += p.stats.completedCycles;
    totalWins += p.stats.winningCycles;
    totalAllTrades += p.stats.completedCycles;

    rows.push({
      id: p.id,
      botType: 'PROFIT',
      name: p.name,
      symbol: p.symbol,
      baseAsset: p.baseAsset,
      quoteCurrency: p.quoteCurrency,
      mode: p.mode,
      isActive: p.isActive,
      statusLabelFa: p.isActive ? 'فعال' : 'متوقف',
      allocatedCapitalQuote: p.maxCapitalInvolved || p.entryAmount,
      committedCapitalQuote: committed,
      realizedPnlQuote: p.stats.totalNetProfitQuote,
      unrealizedPnlQuote: unreal,
      feesPaidQuote: p.stats.totalFeesPaidQuote,
      tradesCount: p.stats.completedCycles,
      winRatePercent:
        p.stats.completedCycles > 0
          ? Number(((p.stats.winningCycles / p.stats.completedCycles) * 100).toFixed(1))
          : 0,
      lastUpdatedAt: p.updatedAt,
    });
  }

  // Strategy & Fixed Price Bots
  const cfgRows = await db
    .select()
    .from(schema.botConfigurations)
    .where(eq(schema.botConfigurations.userId, userId));
  const cfgMap = new Map(cfgRows.map((c) => [c.botId, c]));

  for (const s of strategyRows) {
    const cfg = cfgMap.get(s.id);
    const entryRules = Array.isArray(cfg?.entryRulesJson)
      ? (cfg!.entryRulesJson as Array<{ type?: string }>)
      : [];
    const isFixed = entryRules.some((r) => r.type === 'FIXED_BUY_PRICE');
    const st = (s.statsJson || {}) as {
      totalTrades?: number;
      winningTrades?: number;
      realizedPnl?: number;
      totalFeesPaidQuote?: number;
    };
    const pos = s.activePositionJson as { entryPrice?: number; quantity?: number } | null;
    const qc: QuoteCurrency = s.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
    const px = getLivePrice(s.baseAsset, qc);
    const committed = pos ? Number(s.orderAmount || 0) : 0;
    const unreal =
      pos && pos.quantity && pos.entryPrice && px > 0 ? (px - pos.entryPrice) * pos.quantity : 0;
    const fees = Number(st.totalFeesPaidQuote || 0);
    if (pos) openPositionsCount += 1;
    if (qc === 'IRT') {
      committedCapitalIrt += committed;
      unrealizedPnlIrt += unreal;
      totalFeesPaidIrt += fees;
    } else {
      committedCapitalUsdt += committed;
      unrealizedPnlUsdt += unreal;
      totalFeesPaidUsdt += fees;
    }
    const tradesCount = Number(st.totalTrades || 0);
    const wins = Number(st.winningTrades || 0);
    closedTradesCount += tradesCount;
    totalWins += wins;
    totalAllTrades += tradesCount;

    rows.push({
      id: s.id,
      botType: isFixed ? 'FIXED_PRICE' : 'STRATEGY',
      name: s.name,
      symbol: s.symbol,
      baseAsset: s.baseAsset,
      quoteCurrency: qc,
      mode: s.mode === 'live' ? 'live' : 'paper',
      isActive: s.status === 'RUNNING',
      statusLabelFa: s.status === 'RUNNING' ? 'فعال' : 'متوقف',
      allocatedCapitalQuote: s.orderAmount,
      committedCapitalQuote: committed,
      realizedPnlQuote: Number(st.realizedPnl || 0),
      unrealizedPnlQuote: unreal,
      feesPaidQuote: fees,
      tradesCount,
      winRatePercent: tradesCount > 0 ? Number(((wins / tradesCount) * 100).toFixed(1)) : 0,
      lastUpdatedAt: s.updatedAt,
    });
  }

  // Grid Bots
  for (const g of gridBots) {
    const px = getLivePrice(g.baseAsset, g.quoteCurrency);
    const committed = g.stats.currentCapitalInvolved;
    let unreal = 0;
    for (const lv of g.allocatedLevels) {
      if (lv.status === 'HOLDING' && px > 0 && lv.buyPrice) {
        unreal += (px - lv.buyPrice) * lv.qty;
      }
    }
    if (g.stats.openOrdersCount > 0) openPositionsCount += 1;
    if (g.quoteCurrency === 'IRT') {
      committedCapitalIrt += committed;
      unrealizedPnlIrt += unreal;
      totalFeesPaidIrt += g.stats.totalFeesPaidQuote;
    } else {
      committedCapitalUsdt += committed;
      unrealizedPnlUsdt += unreal;
      totalFeesPaidUsdt += g.stats.totalFeesPaidQuote;
    }
    closedTradesCount += g.stats.completedCycles;
    totalWins += g.stats.totalNetProfitQuote >= 0 ? g.stats.completedCycles : 0;
    totalAllTrades += g.stats.completedCycles;

    rows.push({
      id: g.id,
      botType: 'GRID',
      name: g.name,
      symbol: g.symbol,
      baseAsset: g.baseAsset,
      quoteCurrency: g.quoteCurrency,
      mode: g.mode,
      isActive: g.isActive,
      statusLabelFa: g.status === 'OUT_OF_RANGE' ? 'خارج از بازه' : g.isActive ? 'فعال' : 'متوقف',
      allocatedCapitalQuote: g.totalCapital,
      committedCapitalQuote: committed,
      realizedPnlQuote: g.stats.totalNetProfitQuote,
      unrealizedPnlQuote: unreal,
      feesPaidQuote: g.stats.totalFeesPaidQuote,
      tradesCount: g.stats.completedCycles,
      winRatePercent: g.stats.completedCycles > 0 ? 100 : 0,
      lastUpdatedAt: g.updatedAt,
    });
  }

  // DCA Bots
  for (const d of dcaBots) {
    const px = getLivePrice(d.baseAsset, d.quoteCurrency);
    const committed = d.state.totalInvestedQuote;
    const unreal =
      d.state.netOwnedQty > 0 && px > 0 ? d.state.netOwnedQty * px - d.state.totalInvestedQuote : 0;
    if (d.state.netOwnedQty > 0) openPositionsCount += 1;
    if (d.quoteCurrency === 'IRT') {
      committedCapitalIrt += committed;
      unrealizedPnlIrt += unreal;
      totalFeesPaidIrt += d.stats.totalFeesPaidQuote;
    } else {
      committedCapitalUsdt += committed;
      unrealizedPnlUsdt += unreal;
      totalFeesPaidUsdt += d.stats.totalFeesPaidQuote;
    }
    closedTradesCount += d.stats.completedCycles;
    if (d.stats.realizedNetProfitQuote > 0) totalWins += d.stats.completedCycles;
    totalAllTrades += d.stats.completedCycles;

    rows.push({
      id: d.id,
      botType: 'DCA',
      name: d.name,
      symbol: d.symbol,
      baseAsset: d.baseAsset,
      quoteCurrency: d.quoteCurrency,
      mode: d.mode,
      isActive: d.isActive,
      statusLabelFa: d.pauseNewBuys ? 'خرید متوقف (مدیریت دارایی)' : d.isActive ? 'فعال' : 'متوقف',
      allocatedCapitalQuote: d.totalCapital,
      committedCapitalQuote: committed,
      realizedPnlQuote: d.stats.realizedNetProfitQuote,
      unrealizedPnlQuote: unreal,
      feesPaidQuote: d.stats.totalFeesPaidQuote,
      tradesCount: d.stats.completedCycles,
      winRatePercent: d.stats.completedCycles > 0 && d.stats.realizedNetProfitQuote >= 0 ? 100 : 0,
      lastUpdatedAt: d.updatedAt,
    });
  }

  // AI Cycle Pro Bots
  for (const ac of aiCycleBots) {
    const px = getLivePrice(ac.baseAsset, ac.quoteCurrency);
    const committed = ac.activePosition ? ac.activePosition.totalBuyCostQuote : 0;
    const unreal = ac.activePosition
      ? ac.activePosition.lastEstimatedNetProfitQuote ??
        (px > 0
          ? ac.activePosition.netOwnedQty * px * (1 - ac.feeRate) -
            ac.activePosition.totalBuyCostQuote
          : 0)
      : 0;
    if (ac.activePosition) openPositionsCount += 1;
    if (ac.quoteCurrency === 'IRT') {
      committedCapitalIrt += committed;
      unrealizedPnlIrt += unreal;
      totalFeesPaidIrt += ac.stats.totalFeesPaidQuote;
    } else {
      committedCapitalUsdt += committed;
      unrealizedPnlUsdt += unreal;
      totalFeesPaidUsdt += ac.stats.totalFeesPaidQuote;
    }
    closedTradesCount += ac.stats.completedCycles;
    totalWins += ac.stats.winningCycles;
    totalAllTrades += ac.stats.completedCycles;

    rows.push({
      id: ac.id,
      botType: 'AI_CYCLE_PRO',
      name: ac.name,
      symbol: ac.symbol,
      baseAsset: ac.baseAsset,
      quoteCurrency: ac.quoteCurrency,
      mode: ac.mode,
      isActive: ac.isActive,
      statusLabelFa:
        ac.status === 'HOLDING_POSITION'
          ? 'در حال نگهداری پوزیشن'
          : ac.status === 'WAITING_CASH'
            ? 'نقد (انتظار شرایط بهتر)'
            : ac.status === 'PAUSED_RISK'
              ? 'متوقف (سقف ریسک)'
              : ac.isActive
                ? 'در حال تحلیل هوشمند'
                : 'متوقف',
      allocatedCapitalQuote: ac.capitalAmount,
      committedCapitalQuote: committed,
      realizedPnlQuote: ac.stats.totalNetProfitQuote,
      unrealizedPnlQuote: unreal,
      feesPaidQuote: ac.stats.totalFeesPaidQuote,
      tradesCount: ac.stats.completedCycles,
      winRatePercent:
        ac.stats.completedCycles > 0
          ? Number(((ac.stats.winningCycles / ac.stats.completedCycles) * 100).toFixed(1))
          : 0,
      lastUpdatedAt: ac.updatedAt,
    });
  }

  // Conflict check
  const activeSymbolsMap = new Map<string, number>();
  for (const r of rows) {
    if (r.isActive) {
      activeSymbolsMap.set(r.symbol, (activeSymbolsMap.get(r.symbol) || 0) + 1);
    }
  }
  const activeConflictSymbols = [...activeSymbolsMap.entries()]
    .filter(([, cnt]) => cnt > 1)
    .map(([sym]) => sym);

  const sortedByPerf = [...rows].sort((a, b) => b.realizedPnlQuote - a.realizedPnlQuote);
  const bestBot = sortedByPerf[0] || null;
  const worstBot = sortedByPerf.length > 1 ? sortedByPerf[sortedByPerf.length - 1] : null;
  const totalIrtPnl = rows
    .filter((r) => r.quoteCurrency === 'IRT')
    .reduce((s, r) => s + r.realizedPnlQuote, 0);
  const irtTrades = rows
    .filter((r) => r.quoteCurrency === 'IRT')
    .reduce((s, r) => s + r.tradesCount, 0);

  return {
    totalBudgetIrt: riskSettings.totalBotsBudgetIrt,
    totalBudgetUsdt: riskSettings.totalBotsBudgetUsdt,
    committedCapitalIrt,
    committedCapitalUsdt,
    freeBudgetIrt: Math.max(0, riskSettings.totalBotsBudgetIrt - committedCapitalIrt),
    freeBudgetUsdt: Math.max(0, riskSettings.totalBotsBudgetUsdt - committedCapitalUsdt),
    realizedPnlDailyIrt,
    realizedPnlWeeklyIrt,
    realizedPnlMonthlyIrt,
    unrealizedPnlIrt,
    totalFeesPaidIrt,
    realizedPnlDailyUsdt,
    unrealizedPnlUsdt,
    totalFeesPaidUsdt,
    openPositionsCount,
    closedTradesCount,
    overallWinRatePercent: totalAllTrades > 0 ? Number(((totalWins / totalAllTrades) * 100).toFixed(1)) : 0,
    avgPnlPerTradeIrt: irtTrades > 0 ? Math.round(totalIrtPnl / irtTrades) : 0,
    bestBot,
    worstBot,
    activeConflictSymbols,
    pendingConfirmationsCount: pendingConfs.filter((c) => c.status === 'PENDING').length,
    rows,
  };
}
