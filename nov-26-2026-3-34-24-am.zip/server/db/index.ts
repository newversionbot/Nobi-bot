import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { PGlite } from '@electric-sql/pglite';
import { eq, sql } from 'drizzle-orm';
import { drizzle as drizzlePg, type NodePgDatabase } from 'drizzle-orm/node-postgres';
import { drizzle as drizzlePglite, type PgliteDatabase } from 'drizzle-orm/pglite';
import { Pool } from 'pg';
import * as schema from '../../src/db/schema.ts';
import { appConfig, buildVaultKeyRing } from '../config.ts';
import { logger } from '../logger.ts';

export type AppDatabase =
  | NodePgDatabase<typeof schema>
  | PgliteDatabase<typeof schema>;

interface DatabaseRuntime {
  driver: 'pg' | 'pglite';
  db: AppDatabase;
  pool?: Pool;
  pglite?: PGlite;
  close: () => Promise<void>;
  execSql: (sqlText: string) => Promise<void>;
  queryRows: <T = Record<string, unknown>>(sqlText: string, params?: unknown[]) => Promise<T[]>;
}

let runtime: DatabaseRuntime | null = null;
let initPromise: Promise<AppDatabase> | null = null;

const MIGRATION_FILE = path.resolve(process.cwd(), 'drizzle', '0000_init.sql');
const SYNC_COLUMNS_MIGRATION_FILE = path.resolve(process.cwd(), 'drizzle', '0001_sync_columns.sql');
const PROFIT_BOTS_MIGRATION_FILE = path.resolve(process.cwd(), 'drizzle', '0002_profit_bots.sql');
const SMART_BOTS_MIGRATION_FILE = path.resolve(process.cwd(), 'drizzle', '0003_smart_bots_upgrade.sql');
const AI_CYCLE_PRO_MIGRATION_FILE = path.resolve(process.cwd(), 'drizzle', '0004_ai_cycle_pro.sql');
const REFERRAL_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

export function makeReferralCode(): string {
  const bytes = crypto.randomBytes(6);
  let suffix = '';
  for (let i = 0; i < 6; i++) {
    suffix += REFERRAL_ALPHABET[bytes[i] % REFERRAL_ALPHABET.length];
  }
  return `ALI-${suffix}`;
}

export async function initDatabase(options?: {
  databaseUrl?: string;
  pgliteDataDir?: string;
  forceReset?: boolean;
}): Promise<AppDatabase> {
  if (options?.forceReset && runtime) {
    await closeDatabase();
  }
  if (runtime) return runtime.db;
  if (initPromise) return initPromise;

  initPromise = (async () => {
    const dbUrl = options?.databaseUrl ?? appConfig.DATABASE_URL;
    if (appConfig.isProduction && !dbUrl) {
      throw new Error('DATABASE_URL is strictly required in production mode.');
    }

    if (dbUrl) {
      const pool = new Pool({
        connectionString: dbUrl,
        max: 20,
        idleTimeoutMillis: 30_000,
        connectionTimeoutMillis: 10_000,
      });
      const db = drizzlePg(pool, { schema });
      runtime = {
        driver: 'pg',
        db,
        pool,
        close: async () => {
          await pool.end();
        },
        execSql: async (sqlText: string) => {
          await pool.query(sqlText);
        },
        queryRows: async <T = Record<string, unknown>>(sqlText: string, params: unknown[] = []) => {
          const res = await pool.query(sqlText, params);
          return res.rows as T[];
        },
      };
      logger.info('db.connected', { driver: 'pg' });
    } else {
      const isTestRuntime =
        appConfig.isTest || process.env.NODE_ENV === 'test' || Boolean(process.env.VITEST);
      const targetDir =
        options?.pgliteDataDir ??
        (isTestRuntime ? 'memory://' : path.resolve(process.cwd(), appConfig.PGLITE_DATA_DIR));

      if (targetDir !== 'memory://') {
        fs.mkdirSync(targetDir, { recursive: true });
      }
      const pglite = new PGlite(targetDir);
      await pglite.waitReady;
      const db = drizzlePglite(pglite, { schema });
      runtime = {
        driver: 'pglite',
        db,
        pglite,
        close: async () => {
          await pglite.close();
        },
        execSql: async (sqlText: string) => {
          await pglite.exec(sqlText);
        },
        queryRows: async <T = Record<string, unknown>>(sqlText: string, params: unknown[] = []) => {
          const res = await pglite.query<T>(sqlText, params);
          return res.rows;
        },
      };
      logger.info('db.connected', {
        driver: 'pglite',
        target: targetDir === 'memory://' ? 'memory' : 'local_dir',
      });
    }

    await applySqlMigrations();
    const isTestRuntime =
      appConfig.isTest || process.env.NODE_ENV === 'test' || Boolean(process.env.VITEST);
    if (!isTestRuntime) {
      await migrateLegacyJsonFilesIfNeeded();
    }
    return runtime.db;
  })();

  try {
    return await initPromise;
  } catch (err) {
    initPromise = null;
    throw err;
  }
}

export function getDb(): AppDatabase {
  if (!runtime) {
    throw new Error('Database has not been initialized. Call initDatabase() first.');
  }
  return runtime.db;
}

export function getDbRuntime(): DatabaseRuntime {
  if (!runtime) {
    throw new Error('Database has not been initialized. Call initDatabase() first.');
  }
  return runtime;
}

export async function closeDatabase(): Promise<void> {
  initPromise = null;
  if (!runtime) return;
  const current = runtime;
  runtime = null;
  await current.close();
}

export async function pingDatabase(): Promise<boolean> {
  if (!runtime) return false;
  try {
    await runtime.queryRows('SELECT 1 AS ok');
    return true;
  } catch {
    return false;
  }
}

export async function withTransaction<T>(
  fn: (tx: AppDatabase) => Promise<T>
): Promise<T> {
  const db = getDb();
  return (db as NodePgDatabase<typeof schema>).transaction(async (tx) => {
    return fn(tx as unknown as AppDatabase);
  });
}

async function applySqlMigrations(): Promise<void> {
  if (!runtime) return;
  if (!fs.existsSync(MIGRATION_FILE)) {
    throw new Error(`Migration file not found: ${MIGRATION_FILE}`);
  }
  const migrationSql = fs.readFileSync(MIGRATION_FILE, 'utf-8');
  await runtime.execSql(migrationSql);

  if (fs.existsSync(SYNC_COLUMNS_MIGRATION_FILE)) {
    const syncSql = fs.readFileSync(SYNC_COLUMNS_MIGRATION_FILE, 'utf-8');
    await runtime.execSql(syncSql);
  }

  if (fs.existsSync(PROFIT_BOTS_MIGRATION_FILE)) {
    const profitSql = fs.readFileSync(PROFIT_BOTS_MIGRATION_FILE, 'utf-8');
    await runtime.execSql(profitSql);
  }

  if (fs.existsSync(SMART_BOTS_MIGRATION_FILE)) {
    const smartSql = fs.readFileSync(SMART_BOTS_MIGRATION_FILE, 'utf-8');
    await runtime.execSql(smartSql);
  }

  if (fs.existsSync(AI_CYCLE_PRO_MIGRATION_FILE)) {
    const aiCycleSql = fs.readFileSync(AI_CYCLE_PRO_MIGRATION_FILE, 'utf-8');
    await runtime.execSql(aiCycleSql);
  }

  for (const migrationId of [
    '0000_init',
    '0001_sync_columns',
    '0002_profit_bots',
    '0003_smart_bots_upgrade',
    '0004_ai_cycle_pro',
  ]) {
    const existing = await runtime.queryRows<{ id: string }>(
      `SELECT id FROM _app_migrations WHERE id = $1`,
      [migrationId]
    );
    if (existing.length === 0) {
      await runtime.queryRows(
        `INSERT INTO _app_migrations (id, applied_at) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
        [migrationId, Date.now()]
      );
    }
  }
}

export async function ensureUserRecord(input: {
  uid: string;
  email?: string;
  displayName?: string;
}): Promise<typeof schema.users.$inferSelect> {
  const db = getDb();
  const cleanUid = input.uid.trim();
  const existing = await db
    .select()
    .from(schema.users)
    .where(eq(schema.users.uid, cleanUid))
    .limit(1);

  const now = Date.now();
  if (existing.length > 0) {
    const row = existing[0];
    const nextEmail = input.email?.trim() || row.email;
    const nextName = input.displayName?.trim() || row.displayName || nextEmail || 'کاربر';
    if (nextEmail !== row.email || nextName !== row.displayName || now - row.lastSeenAt > 60_000) {
      const [updated] = await db
        .update(schema.users)
        .set({
          email: nextEmail,
          displayName: nextName,
          lastSeenAt: now,
        })
        .where(eq(schema.users.uid, cleanUid))
        .returning();
      return updated || row;
    }
    return row;
  }

  let code = makeReferralCode();
  for (let i = 0; i < 8; i++) {
    const clash = await db
      .select({ uid: schema.users.uid })
      .from(schema.users)
      .where(sql`UPPER(${schema.users.referralCode}) = ${code.toUpperCase()}`)
      .limit(1);
    if (clash.length === 0) break;
    code = makeReferralCode();
  }

  await db
    .insert(schema.users)
    .values({
      uid: cleanUid,
      email: input.email?.trim() || '',
      displayName: input.displayName?.trim() || input.email?.trim() || 'کاربر',
      isBanned: false,
      referralCode: code,
      referralBonusDaysEarned: 0,
      createdAt: now,
      lastSeenAt: now,
    })
    .onConflictDoNothing();

  const [created] = await db
    .select()
    .from(schema.users)
    .where(eq(schema.users.uid, cleanUid))
    .limit(1);
  return created;
}

export async function ensureDefaultPaperWallet(userId: string): Promise<void> {
  const db = getDb();
  const existing = await db
    .select({ id: schema.paperTradingBalances.id })
    .from(schema.paperTradingBalances)
    .where(eq(schema.paperTradingBalances.userId, userId))
    .limit(1);

  if (existing.length > 0) return;

  const now = Date.now();
  await db
    .insert(schema.paperTradingBalances)
    .values([
      { userId, asset: 'IRT', balance: 500_000_000, updatedAt: now },
      { userId, asset: 'USDT', balance: 5_000, updatedAt: now },
    ])
    .onConflictDoNothing();
}

export async function acquireWorkerLock(
  lockName: string,
  ownerId: string,
  ttlMs = 30_000
): Promise<boolean> {
  const rt = getDbRuntime();
  const now = Date.now();
  const expiresAt = now + ttlMs;
  const rows = await rt.queryRows<{ owner_id: string }>(
    `INSERT INTO worker_locks (lock_name, owner_id, acquired_at, expires_at, updated_at)
     VALUES ($1, $2, $3, $4, $3)
     ON CONFLICT (lock_name) DO UPDATE
       SET owner_id = EXCLUDED.owner_id,
           acquired_at = CASE WHEN worker_locks.owner_id = EXCLUDED.owner_id THEN worker_locks.acquired_at ELSE EXCLUDED.acquired_at END,
           expires_at = EXCLUDED.expires_at,
           updated_at = EXCLUDED.updated_at
     WHERE worker_locks.expires_at <= $3 OR worker_locks.owner_id = EXCLUDED.owner_id
     RETURNING owner_id`,
    [lockName, ownerId, now, expiresAt]
  );
  return rows.length > 0 && rows[0].owner_id === ownerId;
}

export async function renewWorkerLock(
  lockName: string,
  ownerId: string,
  ttlMs = 30_000
): Promise<boolean> {
  const rt = getDbRuntime();
  const now = Date.now();
  const rows = await rt.queryRows<{ owner_id: string }>(
    `UPDATE worker_locks
     SET expires_at = $3, updated_at = $2
     WHERE lock_name = $1 AND owner_id = $4
     RETURNING owner_id`,
    [lockName, now, now + ttlMs, ownerId]
  );
  return rows.length > 0;
}

export async function releaseWorkerLock(lockName: string, ownerId: string): Promise<void> {
  const rt = getDbRuntime();
  await rt.queryRows(
    `DELETE FROM worker_locks WHERE lock_name = $1 AND owner_id = $2`,
    [lockName, ownerId]
  );
}

const BACKUP_TABLES_ORDER = [
  'users',
  'exchange_credentials',
  'telegram_configurations',
  'trading_bots',
  'bot_configurations',
  'profit_bots',
  'profit_bot_cycles',
  'profit_bot_logs',
  'bot_risk_settings',
  'grid_bots',
  'dca_bots',
  'ai_cycle_pro_bots',
  'ai_cycle_pro_cycles',
  'ai_cycle_pro_logs',
  'pending_bot_confirmations',
  'ai_manager_reports',
  'orders',
  'trades',
  'trading_logs',
  'paper_trading_balances',
  'price_alerts',
  'price_watchers',
  'notifications',
  'subscriptions',
  'payments',
  'referrals',
  'admin_settings',
  'audit_logs',
  'app_api_keys',
  'cost_basis_overrides',
  'feature_ideas',
  'broadcasts',
  'direct_messages',
] as const;

export interface LogicalBackupPayload {
  version: number;
  exportedAt: number;
  tables: Record<string, Record<string, unknown>[]>;
}

export async function exportLogicalBackup(): Promise<LogicalBackupPayload> {
  const rt = getDbRuntime();
  const tables: Record<string, Record<string, unknown>[]> = {};
  for (const table of BACKUP_TABLES_ORDER) {
    tables[table] = await rt.queryRows(`SELECT * FROM ${table}`);
  }
  return {
    version: 1,
    exportedAt: Date.now(),
    tables,
  };
}

export async function restoreLogicalBackup(backup: LogicalBackupPayload): Promise<void> {
  const rt = getDbRuntime();
  // Truncate in reverse dependency order
  const reversed = [...BACKUP_TABLES_ORDER].reverse();
  for (const table of reversed) {
    await rt.execSql(`DELETE FROM ${table};`);
  }

  for (const table of BACKUP_TABLES_ORDER) {
    const rows = backup.tables[table] || [];
    for (const row of rows) {
      const cols = Object.keys(row);
      if (cols.length === 0) continue;
      const placeholders = cols.map((_, idx) => `$${idx + 1}`).join(', ');
      const colNames = cols.map((c) => `"${c}"`).join(', ');
      const values = cols.map((c) => {
        const val = row[c];
        if (val !== null && typeof val === 'object' && !(val instanceof Date)) {
          return JSON.stringify(val);
        }
        return val;
      });
      await rt.queryRows(
        `INSERT INTO ${table} (${colNames}) VALUES (${placeholders}) ON CONFLICT DO NOTHING`,
        values
      );
    }
  }
}

function encryptLegacyToken(plain: string): {
  keyId: string;
  encrypted: string;
  iv: string;
  authTag: string;
} {
  const ring = buildVaultKeyRing();
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', ring.primaryKey, iv);
  const encrypted = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
  return {
    keyId: ring.primaryKeyId,
    encrypted: encrypted.toString('base64'),
    iv: iv.toString('base64'),
    authTag: cipher.getAuthTag().toString('base64'),
  };
}

export interface LegacyMigrationResult {
  skipped: boolean;
  reason?: string;
  migratedBilling: boolean;
  migratedVault: boolean;
  migratedState: boolean;
  counts: {
    users: number;
    subscriptions: number;
    payments: number;
    bots: number;
    orders: number;
    trades: number;
    balances: number;
    alerts: number;
    watchers: number;
    exchangeCredentials: number;
    appApiKeys: number;
  };
}

export async function migrateLegacyJsonFiles(options?: {
  baseDir?: string;
  defaultOwnerUid?: string;
  forceRerun?: boolean;
}): Promise<LegacyMigrationResult> {
  const rt = getDbRuntime();
  const baseDir = options?.baseDir || process.cwd();
  const billingFile = path.resolve(baseDir, '.nobitex-billing.json');
  const vaultFile = path.resolve(baseDir, '.nobitex-vault.json');
  const stateFile = path.resolve(baseDir, '.nobitex-trader-state.json');

  const counts = {
    users: 0,
    subscriptions: 0,
    payments: 0,
    bots: 0,
    orders: 0,
    trades: 0,
    balances: 0,
    alerts: 0,
    watchers: 0,
    exchangeCredentials: 0,
    appApiKeys: 0,
  };

  if (!options?.forceRerun) {
    const marker = await rt.queryRows<{ id: string }>(
      `SELECT id FROM _app_migrations WHERE id = $1`,
      ['legacy_json_v1']
    );
    if (marker.length > 0) {
      return {
        skipped: true,
        reason: 'already_migrated',
        migratedBilling: false,
        migratedVault: false,
        migratedState: false,
        counts,
      };
    }
  }

  const hasBilling = fs.existsSync(billingFile);
  const hasVault = fs.existsSync(vaultFile);
  const hasState = fs.existsSync(stateFile);

  if (!hasBilling && !hasVault && !hasState) {
    return {
      skipped: true,
      reason: 'no_legacy_files',
      migratedBilling: false,
      migratedVault: false,
      migratedState: false,
      counts,
    };
  }

  let migratedBilling = false;
  let migratedVault = false;
  let migratedState = false;

  await withTransaction(async (tx) => {
    const ensureTxUser = async (uidRaw: string, email?: string, displayName?: string) => {
      const uid = uidRaw.trim();
      if (!uid) return;
      const now = Date.now();
      await tx
        .insert(schema.users)
        .values({
          uid,
          email: (email || '').trim(),
          displayName: (displayName || email || 'کاربر').trim(),
          isBanned: false,
          referralCode: makeReferralCode(),
          referralBonusDaysEarned: 0,
          createdAt: now,
          lastSeenAt: now,
        })
        .onConflictDoNothing();
    };

    let fallbackOwnerUid = (options?.defaultOwnerUid || process.env.LEGACY_MIGRATION_UID || '').trim();

    if (hasBilling) {
      const parsed = JSON.parse(fs.readFileSync(billingFile, 'utf-8')) as {
        users?: Record<string, any>;
        subscriptions?: Record<string, any>;
        paymentRequests?: any[];
        broadcasts?: any[];
        directMessages?: any[];
        referrals?: any[];
        auditLogs?: any[];
        config?: any;
        appControl?: any;
      };

      if (parsed.users && typeof parsed.users === 'object') {
        for (const u of Object.values(parsed.users)) {
          if (!u?.uid) continue;
          const uid = String(u.uid);
          if (!fallbackOwnerUid) fallbackOwnerUid = uid;
          await tx
            .insert(schema.users)
            .values({
              uid,
              email: String(u.email || ''),
              displayName: String(u.displayName || u.email || 'کاربر'),
              isBanned: Boolean(u.isBanned),
              banReason: u.banReason || null,
              adminNote: u.adminNote || null,
              referralCode: String(u.referralCode || makeReferralCode()),
              referredByUid: u.referredByUid || null,
              referredByCode: u.referredByCode || null,
              referredAt: u.referredAt ?? null,
              referralBonusDaysEarned: Number(u.referralBonusDaysEarned || 0),
              createdAt: Number(u.createdAt || Date.now()),
              lastSeenAt: Number(u.lastSeenAt || Date.now()),
            })
            .onConflictDoNothing();
          counts.users += 1;
        }
      }

      if (parsed.subscriptions && typeof parsed.subscriptions === 'object') {
        for (const s of Object.values(parsed.subscriptions)) {
          if (!s?.userId) continue;
          await ensureTxUser(String(s.userId), s.email, s.displayName);
          await tx
            .insert(schema.subscriptions)
            .values({
              userId: String(s.userId),
              email: String(s.email || ''),
              displayName: String(s.displayName || 'کاربر'),
              plan: String(s.plan || 'PRO_MONTHLY'),
              status: String(s.status || 'EXPIRED'),
              paymentMethod: String(s.paymentMethod || 'ADMIN_GRANT'),
              startAt: Number(s.startAt || Date.now()),
              expiresAt: Number(s.expiresAt || Date.now()),
              updatedAt: Number(s.updatedAt || Date.now()),
            })
            .onConflictDoNothing();
          counts.subscriptions += 1;
        }
      }

      for (const p of parsed.paymentRequests || []) {
        if (!p?.id || !p?.userId) continue;
        await ensureTxUser(String(p.userId), p.userEmail, p.userDisplayName);
        await tx
          .insert(schema.payments)
          .values({
            id: String(p.id),
            userId: String(p.userId),
            userEmail: String(p.userEmail || ''),
            userDisplayName: String(p.userDisplayName || 'کاربر'),
            method: String(p.method || 'USDT'),
            status: String(p.status || 'PENDING'),
            amountToman: Number(p.amountToman || 0),
            amountUsdt: Number(p.amountUsdt || 0),
            network: p.network || null,
            walletAddress: p.walletAddress || null,
            txHash: p.txHash || null,
            authority: p.authority || null,
            refId: p.refId || null,
            note: p.note || null,
            adminNote: p.adminNote || null,
            createdAt: Number(p.createdAt || Date.now()),
            updatedAt: Number(p.updatedAt || Date.now()),
            reviewedAt: p.reviewedAt ?? null,
          })
          .onConflictDoNothing();
        counts.payments += 1;
      }

      for (const b of parsed.broadcasts || []) {
        if (!b?.id) continue;
        await tx
          .insert(schema.broadcasts)
          .values({
            id: String(b.id),
            title: String(b.title || ''),
            body: String(b.body || ''),
            severity: String(b.severity || 'INFO'),
            active: b.active !== false,
            pinned: Boolean(b.pinned),
            createdAt: Number(b.createdAt || Date.now()),
            updatedAt: Number(b.updatedAt || Date.now()),
            expiresAt: b.expiresAt ?? null,
            createdByEmail: String(b.createdByEmail || ''),
          })
          .onConflictDoNothing();
      }

      for (const dm of parsed.directMessages || []) {
        if (!dm?.id || !dm?.targetUserId) continue;
        await ensureTxUser(String(dm.targetUserId), dm.targetUserEmail, dm.targetUserName);
        await tx
          .insert(schema.directMessages)
          .values({
            id: String(dm.id),
            targetUserId: String(dm.targetUserId),
            targetUserEmail: String(dm.targetUserEmail || ''),
            targetUserName: String(dm.targetUserName || ''),
            subject: String(dm.subject || ''),
            body: String(dm.body || ''),
            severity: String(dm.severity || 'INFO'),
            readByUser: Boolean(dm.readByUser),
            readAt: dm.readAt ?? null,
            createdAt: Number(dm.createdAt || Date.now()),
            updatedAt: Number(dm.updatedAt || Date.now()),
            senderEmail: String(dm.senderEmail || ''),
          })
          .onConflictDoNothing();
      }

      for (const ref of parsed.referrals || []) {
        if (!ref?.id || !ref?.referrerUid || !ref?.referredUserUid) continue;
        await ensureTxUser(String(ref.referrerUid), ref.referrerEmail, ref.referrerDisplayName);
        await ensureTxUser(
          String(ref.referredUserUid),
          ref.referredUserEmail,
          ref.referredUserDisplayName
        );
        await tx
          .insert(schema.referrals)
          .values({
            id: String(ref.id),
            referrerUid: String(ref.referrerUid),
            referrerEmail: String(ref.referrerEmail || ''),
            referrerDisplayName: String(ref.referrerDisplayName || 'کاربر'),
            referredUserUid: String(ref.referredUserUid),
            referredUserEmail: String(ref.referredUserEmail || ''),
            referredUserDisplayName: String(ref.referredUserDisplayName || 'کاربر'),
            referralCode: String(ref.referralCode || ''),
            status: String(ref.status || 'REGISTERED'),
            rewardDays: Number(ref.rewardDays || 4),
            createdAt: Number(ref.createdAt || Date.now()),
            updatedAt: Number(ref.updatedAt || Date.now()),
            rewardedAt: ref.rewardedAt ?? null,
          })
          .onConflictDoNothing();
      }

      if (parsed.config || parsed.appControl) {
        const cfg = parsed.config || {};
        const ac = parsed.appControl || {};
        await tx
          .insert(schema.adminSettings)
          .values({
            id: 'global',
            monthlyPriceToman: Number(cfg.monthlyPriceToman || 950_000),
            monthlyPriceUsdt: Number(cfg.monthlyPriceUsdt || 15),
            autoUsdtFromRate: cfg.autoUsdtFromRate !== false,
            usdtWalletAddress: String(cfg.usdtWalletAddress || ''),
            usdtNetwork: String(cfg.usdtNetwork || 'TRC20'),
            usdtWalletAddress2: String(cfg.usdtWalletAddress2 || ''),
            usdtNetwork2: String(cfg.usdtNetwork2 || 'BEP20'),
            zarinpalSandbox: cfg.zarinpalSandbox !== false,
            merchantKeyId: 'v1',
            encryptedMerchantJson: cfg.encryptedMerchantId || null,
            maskedMerchantId: String(cfg.maskedMerchantId || ''),
            maintenanceMode: Boolean(ac.maintenanceMode),
            maintenanceMessage: String(
              ac.maintenanceMessage ||
                'سیستم موقتاً در حال به‌روزرسانی و ارتقای سرویس است. لطفاً دقایقی دیگر مجدداً تلاش کنید.'
            ),
            promoFreeAccess: Boolean(ac.promoFreeAccess),
            promoBannerText: String(ac.promoBannerText || ''),
            supportPhone: String(ac.supportPhone || '09999961279'),
            supportTelegram: String(ac.supportTelegram || ''),
            featurePoliciesJson: ac.featurePolicies || {
              terminal: 'PRO',
              analysis: 'PRO',
              bots: 'PRO',
              telegram: 'PRO',
              watchers: 'PRO',
              alerts: 'FREE',
              pnlCalculator: 'FREE',
            },
            updatedAt: Number(cfg.updatedAt || ac.updatedAt || Date.now()),
          })
          .onConflictDoNothing();
      }
      migratedBilling = true;
    }

    if (hasVault) {
      const parsed = JSON.parse(fs.readFileSync(vaultFile, 'utf-8')) as {
        appKeys?: any[];
        exchangeCreds?: any[];
      };
      for (const k of parsed.appKeys || []) {
        if (!k?.id || !k?.userId || !k?.keyHash) continue;
        if (!fallbackOwnerUid) fallbackOwnerUid = String(k.userId);
        await ensureTxUser(String(k.userId));
        await tx
          .insert(schema.appApiKeys)
          .values({
            id: String(k.id),
            userId: String(k.userId),
            label: String(k.label || 'API Key'),
            keyPrefix: String(k.keyPrefix || ''),
            keyHash: String(k.keyHash),
            scopesJson: Array.isArray(k.scopes) ? k.scopes : ['market:read'],
            status: String(k.status || 'ACTIVE'),
            createdAt: Number(k.createdAt || Date.now()),
            revokedAt: k.revokedAt ?? null,
            lastUsedAt: k.lastUsedAt ?? null,
          })
          .onConflictDoNothing();
        counts.appApiKeys += 1;
      }
      for (const c of parsed.exchangeCreds || []) {
        if (!c?.id || !c?.userId || !c?.encryptedToken) continue;
        if (!fallbackOwnerUid) fallbackOwnerUid = String(c.userId);
        await ensureTxUser(String(c.userId));
        await tx
          .insert(schema.exchangeCredentials)
          .values({
            id: String(c.id),
            userId: String(c.userId),
            label: String(c.label || 'حساب نوبیتکس'),
            maskedApiKey: String(c.maskedApiKey || ''),
            keyId: String(c.keyId || 'v1'),
            encryptedToken: String(c.encryptedToken),
            iv: String(c.iv),
            authTag: String(c.authTag),
            status: String(c.status || 'ACTIVE'),
            lastVerifiedAt: c.lastVerifiedAt ?? null,
            createdAt: Number(c.createdAt || Date.now()),
            revokedAt: c.revokedAt ?? null,
          })
          .onConflictDoNothing();
        counts.exchangeCredentials += 1;
      }
      migratedVault = true;
    }

    if (hasState) {
      const parsed = JSON.parse(fs.readFileSync(stateFile, 'utf-8')) as {
        bots?: any[];
        botLogs?: any[];
        logs?: any[];
        orders?: any[];
        trades?: any[];
        paperBalances?: Record<string, number> | any[];
        alerts?: any[];
        watchers?: any[];
        notifications?: any[];
        ideas?: any[];
        telegram?: any;
      };

      if (!fallbackOwnerUid) {
        const firstUser = await tx.select({ uid: schema.users.uid }).from(schema.users).limit(1);
        fallbackOwnerUid = firstUser[0]?.uid || 'legacy-owner';
      }
      const resolveOwner = async (candidate?: string | null) => {
        const uid = String(candidate || fallbackOwnerUid).trim() || 'legacy-owner';
        await ensureTxUser(uid);
        return uid;
      };

      for (const b of parsed.bots || []) {
        if (!b?.id) continue;
        const ownerUid = await resolveOwner(b.ownerId || b.userId);
        const now = Date.now();
        await tx
          .insert(schema.tradingBots)
          .values({
            id: String(b.id),
            userId: ownerUid,
            name: String(b.name || 'ربات انتقال‌یافته'),
            baseAsset: String(b.baseAsset || 'BTC').toUpperCase(),
            quoteCurrency: b.quoteCurrency === 'USDT' ? 'USDT' : 'IRT',
            symbol: String(b.symbol || `${String(b.baseAsset || 'BTC').toUpperCase()}IRT`),
            timeframe: String(b.timeframe || '15m'),
            mode: b.mode === 'live' ? 'live' : 'paper',
            status: b.status === 'RUNNING' ? 'RUNNING' : 'PAUSED',
            orderAmount: Number(b.orderAmount || 100),
            activePositionJson: b.activePosition ?? null,
            statsJson: b.stats || {
              totalTrades: 0,
              winningTrades: 0,
              losingTrades: 0,
              realizedPnl: 0,
            },
            lastCheckedAt: b.lastCheckedAt ?? null,
            lastSignalSummary: String(b.lastSignalSummary || ''),
            notifyTelegram: b.notifyTelegram !== false,
            consecutiveFailures: 0,
            nextRetryAt: null,
            lastError: null,
            createdAt: Number(b.createdAt || now),
            updatedAt: Number(b.updatedAt || now),
          })
          .onConflictDoNothing();

        await tx
          .insert(schema.botConfigurations)
          .values({
            botId: String(b.id),
            userId: ownerUid,
            stopLossPercent: Number(b.stopLossPercent ?? 2.5),
            takeProfitPercent: Number(b.takeProfitPercent ?? 5),
            trailingStopEnabled: Boolean(b.trailingStopEnabled),
            trailingStopPercent: Number(b.trailingStopPercent ?? 1.5),
            cooldownMinutes: Number(b.cooldownMinutes ?? 15),
            logicOperator: b.logicOperator === 'OR' ? 'OR' : 'AND',
            entryRulesJson: Array.isArray(b.entryRules) ? b.entryRules : [],
            exitRulesJson: Array.isArray(b.exitRules) ? b.exitRules : [],
            updatedAt: Number(b.updatedAt || now),
          })
          .onConflictDoNothing();
        counts.bots += 1;
      }

      for (const o of parsed.orders || []) {
        if (!o?.orderId) continue;
        const ownerUid = await resolveOwner(o.ownerId || o.userId);
        await tx
          .insert(schema.orders)
          .values({
            orderId: String(o.orderId),
            userId: ownerUid,
            botId: o.botId || null,
            exchangeOrderId: o.exchangeOrderId || null,
            idempotencyKey: o.idempotencyKey || null,
            symbol: String(o.symbol || 'BTCIRT'),
            baseAsset: String(o.baseAsset || 'BTC'),
            quoteCurrency: o.quoteCurrency === 'USDT' ? 'USDT' : 'IRT',
            side: o.side === 'SELL' ? 'SELL' : 'BUY',
            type: o.type === 'LIMIT' ? 'LIMIT' : 'MARKET',
            price: Number(o.price || 0),
            quantity: Number(o.quantity || 0),
            executedQty: Number(o.executedQty ?? o.quantity ?? 0),
            totalQuoteAmount: Number(o.totalQuoteAmount ?? Number(o.price || 0) * Number(o.quantity || 0)),
            feeAmount: Number(o.feeAmount || 0),
            status: String(o.status || 'FILLED'),
            stopLossPrice: o.stopLossPrice ?? null,
            takeProfitPrice: o.takeProfitPrice ?? null,
            mode: o.mode === 'live' ? 'live' : 'paper',
            source: String(o.source || 'MANUAL'),
            createdAt: Number(o.createdAt || Date.now()),
            updatedAt: Number(o.updatedAt || Date.now()),
          })
          .onConflictDoNothing();
        counts.orders += 1;
      }

      for (const t of parsed.trades || []) {
        if (!t?.id) continue;
        const ownerUid = await resolveOwner(t.ownerId || t.userId);
        await tx
          .insert(schema.trades)
          .values({
            id: String(t.id),
            userId: ownerUid,
            orderId: String(t.orderId || t.id),
            botId: t.botId || null,
            symbol: String(t.symbol || 'BTCIRT'),
            baseAsset: String(t.baseAsset || 'BTC'),
            quoteCurrency: t.quoteCurrency === 'USDT' ? 'USDT' : 'IRT',
            side: t.side === 'SELL' ? 'SELL' : 'BUY',
            price: Number(t.price || 0),
            quantity: Number(t.quantity || 0),
            quoteAmount: Number(t.quoteAmount || 0),
            feeAmount: Number(t.feeAmount || 0),
            realizedPnlQuote: t.realizedPnlQuote ?? null,
            mode: t.mode === 'live' ? 'live' : 'paper',
            executedAt: Number(t.executedAt || Date.now()),
          })
          .onConflictDoNothing();
        counts.trades += 1;
      }

      for (const l of parsed.botLogs || parsed.logs || []) {
        if (!l?.id || !l?.botId) continue;
        const ownerUid = await resolveOwner(l.ownerId || l.userId);
        await tx
          .insert(schema.tradingLogs)
          .values({
            id: String(l.id),
            userId: ownerUid,
            botId: String(l.botId),
            botName: String(l.botName || ''),
            symbol: String(l.symbol || 'BTCIRT'),
            quoteCurrency: l.quoteCurrency === 'USDT' ? 'USDT' : 'IRT',
            event: String(l.event || 'INFO'),
            price: Number(l.price || 0),
            quantity: l.quantity ?? null,
            pnlQuote: l.pnlQuote ?? null,
            message: String(l.message || ''),
            mode: l.mode === 'live' ? 'live' : 'paper',
            timestamp: Number(l.timestamp || Date.now()),
          })
          .onConflictDoNothing();
      }

      if (parsed.paperBalances && !Array.isArray(parsed.paperBalances)) {
        const ownerUid = await resolveOwner(undefined);
        const now = Date.now();
        for (const [asset, bal] of Object.entries(parsed.paperBalances)) {
          if (!Number.isFinite(Number(bal))) continue;
          await tx
            .insert(schema.paperTradingBalances)
            .values({
              userId: ownerUid,
              asset: asset.toUpperCase(),
              balance: Number(bal),
              updatedAt: now,
            })
            .onConflictDoNothing();
          counts.balances += 1;
        }
      } else if (Array.isArray(parsed.paperBalances)) {
        for (const pb of parsed.paperBalances) {
          if (!pb?.asset || !Number.isFinite(Number(pb.balance))) continue;
          const ownerUid = await resolveOwner(pb.userId || pb.ownerId);
          await tx
            .insert(schema.paperTradingBalances)
            .values({
              userId: ownerUid,
              asset: String(pb.asset).toUpperCase(),
              balance: Number(pb.balance),
              updatedAt: Number(pb.updatedAt || Date.now()),
            })
            .onConflictDoNothing();
          counts.balances += 1;
        }
      }

      for (const a of parsed.alerts || []) {
        if (!a?.id) continue;
        const ownerUid = await resolveOwner(a.ownerId || a.userId);
        await tx
          .insert(schema.priceAlerts)
          .values({
            id: String(a.id),
            userId: ownerUid,
            baseAsset: String(a.baseAsset || 'BTC'),
            persianName: String(a.persianName || a.baseAsset || 'BTC'),
            quoteCurrency: a.quoteCurrency === 'USDT' ? 'USDT' : 'IRT',
            symbol: String(a.symbol || 'BTCIRT'),
            condition: a.condition === 'BELOW' ? 'BELOW' : 'ABOVE',
            targetPrice: Number(a.targetPrice || 0),
            createdPrice: Number(a.createdPrice || 0),
            status: String(a.status || 'ACTIVE'),
            sendTelegram: a.sendTelegram !== false,
            note: a.note || null,
            createdAt: Number(a.createdAt || Date.now()),
            triggeredAt: a.triggeredAt ?? null,
            triggeredPrice: a.triggeredPrice ?? null,
          })
          .onConflictDoNothing();
        counts.alerts += 1;
      }

      for (const w of parsed.watchers || []) {
        if (!w?.id) continue;
        const ownerUid = await resolveOwner(w.ownerId || w.userId);
        await tx
          .insert(schema.priceWatchers)
          .values({
            id: String(w.id),
            userId: ownerUid,
            baseAsset: String(w.baseAsset || 'BTC'),
            persianName: String(w.persianName || w.baseAsset || 'BTC'),
            quoteMode: String(w.quoteMode || 'BOTH'),
            intervalMinutes: Number(w.intervalMinutes || 15),
            status: String(w.status || 'ACTIVE'),
            notifyBrowser: w.notifyBrowser !== false,
            playSound: w.playSound !== false,
            sendTelegram: w.sendTelegram !== false,
            webhookUrl: w.webhookUrl || null,
            lastPriceToman: w.lastPriceToman ?? null,
            lastPriceUsdt: w.lastPriceUsdt ?? null,
            lastChange24h: w.lastChange24h ?? null,
            sentCount: Number(w.sentCount || 0),
            createdAt: Number(w.createdAt || Date.now()),
            lastSentAt: w.lastSentAt ?? null,
            nextSendAt: Number(w.nextSendAt || Date.now()),
          })
          .onConflictDoNothing();
        counts.watchers += 1;
      }

      if (parsed.telegram && typeof parsed.telegram === 'object' && parsed.telegram.botToken) {
        const tg = parsed.telegram;
        const ownerUid = await resolveOwner(tg.userId || tg.ownerId);
        const enc = encryptLegacyToken(String(tg.botToken));
        const rawTok = String(tg.botToken);
        await tx
          .insert(schema.telegramConfigurations)
          .values({
            userId: ownerUid,
            keyId: enc.keyId,
            encryptedBotToken: enc.encrypted,
            iv: enc.iv,
            authTag: enc.authTag,
            maskedBotToken: `${rawTok.slice(0, 8)}••••${rawTok.slice(-4)}`,
            botUsername: String(tg.botUsername || ''),
            botFirstName: String(tg.botFirstName || ''),
            chatId: String(tg.chatId || ''),
            enabled: tg.enabled !== false,
            sendPriceAlerts: tg.sendPriceAlerts !== false,
            sendPeriodicWatchers: tg.sendPeriodicWatchers !== false,
            sendTradeReports: tg.sendTradeReports !== false,
            sendBotTrades: tg.sendBotTrades !== false,
            sendBotMonitoring: tg.sendBotMonitoring !== false,
            botMonitorMode: String(tg.botMonitorMode || 'EVENTS_AND_STATUS'),
            botMonitorIntervalMinutes: Number(tg.botMonitorIntervalMinutes || 15),
            updatedAt: Number(tg.updatedAt || Date.now()),
          })
          .onConflictDoNothing();
      }

      migratedState = true;
    }

    await (tx as any).execute(
      sql`INSERT INTO _app_migrations (id, applied_at) VALUES ('legacy_json_v1', ${Date.now()}) ON CONFLICT DO NOTHING`
    );
  });

  logger.info('db.legacy_json_migrated', {
    migratedBilling,
    migratedVault,
    migratedState,
    counts,
  });

  return {
    skipped: false,
    migratedBilling,
    migratedVault,
    migratedState,
    counts,
  };
}

async function migrateLegacyJsonFilesIfNeeded(): Promise<void> {
  try {
    await migrateLegacyJsonFiles();
  } catch (err) {
    logger.warn('db.legacy_migration_skipped', { error: err });
  }
}
