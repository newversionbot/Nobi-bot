const SENSITIVE_KEY_RE =
  /^(api[-_]?token|api[-_]?key|secret[-_]?key|private[-_]?key|nobitex[-_]?key|nobitex[-_]?signature|bot[-_]?token|merchant[-_]?id|password|secret|authorization|x-app-apikey|encrypted[-_]?token|iv|auth[-_]?tag|key[-_]?hash|raw[-_]?key|vault[-_]?master[-_]?key|service[-_]?account)$/i;

export function redactSensitiveText(input: string): string {
  if (!input) return input;
  return input
    .replace(/bot\d{5,}:[A-Za-z0-9_-]{12,}/g, 'bot***REDACTED***')
    .replace(/tbx_live_[a-zA-Z0-9]+/g, 'tbx_live_***REDACTED***')
    .replace(/Token\s+[A-Za-z0-9._-]{12,}/gi, 'Token ***REDACTED***')
    .replace(/Bearer\s+[A-Za-z0-9._-]{20,}/gi, 'Bearer ***REDACTED***')
    .replace(/Nobitex-(Key|Signature)\s*[:=]\s*[A-Za-z0-9_+=/:-]{8,}/gi, 'Nobitex-$1: ***REDACTED***');
}

export function sanitizeForLog(value: unknown, depth = 0): unknown {
  if (depth > 4) return '[MaxDepth]';
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') return redactSensitiveText(value.slice(0, 600));
  if (typeof value === 'number' || typeof value === 'boolean') return value;
  if (value instanceof Error) {
    return {
      name: value.name,
      message: redactSensitiveText(value.message),
    };
  }
  if (Array.isArray(value)) {
    return value.slice(0, 20).map((item) => sanitizeForLog(item, depth + 1));
  }
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (SENSITIVE_KEY_RE.test(k)) {
        out[k] = '[REDACTED]';
      } else {
        out[k] = sanitizeForLog(v, depth + 1);
      }
    }
    return out;
  }
  return String(value);
}

export type LogLevel = 'debug' | 'info' | 'warn' | 'error' | 'silent';

const LEVEL_RANK: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warn: 30,
  error: 40,
  silent: 99,
};

function currentMinLevel(): LogLevel {
  const envLevel = (process.env.LOG_LEVEL || '').toLowerCase() as LogLevel;
  if (envLevel in LEVEL_RANK) return envLevel;
  if (process.env.NODE_ENV === 'test') return 'silent';
  return 'info';
}

function writeLog(level: Exclude<LogLevel, 'silent'>, event: string, meta?: Record<string, unknown>) {
  if (LEVEL_RANK[level] < LEVEL_RANK[currentMinLevel()]) return;
  const payload = {
    ts: new Date().toISOString(),
    level,
    event,
    ...(meta ? (sanitizeForLog(meta) as Record<string, unknown>) : {}),
  };

  const line = JSON.stringify(payload);
  if (level === 'error') {
    console.error(line);
  } else if (level === 'warn') {
    console.warn(line);
  } else {
    console.log(line);
  }
}

export const logger = {
  debug: (event: string, meta?: Record<string, unknown>) => writeLog('debug', event, meta),
  info: (event: string, meta?: Record<string, unknown>) => writeLog('info', event, meta),
  warn: (event: string, meta?: Record<string, unknown>) => writeLog('warn', event, meta),
  error: (event: string, meta?: Record<string, unknown>) => writeLog('error', event, meta),
};
