import 'dotenv/config';
import { appConfig } from './config.ts';
import { closeDatabase, initDatabase } from './db/index.ts';
import { logger } from './logger.ts';
import { runAllActiveBotsCycle, startBotLoop, stopBotLoop } from './botEngine.ts';

async function main() {
  logger.info('worker.starting', { pollMs: appConfig.WORKER_POLL_MS });
  await initDatabase();

  // Run one immediate cycle before scheduling interval
  await runAllActiveBotsCycle().catch((err) => {
    logger.warn('worker.initial_cycle_error', { error: err });
  });

  startBotLoop(appConfig.WORKER_POLL_MS);
  logger.info('worker.ready', { pollMs: appConfig.WORKER_POLL_MS });

  const shutdown = async (signal: string) => {
    logger.info('worker.shutting_down', { signal });
    stopBotLoop();
    await closeDatabase().catch(() => {});
    process.exit(0);
  };

  process.on('SIGINT', () => void shutdown('SIGINT'));
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
}

main().catch((err) => {
  logger.error('worker.fatal_startup', { error: err });
  process.exit(1);
});
