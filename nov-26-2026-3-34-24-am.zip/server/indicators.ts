import type {
  BacktestResult,
  BacktestTrade,
  BotStrategyConfig,
  DcaStepUnit,
  DcaTriggerMode,
  GridStepMode,
  IndicatorSnapshot,
  KlineCandle,
  QuoteCurrency,
  StrategyRule,
  TakeProfitTarget,
  Timeframe,
} from '../src/types/trading.ts';

export function computeSMA(values: number[], period: number): (number | null)[] {
  const out: (number | null)[] = new Array(values.length).fill(null);
  if (period <= 0 || values.length < period) return out;
  let sum = 0;
  for (let i = 0; i < values.length; i++) {
    sum += values[i];
    if (i >= period) {
      sum -= values[i - period];
    }
    if (i >= period - 1) {
      out[i] = sum / period;
    }
  }
  return out;
}

export function computeEMA(values: number[], period: number): (number | null)[] {
  const out: (number | null)[] = new Array(values.length).fill(null);
  if (period <= 0 || values.length < period) return out;

  let initialSum = 0;
  for (let i = 0; i < period; i++) {
    initialSum += values[i];
  }
  let prevEma = initialSum / period;
  out[period - 1] = prevEma;

  const k = 2 / (period + 1);
  for (let i = period; i < values.length; i++) {
    prevEma = values[i] * k + prevEma * (1 - k);
    out[i] = prevEma;
  }
  return out;
}

export function computeRSI(closes: number[], period = 14): (number | null)[] {
  const out: (number | null)[] = new Array(closes.length).fill(null);
  if (closes.length <= period) return out;

  let avgGain = 0;
  let avgLoss = 0;
  for (let i = 1; i <= period; i++) {
    const diff = closes[i] - closes[i - 1];
    if (diff >= 0) avgGain += diff;
    else avgLoss += Math.abs(diff);
  }
  avgGain /= period;
  avgLoss /= period;

  out[period] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);

  for (let i = period + 1; i < closes.length; i++) {
    const diff = closes[i] - closes[i - 1];
    const gain = diff > 0 ? diff : 0;
    const loss = diff < 0 ? Math.abs(diff) : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
    out[i] = avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss);
  }
  return out;
}

export function computeMACD(
  closes: number[],
  fast = 12,
  slow = 26,
  signalPeriod = 9
): {
  macdLine: (number | null)[];
  signalLine: (number | null)[];
  histogram: (number | null)[];
} {
  const emaFast = computeEMA(closes, fast);
  const emaSlow = computeEMA(closes, slow);
  const macdLine: (number | null)[] = closes.map((_, i) => {
    const f = emaFast[i];
    const s = emaSlow[i];
    return f !== null && s !== null ? f - s : null;
  });

  const validStart = macdLine.findIndex((v) => v !== null);
  const signalLine: (number | null)[] = new Array(closes.length).fill(null);
  const histogram: (number | null)[] = new Array(closes.length).fill(null);

  if (validStart !== -1) {
    const validSlice = macdLine.slice(validStart).map((v) => v ?? 0);
    const sigSlice = computeEMA(validSlice, signalPeriod);
    for (let i = 0; i < sigSlice.length; i++) {
      const idx = validStart + i;
      signalLine[idx] = sigSlice[i];
      if (macdLine[idx] !== null && sigSlice[i] !== null) {
        histogram[idx] = (macdLine[idx] as number) - (sigSlice[i] as number);
      }
    }
  }

  return { macdLine, signalLine, histogram };
}

export function computeBollinger(
  closes: number[],
  period = 20,
  stdMult = 2
): {
  upper: (number | null)[];
  middle: (number | null)[];
  lower: (number | null)[];
} {
  const middle = computeSMA(closes, period);
  const upper: (number | null)[] = new Array(closes.length).fill(null);
  const lower: (number | null)[] = new Array(closes.length).fill(null);

  for (let i = period - 1; i < closes.length; i++) {
    const mean = middle[i];
    if (mean === null) continue;
    let sqSum = 0;
    for (let j = i - period + 1; j <= i; j++) {
      const d = closes[j] - mean;
      sqSum += d * d;
    }
    const std = Math.sqrt(sqSum / period);
    upper[i] = mean + std * stdMult;
    lower[i] = mean - std * stdMult;
  }

  return { upper, middle, lower };
}

export function computeATR(candles: KlineCandle[], period = 14): (number | null)[] {
  const out: (number | null)[] = new Array(candles.length).fill(null);
  if (candles.length <= period) return out;

  const trs: number[] = [candles[0].high - candles[0].low];
  for (let i = 1; i < candles.length; i++) {
    const c = candles[i];
    const prevClose = candles[i - 1].close;
    const tr = Math.max(
      c.high - c.low,
      Math.abs(c.high - prevClose),
      Math.abs(c.low - prevClose)
    );
    trs.push(tr);
  }

  let sum = 0;
  for (let i = 1; i <= period; i++) sum += trs[i];
  let atr = sum / period;
  out[period] = atr;

  for (let i = period + 1; i < candles.length; i++) {
    atr = (atr * (period - 1) + trs[i]) / period;
    out[i] = atr;
  }
  return out;
}

export function computeStochastic(
  candles: KlineCandle[],
  kPeriod = 14,
  dPeriod = 3
): { k: number; d: number } {
  if (candles.length < kPeriod + dPeriod) {
    return { k: 50, d: 50 };
  }
  const kSeries: number[] = [];
  for (let i = kPeriod - 1; i < candles.length; i++) {
    let highest = -Infinity;
    let lowest = Infinity;
    for (let j = i - kPeriod + 1; j <= i; j++) {
      if (candles[j].high > highest) highest = candles[j].high;
      if (candles[j].low < lowest) lowest = candles[j].low;
    }
    const denom = highest - lowest;
    const kVal = denom === 0 ? 50 : ((candles[i].close - lowest) / denom) * 100;
    kSeries.push(kVal);
  }
  const latestK = kSeries[kSeries.length - 1] ?? 50;
  const recentD = kSeries.slice(-dPeriod);
  const latestD =
    recentD.length > 0 ? recentD.reduce((acc, v) => acc + v, 0) / recentD.length : 50;
  return { k: latestK, d: latestD };
}

export function analyzeCandles(
  symbol: string,
  timeframe: Timeframe,
  candles: KlineCandle[]
): IndicatorSnapshot {
  const closes = candles.map((c) => c.close);
  const volumes = candles.map((c) => c.volume);
  const lastIdx = candles.length - 1;
  const price = closes[lastIdx] || 0;

  const rsiSeries = computeRSI(closes, 14);
  const ema9Series = computeEMA(closes, 9);
  const ema20Series = computeEMA(closes, 20);
  const ema50Series = computeEMA(closes, 50);
  const ema200Series = computeEMA(closes, 200);
  const sma20Series = computeSMA(closes, 20);
  const macd = computeMACD(closes, 12, 26, 9);
  const bb = computeBollinger(closes, 20, 2);
  const atrSeries = computeATR(candles, 14);
  const stoch = computeStochastic(candles, 14, 3);

  const rsi14 = rsiSeries[lastIdx] ?? 50;
  const ema9 = ema9Series[lastIdx] ?? price;
  const ema20 = ema20Series[lastIdx] ?? price;
  const ema50 = ema50Series[lastIdx] ?? price;
  const ema200 = ema200Series[lastIdx] ?? ema50;
  const sma20 = sma20Series[lastIdx] ?? price;
  const macdLine = macd.macdLine[lastIdx] ?? 0;
  const signalLine = macd.signalLine[lastIdx] ?? 0;
  const histogram = macd.histogram[lastIdx] ?? 0;
  const bbUpper = bb.upper[lastIdx] ?? price * 1.02;
  const bbMiddle = bb.middle[lastIdx] ?? price;
  const bbLower = bb.lower[lastIdx] ?? price * 0.98;
  const atr14 = atrSeries[lastIdx] ?? price * 0.015;

  const avgVolSlice = volumes.slice(Math.max(0, lastIdx - 20), lastIdx);
  const avgVol =
    avgVolSlice.length > 0
      ? avgVolSlice.reduce((a, b) => a + b, 0) / avgVolSlice.length
      : volumes[lastIdx] || 1;
  const volumeRatio = avgVol > 0 ? (volumes[lastIdx] || 0) / avgVol : 1;

  // Classic Pivot Points using previous candle or recent 24-bar high/low/close
  const refWindow = candles.slice(Math.max(0, lastIdx - 24), lastIdx);
  const refHigh = refWindow.length > 0 ? Math.max(...refWindow.map((c) => c.high)) : price;
  const refLow = refWindow.length > 0 ? Math.min(...refWindow.map((c) => c.low)) : price;
  const refClose = candles[Math.max(0, lastIdx - 1)]?.close ?? price;
  const pivot = (refHigh + refLow + refClose) / 3;
  const r1 = 2 * pivot - refLow;
  const s1 = 2 * pivot - refHigh;
  const r2 = pivot + (refHigh - refLow);
  const s2 = pivot - (refHigh - refLow);
  const r3 = refHigh + 2 * (pivot - refLow);
  const s3 = refLow - 2 * (refHigh - pivot);

  // Signal consensus
  let buyCount = 0;
  let sellCount = 0;
  let neutralCount = 0;
  const reasons: string[] = [];

  if (rsi14 <= 35) {
    buyCount++;
    reasons.push(`شاخص RSI در محدوده اشباع فروش (${rsi14.toFixed(1)}) قرار دارد.`);
  } else if (rsi14 >= 65) {
    sellCount++;
    reasons.push(`شاخص RSI در محدوده اشباع خرید (${rsi14.toFixed(1)}) قرار دارد.`);
  } else {
    neutralCount++;
  }

  if (macdLine > signalLine && histogram > 0) {
    buyCount++;
    reasons.push('هیستوگرام مکدی (MACD) مثبت و بالاتر از خط سیگنال است.');
  } else if (macdLine < signalLine && histogram < 0) {
    sellCount++;
    reasons.push('خط مکدی پایین‌تر از خط سیگنال با مومنتوم نزولی قرار دارد.');
  } else {
    neutralCount++;
  }

  if (price > ema20 && ema20 > ema50) {
    buyCount++;
    reasons.push('قیمت بالای EMA20 و آرایش میانگین‌های متحرک صعودی است.');
  } else if (price < ema20 && ema20 < ema50) {
    sellCount++;
    reasons.push('قیمت زیر EMA20 و روند میانگین‌های متحرک نزولی است.');
  } else {
    neutralCount++;
  }

  if (ema9 > ema20) {
    buyCount++;
  } else if (ema9 < ema20) {
    sellCount++;
  } else {
    neutralCount++;
  }

  if (price <= bbLower * 1.003) {
    buyCount++;
    reasons.push('قیمت در تماس با باند پایینی بولینگر (حمایت نوسانی) است.');
  } else if (price >= bbUpper * 0.997) {
    sellCount++;
    reasons.push('قیمت به باند بالایی بولینگر (مقاومت نوسانی) رسیده است.');
  } else {
    neutralCount++;
  }

  if (stoch.k < 25 && stoch.k > stoch.d) {
    buyCount++;
  } else if (stoch.k > 75 && stoch.k < stoch.d) {
    sellCount++;
  } else {
    neutralCount++;
  }

  const netScore = buyCount - sellCount;
  let action: IndicatorSnapshot['signal']['action'] = 'NEUTRAL';
  let labelFa = 'خنثی (انتظار)';
  if (netScore >= 3) {
    action = 'STRONG_BUY';
    labelFa = 'خرید قوی';
  } else if (netScore >= 1) {
    action = 'BUY';
    labelFa = 'متمایل به خرید';
  } else if (netScore <= -3) {
    action = 'STRONG_SELL';
    labelFa = 'فروش قوی';
  } else if (netScore <= -1) {
    action = 'SELL';
    labelFa = 'متمایل به فروش';
  }

  if (reasons.length === 0) {
    reasons.push('بازار در وضعیت تعادل قرار دارد و اندیکاتورها همگرایی جهت‌دار نشان نمی‌دهند.');
  }

  const bbRange = bbUpper - bbLower;

  return {
    symbol,
    timeframe,
    price,
    timestamp: candles[lastIdx]?.openTime || Date.now(),
    rsi14,
    stochK: stoch.k,
    stochD: stoch.d,
    macd: {
      macdLine,
      signalLine,
      histogram,
    },
    ema9,
    ema20,
    ema50,
    ema200,
    sma20,
    bollinger: {
      upper: bbUpper,
      middle: bbMiddle,
      lower: bbLower,
      bandwidthPercent: bbMiddle > 0 ? (bbRange / bbMiddle) * 100 : 0,
      percentB: bbRange > 0 ? ((price - bbLower) / bbRange) * 100 : 50,
    },
    atr14,
    volumeRatio,
    pivots: { pivot, r1, r2, r3, s1, s2, s3 },
    signal: {
      action,
      labelFa,
      buyCount,
      sellCount,
      neutralCount,
      reasons,
    },
    series: {
      ema20: ema20Series,
      ema50: ema50Series,
      bbUpper: bb.upper,
      bbLower: bb.lower,
      rsi: rsiSeries,
      macdLine: macd.macdLine,
      macdSignal: macd.signalLine,
      macdHistogram: macd.histogram,
    },
  };
}

interface PrecomputedSeries {
  closes: number[];
  volumes: number[];
  rsiCache: Map<number, (number | null)[]>;
  emaCache: Map<number, (number | null)[]>;
  macd: ReturnType<typeof computeMACD>;
  bb: ReturnType<typeof computeBollinger>;
}

function buildPrecomputed(candles: KlineCandle[]): PrecomputedSeries {
  const closes = candles.map((c) => c.close);
  const volumes = candles.map((c) => c.volume);
  return {
    closes,
    volumes,
    rsiCache: new Map(),
    emaCache: new Map(),
    macd: computeMACD(closes, 12, 26, 9),
    bb: computeBollinger(closes, 20, 2),
  };
}

function getCachedRSI(pre: PrecomputedSeries, period: number): (number | null)[] {
  let s = pre.rsiCache.get(period);
  if (!s) {
    s = computeRSI(pre.closes, period);
    pre.rsiCache.set(period, s);
  }
  return s;
}

function getCachedEMA(pre: PrecomputedSeries, period: number): (number | null)[] {
  let s = pre.emaCache.get(period);
  if (!s) {
    s = computeEMA(pre.closes, period);
    pre.emaCache.set(period, s);
  }
  return s;
}

export function evaluateSingleRuleAt(
  rule: StrategyRule,
  idx: number,
  candles: KlineCandle[],
  pre: PrecomputedSeries
): { matched: boolean; detail: string } {
  if (!rule.enabled || idx < 2) {
    return { matched: false, detail: '' };
  }

  const close = candles[idx].close;
  const prevClose = candles[idx - 1].close;

  switch (rule.type) {
    case 'RSI_OVERSOLD': {
      const period = rule.params.period || 14;
      const threshold = rule.params.threshold ?? 32;
      const rsi = getCachedRSI(pre, period);
      const curr = rsi[idx];
      if (curr === null) return { matched: false, detail: '' };
      return {
        matched: curr <= threshold,
        detail: `RSI(${period})=${curr.toFixed(1)} <= ${threshold}`,
      };
    }
    case 'RSI_OVERBOUGHT': {
      const period = rule.params.period || 14;
      const threshold = rule.params.threshold ?? 70;
      const rsi = getCachedRSI(pre, period);
      const curr = rsi[idx];
      if (curr === null) return { matched: false, detail: '' };
      return {
        matched: curr >= threshold,
        detail: `RSI(${period})=${curr.toFixed(1)} >= ${threshold}`,
      };
    }
    case 'EMA_GOLDEN_CROSS': {
      const fast = rule.params.fastPeriod || 9;
      const slow = rule.params.slowPeriod || 21;
      const fSeries = getCachedEMA(pre, fast);
      const sSeries = getCachedEMA(pre, slow);
      const fCurr = fSeries[idx];
      const sCurr = sSeries[idx];
      const fPrev = fSeries[idx - 1];
      const sPrev = sSeries[idx - 1];
      if (fCurr === null || sCurr === null || fPrev === null || sPrev === null) {
        return { matched: false, detail: '' };
      }
      const crossed = fPrev <= sPrev && fCurr > sCurr;
      return {
        matched: crossed,
        detail: `EMA(${fast}) عبور صعودی از EMA(${slow})`,
      };
    }
    case 'EMA_DEATH_CROSS': {
      const fast = rule.params.fastPeriod || 9;
      const slow = rule.params.slowPeriod || 21;
      const fSeries = getCachedEMA(pre, fast);
      const sSeries = getCachedEMA(pre, slow);
      const fCurr = fSeries[idx];
      const sCurr = sSeries[idx];
      const fPrev = fSeries[idx - 1];
      const sPrev = sSeries[idx - 1];
      if (fCurr === null || sCurr === null || fPrev === null || sPrev === null) {
        return { matched: false, detail: '' };
      }
      const crossed = fPrev >= sPrev && fCurr < sCurr;
      return {
        matched: crossed,
        detail: `EMA(${fast}) عبور نزولی از EMA(${slow})`,
      };
    }
    case 'MACD_BULLISH_CROSS': {
      const mCurr = pre.macd.macdLine[idx];
      const sigCurr = pre.macd.signalLine[idx];
      const mPrev = pre.macd.macdLine[idx - 1];
      const sigPrev = pre.macd.signalLine[idx - 1];
      if (mCurr === null || sigCurr === null || mPrev === null || sigPrev === null) {
        return { matched: false, detail: '' };
      }
      const crossed = mPrev <= sigPrev && mCurr > sigCurr;
      return { matched: crossed, detail: 'کراس صعودی MACD' };
    }
    case 'MACD_BEARISH_CROSS': {
      const mCurr = pre.macd.macdLine[idx];
      const sigCurr = pre.macd.signalLine[idx];
      const mPrev = pre.macd.macdLine[idx - 1];
      const sigPrev = pre.macd.signalLine[idx - 1];
      if (mCurr === null || sigCurr === null || mPrev === null || sigPrev === null) {
        return { matched: false, detail: '' };
      }
      const crossed = mPrev >= sigPrev && mCurr < sigCurr;
      return { matched: crossed, detail: 'کراس نزولی MACD' };
    }
    case 'BB_LOWER_TOUCH': {
      const lower = pre.bb.lower[idx];
      if (lower === null) return { matched: false, detail: '' };
      const touched = close <= lower * 1.002 || (prevClose <= lower && close > lower);
      return { matched: touched, detail: `برخورد به باند پایین بولینگر` };
    }
    case 'BB_UPPER_TOUCH': {
      const upper = pre.bb.upper[idx];
      if (upper === null) return { matched: false, detail: '' };
      const touched = close >= upper * 0.998;
      return { matched: touched, detail: `برخورد به باند بالای بولینگر` };
    }
    case 'VOLUME_SPIKE': {
      const mult = rule.params.multiplier || 1.6;
      const start = Math.max(0, idx - 20);
      const slice = pre.volumes.slice(start, idx);
      if (slice.length === 0) return { matched: false, detail: '' };
      const avg = slice.reduce((a, b) => a + b, 0) / slice.length;
      const ratio = avg > 0 ? pre.volumes[idx] / avg : 1;
      return {
        matched: ratio >= mult,
        detail: `جهش حجم (${ratio.toFixed(1)}x)`,
      };
    }
    case 'BREAKOUT_RESISTANCE': {
      const lookback = Math.max(5, Math.min(60, rule.params.lookbackBars || rule.params.period || 20));
      const mult = rule.params.multiplier ?? 1.15;
      if (idx < lookback + 1) return { matched: false, detail: '' };
      let resistance = 0;
      for (let k = idx - lookback; k < idx; k++) {
        if (candles[k].high > resistance) resistance = candles[k].high;
      }
      const volSlice = pre.volumes.slice(Math.max(0, idx - 20), idx);
      const avgVol = volSlice.length > 0 ? volSlice.reduce((a, b) => a + b, 0) / volSlice.length : 0;
      const volRatio = avgVol > 0 ? pre.volumes[idx] / avgVol : 1;
      const broke = resistance > 0 && close > resistance * 1.001 && prevClose <= resistance * 1.002;
      const confirmed = broke && volRatio >= mult;
      return {
        matched: confirmed,
        detail: `شکست مقاومت ${lookback} کندلی با حجم ${volRatio.toFixed(1)}x`,
      };
    }
    case 'BREAKDOWN_SUPPORT': {
      const lookback = Math.max(5, Math.min(60, rule.params.lookbackBars || rule.params.period || 20));
      if (idx < lookback + 1) return { matched: false, detail: '' };
      let support = Number.MAX_VALUE;
      for (let k = idx - lookback; k < idx; k++) {
        if (candles[k].low > 0 && candles[k].low < support) support = candles[k].low;
      }
      const broke = support < Number.MAX_VALUE && close < support * 0.999;
      return {
        matched: broke,
        detail: `شکست حمایت ${lookback} کندلی`,
      };
    }
    case 'TREND_ALIGNMENT': {
      const fast = rule.params.fastPeriod || 20;
      const slow = rule.params.slowPeriod || 50;
      const fSeries = getCachedEMA(pre, fast);
      const sSeries = getCachedEMA(pre, slow);
      const fCurr = fSeries[idx];
      const sCurr = sSeries[idx];
      if (fCurr === null || sCurr === null) return { matched: false, detail: '' };
      const aligned = close > fCurr && fCurr > sCurr;
      return {
        matched: aligned,
        detail: `هم‌راستایی روند صعودی (EMA${fast} > EMA${slow})`,
      };
    }
    case 'VOLATILITY_FILTER': {
      const minAtr = rule.params.minAtrPercent ?? 0.15;
      const maxAtr = rule.params.maxAtrPercent ?? 6.5;
      if (idx < 14 || close <= 0) return { matched: true, detail: '' };
      let trSum = 0;
      for (let k = idx - 13; k <= idx; k++) {
        const cur = candles[k];
        const prev = candles[k - 1];
        const tr = Math.max(
          cur.high - cur.low,
          Math.abs(cur.high - prev.close),
          Math.abs(cur.low - prev.close)
        );
        trSum += tr;
      }
      const atrPct = ((trSum / 14) / close) * 100;
      const healthy = atrPct >= minAtr && atrPct <= maxAtr;
      return {
        matched: healthy,
        detail: healthy
          ? `فیلتر نوسان سالم (ATR ${atrPct.toFixed(2)}٪)`
          : `نوسان خارج از بازه امن (ATR ${atrPct.toFixed(2)}٪)`,
      };
    }
    default:
      return { matched: false, detail: '' };
  }
}

export function evaluateRuleset(
  rules: StrategyRule[],
  logicOperator: 'AND' | 'OR',
  candles: KlineCandle[],
  idx: number,
  pre?: PrecomputedSeries,
  options?: {
    volumeConfirmationEnabled?: boolean;
    minVolumeRatio?: number;
    volatilityFilterEnabled?: boolean;
    volatilityFilterMaxAtrPercent?: number;
    minSignalScore?: number;
  }
): { triggered: boolean; details: string[]; score: number } {
  const activeRules = rules.filter((r) => r.enabled);
  if (activeRules.length === 0) {
    return { triggered: false, details: [], score: 0 };
  }
  const series = pre || buildPrecomputed(candles);
  const results = activeRules.map((r) => evaluateSingleRuleAt(r, idx, candles, series));
  const matchedCount = results.filter((r) => r.matched).length;
  const details = results.filter((r) => r.matched).map((r) => r.detail);
  const score = Math.round((matchedCount / activeRules.length) * 100);

  let triggered =
    logicOperator === 'AND'
      ? results.every((r) => r.matched)
      : results.some((r) => r.matched);

  if (triggered && options?.minSignalScore && score < options.minSignalScore) {
    triggered = false;
  }

  if (triggered && options?.volumeConfirmationEnabled && idx >= 20) {
    const volSlice = series.volumes.slice(Math.max(0, idx - 20), idx);
    const avgVol = volSlice.length > 0 ? volSlice.reduce((a, b) => a + b, 0) / volSlice.length : 0;
    const volRatio = avgVol > 0 ? series.volumes[idx] / avgVol : 1;
    const minRatio = options.minVolumeRatio ?? 1.1;
    if (volRatio < minRatio) {
      triggered = false;
    } else {
      details.push(`تأیید حجم (${volRatio.toFixed(1)}x)`);
    }
  }

  if (triggered && options?.volatilityFilterEnabled && idx >= 14 && candles[idx].close > 0) {
    let trSum = 0;
    for (let k = idx - 13; k <= idx; k++) {
      const cur = candles[k];
      const prev = candles[k - 1];
      trSum += Math.max(
        cur.high - cur.low,
        Math.abs(cur.high - prev.close),
        Math.abs(cur.low - prev.close)
      );
    }
    const atrPct = ((trSum / 14) / candles[idx].close) * 100;
    const maxAtr = options.volatilityFilterMaxAtrPercent ?? 6.5;
    if (atrPct > maxAtr) {
      triggered = false;
    } else {
      details.push(`فیلتر نوسان تایید شد (${atrPct.toFixed(2)}٪)`);
    }
  }

  return { triggered, details, score };
}

export function runStrategyBacktest(
  candles: KlineCandle[],
  config: Pick<
    BotStrategyConfig,
    | 'symbol'
    | 'quoteCurrency'
    | 'timeframe'
    | 'orderAmount'
    | 'stopLossPercent'
    | 'takeProfitPercent'
    | 'trailingStopEnabled'
    | 'trailingStopPercent'
    | 'logicOperator'
    | 'entryRules'
    | 'exitRules'
    | 'takeProfitTargets'
    | 'trailingTakeProfitEnabled'
    | 'trailingTakeProfitActivationPercent'
    | 'trailingTakeProfitCallbackPercent'
    | 'keepRunnerPercent'
    | 'feeRate'
    | 'estimatedSlippagePercent'
    | 'volumeConfirmationEnabled'
    | 'minVolumeRatio'
    | 'volatilityFilterEnabled'
    | 'volatilityFilterMaxAtrPercent'
    | 'minSignalScore'
  >
): BacktestResult {
  const minInitial = config.quoteCurrency === 'IRT' ? 20_000_000 : 1000;
  const initialCapital = Math.max(config.orderAmount * 2, minInitial);
  let capital = initialCapital;
  const feeRate = config.feeRate ?? 0.0025;
  const slippageRate = Math.max(0, Number(config.estimatedSlippagePercent ?? 0.1)) / 100;
  const pre = buildPrecomputed(candles);

  const sortedTargets = [...(config.takeProfitTargets || [])]
    .filter((t) => t.risePercent > 0 && t.sellPercent > 0)
    .sort((a, b) => a.risePercent - b.risePercent);

  let position: {
    entryPrice: number;
    entryTime: number;
    qty: number;
    initialQty: number;
    costRemaining: number;
    highestPrice: number;
    stopLossPrice: number;
    takeProfitPrice: number;
    trailingTpArmed: boolean;
    executedTpIds: Set<string>;
  } | null = null;

  const trades: BacktestTrade[] = [];
  const equityCurve: { time: number; equity: number }[] = [];
  let peakEquity = initialCapital;
  let maxDrawdown = 0;
  let totalFeesPaidQuote = 0;
  let estimatedSlippageQuote = 0;

  const warmup = Math.min(35, Math.floor(candles.length / 4));

  for (let i = warmup; i < candles.length; i++) {
    const candle = candles[i];

    if (position) {
      if (candle.high > position.highestPrice) {
        position.highestPrice = candle.high;
      }

      // Check staged multi-TP partial exits before full exit
      if (sortedTargets.length > 0 && position.qty > 0) {
        for (const tp of sortedTargets) {
          if (position.executedTpIds.has(tp.id)) continue;
          const targetPrice = position.entryPrice * (1 + tp.risePercent / 100);
          if (candle.high >= targetPrice) {
            position.executedTpIds.add(tp.id);
            const desiredQty = position.initialQty * (Math.min(100, tp.sellPercent) / 100);
            const sellQty = Math.min(position.qty, desiredQty);
            if (sellQty > 0) {
              const execPrice = targetPrice * (1 - slippageRate * 0.5);
              const grossProceeds = sellQty * execPrice;
              const fee = grossProceeds * feeRate;
              const slipCost = sellQty * targetPrice - grossProceeds;
              const netProceeds = grossProceeds - fee;
              const proportionalCost = position.costRemaining * (sellQty / position.qty);
              const pnlQuote = netProceeds - proportionalCost;

              totalFeesPaidQuote += fee;
              estimatedSlippageQuote += Math.max(0, slipCost);
              capital += netProceeds;
              position.qty -= sellQty;
              position.costRemaining -= proportionalCost;

              trades.push({
                entryTime: position.entryTime,
                exitTime: candle.openTime,
                entryPrice: position.entryPrice,
                exitPrice: execPrice,
                pnlQuote,
                pnlPercent: proportionalCost > 0 ? (pnlQuote / proportionalCost) * 100 : 0,
                feeQuote: fee,
                slippageQuote: Math.max(0, slipCost),
                exitReason: 'PARTIAL_TP',
              });
            }
          }
        }
        if (position.qty <= 1e-10) {
          position = null;
        }
      }

      if (position) {
        let exitPrice: number | null = null;
        let exitReason: BacktestTrade['exitReason'] | null = null;

        if (config.trailingTakeProfitEnabled && !position.trailingTpArmed) {
          const actPct = config.trailingTakeProfitActivationPercent ?? 3;
          if (candle.high >= position.entryPrice * (1 + actPct / 100)) {
            position.trailingTpArmed = true;
          }
        }

        const runnerFactor =
          Math.max(0, Math.min(50, Number(config.keepRunnerPercent ?? 0))) > 0 ? 1 : 0;

        if (config.stopLossPercent > 0 && candle.low <= position.stopLossPrice) {
          exitPrice = position.stopLossPrice;
          exitReason = 'STOP_LOSS';
        } else if (
          position.trailingTpArmed &&
          (config.trailingTakeProfitCallbackPercent ?? 1.2) > 0 &&
          candle.low <=
            position.highestPrice * (1 - (config.trailingTakeProfitCallbackPercent ?? 1.2) / 100)
        ) {
          exitPrice =
            position.highestPrice * (1 - (config.trailingTakeProfitCallbackPercent ?? 1.2) / 100);
          exitReason = 'TRAILING_TP';
        } else if (
          config.trailingStopEnabled &&
          config.trailingStopPercent > 0 &&
          candle.low <= position.highestPrice * (1 - config.trailingStopPercent / 100)
        ) {
          const trailStop = position.highestPrice * (1 - config.trailingStopPercent / 100);
          if (trailStop > position.stopLossPrice) {
            exitPrice = trailStop;
            exitReason = 'TRAILING_STOP';
          }
        } else if (
          sortedTargets.length === 0 &&
          config.takeProfitPercent > 0 &&
          candle.high >= position.takeProfitPrice
        ) {
          exitPrice = position.takeProfitPrice;
          exitReason = 'TAKE_PROFIT';
        } else {
          const exitEval = evaluateRuleset(config.exitRules, 'OR', candles, i, pre);
          if (exitEval.triggered) {
            exitPrice = candle.close;
            exitReason = 'EXIT_SIGNAL';
          }
        }

        if (exitPrice !== null && exitReason !== null) {
          const execSellPrice = exitPrice * (1 - slippageRate);
          const sellFraction =
            exitReason === 'TAKE_PROFIT' && runnerFactor === 1
              ? 1 - Number(config.keepRunnerPercent ?? 0) / 100
              : 1;
          const sellQty = position.qty * Math.max(0.1, sellFraction);
          const grossProceeds = sellQty * execSellPrice;
          const exitFee = grossProceeds * feeRate;
          const slipCost = sellQty * exitPrice - grossProceeds;
          const netProceeds = grossProceeds - exitFee;
          const costBasis = position.costRemaining * (sellQty / position.qty);
          const pnlQuote = netProceeds - costBasis;
          const pnlPercent = costBasis > 0 ? (pnlQuote / costBasis) * 100 : 0;

          totalFeesPaidQuote += exitFee;
          estimatedSlippageQuote += Math.max(0, slipCost);
          capital += netProceeds;
          trades.push({
            entryTime: position.entryTime,
            exitTime: candle.openTime,
            entryPrice: position.entryPrice,
            exitPrice: execSellPrice,
            pnlQuote,
            pnlPercent,
            feeQuote: exitFee,
            slippageQuote: Math.max(0, slipCost),
            exitReason,
          });
          if (sellQty >= position.qty * 0.999) {
            position = null;
          } else {
            position.qty -= sellQty;
            position.costRemaining -= costBasis;
          }
        }
      }
    } else {
      const entryEval = evaluateRuleset(config.entryRules, config.logicOperator, candles, i, pre, {
        volumeConfirmationEnabled: config.volumeConfirmationEnabled,
        minVolumeRatio: config.minVolumeRatio,
        volatilityFilterEnabled: config.volatilityFilterEnabled,
        volatilityFilterMaxAtrPercent: config.volatilityFilterMaxAtrPercent,
        minSignalScore: config.minSignalScore,
      });
      if (entryEval.triggered && capital >= config.orderAmount && candle.close > 0) {
        const spend = Math.min(config.orderAmount, capital);
        const execEntryPrice = candle.close * (1 + slippageRate);
        const entryFee = spend * feeRate;
        const netSpend = spend - entryFee;
        const qty = netSpend / execEntryPrice;
        totalFeesPaidQuote += entryFee;
        estimatedSlippageQuote += spend - netSpend * (candle.close / execEntryPrice);
        capital -= spend;

        position = {
          entryPrice: execEntryPrice,
          entryTime: candle.openTime,
          qty,
          initialQty: qty,
          costRemaining: spend,
          highestPrice: execEntryPrice,
          stopLossPrice:
            config.stopLossPercent > 0
              ? execEntryPrice * (1 - config.stopLossPercent / 100)
              : 0,
          takeProfitPrice:
            config.takeProfitPercent > 0
              ? execEntryPrice * (1 + config.takeProfitPercent / 100)
              : Number.MAX_SAFE_INTEGER,
          trailingTpArmed: false,
          executedTpIds: new Set<string>(),
        };
      }
    }

    const markToMarket = capital + (position ? position.qty * candle.close : 0);
    if (markToMarket > peakEquity) peakEquity = markToMarket;
    const dd = peakEquity > 0 ? ((peakEquity - markToMarket) / peakEquity) * 100 : 0;
    if (dd > maxDrawdown) maxDrawdown = dd;

    equityCurve.push({
      time: candle.openTime,
      equity: Number(markToMarket.toFixed(config.quoteCurrency === 'IRT' ? 0 : 2)),
    });
  }

  if (position && candles.length > 0) {
    const last = candles[candles.length - 1];
    const gross = position.qty * last.close;
    const fee = gross * feeRate;
    const net = gross - fee;
    const pnlQuote = net - position.costRemaining;
    totalFeesPaidQuote += fee;
    capital += net;
    trades.push({
      entryTime: position.entryTime,
      exitTime: last.openTime,
      entryPrice: position.entryPrice,
      exitPrice: last.close,
      pnlQuote,
      pnlPercent: position.costRemaining > 0 ? (pnlQuote / position.costRemaining) * 100 : 0,
      feeQuote: fee,
      exitReason: 'END_OF_DATA',
    });
  }

  const winning = trades.filter((t) => t.pnlQuote > 0);
  const losing = trades.filter((t) => t.pnlQuote <= 0);
  const grossProfit = winning.reduce((s, t) => s + t.pnlQuote, 0);
  const grossLoss = Math.abs(losing.reduce((s, t) => s + t.pnlQuote, 0));
  const netProfitQuote = capital - initialCapital;
  const dec = config.quoteCurrency === 'IRT' ? 0 : 2;

  return {
    symbol: config.symbol,
    quoteCurrency: config.quoteCurrency,
    timeframe: config.timeframe,
    botType: 'STRATEGY',
    candlesTested: candles.length,
    initialCapital: Number(initialCapital.toFixed(dec)),
    finalCapital: Number(capital.toFixed(dec)),
    netProfitQuote: Number(netProfitQuote.toFixed(dec)),
    netProfitPercent: Number(((netProfitQuote / initialCapital) * 100).toFixed(2)),
    totalFeesPaidQuote: Number(totalFeesPaidQuote.toFixed(dec)),
    estimatedSlippageQuote: Number(estimatedSlippageQuote.toFixed(dec)),
    avgWinQuote: winning.length > 0 ? Number((grossProfit / winning.length).toFixed(dec)) : 0,
    avgLossQuote: losing.length > 0 ? Number((grossLoss / losing.length).toFixed(dec)) : 0,
    totalTrades: trades.length,
    winningTrades: winning.length,
    losingTrades: losing.length,
    winRatePercent:
      trades.length > 0 ? Number(((winning.length / trades.length) * 100).toFixed(1)) : 0,
    maxDrawdownPercent: Number(maxDrawdown.toFixed(2)),
    profitFactor:
      grossLoss > 0 ? Number((grossProfit / grossLoss).toFixed(2)) : grossProfit > 0 ? 9.99 : 0,
    equityCurve,
    trades: trades.slice(-30).reverse(),
  };
}

export function buildGridPriceLevels(
  lowerPrice: number,
  upperPrice: number,
  gridLevels: number,
  stepMode: GridStepMode
): number[] {
  const count = Math.max(2, Math.min(50, Math.round(gridLevels)));
  if (lowerPrice <= 0 || upperPrice <= lowerPrice) return [];
  const prices: number[] = [];
  if (stepMode === 'GEOMETRIC') {
    const ratio = Math.pow(upperPrice / lowerPrice, 1 / (count - 1));
    for (let i = 0; i < count; i++) {
      prices.push(lowerPrice * Math.pow(ratio, i));
    }
  } else {
    const step = (upperPrice - lowerPrice) / (count - 1);
    for (let i = 0; i < count; i++) {
      prices.push(lowerPrice + step * i);
    }
  }
  return prices;
}

export function runGridBacktest(
  candles: KlineCandle[],
  params: {
    symbol: string;
    quoteCurrency: QuoteCurrency;
    timeframe: Timeframe;
    lowerPrice: number;
    upperPrice: number;
    gridLevels: number;
    stepMode: GridStepMode;
    totalCapital: number;
    stopOnBreakout: boolean;
    feeRate?: number;
    estimatedSlippagePercent?: number;
  }
): BacktestResult {
  const levels = buildGridPriceLevels(
    params.lowerPrice,
    params.upperPrice,
    params.gridLevels,
    params.stepMode
  );
  const feeRate = params.feeRate ?? 0.0025;
  const slipRate = Math.max(0, params.estimatedSlippagePercent ?? 0.1) / 100;
  const initialCapital = Math.max(params.totalCapital, 1);
  let quoteCash = initialCapital;
  let totalFees = 0;
  let totalSlip = 0;
  const capitalPerSlot = initialCapital / Math.max(1, levels.length - 1);

  const holdings = new Map<number, { entryPrice: number; entryTime: number; qty: number; cost: number }>();
  const trades: BacktestTrade[] = [];
  const equityCurve: { time: number; equity: number }[] = [];
  let peakEquity = initialCapital;
  let maxDd = 0;
  let stopped = false;

  for (let i = 0; i < candles.length; i++) {
    const c = candles[i];
    if (!stopped) {
      if (params.stopOnBreakout && (c.close < params.lowerPrice * 0.99 || c.close > params.upperPrice * 1.01)) {
        stopped = true;
      } else {
        for (let lv = 0; lv < levels.length - 1; lv++) {
          const buyPx = levels[lv];
          const sellPx = levels[lv + 1];
          const held = holdings.get(lv);

          if (!held && c.low <= buyPx && c.close >= buyPx * 0.985 && quoteCash >= capitalPerSlot) {
            const execBuy = buyPx * (1 + slipRate * 0.4);
            const fee = capitalPerSlot * feeRate;
            const qty = (capitalPerSlot - fee) / execBuy;
            totalFees += fee;
            totalSlip += capitalPerSlot * slipRate * 0.4;
            quoteCash -= capitalPerSlot;
            holdings.set(lv, {
              entryPrice: execBuy,
              entryTime: c.openTime,
              qty,
              cost: capitalPerSlot,
            });
          } else if (held && c.high >= sellPx) {
            const execSell = sellPx * (1 - slipRate * 0.4);
            const gross = held.qty * execSell;
            const fee = gross * feeRate;
            const net = gross - fee;
            const pnlQuote = net - held.cost;
            totalFees += fee;
            totalSlip += gross * slipRate * 0.4;
            quoteCash += net;
            holdings.delete(lv);
            trades.push({
              entryTime: held.entryTime,
              exitTime: c.openTime,
              entryPrice: held.entryPrice,
              exitPrice: execSell,
              pnlQuote,
              pnlPercent: (pnlQuote / held.cost) * 100,
              feeQuote: fee,
              exitReason: 'GRID_CYCLE',
            });
          }
        }
      }
    }

    let heldVal = 0;
    for (const h of holdings.values()) heldVal += h.qty * c.close;
    const eq = quoteCash + heldVal;
    if (eq > peakEquity) peakEquity = eq;
    const dd = peakEquity > 0 ? ((peakEquity - eq) / peakEquity) * 100 : 0;
    if (dd > maxDd) maxDd = dd;
    const dec = params.quoteCurrency === 'IRT' ? 0 : 2;
    equityCurve.push({ time: c.openTime, equity: Number(eq.toFixed(dec)) });
  }

  let finalCapital = quoteCash;
  if (candles.length > 0) {
    const last = candles[candles.length - 1];
    for (const h of holdings.values()) {
      const net = h.qty * last.close * (1 - feeRate);
      finalCapital += net;
    }
  }

  const winning = trades.filter((t) => t.pnlQuote > 0);
  const losing = trades.filter((t) => t.pnlQuote <= 0);
  const grossProfit = winning.reduce((s, t) => s + t.pnlQuote, 0);
  const grossLoss = Math.abs(losing.reduce((s, t) => s + t.pnlQuote, 0));
  const netProfitQuote = finalCapital - initialCapital;
  const dec = params.quoteCurrency === 'IRT' ? 0 : 2;

  return {
    symbol: params.symbol,
    quoteCurrency: params.quoteCurrency,
    timeframe: params.timeframe,
    botType: 'GRID',
    candlesTested: candles.length,
    initialCapital: Number(initialCapital.toFixed(dec)),
    finalCapital: Number(finalCapital.toFixed(dec)),
    netProfitQuote: Number(netProfitQuote.toFixed(dec)),
    netProfitPercent: Number(((netProfitQuote / initialCapital) * 100).toFixed(2)),
    totalFeesPaidQuote: Number(totalFees.toFixed(dec)),
    estimatedSlippageQuote: Number(totalSlip.toFixed(dec)),
    avgWinQuote: winning.length > 0 ? Number((grossProfit / winning.length).toFixed(dec)) : 0,
    avgLossQuote: losing.length > 0 ? Number((grossLoss / losing.length).toFixed(dec)) : 0,
    totalTrades: trades.length,
    winningTrades: winning.length,
    losingTrades: losing.length,
    winRatePercent: trades.length > 0 ? Number(((winning.length / trades.length) * 100).toFixed(1)) : 0,
    maxDrawdownPercent: Number(maxDd.toFixed(2)),
    profitFactor: grossLoss > 0 ? Number((grossProfit / grossLoss).toFixed(2)) : grossProfit > 0 ? 9.99 : 0,
    equityCurve,
    trades: trades.slice(-30).reverse(),
  };
}

export function runDcaBacktest(
  candles: KlineCandle[],
  params: {
    symbol: string;
    quoteCurrency: QuoteCurrency;
    timeframe: Timeframe;
    totalCapital: number;
    stagesCount: number;
    stepUnit: DcaStepUnit;
    stepValue: number;
    triggerMode: DcaTriggerMode;
    intervalMinutes: number;
    stopLossEnabled: boolean;
    stopLossPercent: number;
    takeProfitEnabled: boolean;
    takeProfitPercent: number;
    trailingTpEnabled?: boolean;
    trailingTpActivationPercent?: number;
    trailingTpCallbackPercent?: number;
    takeProfitTargets?: TakeProfitTarget[];
    feeRate?: number;
    estimatedSlippagePercent?: number;
  }
): BacktestResult {
  const feeRate = params.feeRate ?? 0.0025;
  const slipRate = Math.max(0, params.estimatedSlippagePercent ?? 0.1) / 100;
  const initialCapital = Math.max(params.totalCapital, 1);
  const stages = Math.max(1, Math.min(30, params.stagesCount));
  const perStageSpend = initialCapital / stages;
  const pre = buildPrecomputed(candles);
  const rsiSeries = getCachedRSI(pre, 14);

  let quoteCash = initialCapital;
  let qtyHeld = 0;
  let totalCost = 0;
  let stagesDone = 0;
  let lastBuyPrice = 0;
  let lastBuyTime = 0;
  let cycleEntryTime = 0;
  let highestSinceEntry = 0;
  let trailingArmed = false;
  let totalFees = 0;
  let totalSlip = 0;

  const trades: BacktestTrade[] = [];
  const equityCurve: { time: number; equity: number }[] = [];
  let peakEquity = initialCapital;
  let maxDd = 0;

  for (let i = 15; i < candles.length; i++) {
    const c = candles[i];

    // Check exit first if holding
    if (qtyHeld > 0 && totalCost > 0) {
      const avgBuy = totalCost / qtyHeld;
      if (c.high > highestSinceEntry) highestSinceEntry = c.high;
      if (
        params.trailingTpEnabled &&
        !trailingArmed &&
        c.high >= avgBuy * (1 + (params.trailingTpActivationPercent ?? 5) / 100)
      ) {
        trailingArmed = true;
      }

      let exitPx: number | null = null;
      let reason: BacktestTrade['exitReason'] | null = null;
      if (params.stopLossEnabled && c.low <= avgBuy * (1 - params.stopLossPercent / 100)) {
        exitPx = avgBuy * (1 - params.stopLossPercent / 100);
        reason = 'STOP_LOSS';
      } else if (
        trailingArmed &&
        c.low <= highestSinceEntry * (1 - (params.trailingTpCallbackPercent ?? 1.2) / 100)
      ) {
        exitPx = highestSinceEntry * (1 - (params.trailingTpCallbackPercent ?? 1.2) / 100);
        reason = 'TRAILING_TP';
      } else if (params.takeProfitEnabled && c.high >= avgBuy * (1 + params.takeProfitPercent / 100)) {
        exitPx = avgBuy * (1 + params.takeProfitPercent / 100);
        reason = 'DCA_EXIT';
      }

      if (exitPx !== null && reason !== null) {
        const execSell = exitPx * (1 - slipRate);
        const gross = qtyHeld * execSell;
        const fee = gross * feeRate;
        const net = gross - fee;
        const pnlQuote = net - totalCost;
        totalFees += fee;
        totalSlip += gross * slipRate;
        quoteCash += net;
        trades.push({
          entryTime: cycleEntryTime,
          exitTime: c.openTime,
          entryPrice: avgBuy,
          exitPrice: execSell,
          pnlQuote,
          pnlPercent: (pnlQuote / totalCost) * 100,
          feeQuote: fee,
          exitReason: reason,
        });
        qtyHeld = 0;
        totalCost = 0;
        stagesDone = 0;
        lastBuyPrice = 0;
        highestSinceEntry = 0;
        trailingArmed = false;
      }
    }

    // Check DCA stage entry
    if (stagesDone < stages && quoteCash >= perStageSpend * 0.99 && c.close > 0) {
      let shouldBuy = false;
      if (stagesDone === 0) {
        shouldBuy = params.triggerMode === 'INDICATOR' ? (rsiSeries[i] ?? 50) <= 45 : true;
      } else if (params.triggerMode === 'TIME') {
        shouldBuy = c.openTime - lastBuyTime >= Math.max(1, params.intervalMinutes) * 60_000;
      } else if (params.triggerMode === 'INDICATOR') {
        const dropOk =
          params.stepUnit === 'PERCENT'
            ? c.close <= lastBuyPrice * (1 - params.stepValue / 100)
            : c.close <= lastBuyPrice - params.stepValue;
        shouldBuy = dropOk && (rsiSeries[i] ?? 50) <= 40;
      } else {
        shouldBuy =
          params.stepUnit === 'PERCENT'
            ? c.close <= lastBuyPrice * (1 - params.stepValue / 100)
            : c.close <= lastBuyPrice - params.stepValue;
      }

      if (shouldBuy) {
        const spend = Math.min(perStageSpend, quoteCash);
        const execBuy = c.close * (1 + slipRate);
        const fee = spend * feeRate;
        const netQty = (spend - fee) / execBuy;
        totalFees += fee;
        totalSlip += spend * slipRate;
        quoteCash -= spend;
        qtyHeld += netQty;
        totalCost += spend;
        if (stagesDone === 0) {
          cycleEntryTime = c.openTime;
          highestSinceEntry = execBuy;
        }
        stagesDone += 1;
        lastBuyPrice = execBuy;
        lastBuyTime = c.openTime;
      }
    }

    const eq = quoteCash + qtyHeld * c.close;
    if (eq > peakEquity) peakEquity = eq;
    const dd = peakEquity > 0 ? ((peakEquity - eq) / peakEquity) * 100 : 0;
    if (dd > maxDd) maxDd = dd;
    const dec = params.quoteCurrency === 'IRT' ? 0 : 2;
    equityCurve.push({ time: c.openTime, equity: Number(eq.toFixed(dec)) });
  }

  let finalCapital = quoteCash;
  if (qtyHeld > 0 && candles.length > 0) {
    const last = candles[candles.length - 1];
    finalCapital += qtyHeld * last.close * (1 - feeRate);
  }

  const winning = trades.filter((t) => t.pnlQuote > 0);
  const losing = trades.filter((t) => t.pnlQuote <= 0);
  const grossProfit = winning.reduce((s, t) => s + t.pnlQuote, 0);
  const grossLoss = Math.abs(losing.reduce((s, t) => s + t.pnlQuote, 0));
  const netProfitQuote = finalCapital - initialCapital;
  const dec = params.quoteCurrency === 'IRT' ? 0 : 2;

  return {
    symbol: params.symbol,
    quoteCurrency: params.quoteCurrency,
    timeframe: params.timeframe,
    botType: 'DCA',
    candlesTested: candles.length,
    initialCapital: Number(initialCapital.toFixed(dec)),
    finalCapital: Number(finalCapital.toFixed(dec)),
    netProfitQuote: Number(netProfitQuote.toFixed(dec)),
    netProfitPercent: Number(((netProfitQuote / initialCapital) * 100).toFixed(2)),
    totalFeesPaidQuote: Number(totalFees.toFixed(dec)),
    estimatedSlippageQuote: Number(totalSlip.toFixed(dec)),
    avgWinQuote: winning.length > 0 ? Number((grossProfit / winning.length).toFixed(dec)) : 0,
    avgLossQuote: losing.length > 0 ? Number((grossLoss / losing.length).toFixed(dec)) : 0,
    totalTrades: trades.length,
    winningTrades: winning.length,
    losingTrades: losing.length,
    winRatePercent: trades.length > 0 ? Number(((winning.length / trades.length) * 100).toFixed(1)) : 0,
    maxDrawdownPercent: Number(maxDd.toFixed(2)),
    profitFactor: grossLoss > 0 ? Number((grossProfit / grossLoss).toFixed(2)) : grossProfit > 0 ? 9.99 : 0,
    equityCurve,
    trades: trades.slice(-30).reverse(),
  };
}

