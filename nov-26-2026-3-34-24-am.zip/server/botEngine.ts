import crypto from 'node:crypto';
import { and, desc, eq, inArray, lte } from 'drizzle-orm';
import * as schema from '../src/db/schema.ts';
import type {
  BotExecutionConfirmationMode,
  BotExecutionLog,
  BotFundingMode,
  BotStrategyConfig,
  CostBasisSource,
  ExecutionMode,
  FeatureIdeaCategory,
  FeatureIdeaItem,
  FeatureIdeaStatus,
  PeriodicPriceWatcher,
  PortfolioAssetPerformance,
  PortfolioPerformanceSummary,
  PriceAlert,
  PriceAlertCondition,
  PricePulseNotification,
  PriceReporterQuoteMode,
  QuoteCurrency,
  SpotBalance,
  SpotOrder,
  StrategyRule,
  StrategyStyleMode,
  TakeProfitTarget,
  Timeframe,
  UnifiedMarketTicker,
} from '../src/types/trading.ts';
import {
  computeExistingBalanceAllocation,
  getMinimumOrderNotional,
  roundQuantityToStep,
} from '../src/utils/profitBotMath.ts';
import {
  acquireWorkerLock,
  ensureDefaultPaperWallet,
  ensureUserRecord,
  getDb,
  releaseWorkerLock,
  withTransaction,
  type AppDatabase,
} from './db/index.ts';
import { logger } from './logger.ts';
import {
  fetchNobitexKlines,
  fetchNobitexLiveBalances,
  fetchNobitexUnifiedMarkets,
  formatNobitexClientOrderId,
  getNobitexMarketRules,
  getPersianCoinName,
  NobitexAuthError,
  placeNobitexLiveOrder,
} from './nobitexClient.ts';
import {
  getActiveExchangeCredentialsForUser,
  hasActiveExchangeCredentialsForUser,
} from './securityVault.ts';
import {
  notifyTelegramBotActivity,
  notifyTelegramBotTrade,
  notifyTelegramPriceAlert,
  notifyTelegramPricePulse,
  notifyTelegramSpotOrder,
} from './telegramClient.ts';
import { analyzeCandles, evaluateRuleset } from './indicators.ts';
import {
  emergencyStopAllProfitBots,
  emergencyStopUserProfitBots,
  runAllActiveProfitBotsCycle,
} from './profitBotEngine.ts';

const NOBITEX_FEE_RATE = 0.0025; // 0.25%
const WORKER_LOCK_NAME = 'ali_trader_bot_cycle_lock';
const WORKER_INSTANCE_ID = `worker-${process.pid}-${crypto.randomBytes(4).toString('hex')}`;

let isEvaluatingLocally = false;
let loopTimer: ReturnType<typeof setInterval> | null = null;

function formatAmountText(amount: number, quoteCurrency: QuoteCurrency): string {
  if (quoteCurrency === 'IRT') {
    return `${Math.round(amount).toLocaleString('en-US')} تومان`;
  }
  return `${amount.toFixed(2)} USDT`;
}

function extractFixedPriceConfig(
  entryRules: StrategyRule[],
  exitRules: StrategyRule[]
): {
  strategyKind: 'INDICATOR' | 'FIXED_PRICE';
  targetBuyPrice?: number;
  targetSellPrice?: number;
  repeatCycle?: boolean;
  maxCycles?: number | null;
  pollIntervalSeconds?: number;
} {
  const buyRule = entryRules.find((r) => r.type === 'FIXED_BUY_PRICE' && r.enabled !== false);
  const sellRule = exitRules.find((r) => r.type === 'FIXED_SELL_PRICE' && r.enabled !== false);
  if (!buyRule && !sellRule) {
    return { strategyKind: 'INDICATOR' };
  }
  const targetBuyPrice = Number(buyRule?.params?.targetPrice || 0) || undefined;
  const targetSellPrice = Number(sellRule?.params?.targetPrice || 0) || undefined;
  const repeatCycle = buyRule?.params?.repeatCycle !== false;
  const rawMax = buyRule?.params?.maxCycles;
  const maxCycles = typeof rawMax === 'number' && rawMax > 0 ? Math.floor(rawMax) : null;
  const rawPoll = Number(buyRule?.params?.pollSeconds || 5);
  const pollIntervalSeconds = Number.isFinite(rawPoll)
    ? Math.min(300, Math.max(2, Math.round(rawPoll)))
    : 5;
  return {
    strategyKind: 'FIXED_PRICE',
    targetBuyPrice,
    targetSellPrice,
    repeatCycle,
    maxCycles,
    pollIntervalSeconds,
  };
}

function isFixedPriceBot(bot: BotStrategyConfig): boolean {
  if (bot.strategyKind === 'FIXED_PRICE') return true;
  return (
    bot.entryRules.some((r) => r.type === 'FIXED_BUY_PRICE') ||
    bot.exitRules.some((r) => r.type === 'FIXED_SELL_PRICE')
  );
}

type PersistedBotStatsJson = BotStrategyConfig['stats'] & {
  __fundingMode?: BotFundingMode;
  __existingBalancePercent?: number;
  __strategyStyle?: StrategyStyleMode;
  __executionConfirmationMode?: BotExecutionConfirmationMode;
  __maxAllocatedCapital?: number;
  __feeRate?: number;
  __estimatedSlippagePercent?: number;
  __volumeConfirmationEnabled?: boolean;
  __minVolumeRatio?: number;
  __volatilityFilterEnabled?: boolean;
  __volatilityFilterMaxAtrPercent?: number;
  __minSignalScore?: number;
  __takeProfitTargets?: TakeProfitTarget[];
  __trailingTakeProfitEnabled?: boolean;
  __trailingTakeProfitActivationPercent?: number;
  __trailingTakeProfitCallbackPercent?: number;
  __keepRunnerPercent?: number;
};

function normalizeBotFundingMode(mode?: unknown): BotFundingMode {
  if (mode === 'EXISTING_ASSET' || mode === 'AUTO_PREFER_EXISTING') return mode;
  return 'QUOTE_BUY';
}

function clampBotBalancePercent(pct?: unknown): number {
  const num = Number(pct);
  if (!Number.isFinite(num) || num <= 0) return 50;
  return Math.min(100, Math.max(1, num));
}

function buildPersistedBotStatsJson(
  bot: Pick<
    BotStrategyConfig,
    | 'stats'
    | 'fundingMode'
    | 'existingBalancePercent'
    | 'strategyStyle'
    | 'executionConfirmationMode'
    | 'maxAllocatedCapital'
    | 'feeRate'
    | 'estimatedSlippagePercent'
    | 'volumeConfirmationEnabled'
    | 'minVolumeRatio'
    | 'volatilityFilterEnabled'
    | 'volatilityFilterMaxAtrPercent'
    | 'minSignalScore'
    | 'takeProfitTargets'
    | 'trailingTakeProfitEnabled'
    | 'trailingTakeProfitActivationPercent'
    | 'trailingTakeProfitCallbackPercent'
    | 'keepRunnerPercent'
  >
): PersistedBotStatsJson {
  return {
    ...bot.stats,
    __fundingMode: normalizeBotFundingMode(bot.fundingMode),
    __existingBalancePercent: clampBotBalancePercent(bot.existingBalancePercent),
    __strategyStyle: bot.strategyStyle || 'MEDIUM_TERM',
    __executionConfirmationMode: bot.executionConfirmationMode || 'AUTO',
    __maxAllocatedCapital: bot.maxAllocatedCapital,
    __feeRate: bot.feeRate,
    __estimatedSlippagePercent: bot.estimatedSlippagePercent,
    __volumeConfirmationEnabled: bot.volumeConfirmationEnabled,
    __minVolumeRatio: bot.minVolumeRatio,
    __volatilityFilterEnabled: bot.volatilityFilterEnabled,
    __volatilityFilterMaxAtrPercent: bot.volatilityFilterMaxAtrPercent,
    __minSignalScore: bot.minSignalScore,
    __takeProfitTargets: bot.takeProfitTargets,
    __trailingTakeProfitEnabled: bot.trailingTakeProfitEnabled,
    __trailingTakeProfitActivationPercent: bot.trailingTakeProfitActivationPercent,
    __trailingTakeProfitCallbackPercent: bot.trailingTakeProfitCallbackPercent,
    __keepRunnerPercent: bot.keepRunnerPercent,
  };
}

function mapBotRowsToConfig(
  botRow: typeof schema.tradingBots.$inferSelect,
  cfgRow?: typeof schema.botConfigurations.$inferSelect
): BotStrategyConfig {
  const defaultStats: PersistedBotStatsJson = {
    totalTrades: 0,
    winningTrades: 0,
    losingTrades: 0,
    realizedPnl: 0,
  };
  const statsRaw = (botRow.statsJson || defaultStats) as Partial<PersistedBotStatsJson>;
  const entryRules = Array.isArray(cfgRow?.entryRulesJson)
    ? (cfgRow!.entryRulesJson as StrategyRule[])
    : [];
  const exitRules = Array.isArray(cfgRow?.exitRulesJson)
    ? (cfgRow!.exitRulesJson as StrategyRule[])
    : [];
  const fixedMeta = extractFixedPriceConfig(entryRules, exitRules);

  return {
    id: botRow.id,
    ownerId: botRow.userId,
    name: botRow.name,
    strategyKind: fixedMeta.strategyKind,
    strategyStyle: (statsRaw.__strategyStyle as StrategyStyleMode) || 'MEDIUM_TERM',
    executionConfirmationMode:
      statsRaw.__executionConfirmationMode === 'MANUAL_CONFIRM' ? 'MANUAL_CONFIRM' : 'AUTO',
    maxAllocatedCapital:
      typeof statsRaw.__maxAllocatedCapital === 'number'
        ? statsRaw.__maxAllocatedCapital
        : undefined,
    feeRate: typeof statsRaw.__feeRate === 'number' ? statsRaw.__feeRate : NOBITEX_FEE_RATE,
    estimatedSlippagePercent:
      typeof statsRaw.__estimatedSlippagePercent === 'number'
        ? statsRaw.__estimatedSlippagePercent
        : 0.15,
    volumeConfirmationEnabled: Boolean(statsRaw.__volumeConfirmationEnabled),
    minVolumeRatio:
      typeof statsRaw.__minVolumeRatio === 'number' ? statsRaw.__minVolumeRatio : 1.2,
    volatilityFilterEnabled: Boolean(statsRaw.__volatilityFilterEnabled),
    volatilityFilterMaxAtrPercent:
      typeof statsRaw.__volatilityFilterMaxAtrPercent === 'number'
        ? statsRaw.__volatilityFilterMaxAtrPercent
        : 4.5,
    minSignalScore:
      typeof statsRaw.__minSignalScore === 'number' ? statsRaw.__minSignalScore : 1,
    takeProfitTargets: Array.isArray(statsRaw.__takeProfitTargets)
      ? statsRaw.__takeProfitTargets
      : undefined,
    trailingTakeProfitEnabled: Boolean(statsRaw.__trailingTakeProfitEnabled),
    trailingTakeProfitActivationPercent:
      typeof statsRaw.__trailingTakeProfitActivationPercent === 'number'
        ? statsRaw.__trailingTakeProfitActivationPercent
        : 3.0,
    trailingTakeProfitCallbackPercent:
      typeof statsRaw.__trailingTakeProfitCallbackPercent === 'number'
        ? statsRaw.__trailingTakeProfitCallbackPercent
        : 1.0,
    keepRunnerPercent:
      typeof statsRaw.__keepRunnerPercent === 'number' ? statsRaw.__keepRunnerPercent : 0,
    targetBuyPrice: fixedMeta.targetBuyPrice,
    targetSellPrice: fixedMeta.targetSellPrice,
    repeatCycle: fixedMeta.repeatCycle,
    maxCycles: fixedMeta.maxCycles,
    pollIntervalSeconds: fixedMeta.pollIntervalSeconds,
    fundingMode: normalizeBotFundingMode(statsRaw.__fundingMode),
    existingBalancePercent: clampBotBalancePercent(statsRaw.__existingBalancePercent),
    baseAsset: botRow.baseAsset,
    quoteCurrency: (botRow.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    symbol: botRow.symbol,
    timeframe: botRow.timeframe as Timeframe,
    mode: (botRow.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    status: (botRow.status === 'RUNNING' ? 'RUNNING' : 'PAUSED') as 'RUNNING' | 'PAUSED',
    orderAmount: botRow.orderAmount,
    stopLossPercent: cfgRow?.stopLossPercent ?? 2.5,
    takeProfitPercent: cfgRow?.takeProfitPercent ?? 5.0,
    trailingStopEnabled: cfgRow?.trailingStopEnabled ?? false,
    trailingStopPercent: cfgRow?.trailingStopPercent ?? 1.5,
    cooldownMinutes: cfgRow?.cooldownMinutes ?? 15,
    logicOperator: (cfgRow?.logicOperator === 'OR' ? 'OR' : 'AND') as 'AND' | 'OR',
    entryRules,
    exitRules,
    activePosition: (botRow.activePositionJson as BotStrategyConfig['activePosition']) ?? null,
    stats: {
      totalTrades: Number(statsRaw.totalTrades || 0),
      winningTrades: Number(statsRaw.winningTrades || 0),
      losingTrades: Number(statsRaw.losingTrades || 0),
      realizedPnl: Number(statsRaw.realizedPnl || 0),
    },
    lastCheckedAt: botRow.lastCheckedAt ?? null,
    lastSignalSummary: botRow.lastSignalSummary || '',
    notifyTelegram: botRow.notifyTelegram !== false,
    createdAt: botRow.createdAt,
  };
}

function mapOrderRow(row: typeof schema.orders.$inferSelect): SpotOrder {
  return {
    orderId: row.orderId,
    symbol: row.symbol,
    baseAsset: row.baseAsset,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    side: row.side as 'BUY' | 'SELL',
    type: row.type as 'LIMIT' | 'MARKET',
    price: row.price,
    quantity: row.quantity,
    executedQty: row.executedQty,
    totalQuoteAmount: row.totalQuoteAmount,
    status: row.status as SpotOrder['status'],
    stopLossPrice: row.stopLossPrice ?? undefined,
    takeProfitPrice: row.takeProfitPrice ?? undefined,
    mode: (row.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    source: (row.source === 'BOT' ? 'BOT' : 'MANUAL') as 'MANUAL' | 'BOT',
    botId: row.botId ?? undefined,
    createdAt: row.createdAt,
  };
}

function mapLogRow(row: typeof schema.tradingLogs.$inferSelect): BotExecutionLog {
  return {
    id: row.id,
    botId: row.botId,
    botName: row.botName,
    symbol: row.symbol,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    event: row.event as BotExecutionLog['event'],
    price: row.price,
    quantity: row.quantity ?? undefined,
    pnlQuote: row.pnlQuote ?? undefined,
    message: row.message,
    mode: (row.mode === 'live' ? 'live' : 'paper') as ExecutionMode,
    timestamp: row.timestamp,
  };
}

function mapAlertRow(row: typeof schema.priceAlerts.$inferSelect): PriceAlert {
  return {
    id: row.id,
    baseAsset: row.baseAsset,
    persianName: row.persianName,
    quoteCurrency: (row.quoteCurrency === 'USDT' ? 'USDT' : 'IRT') as QuoteCurrency,
    symbol: row.symbol,
    condition: (row.condition === 'BELOW' ? 'BELOW' : 'ABOVE') as PriceAlertCondition,
    targetPrice: row.targetPrice,
    createdPrice: row.createdPrice,
    status: (row.status === 'TRIGGERED' ? 'TRIGGERED' : 'ACTIVE') as PriceAlert['status'],
    sendTelegram: row.sendTelegram !== false,
    note: row.note ?? undefined,
    createdAt: row.createdAt,
    triggeredAt: row.triggeredAt ?? undefined,
    triggeredPrice: row.triggeredPrice ?? undefined,
  };
}

function mapWatcherRow(row: typeof schema.priceWatchers.$inferSelect): PeriodicPriceWatcher {
  return {
    id: row.id,
    baseAsset: row.baseAsset,
    persianName: row.persianName,
    quoteMode: (row.quoteMode === 'IRT' || row.quoteMode === 'USDT'
      ? row.quoteMode
      : 'BOTH') as PriceReporterQuoteMode,
    intervalMinutes: row.intervalMinutes,
    status: (row.status === 'PAUSED' ? 'PAUSED' : 'ACTIVE') as 'ACTIVE' | 'PAUSED',
    notifyBrowser: row.notifyBrowser,
    playSound: row.playSound,
    sendTelegram: row.sendTelegram !== false,
    webhookUrl: row.webhookUrl ?? undefined,
    lastPriceToman: row.lastPriceToman ?? undefined,
    lastPriceUsdt: row.lastPriceUsdt ?? undefined,
    lastChange24h: row.lastChange24h ?? undefined,
    sentCount: row.sentCount,
    createdAt: row.createdAt,
    lastSentAt: row.lastSentAt ?? null,
    nextSendAt: row.nextSendAt,
  };
}

function mapPulseRow(row: typeof schema.notifications.$inferSelect): PricePulseNotification {
  return {
    id: row.id,
    watcherId: row.watcherId,
    baseAsset: row.baseAsset,
    persianName: row.persianName,
    quoteMode: (row.quoteMode === 'IRT' || row.quoteMode === 'USDT'
      ? row.quoteMode
      : 'BOTH') as PriceReporterQuoteMode,
    priceToman: row.priceToman,
    priceUsdt: row.priceUsdt,
    change24hPercent: row.change24hPercent,
    intervalMinutes: row.intervalMinutes,
    sentAt: row.sentAt,
  };
}

async function appendLog(
  userId: string,
  log: Omit<BotExecutionLog, 'id' | 'timestamp'>,
  dbClient?: AppDatabase
): Promise<BotExecutionLog> {
  const db = dbClient || getDb();
  const entry: BotExecutionLog = {
    ...log,
    id: `log-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
    timestamp: Date.now(),
  };
  await db.insert(schema.tradingLogs).values({
    id: entry.id,
    userId,
    botId: entry.botId,
    botName: entry.botName,
    symbol: entry.symbol,
    quoteCurrency: entry.quoteCurrency,
    event: entry.event,
    price: entry.price,
    quantity: entry.quantity ?? null,
    pnlQuote: entry.pnlQuote ?? null,
    message: entry.message,
    mode: entry.mode,
    timestamp: entry.timestamp,
  });
  return entry;
}

// ===========================================================================
// Paper Trading Wallets, Orders & Ledger (Strictly Per User)
// ===========================================================================
async function upsertPaperBalanceInTx(
  tx: AppDatabase,
  userId: string,
  asset: string,
  delta: number
): Promise<number> {
  const cleanAsset = asset.toUpperCase();
  const rows = await tx
    .select()
    .from(schema.paperTradingBalances)
    .where(
      and(
        eq(schema.paperTradingBalances.userId, userId),
        eq(schema.paperTradingBalances.asset, cleanAsset)
      )
    )
    .limit(1);

  const now = Date.now();
  const current = rows[0]?.balance ?? 0;
  const next = Number((current + delta).toFixed(12));
  if (next < -0.00000001) {
    throw new Error(`موجودی ${cleanAsset} کافی نیست.`);
  }
  const clamped = Math.max(0, next);

  if (rows[0]) {
    await tx
      .update(schema.paperTradingBalances)
      .set({ balance: clamped, updatedAt: now })
      .where(eq(schema.paperTradingBalances.id, rows[0].id));
  } else {
    await tx.insert(schema.paperTradingBalances).values({
      userId,
      asset: cleanAsset,
      balance: clamped,
      updatedAt: now,
    });
  }
  return clamped;
}

export async function getPaperBalances(
  userId: string,
  markets: UnifiedMarketTicker[],
  usdtTomanRate: number
): Promise<SpotBalance[]> {
  await ensureUserRecord({ uid: userId });
  await ensureDefaultPaperWallet(userId);
  const db = getDb();

  const [balRows, openOrderRows] = await Promise.all([
    db
      .select()
      .from(schema.paperTradingBalances)
      .where(eq(schema.paperTradingBalances.userId, userId)),
    db
      .select()
      .from(schema.orders)
      .where(
        and(
          eq(schema.orders.userId, userId),
          eq(schema.orders.mode, 'paper'),
          eq(schema.orders.status, 'NEW')
        )
      ),
  ]);

  const tomanMap = new Map<string, number>();
  const usdtMap = new Map<string, number>();

  tomanMap.set('IRT', 1);
  usdtMap.set('IRT', usdtTomanRate > 0 ? 1 / usdtTomanRate : 0);
  usdtMap.set('USDT', 1);
  tomanMap.set('USDT', usdtTomanRate);

  for (const m of markets) {
    tomanMap.set(m.baseAsset, m.priceToman);
    usdtMap.set(m.baseAsset, m.priceUsdt);
  }

  const freeMap = new Map<string, number>();
  for (const r of balRows) {
    freeMap.set(r.asset.toUpperCase(), r.balance);
  }

  const lockedMap = new Map<string, number>();
  for (const ord of openOrderRows) {
    if (ord.side === 'BUY') {
      lockedMap.set(
        ord.quoteCurrency,
        (lockedMap.get(ord.quoteCurrency) || 0) + ord.price * ord.quantity
      );
    } else {
      lockedMap.set(ord.baseAsset, (lockedMap.get(ord.baseAsset) || 0) + ord.quantity);
    }
  }

  const assets = new Set(['IRT', 'USDT', ...freeMap.keys(), ...lockedMap.keys()]);
  const list: SpotBalance[] = [];

  for (const asset of assets) {
    const free = freeMap.get(asset) || 0;
    const locked = lockedMap.get(asset) || 0;
    const total = free + locked;
    if (total <= 0.0000001 && asset !== 'IRT' && asset !== 'USDT') continue;

    const unitToman = tomanMap.get(asset) || 0;
    const unitUsdt = usdtMap.get(asset) || 0;

    list.push({
      asset,
      persianName: asset === 'IRT' ? 'تومان' : getPersianCoinName(asset),
      free,
      locked,
      total,
      tomanValue: total * unitToman,
      usdtValue: total * unitUsdt,
    });
  }

  return list.sort((a, b) => b.tomanValue - a.tomanValue);
}

export async function resetPaperWallet(
  userId: string,
  usdtTomanRate = 269000
): Promise<SpotBalance[]> {
  await ensureUserRecord({ uid: userId });
  await withTransaction(async (tx) => {
    const now = Date.now();
    await tx
      .delete(schema.paperTradingBalances)
      .where(eq(schema.paperTradingBalances.userId, userId));
    await tx.insert(schema.paperTradingBalances).values([
      { userId, asset: 'IRT', balance: 500_000_000, updatedAt: now },
      { userId, asset: 'USDT', balance: 5_000, updatedAt: now },
    ]);
    await tx
      .delete(schema.orders)
      .where(and(eq(schema.orders.userId, userId), eq(schema.orders.mode, 'paper')));
    await tx
      .delete(schema.trades)
      .where(and(eq(schema.trades.userId, userId), eq(schema.trades.mode, 'paper')));
    await tx
      .delete(schema.costBasisOverrides)
      .where(
        and(
          eq(schema.costBasisOverrides.userId, userId),
          eq(schema.costBasisOverrides.mode, 'paper')
        )
      );
  });

  return [
    {
      asset: 'IRT',
      persianName: 'تومان',
      free: 500_000_000,
      locked: 0,
      total: 500_000_000,
      tomanValue: 500_000_000,
      usdtValue: usdtTomanRate > 0 ? 500_000_000 / usdtTomanRate : 0,
    },
    {
      asset: 'USDT',
      persianName: 'تتر',
      free: 5_000,
      locked: 0,
      total: 5_000,
      tomanValue: 5_000 * usdtTomanRate,
      usdtValue: 5_000,
    },
  ];
}

export async function setAssetCostBasis(
  userId: string,
  input: {
    asset: string;
    price: number;
    quoteCurrency: QuoteCurrency;
    mode: ExecutionMode;
    usdtTomanRate: number;
  }
): Promise<void> {
  const cleanAsset = input.asset.toUpperCase().trim();
  if (!cleanAsset || cleanAsset === 'IRT' || cleanAsset === 'USDT') {
    throw new Error('امکان ثبت قیمت خرید اولیه برای ارز پایه نقدی وجود ندارد.');
  }
  if (!Number.isFinite(input.price) || input.price <= 0) {
    throw new Error('قیمت خرید اولیه باید بزرگ‌تر از صفر باشد.');
  }

  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const rate = input.usdtTomanRate > 0 ? input.usdtTomanRate : 1;
  const priceToman = input.quoteCurrency === 'IRT' ? input.price : input.price * rate;
  const priceUsdt = input.quoteCurrency === 'USDT' ? input.price : input.price / rate;
  const now = Date.now();

  const existing = await db
    .select()
    .from(schema.costBasisOverrides)
    .where(
      and(
        eq(schema.costBasisOverrides.userId, userId),
        eq(schema.costBasisOverrides.mode, input.mode),
        eq(schema.costBasisOverrides.asset, cleanAsset)
      )
    )
    .limit(1);

  if (existing[0]) {
    await db
      .update(schema.costBasisOverrides)
      .set({ priceToman, priceUsdt, updatedAt: now })
      .where(eq(schema.costBasisOverrides.id, existing[0].id));
  } else {
    await db.insert(schema.costBasisOverrides).values({
      userId,
      mode: input.mode,
      asset: cleanAsset,
      priceToman,
      priceUsdt,
      updatedAt: now,
    });
  }
}

export async function clearAssetCostBasis(
  userId: string,
  asset: string,
  mode: ExecutionMode
): Promise<void> {
  const db = getDb();
  await db
    .delete(schema.costBasisOverrides)
    .where(
      and(
        eq(schema.costBasisOverrides.userId, userId),
        eq(schema.costBasisOverrides.mode, mode),
        eq(schema.costBasisOverrides.asset, asset.toUpperCase().trim())
      )
    );
}

export async function getPaperOrders(userId: string, symbol?: string): Promise<SpotOrder[]> {
  const db = getDb();
  const conditions = [eq(schema.orders.userId, userId), eq(schema.orders.mode, 'paper')];
  if (symbol) conditions.push(eq(schema.orders.symbol, symbol.toUpperCase()));
  const rows = await db
    .select()
    .from(schema.orders)
    .where(and(...conditions))
    .orderBy(desc(schema.orders.createdAt))
    .limit(200);
  return rows.map(mapOrderRow);
}

export async function getPaperOpenOrders(userId: string, symbol?: string): Promise<SpotOrder[]> {
  const db = getDb();
  const conditions = [
    eq(schema.orders.userId, userId),
    eq(schema.orders.mode, 'paper'),
    eq(schema.orders.status, 'NEW'),
  ];
  if (symbol) conditions.push(eq(schema.orders.symbol, symbol.toUpperCase()));
  const rows = await db
    .select()
    .from(schema.orders)
    .where(and(...conditions))
    .orderBy(desc(schema.orders.createdAt))
    .limit(100);
  return rows.map(mapOrderRow);
}

export async function getUserOrdersAndTrades(userId: string, limit = 100) {
  const db = getDb();
  const [orderRows, tradeRows] = await Promise.all([
    db
      .select()
      .from(schema.orders)
      .where(eq(schema.orders.userId, userId))
      .orderBy(desc(schema.orders.createdAt))
      .limit(limit),
    db
      .select()
      .from(schema.trades)
      .where(eq(schema.trades.userId, userId))
      .orderBy(desc(schema.trades.executedAt))
      .limit(limit),
  ]);
  return {
    orders: orderRows.map(mapOrderRow),
    trades: tradeRows,
  };
}

export async function placePaperOrder(
  userId: string,
  input: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    side: 'BUY' | 'SELL';
    type: 'LIMIT' | 'MARKET';
    quantity: number;
    price: number;
    stopLossPrice?: number;
    takeProfitPrice?: number;
    source?: 'MANUAL' | 'BOT';
    botId?: string;
    idempotencyKey?: string;
    realizedPnlQuote?: number;
  }
): Promise<SpotOrder> {
  const baseAsset = input.baseAsset.toUpperCase();
  const quoteCurrency = input.quoteCurrency;
  const symbol = `${baseAsset}${quoteCurrency}`;

  if (
    !Number.isFinite(input.quantity) ||
    !Number.isFinite(input.price) ||
    input.quantity <= 0 ||
    input.price <= 0
  ) {
    throw new Error('مقدار و قیمت سفارش باید بزرگ‌تر از صفر باشند.');
  }

  const notional = input.quantity * input.price;
  if (quoteCurrency === 'IRT' && notional + 1e-6 < 50_000) {
    throw new Error('حداقل ارزش سفارش تومانی در نوبیتکس ۵۰,۰۰۰ تومان است.');
  }
  if (quoteCurrency === 'USDT' && notional + 1e-6 < 0.5) {
    throw new Error('حداقل ارزش سفارش تتری ۰.۵ USDT است.');
  }

  await ensureUserRecord({ uid: userId });
  await ensureDefaultPaperWallet(userId);

  return withTransaction(async (tx) => {
    if (input.idempotencyKey) {
      const existing = await tx
        .select()
        .from(schema.orders)
        .where(eq(schema.orders.idempotencyKey, input.idempotencyKey))
        .limit(1);
      if (existing[0]) {
        return mapOrderRow(existing[0]);
      }
    }

    let feeAmount = 0;
    if (input.side === 'BUY') {
      const balRows = await tx
        .select()
        .from(schema.paperTradingBalances)
        .where(
          and(
            eq(schema.paperTradingBalances.userId, userId),
            eq(schema.paperTradingBalances.asset, quoteCurrency)
          )
        )
        .limit(1);
      const availQuote = balRows[0]?.balance ?? 0;
      if (availQuote < notional) {
        throw new Error(
          `موجودی ${quoteCurrency === 'IRT' ? 'تومان' : 'تتر (USDT)'} کافی نیست (نیاز: ${formatAmountText(
            notional,
            quoteCurrency
          )}، موجود: ${formatAmountText(availQuote, quoteCurrency)})`
        );
      }
      await upsertPaperBalanceInTx(tx, userId, quoteCurrency, -notional);

      if (input.type === 'MARKET') {
        const receivedBase = input.quantity * (1 - NOBITEX_FEE_RATE);
        feeAmount = input.quantity * NOBITEX_FEE_RATE;
        await upsertPaperBalanceInTx(tx, userId, baseAsset, receivedBase);
      }
    } else {
      const balRows = await tx
        .select()
        .from(schema.paperTradingBalances)
        .where(
          and(
            eq(schema.paperTradingBalances.userId, userId),
            eq(schema.paperTradingBalances.asset, baseAsset)
          )
        )
        .limit(1);
      const availBase = balRows[0]?.balance ?? 0;
      if (availBase + 1e-8 < input.quantity) {
        throw new Error(
          `موجودی ${baseAsset} کافی نیست (نیاز: ${input.quantity.toFixed(
            6
          )}، موجود: ${availBase.toFixed(6)})`
        );
      }
      const sellQty = Math.min(input.quantity, availBase);
      const sellNotional = sellQty * input.price;
      await upsertPaperBalanceInTx(tx, userId, baseAsset, -sellQty);

      if (input.type === 'MARKET') {
        feeAmount = sellNotional * NOBITEX_FEE_RATE;
        const receivedQuote = sellNotional * (1 - NOBITEX_FEE_RATE);
        await upsertPaperBalanceInTx(tx, userId, quoteCurrency, receivedQuote);
      }
    }

    const now = Date.now();
    const orderId = `paper-${now}-${crypto.randomBytes(3).toString('hex')}`;
    const status = input.type === 'MARKET' ? 'FILLED' : 'NEW';
    const executedQty = input.type === 'MARKET' ? input.quantity : 0;

    await tx.insert(schema.orders).values({
      orderId,
      userId,
      botId: input.botId ?? null,
      exchangeOrderId: null,
      idempotencyKey: input.idempotencyKey ?? null,
      symbol,
      baseAsset,
      quoteCurrency,
      side: input.side,
      type: input.type,
      price: input.price,
      quantity: input.quantity,
      executedQty,
      totalQuoteAmount: notional,
      feeAmount,
      status,
      stopLossPrice: input.stopLossPrice ?? null,
      takeProfitPrice: input.takeProfitPrice ?? null,
      mode: 'paper',
      source: input.source || 'MANUAL',
      createdAt: now,
      updatedAt: now,
    });

    if (status === 'FILLED') {
      await tx.insert(schema.trades).values({
        id: `trd-${now}-${crypto.randomBytes(3).toString('hex')}`,
        userId,
        orderId,
        botId: input.botId ?? null,
        symbol,
        baseAsset,
        quoteCurrency,
        side: input.side,
        price: input.price,
        quantity: input.quantity,
        quoteAmount: notional,
        feeAmount,
        realizedPnlQuote: input.realizedPnlQuote ?? null,
        mode: 'paper',
        executedAt: now,
      });
    }

    return {
      orderId,
      symbol,
      baseAsset,
      quoteCurrency,
      side: input.side,
      type: input.type,
      price: input.price,
      quantity: input.quantity,
      executedQty,
      totalQuoteAmount: notional,
      status,
      stopLossPrice: input.stopLossPrice,
      takeProfitPrice: input.takeProfitPrice,
      mode: 'paper',
      source: input.source || 'MANUAL',
      botId: input.botId,
      createdAt: now,
    };
  });
}

export async function recordLiveOrderAndTrade(
  userId: string,
  order: SpotOrder,
  options?: {
    idempotencyKey?: string;
    realizedPnlQuote?: number;
  }
): Promise<void> {
  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const now = Date.now();
  await db
    .insert(schema.orders)
    .values({
      orderId: `live-${order.orderId}-${crypto.randomBytes(2).toString('hex')}`,
      userId,
      botId: order.botId ?? null,
      exchangeOrderId: order.orderId,
      idempotencyKey: options?.idempotencyKey ?? null,
      symbol: order.symbol,
      baseAsset: order.baseAsset,
      quoteCurrency: order.quoteCurrency,
      side: order.side,
      type: order.type,
      price: order.price,
      quantity: order.quantity,
      executedQty: order.executedQty,
      totalQuoteAmount: order.totalQuoteAmount,
      feeAmount:
        order.side === 'BUY'
          ? order.executedQty * NOBITEX_FEE_RATE
          : order.totalQuoteAmount * NOBITEX_FEE_RATE,
      status: order.status,
      stopLossPrice: order.stopLossPrice ?? null,
      takeProfitPrice: order.takeProfitPrice ?? null,
      mode: 'live',
      source: order.source,
      createdAt: order.createdAt || now,
      updatedAt: now,
    })
    .onConflictDoNothing();

  if (order.status === 'FILLED') {
    await db.insert(schema.trades).values({
      id: `trd-${now}-${crypto.randomBytes(3).toString('hex')}`,
      userId,
      orderId: order.orderId,
      botId: order.botId ?? null,
      symbol: order.symbol,
      baseAsset: order.baseAsset,
      quoteCurrency: order.quoteCurrency,
      side: order.side,
      price: order.price,
      quantity: order.executedQty || order.quantity,
      quoteAmount: order.totalQuoteAmount,
      feeAmount:
        order.side === 'BUY'
          ? order.executedQty * NOBITEX_FEE_RATE
          : order.totalQuoteAmount * NOBITEX_FEE_RATE,
      realizedPnlQuote: options?.realizedPnlQuote ?? null,
      mode: 'live',
      executedAt: now,
    });
  }
}

export async function cancelPaperOrder(userId: string, orderId: string): Promise<SpotOrder> {
  return withTransaction(async (tx) => {
    const rows = await tx
      .select()
      .from(schema.orders)
      .where(and(eq(schema.orders.orderId, orderId), eq(schema.orders.userId, userId)))
      .limit(1);
    const order = rows[0];
    if (!order) {
      throw new Error('سفارش مورد نظر یافت نشد.');
    }
    if (order.status !== 'NEW') {
      throw new Error('فقط سفارش‌های باز قابل لغو هستند.');
    }

    const updated = await tx
      .update(schema.orders)
      .set({ status: 'CANCELED', updatedAt: Date.now() })
      .where(and(eq(schema.orders.orderId, orderId), eq(schema.orders.status, 'NEW')))
      .returning();

    if (updated.length === 0) {
      throw new Error('فقط سفارش‌های باز قابل لغو هستند.');
    }

    if (order.side === 'BUY') {
      await upsertPaperBalanceInTx(tx, userId, order.quoteCurrency, order.price * order.quantity);
    } else {
      await upsertPaperBalanceInTx(tx, userId, order.baseAsset, order.quantity);
    }

    return mapOrderRow(updated[0]);
  });
}

export async function matchPaperLimitOrders(
  symbol: string,
  marketPrice: number,
  userId?: string
): Promise<void> {
  if (marketPrice <= 0) return;
  const db = getDb();
  const conditions = [
    eq(schema.orders.symbol, symbol.toUpperCase()),
    eq(schema.orders.mode, 'paper'),
    eq(schema.orders.status, 'NEW'),
    eq(schema.orders.type, 'LIMIT'),
  ];
  if (userId) {
    conditions.push(eq(schema.orders.userId, userId));
  }

  const openLimits = await db
    .select()
    .from(schema.orders)
    .where(and(...conditions));

  for (const ord of openLimits) {
    const canFillBuy = ord.side === 'BUY' && marketPrice <= ord.price;
    const canFillSell = ord.side === 'SELL' && marketPrice >= ord.price;
    if (!canFillBuy && !canFillSell) continue;

    const filledOrder = await withTransaction(async (tx) => {
      const now = Date.now();
      const updated = await tx
        .update(schema.orders)
        .set({
          status: 'FILLED',
          executedQty: ord.quantity,
          updatedAt: now,
        })
        .where(and(eq(schema.orders.orderId, ord.orderId), eq(schema.orders.status, 'NEW')))
        .returning();
      if (updated.length === 0) return null;

      let feeAmount = 0;
      if (ord.side === 'BUY') {
        feeAmount = ord.quantity * NOBITEX_FEE_RATE;
        await upsertPaperBalanceInTx(
          tx,
          ord.userId,
          ord.baseAsset,
          ord.quantity * (1 - NOBITEX_FEE_RATE)
        );
      } else {
        const notional = ord.quantity * ord.price;
        feeAmount = notional * NOBITEX_FEE_RATE;
        await upsertPaperBalanceInTx(
          tx,
          ord.userId,
          ord.quoteCurrency,
          notional * (1 - NOBITEX_FEE_RATE)
        );
      }

      await tx.insert(schema.trades).values({
        id: `trd-${now}-${crypto.randomBytes(3).toString('hex')}`,
        userId: ord.userId,
        orderId: ord.orderId,
        botId: ord.botId ?? null,
        symbol: ord.symbol,
        baseAsset: ord.baseAsset,
        quoteCurrency: ord.quoteCurrency,
        side: ord.side,
        price: ord.price,
        quantity: ord.quantity,
        quoteAmount: ord.totalQuoteAmount,
        feeAmount,
        realizedPnlQuote: null,
        mode: 'paper',
        executedAt: now,
      });

      return mapOrderRow(updated[0]);
    });

    if (filledOrder) {
      void notifyTelegramSpotOrder(ord.userId, filledOrder, 'FILLED');
    }
  }
}

export async function computePortfolioPerformance(input: {
  userId: string;
  balances: SpotBalance[];
  markets: UnifiedMarketTicker[];
  usdtTomanRate: number;
  mode: ExecutionMode;
}): Promise<PortfolioPerformanceSummary> {
  const db = getDb();
  const rate = input.usdtTomanRate > 0 ? input.usdtTomanRate : 1;
  const marketMap = new Map<string, UnifiedMarketTicker>();
  for (const m of input.markets) {
    marketMap.set(m.baseAsset.toUpperCase(), m);
  }

  const [orderRows, overrideRows] = await Promise.all([
    db
      .select()
      .from(schema.orders)
      .where(
        and(
          eq(schema.orders.userId, input.userId),
          eq(schema.orders.mode, input.mode),
          eq(schema.orders.status, 'FILLED')
        )
      ),
    db
      .select()
      .from(schema.costBasisOverrides)
      .where(
        and(
          eq(schema.costBasisOverrides.userId, input.userId),
          eq(schema.costBasisOverrides.mode, input.mode)
        )
      ),
  ]);

  const ledger = new Map<string, { qty: number; costToman: number; costUsdt: number }>();
  const chronologicalOrders = orderRows.slice().sort((a, b) => a.createdAt - b.createdAt);

  for (const ord of chronologicalOrders) {
    const asset = ord.baseAsset.toUpperCase();
    const cur = ledger.get(asset) || { qty: 0, costToman: 0, costUsdt: 0 };
    const unitToman = ord.quoteCurrency === 'IRT' ? ord.price : ord.price * rate;
    const unitUsdt = ord.quoteCurrency === 'USDT' ? ord.price : ord.price / rate;

    if (ord.side === 'BUY') {
      const receivedQty = ord.quantity * (1 - NOBITEX_FEE_RATE);
      cur.qty += receivedQty;
      cur.costToman += ord.quantity * unitToman;
      cur.costUsdt += ord.quantity * unitUsdt;
      ledger.set(asset, cur);
    } else if (ord.side === 'SELL' && cur.qty > 0) {
      const remainingRatio = Math.max(0, (cur.qty - ord.quantity) / cur.qty);
      cur.qty = Math.max(0, cur.qty - ord.quantity);
      cur.costToman *= remainingRatio;
      cur.costUsdt *= remainingRatio;
      ledger.set(asset, cur);
    }
  }

  const overrideMap = new Map(overrideRows.map((o) => [o.asset.toUpperCase(), o]));

  const totalCurrentToman = input.balances.reduce((s, b) => s + b.tomanValue, 0);
  const totalCurrentUsdt = input.balances.reduce((s, b) => s + b.usdtValue, 0);
  const cashToman =
    (input.balances.find((b) => b.asset === 'IRT')?.tomanValue || 0) +
    (input.balances.find((b) => b.asset === 'USDT')?.tomanValue || 0);
  const cashUsdt =
    (input.balances.find((b) => b.asset === 'IRT')?.usdtValue || 0) +
    (input.balances.find((b) => b.asset === 'USDT')?.usdtValue || 0);

  const assets: PortfolioAssetPerformance[] = [];
  for (const bal of input.balances) {
    const asset = bal.asset.toUpperCase();
    if (asset === 'IRT' || asset === 'USDT' || bal.total <= 0.0000001) continue;

    const ticker = marketMap.get(asset);
    const currentPriceToman =
      ticker?.priceToman ?? (bal.total > 0 ? bal.tomanValue / bal.total : 0);
    const currentPriceUsdt =
      ticker?.priceUsdt ?? (bal.total > 0 ? bal.usdtValue / bal.total : 0);

    const override = overrideMap.get(asset);
    let avgBuyPriceToman = currentPriceToman;
    let avgBuyPriceUsdt = currentPriceUsdt;
    let source: CostBasisSource = 'ESTIMATED';

    const ledgerEntry = ledger.get(asset);
    if (override && override.priceToman > 0) {
      avgBuyPriceToman = override.priceToman;
      avgBuyPriceUsdt = override.priceUsdt;
      source = 'MANUAL';
    } else if (input.mode === 'paper' && ledgerEntry && ledgerEntry.qty > 0) {
      avgBuyPriceToman = ledgerEntry.costToman / ledgerEntry.qty;
      avgBuyPriceUsdt = ledgerEntry.costUsdt / ledgerEntry.qty;
      source = 'ORDERS';
    } else if (ticker) {
      const denom = 1 + ticker.change24hPercent / 100;
      const safeDenom = denom > 0.05 ? denom : 1;
      avgBuyPriceToman = currentPriceToman / safeDenom;
      avgBuyPriceUsdt = currentPriceUsdt / safeDenom;
      source = 'ESTIMATED';
    }

    const costBasisToman = bal.total * avgBuyPriceToman;
    const costBasisUsdt = bal.total * avgBuyPriceUsdt;
    const currentValueToman = bal.tomanValue;
    const currentValueUsdt = bal.usdtValue;
    const pnlToman = currentValueToman - costBasisToman;
    const pnlUsdt = currentValueUsdt - costBasisUsdt;
    const pnlPercentToman = costBasisToman > 0 ? (pnlToman / costBasisToman) * 100 : 0;
    const pnlPercentUsdt = costBasisUsdt > 0 ? (pnlUsdt / costBasisUsdt) * 100 : 0;

    assets.push({
      asset,
      persianName: bal.persianName || ticker?.persianName || getPersianCoinName(asset),
      quantity: bal.total,
      avgBuyPriceToman,
      avgBuyPriceUsdt,
      currentPriceToman,
      currentPriceUsdt,
      costBasisToman,
      costBasisUsdt,
      currentValueToman,
      currentValueUsdt,
      pnlToman,
      pnlUsdt,
      pnlPercentToman,
      pnlPercentUsdt,
      source,
    });
  }

  const cryptoCurrentToman = assets.reduce((s, a) => s + a.currentValueToman, 0);
  const cryptoCurrentUsdt = assets.reduce((s, a) => s + a.currentValueUsdt, 0);
  const cryptoCostBasisToman = assets.reduce((s, a) => s + a.costBasisToman, 0);
  const cryptoCostBasisUsdt = assets.reduce((s, a) => s + a.costBasisUsdt, 0);
  const cryptoPnlToman = cryptoCurrentToman - cryptoCostBasisToman;
  const cryptoPnlUsdt = cryptoCurrentUsdt - cryptoCostBasisUsdt;
  const cryptoPnlPercentToman =
    cryptoCostBasisToman > 0 ? (cryptoPnlToman / cryptoCostBasisToman) * 100 : 0;
  const cryptoPnlPercentUsdt =
    cryptoCostBasisUsdt > 0 ? (cryptoPnlUsdt / cryptoCostBasisUsdt) * 100 : 0;

  return {
    mode: input.mode,
    totalCurrentToman,
    totalCurrentUsdt,
    cashToman,
    cashUsdt,
    cryptoCurrentToman,
    cryptoCurrentUsdt,
    cryptoCostBasisToman,
    cryptoCostBasisUsdt,
    cryptoPnlToman,
    cryptoPnlUsdt,
    cryptoPnlPercentToman,
    cryptoPnlPercentUsdt,
    assets,
  };
}

// ===========================================================================
// Price Alerts (Strictly Per User)
// ===========================================================================
export async function getPriceAlerts(userId: string): Promise<PriceAlert[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.priceAlerts)
    .where(eq(schema.priceAlerts.userId, userId))
    .orderBy(desc(schema.priceAlerts.createdAt));

  return rows.map(mapAlertRow).sort((a, b) => {
    if (a.status !== b.status) return a.status === 'ACTIVE' ? -1 : 1;
    return b.createdAt - a.createdAt;
  });
}

export async function createPriceAlert(
  userId: string,
  input: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    condition: PriceAlertCondition;
    targetPrice: number;
    createdPrice: number;
    persianName?: string;
    sendTelegram?: boolean;
    note?: string;
  }
): Promise<PriceAlert> {
  const baseAsset = input.baseAsset.toUpperCase().trim();
  const quoteCurrency: QuoteCurrency = input.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
  if (!baseAsset) throw new Error('نام ارز الزامی است.');
  if (!Number.isFinite(input.targetPrice) || input.targetPrice <= 0) {
    throw new Error('قیمت هدف باید بزرگ‌تر از صفر باشد.');
  }
  if (input.condition !== 'ABOVE' && input.condition !== 'BELOW') {
    throw new Error('شرط هشدار نامعتبر است.');
  }

  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const now = Date.now();
  const alreadyHit =
    input.createdPrice > 0 &&
    ((input.condition === 'ABOVE' && input.createdPrice >= input.targetPrice) ||
      (input.condition === 'BELOW' && input.createdPrice <= input.targetPrice));

  const alert: PriceAlert = {
    id: `alert-${now}-${crypto.randomBytes(3).toString('hex')}`,
    baseAsset,
    persianName: input.persianName || getPersianCoinName(baseAsset),
    quoteCurrency,
    symbol: `${baseAsset}${quoteCurrency}`,
    condition: input.condition,
    targetPrice: input.targetPrice,
    createdPrice: input.createdPrice,
    status: alreadyHit ? 'TRIGGERED' : 'ACTIVE',
    sendTelegram: input.sendTelegram !== false,
    note: input.note?.trim() || undefined,
    createdAt: now,
    triggeredAt: alreadyHit ? now : undefined,
    triggeredPrice: alreadyHit ? input.createdPrice : undefined,
  };

  await db.insert(schema.priceAlerts).values({
    id: alert.id,
    userId,
    baseAsset: alert.baseAsset,
    persianName: alert.persianName,
    quoteCurrency: alert.quoteCurrency,
    symbol: alert.symbol,
    condition: alert.condition,
    targetPrice: alert.targetPrice,
    createdPrice: alert.createdPrice,
    status: alert.status,
    sendTelegram: alert.sendTelegram !== false,
    note: alert.note ?? null,
    createdAt: alert.createdAt,
    triggeredAt: alert.triggeredAt ?? null,
    triggeredPrice: alert.triggeredPrice ?? null,
  });

  if (alreadyHit && alert.sendTelegram !== false) {
    void notifyTelegramPriceAlert(userId, alert);
  }
  return alert;
}

export async function rearmPriceAlert(userId: string, alertId: string): Promise<PriceAlert> {
  const db = getDb();
  const [updated] = await db
    .update(schema.priceAlerts)
    .set({
      status: 'ACTIVE',
      triggeredAt: null,
      triggeredPrice: null,
    })
    .where(and(eq(schema.priceAlerts.id, alertId), eq(schema.priceAlerts.userId, userId)))
    .returning();

  if (!updated) throw new Error('هشدار قیمت یافت نشد.');
  return mapAlertRow(updated);
}

export async function deletePriceAlert(userId: string, alertId: string): Promise<void> {
  const db = getDb();
  await db
    .delete(schema.priceAlerts)
    .where(and(eq(schema.priceAlerts.id, alertId), eq(schema.priceAlerts.userId, userId)));
}

export async function evaluatePriceAlerts(
  markets: UnifiedMarketTicker[],
  userId?: string
): Promise<PriceAlert[]> {
  const db = getDb();
  const conditions = [eq(schema.priceAlerts.status, 'ACTIVE')];
  if (userId) conditions.push(eq(schema.priceAlerts.userId, userId));

  const activeRows = await db
    .select()
    .from(schema.priceAlerts)
    .where(and(...conditions));
  if (activeRows.length === 0) return [];

  const marketMap = new Map<string, UnifiedMarketTicker>();
  for (const m of markets) {
    marketMap.set(m.baseAsset.toUpperCase(), m);
  }

  const newlyTriggered: PriceAlert[] = [];
  const now = Date.now();

  for (const row of activeRows) {
    const m = marketMap.get(row.baseAsset.toUpperCase());
    if (!m) continue;
    const currentPrice = row.quoteCurrency === 'IRT' ? m.priceToman : m.priceUsdt;
    if (currentPrice <= 0) continue;

    const hit =
      (row.condition === 'ABOVE' && currentPrice >= row.targetPrice) ||
      (row.condition === 'BELOW' && currentPrice <= row.targetPrice);
    if (!hit) continue;

    const [updated] = await db
      .update(schema.priceAlerts)
      .set({
        status: 'TRIGGERED',
        triggeredAt: now,
        triggeredPrice: currentPrice,
      })
      .where(and(eq(schema.priceAlerts.id, row.id), eq(schema.priceAlerts.status, 'ACTIVE')))
      .returning();

    if (!updated) continue;
    const mapped = mapAlertRow(updated);
    newlyTriggered.push(mapped);
    if (mapped.sendTelegram !== false) {
      void notifyTelegramPriceAlert(row.userId, mapped);
    }
  }

  return newlyTriggered;
}

// ===========================================================================
// Periodic Price Reporters (Strictly Per User)
// ===========================================================================
function isSafeWebhookUrl(raw: string): boolean {
  try {
    const parsed = new URL(raw);
    if (parsed.protocol !== 'https:') return false;
    const host = parsed.hostname.toLowerCase();
    if (
      host === 'localhost' ||
      host === '127.0.0.1' ||
      host === '::1' ||
      host.startsWith('10.') ||
      host.startsWith('192.168.') ||
      host.startsWith('169.254.') ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(host) ||
      host.endsWith('.internal') ||
      host.endsWith('.local')
    ) {
      return false;
    }
    return true;
  } catch {
    return false;
  }
}

async function dispatchWatcherWebhook(
  watcher: PeriodicPriceWatcher,
  pulse: PricePulseNotification
): Promise<void> {
  if (!watcher.webhookUrl || !isSafeWebhookUrl(watcher.webhookUrl)) return;
  const priceLine =
    pulse.quoteMode === 'IRT'
      ? `${Math.round(pulse.priceToman).toLocaleString('en-US')} تومان`
      : pulse.quoteMode === 'USDT'
        ? `$${pulse.priceUsdt.toLocaleString('en-US', { maximumFractionDigits: 6 })} USDT`
        : `${Math.round(pulse.priceToman).toLocaleString('en-US')} تومان ($${pulse.priceUsdt.toLocaleString(
            'en-US',
            { maximumFractionDigits: 6 }
          )})`;

  const text = `📊 قیمت لحظه‌ای ${pulse.persianName} (${pulse.baseAsset}) - AI NobiBot (ainobibot.ir)\n💰 قیمت: ${priceLine}\n📈 تغییر ۲۴ساعته: ${
    pulse.change24hPercent >= 0 ? '+' : ''
  }${pulse.change24hPercent.toFixed(2)}%`;

  try {
    await fetch(watcher.webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        message: text,
        baseAsset: pulse.baseAsset,
        persianName: pulse.persianName,
        priceToman: pulse.priceToman,
        priceUsdt: pulse.priceUsdt,
        change24hPercent: pulse.change24hPercent,
        sentAt: pulse.sentAt,
      }),
      signal: AbortSignal.timeout(5000),
    });
  } catch {
    // Non-blocking external webhook
  }
}

export async function getPriceWatchers(userId: string): Promise<PeriodicPriceWatcher[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.priceWatchers)
    .where(eq(schema.priceWatchers.userId, userId));

  return rows.map(mapWatcherRow).sort((a, b) => {
    if (a.status !== b.status) return a.status === 'ACTIVE' ? -1 : 1;
    return b.createdAt - a.createdAt;
  });
}

export async function getPricePulses(userId: string): Promise<PricePulseNotification[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.notifications)
    .where(eq(schema.notifications.userId, userId))
    .orderBy(desc(schema.notifications.sentAt))
    .limit(60);
  return rows.map(mapPulseRow);
}

export async function createPriceWatcher(
  userId: string,
  input: {
    baseAsset: string;
    persianName?: string;
    quoteMode?: PriceReporterQuoteMode;
    intervalMinutes: number;
    notifyBrowser?: boolean;
    playSound?: boolean;
    sendTelegram?: boolean;
    webhookUrl?: string;
    initialMarket?: UnifiedMarketTicker | null;
  }
): Promise<{ watcher: PeriodicPriceWatcher; pulse?: PricePulseNotification }> {
  const baseAsset = String(input.baseAsset || '').toUpperCase().trim();
  if (!baseAsset) throw new Error('نام ارز دیجیتال الزامی است.');

  const intervalMinutes = Math.round(Number(input.intervalMinutes));
  if (!Number.isFinite(intervalMinutes) || intervalMinutes < 1 || intervalMinutes > 1440) {
    throw new Error('بازه زمانی باید بین ۱ تا ۱۴۴۰ دقیقه باشد.');
  }

  const quoteMode: PriceReporterQuoteMode =
    input.quoteMode === 'IRT' || input.quoteMode === 'USDT' ? input.quoteMode : 'BOTH';

  const cleanWebhook = input.webhookUrl?.trim() || undefined;
  if (cleanWebhook && !isSafeWebhookUrl(cleanWebhook)) {
    throw new Error('آدرس وب‌هوک باید معتبر و با پروتکل https:// باشد.');
  }

  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const now = Date.now();
  const persianName = input.persianName || getPersianCoinName(baseAsset);
  const priceToman = input.initialMarket?.priceToman ?? 0;
  const priceUsdt = input.initialMarket?.priceUsdt ?? 0;
  const change24h = input.initialMarket?.change24hPercent ?? 0;

  const watcher: PeriodicPriceWatcher = {
    id: `watch-${now}-${crypto.randomBytes(3).toString('hex')}`,
    baseAsset,
    persianName,
    quoteMode,
    intervalMinutes,
    status: 'ACTIVE',
    notifyBrowser: input.notifyBrowser !== false,
    playSound: input.playSound !== false,
    sendTelegram: input.sendTelegram !== false,
    webhookUrl: cleanWebhook,
    lastPriceToman: priceToman > 0 ? priceToman : undefined,
    lastPriceUsdt: priceUsdt > 0 ? priceUsdt : undefined,
    lastChange24h: input.initialMarket ? change24h : undefined,
    sentCount: input.initialMarket ? 1 : 0,
    createdAt: now,
    lastSentAt: input.initialMarket ? now : null,
    nextSendAt: now + intervalMinutes * 60_000,
  };

  await db.insert(schema.priceWatchers).values({
    id: watcher.id,
    userId,
    baseAsset: watcher.baseAsset,
    persianName: watcher.persianName,
    quoteMode: watcher.quoteMode,
    intervalMinutes: watcher.intervalMinutes,
    status: watcher.status,
    notifyBrowser: watcher.notifyBrowser,
    playSound: watcher.playSound,
    sendTelegram: watcher.sendTelegram !== false,
    webhookUrl: watcher.webhookUrl ?? null,
    lastPriceToman: watcher.lastPriceToman ?? null,
    lastPriceUsdt: watcher.lastPriceUsdt ?? null,
    lastChange24h: watcher.lastChange24h ?? null,
    sentCount: watcher.sentCount,
    createdAt: watcher.createdAt,
    lastSentAt: watcher.lastSentAt,
    nextSendAt: watcher.nextSendAt,
  });

  let pulse: PricePulseNotification | undefined;
  if (input.initialMarket && (priceToman > 0 || priceUsdt > 0)) {
    pulse = {
      id: `pulse-${now}-${crypto.randomBytes(3).toString('hex')}`,
      watcherId: watcher.id,
      baseAsset,
      persianName,
      quoteMode,
      priceToman,
      priceUsdt,
      change24hPercent: change24h,
      intervalMinutes,
      sentAt: now,
    };
    await db.insert(schema.notifications).values({
      ...pulse,
      userId,
      kind: 'PRICE_PULSE',
    });
    if (watcher.sendTelegram !== false) {
      void notifyTelegramPricePulse(userId, pulse);
    }
    if (watcher.webhookUrl) {
      void dispatchWatcherWebhook(watcher, pulse);
    }
  }

  return { watcher, pulse };
}

export async function togglePriceWatcherStatus(
  userId: string,
  watcherId: string,
  status: 'ACTIVE' | 'PAUSED'
): Promise<PeriodicPriceWatcher> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.priceWatchers)
    .where(and(eq(schema.priceWatchers.id, watcherId), eq(schema.priceWatchers.userId, userId)))
    .limit(1);
  const existing = rows[0];
  if (!existing) throw new Error('تنظیم ارسال دوره‌ای قیمت یافت نشد.');

  const nextSendAt =
    status === 'ACTIVE'
      ? Date.now() + existing.intervalMinutes * 60_000
      : existing.nextSendAt;

  const [updated] = await db
    .update(schema.priceWatchers)
    .set({ status, nextSendAt })
    .where(and(eq(schema.priceWatchers.id, watcherId), eq(schema.priceWatchers.userId, userId)))
    .returning();
  return mapWatcherRow(updated);
}

export async function deletePriceWatcher(userId: string, watcherId: string): Promise<void> {
  const db = getDb();
  await db
    .delete(schema.priceWatchers)
    .where(and(eq(schema.priceWatchers.id, watcherId), eq(schema.priceWatchers.userId, userId)));
}

export async function triggerPriceWatcherNow(
  userId: string,
  watcherId: string,
  markets: UnifiedMarketTicker[]
): Promise<PricePulseNotification> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.priceWatchers)
    .where(and(eq(schema.priceWatchers.id, watcherId), eq(schema.priceWatchers.userId, userId)))
    .limit(1);
  const watcherRow = rows[0];
  if (!watcherRow) throw new Error('تنظیم ارسال دوره‌ای قیمت یافت نشد.');

  const m = markets.find((x) => x.baseAsset.toUpperCase() === watcherRow.baseAsset.toUpperCase());
  if (!m) throw new Error('قیمت لحظه‌ای این ارز در نوبیتکس در دسترس نیست.');

  const now = Date.now();
  const [updated] = await db
    .update(schema.priceWatchers)
    .set({
      lastPriceToman: m.priceToman,
      lastPriceUsdt: m.priceUsdt,
      lastChange24h: m.change24hPercent,
      sentCount: watcherRow.sentCount + 1,
      lastSentAt: now,
      nextSendAt: now + watcherRow.intervalMinutes * 60_000,
    })
    .where(eq(schema.priceWatchers.id, watcherId))
    .returning();

  const pulse: PricePulseNotification = {
    id: `pulse-${now}-${crypto.randomBytes(3).toString('hex')}`,
    watcherId: watcherRow.id,
    baseAsset: watcherRow.baseAsset,
    persianName: watcherRow.persianName,
    quoteMode: watcherRow.quoteMode as PriceReporterQuoteMode,
    priceToman: m.priceToman,
    priceUsdt: m.priceUsdt,
    change24hPercent: m.change24hPercent,
    intervalMinutes: watcherRow.intervalMinutes,
    sentAt: now,
  };

  await db.insert(schema.notifications).values({
    ...pulse,
    userId,
    kind: 'PRICE_PULSE',
  });

  const watcher = mapWatcherRow(updated);
  if (watcher.sendTelegram !== false) {
    void notifyTelegramPricePulse(userId, pulse);
  }
  if (watcher.webhookUrl) {
    void dispatchWatcherWebhook(watcher, pulse);
  }
  return pulse;
}

export async function evaluatePriceWatchers(
  markets: UnifiedMarketTicker[],
  userId?: string
): Promise<PricePulseNotification[]> {
  const db = getDb();
  const now = Date.now();
  const conditions = [
    eq(schema.priceWatchers.status, 'ACTIVE'),
    lte(schema.priceWatchers.nextSendAt, now),
  ];
  if (userId) conditions.push(eq(schema.priceWatchers.userId, userId));

  const dueWatchers = await db
    .select()
    .from(schema.priceWatchers)
    .where(and(...conditions));

  if (dueWatchers.length === 0) return [];

  const marketMap = new Map<string, UnifiedMarketTicker>();
  for (const m of markets) {
    marketMap.set(m.baseAsset.toUpperCase(), m);
  }

  const emitted: PricePulseNotification[] = [];
  for (const row of dueWatchers) {
    const m = marketMap.get(row.baseAsset.toUpperCase());
    if (!m) continue;

    const [updated] = await db
      .update(schema.priceWatchers)
      .set({
        lastPriceToman: m.priceToman,
        lastPriceUsdt: m.priceUsdt,
        lastChange24h: m.change24hPercent,
        sentCount: row.sentCount + 1,
        lastSentAt: now,
        nextSendAt: now + row.intervalMinutes * 60_000,
      })
      .where(and(eq(schema.priceWatchers.id, row.id), lte(schema.priceWatchers.nextSendAt, now)))
      .returning();

    if (!updated) continue;

    const pulse: PricePulseNotification = {
      id: `pulse-${now}-${crypto.randomBytes(3).toString('hex')}`,
      watcherId: row.id,
      baseAsset: row.baseAsset,
      persianName: row.persianName,
      quoteMode: row.quoteMode as PriceReporterQuoteMode,
      priceToman: m.priceToman,
      priceUsdt: m.priceUsdt,
      change24hPercent: m.change24hPercent,
      intervalMinutes: row.intervalMinutes,
      sentAt: now,
    };

    await db.insert(schema.notifications).values({
      ...pulse,
      userId: row.userId,
      kind: 'PRICE_PULSE',
    });

    emitted.push(pulse);
    const watcher = mapWatcherRow(updated);
    if (watcher.sendTelegram !== false) {
      void notifyTelegramPricePulse(row.userId, pulse);
    }
    if (watcher.webhookUrl) {
      void dispatchWatcherWebhook(watcher, pulse);
    }
  }

  return emitted;
}

// ===========================================================================
// Future Ideas Backlog (Strictly Per User)
// ===========================================================================
export async function getFeatureIdeas(userId: string): Promise<FeatureIdeaItem[]> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.featureIdeas)
    .where(eq(schema.featureIdeas.userId, userId))
    .orderBy(desc(schema.featureIdeas.createdAt));

  return rows.map((r) => ({
    id: r.id,
    title: r.title,
    description: r.description,
    category: r.category as FeatureIdeaCategory,
    status: r.status as FeatureIdeaStatus,
    createdAt: r.createdAt,
  }));
}

export async function createFeatureIdea(
  userId: string,
  input: {
    title: string;
    description?: string;
    category?: FeatureIdeaCategory;
  }
): Promise<FeatureIdeaItem> {
  const title = String(input.title || '').trim();
  if (!title) throw new Error('عنوان ایده یا قابلیت جدید الزامی است.');

  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const validCats: FeatureIdeaCategory[] = ['TRADING', 'ALERTS', 'AI', 'BOT', 'GENERAL'];
  const category: FeatureIdeaCategory = validCats.includes(input.category as FeatureIdeaCategory)
    ? (input.category as FeatureIdeaCategory)
    : 'GENERAL';

  const idea: FeatureIdeaItem = {
    id: `idea-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`,
    title: title.slice(0, 140),
    description: String(input.description || '').trim().slice(0, 1000),
    category,
    status: 'IDEA',
    createdAt: Date.now(),
  };

  await db.insert(schema.featureIdeas).values({
    ...idea,
    userId,
  });

  return idea;
}

export async function updateFeatureIdeaStatus(
  userId: string,
  ideaId: string,
  status: FeatureIdeaStatus
): Promise<FeatureIdeaItem> {
  if (status !== 'IDEA' && status !== 'PLANNED' && status !== 'DONE') {
    throw new Error('وضعیت نامعتبر است.');
  }
  const db = getDb();
  const [updated] = await db
    .update(schema.featureIdeas)
    .set({ status })
    .where(and(eq(schema.featureIdeas.id, ideaId), eq(schema.featureIdeas.userId, userId)))
    .returning();

  if (!updated) throw new Error('ایده مورد نظر یافت نشد.');
  return {
    id: updated.id,
    title: updated.title,
    description: updated.description,
    category: updated.category as FeatureIdeaCategory,
    status: updated.status as FeatureIdeaStatus,
    createdAt: updated.createdAt,
  };
}

export async function deleteFeatureIdea(userId: string, ideaId: string): Promise<void> {
  const db = getDb();
  await db
    .delete(schema.featureIdeas)
    .where(and(eq(schema.featureIdeas.id, ideaId), eq(schema.featureIdeas.userId, userId)));
}

// ===========================================================================
// Automated Multi-Tenant Trading Bots & Execution Engine
// ===========================================================================
export async function getUserBots(userId: string): Promise<BotStrategyConfig[]> {
  const db = getDb();
  const [botRows, cfgRows] = await Promise.all([
    db
      .select()
      .from(schema.tradingBots)
      .where(eq(schema.tradingBots.userId, userId))
      .orderBy(desc(schema.tradingBots.createdAt)),
    db
      .select()
      .from(schema.botConfigurations)
      .where(eq(schema.botConfigurations.userId, userId)),
  ]);
  const cfgMap = new Map(cfgRows.map((c) => [c.botId, c]));
  return botRows.map((b) => mapBotRowsToConfig(b, cfgMap.get(b.id)));
}

export async function getUserBotById(
  userId: string,
  botId: string
): Promise<BotStrategyConfig | null> {
  const db = getDb();
  const [botRows, cfgRows] = await Promise.all([
    db
      .select()
      .from(schema.tradingBots)
      .where(and(eq(schema.tradingBots.id, botId), eq(schema.tradingBots.userId, userId)))
      .limit(1),
    db
      .select()
      .from(schema.botConfigurations)
      .where(
        and(eq(schema.botConfigurations.botId, botId), eq(schema.botConfigurations.userId, userId))
      )
      .limit(1),
  ]);
  if (!botRows[0]) return null;
  return mapBotRowsToConfig(botRows[0], cfgRows[0]);
}

export async function getAllSystemBots(): Promise<BotStrategyConfig[]> {
  const db = getDb();
  const [botRows, cfgRows] = await Promise.all([
    db.select().from(schema.tradingBots).orderBy(desc(schema.tradingBots.createdAt)),
    db.select().from(schema.botConfigurations),
  ]);
  const cfgMap = new Map(cfgRows.map((c) => [c.botId, c]));
  return botRows.map((b) => mapBotRowsToConfig(b, cfgMap.get(b.id)));
}

export async function getGlobalRuntimeStats() {
  const db = getDb();
  const [bots, alerts, watchers, ideas] = await Promise.all([
    getAllSystemBots(),
    db
      .select({ id: schema.priceAlerts.id })
      .from(schema.priceAlerts)
      .where(eq(schema.priceAlerts.status, 'ACTIVE')),
    db
      .select({ id: schema.priceWatchers.id })
      .from(schema.priceWatchers)
      .where(eq(schema.priceWatchers.status, 'ACTIVE')),
    db.select({ id: schema.featureIdeas.id }).from(schema.featureIdeas),
  ]);
  return {
    bots,
    activeAlertsCount: alerts.length,
    activeWatchersCount: watchers.length,
    ideasCount: ideas.length,
  };
}

export async function getBotLogs(userId: string, botId?: string): Promise<BotExecutionLog[]> {
  const db = getDb();
  const conditions = [eq(schema.tradingLogs.userId, userId)];
  if (botId) conditions.push(eq(schema.tradingLogs.botId, botId));
  const rows = await db
    .select()
    .from(schema.tradingLogs)
    .where(and(...conditions))
    .orderBy(desc(schema.tradingLogs.timestamp))
    .limit(150);
  return rows.map(mapLogRow);
}

export async function createBot(
  userId: string,
  input: Omit<
    BotStrategyConfig,
    'id' | 'ownerId' | 'activePosition' | 'stats' | 'lastCheckedAt' | 'lastSignalSummary' | 'createdAt'
  >
): Promise<BotStrategyConfig> {
  if (input.mode === 'live' && !(await hasActiveExchangeCredentialsForUser(userId))) {
    throw new Error(
      'برای اجرای ربات روی حساب واقعی نوبیتکس، ابتدا توکن API نوبیتکس خود را در بخش «حساب و کلیدهای API» وارد کنید.'
    );
  }
  await ensureUserRecord({ uid: userId });

  const baseAsset = input.baseAsset.toUpperCase().trim();
  const quoteCurrency: QuoteCurrency = input.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
  const symbol = `${baseAsset}${quoteCurrency}`;
  const now = Date.now();
  const id = `bot-${now}-${crypto.randomBytes(3).toString('hex')}`;

  const fundingMode = normalizeBotFundingMode(input.fundingMode);
  const existingBalancePercent = clampBotBalancePercent(input.existingBalancePercent);
  const orderAmount = Number(input.orderAmount || 0);
  if (fundingMode !== 'EXISTING_ASSET' && (!Number.isFinite(orderAmount) || orderAmount <= 0)) {
    throw new Error('مبلغ هر معامله ربات باید بزرگ‌تر از صفر باشد.');
  }

  const isFixed =
    input.strategyKind === 'FIXED_PRICE' ||
    input.entryRules.some((r) => r.type === 'FIXED_BUY_PRICE') ||
    input.exitRules.some((r) => r.type === 'FIXED_SELL_PRICE');

  let normalizedEntryRules = input.entryRules;
  let normalizedExitRules = input.exitRules;
  let fixedBuyPrice = input.targetBuyPrice;
  let fixedSellPrice = input.targetSellPrice;
  let repeatCycle = input.repeatCycle !== false;
  let maxCycles =
    typeof input.maxCycles === 'number' && input.maxCycles > 0 ? Math.floor(input.maxCycles) : null;
  let pollIntervalSeconds =
    typeof input.pollIntervalSeconds === 'number' && Number.isFinite(input.pollIntervalSeconds)
      ? Math.min(300, Math.max(2, Math.round(input.pollIntervalSeconds)))
      : 5;

  if (isFixed) {
    const existingBuy = input.entryRules.find((r) => r.type === 'FIXED_BUY_PRICE');
    const existingSell = input.exitRules.find((r) => r.type === 'FIXED_SELL_PRICE');
    fixedBuyPrice = Number(fixedBuyPrice || existingBuy?.params?.targetPrice || 0);
    fixedSellPrice = Number(fixedSellPrice || existingSell?.params?.targetPrice || 0);
    if (existingBuy?.params?.repeatCycle !== undefined && input.repeatCycle === undefined) {
      repeatCycle = existingBuy.params.repeatCycle !== false;
    }
    if (existingBuy?.params?.maxCycles !== undefined && input.maxCycles === undefined) {
      maxCycles =
        typeof existingBuy.params.maxCycles === 'number' && existingBuy.params.maxCycles > 0
          ? Math.floor(existingBuy.params.maxCycles)
          : null;
    }
    if (existingBuy?.params?.pollSeconds !== undefined && input.pollIntervalSeconds === undefined) {
      pollIntervalSeconds = Math.min(300, Math.max(2, Math.round(Number(existingBuy.params.pollSeconds))));
    }

    if (fundingMode !== 'EXISTING_ASSET' && (!Number.isFinite(fixedBuyPrice) || fixedBuyPrice <= 0)) {
      throw new Error('قیمت هدف خرید باید بزرگ‌تر از صفر باشد.');
    }
    if (!Number.isFinite(fixedSellPrice) || fixedSellPrice <= 0) {
      throw new Error('قیمت هدف فروش باید بزرگ‌تر از صفر باشد.');
    }
    if (fixedBuyPrice > 0 && fixedSellPrice <= fixedBuyPrice) {
      throw new Error('قیمت هدف فروش باید بیشتر از قیمت هدف خرید باشد.');
    }

    normalizedEntryRules = [
      {
        id: existingBuy?.id || `fixed-buy-${now}`,
        type: 'FIXED_BUY_PRICE',
        action: 'BUY',
        enabled: true,
        params: {
          ...(fixedBuyPrice > 0 ? { targetPrice: fixedBuyPrice } : {}),
          repeatCycle,
          maxCycles,
          pollSeconds: pollIntervalSeconds,
        },
      },
    ];
    normalizedExitRules = [
      {
        id: existingSell?.id || `fixed-sell-${now}`,
        type: 'FIXED_SELL_PRICE',
        action: 'SELL',
        enabled: true,
        params: {
          targetPrice: fixedSellPrice,
        },
      },
    ];
  }

  const bot: BotStrategyConfig = {
    ...input,
    id,
    ownerId: userId,
    strategyKind: isFixed ? 'FIXED_PRICE' : 'INDICATOR',
    targetBuyPrice: isFixed && fixedBuyPrice && fixedBuyPrice > 0 ? fixedBuyPrice : undefined,
    targetSellPrice: isFixed ? fixedSellPrice : undefined,
    repeatCycle: isFixed ? repeatCycle : undefined,
    maxCycles: isFixed ? maxCycles : undefined,
    pollIntervalSeconds: isFixed ? pollIntervalSeconds : undefined,
    fundingMode,
    existingBalancePercent,
    orderAmount: Number.isFinite(orderAmount) && orderAmount > 0 ? orderAmount : 0,
    baseAsset,
    quoteCurrency,
    symbol,
    stopLossPercent: isFixed ? 0 : input.stopLossPercent,
    takeProfitPercent: isFixed ? 0 : input.takeProfitPercent,
    trailingStopEnabled: isFixed ? false : input.trailingStopEnabled,
    cooldownMinutes: isFixed ? 0 : input.cooldownMinutes,
    entryRules: normalizedEntryRules,
    exitRules: normalizedExitRules,
    notifyTelegram: input.notifyTelegram !== false,
    activePosition: null,
    stats: {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      realizedPnl: 0,
    },
    lastCheckedAt: null,
    lastSignalSummary:
      input.status === 'RUNNING'
        ? isFixed
          ? fundingMode === 'EXISTING_ASSET'
            ? `فعال · پایش ${existingBalancePercent}٪ موجودی فعلی ${baseAsset} · فروش ≥ ${formatAmountText(
                fixedSellPrice!,
                quoteCurrency
              )}`
            : `فعال · در حال رصد لحظه‌ای (هر ${pollIntervalSeconds} ثانیه) · خرید ≤ ${formatAmountText(
                fixedBuyPrice!,
                quoteCurrency
              )} / فروش ≥ ${formatAmountText(fixedSellPrice!, quoteCurrency)}`
          : fundingMode === 'EXISTING_ASSET'
            ? `فعال · پایش ${existingBalancePercent}٪ موجودی فعلی ${baseAsset}`
            : 'در انتظار اولین بررسی اندیکاتورها'
        : 'متوقف شده',
    createdAt: now,
  };

  await withTransaction(async (tx) => {
    await tx.insert(schema.tradingBots).values({
      id: bot.id,
      userId,
      name: bot.name,
      baseAsset: bot.baseAsset,
      quoteCurrency: bot.quoteCurrency,
      symbol: bot.symbol,
      timeframe: bot.timeframe,
      mode: bot.mode,
      status: bot.status,
      orderAmount: bot.orderAmount,
      activePositionJson: null,
      statsJson: buildPersistedBotStatsJson(bot),
      lastCheckedAt: null,
      lastSignalSummary: bot.lastSignalSummary,
      notifyTelegram: bot.notifyTelegram !== false,
      consecutiveFailures: 0,
      nextRetryAt: null,
      lastError: null,
      createdAt: now,
      updatedAt: now,
    });

    await tx.insert(schema.botConfigurations).values({
      botId: bot.id,
      userId,
      stopLossPercent: bot.stopLossPercent,
      takeProfitPercent: bot.takeProfitPercent,
      trailingStopEnabled: bot.trailingStopEnabled,
      trailingStopPercent: bot.trailingStopPercent,
      cooldownMinutes: bot.cooldownMinutes,
      logicOperator: bot.logicOperator,
      entryRulesJson: bot.entryRules,
      exitRulesJson: bot.exitRules,
      updatedAt: now,
    });
  });

  const createMsg = isFixed
    ? fundingMode === 'EXISTING_ASSET'
      ? `ربات قیمتی «${bot.name}» با استفاده از ${existingBalancePercent}٪ موجودی فعلی ${bot.baseAsset} ایجاد شد (فروش هدف: ${formatAmountText(
          fixedSellPrice!,
          bot.quoteCurrency
        )}).`
      : `ربات قیمتی «${bot.name}» روی بازار ${bot.baseAsset}/${
          bot.quoteCurrency === 'IRT' ? 'تومان' : 'تتر'
        } ایجاد شد (خرید: ${formatAmountText(fixedBuyPrice!, bot.quoteCurrency)} · فروش: ${formatAmountText(
          fixedSellPrice!,
          bot.quoteCurrency
        )} · ${repeatCycle ? 'چرخه تکراری' : 'تک چرخه'}).`
    : `ربات «${bot.name}» روی بازار ${bot.baseAsset}/${
        bot.quoteCurrency === 'IRT' ? 'تومان' : 'تتر'
      } (${bot.timeframe}) ایجاد شد.`;

  await appendLog(userId, {
    botId: bot.id,
    botName: bot.name,
    symbol: bot.symbol,
    quoteCurrency: bot.quoteCurrency,
    event: 'INFO',
    price: 0,
    message: createMsg,
    mode: bot.mode,
  });

  void notifyTelegramBotActivity(userId, {
    bot,
    eventType: 'CREATED',
    title: isFixed ? 'ساخت ربات خرید و فروش قیمتی' : 'ساخت ربات جدید',
    summary: createMsg,
  });

  return bot;
}

export async function updateBotStatus(
  userId: string | null,
  botId: string,
  status: 'RUNNING' | 'PAUSED',
  isAdminOverride = false
): Promise<BotStrategyConfig> {
  const db = getDb();
  const botRows = await db
    .select()
    .from(schema.tradingBots)
    .where(
      isAdminOverride
        ? eq(schema.tradingBots.id, botId)
        : and(eq(schema.tradingBots.id, botId), eq(schema.tradingBots.userId, userId || ''))
    )
    .limit(1);

  const botRow = botRows[0];
  if (!botRow) throw new Error('ربات یافت نشد.');

  if (status === 'RUNNING' && botRow.mode === 'live') {
    const hasCreds = await hasActiveExchangeCredentialsForUser(botRow.userId);
    if (!hasCreds) {
      throw new Error('توکن API صرافی نوبیتکس برای این حساب تنظیم نشده است.');
    }
  }

  const now = Date.now();
  const nextSummary =
    status === 'RUNNING' ? 'فعال — در حال پایش لحظه‌ای بازار نوبیتکس' : 'متوقف شده توسط کاربر';

  const [updatedRow] = await db
    .update(schema.tradingBots)
    .set({
      status,
      lastSignalSummary: nextSummary,
      consecutiveFailures: 0,
      nextRetryAt: null,
      lastError: null,
      updatedAt: now,
    })
    .where(eq(schema.tradingBots.id, botId))
    .returning();

  const cfgRows = await db
    .select()
    .from(schema.botConfigurations)
    .where(eq(schema.botConfigurations.botId, botId))
    .limit(1);

  const bot = mapBotRowsToConfig(updatedRow, cfgRows[0]);
  const statusMsg = status === 'RUNNING' ? 'ربات فعال و وارد چرخه پایش شد.' : 'ربات متوقف شد.';

  await appendLog(botRow.userId, {
    botId: bot.id,
    botName: bot.name,
    symbol: bot.symbol,
    quoteCurrency: bot.quoteCurrency,
    event: 'INFO',
    price: 0,
    message: statusMsg,
    mode: bot.mode,
  });

  void notifyTelegramBotActivity(botRow.userId, {
    bot,
    eventType: status === 'RUNNING' ? 'STARTED' : 'PAUSED',
    title: status === 'RUNNING' ? 'شروع به کار ربات' : 'توقف موقت ربات',
    summary: statusMsg,
  });

  return bot;
}

export async function updateBotMode(
  userId: string,
  botId: string,
  mode: ExecutionMode
): Promise<BotStrategyConfig> {
  const db = getDb();
  const existing = await getUserBotById(userId, botId);
  if (!existing) throw new Error('ربات یافت نشد.');
  if (mode === 'live' && !(await hasActiveExchangeCredentialsForUser(userId))) {
    throw new Error('توکن شخصی صرافی نوبیتکس برای این حساب موجود نیست.');
  }

  const [updated] = await db
    .update(schema.tradingBots)
    .set({ mode, updatedAt: Date.now() })
    .where(and(eq(schema.tradingBots.id, botId), eq(schema.tradingBots.userId, userId)))
    .returning();

  const cfgRows = await db
    .select()
    .from(schema.botConfigurations)
    .where(eq(schema.botConfigurations.botId, botId))
    .limit(1);

  const bot = mapBotRowsToConfig(updated, cfgRows[0]);
  void notifyTelegramBotActivity(userId, {
    bot,
    eventType: 'MODE_CHANGED',
    title: 'تغییر حالت اجرای ربات',
    summary: `حالت اجرای ربات به ${mode === 'live' ? 'حساب واقعی نوبیتکس' : 'حساب تمرینی'} تغییر یافت.`,
  });

  return bot;
}

export async function updateBotTelegramSetting(
  userId: string,
  botId: string,
  notifyTelegram: boolean
): Promise<BotStrategyConfig> {
  const db = getDb();
  const [updated] = await db
    .update(schema.tradingBots)
    .set({ notifyTelegram, updatedAt: Date.now() })
    .where(and(eq(schema.tradingBots.id, botId), eq(schema.tradingBots.userId, userId)))
    .returning();

  if (!updated) throw new Error('ربات یافت نشد.');
  const cfgRows = await db
    .select()
    .from(schema.botConfigurations)
    .where(eq(schema.botConfigurations.botId, botId))
    .limit(1);

  return mapBotRowsToConfig(updated, cfgRows[0]);
}

export async function updateBotFixedTargets(
  userId: string,
  botId: string,
  updates: {
    targetBuyPrice?: number;
    targetSellPrice: number;
    orderAmount?: number;
    repeatCycle?: boolean;
    maxCycles?: number | null;
    pollIntervalSeconds?: number;
    fundingMode?: BotFundingMode;
    existingBalancePercent?: number;
  }
): Promise<BotStrategyConfig> {
  const existing = await getUserBotById(userId, botId);
  if (!existing) throw new Error('ربات یافت نشد.');
  if (!isFixedPriceBot(existing)) {
    throw new Error('این ربات از نوع هدف قیمتی نیست.');
  }

  const nextFundingMode =
    updates.fundingMode !== undefined
      ? normalizeBotFundingMode(updates.fundingMode)
      : normalizeBotFundingMode(existing.fundingMode);
  const nextExistingPercent =
    updates.existingBalancePercent !== undefined
      ? clampBotBalancePercent(updates.existingBalancePercent)
      : clampBotBalancePercent(existing.existingBalancePercent);

  const buyPriceVal = Number(updates.targetBuyPrice ?? existing.targetBuyPrice ?? 0);
  if (nextFundingMode !== 'EXISTING_ASSET' && (!Number.isFinite(buyPriceVal) || buyPriceVal <= 0)) {
    throw new Error('قیمت هدف خرید نامعتبر است.');
  }
  if (!Number.isFinite(updates.targetSellPrice) || updates.targetSellPrice <= 0) {
    throw new Error('قیمت هدف فروش نامعتبر است.');
  }
  if (buyPriceVal > 0 && updates.targetSellPrice <= buyPriceVal) {
    throw new Error('قیمت هدف فروش باید بزرگ‌تر از قیمت هدف خرید باشد.');
  }

  const now = Date.now();
  const nextOrderAmount =
    updates.orderAmount !== undefined && Number.isFinite(updates.orderAmount) && updates.orderAmount >= 0
      ? updates.orderAmount
      : existing.orderAmount;
  const nextRepeat =
    updates.repeatCycle !== undefined ? updates.repeatCycle : existing.repeatCycle !== false;
  const nextMaxCycles =
    updates.maxCycles !== undefined ? updates.maxCycles : existing.maxCycles ?? null;
  const nextPollSec =
    updates.pollIntervalSeconds !== undefined
      ? Math.min(300, Math.max(2, Math.round(updates.pollIntervalSeconds)))
      : existing.pollIntervalSeconds ?? 5;

  const nextEntryRules: StrategyRule[] = [
    {
      id: existing.entryRules[0]?.id || `fixed-buy-${now}`,
      type: 'FIXED_BUY_PRICE',
      action: 'BUY',
      enabled: true,
      params: {
        ...(buyPriceVal > 0 ? { targetPrice: buyPriceVal } : {}),
        repeatCycle: nextRepeat,
        maxCycles: nextMaxCycles,
        pollSeconds: nextPollSec,
      },
    },
  ];
  const nextExitRules: StrategyRule[] = [
    {
      id: existing.exitRules[0]?.id || `fixed-sell-${now}`,
      type: 'FIXED_SELL_PRICE',
      action: 'SELL',
      enabled: true,
      params: {
        targetPrice: updates.targetSellPrice,
      },
    },
  ];

  const summary =
    nextFundingMode === 'EXISTING_ASSET'
      ? `تنظیمات به‌روزرسانی شد · استفاده از ${nextExistingPercent}٪ موجودی فعلی ${existing.baseAsset} · فروش: ${formatAmountText(
          updates.targetSellPrice,
          existing.quoteCurrency
        )}`
      : `قیمت‌های هدف به‌روزرسانی شد · خرید: ${formatAmountText(
          buyPriceVal,
          existing.quoteCurrency
        )} · فروش: ${formatAmountText(updates.targetSellPrice, existing.quoteCurrency)}`;

  await withTransaction(async (tx) => {
    await tx
      .update(schema.tradingBots)
      .set({
        orderAmount: nextOrderAmount,
        statsJson: buildPersistedBotStatsJson({
          stats: existing.stats,
          fundingMode: nextFundingMode,
          existingBalancePercent: nextExistingPercent,
        }),
        lastSignalSummary: summary,
        updatedAt: now,
      })
      .where(and(eq(schema.tradingBots.id, botId), eq(schema.tradingBots.userId, userId)));

    await tx
      .update(schema.botConfigurations)
      .set({
        entryRulesJson: nextEntryRules,
        exitRulesJson: nextExitRules,
        stopLossPercent: 0,
        takeProfitPercent: 0,
        trailingStopEnabled: false,
        cooldownMinutes: 0,
        updatedAt: now,
      })
      .where(and(eq(schema.botConfigurations.botId, botId), eq(schema.botConfigurations.userId, userId)));
  });

  const updated = await getUserBotById(userId, botId);
  if (!updated) throw new Error('خطا در بازیابی ربات پس از ویرایش');

  await appendLog(userId, {
    botId: updated.id,
    botName: updated.name,
    symbol: updated.symbol,
    quoteCurrency: updated.quoteCurrency,
    event: 'INFO',
    price: 0,
    message: summary,
    mode: updated.mode,
  });

  return updated;
}

export async function deleteBot(userId: string, botId: string): Promise<void> {
  const existing = await getUserBotById(userId, botId);
  if (!existing) return;
  const db = getDb();
  await db
    .delete(schema.tradingBots)
    .where(and(eq(schema.tradingBots.id, botId), eq(schema.tradingBots.userId, userId)));

  void notifyTelegramBotActivity(userId, {
    bot: existing,
    eventType: 'DELETED',
    title: 'حذف ربات معامله‌گر',
    summary: `ربات «${existing.name}» از لیست ربات‌ها حذف شد.`,
  });
}

export async function emergencyStopUserBots(userId: string): Promise<number> {
  const db = getDb();
  const updated = await db
    .update(schema.tradingBots)
    .set({
      status: 'PAUSED',
      lastSignalSummary: 'توقف اضطراری توسط کاربر',
      updatedAt: Date.now(),
    })
    .where(and(eq(schema.tradingBots.userId, userId), eq(schema.tradingBots.status, 'RUNNING')))
    .returning();

  for (const row of updated) {
    await appendLog(userId, {
      botId: row.id,
      botName: row.name,
      symbol: row.symbol,
      quoteCurrency: row.quoteCurrency as QuoteCurrency,
      event: 'INFO',
      price: 0,
      message: 'توقف اضطراری (Kill Switch) برای ربات اجرا شد.',
      mode: row.mode as ExecutionMode,
    });
  }
  const stoppedProfitBots = await emergencyStopUserProfitBots(userId);
  let stoppedSmartBots = 0;
  try {
    const [smartMgr, aiCycle] = await Promise.all([
      import('./smartBotManager.ts'),
      import('./aiCycleProEngine.ts'),
    ]);
    const [stoppedGrid, stoppedDca, stoppedAiCycle] = await Promise.all([
      smartMgr.emergencyStopUserGridBots(userId),
      smartMgr.emergencyStopUserDcaBots(userId),
      aiCycle.emergencyStopUserAiCycleProBots(userId),
    ]);
    stoppedSmartBots = stoppedGrid + stoppedDca + stoppedAiCycle;
  } catch {
    // Non-blocking fallback
  }
  return updated.length + stoppedProfitBots + stoppedSmartBots;
}

export async function emergencyStopAllBots(actorEmail: string): Promise<number> {
  const db = getDb();
  const updated = await db
    .update(schema.tradingBots)
    .set({
      status: 'PAUSED',
      lastSignalSummary: `توقف اضطراری سراسری توسط مدیر (${actorEmail})`,
      updatedAt: Date.now(),
    })
    .where(eq(schema.tradingBots.status, 'RUNNING'))
    .returning();

  const stoppedProfitBots = await emergencyStopAllProfitBots(actorEmail);
  let stoppedSmartBots = 0;
  try {
    const now = Date.now();
    const [gRes, dRes, acRes] = await Promise.all([
      db
        .update(schema.gridBots)
        .set({
          isActive: false,
          status: 'STOPPED',
          lastStatusReason: `توقف اضطراری سراسری (${actorEmail})`,
          updatedAt: now,
        })
        .where(eq(schema.gridBots.isActive, true))
        .returning(),
      db
        .update(schema.dcaBots)
        .set({
          isActive: false,
          status: 'STOPPED',
          lastStatusReason: `توقف اضطراری سراسری (${actorEmail})`,
          updatedAt: now,
        })
        .where(eq(schema.dcaBots.isActive, true))
        .returning(),
      db
        .update(schema.aiCycleProBots)
        .set({
          isActive: false,
          status: 'STOPPED',
          lastStatusReason: `توقف اضطراری سراسری (${actorEmail})`,
          updatedAt: now,
        })
        .where(eq(schema.aiCycleProBots.isActive, true))
        .returning(),
    ]);
    stoppedSmartBots = (gRes?.length || 0) + (dRes?.length || 0) + (acRes?.length || 0);
  } catch {
    // Ignore
  }
  logger.warn('bots.global_emergency_stop', {
    actorEmail,
    stoppedCount: updated.length + stoppedProfitBots + stoppedSmartBots,
  });
  return updated.length + stoppedProfitBots + stoppedSmartBots;
}

async function hasIdempotencyOrder(key: string): Promise<boolean> {
  const db = getDb();
  const rows = await db
    .select({ orderId: schema.orders.orderId })
    .from(schema.orders)
    .where(eq(schema.orders.idempotencyKey, key))
    .limit(1);
  return rows.length > 0;
}

async function persistBotState(bot: BotStrategyConfig): Promise<void> {
  const db = getDb();
  await db
    .update(schema.tradingBots)
    .set({
      activePositionJson: bot.activePosition,
      statsJson: buildPersistedBotStatsJson(bot),
      lastCheckedAt: bot.lastCheckedAt,
      lastSignalSummary: bot.lastSignalSummary,
      status: bot.status,
      updatedAt: Date.now(),
    })
    .where(eq(schema.tradingBots.id, bot.id));
}

async function getUserBalancesForBot(userId: string, mode: ExecutionMode): Promise<SpotBalance[]> {
  if (!userId) return [];
  const { markets, usdtTomanRate } = await fetchNobitexUnifiedMarkets();
  if (mode === 'live') {
    const creds = await getActiveExchangeCredentialsForUser(userId);
    if (!creds) {
      throw new NobitexAuthError('توکن صرافی نوبیتکس برای خواندن موجودی واقعی یافت نشد.');
    }
    return fetchNobitexLiveBalances(markets, usdtTomanRate, creds);
  }
  return getPaperBalances(userId, markets, usdtTomanRate);
}

async function tryEnterBotFromExistingBalance(
  bot: BotStrategyConfig,
  currentPrice: number,
  isFixed: boolean,
  usdtTomanRate?: number
): Promise<'ENTERED' | 'INSUFFICIENT' | 'NOT_APPLICABLE'> {
  const fundingMode = normalizeBotFundingMode(bot.fundingMode);
  if (fundingMode === 'QUOTE_BUY') return 'NOT_APPLICABLE';

  const userId = bot.ownerId || '';
  if (!userId) return 'INSUFFICIENT';

  const existingPct = clampBotBalancePercent(bot.existingBalancePercent);
  const [balances, marketRules] = await Promise.all([
    getUserBalancesForBot(userId, bot.mode),
    getNobitexMarketRules(bot.symbol).catch(() => ({
      minNotional: getMinimumOrderNotional(bot.quoteCurrency),
      amountStep: 1e-6,
    })),
  ]);
  const freeBase =
    balances.find((b) => b.asset.toUpperCase() === bot.baseAsset.toUpperCase())?.free ?? 0;

  const alloc = computeExistingBalanceAllocation({
    freeBase,
    percent: existingPct,
    referencePrice: currentPrice,
    minNotional: marketRules.minNotional,
    step: marketRules.amountStep,
    baseAsset: bot.baseAsset,
    quoteCurrency: bot.quoteCurrency,
  });

  if (!alloc.ok) {
    if (fundingMode === 'EXISTING_ASSET') {
      bot.status = 'PAUSED';
      bot.lastSignalSummary =
        alloc.reason ||
        `موجودی آزاد ${bot.baseAsset} برای ورود با ${existingPct}٪ کافی نیست؛ ربات متوقف شد.`;
      await persistBotState(bot);
      await appendLog(userId, {
        botId: bot.id,
        botName: bot.name,
        symbol: bot.symbol,
        quoteCurrency: bot.quoteCurrency,
        event: 'INFO',
        price: currentPrice,
        message: bot.lastSignalSummary,
        mode: bot.mode,
      });
      return 'INSUFFICIENT';
    }
    return 'NOT_APPLICABLE';
  }

  const stopLossPrice =
    !isFixed && bot.stopLossPercent > 0 ? currentPrice * (1 - bot.stopLossPercent / 100) : 0;
  const takeProfitPrice = isFixed
    ? bot.targetSellPrice || 0
    : bot.takeProfitPercent > 0
      ? currentPrice * (1 + bot.takeProfitPercent / 100)
      : 0;

  bot.activePosition = {
    entryPrice: currentPrice,
    quantity: alloc.allocatedQty,
    highestPrice: currentPrice,
    stopLossPrice,
    takeProfitPrice,
    openedAt: Date.now(),
    fromExistingBalance: true,
  };

  bot.lastSignalSummary = isFixed
    ? `ورود با ${existingPct}٪ موجودی فعلی (${alloc.allocatedQty} ${bot.baseAsset}) در نرخ ${formatAmountText(
        currentPrice,
        bot.quoteCurrency
      )} · منتظر فروش ≥ ${formatAmountText(takeProfitPrice, bot.quoteCurrency)}`
    : `ورود با ${existingPct}٪ موجودی فعلی (${alloc.allocatedQty} ${bot.baseAsset}) · حد ضرر: ${formatAmountText(
        stopLossPrice,
        bot.quoteCurrency
      )} · حد سود: ${formatAmountText(takeProfitPrice, bot.quoteCurrency)}`;

  await persistBotState(bot);

  await appendLog(userId, {
    botId: bot.id,
    botName: bot.name,
    symbol: bot.symbol,
    quoteCurrency: bot.quoteCurrency,
    event: 'BUY_EXECUTED',
    price: currentPrice,
    quantity: alloc.allocatedQty,
    message: bot.lastSignalSummary,
    mode: bot.mode,
  });

  void notifyTelegramBotTrade(userId, {
    bot,
    event: 'BUY_EXECUTED',
    price: currentPrice,
    quantity: alloc.allocatedQty,
    usdtTomanRate,
    reason: bot.lastSignalSummary,
  });

  return 'ENTERED';
}

async function executeBotBuy(
  bot: BotStrategyConfig,
  currentPrice: number,
  reason: string,
  candleOpenTime: number,
  usdtTomanRate?: number
): Promise<boolean> {
  const userId = bot.ownerId || '';
  if (!userId) throw new Error('شناسه مالک ربات نامعتبر است.');

  const isFixed = isFixedPriceBot(bot);
  const botType = isFixed ? 'FIXED_PRICE' : 'STRATEGY';
  const smartMgr = await import('./smartBotManager.ts');
  const guard = await smartMgr.validateSharedExecutionGuards({
    userId,
    botId: bot.id,
    botType,
    symbol: bot.symbol,
    quoteCurrency: bot.quoteCurrency,
    side: 'BUY',
    requestedQuoteAmount: bot.orderAmount,
  });
  if (!guard.ok) {
    bot.lastSignalSummary = guard.reasonFa;
    await persistBotState(bot);
    return false;
  }

  const idempotencyKey = isFixed
    ? `bot:${bot.id}:cycle:${bot.stats.totalTrades + 1}:BUY`
    : `bot:${bot.id}:${bot.symbol}:${bot.timeframe}:${candleOpenTime}:BUY`;
  if (await hasIdempotencyOrder(idempotencyKey)) {
    return false;
  }

  const qty = bot.orderAmount / currentPrice;
  const feeRate = bot.feeRate ?? NOBITEX_FEE_RATE;

  if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
    await smartMgr.createPendingConfirmation({
      userId,
      botId: bot.id,
      botType,
      botName: bot.name,
      symbol: bot.symbol,
      baseAsset: bot.baseAsset,
      quoteCurrency: bot.quoteCurrency,
      mode: bot.mode,
      side: 'BUY',
      orderType: 'MARKET',
      suggestedPrice: currentPrice,
      quantity: qty,
      quoteAmount: bot.orderAmount,
      estimatedFeeQuote: bot.orderAmount * feeRate,
      reasonFa: reason,
      riskSummaryFa: `حداکثر مبلغ درگیر: ${formatAmountText(
        bot.orderAmount,
        bot.quoteCurrency
      )} · حد ضرر: ${bot.stopLossPercent || 0}٪`,
      metaJson: {
        stopLossPercent: bot.stopLossPercent,
        takeProfitPercent: bot.takeProfitPercent,
        targetSellPrice: bot.targetSellPrice,
      },
    });
    bot.lastSignalSummary = `در انتظار تأیید دستی کاربر برای خرید در ${formatAmountText(
      currentPrice,
      bot.quoteCurrency
    )} (${reason})`;
    await persistBotState(bot);
    return false;
  }

  if (bot.mode === 'live') {
    const creds = await getActiveExchangeCredentialsForUser(userId);
    if (!creds) {
      throw new NobitexAuthError('توکن صرافی نوبیتکس برای اجرای معامله واقعی یافت نشد.');
    }
    const order = await placeNobitexLiveOrder(
      {
        baseAsset: bot.baseAsset,
        quoteCurrency: bot.quoteCurrency,
        side: 'BUY',
        type: 'MARKET',
        quantity: qty,
        source: 'BOT',
        botId: bot.id,
        clientOrderId: formatNobitexClientOrderId(idempotencyKey),
      },
      creds
    );
    await recordLiveOrderAndTrade(userId, order, { idempotencyKey });
  } else {
    await placePaperOrder(userId, {
      baseAsset: bot.baseAsset,
      quoteCurrency: bot.quoteCurrency,
      side: 'BUY',
      type: 'MARKET',
      quantity: qty,
      price: currentPrice,
      source: 'BOT',
      botId: bot.id,
      idempotencyKey,
    });
  }

  const stopLossPrice =
    !isFixed && bot.stopLossPercent > 0 ? currentPrice * (1 - bot.stopLossPercent / 100) : 0;
  const takeProfitPrice = isFixed
    ? bot.targetSellPrice || 0
    : bot.takeProfitPercent > 0
      ? currentPrice * (1 + bot.takeProfitPercent / 100)
      : 0;

  const openedQty = qty * (1 - feeRate);
  bot.activePosition = {
    entryPrice: currentPrice,
    quantity: openedQty,
    initialQuantity: openedQty,
    highestPrice: currentPrice,
    stopLossPrice,
    takeProfitPrice,
    openedAt: Date.now(),
    executedTpIds: [],
    trailingTpArmed: false,
  };

  await persistBotState(bot);

  const buyMsg = isFixed
    ? `خرید خودکار قیمتی انجام شد (${reason}) · آماده فروش در ${formatAmountText(
        takeProfitPrice,
        bot.quoteCurrency
      )}`
    : `خرید خودکار انجام شد (${reason}) · حد ضرر: ${formatAmountText(
        stopLossPrice,
        bot.quoteCurrency
      )} · حد سود: ${formatAmountText(takeProfitPrice, bot.quoteCurrency)}`;

  await appendLog(userId, {
    botId: bot.id,
    botName: bot.name,
    symbol: bot.symbol,
    quoteCurrency: bot.quoteCurrency,
    event: 'BUY_EXECUTED',
    price: currentPrice,
    quantity: openedQty,
    message: buyMsg,
    mode: bot.mode,
  });

  void notifyTelegramBotTrade(userId, {
    bot,
    event: 'BUY_EXECUTED',
    price: currentPrice,
    quantity: openedQty,
    usdtTomanRate,
    reason: buyMsg,
  });
  return true;
}

async function executeBotSell(
  bot: BotStrategyConfig,
  currentPrice: number,
  event: 'SELL_TP' | 'SELL_SL' | 'SELL_TRAILING' | 'SELL_SIGNAL',
  reason: string,
  candleOpenTime: number,
  usdtTomanRate?: number,
  options?: { sellFraction?: number; targetId?: string; keepRunnerFraction?: number }
): Promise<void> {
  if (!bot.activePosition) return;
  const userId = bot.ownerId || '';
  if (!userId) return;

  const isFixed = isFixedPriceBot(bot);
  const botType = isFixed ? 'FIXED_PRICE' : 'STRATEGY';
  const pos = bot.activePosition;
  const fraction =
    options?.sellFraction && options.sellFraction > 0 && options.sellFraction < 1
      ? options.sellFraction
      : options?.keepRunnerFraction && options.keepRunnerFraction > 0 && options.keepRunnerFraction < 1
        ? 1 - options.keepRunnerFraction
        : 1;
  const isPartial = fraction < 0.999;

  const idempotencyKey = isFixed
    ? `bot:${bot.id}:cycle:${bot.stats.totalTrades + 1}:${event}`
    : `bot:${bot.id}:${bot.symbol}:${bot.timeframe}:${candleOpenTime}:${event}${
        options?.targetId ? `:tp${options.targetId}` : ''
      }`;
  if (await hasIdempotencyOrder(idempotencyKey)) {
    return;
  }

  const [balances, marketRules] = await Promise.all([
    getUserBalancesForBot(userId, bot.mode),
    getNobitexMarketRules(bot.symbol).catch(() => ({
      minNotional: getMinimumOrderNotional(bot.quoteCurrency),
      amountStep: 1e-6,
    })),
  ]);
  const freeBase =
    balances.find((b) => b.asset.toUpperCase() === bot.baseAsset.toUpperCase())?.free ?? 0;
  const desiredSellQty = pos.quantity * fraction;
  const sellQty = roundQuantityToStep(
    Math.min(desiredSellQty, freeBase),
    marketRules.amountStep,
    'floor'
  );
  if (sellQty <= 0 || sellQty * currentPrice + 1e-6 < marketRules.minNotional) {
    if (isPartial) return;
    bot.status = 'PAUSED';
    bot.lastSignalSummary = `موجودی آزاد ${bot.baseAsset} (${freeBase}) برای فروش خودکار کافی نیست یا کمتر از حداقل مجاز نوبیتکس است.`;
    await persistBotState(bot);
    await appendLog(userId, {
      botId: bot.id,
      botName: bot.name,
      symbol: bot.symbol,
      quoteCurrency: bot.quoteCurrency,
      event: 'INFO',
      price: currentPrice,
      message: bot.lastSignalSummary,
      mode: bot.mode,
    });
    return;
  }

  const feeRate = bot.feeRate ?? NOBITEX_FEE_RATE;
  const grossExit = sellQty * currentPrice * (1 - feeRate);
  const entryCost = sellQty * pos.entryPrice;
  const pnlQuote = grossExit - entryCost;
  const roundedPnl = Number(pnlQuote.toFixed(bot.quoteCurrency === 'IRT' ? 0 : 2));

  if (bot.executionConfirmationMode === 'MANUAL_CONFIRM') {
    const smartMgr = await import('./smartBotManager.ts');
    await smartMgr.createPendingConfirmation({
      userId,
      botId: bot.id,
      botType,
      botName: bot.name,
      symbol: bot.symbol,
      baseAsset: bot.baseAsset,
      quoteCurrency: bot.quoteCurrency,
      mode: bot.mode,
      side: 'SELL',
      orderType: 'MARKET',
      suggestedPrice: currentPrice,
      quantity: sellQty,
      quoteAmount: sellQty * currentPrice,
      estimatedFeeQuote: sellQty * currentPrice * feeRate,
      reasonFa: reason,
      riskSummaryFa: `سود/زیان تخمینی خالص: ${roundedPnl >= 0 ? '+' : ''}${formatAmountText(
        roundedPnl,
        bot.quoteCurrency
      )}`,
      metaJson: { event, isPartial, targetId: options?.targetId },
    });
    bot.lastSignalSummary = `در انتظار تأیید دستی شما برای فروش در ${formatAmountText(
      currentPrice,
      bot.quoteCurrency
    )} (${reason})`;
    await persistBotState(bot);
    return;
  }

  if (bot.mode === 'live') {
    const creds = await getActiveExchangeCredentialsForUser(userId);
    if (!creds) {
      throw new NobitexAuthError('توکن صرافی نوبیتکس برای فروش واقعی یافت نشد.');
    }
    const order = await placeNobitexLiveOrder(
      {
        baseAsset: bot.baseAsset,
        quoteCurrency: bot.quoteCurrency,
        side: 'SELL',
        type: 'MARKET',
        quantity: sellQty,
        source: 'BOT',
        botId: bot.id,
        clientOrderId: formatNobitexClientOrderId(idempotencyKey),
      },
      creds
    );
    await recordLiveOrderAndTrade(userId, order, {
      idempotencyKey,
      realizedPnlQuote: roundedPnl,
    });
  } else {
    await placePaperOrder(userId, {
      baseAsset: bot.baseAsset,
      quoteCurrency: bot.quoteCurrency,
      side: 'SELL',
      type: 'MARKET',
      quantity: sellQty,
      price: currentPrice,
      source: 'BOT',
      botId: bot.id,
      idempotencyKey,
      realizedPnlQuote: roundedPnl,
    });
  }

  bot.stats.totalTrades += 1;
  if (pnlQuote >= 0) bot.stats.winningTrades += 1;
  else bot.stats.losingTrades += 1;
  bot.stats.realizedPnl = Number(
    (bot.stats.realizedPnl + pnlQuote).toFixed(bot.quoteCurrency === 'IRT' ? 0 : 2)
  );

  if (isPartial) {
    const remainingQty = Math.max(0, pos.quantity - sellQty);
    if (remainingQty * currentPrice < marketRules.minNotional) {
      bot.activePosition = null;
    } else {
      const triggered = Array.isArray(pos.executedTpIds) ? [...pos.executedTpIds] : [];
      if (options?.targetId && !triggered.includes(options.targetId)) {
        triggered.push(options.targetId);
      }
      bot.activePosition = {
        ...pos,
        quantity: remainingQty,
        stopLossPrice:
          options?.keepRunnerFraction && pos.entryPrice > pos.stopLossPrice
            ? pos.entryPrice
            : pos.stopLossPrice,
        executedTpIds: triggered,
      };
    }
  } else {
    bot.activePosition = null;
  }

  await persistBotState(bot);

  await appendLog(userId, {
    botId: bot.id,
    botName: bot.name,
    symbol: bot.symbol,
    quoteCurrency: bot.quoteCurrency,
    event,
    price: currentPrice,
    quantity: sellQty,
    pnlQuote: roundedPnl,
    message: `${reason} · سود/زیان: ${pnlQuote >= 0 ? '+' : ''}${formatAmountText(
      pnlQuote,
      bot.quoteCurrency
    )}`,
    mode: bot.mode,
  });

  void notifyTelegramBotTrade(userId, {
    bot,
    event,
    price: currentPrice,
    quantity: sellQty,
    pnlQuote: roundedPnl,
    usdtTomanRate,
    reason,
  });
}

export async function evaluateSingleBot(bot: BotStrategyConfig): Promise<BotStrategyConfig> {
  const userId = bot.ownerId || '';
  const db = getDb();
  try {
    if (isFixedPriceBot(bot)) {
      const { markets, usdtTomanRate } = await fetchNobitexUnifiedMarkets();
      const market = markets.find((m) => m.baseAsset === bot.baseAsset);
      const currentPrice =
        bot.quoteCurrency === 'IRT'
          ? market?.priceToman || market?.bestSellToman || market?.bestBuyToman || 0
          : market?.priceUsdt || market?.bestSellUsdt || market?.bestBuyUsdt || 0;

      bot.lastCheckedAt = Date.now();
      if (currentPrice <= 0) {
        bot.lastSignalSummary = 'قیمت لحظه‌ای این بازار در نوبیتکس دریافت نشد';
        await persistBotState(bot);
        return bot;
      }

      if (userId) {
        await matchPaperLimitOrders(bot.symbol, currentPrice, userId);
      }

      const buyTarget = Number(bot.targetBuyPrice || 0);
      const sellTarget = Number(bot.targetSellPrice || 0);
      const repeatCycle = bot.repeatCycle !== false;
      const maxCycles = typeof bot.maxCycles === 'number' && bot.maxCycles > 0 ? bot.maxCycles : null;

      if (bot.activePosition) {
        const pos = bot.activePosition;
        if (currentPrice > pos.highestPrice) {
          pos.highestPrice = currentPrice;
        }

        if (sellTarget > 0 && currentPrice >= sellTarget) {
          await executeBotSell(
            bot,
            currentPrice,
            'SELL_SIGNAL',
            `فروش در قیمت هدف (${formatAmountText(sellTarget, bot.quoteCurrency)})`,
            bot.lastCheckedAt,
            usdtTomanRate
          );

          const cyclesDone = bot.stats.totalTrades;
          const reachedMax = maxCycles !== null && cyclesDone >= maxCycles;
          if (!repeatCycle || reachedMax) {
            bot.status = 'PAUSED';
            bot.lastSignalSummary = reachedMax
              ? `تکمیل ${cyclesDone} چرخه و توقف خودکار`
              : `فروش در ${formatAmountText(currentPrice, bot.quoteCurrency)} انجام شد و چرخه پایان یافت`;
          } else {
            bot.status = 'RUNNING';
            bot.lastSignalSummary =
              normalizeBotFundingMode(bot.fundingMode) === 'EXISTING_ASSET'
                ? `چرخه ${cyclesDone} با فروش در ${formatAmountText(
                    currentPrice,
                    bot.quoteCurrency
                  )} کامل شد · بررسی موجودی باقیمانده ${bot.baseAsset}`
                : `چرخه ${cyclesDone} با فروش در ${formatAmountText(
                    currentPrice,
                    bot.quoteCurrency
                  )} کامل شد · آماده خرید بعدی در ≤ ${formatAmountText(buyTarget, bot.quoteCurrency)}`;
          }
          await persistBotState(bot);
        } else {
          const pctToSell = currentPrice > 0 ? ((sellTarget - currentPrice) / currentPrice) * 100 : 0;
          bot.lastSignalSummary = `${
            pos.fromExistingBalance ? 'موجودی فعلی' : 'خرید'
          } @ ${formatAmountText(
            pos.entryPrice,
            bot.quoteCurrency
          )} · فعلی: ${formatAmountText(currentPrice, bot.quoteCurrency)} · منتظر فروش ≥ ${formatAmountText(
            sellTarget,
            bot.quoteCurrency
          )} (${pctToSell >= 0 ? `+${pctToSell.toFixed(2)}%` : 'نزدیک هدف'})`;
          await persistBotState(bot);
          if (userId) {
            void notifyTelegramBotActivity(userId, {
              bot,
              eventType: 'MONITOR_CYCLE',
              title: 'پایش ربات قیمتی (در انتظار فروش)',
              summary: bot.lastSignalSummary,
              currentPrice,
              usdtTomanRate,
            });
          }
        }
      } else {
        const existingRes = await tryEnterBotFromExistingBalance(
          bot,
          currentPrice,
          true,
          usdtTomanRate
        );
        if (existingRes === 'ENTERED' || existingRes === 'INSUFFICIENT') {
          await db
            .update(schema.tradingBots)
            .set({ consecutiveFailures: 0, nextRetryAt: null, lastError: null })
            .where(eq(schema.tradingBots.id, bot.id));
          return bot;
        }

        if (buyTarget > 0 && currentPrice <= buyTarget) {
          const entered = await executeBotBuy(
            bot,
            currentPrice,
            `رسیدن قیمت به هدف خرید ≤ ${formatAmountText(buyTarget, bot.quoteCurrency)}`,
            bot.lastCheckedAt,
            usdtTomanRate
          );
          if (entered) {
            bot.lastSignalSummary = `خرید در ${formatAmountText(
              currentPrice,
              bot.quoteCurrency
            )} انجام شد · منتظر فروش ≥ ${formatAmountText(sellTarget, bot.quoteCurrency)}`;
            await persistBotState(bot);
          }
        } else {
          const pctToBuy = currentPrice > 0 ? ((currentPrice - buyTarget) / currentPrice) * 100 : 0;
          bot.lastSignalSummary = `پایش سریع · قیمت فعلی: ${formatAmountText(
            currentPrice,
            bot.quoteCurrency
          )} · منتظر افت ${pctToBuy.toFixed(2)}% تا خرید در ≤ ${formatAmountText(
            buyTarget,
            bot.quoteCurrency
          )}`;
          await persistBotState(bot);
          if (userId) {
            void notifyTelegramBotActivity(userId, {
              bot,
              eventType: 'MONITOR_CYCLE',
              title: 'پایش ربات قیمتی (در انتظار خرید)',
              summary: bot.lastSignalSummary,
              currentPrice,
              usdtTomanRate,
            });
          }
        }
      }

      await db
        .update(schema.tradingBots)
        .set({ consecutiveFailures: 0, nextRetryAt: null, lastError: null })
        .where(eq(schema.tradingBots.id, bot.id));
      return bot;
    }

    const [{ markets, usdtTomanRate }, candles] = await Promise.all([
      fetchNobitexUnifiedMarkets(),
      fetchNobitexKlines(bot.symbol, bot.timeframe, 120),
    ]);

    const market = markets.find((m) => m.baseAsset === bot.baseAsset);
    const currentPrice =
      bot.quoteCurrency === 'IRT'
        ? market?.priceToman || candles[candles.length - 1]?.close || 0
        : market?.priceUsdt || candles[candles.length - 1]?.close || 0;

    if (candles.length < 30 || currentPrice <= 0) {
      bot.lastCheckedAt = Date.now();
      bot.lastSignalSummary = 'داده کندل کافی از نوبیتکس برای این تایم‌فریم دریافت نشد';
      await persistBotState(bot);
      return bot;
    }

    if (userId) {
      await matchPaperLimitOrders(bot.symbol, currentPrice, userId);
    }

    const snap = analyzeCandles(bot.symbol, bot.timeframe, candles);
    const idx = candles.length - 1;
    const candleOpenTime = candles[idx].openTime;
    bot.lastCheckedAt = Date.now();

    if (bot.activePosition) {
      const pos = bot.activePosition;
      if (currentPrice > pos.highestPrice) {
        pos.highestPrice = currentPrice;
      }

      if (pos.stopLossPrice > 0 && currentPrice <= pos.stopLossPrice) {
        await executeBotSell(
          bot,
          currentPrice,
          'SELL_SL',
          'فعال شدن حد ضرر (Stop-Loss)',
          candleOpenTime,
          usdtTomanRate
        );
        bot.lastSignalSummary = `بسته شد با حد ضرر در ${formatAmountText(
          currentPrice,
          bot.quoteCurrency
        )}`;
        await persistBotState(bot);
        return bot;
      }

      if (bot.trailingStopEnabled && bot.trailingStopPercent > 0) {
        const trailingLevel = pos.highestPrice * (1 - bot.trailingStopPercent / 100);
        if (trailingLevel > pos.entryPrice && currentPrice <= trailingLevel) {
          await executeBotSell(
            bot,
            currentPrice,
            'SELL_TRAILING',
            'فعال شدن حد ضرر متحرک (Trailing Stop)',
            candleOpenTime,
            usdtTomanRate
          );
          bot.lastSignalSummary = `بسته شد با Trailing Stop در ${formatAmountText(
            currentPrice,
            bot.quoteCurrency
          )}`;
          await persistBotState(bot);
          return bot;
        }
      }

      if (bot.trailingTakeProfitEnabled && bot.trailingTakeProfitActivationPercent && bot.trailingTakeProfitCallbackPercent) {
        const gainPct = ((currentPrice - pos.entryPrice) / pos.entryPrice) * 100;
        if (gainPct >= bot.trailingTakeProfitActivationPercent && !pos.trailingTpArmed) {
          pos.trailingTpArmed = true;
        }
        if (pos.trailingTpArmed) {
          const trailTpStop = pos.highestPrice * (1 - bot.trailingTakeProfitCallbackPercent / 100);
          if (trailTpStop > pos.entryPrice && currentPrice <= trailTpStop) {
            await executeBotSell(
              bot,
              currentPrice,
              'SELL_TRAILING',
              'تحقق حد سود متحرک (Trailing Take Profit)',
              candleOpenTime,
              usdtTomanRate
            );
            bot.lastSignalSummary = `خروج با حد سود متحرک در ${formatAmountText(
              currentPrice,
              bot.quoteCurrency
            )}`;
            await persistBotState(bot);
            return bot;
          }
        }
      }

      if (Array.isArray(bot.takeProfitTargets) && bot.takeProfitTargets.length > 0) {
        const alreadyTriggered = new Set(pos.executedTpIds || []);
        for (let tIdx = 0; tIdx < bot.takeProfitTargets.length; tIdx += 1) {
          const tier = bot.takeProfitTargets[tIdx];
          const tierId = tier.id || `tp-${tIdx}`;
          if (alreadyTriggered.has(tierId)) continue;
          if (tier.risePercent > 0 && tier.sellPercent > 0) {
            const tierPrice = pos.entryPrice * (1 + tier.risePercent / 100);
            if (currentPrice >= tierPrice) {
              const isLastTier = tIdx === bot.takeProfitTargets.length - 1;
              const runnerFrac =
                isLastTier && bot.keepRunnerPercent && bot.keepRunnerPercent > 0
                  ? Math.min(0.6, bot.keepRunnerPercent / 100)
                  : 0;
              const frac = isLastTier
                ? 1 - runnerFrac
                : Math.min(0.95, Math.max(0.1, tier.sellPercent / 100));
              await executeBotSell(
                bot,
                currentPrice,
                'SELL_TP',
                `فروش پله‌ای هدف ${tIdx + 1} (+${tier.risePercent}%)`,
                candleOpenTime,
                usdtTomanRate,
                { sellFraction: frac, targetId: tierId, keepRunnerFraction: runnerFrac }
              );
              return bot;
            }
          }
        }
      }

      if (pos.takeProfitPrice > 0 && currentPrice >= pos.takeProfitPrice) {
        const runnerFrac =
          bot.keepRunnerPercent && bot.keepRunnerPercent > 0
            ? Math.min(0.6, bot.keepRunnerPercent / 100)
            : 0;
        await executeBotSell(
          bot,
          currentPrice,
          'SELL_TP',
          'تحقق حد سود (Take-Profit)',
          candleOpenTime,
          usdtTomanRate,
          runnerFrac > 0 ? { keepRunnerFraction: runnerFrac } : undefined
        );
        bot.lastSignalSummary = `بسته شد با حد سود در ${formatAmountText(
          currentPrice,
          bot.quoteCurrency
        )}`;
        await persistBotState(bot);
        return bot;
      }

      const exitEval = evaluateRuleset(bot.exitRules, 'OR', candles, idx);
      if (exitEval.triggered) {
        await executeBotSell(
          bot,
          currentPrice,
          'SELL_SIGNAL',
          `سیگنال خروج اندیکاتور: ${exitEval.details.join(' + ')}`,
          candleOpenTime,
          usdtTomanRate
        );
        bot.lastSignalSummary = `خروج با سیگنال: ${exitEval.details.join(' + ')}`;
        await persistBotState(bot);
        return bot;
      }

      const unrealizedPct = ((currentPrice - pos.entryPrice) / pos.entryPrice) * 100;
      bot.lastSignalSummary = `پوزیشن باز (${unrealizedPct >= 0 ? '+' : ''}${unrealizedPct.toFixed(
        2
      )}%) · RSI: ${snap.rsi14.toFixed(1)}`;
      await persistBotState(bot);
      if (userId) {
        void notifyTelegramBotActivity(userId, {
          bot,
          eventType: 'MONITOR_CYCLE',
          title: 'گزارش پایش پوزیشن ربات',
          summary: bot.lastSignalSummary,
          currentPrice,
          rsi14: snap.rsi14,
          usdtTomanRate,
        });
      }
      return bot;
    }

    const recentTradeLogs = userId
      ? await db
          .select()
          .from(schema.tradingLogs)
          .where(
            and(
              eq(schema.tradingLogs.botId, bot.id),
              inArray(schema.tradingLogs.event, [
                'BUY_EXECUTED',
                'SELL_TP',
                'SELL_SL',
                'SELL_TRAILING',
                'SELL_SIGNAL',
              ])
            )
          )
          .orderBy(desc(schema.tradingLogs.timestamp))
          .limit(1)
      : [];

    const lastTradeLog = recentTradeLogs[0];
    const cooldownMs = bot.cooldownMinutes * 60_000;
    if (lastTradeLog && Date.now() - lastTradeLog.timestamp < cooldownMs) {
      bot.lastSignalSummary = `در دوره استراحت · RSI: ${snap.rsi14.toFixed(
        1
      )} · قیمت: ${formatAmountText(currentPrice, bot.quoteCurrency)}`;
      await persistBotState(bot);
      if (userId) {
        void notifyTelegramBotActivity(userId, {
          bot,
          eventType: 'MONITOR_CYCLE',
          title: 'گزارش پایش ربات',
          summary: bot.lastSignalSummary,
          currentPrice,
          rsi14: snap.rsi14,
          usdtTomanRate,
        });
      }
      return bot;
    }

    const existingRes = await tryEnterBotFromExistingBalance(
      bot,
      currentPrice,
      false,
      usdtTomanRate
    );
    if (existingRes === 'ENTERED' || existingRes === 'INSUFFICIENT') {
      await db
        .update(schema.tradingBots)
        .set({ consecutiveFailures: 0, nextRetryAt: null, lastError: null })
        .where(eq(schema.tradingBots.id, bot.id));
      return bot;
    }

    const entryEval = evaluateRuleset(bot.entryRules, bot.logicOperator, candles, idx, undefined, {
      volumeConfirmationEnabled: Boolean(bot.volumeConfirmationEnabled),
      minVolumeRatio: bot.minVolumeRatio || 1.2,
      volatilityFilterEnabled: Boolean(bot.volatilityFilterEnabled),
      volatilityFilterMaxAtrPercent: bot.volatilityFilterMaxAtrPercent || 4.5,
      minSignalScore: bot.minSignalScore || 1,
    });
    if (entryEval.triggered) {
      const entered = await executeBotBuy(
        bot,
        currentPrice,
        entryEval.details.join(' + ') || 'سیگنال استراتژی',
        candleOpenTime,
        usdtTomanRate
      );
      if (entered) {
        bot.lastSignalSummary = `ورود انجام شد: ${entryEval.details.join(' + ')}`;
        await persistBotState(bot);
      }
    } else {
      bot.lastSignalSummary = `پایش فعال · RSI(14): ${snap.rsi14.toFixed(1)} · ${formatAmountText(
        currentPrice,
        bot.quoteCurrency
      )}`;
      await persistBotState(bot);
      if (userId) {
        void notifyTelegramBotActivity(userId, {
          bot,
          eventType: 'MONITOR_CYCLE',
          title: 'گزارش پایش ربات',
          summary: bot.lastSignalSummary,
          currentPrice,
          rsi14: snap.rsi14,
          usdtTomanRate,
        });
      }
    }

    // Reset failure counter on healthy evaluation
    await db
      .update(schema.tradingBots)
      .set({ consecutiveFailures: 0, nextRetryAt: null, lastError: null })
      .where(eq(schema.tradingBots.id, bot.id));
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'خطا در اجرای چرخه ربات';
    const isAuthErr = err instanceof NobitexAuthError;

    const currentRows = await db
      .select({ consecutiveFailures: schema.tradingBots.consecutiveFailures })
      .from(schema.tradingBots)
      .where(eq(schema.tradingBots.id, bot.id))
      .limit(1);
    const nextFailures = (currentRows[0]?.consecutiveFailures ?? 0) + 1;
    const shouldPause = isAuthErr || nextFailures >= 5;
    const backoffMs = Math.min(300_000, 15_000 * Math.pow(2, nextFailures - 1));

    bot.lastCheckedAt = Date.now();
    bot.lastSignalSummary = shouldPause
      ? `توقف خودکار به دلیل خطا: ${msg}`
      : `خطا: ${msg}`;
    if (shouldPause) {
      bot.status = 'PAUSED';
    }

    await db
      .update(schema.tradingBots)
      .set({
        status: bot.status,
        lastCheckedAt: bot.lastCheckedAt,
        lastSignalSummary: bot.lastSignalSummary,
        consecutiveFailures: nextFailures,
        nextRetryAt: shouldPause ? null : Date.now() + backoffMs,
        lastError: msg.slice(0, 400),
        updatedAt: Date.now(),
      })
      .where(eq(schema.tradingBots.id, bot.id));

    if (userId) {
      await appendLog(userId, {
        botId: bot.id,
        botName: bot.name,
        symbol: bot.symbol,
        quoteCurrency: bot.quoteCurrency,
        event: 'ERROR',
        price: 0,
        message: msg,
        mode: bot.mode,
      });
      void notifyTelegramBotActivity(userId, {
        bot,
        eventType: 'ERROR',
        title: shouldPause ? 'توقف خودکار ربات (خطای احراز/تکرار)' : 'خطای اجرای ربات',
        summary: msg,
        force: isAuthErr,
      });
    }
  }
  return bot;
}

export async function runAllActiveBotsCycle(
  ownerOverride?: string,
  options?: { respectSchedule?: boolean; indicatorPollMs?: number }
): Promise<{ acquired: boolean; evaluatedBots: number }> {
  if (isEvaluatingLocally) return { acquired: false, evaluatedBots: 0 };

  const db = getDb();
  const [runningBotRows, cfgRows, activeAlerts, activeWatchers] = await Promise.all([
    db.select().from(schema.tradingBots).where(eq(schema.tradingBots.status, 'RUNNING')),
    db.select().from(schema.botConfigurations),
    db
      .select({ id: schema.priceAlerts.id })
      .from(schema.priceAlerts)
      .where(eq(schema.priceAlerts.status, 'ACTIVE'))
      .limit(1),
    db
      .select({ id: schema.priceWatchers.id })
      .from(schema.priceWatchers)
      .where(eq(schema.priceWatchers.status, 'ACTIVE'))
      .limit(1),
  ]);

  const profitRes = await runAllActiveProfitBotsCycle({
    respectSchedule: Boolean(options?.respectSchedule),
    ownerOverride,
  }).catch(() => ({ evaluated: 0 }));

  let smartEvaluated = 0;
  try {
    const [smartMgr, aiCycle] = await Promise.all([
      import('./smartBotManager.ts'),
      import('./aiCycleProEngine.ts'),
    ]);
    const [gridCount, dcaCount, aiCycleRes] = await Promise.all([
      smartMgr.runAllActiveGridBotsCycle({ respectSchedule: Boolean(options?.respectSchedule) }),
      smartMgr.runAllActiveDcaBotsCycle({ respectSchedule: Boolean(options?.respectSchedule) }),
      aiCycle.runAllActiveAiCycleProBotsCycle({
        respectSchedule: Boolean(options?.respectSchedule),
        ownerOverride,
      }),
    ]);
    smartEvaluated = gridCount + dcaCount + aiCycleRes.evaluated;
  } catch {
    // Non-blocking fallback
  }

  if (runningBotRows.length === 0 && activeAlerts.length === 0 && activeWatchers.length === 0) {
    return {
      acquired: profitRes.evaluated + smartEvaluated > 0,
      evaluatedBots: profitRes.evaluated + smartEvaluated,
    };
  }

  const cfgMap = new Map(cfgRows.map((c) => [c.botId, c]));
  const now = Date.now();
  const respectSchedule = Boolean(options?.respectSchedule);
  const indicatorPollMs = Math.max(5_000, options?.indicatorPollMs ?? 15_000);

  const dueBots: BotStrategyConfig[] = [];
  for (const botRow of runningBotRows) {
    if (botRow.nextRetryAt && botRow.nextRetryAt > now) continue;
    const botConfig = mapBotRowsToConfig(botRow, cfgMap.get(botRow.id));
    if (respectSchedule && botConfig.lastCheckedAt) {
      const intervalMs = isFixedPriceBot(botConfig)
        ? Math.max(2000, (botConfig.pollIntervalSeconds || 5) * 1000)
        : indicatorPollMs;
      if (now - botConfig.lastCheckedAt < intervalMs - 250) {
        continue;
      }
    }
    dueBots.push(botConfig);
  }

  if (dueBots.length === 0 && activeAlerts.length === 0 && activeWatchers.length === 0) {
    return {
      acquired: profitRes.evaluated > 0,
      evaluatedBots: profitRes.evaluated,
    };
  }

  const lockOwner = ownerOverride || WORKER_INSTANCE_ID;
  const acquired = await acquireWorkerLock(WORKER_LOCK_NAME, lockOwner, 30_000);
  if (!acquired) {
    return {
      acquired: profitRes.evaluated > 0,
      evaluatedBots: profitRes.evaluated,
    };
  }

  isEvaluatingLocally = true;
  let evaluatedBots = profitRes.evaluated;

  try {
    if (activeAlerts.length > 0 || activeWatchers.length > 0) {
      try {
        const { markets } = await fetchNobitexUnifiedMarkets();
        if (activeAlerts.length > 0) await evaluatePriceAlerts(markets);
        if (activeWatchers.length > 0) await evaluatePriceWatchers(markets);
      } catch {
        // Ignore transient market fetch failures for alerts/watchers
      }
    }

    for (const botConfig of dueBots) {
      await evaluateSingleBot(botConfig);
      evaluatedBots += 1;
    }

    return { acquired: true, evaluatedBots };
  } finally {
    isEvaluatingLocally = false;
    await releaseWorkerLock(WORKER_LOCK_NAME, lockOwner);
  }
}

export function startBotLoop(pollMs = 15_000): void {
  if (loopTimer) return;
  const schedulerTickMs = Math.min(2000, Math.max(1000, pollMs));
  loopTimer = setInterval(() => {
    void runAllActiveBotsCycle(undefined, {
      respectSchedule: true,
      indicatorPollMs: pollMs,
    });
  }, schedulerTickMs);
}

export function stopBotLoop(): void {
  if (loopTimer) {
    clearInterval(loopTimer);
    loopTimer = null;
  }
}
