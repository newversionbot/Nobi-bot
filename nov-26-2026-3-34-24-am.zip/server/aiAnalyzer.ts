import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import type {
  AiAskResponse,
  AiBotManagerBotReview,
  AiBotManagerCoinRank,
  AiBotManagerConflictAlert,
  AiBotManagerProposal,
  AiChatTurn,
  AiCoinAnalysis,
  AiCycleProCapitalUsageMode,
  AiCycleProDecision,
  AiCycleProPosition,
  AiManagerAnalysis,
  BotType,
  CoinSentimentAnalysis,
  IndicatorSnapshot,
  MarketRegimeType,
  OrderBookSnapshot,
  QuoteCurrency,
  SentimentNewsItem,
  SentimentSourceLink,
  SentimentSuggestion,
  SharedBotRiskSettings,
  UnifiedBotSummaryRow,
  UnifiedMarketTicker,
} from '../src/types/trading.ts';

export class GeminiServiceError extends Error {
  statusCode: number;
  isQuotaExceeded: boolean;

  constructor(message: string, statusCode = 500, isQuotaExceeded = false) {
    super(message);
    this.name = 'GeminiServiceError';
    this.statusCode = statusCode;
    this.isQuotaExceeded = isQuotaExceeded;
  }
}

function classifyGeminiError(err: unknown): GeminiServiceError {
  if (err instanceof GeminiServiceError) return err;
  const rawMessage = err instanceof Error ? err.message : String(err || '');
  const upper = rawMessage.toUpperCase();
  const statusProp =
    err && typeof err === 'object' && 'status' in err
      ? Number((err as { status?: unknown }).status)
      : NaN;

  if (
    statusProp === 429 ||
    upper.includes('429') ||
    upper.includes('RESOURCE_EXHAUSTED') ||
    upper.includes('QUOTA') ||
    upper.includes('RATE LIMIT')
  ) {
    return new GeminiServiceError(
      'سهمیه یا محدودیت درخواست Gemini API تکمیل شده است. می‌توانید وضعیت کلید و پلن را در بخش Settings > Secrets بررسی کنید.',
      429,
      true
    );
  }

  if (
    statusProp === 403 ||
    upper.includes('PERMISSION_DENIED') ||
    upper.includes('API_KEY_INVALID') ||
    upper.includes('API KEY NOT VALID')
  ) {
    return new GeminiServiceError(
      'کلید Gemini API معتبر نیست یا مجوز لازم را ندارد. لطفاً کلید را در بخش Settings > Secrets بررسی کنید.',
      403,
      false
    );
  }

  if (statusProp === 404 || upper.includes('NOT_FOUND')) {
    return new GeminiServiceError(
      'مدل یا سرویس هوش مصنوعی در دسترس نیست.',
      404,
      false
    );
  }

  return new GeminiServiceError(
    rawMessage && !rawMessage.trim().startsWith('{')
      ? rawMessage
      : 'خطا در ارتباط با سرویس هوش مصنوعی Gemini. لطفاً چند لحظه بعد دوباره تلاش کنید.',
    500,
    false
  );
}

function getGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new GeminiServiceError(
      'کلید GEMINI_API_KEY در تنظیمات سرور (Settings > Secrets) تنظیم نشده است.',
      403,
      false
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export async function generateAiCoinAnalysis(input: {
  symbol: string;
  baseAsset: string;
  market: UnifiedMarketTicker | null;
  usdtTomanRate: number;
  snapshots: IndicatorSnapshot[];
  question?: string;
}): Promise<AiCoinAnalysis> {
  const ai = getGeminiClient();

  const tfSummary = input.snapshots.map((s) => ({
    timeframe: s.timeframe,
    price: s.price,
    signal: s.signal.labelFa,
    buyIndicators: s.signal.buyCount,
    sellIndicators: s.signal.sellCount,
    rsi14: Number(s.rsi14.toFixed(2)),
    stochK: Number(s.stochK.toFixed(1)),
    macdLine: Number(s.macd.macdLine.toFixed(4)),
    macdSignal: Number(s.macd.signalLine.toFixed(4)),
    macdHistogram: Number(s.macd.histogram.toFixed(4)),
    ema9: Number(s.ema9.toFixed(4)),
    ema20: Number(s.ema20.toFixed(4)),
    ema50: Number(s.ema50.toFixed(4)),
    bbUpper: Number(s.bollinger.upper.toFixed(4)),
    bbLower: Number(s.bollinger.lower.toFixed(4)),
    volumeRatio: Number(s.volumeRatio.toFixed(2)),
    pivots: {
      s2: Number(s.pivots.s2.toFixed(4)),
      s1: Number(s.pivots.s1.toFixed(4)),
      pivot: Number(s.pivots.pivot.toFixed(4)),
      r1: Number(s.pivots.r1.toFixed(4)),
      r2: Number(s.pivots.r2.toFixed(4)),
    },
  }));

  const contextPayload = {
    exchange: 'Nobitex (نوبیتکس)',
    baseAsset: input.baseAsset,
    persianName: input.market?.persianName || input.baseAsset,
    symbolAnalyzed: input.symbol,
    usdtTomanRate: Math.round(input.usdtTomanRate),
    liveNobitexMarket: input.market
      ? {
          priceToman: Math.round(input.market.priceToman),
          priceUsdt: Number(input.market.priceUsdt.toFixed(6)),
          change24hPercent: Number(input.market.change24hPercent.toFixed(2)),
          high24hToman: Math.round(input.market.high24hToman),
          low24hToman: Math.round(input.market.low24hToman),
          high24hUsdt: Number(input.market.high24hUsdt.toFixed(6)),
          low24hUsdt: Number(input.market.low24hUsdt.toFixed(6)),
        }
      : null,
    multiTimeframeIndicators: tfSummary,
    userQuestion: input.question?.trim() || null,
  };

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: `اطلاعات زنده بازار نوبیتکس و اندیکاتورهای ارز ${input.baseAsset} (${contextPayload.persianName}) به شرح زیر است:\n${JSON.stringify(contextPayload, null, 2)}`,
      config: {
        systemInstruction:
          'تو رفیقِ تریدرِ خوش‌مشرب، شوخ‌طبع، خاکی و کاربلدِ کاربر توی پلتفرم AI NobiBot هستی. وضعیت بازار نوبیتکس رو خیلی خودمونی، صمیمی، شیرین و با نمک و طنز ملایم توضیح بده — طوری که هم لبخند بیاد رو لب کاربر، هم کسی که تازه‌کاره دقیق بفهمه الان وقت خریده، وقت سیو سوده، یا بهتره یه چایی بریزه و فعلاً دست به ماشه نبره! اصطلاحات خشک مثل RSI و MACD رو خودمونی معنی کن (مثلاً: «فروشنده‌ها دیگه نفسشون بریده» یا «قیمت زیادی گاز داده و ممکنه یهو ترمز بزنه»). فقط حواست باشه سرِ پول مردم شوخی بی‌جا نکنی: اعداد ورود، هدف و حد ضرر رو دقیق و واقعی هم به **تومان** و هم به **دلار (USDT)** بر اساس همین دیتا بنویس، بدون وعده تخیلی و با یادآوری ریسک. اگر کاربر سوال خاصی پرسیده، مستقیم و خودمونی جوابش رو بده.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            stance: {
              type: Type.STRING,
              enum: ['STRONG_BUY', 'BUY', 'HOLD', 'SELL', 'STRONG_SELL'],
            },
            stanceLabelFa: {
              type: Type.STRING,
              description: 'خیلی خودمونی و باحال، مثلاً: وقت خرید پله‌ایه رفیق / یه چایی بریز صبر کن / وقت برداشت سوده / فعلاً نزدیکش نشو',
            },
            verdictHeadline: {
              type: Type.STRING,
              description: 'تیتر کوتاه، خودمونی و کمی شوخ‌طبع درباره وضعیت الان ارز (مثلاً: بیت‌کوین رو حمایت لنگر انداخته و داره نفس تازه می‌کنه)',
            },
            confidencePercent: {
              type: Type.INTEGER,
              description: 'درصد اطمینان سیگنال‌ها از 0 تا 100',
            },
            friendlySummary: {
              type: Type.STRING,
              description: '۲ تا ۳ جمله کاملاً خودمونی، گرم و کمی شوخ‌طبع که داستان الان بازار این ارز را تعریف کند',
            },
            shouldBuyOrSell: {
              type: Type.STRING,
              description: 'توصیه رک، خودمونی و باحال که الان بخریم، بفروشیم یا دست نگه داریم و چرا',
            },
            simpleTechnicalExplain: {
              type: Type.STRING,
              description: 'ترجمه خودمونی و شیرین وضعیت اندیکاتورها (RSI، میانگین‌ها و حجم) بدون کلمات خشک کتابی',
            },
            tradePlan: {
              type: Type.OBJECT,
              properties: {
                buyRangeUsd: { type: Type.STRING },
                buyRangeToman: { type: Type.STRING },
                target1Usd: { type: Type.STRING },
                target1Toman: { type: Type.STRING },
                target2Usd: { type: Type.STRING },
                target2Toman: { type: Type.STRING },
                stopLossUsd: { type: Type.STRING },
                stopLossToman: { type: Type.STRING },
              },
              required: [
                'buyRangeUsd',
                'buyRangeToman',
                'target1Usd',
                'target1Toman',
                'target2Usd',
                'target2Toman',
                'stopLossUsd',
                'stopLossToman',
              ],
            },
            keyLevels: {
              type: Type.OBJECT,
              properties: {
                support: { type: Type.STRING, description: 'حمایت مهم هم به تومان و هم به دلار' },
                resistance: { type: Type.STRING, description: 'مقاومت مهم هم به تومان و هم به دلار' },
              },
              required: ['support', 'resistance'],
            },
            riskTips: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '۲ تا ۳ نکته خودمونی برای مدیریت ریسک و مراقبت از سرمایه',
            },
            customAnswer: {
              type: Type.STRING,
              description: 'پاسخ صمیمی به سوال خاص کاربر در صورت وجود',
            },
          },
          required: [
            'stance',
            'stanceLabelFa',
            'verdictHeadline',
            'confidencePercent',
            'friendlySummary',
            'shouldBuyOrSell',
            'simpleTechnicalExplain',
            'tradePlan',
            'keyLevels',
            'riskTips',
          ],
        },
      },
    });

    const rawText = (response.text ?? '{}').trim();
    const parsed = JSON.parse(rawText) as Omit<
      AiCoinAnalysis,
      'symbol' | 'baseAsset' | 'generatedAt'
    >;

    return {
      symbol: input.symbol,
      baseAsset: input.baseAsset,
      generatedAt: Date.now(),
      ...parsed,
    };
  } catch (err) {
    throw classifyGeminiError(err);
  }
}

export async function askAiTradingBuddy(input: {
  question: string;
  history: AiChatTurn[];
  symbol: string;
  baseAsset: string;
  market: UnifiedMarketTicker | null;
  usdtTomanRate: number;
  snapshots: IndicatorSnapshot[];
  topMarkets: UnifiedMarketTicker[];
  mentionedMarkets: UnifiedMarketTicker[];
}): Promise<AiAskResponse> {
  const ai = getGeminiClient();

  const marketStatsSummary = {
    totalMarketsLoaded: input.topMarkets.length,
    gainersCount: input.topMarkets.filter((m) => m.change24hPercent > 0).length,
    losersCount: input.topMarkets.filter((m) => m.change24hPercent < 0).length,
    usdtTomanRate: Math.round(input.usdtTomanRate),
    topWatchlist: input.topMarkets.slice(0, 12).map((m) => ({
      asset: m.baseAsset,
      fa: m.persianName,
      toman: Math.round(m.priceToman),
      usdt: Number(m.priceUsdt.toFixed(6)),
      change24h: Number(m.change24hPercent.toFixed(2)),
    })),
    mentionedCoinsInQuestion: input.mentionedMarkets.map((m) => ({
      asset: m.baseAsset,
      fa: m.persianName,
      toman: Math.round(m.priceToman),
      usdt: Number(m.priceUsdt.toFixed(6)),
      change24h: Number(m.change24hPercent.toFixed(2)),
      high24hToman: Math.round(m.high24hToman),
      low24hToman: Math.round(m.low24hToman),
    })),
  };

  const selectedCoinSummary = {
    symbol: input.symbol,
    baseAsset: input.baseAsset,
    persianName: input.market?.persianName || input.baseAsset,
    priceToman: input.market ? Math.round(input.market.priceToman) : 0,
    priceUsdt: input.market ? Number(input.market.priceUsdt.toFixed(6)) : 0,
    change24hPercent: input.market ? Number(input.market.change24hPercent.toFixed(2)) : 0,
    indicators: input.snapshots.map((s) => ({
      tf: s.timeframe,
      signal: s.signal.labelFa,
      rsi14: Number(s.rsi14.toFixed(1)),
      macdBullish: s.macd.macdLine > s.macd.signalLine,
      ema20: Number(s.ema20.toFixed(4)),
      support: Number(s.pivots.s1.toFixed(4)),
      resistance: Number(s.pivots.r1.toFixed(4)),
    })),
  };

  const recentHistory = input.history
    .slice(-8)
    .map((h) => `${h.role === 'user' ? 'کاربر' : 'دستیار'}: ${h.text}`)
    .join('\n');

  const prompt = [
    `داده زنده الان نوبیتکس برای ارز انتخابی کاربر:`,
    JSON.stringify(selectedCoinSummary, null, 2),
    `\nنبض کلی بازار نوبیتکس و ارزهای مهم/اشاره‌شده:`,
    JSON.stringify(marketStatsSummary, null, 2),
    recentHistory ? `\nادامه گفتگوی قبلی:\n${recentHistory}` : '',
    `\nسوال یا حرف جدید کاربر:\n«${input.question.trim()}»`,
  ]
    .filter(Boolean)
    .join('\n');

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        systemInstruction:
          'تو «همیار باحال AI NobiBot» (بخش از من بپرس) در سایت ainobibot.ir هستی. لحن تو کاملاً خودمونی، گرم، صمیمی، شوخ‌طبع و راحته — مثل یه رفیق تریدر خوش‌مشرب که با هم سر چارت نشستین و داری جواب سوالشو میدی! قوانین طلایی تو: ۱) هر چی به زبان خودمونی پرسید (درباره ارز انتخابی، یه ارز دیگه، تتر، ریزش بازار، مدیریت سرمایه، ربات سود، یا حتی درد دل از بازار قرمز)، مستقیم، دقیق و با شوخ‌طبعیِ به‌جا جوابش رو بده. ۲) هر وقت راجع به قیمت یا وضعیت ارزی صحبت می‌کنی، از عددهای واقعی زنده نوبیتکس که توی کانتکست هست (به تومان و دلار) استفاده کن و هرگز قیمت خیالی نساز. ۳) جواب‌ها رو جمع‌وجور، روان و باحال نگه دار (۳ تا ۶ جمله یا بولت کوتاه خودمونی)، مگر اینکه کاربر توضیح مفصل بخواد. ۴) همیشه با احترام و بدون شعارهای خشک، حواست به حفظ سرمایه کاربر باشه (هیچ‌وقت نگو صددرصد سود می‌کنی). ۵) ۲ تا ۳ تا پیشنهاد سوال بعدیِ خودمونی هم برای ادامه گپ برگردون.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            answer: {
              type: Type.STRING,
              description: 'پاسخ خودمونی، هوشمند، دقیق و با نمک و طنز ملایم به زبان فارسی روزمره',
            },
            suggestedFollowUps: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: '۲ تا ۳ سوال کوتاه و خودمونی که کاربر بتونه با یک کلیک بپرسه',
            },
          },
          required: ['answer', 'suggestedFollowUps'],
        },
      },
    });

    const raw = (response.text ?? '{}').trim();
    const parsed = extractJsonObject(raw) as {
      answer?: unknown;
      suggestedFollowUps?: unknown;
    } | null;

    const answerText =
      typeof parsed?.answer === 'string' && parsed.answer.trim()
        ? parsed.answer.trim()
        : raw || 'الان یه لحظه حواسم پرتِ کندل‌ها شد، یه بار دیگه بپرس رفیق!';

    const followUps = Array.isArray(parsed?.suggestedFollowUps)
      ? parsed.suggestedFollowUps
          .map((x) => String(x || '').trim())
          .filter(Boolean)
          .slice(0, 3)
      : [
          `الان برای ${input.market?.persianName || input.baseAsset} حد ضرر کجا بذارم؟`,
          'وضعیت کل بازار نوبیتکس الان چطوره؟',
        ];

    return {
      answer: answerText,
      suggestedFollowUps: followUps,
      referencedSymbol: input.symbol,
      generatedAt: Date.now(),
    };
  } catch (err) {
    throw classifyGeminiError(err);
  }
}

const SENTIMENT_CACHE_TTL_MS = 10 * 60 * 1000;
const SENTIMENT_FALLBACK_CACHE_TTL_MS = 3 * 60 * 1000;
const GEMINI_SENTIMENT_COOLDOWN_MS = 10 * 60 * 1000;
const sentimentCache = new Map<
  string,
  { data: CoinSentimentAnalysis; expiresAt: number }
>();
const inFlightSentiment = new Map<string, Promise<CoinSentimentAnalysis>>();
let geminiSentimentCooldownUntil = 0;

function translateFearGreedLabel(classification: string): string {
  const lower = classification.toLowerCase();
  if (lower.includes('extreme fear')) return 'ترس شدید در کل بازار';
  if (lower.includes('fear')) return 'فضای احتیاط و ترس';
  if (lower.includes('extreme greed')) return 'طمع و هیجان شدید';
  if (lower.includes('greed')) return 'خوش‌بینی و طمع';
  return 'حالت خنثی و متعادل';
}

async function fetchGlobalFearGreed(): Promise<CoinSentimentAnalysis['marketFearGreed']> {
  try {
    const res = await fetch('https://api.alternative.me/fng/?limit=1', {
      signal: AbortSignal.timeout(3500),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as {
      data?: Array<{ value?: string; value_classification?: string }>;
    };
    const item = json.data?.[0];
    if (!item?.value) return null;
    const val = Number(item.value);
    if (!Number.isFinite(val)) return null;
    const classification = item.value_classification || 'Neutral';
    return {
      value: val,
      classification,
      classificationFa: translateFearGreedLabel(classification),
    };
  } catch {
    return null;
  }
}

interface RawRssNewsItem {
  title: string;
  link: string;
  pubDate: string;
  sourceName: string;
  impact: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
}

const BULLISH_KEYWORDS = [
  'surge', 'rally', 'soar', 'gain', 'bull', 'etf', 'inflow', 'adoption', 'approval',
  'breakout', 'high', 'record', 'partnership', 'upgrade', 'institutional', 'buy', 'growth',
];
const BEARISH_KEYWORDS = [
  'crash', 'drop', 'plunge', 'fall', 'bear', 'hack', 'exploit', 'lawsuit', 'sec',
  'outflow', 'sell-off', 'selloff', 'ban', 'risk', 'fear', 'decline', 'slump', 'warning',
];

function scoreHeadlineImpact(title: string): 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL' {
  const lower = title.toLowerCase();
  let score = 0;
  for (const kw of BULLISH_KEYWORDS) {
    if (lower.includes(kw)) score += 1;
  }
  for (const kw of BEARISH_KEYWORDS) {
    if (lower.includes(kw)) score -= 1;
  }
  if (score > 0) return 'POSITIVE';
  if (score < 0) return 'NEGATIVE';
  return 'NEUTRAL';
}

function decodeXmlEntities(text: string): string {
  return text
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim();
}

function formatRelativePubDateFa(pubDateStr: string): string {
  const ts = Date.parse(pubDateStr);
  if (!Number.isFinite(ts)) return 'اخیر';
  const diffHours = Math.max(0, Math.round((Date.now() - ts) / (1000 * 60 * 60)));
  if (diffHours < 1) return 'دقایقی پیش';
  if (diffHours < 24) return `${diffHours} ساعت پیش`;
  const diffDays = Math.round(diffHours / 24);
  return `${diffDays} روز پیش`;
}

async function fetchLiveCryptoNewsRss(baseAsset: string): Promise<RawRssNewsItem[]> {
  try {
    const coinNames: Record<string, string> = {
      BTC: 'Bitcoin',
      ETH: 'Ethereum',
      SOL: 'Solana',
      XRP: 'Ripple XRP',
      BNB: 'BNB Binance',
      ADA: 'Cardano',
      DOGE: 'Dogecoin',
      TON: 'Toncoin',
      TRX: 'Tron TRX',
      AVAX: 'Avalanche',
      LINK: 'Chainlink',
      LTC: 'Litecoin',
      SHIB: 'Shiba Inu',
      PEPE: 'Pepe crypto',
      NOT: 'Notcoin',
      DOGS: 'Dogs crypto',
      USDT: 'Tether USDT',
    };
    const queryTerm = coinNames[baseAsset.toUpperCase()] || `${baseAsset} crypto`;
    const url = `https://news.google.com/rss/search?q=${encodeURIComponent(
      `${queryTerm} cryptocurrency`
    )}&hl=en-US&gl=US&ceid=US:en`;

    const res = await fetch(url, {
      headers: { 'User-Agent': 'Mozilla/5.0' },
      signal: AbortSignal.timeout(4500),
    });
    if (!res.ok) return [];
    const xml = await res.text();

    const items: RawRssNewsItem[] = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    let match: RegExpExecArray | null;
    while ((match = itemRegex.exec(xml)) !== null && items.length < 5) {
      const block = match[1];
      const titleRaw = block.match(/<title>([\s\S]*?)<\/title>/)?.[1] || '';
      const linkRaw = block.match(/<link>([\s\S]*?)<\/link>/)?.[1] || '';
      const dateRaw = block.match(/<pubDate>([\s\S]*?)<\/pubDate>/)?.[1] || '';
      const sourceRaw = block.match(/<source[^>]*>([\s\S]*?)<\/source>/)?.[1] || 'خبرگزاری بازار';

      const title = decodeXmlEntities(titleRaw);
      const link = decodeXmlEntities(linkRaw);
      const sourceName = decodeXmlEntities(sourceRaw);
      if (title && link) {
        items.push({
          title,
          link,
          pubDate: decodeXmlEntities(dateRaw),
          sourceName,
          impact: scoreHeadlineImpact(title),
        });
      }
    }
    return items;
  } catch {
    return [];
  }
}

function extractJsonObject(raw: string): Record<string, unknown> | null {
  const cleaned = raw
    .replace(/```json\s*/gi, '')
    .replace(/```/g, '')
    .trim();
  try {
    return JSON.parse(cleaned) as Record<string, unknown>;
  } catch {
    const start = cleaned.indexOf('{');
    const end = cleaned.lastIndexOf('}');
    if (start !== -1 && end > start) {
      try {
        return JSON.parse(cleaned.slice(start, end + 1)) as Record<string, unknown>;
      } catch {
        return null;
      }
    }
    return null;
  }
}

function normalizeSuggestion(val: unknown): SentimentSuggestion {
  const s = String(val || '').toUpperCase().trim();
  if (s === 'BUY') return 'BUY';
  if (s === 'SELL') return 'SELL';
  return 'HOLD';
}

function defaultSuggestionLabel(suggestion: SentimentSuggestion): string {
  if (suggestion === 'BUY') return 'خرید (جو بازار مثبته)';
  if (suggestion === 'SELL') return 'فروش / ذخیره سود';
  return 'نگهداری و صبر (بدون عجله)';
}

function buildFallbackSentimentFromLiveFeeds(input: {
  symbol: string;
  baseAsset: string;
  persianName: string;
  market: UnifiedMarketTicker | null;
  marketFearGreed: CoinSentimentAnalysis['marketFearGreed'];
  rssNews: RawRssNewsItem[];
}): CoinSentimentAnalysis {
  const change24h = input.market?.change24hPercent ?? 0;
  const fngVal = input.marketFearGreed?.value ?? 50;

  let posNews = 0;
  let negNews = 0;
  for (const n of input.rssNews) {
    if (n.impact === 'POSITIVE') posNews += 1;
    if (n.impact === 'NEGATIVE') negNews += 1;
  }

  // Blend news balance, 24h momentum, and Fear & Greed into a 0-100 sentiment score
  let score = 50;
  score += (posNews - negNews) * 8;
  score += Math.max(-18, Math.min(18, change24h * 2.5));
  score += Math.round((fngVal - 50) * 0.35);
  score = Math.max(8, Math.min(92, Math.round(score)));

  let suggestion: SentimentSuggestion = 'HOLD';
  let suggestionLabelFa = 'نگهداری و صبر (فعلاً بدون عجله)';
  let sentimentMoodFa = 'فضای متعادل و در حال رصد بازار';
  let plainSummaryFa = '';
  let socialBuzzFa = '';

  if (score >= 62) {
    suggestion = 'BUY';
    suggestionLabelFa = 'خرید پله‌ای خوبه رفیق (جو بازار مثبته)';
    sentimentMoodFa = 'خوش‌بینی و قدرت خریداران';
    plainSummaryFa = `خبرهای تازه و روند ۲۴ ساعته ${input.persianName} (${change24h >= 0 ? '+' : ''}${change24h.toFixed(1)}%) نشون می‌ده خریداران حسابی سرحالند و دست بالا رو دارن! اگه قصد ورود داری، یهویی کل پولت رو نریز وسط؛ پله‌ای و با حد ضرر مشخص وارد شو.`;
    socialBuzzFa = `توی شبکه‌های اجتماعی بچه‌های کریپتو حسابی درباره ${input.baseAsset} خوش‌بین شدند و همه دنبال شکار موج بعدی‌اند.`;
  } else if (score <= 36) {
    suggestion = fngVal <= 20 && change24h > -1.5 ? 'HOLD' : 'SELL';
    if (suggestion === 'HOLD') {
      suggestionLabelFa = 'صبر کن و نفس عمیق بکش (ترس شدید در بازار)';
      sentimentMoodFa = 'ترس و احتیاط شدید معامله‌گران';
      plainSummaryFa = `شاخص ترس و طمع کل بازار رفته روی ${fngVal} و یه کم جو ترس حاکمه. توی این شلوغی معمولاً فروش هیجانی کار دست آدم می‌ده؛ اگه ارز رو داری عجولانه تو ضرر نفروش و اگه دنبال خریدی، بذار گرد و خاک بخوابه بعد وارد شو.`;
      socialBuzzFa = `کاربران توی X و ردیت یه کم استرس گرفتن و فعلاً بیشترشون توصیه می‌کنن دست به عصا راه بریم و نقد بمونیم.`;
    } else {
      suggestionLabelFa = 'مراقب سودت باش رفیق (فشار فروش)';
      sentimentMoodFa = 'فشار فروش و فضای منفی خبرها';
      plainSummaryFa = `تیترهای خبری اخیر و افت ${Math.abs(change24h).toFixed(1)} درصدی قیمت ${input.persianName} می‌گه فروشنده‌ها فعلاً زورشون بیشتره. اگه توی سودی، بد نیست یه بخشی رو بذاری تو جیبت یا حد ضررت رو سفت ببندی که غافلگیر نشی!`;
      socialBuzzFa = `فضای گفتگوهای کاربران تو شبکه‌های اجتماعی یه کم سنگینه و خیلیا فعلاً از ترس اصلاح بیشتر دست نگه داشتن.`;
    }
  } else {
    suggestion = 'HOLD';
    suggestionLabelFa = 'چایی بریز و صبر کن (فعلاً خبری نیست)';
    sentimentMoodFa = 'خنثی و منتظر حرکت بعدی بازار';
    plainSummaryFa = `الان خبرهای مثبت و منفی درباره ${input.persianName} سر به سر شدند و قیمت در نوبیتکس تغییر آرومی (${change24h >= 0 ? '+' : ''}${change24h.toFixed(1)}%) داشته. انگار بازار چرت بعدازظهر زده! صبر کن جهت روشن‌تر بشه بعد پله‌ای تصمیم بگیر.`;
    socialBuzzFa = `توی شبکه‌های اجتماعی دو دستگیه؛ نصفشون می‌گن الان می‌پره بالا، نصفشون می‌گن می‌ریزه، خلاصه هنوز کسی تکلیفش با خودش معلوم نیست!`;
  }

  const newsItems: SentimentNewsItem[] = input.rssNews.slice(0, 4).map((item) => ({
    headline: item.title,
    summary:
      item.impact === 'POSITIVE'
        ? `گزارش تازه از ${item.sourceName} با بار خبری مثبت برای ${input.persianName}`
        : item.impact === 'NEGATIVE'
          ? `گزارش تازه از ${item.sourceName} که فضای احتیاط و ریسک را نشان می‌دهد`
          : `پوشش خبری جدید درباره وضعیت ${input.persianName} در ${item.sourceName}`,
    impact: item.impact,
    dateHint: formatRelativePubDateFa(item.pubDate),
  }));

  const sources: SentimentSourceLink[] = input.rssNews.slice(0, 5).map((item) => ({
    title: `${item.sourceName} — ${item.title.slice(0, 60)}`,
    url: item.link,
  }));

  return {
    baseAsset: input.baseAsset.toUpperCase(),
    symbol: input.symbol,
    generatedAt: Date.now(),
    suggestion,
    suggestionLabelFa,
    sentimentScore: score,
    sentimentMoodFa,
    marketFearGreed: input.marketFearGreed,
    plainSummaryFa,
    socialBuzzFa,
    newsItems,
    sources,
  };
}

export async function generateCoinSentimentAnalysis(input: {
  symbol: string;
  baseAsset: string;
  persianName: string;
  market: UnifiedMarketTicker | null;
  forceRefresh?: boolean;
}): Promise<CoinSentimentAnalysis> {
  const cacheKey = input.baseAsset.toUpperCase();
  const cached = sentimentCache.get(cacheKey);
  if (!input.forceRefresh && cached && cached.expiresAt > Date.now()) {
    return { ...cached.data, symbol: input.symbol };
  }

  const pending = inFlightSentiment.get(cacheKey);
  if (pending) {
    const res = await pending;
    return { ...res, symbol: input.symbol };
  }

  const task = (async (): Promise<CoinSentimentAnalysis> => {
    // Always fetch live public Fear & Greed + real Google News RSS headlines first
    const [marketFearGreed, rssNews] = await Promise.all([
      fetchGlobalFearGreed(),
      fetchLiveCryptoNewsRss(cacheKey),
    ]);

    const hasGeminiKey = Boolean(process.env.GEMINI_API_KEY?.trim());
    const inQuotaCooldown = Date.now() < geminiSentimentCooldownUntil;

    if (!hasGeminiKey || inQuotaCooldown) {
      const fallback = buildFallbackSentimentFromLiveFeeds({
        symbol: input.symbol,
        baseAsset: cacheKey,
        persianName: input.persianName,
        market: input.market,
        marketFearGreed,
        rssNews,
      });
      sentimentCache.set(cacheKey, {
        data: fallback,
        expiresAt: Date.now() + SENTIMENT_FALLBACK_CACHE_TTL_MS,
      });
      return fallback;
    }

    try {
      const ai = getGeminiClient();

      const livePriceContext = input.market
        ? `قیمت فعلی در نوبیتکس: ${Math.round(input.market.priceToman).toLocaleString('en-US')} تومان (${input.market.priceUsdt} دلار)، تغییر ۲۴ ساعته: ${input.market.change24hPercent.toFixed(2)}%`
        : `نماد: ${input.symbol}`;

      const fngContext = marketFearGreed
        ? `شاخص ترس و طمع کل بازار کریپتو (Fear & Greed Index): ${marketFearGreed.value} از ۱۰۰ (${marketFearGreed.classification})`
        : '';

      const newsBullets =
        rssNews.length > 0
          ? `تیترهای واقعی اخبار تازه:\n${rssNews.map((n, i) => `${i + 1}. ${n.title} (${n.sourceName})`).join('\n')}`
          : '';

      const prompt = `امروز جدیدترین اخبار بازار کریپتو، گزارش‌های تحلیلی و جو شبکه‌های اجتماعی (مثل X/توییتر و ردیت) درباره ارز دیجیتال ${input.baseAsset} (${input.persianName}) را با جستجو بررسی کن.
${livePriceContext}
${fngContext}
${newsBullets}

خروجی را دقیقاً و فقط به صورت یک آبجکت JSON معتبر (بدون هیچ متن اضافه یا \`\`\`) با ساختار زیر برگردان:
{
  "suggestion": "BUY" | "SELL" | "HOLD",
  "suggestionLabelFa": "پیشنهاد خیلی کوتاه و ساده فارسی مثلاً: خرید پله‌ای خوبه / وقت فروش و سیو سوده / فعلاً دست نگه دار و صبر کن",
  "sentimentScore": 0 تا 100 (عدد صحیح؛ 0 خیلی منفی، 50 خنثی، 100 خیلی مثبت),
  "sentimentMoodFa": "یک عبارت کوتاه فارسی مثلاً: خوش‌بین و صعودی / محتاط و مردد / ترس و فشار فروش",
  "plainSummaryFa": "۲ تا ۳ جمله کاملاً ساده، خودمونی و فارسی که بر اساس خبرهای جدید و جو بازار توضیح بده چرا بهتره بخریم، بفروشیم یا صبر کنیم.",
  "socialBuzzFa": "۱ تا ۲ جمله ساده فارسی درباره اینکه کاربران و تریدرها در شبکه‌های اجتماعی (X و ردیت و جامعه کریپتو) الان درباره این ارز چی میگن و حال‌وهوا چطوره.",
  "newsItems": [
    {
      "headline": "تیتر کوتاه خبر واقعی به فارسی روان",
      "summary": "توضیح یک جمله‌ای خیلی ساده که این خبر چه تاثیری روی قیمت داره",
      "impact": "POSITIVE" | "NEGATIVE" | "NEUTRAL",
      "dateHint": "مثلاً امروز یا ۲ روز پیش"
    }
  ]
}
حداکثر ۴ خبر واقعی و تازه در newsItems بگذار.`;

      const response = await ai.models.generateContent({
        model: 'gemini-4-hydrogen',
        contents: prompt,
        config: {
          tools: [{ googleSearch: {} }],
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction:
            'تو یک تحلیلگر باحال، شوخ‌طبع و خودمونی کریپتو هستی که اخبار زنده و جو شبکه‌های اجتماعی رو بررسی می‌کنی و نتیجه رو خیلی راحت، خاکی، شیرین و بدون اصطلاحات خشک کتابی برای کاربر ایرانی توی JSON برمی‌گردانی. هیچ حرف اضافه خارج از JSON ننویس.',
        },
      });

      const rawText = (response.text ?? '').trim();
      const parsed = extractJsonObject(rawText);

      const groundingChunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      const seenUrls = new Set<string>();
      const sources: SentimentSourceLink[] = [];
      for (const chunk of groundingChunks) {
        const uri = chunk.web?.uri?.trim();
        const title = chunk.web?.title?.trim() || uri;
        if (uri && !seenUrls.has(uri)) {
          seenUrls.add(uri);
          sources.push({ title: title || 'منبع خبری', url: uri });
        }
      }
      for (const rss of rssNews) {
        if (sources.length >= 6) break;
        if (!seenUrls.has(rss.link)) {
          seenUrls.add(rss.link);
          sources.push({ title: `${rss.sourceName} — ${rss.title.slice(0, 50)}`, url: rss.link });
        }
      }

      const suggestion = normalizeSuggestion(parsed?.suggestion);
      const rawScore = Number(parsed?.sentimentScore);
      const sentimentScore = Number.isFinite(rawScore)
        ? Math.max(0, Math.min(100, Math.round(rawScore)))
        : suggestion === 'BUY'
          ? 68
          : suggestion === 'SELL'
            ? 32
            : 50;

      const rawNews = Array.isArray(parsed?.newsItems) ? parsed.newsItems : [];
      const newsItems: SentimentNewsItem[] = rawNews
        .slice(0, 4)
        .map((item) => {
          const obj = (item || {}) as Record<string, unknown>;
          const rawImpact = String(obj.impact || '').toUpperCase();
          const impact: SentimentNewsItem['impact'] =
            rawImpact === 'POSITIVE' || rawImpact === 'NEGATIVE' ? rawImpact : 'NEUTRAL';
          return {
            headline: String(obj.headline || `خبر مرتبط با ${input.persianName}`).trim(),
            summary: String(obj.summary || '').trim(),
            impact,
            dateHint: obj.dateHint ? String(obj.dateHint).trim() : undefined,
          };
        })
        .filter((n) => n.headline.length > 0);

      const result: CoinSentimentAnalysis = {
        baseAsset: cacheKey,
        symbol: input.symbol,
        generatedAt: Date.now(),
        suggestion,
        suggestionLabelFa:
          typeof parsed?.suggestionLabelFa === 'string' && parsed.suggestionLabelFa.trim()
            ? parsed.suggestionLabelFa.trim()
            : defaultSuggestionLabel(suggestion),
        sentimentScore,
        sentimentMoodFa:
          typeof parsed?.sentimentMoodFa === 'string' && parsed.sentimentMoodFa.trim()
            ? parsed.sentimentMoodFa.trim()
            : sentimentScore >= 60
              ? 'جو مثبت و امیدوارکننده'
              : sentimentScore <= 40
                ? 'فضای محتاط و منفی'
                : 'متعادل و در انتظار جهت',
        marketFearGreed,
        plainSummaryFa:
          typeof parsed?.plainSummaryFa === 'string' && parsed.plainSummaryFa.trim()
            ? parsed.plainSummaryFa.trim()
            : rawText ||
              'بر اساس خبرها و فضای فعلی بازار، فعلاً بهتره بدون هیجان تصمیم بگیریم و روند قیمت رو زیر نظر داشته باشیم.',
        socialBuzzFa:
          typeof parsed?.socialBuzzFa === 'string' && parsed.socialBuzzFa.trim()
            ? parsed.socialBuzzFa.trim()
            : 'گفتگوهای کاربران در شبکه‌های اجتماعی درباره حرکت بعدی این ارز با احتیاط و پیگیری اخبار کلان بازار همراه است.',
        newsItems:
          newsItems.length > 0
            ? newsItems
            : rssNews.slice(0, 4).map((r) => ({
                headline: r.title,
                summary: `خبر تازه از ${r.sourceName}`,
                impact: r.impact,
                dateHint: formatRelativePubDateFa(r.pubDate),
              })),
        sources: sources.slice(0, 6),
      };

      sentimentCache.set(cacheKey, {
        data: result,
        expiresAt: Date.now() + SENTIMENT_CACHE_TTL_MS,
      });

      return result;
    } catch (err) {
      const classified = classifyGeminiError(err);
      if (classified.isQuotaExceeded || classified.statusCode === 403) {
        geminiSentimentCooldownUntil = Date.now() + GEMINI_SENTIMENT_COOLDOWN_MS;
      }
      const fallback = buildFallbackSentimentFromLiveFeeds({
        symbol: input.symbol,
        baseAsset: cacheKey,
        persianName: input.persianName,
        market: input.market,
        marketFearGreed,
        rssNews,
      });
      sentimentCache.set(cacheKey, {
        data: fallback,
        expiresAt: Date.now() + SENTIMENT_FALLBACK_CACHE_TTL_MS,
      });
      return fallback;
    }
  })();

  inFlightSentiment.set(cacheKey, task);
  try {
    return await task;
  } finally {
    inFlightSentiment.delete(cacheKey);
  }
}

function computeHeuristicBotManagerReport(input: {
  markets: UnifiedMarketTicker[];
  botSummaries: UnifiedBotSummaryRow[];
  riskSettings: SharedBotRiskSettings;
  usedFallback?: boolean;
}): AiManagerAnalysis {
  const topLiquid = [...input.markets]
    .filter((m) => m.priceToman > 0 && m.volumeToman > 0)
    .sort((a, b) => b.volumeToman - a.volumeToman)
    .slice(0, 12);

  const avgChange =
    topLiquid.length > 0
      ? topLiquid.reduce((s, m) => s + m.change24hPercent, 0) / topLiquid.length
      : 0;
  const avgRangePct =
    topLiquid.length > 0
      ? topLiquid.reduce((s, m) => {
          const span =
            m.low24hToman > 0 ? ((m.high24hToman - m.low24hToman) / m.low24hToman) * 100 : 2;
          return s + span;
        }, 0) / topLiquid.length
      : 2;

  let regime: MarketRegimeType = 'RANGING';
  let regimeLabelFa = 'خنثی و نوسانی در محدوده';
  let recommendedPrimaryBotType: BotType = 'GRID';
  if (avgRangePct >= 6.5) {
    regime = 'VOLATILE';
    regimeLabelFa = 'پرنوسان و هیجانی';
    recommendedPrimaryBotType = 'PROFIT';
  } else if (avgChange >= 2.2) {
    regime = 'BULLISH';
    regimeLabelFa = 'صعودی و امیدوارکننده';
    recommendedPrimaryBotType = 'STRATEGY';
  } else if (avgChange <= -2.2) {
    regime = 'BEARISH';
    regimeLabelFa = 'نزولی و اصلاحی';
    recommendedPrimaryBotType = 'DCA';
  }

  const rankedCoins: AiBotManagerCoinRank[] = topLiquid.slice(0, 6).map((m, idx) => {
    const spreadPct =
      m.bestSellToman > 0 && m.bestBuyToman > 0
        ? ((m.bestSellToman - m.bestBuyToman) / m.bestSellToman) * 100
        : 0.4;
    const rangePct =
      m.low24hToman > 0 ? ((m.high24hToman - m.low24hToman) / m.low24hToman) * 100 : 2.5;
    const liqScore = Math.max(40, Math.min(98, 92 - idx * 6 - spreadPct * 8));
    let recBot: BotType = 'GRID';
    if (m.change24hPercent >= 3) recBot = 'STRATEGY';
    else if (m.change24hPercent <= -3) recBot = 'DCA';
    else if (rangePct >= 5) recBot = 'PROFIT';

    return {
      symbol: m.hasIrtMarket ? m.symbolIrt : m.symbolUsdt,
      baseAsset: m.baseAsset,
      persianName: m.persianName,
      score: Math.round(liqScore),
      liquidityScore: Math.round(liqScore),
      volatilityLabelFa: rangePct >= 6 ? 'نوسان بالا' : rangePct >= 3 ? 'نوسان متعادل' : 'آرام و خنثی',
      trendLabelFa:
        m.change24hPercent >= 2 ? 'صعودی' : m.change24hPercent <= -2 ? 'نزولی' : 'رِنج / خنثی',
      recommendedBotType: recBot,
      reasonFa:
        recBot === 'GRID'
          ? 'قیمت در بازه مشخصی نوسان می‌کنه؛ ربات گرید با خرید پایین و فروش بالا می‌تونه از هر موج سود بگیره.'
          : recBot === 'DCA'
            ? 'بعد از اصلاح قیمتی، خرید پله‌ای میانگین خرید رو منطقی‌تر می‌کنه.'
            : recBot === 'PROFIT'
              ? 'نقدینگی خوب و نوسان لحظه‌ای مناسب برای شکار سود خالص مشخص پس از کارمزد.'
              : 'مومنتوم و جهت روند روشنه و ربات استراتژی می‌تونه شکست یا کراس صعودی رو شکار کنه.',
    };
  });

  const activeBySymbol = new Map<string, UnifiedBotSummaryRow[]>();
  for (const b of input.botSummaries) {
    if (!b.isActive) continue;
    const list = activeBySymbol.get(b.symbol) || [];
    list.push(b);
    activeBySymbol.set(b.symbol, list);
  }
  const conflictAlerts: AiBotManagerConflictAlert[] = [];
  for (const [symbol, list] of activeBySymbol.entries()) {
    if (list.length > 1) {
      conflictAlerts.push({
        symbol,
        botIds: list.map((x) => x.id),
        botNames: list.map((x) => x.name),
        severity: 'HIGH',
        messageFa: `چند ربات هم‌زمان روی ${symbol} فعال هستند (${list
          .map((x) => x.name)
          .join(' و ')}) که ریسک هم‌پوشانی سرمایه یا سفارش متناقض ایجاد می‌کند.`,
      });
    }
  }

  const botReviews: AiBotManagerBotReview[] = input.botSummaries.slice(0, 12).map((b) => {
    const winRate = b.winRatePercent || 0;
    const health: AiBotManagerBotReview['health'] =
      b.realizedPnlQuote < 0 && b.tradesCount >= 3
        ? 'NEEDS_REVIEW'
        : conflictAlerts.some((c) => c.botIds.includes(b.id))
          ? 'CAUTION'
          : 'HEALTHY';
    return {
      botId: b.id,
      botName: b.name,
      botType: b.botType,
      health,
      summaryFa:
        health === 'NEEDS_REVIEW'
          ? `عملکرد فعلی منفی بوده (نرخ برد ${winRate.toFixed(0)}٪)؛ بازبینی حد ضرر و شرایط ورود پیشنهاد می‌شود.`
          : health === 'CAUTION'
            ? 'هم‌زمانی با ربات دیگر روی همین نماد؛ بودجه این جفت‌ارز را بررسی کنید.'
            : b.isActive
              ? 'در محدوده امن بودجه و مطابق قوانین ریسک مشترک در حال کار است.'
              : 'آماده اجرا؛ قبل از روشن کردن، بودجه آزاد و شرایط بازار را چک کنید.',
      suggestedAction: health === 'NEEDS_REVIEW' ? 'PAUSE' : 'KEEP',
    };
  });

  const proposals: AiBotManagerProposal[] = [];
  for (const c of conflictAlerts) {
    proposals.push({
      id: `prop-conflict-${c.symbol}`,
      actionType: 'STOP_BOT',
      targetBotId: c.botIds[1],
      targetBotType: input.botSummaries.find((x) => x.id === c.botIds[1])?.botType,
      titleFa: `جلوگیری از تداخل روی ${c.symbol}`,
      reasonFa: c.messageFa,
      withinApprovedLimits: true,
    });
  }
  if (rankedCoins[0]) {
    proposals.push({
      id: `prop-top-${rankedCoins[0].symbol}`,
      actionType: 'CREATE_RECOMMENDATION',
      recommendedBotType: recommendedPrimaryBotType,
      recommendedSymbol: rankedCoins[0].symbol,
      titleFa: `پیشنهاد اجرای ربات مناسب روی ${rankedCoins[0].persianName}`,
      reasonFa: `وضعیت کلی بازار «${regimeLabelFa}» است و نقدینگی ${rankedCoins[0].persianName} در صدر بازار قرار دارد.`,
      withinApprovedLimits: true,
    });
  }

  return {
    id: `aim-${Date.now()}`,
    generatedAt: Date.now(),
    regime,
    regimeLabelFa,
    marketSummaryFa: `بررسی داده‌های زنده نوبیتکس نشان می‌دهد میانگین تغییر ۲۴ ساعته بازار ${avgChange.toFixed(
      2
    )}٪ و نوسان میانگین حدود ${avgRangePct.toFixed(1)}٪ است.${
      input.usedFallback ? ' (تحلیل بر اساس داده‌های زنده بازار و موتور هوشمند داخلی)' : ''
    }`,
    recommendedPrimaryBotType,
    recommendedPrimaryBotReasonFa:
      recommendedPrimaryBotType === 'GRID'
        ? 'در بازار رِنج و نوسانی محدود، ربات گرید با تقسیم سرمایه در پله‌های قیمتی بهترین کارایی را دارد.'
        : recommendedPrimaryBotType === 'DCA'
          ? 'در بازار اصلاحی، ربات خرید پله‌ای (DCA) میانگین قیمت ورود را کاهش می‌دهد و ریسک خرید یک‌جا را حذف می‌کند.'
          : recommendedPrimaryBotType === 'PROFIT'
            ? 'در نوسانات تند، ربات سود با محاسبه دقیق کارمزد و هدف سود خالص انتخاب مطمئن‌تری است.'
            : 'در روند صعودی شفاف، ربات استراتژی با تایید حجم و حد سود متحرک فرصت میان‌مدت را شکار می‌کند.',
    rankedCoins,
    botReviews,
    conflictAlerts,
    proposals,
    usedFallback: Boolean(input.usedFallback),
  };
}

export async function generateAiBotManagerReport(input: {
  markets: UnifiedMarketTicker[];
  usdtTomanRate: number;
  botSummaries: UnifiedBotSummaryRow[];
  riskSettings: SharedBotRiskSettings;
}): Promise<AiManagerAnalysis> {
  const heuristic = computeHeuristicBotManagerReport({
    markets: input.markets,
    botSummaries: input.botSummaries,
    riskSettings: input.riskSettings,
    usedFallback: true,
  });

  if (!process.env.GEMINI_API_KEY?.trim()) {
    return heuristic;
  }

  try {
    const ai = getGeminiClient();
    const topMarketSnapshot = input.markets
      .filter((m) => m.priceToman > 0)
      .slice(0, 12)
      .map((m) => ({
        symbol: m.hasIrtMarket ? m.symbolIrt : m.symbolUsdt,
        baseAsset: m.baseAsset,
        persianName: m.persianName,
        priceToman: m.priceToman,
        change24hPercent: Number(m.change24hPercent.toFixed(2)),
        volumeToman: Math.round(m.volumeToman),
        highLowSpanPct:
          m.low24hToman > 0
            ? Number((((m.high24hToman - m.low24hToman) / m.low24hToman) * 100).toFixed(2))
            : 0,
      }));

    const botsDigest = input.botSummaries.slice(0, 15).map((b) => ({
      id: b.id,
      name: b.name,
      type: b.botType,
      symbol: b.symbol,
      mode: b.mode,
      isActive: b.isActive,
      committed: b.committedCapitalQuote,
      realizedPnl: b.realizedPnlQuote,
      winRate: b.winRatePercent,
      status: b.statusLabelFa,
    }));

    const prompt = `تو «مدیر هوشمند مرکزی ربات‌های ainobibot» هستی.
وضعیت بازار نوبیتکس، فهرست ربات‌های کاربر و سقف ریسک مشترک را تحلیل کن.
قانون طلایی ایمنی: هیچ‌گاه پیشنهاد تغییر مستقل سقف بودجه یا ضرر کاربر را خودکار اعمال نکن؛ فقط مشاوره دقیق و صادقانه بده و هیچ سودی را تضمین نکن.

داده لحظه‌ای بازارهای برتر نوبیتکس:
${JSON.stringify(topMarketSnapshot)}

ربات‌های فعلی کاربر:
${JSON.stringify(botsDigest)}

محدودیت ریسک مشترک:
بودجه کل تومانی: ${input.riskSettings.totalBotsBudgetIrt} | سقف هر ربات: ${input.riskSettings.maxPerBotCapitalIrt} | سقف ضرر روزانه: ${input.riskSettings.maxDailyLossIrt} | قفل تداخل ارز: ${input.riskSettings.enableSymbolConflictLock}

تضادهای تشخیص‌داده‌شده:
${JSON.stringify(heuristic.conflictAlerts)}

لطفاً خروجی را دقیقاً مطابق اسکیمای JSON برگردان با لحن فارسی شفاف، حرفه‌ای، ساده و صمیمی.`;

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            regime: { type: Type.STRING, enum: ['BULLISH', 'BEARISH', 'RANGING', 'VOLATILE'] },
            regimeLabelFa: { type: Type.STRING },
            marketSummaryFa: { type: Type.STRING },
            recommendedPrimaryBotType: {
              type: Type.STRING,
              enum: ['AI_CYCLE_PRO', 'PROFIT', 'FIXED_PRICE', 'GRID', 'DCA', 'STRATEGY'],
            },
            recommendedPrimaryBotReasonFa: { type: Type.STRING },
            rankedCoins: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  symbol: { type: Type.STRING },
                  baseAsset: { type: Type.STRING },
                  persianName: { type: Type.STRING },
                  score: { type: Type.NUMBER },
                  liquidityScore: { type: Type.NUMBER },
                  volatilityLabelFa: { type: Type.STRING },
                  trendLabelFa: { type: Type.STRING },
                  recommendedBotType: {
                    type: Type.STRING,
                    enum: ['AI_CYCLE_PRO', 'PROFIT', 'FIXED_PRICE', 'GRID', 'DCA', 'STRATEGY'],
                  },
                  reasonFa: { type: Type.STRING },
                },
                required: [
                  'symbol',
                  'baseAsset',
                  'persianName',
                  'score',
                  'recommendedBotType',
                  'reasonFa',
                ],
              },
            },
            botReviews: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  botId: { type: Type.STRING },
                  botName: { type: Type.STRING },
                  botType: { type: Type.STRING },
                  health: { type: Type.STRING, enum: ['HEALTHY', 'CAUTION', 'NEEDS_REVIEW'] },
                  summaryFa: { type: Type.STRING },
                  suggestedAction: { type: Type.STRING, enum: ['KEEP', 'PAUSE', 'ADJUST'] },
                },
                required: ['botId', 'botName', 'health', 'summaryFa', 'suggestedAction'],
              },
            },
            proposals: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  id: { type: Type.STRING },
                  actionType: {
                    type: Type.STRING,
                    enum: ['PAUSE_BOT', 'START_BOT', 'STOP_BOT', 'ADJUST_SETTINGS', 'CREATE_RECOMMENDATION'],
                  },
                  targetBotId: { type: Type.STRING },
                  recommendedBotType: { type: Type.STRING },
                  recommendedSymbol: { type: Type.STRING },
                  titleFa: { type: Type.STRING },
                  reasonFa: { type: Type.STRING },
                },
                required: ['id', 'actionType', 'titleFa', 'reasonFa'],
              },
            },
          },
          required: [
            'regime',
            'regimeLabelFa',
            'marketSummaryFa',
            'recommendedPrimaryBotType',
            'recommendedPrimaryBotReasonFa',
            'rankedCoins',
          ],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}') as Partial<AiManagerAnalysis>;
    return {
      id: `aim-${Date.now()}`,
      generatedAt: Date.now(),
      regime: (parsed.regime as MarketRegimeType) || heuristic.regime,
      regimeLabelFa: parsed.regimeLabelFa || heuristic.regimeLabelFa,
      marketSummaryFa: parsed.marketSummaryFa || heuristic.marketSummaryFa,
      recommendedPrimaryBotType:
        (parsed.recommendedPrimaryBotType as BotType) || heuristic.recommendedPrimaryBotType,
      recommendedPrimaryBotReasonFa:
        parsed.recommendedPrimaryBotReasonFa || heuristic.recommendedPrimaryBotReasonFa,
      rankedCoins:
        Array.isArray(parsed.rankedCoins) && parsed.rankedCoins.length > 0
          ? parsed.rankedCoins.slice(0, 6)
          : heuristic.rankedCoins,
      botReviews:
        Array.isArray(parsed.botReviews) && parsed.botReviews.length > 0
          ? parsed.botReviews
          : heuristic.botReviews,
      conflictAlerts: heuristic.conflictAlerts,
      proposals:
        Array.isArray(parsed.proposals) && parsed.proposals.length > 0
          ? parsed.proposals.map((p) => ({ ...p, withinApprovedLimits: true }))
          : heuristic.proposals,
      usedFallback: false,
    };
  } catch {
    return heuristic;
  }
}

export interface AnalyzeAiCycleProInput {
  symbol: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  capitalAmount: number;
  capitalUsageMode: AiCycleProCapitalUsageMode;
  capitalPortionPercent: number;
  minTargetNetProfitPercent: number;
  stopLossPercent: number;
  maxSlippagePercent: number;
  maxSpreadPercent: number;
  feeRate: number;
  market?: UnifiedMarketTicker | null;
  snapshot15m?: IndicatorSnapshot | null;
  snapshot1h?: IndicatorSnapshot | null;
  orderBook: OrderBookSnapshot;
  bidDepthQuote: number;
  askDepthQuote: number;
  buySlippagePercent: number;
  sellSlippagePercent: number;
  canFillBuyFull: boolean;
  hasSufficientSellDepth: boolean;
  executableBuyPrice: number;
  executableSellPrice: number;
  activePosition?: AiCycleProPosition | null;
  now?: number;
}

export function computeHeuristicAiCycleProDecision(
  input: AnalyzeAiCycleProInput
): AiCycleProDecision {
  const now = input.now ?? Date.now();
  const snap15 = input.snapshot15m;
  const snap1h = input.snapshot1h;
  const currentPrice =
    input.executableBuyPrice ||
    input.orderBook.lastTradePrice ||
    (input.quoteCurrency === 'IRT' ? input.market?.priceToman : input.market?.priceUsdt) ||
    0;

  const spreadPercent = Number((input.orderBook.spreadPercent || 0).toFixed(3));
  const estSlippage = Number(
    (input.activePosition ? input.sellSlippagePercent : input.buySlippagePercent).toFixed(3)
  );

  // Volatility from ATR(14) or 24h range
  const atrPct15 =
    snap15 && snap15.price > 0 ? (snap15.atr14 / snap15.price) * 100 : 0;
  const range24Pct =
    input.market &&
    (input.quoteCurrency === 'IRT' ? input.market.low24hToman : input.market.low24hUsdt) > 0
      ? (((input.quoteCurrency === 'IRT'
          ? input.market.high24hToman - input.market.low24hToman
          : input.market.high24hUsdt - input.market.low24hUsdt) /
          (input.quoteCurrency === 'IRT' ? input.market.low24hToman : input.market.low24hUsdt)) *
          100)
      : 0;
  const volatilityPercent = Number(Math.max(atrPct15, range24Pct * 0.25, 0.4).toFixed(2));

  // Liquidity score based on orderbook depth vs allocated capital & spread
  const targetDepth = Math.max(1, input.capitalAmount * 2);
  const relevantDepth = input.activePosition ? input.bidDepthQuote : input.askDepthQuote;
  const depthRatio = Math.min(1, relevantDepth / targetDepth);
  const spreadPenalty = Math.min(45, spreadPercent * 16);
  const slipPenalty = Math.min(35, estSlippage * 25);
  const liquidityScore = Math.max(
    5,
    Math.min(100, Math.round(depthRatio * 65 + 35 - spreadPenalty - slipPenalty))
  );

  // Trend & momentum score (0-100)
  let trendScore = 50;
  const rsi = snap15?.rsi14 ?? 50;
  if (snap15) {
    if (snap15.ema9 > snap15.ema20) trendScore += 10;
    else trendScore -= 8;
    if (snap15.ema20 > snap15.ema50) trendScore += 10;
    else trendScore -= 8;
    if (snap15.macd.histogram > 0) trendScore += 8;
    else trendScore -= 7;
    if (rsi >= 34 && rsi <= 62) trendScore += 8;
    else if (rsi > 74) trendScore -= 16;
    else if (rsi < 26) trendScore -= 6;
    if (snap15.volumeRatio >= 1.1) trendScore += 6;
  }
  if (snap1h) {
    if (snap1h.ema20 > snap1h.ema50) trendScore += 8;
    else trendScore -= 6;
  }
  const chg24 = input.market?.change24hPercent ?? 0;
  if (chg24 >= 0.3 && chg24 <= 10) trendScore += 4;
  else if (chg24 < -6) trendScore -= 12;
  trendScore = Math.max(5, Math.min(98, Math.round(trendScore)));

  const spreadOk = spreadPercent <= input.maxSpreadPercent;
  const slippageOk = estSlippage <= input.maxSlippagePercent;
  const depthOk = input.activePosition ? input.hasSufficientSellDepth : input.canFillBuyFull;
  const volatilitySafe = volatilityPercent <= 9.5;

  let marketCondition: AiCycleProDecision['marketCondition'] = 'NEUTRAL';
  if (!spreadOk || !slippageOk || !depthOk || !volatilitySafe || trendScore < 36) {
    marketCondition = 'UNFAVORABLE';
  } else if (trendScore >= 54 && liquidityScore >= 50 && rsi <= 68) {
    marketCondition = 'FAVORABLE';
  }

  const userPortion =
    input.capitalUsageMode === 'PARTIAL'
      ? Math.min(100, Math.max(10, Math.round(input.capitalPortionPercent || 50)))
      : 100;
  const recommendedCapitalPortionPercent =
    marketCondition === 'UNFAVORABLE'
      ? 0
      : marketCondition === 'NEUTRAL'
        ? Math.min(userPortion, 60)
        : userPortion;

  const roundTripCostPct = input.feeRate * 200 + estSlippage * 1.5;
  const dynamicTpPct = Number(
    Math.max(
      input.minTargetNetProfitPercent,
      Math.min(6.0, roundTripCostPct + Math.max(0.8, volatilityPercent * 0.48))
    ).toFixed(2)
  );
  const dynamicSlPct = Number(
    Math.max(1.2, Math.min(input.stopLossPercent || 3.5, Math.max(2.0, volatilityPercent * 0.9))).toFixed(2)
  );

  const feeFactor = 1 - input.feeRate;
  const suggestedBuyPrice = currentPrice;
  const suggestedSellPrice =
    suggestedBuyPrice > 0
      ? Number(
          (
            (suggestedBuyPrice * (1 + dynamicTpPct / 100)) /
            Math.max(0.9, feeFactor * feeFactor * (1 - estSlippage / 100))
          ).toFixed(input.quoteCurrency === 'IRT' ? 0 : 4)
        )
      : 0;

  let action: AiCycleProDecision['action'] = 'HOLD_CASH';
  let regimeLabelFa = 'بازار متعادل و کم‌نوسان';
  let reasoningFa = '';
  let riskWarningFa = 'همیشه سقف زیان روزانه و حد ضرر فعال باقی می‌ماند.';

  if (input.activePosition) {
    const pos = input.activePosition;
    const netProceeds =
      input.executableSellPrice * pos.netOwnedQty * (1 - input.feeRate);
    const estNetPnl = netProceeds - pos.totalBuyCostQuote;
    const estNetPct =
      pos.totalBuyCostQuote > 0 ? (estNetPnl / pos.totalBuyCostQuote) * 100 : 0;

    if (estNetPct >= pos.targetNetProfitPercent && input.hasSufficientSellDepth) {
      action = 'SELL';
      regimeLabelFa = 'رسیدن به هدف سود خالص';
      reasoningFa = `سود خالص قابل تحقق با لحاظ کارمزد و عمق دفتر سفارش به +${estNetPct.toFixed(
        2
      )}٪ رسیده است؛ زمان ثبت فروش هوشمند و قفل سود است.`;
    } else if (
      marketCondition === 'UNFAVORABLE' &&
      trendScore < 32 &&
      estNetPct >= Math.max(0.25, input.minTargetNetProfitPercent * 0.4)
    ) {
      action = 'SELL';
      regimeLabelFa = 'تضعیف روند — خروج با سود';
      reasoningFa = `فشار فروش در روند کوتاه‌مدت دیده شد و معامله در سود خالص +${estNetPct.toFixed(
        2
      )}٪ است؛ خروج هوشمند برای حفظ سود انجام می‌شود.`;
    } else {
      action = 'HOLD_POSITION';
      regimeLabelFa =
        marketCondition === 'FAVORABLE' ? 'روند صعودی — نگهداری تا هدف' : 'پایش پوزیشن باز';
      reasoningFa = `معامله فعال است (بازده فعلی پس از کارمزد: ${
        estNetPct >= 0 ? '+' : ''
      }${estNetPct.toFixed(2)}٪ از هدف +${pos.targetNetProfitPercent.toFixed(
        2
      )}٪). ربات در حال پایش دفتر سفارش و حد ضرر است.`;
    }
  } else {
    if (marketCondition === 'FAVORABLE') {
      action = 'BUY';
      regimeLabelFa = 'شرایط مناسب ورود (نقدشوندگی و روند مثبت)';
      reasoningFa = `روند کوتاه‌مدت (امتیاز ${trendScore}/100)، حجم معاملات، اسپرد (${spreadPercent.toFixed(
        2
      )}٪) و لغزش برآوردی (${estSlippage.toFixed(
        2
      )}٪) مناسب است. هدف سود خالص چرخه +${dynamicTpPct.toFixed(2)}٪ تعیین شد.`;
    } else {
      action = 'HOLD_CASH';
      const reasons: string[] = [];
      if (!spreadOk) reasons.push(`اسپرد دفتر سفارش بالاست (${spreadPercent.toFixed(2)}٪)`);
      if (!slippageOk) reasons.push(`لغزش احتمالی خرید بالاست (${estSlippage.toFixed(2)}٪)`);
      if (!depthOk) reasons.push('عمق فروشندگان در دفتر سفارش برای این مبلغ کافی نیست');
      if (!volatilitySafe) reasons.push(`نوسان بازار بیش از حد پرریسک است (${volatilityPercent}٪)`);
      if (trendScore < 36) reasons.push(`روند بازار نزولی/ضعیف است (امتیاز ${trendScore}/100)`);
      if (reasons.length === 0) reasons.push('تایید قطعی ورود صعودی هنوز شکل نگرفته است');
      regimeLabelFa =
        marketCondition === 'UNFAVORABLE'
          ? 'بازار نامناسب — نگهداری نقدی سرمایه'
          : 'انتظار برای نقطه ورود بهتر';
      reasoningFa = `سرمایه نقد نگه داشته شد چون: ${reasons.join(' · ')}.`;
      riskWarningFa = 'تا زمانی که شرایط نقدشوندگی و روند بهبود نیابد، خرید جدید انجام نمی‌شود.';
    }
  }

  return {
    action,
    marketCondition,
    confidencePercent: Math.max(
      35,
      Math.min(95, Math.round(trendScore * 0.55 + liquidityScore * 0.45))
    ),
    trendScore,
    liquidityScore,
    volatilityPercent,
    spreadPercent,
    estimatedSlippagePercent: estSlippage,
    recommendedCapitalPortionPercent,
    recommendedTargetNetProfitPercent: dynamicTpPct,
    recommendedStopLossPercent: dynamicSlPct,
    suggestedBuyPrice,
    suggestedSellPrice,
    regimeLabelFa,
    reasoningFa,
    riskWarningFa,
    usedFallback: true,
    analyzedAt: now,
  };
}

export async function analyzeAiCycleProMarket(
  input: AnalyzeAiCycleProInput
): Promise<AiCycleProDecision> {
  const heuristic = computeHeuristicAiCycleProDecision(input);
  if (!process.env.GEMINI_API_KEY?.trim()) {
    return heuristic;
  }

  try {
    const ai = getGeminiClient();
    const digest = {
      symbol: input.symbol,
      quoteCurrency: input.quoteCurrency,
      capitalAmount: input.capitalAmount,
      capitalUsageMode: input.capitalUsageMode,
      requestedPortionPct: input.capitalPortionPercent,
      orderBook: {
        bestBid: input.orderBook.bids[0]?.price || 0,
        bestAsk: input.orderBook.asks[0]?.price || 0,
        spreadPercent: heuristic.spreadPercent,
        bidDepthQuote: Math.round(input.bidDepthQuote),
        askDepthQuote: Math.round(input.askDepthQuote),
        estimatedSlippagePercent: heuristic.estimatedSlippagePercent,
        canFillBuyFull: input.canFillBuyFull,
        hasSufficientSellDepth: input.hasSufficientSellDepth,
      },
      indicators15m: input.snapshot15m
        ? {
            price: input.snapshot15m.price,
            rsi14: Number(input.snapshot15m.rsi14.toFixed(2)),
            ema9: input.snapshot15m.ema9,
            ema20: input.snapshot15m.ema20,
            ema50: input.snapshot15m.ema50,
            macdHistogram: input.snapshot15m.macd.histogram,
            volumeRatio: Number(input.snapshot15m.volumeRatio.toFixed(2)),
            signalAction: input.snapshot15m.signal.action,
          }
        : null,
      indicators1h: input.snapshot1h
        ? {
            ema20: input.snapshot1h.ema20,
            ema50: input.snapshot1h.ema50,
            rsi14: Number(input.snapshot1h.rsi14.toFixed(2)),
            signalAction: input.snapshot1h.signal.action,
          }
        : null,
      market24h: input.market
        ? {
            change24hPercent: input.market.change24hPercent,
            volumeToman: Math.round(input.market.volumeToman),
            volumeUsdt: Math.round(input.market.volumeUsdt),
          }
        : null,
      activePosition: input.activePosition
        ? {
            entryPrice: input.activePosition.actualBuyAvgPrice,
            totalCostQuote: input.activePosition.totalBuyCostQuote,
            targetNetProfitPercent: input.activePosition.targetNetProfitPercent,
            executableSellPrice: input.executableSellPrice,
          }
        : null,
      constraints: {
        minTargetNetProfitPercent: input.minTargetNetProfitPercent,
        maxSlippagePercent: input.maxSlippagePercent,
        maxSpreadPercent: input.maxSpreadPercent,
        stopLossPercent: input.stopLossPercent,
        feeRate: input.feeRate,
      },
    };

    const prompt = `تو تحلیلگر هوشمند ربات «AI Cycle Pro | ربات چرخه هوشمند» در پلتفرم ainobibot هستی.
داده‌های واقعی بازار نوبیتکس، دفتر سفارشات، عمق نقدینگی، لغزش تخمینی و اندیکاتورها در ادامه آمده است.
قانون ایمنی:
1) اگر موقعیت باز نداریم، فقط زمانی BUY پیشنهاد بده که روند، نقدینگی، اسپرد و لغزش مناسب باشد؛ در غیر این صورت حتماً HOLD_CASH بده تا سرمایه نقد بماند.
2) اگر موقعیت باز داریم، فقط بین HOLD_POSITION و SELL انتخاب کن.
3) هدف سود خالص پیشنهادی باید پس از کسر کارمزد خرید و فروش (${(input.feeRate * 200).toFixed(2)}٪) و لغزش قیمت کاملاً واقع‌بینانه و دست‌یافتنی باشد.
4) هیچ‌گاه سود تضمینی وعده نده و تحلیل را به فارسی شفاف، حرفه‌ای و قابل فهم برای کاربر مبتدی بنویس.

داده بازار و پوزیشن:
${JSON.stringify(digest)}`;

    const allowedActions = input.activePosition
      ? ['SELL', 'HOLD_POSITION']
      : ['BUY', 'HOLD_CASH'];

    const response = await ai.models.generateContent({
      model: 'gemini-4-hydrogen',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            action: { type: Type.STRING, enum: allowedActions },
            marketCondition: {
              type: Type.STRING,
              enum: ['FAVORABLE', 'NEUTRAL', 'UNFAVORABLE'],
            },
            confidencePercent: { type: Type.NUMBER },
            recommendedTargetNetProfitPercent: { type: Type.NUMBER },
            recommendedCapitalPortionPercent: { type: Type.NUMBER },
            regimeLabelFa: { type: Type.STRING },
            reasoningFa: { type: Type.STRING },
            riskWarningFa: { type: Type.STRING },
          },
          required: [
            'action',
            'marketCondition',
            'confidencePercent',
            'recommendedTargetNetProfitPercent',
            'regimeLabelFa',
            'reasoningFa',
          ],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}') as Partial<AiCycleProDecision>;

    // Deterministic hard safety overrides: never let AI bypass liquidity/spread/slippage/depth safety checks
    let safeAction =
      parsed.action && allowedActions.includes(parsed.action)
        ? parsed.action
        : heuristic.action;
    let safeCondition = parsed.marketCondition || heuristic.marketCondition;

    if (!input.activePosition) {
      if (
        heuristic.marketCondition === 'UNFAVORABLE' ||
        !input.canFillBuyFull ||
        heuristic.spreadPercent > input.maxSpreadPercent ||
        heuristic.estimatedSlippagePercent > input.maxSlippagePercent
      ) {
        safeAction = 'HOLD_CASH';
        safeCondition = 'UNFAVORABLE';
      }
    } else if (safeAction === 'SELL') {
      // Prevent accidental AI sell at tiny profit below cost unless heuristic already allows
      const netProceeds =
        input.executableSellPrice * input.activePosition.netOwnedQty * (1 - input.feeRate);
      const estNetPct =
        input.activePosition.totalBuyCostQuote > 0
          ? ((netProceeds - input.activePosition.totalBuyCostQuote) /
              input.activePosition.totalBuyCostQuote) *
            100
          : 0;
      if (estNetPct < 0.15 && heuristic.action !== 'SELL') {
        safeAction = 'HOLD_POSITION';
      }
    }

    const tpPct = Number(
      Math.max(
        input.minTargetNetProfitPercent,
        Math.min(8, Number(parsed.recommendedTargetNetProfitPercent || heuristic.recommendedTargetNetProfitPercent))
      ).toFixed(2)
    );
    const maxUserPortion =
      input.capitalUsageMode === 'PARTIAL'
        ? Math.min(100, Math.max(10, Math.round(input.capitalPortionPercent || 50)))
        : 100;
    const portionPct = Math.max(
      0,
      Math.min(
        maxUserPortion,
        Math.round(parsed.recommendedCapitalPortionPercent || heuristic.recommendedCapitalPortionPercent)
      )
    );

    const feeFactor = 1 - input.feeRate;
    const suggestedSellPrice =
      heuristic.suggestedBuyPrice > 0
        ? Number(
            (
              (heuristic.suggestedBuyPrice * (1 + tpPct / 100)) /
              Math.max(0.9, feeFactor * feeFactor * (1 - heuristic.estimatedSlippagePercent / 100))
            ).toFixed(input.quoteCurrency === 'IRT' ? 0 : 4)
          )
        : heuristic.suggestedSellPrice;

    return {
      ...heuristic,
      action: safeAction as AiCycleProDecision['action'],
      marketCondition: safeCondition as AiCycleProDecision['marketCondition'],
      confidencePercent: Math.max(
        20,
        Math.min(98, Math.round(parsed.confidencePercent || heuristic.confidencePercent))
      ),
      recommendedTargetNetProfitPercent: tpPct,
      recommendedCapitalPortionPercent: safeAction === 'HOLD_CASH' ? 0 : portionPct,
      suggestedSellPrice,
      regimeLabelFa: parsed.regimeLabelFa || heuristic.regimeLabelFa,
      reasoningFa: parsed.reasoningFa || heuristic.reasoningFa,
      riskWarningFa: parsed.riskWarningFa || heuristic.riskWarningFa,
      usedFallback: false,
      analyzedAt: input.now ?? Date.now(),
    };
  } catch {
    return heuristic;
  }
}




