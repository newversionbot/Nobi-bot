import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { NextFunction, Request, Response } from 'express';
import { and, desc, eq } from 'drizzle-orm';
import { getApps, initializeApp, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import * as schema from '../src/db/schema.ts';
import type {
  BotMonitoringTelegramMode,
  NobitexAuthType,
  TelegramBotSummary,
  TelegramSentLogEntry,
} from '../src/types/trading.ts';
import { buildVaultKeyRing, type VaultKeyRing } from './config.ts';
import { ensureUserRecord, getDb } from './db/index.ts';
import { logger } from './logger.ts';
import { validateNobitexCredentialsFormat, type NobitexCredentials } from './nobitexClient.ts';

export interface AuthenticatedUser {
  uid: string;
  email: string;
  displayName: string;
  emailVerified: boolean;
}

export interface StoredAppApiKey {
  id: string;
  userId: string;
  label: string;
  keyPrefix: string;
  keyHash: string;
  scopes: string[];
  status: 'ACTIVE' | 'REVOKED';
  createdAt: number;
  revokedAt?: number;
  lastUsedAt?: number;
}

export interface StoredExchangeCredential {
  id: string;
  userId: string;
  label: string;
  authType?: NobitexAuthType;
  maskedApiKey: string;
  keyId: string;
  encryptedToken: string;
  iv: string;
  authTag: string;
  status: 'ACTIVE' | 'REVOKED';
  lastVerifiedAt?: number;
  createdAt: number;
  revokedAt?: number;
}

let keyRing: VaultKeyRing = buildVaultKeyRing();

export function reloadVaultKeyRing(envOverride?: {
  primaryKeyId?: string;
  primarySecret?: string;
  previousSecrets?: string;
}): void {
  keyRing = buildVaultKeyRing(envOverride);
}

export function getActiveKeyId(): string {
  return keyRing.primaryKeyId;
}

export function encryptSecretText(secretText: string): {
  keyId: string;
  encryptedToken: string;
  iv: string;
  authTag: string;
} {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', keyRing.primaryKey, iv);
  const encrypted = Buffer.concat([cipher.update(secretText, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return {
    keyId: keyRing.primaryKeyId,
    encryptedToken: encrypted.toString('base64'),
    iv: iv.toString('base64'),
    authTag: authTag.toString('base64'),
  };
}

export function decryptSecretText(
  encryptedToken: string,
  iv: string,
  authTag: string,
  keyId?: string
): string {
  const candidates: Buffer[] = [];
  if (keyId && keyRing.keysById.has(keyId)) {
    candidates.push(keyRing.keysById.get(keyId)!);
  }
  candidates.push(keyRing.primaryKey);
  for (const fallback of keyRing.fallbackKeys) {
    if (!candidates.some((k) => k.equals(fallback))) {
      candidates.push(fallback);
    }
  }

  let lastErr: unknown;
  for (const candidateKey of candidates) {
    try {
      const decipher = crypto.createDecipheriv(
        'aes-256-gcm',
        candidateKey,
        Buffer.from(iv, 'base64')
      );
      decipher.setAuthTag(Buffer.from(authTag, 'base64'));
      const decrypted = Buffer.concat([
        decipher.update(Buffer.from(encryptedToken, 'base64')),
        decipher.final(),
      ]);
      return decrypted.toString('utf8');
    } catch (err) {
      lastErr = err;
    }
  }
  throw lastErr instanceof Error
    ? lastErr
    : new Error('رمزگشایی داده امنیتی ناموفق بود.');
}

export async function rotateAllEncryptedSecretsInDb(): Promise<{
  rotatedExchangeCount: number;
  rotatedTelegramCount: number;
  rotatedMerchantCount: number;
}> {
  const db = getDb();
  let rotatedExchangeCount = 0;
  let rotatedTelegramCount = 0;
  let rotatedMerchantCount = 0;

  const exRows = await db.select().from(schema.exchangeCredentials);
  for (const row of exRows) {
    if (row.keyId === keyRing.primaryKeyId) continue;
    const plain = decryptSecretText(row.encryptedToken, row.iv, row.authTag, row.keyId);
    const reEncrypted = encryptSecretText(plain);
    await db
      .update(schema.exchangeCredentials)
      .set({
        keyId: reEncrypted.keyId,
        encryptedToken: reEncrypted.encryptedToken,
        iv: reEncrypted.iv,
        authTag: reEncrypted.authTag,
      })
      .where(eq(schema.exchangeCredentials.id, row.id));
    rotatedExchangeCount += 1;
  }

  const tgRows = await db.select().from(schema.telegramConfigurations);
  for (const row of tgRows) {
    if (row.keyId === keyRing.primaryKeyId) continue;
    const plain = decryptSecretText(row.encryptedBotToken, row.iv, row.authTag, row.keyId);
    const reEncrypted = encryptSecretText(plain);
    await db
      .update(schema.telegramConfigurations)
      .set({
        keyId: reEncrypted.keyId,
        encryptedBotToken: reEncrypted.encryptedToken,
        iv: reEncrypted.iv,
        authTag: reEncrypted.authTag,
      })
      .where(eq(schema.telegramConfigurations.userId, row.userId));
    rotatedTelegramCount += 1;
  }

  const settingsRows = await db
    .select()
    .from(schema.adminSettings)
    .where(eq(schema.adminSettings.id, 'global'));
  const globalSettings = settingsRows[0];
  if (globalSettings?.encryptedMerchantJson && globalSettings.merchantKeyId !== keyRing.primaryKeyId) {
    const enc = globalSettings.encryptedMerchantJson as {
      encryptedToken: string;
      iv: string;
      authTag: string;
    };
    const plain = decryptSecretText(enc.encryptedToken, enc.iv, enc.authTag, globalSettings.merchantKeyId);
    const reEncrypted = encryptSecretText(plain);
    await db
      .update(schema.adminSettings)
      .set({
        merchantKeyId: reEncrypted.keyId,
        encryptedMerchantJson: {
          encryptedToken: reEncrypted.encryptedToken,
          iv: reEncrypted.iv,
          authTag: reEncrypted.authTag,
        },
      })
      .where(eq(schema.adminSettings.id, 'global'));
    rotatedMerchantCount += 1;
  }

  logger.info('vault.keys_rotated', {
    targetKeyId: keyRing.primaryKeyId,
    rotatedExchangeCount,
    rotatedTelegramCount,
    rotatedMerchantCount,
  });

  return { rotatedExchangeCount, rotatedTelegramCount, rotatedMerchantCount };
}

function hashToken(rawToken: string): string {
  return crypto.createHash('sha256').update(rawToken).digest('hex');
}

// =========================================================================
// Cryptographic Firebase JWT Verification (firebase-admin + Google X.509 RS256)
// =========================================================================
const FIREBASE_CONFIG_FILE = path.resolve(process.cwd(), 'firebase-applet-config.json');

function getFirebaseProjectId(): string | null {
  if (process.env.FIREBASE_PROJECT_ID?.trim()) {
    return process.env.FIREBASE_PROJECT_ID.trim();
  }
  try {
    if (fs.existsSync(FIREBASE_CONFIG_FILE)) {
      const parsed = JSON.parse(fs.readFileSync(FIREBASE_CONFIG_FILE, 'utf-8')) as {
        projectId?: string;
      };
      return parsed.projectId || null;
    }
  } catch {
    // Ignore
  }
  return null;
}

let firebaseAdminInitialized = false;
let firebaseAdminAvailable = false;

function ensureFirebaseAdmin(): boolean {
  if (firebaseAdminInitialized) return firebaseAdminAvailable;
  firebaseAdminInitialized = true;

  const svcJson = process.env.FIREBASE_SERVICE_ACCOUNT_JSON?.trim();
  const projectId = getFirebaseProjectId();
  if (!svcJson && !process.env.GOOGLE_APPLICATION_CREDENTIALS) {
    firebaseAdminAvailable = false;
    return false;
  }

  try {
    if (getApps().length === 0) {
      if (svcJson) {
        initializeApp({
          credential: cert(JSON.parse(svcJson)),
          projectId: projectId || undefined,
        });
      } else {
        initializeApp({
          projectId: projectId || undefined,
        });
      }
    }
    firebaseAdminAvailable = true;
  } catch (err) {
    logger.warn('firebase.admin_init_failed', { error: err });
    firebaseAdminAvailable = false;
  }
  return firebaseAdminAvailable;
}

let cachedCerts: { certs: Record<string, string>; expiresAt: number } | null = null;

async function fetchGooglePublicCerts(): Promise<Record<string, string>> {
  if (cachedCerts && cachedCerts.expiresAt > Date.now()) {
    return cachedCerts.certs;
  }
  const url =
    'https://www.googleapis.com/robot/v1/metadata/x509/securetoken@system.gserviceaccount.com';
  const res = await fetch(url, { signal: AbortSignal.timeout(6000) });
  if (!res.ok) {
    throw new Error(`Failed to fetch Firebase public certs (${res.status})`);
  }
  const certs = (await res.json()) as Record<string, string>;
  const cc = res.headers.get('cache-control') || '';
  const maxAgeMatch = cc.match(/max-age=(\d+)/i);
  const maxAgeSec = maxAgeMatch ? Math.min(86400, Math.max(60, Number(maxAgeMatch[1]))) : 3600;
  cachedCerts = {
    certs,
    expiresAt: Date.now() + maxAgeSec * 1000,
  };
  return certs;
}

function decodeBase64Url(segment: string): Buffer {
  const padded = segment.replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((segment.length + 3) % 4);
  return Buffer.from(padded, 'base64');
}

export async function verifyJwtWithPublicCerts(
  idToken: string,
  expectedProjectId: string,
  certsOverride?: Record<string, string>
): Promise<AuthenticatedUser | null> {
  const parts = idToken.split('.');
  if (parts.length !== 3) return null;
  const [headerB64, payloadB64, sigB64] = parts;

  let header: { alg?: string; kid?: string };
  let payload: {
    aud?: string;
    iss?: string;
    sub?: string;
    exp?: number;
    iat?: number;
    auth_time?: number;
    email?: string;
    email_verified?: boolean;
    name?: string;
  };
  try {
    header = JSON.parse(decodeBase64Url(headerB64).toString('utf8'));
    payload = JSON.parse(decodeBase64Url(payloadB64).toString('utf8'));
  } catch {
    return null;
  }

  if (header.alg !== 'RS256' || !header.kid) return null;
  const nowSec = Math.floor(Date.now() / 1000);
  if (!payload.sub || payload.sub.length > 128) return null;
  if (payload.aud !== expectedProjectId) return null;
  if (payload.iss !== `https://securetoken.google.com/${expectedProjectId}`) return null;
  if (typeof payload.exp !== 'number' || payload.exp <= nowSec) return null;
  if (typeof payload.iat !== 'number' || payload.iat > nowSec + 300) return null;
  if (typeof payload.auth_time === 'number' && payload.auth_time > nowSec + 300) return null;

  const certs = certsOverride || (await fetchGooglePublicCerts());
  const certPem = certs[header.kid];
  if (!certPem) return null;

  const verifier = crypto.createVerify('RSA-SHA256');
  verifier.update(`${headerB64}.${payloadB64}`);
  verifier.end();

  const signatureValid = verifier.verify(certPem, decodeBase64Url(sigB64));
  if (!signatureValid) return null;

  return {
    uid: payload.sub,
    email: payload.email || '',
    displayName: payload.name || payload.email || 'Trader',
    emailVerified: Boolean(payload.email_verified),
  };
}

type TestTokenVerifier = (token: string) => Promise<AuthenticatedUser | null>;
let testTokenVerifier: TestTokenVerifier | null = null;

export function setFirebaseVerifierForTest(fn: TestTokenVerifier | null): void {
  if (process.env.NODE_ENV === 'production' && fn) {
    throw new Error('Cannot set test token verifier in production.');
  }
  testTokenVerifier = fn;
  tokenCache.clear();
}

const tokenCache = new Map<string, { user: AuthenticatedUser; expiresAt: number }>();

export async function verifyFirebaseIdToken(idToken: string): Promise<AuthenticatedUser | null> {
  if (!idToken) return null;
  if (testTokenVerifier) {
    return testTokenVerifier(idToken);
  }
  if (idToken.length < 16) return null;

  const cached = tokenCache.get(idToken);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.user;
  }

  const projectId = getFirebaseProjectId();
  if (!projectId) return null;

  try {
    let verified: AuthenticatedUser | null = null;
    if (ensureFirebaseAdmin()) {
      const decoded = await getAuth().verifyIdToken(idToken, true);
      verified = {
        uid: decoded.uid,
        email: decoded.email || '',
        displayName: (decoded.name as string) || decoded.email || 'Trader',
        emailVerified: Boolean(decoded.email_verified),
      };
    } else {
      verified = await verifyJwtWithPublicCerts(idToken, projectId);
    }

    if (verified) {
      tokenCache.set(idToken, { user: verified, expiresAt: Date.now() + 60_000 });
    }
    return verified;
  } catch (err) {
    logger.warn('auth.token_verification_failed', { error: err });
    return null;
  }
}

export async function verifyAppApiKey(rawKey: string): Promise<StoredAppApiKey | null> {
  const db = getDb();
  const hashed = hashToken(rawKey);
  const rows = await db
    .select()
    .from(schema.appApiKeys)
    .where(and(eq(schema.appApiKeys.keyHash, hashed), eq(schema.appApiKeys.status, 'ACTIVE')))
    .limit(1);

  const row = rows[0];
  if (!row) return null;

  const now = Date.now();
  await db
    .update(schema.appApiKeys)
    .set({ lastUsedAt: now })
    .where(eq(schema.appApiKeys.id, row.id));

  return {
    id: row.id,
    userId: row.userId,
    label: row.label,
    keyPrefix: row.keyPrefix,
    keyHash: row.keyHash,
    scopes: Array.isArray(row.scopesJson) ? (row.scopesJson as string[]) : [],
    status: row.status as 'ACTIVE' | 'REVOKED',
    createdAt: row.createdAt,
    revokedAt: row.revokedAt ?? undefined,
    lastUsedAt: now,
  };
}

export interface RequestWithUser extends Request {
  authUser?: AuthenticatedUser;
  appKeyRecord?: StoredAppApiKey;
  authMethod?: 'FIREBASE' | 'API_KEY';
}

export async function requireAuth(
  req: RequestWithUser,
  res: Response,
  next: NextFunction
): Promise<void> {
  const authHeader = req.headers.authorization;
  const appApiKey = req.headers['x-app-apikey'];

  if (typeof appApiKey === 'string' && appApiKey.startsWith('tbx_')) {
    const keyRecord = await verifyAppApiKey(appApiKey);
    if (!keyRecord) {
      logger.warn('auth.invalid_api_key', { ip: req.ip, path: req.path });
      res.status(401).json({ error: 'کلید API نامعتبر یا لغو (Revoke) شده است.' });
      return;
    }
    const db = getDb();
    const userRow = (
      await db.select().from(schema.users).where(eq(schema.users.uid, keyRecord.userId)).limit(1)
    )[0];

    req.authUser = {
      uid: keyRecord.userId,
      email: userRow?.email || '',
      displayName: userRow?.displayName || `API Key (${keyRecord.label})`,
      emailVerified: true,
    };
    req.appKeyRecord = keyRecord;
    req.authMethod = 'API_KEY';
    next();
    return;
  }

  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'برای انجام این عملیات ابتدا وارد حساب کاربری خود شوید.' });
    return;
  }

  const token = authHeader.slice(7).trim();
  const user = await verifyFirebaseIdToken(token);
  if (!user) {
    logger.warn('auth.invalid_bearer_token', { ip: req.ip, path: req.path });
    res.status(401).json({ error: 'نشست کاربری نامعتبر یا منقضی شده است. لطفاً مجدداً وارد شوید.' });
    return;
  }

  await ensureUserRecord(user);
  req.authUser = user;
  req.authMethod = 'FIREBASE';
  next();
}

export function requireScope(requiredScope: 'market:read' | 'trade:spot' | 'bot:manage') {
  return (req: RequestWithUser, res: Response, next: NextFunction): void => {
    if (req.authMethod === 'API_KEY' && req.appKeyRecord) {
      if (!req.appKeyRecord.scopes.includes(requiredScope)) {
        res.status(403).json({
          error: `کلید API فاقد سطح دسترسی «${requiredScope}» برای این عملیات است.`,
          code: 'INSUFFICIENT_SCOPE',
        });
        return;
      }
    }
    next();
  };
}

export function requireFirebaseSession(req: RequestWithUser, res: Response, next: NextFunction): void {
  if (req.authMethod !== 'FIREBASE' || !req.authUser) {
    res.status(403).json({
      error: 'این عملیات حساس فقط با ورود مستقیم کاربر (Firebase Auth) مجاز است.',
      code: 'FIREBASE_SESSION_REQUIRED',
    });
    return;
  }
  next();
}

// =========================================================================
// App API Keys & Encrypted Nobitex Exchange Credentials (PostgreSQL)
// =========================================================================
export async function generateAppApiKey(
  userId: string,
  label: string,
  scopes: string[]
): Promise<{
  rawKey: string;
  record: Omit<StoredAppApiKey, 'keyHash'>;
}> {
  await ensureUserRecord({ uid: userId });
  const db = getDb();

  const cleanLabel = label.trim().slice(0, 80) || 'API Access Key';
  const validScopes = new Set(['market:read', 'trade:spot', 'bot:manage']);
  const cleanScopes = Array.from(new Set(scopes.filter((s) => validScopes.has(s)))).slice(0, 5);
  if (cleanScopes.length === 0) cleanScopes.push('market:read');

  const rawSecret = crypto.randomBytes(24).toString('hex');
  const rawKey = `tbx_live_${rawSecret}`;
  const keyPrefix = `${rawKey.slice(0, 14)}••••${rawKey.slice(-4)}`;
  const id = `key-${Date.now()}-${crypto.randomBytes(3).toString('hex')}`;
  const now = Date.now();

  await db.insert(schema.appApiKeys).values({
    id,
    userId,
    label: cleanLabel,
    keyPrefix,
    keyHash: hashToken(rawKey),
    scopesJson: cleanScopes,
    status: 'ACTIVE',
    createdAt: now,
  });

  return {
    rawKey,
    record: {
      id,
      userId,
      label: cleanLabel,
      keyPrefix,
      scopes: cleanScopes,
      status: 'ACTIVE',
      createdAt: now,
    },
  };
}

export async function listUserAppKeys(
  userId: string
): Promise<Array<Omit<StoredAppApiKey, 'keyHash'>>> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.appApiKeys)
    .where(eq(schema.appApiKeys.userId, userId))
    .orderBy(desc(schema.appApiKeys.createdAt));

  return rows.map((row) => ({
    id: row.id,
    userId: row.userId,
    label: row.label,
    keyPrefix: row.keyPrefix,
    scopes: Array.isArray(row.scopesJson) ? (row.scopesJson as string[]) : [],
    status: row.status as 'ACTIVE' | 'REVOKED',
    createdAt: row.createdAt,
    revokedAt: row.revokedAt ?? undefined,
    lastUsedAt: row.lastUsedAt ?? undefined,
  }));
}

export async function revokeAppApiKey(
  userId: string,
  keyId: string
): Promise<Omit<StoredAppApiKey, 'keyHash'>> {
  const db = getDb();
  const now = Date.now();
  const [updated] = await db
    .update(schema.appApiKeys)
    .set({ status: 'REVOKED', revokedAt: now })
    .where(and(eq(schema.appApiKeys.id, keyId), eq(schema.appApiKeys.userId, userId)))
    .returning();

  if (!updated) {
    throw new Error('کلید API مورد نظر یافت نشد.');
  }

  return {
    id: updated.id,
    userId: updated.userId,
    label: updated.label,
    keyPrefix: updated.keyPrefix,
    scopes: Array.isArray(updated.scopesJson) ? (updated.scopesJson as string[]) : [],
    status: 'REVOKED',
    createdAt: updated.createdAt,
    revokedAt: updated.revokedAt ?? now,
    lastUsedAt: updated.lastUsedAt ?? undefined,
  };
}

export type ExchangeCredentialInput =
  | string
  | {
      authType?: NobitexAuthType;
      apiToken?: string;
      apiKey?: string;
      secretKey?: string;
    };

function maskCredentialValue(prefix: string, raw: string): string {
  const clean = raw.trim();
  if (clean.length <= 10) {
    return `${prefix}_${clean.slice(0, 3)}••••${clean.slice(-2)}`;
  }
  return `${prefix}_${clean.slice(0, 5)}••••••${clean.slice(-4)}`;
}

export async function saveUserExchangeCredential(
  userId: string,
  label: string,
  credInput: ExchangeCredentialInput,
  verified = false
): Promise<Omit<StoredExchangeCredential, 'encryptedToken' | 'iv' | 'authTag' | 'keyId'>> {
  let resolvedAuthType: NobitexAuthType = 'TOKEN';
  let payloadToEncrypt: string;
  let maskedApiKey: string;

  if (typeof credInput === 'string') {
    const cleanToken = credInput.trim();
    if (cleanToken.length < 12) {
      throw new Error('فرمت توکن API صرافی نوبیتکس نامعتبر است.');
    }
    payloadToEncrypt = JSON.stringify({ apiToken: cleanToken });
    maskedApiKey = maskCredentialValue('nbt', cleanToken);
  } else {
    const wantsKeyPair =
      credInput.authType === 'KEY_PAIR' ||
      (Boolean(credInput.apiKey?.trim()) && Boolean(credInput.secretKey?.trim()) && !credInput.apiToken?.trim());

    if (wantsKeyPair) {
      const cleanKey = (credInput.apiKey || '').trim();
      const cleanSecret = (credInput.secretKey || '').trim();
      validateNobitexCredentialsFormat({
        authType: 'KEY_PAIR',
        apiKey: cleanKey,
        secretKey: cleanSecret,
      });
      resolvedAuthType = 'KEY_PAIR';
      payloadToEncrypt = JSON.stringify({
        authType: 'KEY_PAIR',
        apiKey: cleanKey,
        secretKey: cleanSecret,
      });
      maskedApiKey = maskCredentialValue('key', cleanKey);
    } else {
      const cleanToken = (credInput.apiToken || '').trim();
      if (cleanToken.length < 12) {
        throw new Error('فرمت توکن API صرافی نوبیتکس نامعتبر است.');
      }
      resolvedAuthType = 'TOKEN';
      payloadToEncrypt = JSON.stringify({ apiToken: cleanToken });
      maskedApiKey = maskCredentialValue('nbt', cleanToken);
    }
  }

  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const now = Date.now();

  await db
    .update(schema.exchangeCredentials)
    .set({ status: 'REVOKED', revokedAt: now })
    .where(
      and(
        eq(schema.exchangeCredentials.userId, userId),
        eq(schema.exchangeCredentials.status, 'ACTIVE')
      )
    );

  const encrypted = encryptSecretText(payloadToEncrypt);
  const id = `exch-${now}-${crypto.randomBytes(3).toString('hex')}`;
  const cleanLabel = label.trim().slice(0, 80) || 'حساب اصلی نوبیتکس';

  await db.insert(schema.exchangeCredentials).values({
    id,
    userId,
    label: cleanLabel,
    maskedApiKey,
    keyId: encrypted.keyId,
    encryptedToken: encrypted.encryptedToken,
    iv: encrypted.iv,
    authTag: encrypted.authTag,
    status: 'ACTIVE',
    lastVerifiedAt: verified ? now : null,
    createdAt: now,
  });

  return {
    id,
    userId,
    label: cleanLabel,
    authType: resolvedAuthType,
    maskedApiKey,
    status: 'ACTIVE',
    lastVerifiedAt: verified ? now : undefined,
    createdAt: now,
  };
}

export async function listUserExchangeCredentials(
  userId: string
): Promise<Array<Omit<StoredExchangeCredential, 'encryptedToken' | 'iv' | 'authTag' | 'keyId'>>> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.exchangeCredentials)
    .where(eq(schema.exchangeCredentials.userId, userId))
    .orderBy(desc(schema.exchangeCredentials.createdAt));

  return rows.map((row) => ({
    id: row.id,
    userId: row.userId,
    label: row.label,
    authType: row.maskedApiKey.startsWith('key_') ? 'KEY_PAIR' : 'TOKEN',
    maskedApiKey: row.maskedApiKey,
    status: row.status as 'ACTIVE' | 'REVOKED',
    lastVerifiedAt: row.lastVerifiedAt ?? undefined,
    createdAt: row.createdAt,
    revokedAt: row.revokedAt ?? undefined,
  }));
}

export async function markUserExchangeCredentialVerified(userId: string): Promise<void> {
  const db = getDb();
  await db
    .update(schema.exchangeCredentials)
    .set({ lastVerifiedAt: Date.now() })
    .where(
      and(
        eq(schema.exchangeCredentials.userId, userId),
        eq(schema.exchangeCredentials.status, 'ACTIVE')
      )
    );
}

export async function revokeUserExchangeCredential(userId: string, credId: string): Promise<void> {
  const db = getDb();
  const [updated] = await db
    .update(schema.exchangeCredentials)
    .set({ status: 'REVOKED', revokedAt: Date.now() })
    .where(and(eq(schema.exchangeCredentials.id, credId), eq(schema.exchangeCredentials.userId, userId)))
    .returning();

  if (!updated) {
    throw new Error('اتصال صرافی مورد نظر یافت نشد.');
  }
}

export async function getActiveExchangeCredentialsForUser(
  userId?: string | null
): Promise<NobitexCredentials | null> {
  if (!userId) return null;
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.exchangeCredentials)
    .where(
      and(
        eq(schema.exchangeCredentials.userId, userId),
        eq(schema.exchangeCredentials.status, 'ACTIVE')
      )
    )
    .orderBy(desc(schema.exchangeCredentials.createdAt))
    .limit(1);

  const active = rows[0];
  if (!active) return null;
  try {
    const raw = decryptSecretText(
      active.encryptedToken,
      active.iv,
      active.authTag,
      active.keyId
    );
    const parsed = JSON.parse(raw) as {
      authType?: NobitexAuthType;
      apiToken?: string;
      apiKey?: string;
      secretKey?: string;
    };
    if (parsed.apiKey && parsed.secretKey) {
      return {
        authType: 'KEY_PAIR',
        apiKey: parsed.apiKey,
        secretKey: parsed.secretKey,
      };
    }
    return parsed.apiToken ? { authType: 'TOKEN', apiToken: parsed.apiToken } : null;
  } catch (err) {
    logger.error('vault.exchange_decrypt_failed', { userId, error: err });
    return null;
  }
}

export async function hasActiveExchangeCredentialsForUser(userId?: string | null): Promise<boolean> {
  return (await getActiveExchangeCredentialsForUser(userId)) !== null;
}

// =========================================================================
// Strictly Per-User Telegram Bot Encrypted Configuration
// =========================================================================
export type TelegramBotPublicSummary = TelegramBotSummary;

const VALID_BOT_MONITOR_MODES: BotMonitoringTelegramMode[] = [
  'MANUAL_ONLY',
  'EVENTS_AND_STATUS',
  'INTERVAL',
  'EVERY_CYCLE',
];

function sanitizeBotMonitorMode(
  mode: unknown,
  fallback: BotMonitoringTelegramMode = 'EVENTS_AND_STATUS'
): BotMonitoringTelegramMode {
  return VALID_BOT_MONITOR_MODES.includes(mode as BotMonitoringTelegramMode)
    ? (mode as BotMonitoringTelegramMode)
    : fallback;
}

function sanitizeIntervalMinutes(val: unknown, fallback = 15): number {
  const num = Math.round(Number(val));
  if (!Number.isFinite(num) || num < 1) return fallback;
  return Math.min(1440, num);
}

function maskTelegramToken(token: string): string {
  const clean = token.trim();
  if (clean.length <= 12) return '••••••••';
  return `${clean.slice(0, 8)}••••••${clean.slice(-4)}`;
}

function defaultTelegramSummary(): TelegramBotPublicSummary {
  return {
    configured: false,
    enabled: false,
    maskedBotToken: '',
    botUsername: '',
    botFirstName: '',
    chatId: '',
    sendPriceAlerts: true,
    sendPeriodicWatchers: true,
    sendTradeReports: true,
    sendBotTrades: true,
    sendBotMonitoring: true,
    botMonitorMode: 'EVENTS_AND_STATUS',
    botMonitorIntervalMinutes: 15,
    updatedAt: null,
    lastSentAt: null,
    lastBotMonitorSentAt: null,
    lastError: null,
    recentLogs: [],
  };
}

function mapTelegramRowToSummary(
  row: typeof schema.telegramConfigurations.$inferSelect
): TelegramBotPublicSummary {
  return {
    configured: true,
    enabled: row.enabled,
    maskedBotToken: row.maskedBotToken,
    botUsername: row.botUsername,
    botFirstName: row.botFirstName,
    chatId: row.chatId,
    sendPriceAlerts: row.sendPriceAlerts,
    sendPeriodicWatchers: row.sendPeriodicWatchers,
    sendTradeReports: row.sendTradeReports,
    sendBotTrades: row.sendBotTrades,
    sendBotMonitoring: row.sendBotMonitoring,
    botMonitorMode: sanitizeBotMonitorMode(row.botMonitorMode),
    botMonitorIntervalMinutes: sanitizeIntervalMinutes(row.botMonitorIntervalMinutes, 15),
    updatedAt: row.updatedAt,
    lastSentAt: row.lastSentAt,
    lastBotMonitorSentAt: row.lastBotMonitorSentAt,
    lastError: row.lastError,
    recentLogs: Array.isArray(row.recentLogsJson)
      ? (row.recentLogsJson as TelegramSentLogEntry[]).slice(0, 20)
      : [],
  };
}

export async function getTelegramBotSummary(userId: string): Promise<TelegramBotPublicSummary> {
  if (!userId) return defaultTelegramSummary();
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.telegramConfigurations)
    .where(eq(schema.telegramConfigurations.userId, userId))
    .limit(1);

  if (rows.length === 0) return defaultTelegramSummary();
  return mapTelegramRowToSummary(rows[0]);
}

export async function saveTelegramBotConfig(
  userId: string,
  input: {
    botToken?: string;
    botUsername?: string;
    botFirstName?: string;
    chatId: string;
    enabled?: boolean;
    sendPriceAlerts?: boolean;
    sendPeriodicWatchers?: boolean;
    sendTradeReports?: boolean;
    sendBotTrades?: boolean;
    sendBotMonitoring?: boolean;
    botMonitorMode?: BotMonitoringTelegramMode;
    botMonitorIntervalMinutes?: number;
  }
): Promise<TelegramBotPublicSummary> {
  const cleanChatId = String(input.chatId || '').trim();
  if (!cleanChatId) {
    throw new Error('شناسه چت (Chat ID) یا نام کاربری کانال تلگرام الزامی است.');
  }

  await ensureUserRecord({ uid: userId });
  const db = getDb();
  const prevRows = await db
    .select()
    .from(schema.telegramConfigurations)
    .where(eq(schema.telegramConfigurations.userId, userId))
    .limit(1);
  const prev = prevRows[0];

  const rawToken = input.botToken?.trim();
  let encryptedData: {
    keyId: string;
    encryptedToken: string;
    iv: string;
    authTag: string;
  };
  let maskedBotToken: string;

  if (rawToken) {
    encryptedData = encryptSecretText(JSON.stringify({ botToken: rawToken }));
    maskedBotToken = maskTelegramToken(rawToken);
  } else if (prev) {
    encryptedData = {
      keyId: prev.keyId,
      encryptedToken: prev.encryptedBotToken,
      iv: prev.iv,
      authTag: prev.authTag,
    };
    maskedBotToken = prev.maskedBotToken;
  } else {
    throw new Error('توکن ربات تلگرام (Bot Token) الزامی است.');
  }

  const now = Date.now();
  const payload = {
    userId,
    keyId: encryptedData.keyId,
    encryptedBotToken: encryptedData.encryptedToken,
    iv: encryptedData.iv,
    authTag: encryptedData.authTag,
    maskedBotToken,
    botUsername: input.botUsername ?? prev?.botUsername ?? '',
    botFirstName: input.botFirstName ?? prev?.botFirstName ?? '',
    chatId: cleanChatId,
    enabled: input.enabled ?? prev?.enabled ?? true,
    sendPriceAlerts: input.sendPriceAlerts ?? prev?.sendPriceAlerts ?? true,
    sendPeriodicWatchers: input.sendPeriodicWatchers ?? prev?.sendPeriodicWatchers ?? true,
    sendTradeReports: input.sendTradeReports ?? prev?.sendTradeReports ?? true,
    sendBotTrades: input.sendBotTrades ?? prev?.sendBotTrades ?? true,
    sendBotMonitoring: input.sendBotMonitoring ?? prev?.sendBotMonitoring ?? true,
    botMonitorMode: sanitizeBotMonitorMode(
      input.botMonitorMode,
      sanitizeBotMonitorMode(prev?.botMonitorMode)
    ),
    botMonitorIntervalMinutes: sanitizeIntervalMinutes(
      input.botMonitorIntervalMinutes,
      sanitizeIntervalMinutes(prev?.botMonitorIntervalMinutes, 15)
    ),
    updatedAt: now,
    lastSentAt: prev?.lastSentAt ?? null,
    lastBotMonitorSentAt: prev?.lastBotMonitorSentAt ?? null,
    lastError: null,
    recentLogsJson: prev?.recentLogsJson ?? [],
  };

  if (prev) {
    await db
      .update(schema.telegramConfigurations)
      .set(payload)
      .where(eq(schema.telegramConfigurations.userId, userId));
  } else {
    await db.insert(schema.telegramConfigurations).values(payload);
  }

  return getTelegramBotSummary(userId);
}

export async function updateTelegramPreferences(
  userId: string,
  input: {
    enabled?: boolean;
    sendPriceAlerts?: boolean;
    sendPeriodicWatchers?: boolean;
    sendTradeReports?: boolean;
    sendBotTrades?: boolean;
    sendBotMonitoring?: boolean;
    botMonitorMode?: BotMonitoringTelegramMode;
    botMonitorIntervalMinutes?: number;
  }
): Promise<TelegramBotPublicSummary> {
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.telegramConfigurations)
    .where(eq(schema.telegramConfigurations.userId, userId))
    .limit(1);

  const prev = rows[0];
  if (!prev) {
    throw new Error('ابتدا توکن و Chat ID ربات تلگرام را متصل کنید.');
  }

  await db
    .update(schema.telegramConfigurations)
    .set({
      enabled: typeof input.enabled === 'boolean' ? input.enabled : prev.enabled,
      sendPriceAlerts:
        typeof input.sendPriceAlerts === 'boolean'
          ? input.sendPriceAlerts
          : prev.sendPriceAlerts,
      sendPeriodicWatchers:
        typeof input.sendPeriodicWatchers === 'boolean'
          ? input.sendPeriodicWatchers
          : prev.sendPeriodicWatchers,
      sendTradeReports:
        typeof input.sendTradeReports === 'boolean'
          ? input.sendTradeReports
          : prev.sendTradeReports,
      sendBotTrades:
        typeof input.sendBotTrades === 'boolean' ? input.sendBotTrades : prev.sendBotTrades,
      sendBotMonitoring:
        typeof input.sendBotMonitoring === 'boolean'
          ? input.sendBotMonitoring
          : prev.sendBotMonitoring,
      botMonitorMode:
        input.botMonitorMode !== undefined
          ? sanitizeBotMonitorMode(
              input.botMonitorMode,
              sanitizeBotMonitorMode(prev.botMonitorMode)
            )
          : prev.botMonitorMode,
      botMonitorIntervalMinutes:
        input.botMonitorIntervalMinutes !== undefined
          ? sanitizeIntervalMinutes(
              input.botMonitorIntervalMinutes,
              sanitizeIntervalMinutes(prev.botMonitorIntervalMinutes, 15)
            )
          : prev.botMonitorIntervalMinutes,
      updatedAt: Date.now(),
    })
    .where(eq(schema.telegramConfigurations.userId, userId));

  return getTelegramBotSummary(userId);
}

export async function clearTelegramBotConfig(userId: string): Promise<TelegramBotPublicSummary> {
  const db = getDb();
  await db
    .delete(schema.telegramConfigurations)
    .where(eq(schema.telegramConfigurations.userId, userId));
  return defaultTelegramSummary();
}

export async function getActiveTelegramCredentials(
  userId: string,
  requireEnabled = true
): Promise<{
  botToken: string;
  chatId: string;
  enabled: boolean;
  sendPriceAlerts: boolean;
  sendPeriodicWatchers: boolean;
  sendTradeReports: boolean;
  sendBotTrades: boolean;
  sendBotMonitoring: boolean;
  botMonitorMode: BotMonitoringTelegramMode;
  botMonitorIntervalMinutes: number;
  lastBotMonitorSentAt: number | null;
} | null> {
  if (!userId) return null;
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.telegramConfigurations)
    .where(eq(schema.telegramConfigurations.userId, userId))
    .limit(1);

  const cfg = rows[0];
  if (!cfg) return null;
  if (requireEnabled && !cfg.enabled) return null;

  try {
    const raw = decryptSecretText(
      cfg.encryptedBotToken,
      cfg.iv,
      cfg.authTag,
      cfg.keyId
    );
    const parsed = JSON.parse(raw) as { botToken?: string };
    if (!parsed.botToken || !cfg.chatId) return null;
    return {
      botToken: parsed.botToken,
      chatId: cfg.chatId,
      enabled: cfg.enabled,
      sendPriceAlerts: cfg.sendPriceAlerts,
      sendPeriodicWatchers: cfg.sendPeriodicWatchers,
      sendTradeReports: cfg.sendTradeReports,
      sendBotTrades: cfg.sendBotTrades,
      sendBotMonitoring: cfg.sendBotMonitoring,
      botMonitorMode: sanitizeBotMonitorMode(cfg.botMonitorMode),
      botMonitorIntervalMinutes: sanitizeIntervalMinutes(cfg.botMonitorIntervalMinutes, 15),
      lastBotMonitorSentAt: cfg.lastBotMonitorSentAt ?? null,
    };
  } catch {
    return null;
  }
}

export async function recordTelegramDeliveryResult(
  userId: string,
  ok: boolean,
  errorMessage?: string,
  logEntry?: Omit<TelegramSentLogEntry, 'id' | 'status' | 'error' | 'sentAt'>
): Promise<void> {
  if (!userId) return;
  const db = getDb();
  const rows = await db
    .select()
    .from(schema.telegramConfigurations)
    .where(eq(schema.telegramConfigurations.userId, userId))
    .limit(1);
  const cfg = rows[0];
  if (!cfg) return;

  const now = Date.now();
  const prevLogs = Array.isArray(cfg.recentLogsJson)
    ? (cfg.recentLogsJson as TelegramSentLogEntry[])
    : [];

  let nextLogs = prevLogs;
  if (logEntry) {
    const entry: TelegramSentLogEntry = {
      id: `tglog-${now}-${Math.random().toString(36).slice(2, 6)}`,
      kind: logEntry.kind,
      title: logEntry.title,
      preview: logEntry.preview.slice(0, 260),
      status: ok ? 'SENT' : 'ERROR',
      error: ok ? undefined : errorMessage?.slice(0, 180),
      sentAt: now,
    };
    nextLogs = [entry, ...prevLogs].slice(0, 20);
  }

  await db
    .update(schema.telegramConfigurations)
    .set({
      lastSentAt: ok ? now : cfg.lastSentAt,
      lastError: ok ? null : errorMessage ? errorMessage.slice(0, 250) : cfg.lastError,
      recentLogsJson: nextLogs,
    })
    .where(eq(schema.telegramConfigurations.userId, userId));
}

export async function recordBotMonitorSent(userId: string): Promise<void> {
  if (!userId) return;
  const db = getDb();
  await db
    .update(schema.telegramConfigurations)
    .set({ lastBotMonitorSentAt: Date.now() })
    .where(eq(schema.telegramConfigurations.userId, userId));
}
