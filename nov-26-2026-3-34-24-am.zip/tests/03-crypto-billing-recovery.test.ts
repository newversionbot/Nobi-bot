import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import {
  activateUserProSubscription,
  claimReferralCode,
  reviewPaymentRequestAsAdmin,
  setBillingFetchForTest,
  submitCryptoPaymentRequest,
} from '../server/billingVault.ts';
import { createBot, getUserBots } from '../server/botEngine.ts';
import { buildVaultKeyRing } from '../server/config.ts';
import { exportLogicalBackup, getDb, restoreLogicalBackup } from '../server/db/index.ts';
import { redactSensitiveText } from '../server/logger.ts';
import {
  decryptSecretText,
  reloadVaultKeyRing,
  rotateAllEncryptedSecretsInDb,
  saveTelegramBotConfig,
  saveUserExchangeCredential,
} from '../server/securityVault.ts';
import { sendTelegramTestMessage } from '../server/telegramClient.ts';
import * as schema from '../src/db/schema.ts';
import { startIsolatedTestServer, TEST_USERS, type TestServerContext } from './helpers/testHarness.ts';

describe('Crypto Key Rotation, Telegram 429/Redaction, RBAC, ZarinPal/USDT/Referral, Backup & Rate Limits', () => {
  let ctx: TestServerContext;

  beforeEach(async () => {
    ctx = await startIsolatedTestServer({
      generalRateLimitMax: 25,
      tradeRateLimitMax: 5,
    });
  });

  afterEach(async () => {
    reloadVaultKeyRing();
    await ctx.close();
  });

  it('encrypts secrets with AES-256-GCM, rejects wrong key, rotates secrets with VAULT_MASTER_KEY_PREVIOUS, and enforces production guard', async () => {
    reloadVaultKeyRing({
      primaryKeyId: 'v1',
      primarySecret: 'first-master-secret-key-at-least-32-chars!!',
    });

    const uid = TEST_USERS['token-alice'].uid;
    await saveUserExchangeCredential(uid, 'Rotation Cred', 'NOBITEX_SUPER_SECRET_123', false);

    // Wrong key cannot decrypt
    const db = getDb();
    const [rowBefore] = await db.select().from(schema.exchangeCredentials);
    reloadVaultKeyRing({
      primaryKeyId: 'v-wrong',
      primarySecret: 'completely-different-wrong-key-32-chars!!',
    });
    expect(() =>
      decryptSecretText(rowBefore.encryptedToken, rowBefore.iv, rowBefore.authTag, rowBefore.keyId)
    ).toThrow();

    // Rotate to v2 keeping v1 in VAULT_MASTER_KEY_PREVIOUS fallback
    reloadVaultKeyRing({
      primaryKeyId: 'v2',
      primarySecret: 'second-rotated-master-secret-32-chars!!',
      previousSecrets: 'v1:first-master-secret-key-at-least-32-chars!!',
    });

    const rot = await rotateAllEncryptedSecretsInDb();
    expect(rot.rotatedExchangeCount).toBe(1);

    const [rowAfter] = await db.select().from(schema.exchangeCredentials);
    expect(rowAfter.keyId).toBe('v2');
    const decryptedAfter = decryptSecretText(
      rowAfter.encryptedToken,
      rowAfter.iv,
      rowAfter.authTag,
      rowAfter.keyId
    );
    expect(JSON.parse(decryptedAfter)).toEqual({ apiToken: 'NOBITEX_SUPER_SECRET_123' });

    // Verify production guard throws if VAULT_MASTER_KEY missing in production
    const prevEnv = process.env.NODE_ENV;
    process.env.NODE_ENV = 'production';
    try {
      expect(() =>
        buildVaultKeyRing({ primarySecret: '', previousSecrets: '' })
      ).toThrow();
    } finally {
      process.env.NODE_ENV = prevEnv;
    }
  });

  it('handles Telegram 429 retry_after and redacts sensitive secrets in logs/errors', async () => {
    const uid = TEST_USERS['token-alice'].uid;
    await saveTelegramBotConfig(uid, {
      botToken: '123456789:ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijk',
      chatId: '99887766',
      enabled: true,
    });

    ctx.telegram.rateLimit429Count = 1;
    const sent = await sendTelegramTestMessage(uid);
    expect(sent.sentAt).toBeGreaterThan(0);
    expect(ctx.telegram.calls.filter((c) => c.method === 'sendMessage')).toHaveLength(1);

    const redacted = redactSensitiveText(
      'Failed calling https://api.telegram.org/bot123456:ABCDEF_SECRET_TOKEN/sendMessage with Authorization: Token secret_nobitex_999 and tbx_live_abcd'
    );
    expect(redacted).not.toContain('ABCDEF_SECRET_TOKEN');
    expect(redacted).not.toContain('secret_nobitex_999');
    expect(redacted).not.toContain('tbx_live_abcd');
    expect(redacted).toContain('***REDACTED***');
  });

  it('enforces PRO subscription gate, processes ZarinPal/USDT payments atomically, blocks duplicate txHash, and awards 4-day referral bonus once only', async () => {
    // 1. Non-PRO user Bob gets 403 SUBSCRIPTION_REQUIRED on PRO-gated endpoint (/api/orders)
    const freeOrderAttempt = await fetch(`${ctx.baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-bob',
      },
      body: JSON.stringify({
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        side: 'BUY',
        type: 'MARKET',
        quantity: 0.01,
        mode: 'paper',
      }),
    });
    expect(freeOrderAttempt.status).toBe(403);
    const freeJson = await freeOrderAttempt.json();
    expect(freeJson.code).toBe('SUBSCRIPTION_REQUIRED');

    // 2. Alice gets her referral code and Bob claims it
    const aliceStatusRes = await fetch(`${ctx.baseUrl}/api/billing/status`, {
      headers: { Authorization: 'Bearer token-alice' },
    });
    const aliceStatus = await aliceStatusRes.json();
    const aliceRefCode = aliceStatus.referral.referralCode;
    expect(aliceRefCode).toMatch(/^ALI-/);

    const claim = await claimReferralCode(TEST_USERS['token-bob'], aliceRefCode);
    expect(claim.claimed).toBe(true);

    // 3. Bob submits a USDT payment; duplicate txHash replay is rejected
    const payReq = await submitCryptoPaymentRequest({
      user: TEST_USERS['token-bob'],
      txHash: '0xAbCdEf1234567890DuplicateCheck',
      network: 'TRC20',
      walletAddress: 'TX_WALLET_DEMO_12345',
      usdtTomanRate: 62_000,
    });

    await expect(
      submitCryptoPaymentRequest({
        user: TEST_USERS['token-bob'],
        txHash: '0xabcdef1234567890duplicatecheck', // case-insensitive unique index
        network: 'TRC20',
        walletAddress: 'TX_WALLET_DEMO_12345',
        usdtTomanRate: 62_000,
      })
    ).rejects.toThrow(/قبلاً.*ثبت/);

    // 4. Concurrent admin approval runs atomically -> succeeds once, second fails cleanly
    const [r1, r2] = await Promise.allSettled([
      reviewPaymentRequestAsAdmin({
        requestId: payReq.id,
        action: 'APPROVE',
        actorEmail: 'shivamdonyam@gmail.com',
      }),
      reviewPaymentRequestAsAdmin({
        requestId: payReq.id,
        action: 'APPROVE',
        actorEmail: 'shivamdonyam@gmail.com',
      }),
    ]);
    const fulfilled = [r1, r2].filter((r) => r.status === 'fulfilled');
    const rejected = [r1, r2].filter((r) => r.status === 'rejected');
    expect(fulfilled).toHaveLength(1);
    expect(rejected).toHaveLength(1);

    // 5. Alice received +4 referral bonus days ONCE ONLY
    const aliceAfterReward = await (
      await fetch(`${ctx.baseUrl}/api/billing/status`, {
        headers: { Authorization: 'Bearer token-alice' },
      })
    ).json();
    expect(aliceAfterReward.entitlement.hasProAccess).toBe(true);
    expect(aliceAfterReward.referral.totalBonusDaysEarned).toBe(4);
    expect(aliceAfterReward.referral.convertedCount).toBe(1);

    // 6. ZarinPal request + callback verification with mocked fetch
    process.env.ZARINPAL_MERCHANT_ID = '11111111-1111-1111-1111-111111111111';
    setBillingFetchForTest(async (input: string | URL | Request) => {
      const url = typeof input === 'string' ? input : input.toString();
      if (url.includes('/request.json')) {
        return new Response(
          JSON.stringify({ data: { code: 100, authority: 'A00000000000000000000000000001234567' } }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      return new Response(
        JSON.stringify({ data: { code: 100, ref_id: 987654321 } }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    });

    const zpReqRes = await fetch(`${ctx.baseUrl}/api/billing/zarinpal/request`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-alice' },
    });
    const zpReqJson = await zpReqRes.json();
    expect(zpReqRes.status).toBe(200);
    expect(zpReqJson.mode).toBe('GATEWAY_REDIRECT');

    const zpVerifyRes = await fetch(`${ctx.baseUrl}/api/billing/zarinpal/verify`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-alice' },
      body: JSON.stringify({
        authority: 'A00000000000000000000000000001234567',
        status: 'OK',
      }),
    });
    const zpVerifyJson = await zpVerifyRes.json();
    expect(zpVerifyJson.verified).toBe(true);
    expect(zpVerifyJson.refId).toBe('987654321');
    delete process.env.ZARINPAL_MERCHANT_ID;
  });

  it('supports logical DB backup & wipe & restore, Zod validation, Express rate limits, and global emergency stop', async () => {
    const aliceUid = TEST_USERS['token-alice'].uid;
    await activateUserProSubscription(
      {
        userId: aliceUid,
        email: TEST_USERS['token-alice'].email,
        displayName: TEST_USERS['token-alice'].displayName,
        paymentMethod: 'ADMIN_GRANT',
        days: 30,
      },
      'shivamdonyam@gmail.com'
    );

    await createBot(aliceUid, {
      name: 'Backup Restore Bot',
      baseAsset: 'BTC',
      quoteCurrency: 'USDT',
      symbol: 'BTCUSDT',
      timeframe: '15m',
      mode: 'paper',
      status: 'RUNNING',
      orderAmount: 200,
      stopLossPercent: 2,
      takeProfitPercent: 4,
      trailingStopEnabled: false,
      trailingStopPercent: 1.5,
      cooldownMinutes: 15,
      logicOperator: 'AND',
      entryRules: [{ id: 'e1', type: 'RSI_OVERSOLD', action: 'BUY', enabled: true, params: { period: 14, threshold: 35 } }],
      exitRules: [],
    });

    // 1. Export backup -> wipe -> restore
    const backup = await exportLogicalBackup();
    const db = getDb();
    await db.delete(schema.botConfigurations);
    await db.delete(schema.tradingBots);
    expect(await getUserBots(aliceUid)).toHaveLength(0);

    await restoreLogicalBackup(backup);
    const restoredBots = await getUserBots(aliceUid);
    expect(restoredBots).toHaveLength(1);
    expect(restoredBots[0].name).toBe('Backup Restore Bot');

    // 2. Admin global emergency stop halts all running bots
    const adminStopRes = await fetch(`${ctx.baseUrl}/api/billing/admin/bots/emergency-stop`, {
      method: 'POST',
      headers: { Authorization: 'Bearer token-admin' },
    });
    const adminStopJson = await adminStopRes.json();
    expect(adminStopRes.status).toBe(200);
    expect(adminStopJson.stoppedCount).toBe(1);
    expect((await getUserBots(aliceUid))[0].status).toBe('PAUSED');

    // 3. Zod rejects malformed order (400)
    const badOrderRes = await fetch(`${ctx.baseUrl}/api/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-alice' },
      body: JSON.stringify({
        baseAsset: '',
        quoteCurrency: 'INVALID',
        side: 'BUY',
        type: 'MARKET',
        quantity: -5,
      }),
    });
    expect(badOrderRes.status).toBe(400);

    // 4. Rate limit returns 429 after exceeding tradeRateLimitMax (5)
    let hit429 = false;
    for (let i = 0; i < 8; i++) {
      const r = await fetch(`${ctx.baseUrl}/api/orders`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-alice' },
        body: JSON.stringify({
          baseAsset: 'BTC',
          quoteCurrency: 'USDT',
          side: 'BUY',
          type: 'MARKET',
          quantity: 0.005,
          mode: 'paper',
        }),
      });
      if (r.status === 429) {
        hit429 = true;
        break;
      }
    }
    expect(hit429).toBe(true);
  });
});
