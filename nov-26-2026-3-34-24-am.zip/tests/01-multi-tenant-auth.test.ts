import crypto from 'node:crypto';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { verifyJwtWithPublicCerts } from '../server/securityVault.ts';
import { activateUserProSubscription } from '../server/billingVault.ts';
import { getDb } from '../server/db/index.ts';
import * as schema from '../src/db/schema.ts';
import { startIsolatedTestServer, TEST_USERS, type TestServerContext } from './helpers/testHarness.ts';

function buildSignedRs256Jwt(
  privateKey: crypto.KeyObject,
  kid: string,
  payload: Record<string, unknown>
): string {
  const b64url = (obj: unknown) =>
    Buffer.from(JSON.stringify(obj))
      .toString('base64')
      .replace(/=/g, '')
      .replace(/\+/g, '-')
      .replace(/\//g, '_');

  const headerPart = b64url({ alg: 'RS256', typ: 'JWT', kid });
  const payloadPart = b64url(payload);
  const signer = crypto.createSign('RSA-SHA256');
  signer.update(`${headerPart}.${payloadPart}`);
  signer.end();
  const sig = signer
    .sign(privateKey)
    .toString('base64')
    .replace(/=/g, '')
    .replace(/\+/g, '-')
    .replace(/\//g, '_');
  return `${headerPart}.${payloadPart}.${sig}`;
}

describe('Multi-Tenant Isolation, Auth Bypass Guards, and Per-User Credentials', () => {
  let ctx: TestServerContext;

  beforeEach(async () => {
    ctx = await startIsolatedTestServer();
    // Grant Pro access to Alice and Bob so we can test isolated resource routes
    await activateUserProSubscription(
      {
        userId: TEST_USERS['token-alice'].uid,
        email: TEST_USERS['token-alice'].email,
        displayName: TEST_USERS['token-alice'].displayName,
        paymentMethod: 'ADMIN_GRANT',
        days: 30,
      },
      'test-setup@system.local'
    );
    await activateUserProSubscription(
      {
        userId: TEST_USERS['token-bob'].uid,
        email: TEST_USERS['token-bob'].email,
        displayName: TEST_USERS['token-bob'].displayName,
        paymentMethod: 'ADMIN_GRANT',
        days: 30,
      },
      'test-setup@system.local'
    );
  });

  afterEach(async () => {
    await ctx.close();
  });

  it('rejects unauthenticated requests with 401 and blocks cross-user reads/writes/deletes', async () => {
    // 1. Unauthenticated access must fail with 401
    for (const ep of [
      '/api/bots',
      '/api/alerts',
      '/api/orders',
      '/api/features/watchers',
      '/api/features/telegram',
      '/api/keys',
    ]) {
      const res = await fetch(`${ctx.baseUrl}${ep}`);
      expect(res.status).toBe(401);
    }

    // 2. Alice creates a bot, alert, watcher, and paper order
    const createBotRes = await fetch(`${ctx.baseUrl}/api/bots`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({
        name: 'Alice Secret Bot',
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        timeframe: '15m',
        mode: 'paper',
        status: 'PAUSED',
        orderAmount: 100,
        stopLossPercent: 2,
        takeProfitPercent: 4,
        entryRules: [
          { id: 'r1', type: 'RSI_OVERSOLD', action: 'BUY', enabled: true, params: { period: 14, threshold: 35 } },
        ],
      }),
    });
    expect(createBotRes.status).toBe(200);
    const aliceBot = await createBotRes.json();

    const createAlertRes = await fetch(`${ctx.baseUrl}/api/alerts`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        condition: 'ABOVE',
        targetPrice: 65000,
      }),
    });
    expect(createAlertRes.status).toBe(200);
    const aliceAlert = await createAlertRes.json();

    const placeOrderRes = await fetch(`${ctx.baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        side: 'BUY',
        type: 'MARKET',
        quantity: 0.01,
        mode: 'paper',
      }),
    });
    expect(placeOrderRes.status).toBe(200);
    const aliceOrder = await placeOrderRes.json();

    // 3. Bob cannot see Alice's bots, alerts, or orders
    const bobBotsRes = await fetch(`${ctx.baseUrl}/api/bots`, {
      headers: { Authorization: 'Bearer token-bob' },
    });
    const bobBotsData = await bobBotsRes.json();
    expect(bobBotsData.bots).toHaveLength(0);

    const bobAlertsRes = await fetch(`${ctx.baseUrl}/api/alerts`, {
      headers: { Authorization: 'Bearer token-bob' },
    });
    const bobAlertsData = await bobAlertsRes.json();
    expect(bobAlertsData.alerts).toHaveLength(0);

    const bobOrdersRes = await fetch(`${ctx.baseUrl}/api/orders`, {
      headers: { Authorization: 'Bearer token-bob' },
    });
    const bobOrdersData = await bobOrdersRes.json();
    expect(bobOrdersData.orders).toHaveLength(0);

    // 4. Bob's isolated paper balance is untouched (Alice spent 600+ USDT; Bob still has 5000)
    const bobAccRes = await fetch(`${ctx.baseUrl}/api/account?mode=paper`, {
      headers: { Authorization: 'Bearer token-bob' },
    });
    const bobAcc = await bobAccRes.json();
    const bobUsdt = bobAcc.balances.find((b: { asset: string }) => b.asset === 'USDT');
    expect(bobUsdt.free).toBe(5000);

    // 5. Bob cannot modify or delete Alice's bot or rearm her alert
    const toggleAliceBot = await fetch(`${ctx.baseUrl}/api/bots/${aliceBot.id}/status`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-bob',
      },
      body: JSON.stringify({ status: 'RUNNING' }),
    });
    expect(toggleAliceBot.status).toBe(400);

    await fetch(`${ctx.baseUrl}/api/bots/${aliceBot.id}`, {
      method: 'DELETE',
      headers: { Authorization: 'Bearer token-bob' },
    });

    const aliceBotsStillThere = await (
      await fetch(`${ctx.baseUrl}/api/bots`, {
        headers: { Authorization: 'Bearer token-alice' },
      })
    ).json();
    expect(aliceBotsStillThere.bots).toHaveLength(1);
    expect(aliceBotsStillThere.bots[0].id).toBe(aliceBot.id);
    expect(aliceBotsStillThere.bots[0].status).toBe('PAUSED');

    const rearmRes = await fetch(`${ctx.baseUrl}/api/alerts/${aliceAlert.id}/rearm`, {
      method: 'POST',
      headers: { Authorization: 'Bearer token-bob' },
    });
    expect(rearmRes.status).toBe(404);
    expect(aliceOrder.orderId).toBeTruthy();
  });

  it('rejects non-admin access on admin routes with 403 and records audit log', async () => {
    const res = await fetch(`${ctx.baseUrl}/api/billing/admin/overview`, {
      headers: { Authorization: 'Bearer token-alice' },
    });
    expect(res.status).toBe(403);

    const stopAllRes = await fetch(`${ctx.baseUrl}/api/billing/admin/bots/emergency-stop`, {
      method: 'POST',
      headers: { Authorization: 'Bearer token-alice' },
    });
    expect(stopAllRes.status).toBe(403);

    const db = getDb();
    const logs = await db.select().from(schema.auditLogs);
    expect(logs.some((l) => l.action === 'ADMIN_ACCESS_DENIED')).toBe(true);
  });

  it('cryptographically validates RS256 Firebase JWTs and rejects forged/expired/wrong-audience tokens', async () => {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
      modulusLength: 2048,
    });
    const certPem = crypto.createPrivateKey({
      key: privateKey.export({ format: 'pem', type: 'pkcs8' }),
      format: 'pem',
    });
    // X.509 self-signed cert via createVerify works against publicKey SPKI PEM directly in Node crypto
    const spkiPem = publicKey.export({ format: 'pem', type: 'spki' }).toString();
    const nowSec = Math.floor(Date.now() / 1000);
    const projectId = 'ali-trader-prod';
    const kid = 'key-1';

    const validJwt = buildSignedRs256Jwt(certPem, kid, {
      aud: projectId,
      iss: `https://securetoken.google.com/${projectId}`,
      sub: 'uid-real-123',
      email: 'trader@example.com',
      email_verified: true,
      iat: nowSec - 10,
      exp: nowSec + 3600,
    });

    const verified = await verifyJwtWithPublicCerts(validJwt, projectId, { [kid]: spkiPem });
    expect(verified).toMatchObject({ uid: 'uid-real-123', email: 'trader@example.com' });

    // Expired JWT
    const expiredJwt = buildSignedRs256Jwt(certPem, kid, {
      aud: projectId,
      iss: `https://securetoken.google.com/${projectId}`,
      sub: 'uid-real-123',
      iat: nowSec - 7200,
      exp: nowSec - 10,
    });
    expect(await verifyJwtWithPublicCerts(expiredJwt, projectId, { [kid]: spkiPem })).toBeNull();

    // Wrong audience JWT
    const wrongAudJwt = buildSignedRs256Jwt(certPem, kid, {
      aud: 'other-firebase-project',
      iss: `https://securetoken.google.com/${projectId}`,
      sub: 'uid-real-123',
      iat: nowSec - 10,
      exp: nowSec + 3600,
    });
    expect(await verifyJwtWithPublicCerts(wrongAudJwt, projectId, { [kid]: spkiPem })).toBeNull();

    // Tampered payload
    const [h, , s] = validJwt.split('.');
    const forgedPayload = Buffer.from(
      JSON.stringify({
        aud: projectId,
        iss: `https://securetoken.google.com/${projectId}`,
        sub: 'shivam-forged-uid',
        email: 'shivamdonyam@gmail.com',
        iat: nowSec - 10,
        exp: nowSec + 3600,
      })
    ).toString('base64url');
    expect(
      await verifyJwtWithPublicCerts(`${h}.${forgedPayload}.${s}`, projectId, { [kid]: spkiPem })
    ).toBeNull();
  });

  it('enforces API key scopes, blocks API keys from Firebase-session-only vault routes, and requires confirmLive for live trades', async () => {
    // Generate read-only API key for Alice
    const genRes = await fetch(`${ctx.baseUrl}/api/keys/app`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({ label: 'Read Only Key', scopes: ['market:read'] }),
    });
    expect(genRes.status).toBe(200);
    const { rawKey } = await genRes.json();
    expect(rawKey).toMatch(/^tbx_live_/);

    // Read-only key CAN read bots
    const readBots = await fetch(`${ctx.baseUrl}/api/bots`, {
      headers: { 'x-app-apikey': rawKey },
    });
    expect(readBots.status).toBe(200);

    // Read-only key CANNOT place orders (missing trade:spot scope)
    const tradeAttempt = await fetch(`${ctx.baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-app-apikey': rawKey,
      },
      body: JSON.stringify({
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        side: 'BUY',
        type: 'MARKET',
        quantity: 0.01,
        mode: 'paper',
      }),
    });
    expect(tradeAttempt.status).toBe(403);

    // API key CANNOT manage Firebase-session-only vault endpoints
    const vaultAttempt = await fetch(`${ctx.baseUrl}/api/keys`, {
      headers: { 'x-app-apikey': rawKey },
    });
    expect(vaultAttempt.status).toBe(403);

    // Save Nobitex token for Alice and verify live order WITHOUT confirmLive is rejected
    const saveEx = await fetch(`${ctx.baseUrl}/api/keys/exchange`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({
        label: 'Alice Nobitex',
        apiToken: 'ALICE_SECRET_TOKEN_XYZ_123456',
        verifyFirst: true,
      }),
    });
    expect(saveEx.status).toBe(200);

    const unconfirmedLiveOrder = await fetch(`${ctx.baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        side: 'BUY',
        type: 'MARKET',
        quantity: 0.01,
        mode: 'live',
      }),
    });
    expect(unconfirmedLiveOrder.status).toBe(400);
    const unconfJson = await unconfirmedLiveOrder.json();
    expect(unconfJson.code).toBe('LIVE_CONFIRMATION_REQUIRED');
  });

  it('strictly isolates Nobitex exchange credentials and Telegram bot delivery per user', async () => {
    // Save distinct Nobitex tokens and Telegram configs for Alice and Bob
    await fetch(`${ctx.baseUrl}/api/keys/exchange`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-alice' },
      body: JSON.stringify({ label: 'Alice Ex', apiToken: 'TOKEN_ONLY_ALICE_999', verifyFirst: true }),
    });
    await fetch(`${ctx.baseUrl}/api/keys/exchange`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-bob' },
      body: JSON.stringify({ label: 'Bob Ex', apiToken: 'TOKEN_ONLY_BOB_777', verifyFirst: true }),
    });

    ctx.nobitex.calls.length = 0;

    // Bob queries his live account -> must use ONLY Bob's token
    const bobLiveAcc = await fetch(`${ctx.baseUrl}/api/account?mode=live`, {
      headers: { Authorization: 'Bearer token-bob' },
    });
    expect(bobLiveAcc.status).toBe(200);
    const authHeadersSentToNobitex = ctx.nobitex.calls
      .filter((c) => c.url.includes('/users/wallets/list'))
      .map((c) => c.authHeader);
    expect(authHeadersSentToNobitex).toEqual(['Token TOKEN_ONLY_BOB_777']);

    // Telegram isolation: configure Alice & Bob with different tokens & chatIds
    await fetch(`${ctx.baseUrl}/api/features/telegram`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-alice' },
      body: JSON.stringify({
        botToken: '11111111:AAABBBCCCDDDEEEFFFGGGHHHIIIJJJ_ALICE',
        chatId: '100001',
        enabled: true,
      }),
    });
    await fetch(`${ctx.baseUrl}/api/features/telegram`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-bob' },
      body: JSON.stringify({
        botToken: '22222222:AAABBBCCCDDDEEEFFFGGGHHHIIIJJJ_BOB',
        chatId: '200002',
        enabled: true,
      }),
    });

    ctx.telegram.calls.length = 0;
    const aliceTestTg = await fetch(`${ctx.baseUrl}/api/features/telegram/test`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Bearer token-alice' },
      body: JSON.stringify({}),
    });
    expect(aliceTestTg.status).toBe(200);

    const sentMsgs = ctx.telegram.calls.filter((c) => c.method === 'sendMessage');
    expect(sentMsgs).toHaveLength(1);
    expect(sentMsgs[0].botToken).toContain('_ALICE');
    expect(sentMsgs[0].body.chat_id).toBe('100001');
  });
});
