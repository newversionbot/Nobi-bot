import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { PGlite } from '@electric-sql/pglite';
import { getPricePulses } from '../server/botEngine.ts';
import {
  closeDatabase,
  getDb,
  initDatabase,
  migrateLegacyJsonFiles,
} from '../server/db/index.ts';
import { encryptSecretText, reloadVaultKeyRing } from '../server/securityVault.ts';
import * as schema from '../src/db/schema.ts';

describe('Legacy JSON Migration Safety, Idempotency, and Rollback Integrity', () => {
  let tmpDir: string;

  beforeEach(async () => {
    process.env.NODE_ENV = 'test';
    reloadVaultKeyRing({
      primaryKeyId: 'v1',
      primarySecret: 'legacy-migration-test-key-32-chars!!',
    });
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ali-legacy-mig-'));
    await initDatabase({ pgliteDataDir: 'memory://', forceReset: true });
  }, 30_000);

  afterEach(async () => {
    await closeDatabase();
    fs.rmSync(tmpDir, { recursive: true, force: true });
  });

  it('migrates billing, vault, and trader-state JSON cleanly, stays idempotent, and preserves legacy files', async () => {
    const encCred = encryptSecretText(JSON.stringify({ apiToken: 'LEGACY_NOBITEX_TOKEN_1234' }));

    fs.writeFileSync(
      path.join(tmpDir, '.nobitex-billing.json'),
      JSON.stringify({
        users: {
          'uid-legacy-1': {
            uid: 'uid-legacy-1',
            email: 'legacy1@example.com',
            displayName: 'کاربر قدیمی',
            referralCode: 'ALI-LEG001',
            createdAt: 1700000000000,
            lastSeenAt: 1700000000000,
          },
        },
        subscriptions: {
          'uid-legacy-1': {
            userId: 'uid-legacy-1',
            email: 'legacy1@example.com',
            displayName: 'کاربر قدیمی',
            plan: 'PRO_MONTHLY',
            status: 'ACTIVE',
            paymentMethod: 'USDT',
            startAt: 1700000000000,
            expiresAt: Date.now() + 86_400_000 * 15,
            updatedAt: 1700000000000,
          },
        },
      })
    );

    fs.writeFileSync(
      path.join(tmpDir, '.nobitex-vault.json'),
      JSON.stringify({
        exchangeCreds: [
          {
            id: 'cred-legacy-1',
            userId: 'uid-legacy-1',
            label: 'Legacy Exchange',
            maskedApiKey: 'nbt_LEG••••1234',
            keyId: 'v1',
            encryptedToken: encCred.encryptedToken,
            iv: encCred.iv,
            authTag: encCred.authTag,
            status: 'ACTIVE',
            createdAt: 1700000000000,
          },
        ],
      })
    );

    fs.writeFileSync(
      path.join(tmpDir, '.nobitex-trader-state.json'),
      JSON.stringify({
        bots: [
          {
            id: 'bot-legacy-1',
            ownerId: 'uid-legacy-1',
            name: 'Legacy RSI Bot',
            baseAsset: 'BTC',
            quoteCurrency: 'USDT',
            symbol: 'BTCUSDT',
            timeframe: '15m',
            mode: 'paper',
            status: 'PAUSED',
            orderAmount: 300,
            entryRules: [{ id: 'r1', type: 'RSI_OVERSOLD', action: 'BUY', enabled: true, params: {} }],
            exitRules: [],
          },
        ],
        paperBalances: { IRT: 250_000_000, USDT: 2500 },
        alerts: [
          {
            id: 'alert-legacy-1',
            ownerId: 'uid-legacy-1',
            baseAsset: 'BTC',
            persianName: 'بیت‌کوین',
            quoteCurrency: 'USDT',
            symbol: 'BTCUSDT',
            condition: 'ABOVE',
            targetPrice: 90000,
            createdPrice: 65000,
          },
        ],
      })
    );

    // 1. First migration succeeds and imports all records
    const firstRun = await migrateLegacyJsonFiles({ baseDir: tmpDir });
    expect(firstRun.skipped).toBe(false);
    expect(firstRun.migratedBilling).toBe(true);
    expect(firstRun.migratedVault).toBe(true);
    expect(firstRun.migratedState).toBe(true);
    expect(firstRun.counts.users).toBe(1);
    expect(firstRun.counts.bots).toBe(1);
    expect(firstRun.counts.exchangeCredentials).toBe(1);

    const db = getDb();
    expect(await db.select().from(schema.users)).toHaveLength(1);
    expect(await db.select().from(schema.tradingBots)).toHaveLength(1);
    expect(await db.select().from(schema.exchangeCredentials)).toHaveLength(1);
    expect(await db.select().from(schema.priceAlerts)).toHaveLength(1);

    // 2. Legacy files MUST remain untouched on disk until operator verifies
    expect(fs.existsSync(path.join(tmpDir, '.nobitex-billing.json'))).toBe(true);
    expect(fs.existsSync(path.join(tmpDir, '.nobitex-vault.json'))).toBe(true);
    expect(fs.existsSync(path.join(tmpDir, '.nobitex-trader-state.json'))).toBe(true);

    // 3. Re-running migration is strictly idempotent (no duplicate errors or rows)
    const secondRun = await migrateLegacyJsonFiles({ baseDir: tmpDir });
    expect(secondRun.skipped).toBe(true);
    expect(secondRun.reason).toBe('already_migrated');

    const forcedRerun = await migrateLegacyJsonFiles({ baseDir: tmpDir, forceRerun: true });
    expect(forcedRerun.skipped).toBe(false);
    expect(await db.select().from(schema.users)).toHaveLength(1);
    expect(await db.select().from(schema.tradingBots)).toHaveLength(1);
  });

  it('rolls back completely on corrupted legacy JSON without corrupting existing DB state', async () => {
    const db = getDb();
    await db.insert(schema.users).values({
      uid: 'existing-safe-user',
      email: 'safe@example.com',
      displayName: 'Safe User',
      isBanned: false,
      referralCode: 'ALI-SAFE01',
      referralBonusDaysEarned: 0,
      createdAt: Date.now(),
      lastSeenAt: Date.now(),
    });

    // Valid billing + corrupted trader state triggers mid-transaction failure
    fs.writeFileSync(
      path.join(tmpDir, '.nobitex-billing.json'),
      JSON.stringify({
        users: {
          'should-rollback-uid': {
            uid: 'should-rollback-uid',
            email: 'rollback@example.com',
            referralCode: 'ALI-ROLL01',
          },
        },
      })
    );
    fs.writeFileSync(path.join(tmpDir, '.nobitex-trader-state.json'), '{ INVALID_JSON_CORRUPT');

    await expect(migrateLegacyJsonFiles({ baseDir: tmpDir })).rejects.toThrow();

    // Existing DB user intact; partially imported user rolled back cleanly
    const usersAfter = await db.select().from(schema.users);
    expect(usersAfter).toHaveLength(1);
    expect(usersAfter[0].uid).toBe('existing-safe-user');
  });

  it('automatically repairs missing columns on stale persisted tables (e.g. notifications.kind/title/message)', async () => {
    await closeDatabase();
    const staleDbDir = path.join(tmpDir, 'stale-pglite');
    fs.mkdirSync(staleDbDir, { recursive: true });

    // Create an older schema version of users + notifications without kind/title/message
    const pg = new PGlite(staleDbDir);
    await pg.waitReady;
    await pg.exec(`
      CREATE TABLE users (
        uid TEXT PRIMARY KEY,
        email TEXT NOT NULL DEFAULT '',
        display_name TEXT NOT NULL DEFAULT 'کاربر',
        referral_code TEXT NOT NULL DEFAULT 'ALI-OLD01',
        created_at BIGINT NOT NULL DEFAULT 0,
        last_seen_at BIGINT NOT NULL DEFAULT 0
      );
      INSERT INTO users (uid, email, referral_code) VALUES ('u-stale', 'stale@example.com', 'ALI-OLD01');
      CREATE TABLE notifications (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        watcher_id TEXT NOT NULL,
        base_asset TEXT NOT NULL,
        persian_name TEXT NOT NULL,
        quote_mode TEXT NOT NULL DEFAULT 'BOTH',
        price_toman DOUBLE PRECISION NOT NULL DEFAULT 0,
        price_usdt DOUBLE PRECISION NOT NULL DEFAULT 0,
        change_24h_percent DOUBLE PRECISION NOT NULL DEFAULT 0,
        interval_minutes INTEGER NOT NULL DEFAULT 5,
        sent_at BIGINT NOT NULL
      );
      INSERT INTO notifications (id, user_id, watcher_id, base_asset, persian_name, change_24h_percent, sent_at)
      VALUES ('n-1', 'u-stale', 'w-1', 'BTC', 'بیت‌کوین', 3.75, 1700000000000);
    `);
    await pg.close();

    // Booting initDatabase against stale DB must sync missing columns cleanly
    await initDatabase({ pgliteDataDir: staleDbDir, forceReset: true });
    const pulses = await getPricePulses('u-stale');
    expect(pulses).toHaveLength(1);
    expect(pulses[0].id).toBe('n-1');
    expect(pulses[0].baseAsset).toBe('BTC');
    expect(pulses[0].change24hPercent).toBe(3.75);

    const rawRows = await getDb().select().from(schema.notifications);
    expect(rawRows[0].kind).toBe('PRICE_PULSE');
    expect(rawRows[0].title).toBeNull();
    expect(rawRows[0].message).toBeNull();
  }, 15_000);
});
