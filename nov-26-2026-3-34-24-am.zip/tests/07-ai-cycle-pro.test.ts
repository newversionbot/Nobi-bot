import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { activateUserProSubscription } from '../server/billingVault.ts';
import { getPaperOrders } from '../server/botEngine.ts';
import {
  createAiCycleProBot,
  evaluateAiCycleProBot,
  getUserAiCycleProBotById,
  getUserAiCycleProCycles,
  getUserAiCycleProLogs,
  previewAiCycleProMarket,
  type AiCycleProRuntimeDeps,
} from '../server/aiCycleProEngine.ts';
import type { KlineCandle, OrderBookSnapshot, UnifiedMarketTicker } from '../src/types/trading.ts';
import {
  startIsolatedTestServer,
  TEST_USERS,
  type TestServerContext,
} from './helpers/testHarness.ts';

function buildCandles(prices: number[]): KlineCandle[] {
  const startMs = 1_740_000_000_000;
  return prices.map((close, idx) => {
    const openTime = startMs + idx * 900_000;
    const volume = 18 + (idx % 5) * 3;
    return {
      openTime,
      open: idx > 0 ? prices[idx - 1] : close,
      high: close * 1.004,
      low: close * 0.996,
      close,
      volume,
      closeTime: openTime + 899_999,
      quoteVolume: volume * close,
      trades: 42,
    };
  });
}

function buildOrderBook(params: {
  symbol: string;
  midPrice: number;
  spreadPct: number;
  depthMultiplier?: number;
}): OrderBookSnapshot {
  const halfSpread = (params.spreadPct / 100) / 2;
  const bestBid = params.midPrice * (1 - halfSpread);
  const bestAsk = params.midPrice * (1 + halfSpread);
  const qtyUnit = (params.depthMultiplier ?? 1) * (50_000 / Math.max(1, params.midPrice));
  return {
    symbol: params.symbol,
    quoteCurrency: 'USDT',
    timestamp: Date.now(),
    lastTradePrice: params.midPrice,
    spread: Math.max(0, bestAsk - bestBid),
    spreadPercent: params.spreadPct,
    bids: [
      { price: bestBid, quantity: qtyUnit, total: qtyUnit },
      { price: bestBid * 0.998, quantity: qtyUnit * 2, total: qtyUnit * 3 },
      { price: bestBid * 0.994, quantity: qtyUnit * 3, total: qtyUnit * 6 },
    ],
    asks: [
      { price: bestAsk, quantity: qtyUnit, total: qtyUnit },
      { price: bestAsk * 1.002, quantity: qtyUnit * 2, total: qtyUnit * 3 },
      { price: bestAsk * 1.006, quantity: qtyUnit * 3, total: qtyUnit * 6 },
    ],
  };
}

function buildMarketTicker(priceUsdt: number, change24hPercent: number): UnifiedMarketTicker {
  return {
    baseAsset: 'BTC',
    persianName: 'بیت‌کوین',
    symbolIrt: 'BTCIRT',
    symbolUsdt: 'BTCUSDT',
    hasIrtMarket: true,
    hasUsdtMarket: true,
    priceToman: priceUsdt * 70_000,
    priceUsdt,
    bestBuyToman: priceUsdt * 70_000 * 0.999,
    bestSellToman: priceUsdt * 70_000 * 1.001,
    bestBuyUsdt: priceUsdt * 0.999,
    bestSellUsdt: priceUsdt * 1.001,
    change24hPercent,
    high24hToman: priceUsdt * 70_000 * 1.03,
    low24hToman: priceUsdt * 70_000 * 0.97,
    high24hUsdt: priceUsdt * 1.03,
    low24hUsdt: priceUsdt * 0.97,
    volumeToman: priceUsdt * 70_000 * 15,
    volumeUsdt: priceUsdt * 15,
    volumeSrc: 15,
    usdtTomanRate: 70_000,
    timestamp: Date.now(),
  };
}

function makeDeps(state: {
  priceUsdt: number;
  spreadPct?: number;
  change24h?: number;
  trendPrices?: number[];
  depthMultiplier?: number;
  forceAction?: 'BUY' | 'HOLD_CASH' | 'SELL' | 'HOLD_POSITION';
  forceCondition?: 'FAVORABLE' | 'NEUTRAL' | 'UNFAVORABLE';
  nowMs?: number;
}): Partial<AiCycleProRuntimeDeps> {
  const symbol = 'BTCUSDT';
  const prices =
    state.trendPrices ??
    Array.from({ length: 65 }, (_, i) => Number((state.priceUsdt * (0.96 + i * 0.0006)).toFixed(2)));
  const candles = buildCandles(prices);

  return {
    fetchOrderBook: async () =>
      buildOrderBook({
        symbol,
        midPrice: state.priceUsdt,
        spreadPct: state.spreadPct ?? 0.12,
        depthMultiplier: state.depthMultiplier ?? 2,
      }),
    fetchMarkets: async () => ({
      markets: [buildMarketTicker(state.priceUsdt, state.change24h ?? 1.8)],
      usdtTomanRate: 70_000,
    }),
    fetchKlines: async () => candles,
    getMarketRules: async () => ({ minNotional: 1, amountStep: 0.000001 }),
    analyzeMarket: async (input) => ({
      action: state.forceAction ?? (input.activePosition ? 'HOLD_POSITION' : 'BUY'),
      marketCondition: state.forceCondition ?? 'FAVORABLE',
      confidencePercent: 84,
      trendScore: state.forceCondition === 'UNFAVORABLE' ? 25 : 78,
      liquidityScore: (state.spreadPct ?? 0.12) > 2 ? 32 : 90,
      volatilityPercent: 1.4,
      spreadPercent: input.orderBook.spreadPercent,
      estimatedSlippagePercent: input.buySlippagePercent,
      recommendedCapitalPortionPercent: input.capitalUsageMode === 'PARTIAL' ? input.capitalPortionPercent : 100,
      recommendedTargetNetProfitPercent: input.minTargetNetProfitPercent,
      recommendedStopLossPercent: input.stopLossPercent,
      suggestedBuyPrice: input.executableBuyPrice,
      suggestedSellPrice: Number((input.executableBuyPrice * 1.022).toFixed(2)),
      regimeLabelFa: state.forceCondition === 'UNFAVORABLE' ? 'نامناسب — نقد' : 'صعودی متعادل',
      reasoningFa:
        state.forceCondition === 'UNFAVORABLE'
          ? 'اسپرد یا روند بازار مناسب نیست؛ سرمایه نقد نگه داشته شد.'
          : 'نقدینگی دفتر سفارش و مومنتوم بازار برای چرخه مناسب است.',
      riskWarningFa: 'حد ضرر فعال و کارمزدها لحاظ شده است.',
      usedFallback: false,
      analyzedAt: state.nowMs ?? Date.now(),
    }),
    now: () => state.nowMs ?? Date.now(),
  };
}

describe('AI Cycle Pro | ربات چرخه هوشمند End-to-End Suite', () => {
  let ctx: TestServerContext;

  beforeEach(async () => {
    ctx = await startIsolatedTestServer();
    await activateUserProSubscription(
      {
        userId: TEST_USERS['token-alice'].uid,
        email: TEST_USERS['token-alice'].email,
        displayName: TEST_USERS['token-alice'].displayName,
        paymentMethod: 'ADMIN_GRANT',
        days: 30,
      },
      'test-setup@system.local'
    );
    await activateUserProSubscription(
      {
        userId: TEST_USERS['token-bob'].uid,
        email: TEST_USERS['token-bob'].email,
        displayName: TEST_USERS['token-bob'].displayName,
        paymentMethod: 'ADMIN_GRANT',
        days: 30,
      },
      'test-setup@system.local'
    );
  }, 30_000);

  afterEach(async () => {
    await ctx.close();
  });

  it('creates, updates, starts/stops, enforces live confirm guard and multi-tenant isolation via REST', async () => {
    // Attempt live creation without confirmLive => 400
    const badLiveRes = await fetch(`${ctx.baseUrl}/api/ai-cycle-pro`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        capitalAmount: 200,
        mode: 'live',
        confirmLive: false,
      }),
    });
    expect(badLiveRes.status).toBe(400);

    // Create paper AI Cycle Pro bot with PARTIAL 40% capital portion
    const createRes = await fetch(`${ctx.baseUrl}/api/ai-cycle-pro`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({
        name: 'چرخه بیت‌کوین آلیس',
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        capitalAmount: 500,
        capitalUsageMode: 'PARTIAL',
        capitalPortionPercent: 40,
        executionConfirmationMode: 'AUTO',
        minTargetNetProfitPercent: 1.5,
        stopLossPercent: 3,
      }),
    });
    expect(createRes.status).toBe(200);
    const createdBot = (await createRes.json()) as {
      id: string;
      capitalPortionPercent: number;
      capitalUsageMode: string;
    };
    expect(createdBot.capitalUsageMode).toBe('PARTIAL');
    expect(createdBot.capitalPortionPercent).toBe(40);
    const botId = createdBot.id;

    // Bob must NOT see or mutate Alice's bot
    const bobListRes = await fetch(`${ctx.baseUrl}/api/ai-cycle-pro`, {
      headers: { Authorization: 'Bearer token-bob' },
    });
    expect(bobListRes.status).toBe(200);
    const bobData = (await bobListRes.json()) as { bots: unknown[] };
    expect(bobData.bots).toHaveLength(0);

    const bobPatchRes = await fetch(`${ctx.baseUrl}/api/ai-cycle-pro/${botId}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-bob',
      },
      body: JSON.stringify({ capitalAmount: 900 }),
    });
    expect(bobPatchRes.status).toBe(404);

    // Alice patches, starts, stops, and deletes cleanly
    const patchRes = await fetch(`${ctx.baseUrl}/api/ai-cycle-pro/${botId}`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({ capitalAmount: 600, minTargetNetProfitPercent: 2.0 }),
    });
    expect(patchRes.status).toBe(200);

    const startRes = await fetch(`${ctx.baseUrl}/api/ai-cycle-pro/${botId}/start`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({}),
    });
    expect(startRes.status).toBe(200);
    const started = (await startRes.json()) as { isActive: boolean; status: string };
    expect(started.isActive).toBe(true);
    expect(['ANALYZING', 'WAITING_CASH']).toContain(started.status);

    const stopRes = await fetch(`${ctx.baseUrl}/api/ai-cycle-pro/${botId}/stop`, {
      method: 'POST',
      headers: { Authorization: 'Bearer token-alice' },
    });
    expect(stopRes.status).toBe(200);

    const delRes = await fetch(`${ctx.baseUrl}/api/ai-cycle-pro/${botId}`, {
      method: 'DELETE',
      headers: { Authorization: 'Bearer token-alice' },
    });
    expect(delRes.status).toBe(200);
  });

  it('keeps funds in cash (WAITING_CASH) and places zero BUY orders when market conditions are unfavorable', async () => {
    const uid = TEST_USERS['token-alice'].uid;
    const bot = await createAiCycleProBot(uid, {
      baseAsset: 'BTC',
      quoteCurrency: 'USDT',
      capitalAmount: 400,
      startImmediately: true,
      maxSpreadPercent: 1.0,
    });

    // Wide spread + unfavorable condition
    const deps = makeDeps({
      priceUsdt: 60_000,
      spreadPct: 3.8,
      change24h: -7.5,
      forceAction: 'HOLD_CASH',
      forceCondition: 'UNFAVORABLE',
    });

    const preview = await previewAiCycleProMarket(
      {
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        capitalAmount: 400,
        maxSpreadPercent: 1.0,
      },
      deps
    );
    expect(preview.decision.action).toBe('HOLD_CASH');
    expect(preview.decision.marketCondition).toBe('UNFAVORABLE');

    const afterEval = await evaluateAiCycleProBot(bot, deps);
    expect(afterEval.status).toBe('WAITING_CASH');
    expect(afterEval.activePosition).toBeNull();

    const orders = await getPaperOrders(uid);
    expect(orders.filter((o) => o.botId === bot.id)).toHaveLength(0);

    const logs = await getUserAiCycleProLogs(uid, bot.id);
    expect(logs.some((l) => l.event === 'WAIT_CASH')).toBe(true);
  });

  it('executes full autonomous cycle: BUY within capital ceiling, hold without double-buy, SELL on target profit with exact fees, record history, and repeat', async () => {
    const uid = TEST_USERS['token-alice'].uid;
    const bot = await createAiCycleProBot(uid, {
      name: 'چرخه کامل بیت‌کوین',
      baseAsset: 'BTC',
      quoteCurrency: 'USDT',
      capitalAmount: 500,
      capitalUsageMode: 'FULL',
      minTargetNetProfitPercent: 1.5,
      stopLossPercent: 4,
      autoRepeatCycles: true,
      startImmediately: true,
    });

    const t0 = Date.now();
    // Step 1: Favorable market at 60,000 => executes BUY capped by 500 USDT
    const afterBuy = await evaluateAiCycleProBot(
      bot,
      makeDeps({
        priceUsdt: 60_000,
        spreadPct: 0.1,
        forceAction: 'BUY',
        forceCondition: 'FAVORABLE',
        nowMs: t0,
      })
    );
    expect(afterBuy.status).toBe('HOLDING_POSITION');
    expect(afterBuy.activePosition).not.toBeNull();
    expect(afterBuy.activePosition!.totalBuyCostQuote).toBeLessThanOrEqual(500.01);
    expect(afterBuy.activePosition!.buyFeeQuote).toBeGreaterThan(0);
    expect(afterBuy.activePosition!.netOwnedQty).toBeLessThan(afterBuy.activePosition!.filledGrossQty);

    // Step 2: Flat market => holds position, NO duplicate BUY
    const whileHolding = await evaluateAiCycleProBot(
      afterBuy,
      makeDeps({
        priceUsdt: 60_150,
        spreadPct: 0.1,
        forceAction: 'HOLD_POSITION',
        forceCondition: 'FAVORABLE',
        nowMs: t0 + 15_000,
      })
    );
    expect(whileHolding.status).toBe('HOLDING_POSITION');
    const ordersMid = await getPaperOrders(uid);
    expect(ordersMid.filter((o) => o.botId === bot.id && o.side === 'BUY')).toHaveLength(1);

    // Step 3: Price rises +3% => exceeds 1.5% net profit after 0.25%+0.25% fees & slippage => SELL completes cycle!
    const afterSell = await evaluateAiCycleProBot(
      whileHolding,
      makeDeps({
        priceUsdt: 61_850,
        spreadPct: 0.1,
        forceAction: 'HOLD_POSITION',
        forceCondition: 'FAVORABLE',
        nowMs: t0 + 45_000,
      })
    );
    expect(afterSell.activePosition).toBeNull();
    expect(afterSell.isActive).toBe(true);
    expect(afterSell.status).toBe('ANALYZING'); // Auto-repeat ready for next cycle
    expect(afterSell.stats.completedCycles).toBe(1);
    expect(afterSell.stats.winningCycles).toBe(1);
    expect(afterSell.stats.totalNetProfitQuote).toBeGreaterThan(5);
    expect(afterSell.stats.currentCapitalInvolved).toBe(0);

    const cycles = await getUserAiCycleProCycles(uid, bot.id);
    expect(cycles).toHaveLength(1);
    expect(cycles[0].exitReason).toBe('AI_TARGET_PROFIT');
    expect(cycles[0].finalNetProfitQuote).toBeGreaterThan(5);
    expect(cycles[0].buyFeeQuote).toBeGreaterThan(0);
    expect(cycles[0].sellFeeQuote).toBeGreaterThan(0);
  });

  it('enforces Stop-Loss, Daily Loss Cap (PAUSED_RISK), Kill Switch, and MANUAL_CONFIRM approval workflow', async () => {
    const uid = TEST_USERS['token-alice'].uid;

    // A) Stop-Loss + Daily Loss Cap trigger PAUSED_RISK
    const riskBot = await createAiCycleProBot(uid, {
      name: 'تست حد ضرر و سقف زیان',
      baseAsset: 'BTC',
      quoteCurrency: 'USDT',
      capitalAmount: 400,
      stopLossPercent: 3,
      maxDailyLoss: 10, // Dropping >3% on 400 USDT loses >12 USDT => trips 10 USDT daily cap
      autoRepeatCycles: true,
      startImmediately: true,
    });

    const t0 = Date.now();
    const entered = await evaluateAiCycleProBot(
      riskBot,
      makeDeps({
        priceUsdt: 60_000,
        forceAction: 'BUY',
        forceCondition: 'FAVORABLE',
        nowMs: t0,
      })
    );
    expect(entered.activePosition).not.toBeNull();

    // Crash -5% (below -3% stop loss)
    const stoppedOut = await evaluateAiCycleProBot(
      entered,
      makeDeps({
        priceUsdt: 57_000,
        forceAction: 'HOLD_POSITION',
        forceCondition: 'UNFAVORABLE',
        nowMs: t0 + 20_000,
      })
    );
    expect(stoppedOut.activePosition).toBeNull();
    expect(stoppedOut.isActive).toBe(false);
    expect(stoppedOut.status).toBe('PAUSED_RISK');
    expect(stoppedOut.dailyStats.lossQuote).toBeGreaterThanOrEqual(10);

    const cycles = await getUserAiCycleProCycles(uid, riskBot.id);
    expect(cycles[0].exitReason).toBe('STOP_LOSS');

    // B) MANUAL_CONFIRM mode creates Pending Confirmation & approves cleanly over REST
    const manualBot = await createAiCycleProBot(uid, {
      name: 'تست تایید دستی',
      baseAsset: 'BTC',
      quoteCurrency: 'USDT',
      capitalAmount: 200,
      executionConfirmationMode: 'MANUAL_CONFIRM',
      startImmediately: true,
    });

    const afterManualEval = await evaluateAiCycleProBot(
      manualBot,
      makeDeps({
        priceUsdt: 60_000,
        forceAction: 'BUY',
        forceCondition: 'FAVORABLE',
        nowMs: t0 + 30_000,
      })
    );
    expect(afterManualEval.activePosition).toBeNull();

    const confRes = await fetch(`${ctx.baseUrl}/api/bots/pending-confirmations`, {
      headers: { Authorization: 'Bearer token-alice' },
    });
    expect(confRes.status).toBe(200);
    const confData = (await confRes.json()) as {
      items: Array<{ id: string; botType: string; botId: string; status: string }>;
    };
    const pendingItem = confData.items.find(
      (i) => i.botType === 'AI_CYCLE_PRO' && i.botId === manualBot.id && i.status === 'PENDING'
    );
    expect(pendingItem).toBeDefined();

    const approveRes = await fetch(
      `${ctx.baseUrl}/api/bots/pending-confirmations/${pendingItem!.id}/resolve`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer token-alice',
        },
        body: JSON.stringify({ decision: 'APPROVE' }),
      }
    );
    expect(approveRes.status).toBe(200);

    const refreshedManualBot = await getUserAiCycleProBotById(uid, manualBot.id);
    expect(refreshedManualBot?.activePosition).not.toBeNull();
    expect(refreshedManualBot?.status).toBe('HOLDING_POSITION');

    // C) Kill switch stops all active AI Cycle Pro bots immediately
    const ksRes = await fetch(`${ctx.baseUrl}/api/bots/kill-switch`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({ active: true }),
    });
    expect(ksRes.status).toBe(200);
    const afterKsBot = await getUserAiCycleProBotById(uid, manualBot.id);
    expect(afterKsBot?.isActive).toBe(false);
    expect(afterKsBot?.status).toBe('STOPPED');
  });
});
