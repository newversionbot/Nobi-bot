import crypto from 'node:crypto';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { activateUserProSubscription } from '../server/billingVault.ts';
import { getDb } from '../server/db/index.ts';
import { redactSensitiveText } from '../server/logger.ts';
import { setNobitexFetchForTest } from '../server/nobitexClient.ts';
import { decryptSecretText, getActiveExchangeCredentialsForUser } from '../server/securityVault.ts';
import * as schema from '../src/db/schema.ts';
import { startIsolatedTestServer, TEST_USERS, type TestServerContext } from './helpers/testHarness.ts';

describe('Nobitex Ed25519 Key Pair (API Key + Secret Key) Authentication', () => {
  let ctx: TestServerContext;

  beforeEach(async () => {
    ctx = await startIsolatedTestServer();
  });

  afterEach(async () => {
    await ctx.close();
  });

  it('encrypts API Key + Secret Key (Base64URL, Hex, PEM), allows non-PRO linking, and signs requests with verifiable Ed25519 signatures', async () => {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
    const pkcs8Der = privateKey.export({ format: 'der', type: 'pkcs8' }) as Buffer;
    const rawSeed32 = pkcs8Der.subarray(16, 48);
    const seedBase64Url = rawSeed32.toString('base64url');
    const seedHex = rawSeed32.toString('hex');
    const pemPrivate = privateKey.export({ format: 'pem', type: 'pkcs8' }) as string;
    const pemPublic = publicKey.export({ format: 'pem', type: 'spki' }) as string;

    const bobUid = TEST_USERS['token-bob'].uid;

    // 1. Public key pasted into Secret Key must be rejected with clear 400 error
    const badPubRes = await fetch(`${ctx.baseUrl}/api/keys/exchange`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-bob',
      },
      body: JSON.stringify({
        label: 'Wrong Public Key',
        authType: 'KEY_PAIR',
        apiKey: 'nbt_pub_key_1234567890',
        secretKey: pemPublic,
        verifyFirst: false,
      }),
    });
    expect(badPubRes.status).toBe(400);
    const badPubJson = await badPubRes.json();
    expect(badPubJson.error).toContain('عمومی');

    // 2. Non-PRO user Bob can link & verify API Key + Secret Key (Base64URL seed)
    ctx.nobitex.calls.length = 0;
    const saveRes = await fetch(`${ctx.baseUrl}/api/keys/exchange`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-bob',
      },
      body: JSON.stringify({
        label: 'Bob Ed25519 KeyPair',
        authType: 'KEY_PAIR',
        apiKey: 'AK_BOB_ED25519_00112233',
        secretKey: seedBase64Url,
        verifyFirst: true,
      }),
    });
    expect(saveRes.status).toBe(200);
    const saveJson = await saveRes.json();
    expect(saveJson.verified).toBe(true);
    expect(saveJson.credential.authType).toBe('KEY_PAIR');
    expect(saveJson.credential.maskedApiKey).toMatch(/^key_AK_BO/);
    expect(saveJson.credential.maskedApiKey).not.toContain(seedBase64Url);

    // Verify Nobitex received Ed25519 headers and cryptographically valid signature
    const walletCall = ctx.nobitex.calls.find((c) => c.url.includes('/users/wallets/list'));
    expect(walletCall).toBeDefined();
    expect(walletCall!.authHeader).toBe('');
    expect(walletCall!.nobitexKey).toBe('AK_BOB_ED25519_00112233');
    expect(walletCall!.userAgent).toBe('TraderBot/ALITrader-1.0');
    expect(walletCall!.nobitexTimestamp).toMatch(/^\d{10}$/);
    expect(walletCall!.nobitexSignature).toBeTruthy();

    const signedPayload = `${walletCall!.nobitexTimestamp}POST/users/wallets/list${walletCall!.body || ''}`;
    const sigValid = crypto.verify(
      null,
      Buffer.from(signedPayload, 'utf8'),
      publicKey,
      Buffer.from(walletCall!.nobitexSignature!, 'base64url')
    );
    expect(sigValid).toBe(true);

    // Verify database stored encrypted payload with both apiKey & secretKey
    const db = getDb();
    const rows = await db
      .select()
      .from(schema.exchangeCredentials)
      .where((await import('drizzle-orm')).eq(schema.exchangeCredentials.userId, bobUid));
    expect(rows).toHaveLength(1);
    const decrypted = JSON.parse(
      decryptSecretText(rows[0].encryptedToken, rows[0].iv, rows[0].authTag, rows[0].keyId)
    );
    expect(decrypted).toEqual({
      authType: 'KEY_PAIR',
      apiKey: 'AK_BOB_ED25519_00112233',
      secretKey: seedBase64Url,
    });

    // 3. Test /api/keys/exchange/test endpoint with Key Pair
    ctx.nobitex.calls.length = 0;
    const testRes = await fetch(`${ctx.baseUrl}/api/keys/exchange/test`, {
      method: 'POST',
      headers: { Authorization: 'Bearer token-bob' },
    });
    expect(testRes.status).toBe(200);
    const testJson = await testRes.json();
    expect(testJson.ok).toBe(true);
    expect(testJson.authType).toBe('KEY_PAIR');
    expect(testJson.balancesCount).toBe(3);

    // 4. Test Hex 64-char secretKey and PEM secretKey also sign cleanly & place live order
    await activateUserProSubscription(
      {
        userId: bobUid,
        email: TEST_USERS['token-bob'].email,
        displayName: TEST_USERS['token-bob'].displayName,
        paymentMethod: 'ADMIN_GRANT',
        days: 30,
      },
      'test-setup@system.local'
    );
    const savePemRes = await fetch(`${ctx.baseUrl}/api/keys/exchange`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-bob',
      },
      body: JSON.stringify({
        label: 'Bob PEM Key',
        authType: 'KEY_PAIR',
        apiKey: 'AK_BOB_PEM_99887766',
        secretKey: pemPrivate,
        verifyFirst: false,
      }),
    });
    expect(savePemRes.status).toBe(200);

    const saveHexRes = await fetch(`${ctx.baseUrl}/api/keys/exchange`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-bob',
      },
      body: JSON.stringify({
        label: 'Bob Hex Key',
        authType: 'KEY_PAIR',
        apiKey: 'AK_BOB_HEX_44556677',
        secretKey: seedHex,
        verifyFirst: true,
      }),
    });
    expect(saveHexRes.status).toBe(200);

    const activeCreds = await getActiveExchangeCredentialsForUser(bobUid);
    expect(activeCreds?.authType).toBe('KEY_PAIR');
    expect(activeCreds?.apiKey).toBe('AK_BOB_HEX_44556677');

    ctx.nobitex.calls.length = 0;
    const liveOrderRes = await fetch(`${ctx.baseUrl}/api/orders`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-bob',
      },
      body: JSON.stringify({
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        side: 'BUY',
        type: 'MARKET',
        quantity: 0.01,
        mode: 'live',
        confirmLive: true,
      }),
    });
    expect(liveOrderRes.status).toBe(200);

    const orderAddCall = ctx.nobitex.calls.find((c) => c.url.includes('/market/orders/add'));
    expect(orderAddCall).toBeDefined();
    expect(orderAddCall!.nobitexKey).toBe('AK_BOB_HEX_44556677');
    const orderPayload = `${orderAddCall!.nobitexTimestamp}POST/market/orders/add${orderAddCall!.body}`;
    expect(
      crypto.verify(
        null,
        Buffer.from(orderPayload, 'utf8'),
        publicKey,
        Buffer.from(orderAddCall!.nobitexSignature!, 'base64url')
      )
    ).toBe(true);
  });

  it('surfaces clear Persian errors on 403/InvalidSignature and redacts Key Pair headers from logs', async () => {
    const { privateKey } = crypto.generateKeyPairSync('ed25519');
    const pkcs8Der = privateKey.export({ format: 'der', type: 'pkcs8' }) as Buffer;
    const seedBase64Url = pkcs8Der.subarray(16, 48).toString('base64url');

    // Simulate Nobitex 403 firewall/IP block returning HTML
    setNobitexFetchForTest(async () => {
      return new Response('<html><body>403 Forbidden</body></html>', {
        status: 403,
        headers: { 'Content-Type': 'text/html' },
      });
    });

    const res403 = await fetch(`${ctx.baseUrl}/api/keys/exchange`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({
        label: 'Blocked Server Test',
        authType: 'KEY_PAIR',
        apiKey: 'AK_ALICE_TEST_KEY_1234',
        secretKey: seedBase64Url,
        verifyFirst: true,
      }),
    });
    expect(res403.status).toBe(400);
    const json403 = await res403.json();
    expect(json403.error).toContain('HTTP 403');
    expect(json403.error).not.toContain('<html>');
    expect(json403.error).not.toContain(seedBase64Url);

    // Simulate InvalidSignature response
    setNobitexFetchForTest(async () => {
      return new Response(
        JSON.stringify({ status: 'failed', code: 'InvalidSignature', detail: 'Invalid signature' }),
        { status: 401, headers: { 'Content-Type': 'application/json' } }
      );
    });

    const resSig = await fetch(`${ctx.baseUrl}/api/keys/exchange`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-alice',
      },
      body: JSON.stringify({
        label: 'Bad Sig Test',
        authType: 'KEY_PAIR',
        apiKey: 'AK_ALICE_TEST_KEY_1234',
        secretKey: seedBase64Url,
        verifyFirst: true,
      }),
    });
    expect(resSig.status).toBe(400);
    const jsonSig = await resSig.json();
    expect(jsonSig.error).toContain('Invalid Signature');

    // Verify logger redacts Nobitex-Key and Nobitex-Signature
    const redacted = redactSensitiveText(
      'Headers: Nobitex-Key: AK_SECRET_12345 Nobitex-Signature=sig_abc_xyz_999'
    );
    expect(redacted).not.toContain('AK_SECRET_12345');
    expect(redacted).not.toContain('sig_abc_xyz_999');
  });
});
