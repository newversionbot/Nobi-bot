import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { activateUserProSubscription } from '../server/billingVault.ts';
import {
  getPaperOrders,
  getUserBots,
  runAllActiveBotsCycle,
} from '../server/botEngine.ts';
import {
  startIsolatedTestServer,
  TEST_USERS,
  type TestServerContext,
} from './helpers/testHarness.ts';

describe('Fixed-Price Target Auto-Trader (Buy/Sell Cycle & Multi-Tenant Guards)', () => {
  let ctx: TestServerContext;

  beforeEach(async () => {
    ctx = await startIsolatedTestServer();
    await activateUserProSubscription(
      {
        userId: TEST_USERS['token-alice'].uid,
        email: TEST_USERS['token-alice'].email,
        displayName: TEST_USERS['token-alice'].displayName,
        paymentMethod: 'ADMIN_GRANT',
        days: 30,
      },
      'test-setup@system.local'
    );
    await activateUserProSubscription(
      {
        userId: TEST_USERS['token-bob'].uid,
        email: TEST_USERS['token-bob'].email,
        displayName: TEST_USERS['token-bob'].displayName,
        paymentMethod: 'ADMIN_GRANT',
        days: 30,
      },
      'test-setup@system.local'
    );
  }, 30_000);

  afterEach(async () => {
    await ctx.close();
  });

  it('creates a fixed-price bot without indicators/SL/TP, enforces live confirmation, and validates buy < sell', async () => {
    const aliceHeaders = {
      'Content-Type': 'application/json',
      Authorization: 'Bearer token-alice',
    };

    // Invalid targets (sell <= buy) must be rejected
    const badRes = await fetch(`${ctx.baseUrl}/api/bots`, {
      method: 'POST',
      headers: aliceHeaders,
      body: JSON.stringify({
        name: 'Bad Targets',
        strategyKind: 'FIXED_PRICE',
        targetBuyPrice: 60000,
        targetSellPrice: 59000,
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        mode: 'paper',
        status: 'PAUSED',
        orderAmount: 200,
      }),
    });
    expect(badRes.status).toBe(400);

    // Live creation without confirmLive must be rejected
    const liveDeniedRes = await fetch(`${ctx.baseUrl}/api/bots`, {
      method: 'POST',
      headers: aliceHeaders,
      body: JSON.stringify({
        name: 'Live Fixed Guard',
        strategyKind: 'FIXED_PRICE',
        targetBuyPrice: 55000,
        targetSellPrice: 58000,
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        mode: 'live',
        status: 'PAUSED',
        orderAmount: 200,
      }),
    });
    expect(liveDeniedRes.status).toBe(400);
    const liveDeniedJson = (await liveDeniedRes.json()) as { code?: string };
    expect(liveDeniedJson.code).toBe('LIVE_CONFIRMATION_REQUIRED');

    // Valid simple fixed-price bot without SL/TP or technical indicators
    const createRes = await fetch(`${ctx.baseUrl}/api/bots`, {
      method: 'POST',
      headers: aliceHeaders,
      body: JSON.stringify({
        name: 'Simple Price Cycle BTC',
        strategyKind: 'FIXED_PRICE',
        targetBuyPrice: 58000,
        targetSellPrice: 62000,
        repeatCycle: true,
        pollIntervalSeconds: 3,
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        timeframe: '1m',
        mode: 'paper',
        status: 'PAUSED',
        orderAmount: 500,
        stopLossPercent: 0,
        takeProfitPercent: 0,
      }),
    });
    expect(createRes.status).toBe(200);
    const created = (await createRes.json()) as {
      id: string;
      strategyKind: string;
      targetBuyPrice: number;
      targetSellPrice: number;
      repeatCycle: boolean;
      pollIntervalSeconds: number;
      stopLossPercent: number;
      takeProfitPercent: number;
    };
    expect(created.strategyKind).toBe('FIXED_PRICE');
    expect(created.targetBuyPrice).toBe(58000);
    expect(created.targetSellPrice).toBe(62000);
    expect(created.repeatCycle).toBe(true);
    expect(created.pollIntervalSeconds).toBe(3);
    expect(created.stopLossPercent).toBe(0);
    expect(created.takeProfitPercent).toBe(0);

    // Owner can edit target prices; another user (Bob) cannot
    const bobPatchRes = await fetch(`${ctx.baseUrl}/api/bots/${created.id}/fixed-targets`, {
      method: 'PATCH',
      headers: {
        'Content-Type': 'application/json',
        Authorization: 'Bearer token-bob',
      },
      body: JSON.stringify({
        targetBuyPrice: 57000,
        targetSellPrice: 63000,
      }),
    });
    expect(bobPatchRes.status).toBe(400);

    const alicePatchRes = await fetch(`${ctx.baseUrl}/api/bots/${created.id}/fixed-targets`, {
      method: 'PATCH',
      headers: aliceHeaders,
      body: JSON.stringify({
        targetBuyPrice: 57500,
        targetSellPrice: 62500,
        pollIntervalSeconds: 4,
      }),
    });
    expect(alicePatchRes.status).toBe(200);
    const patched = (await alicePatchRes.json()) as {
      targetBuyPrice: number;
      targetSellPrice: number;
      pollIntervalSeconds: number;
    };
    expect(patched.targetBuyPrice).toBe(57500);
    expect(patched.targetSellPrice).toBe(62500);
    expect(patched.pollIntervalSeconds).toBe(4);
  });

  it('executes multiple consecutive Buy -> Sell cycles automatically when repeatCycle is true', async () => {
    const aliceUid = TEST_USERS['token-alice'].uid;
    const aliceHeaders = {
      'Content-Type': 'application/json',
      Authorization: 'Bearer token-alice',
    };

    // Start with market price ABOVE target buy price -> should NOT buy yet
    ctx.nobitex.btcPriceUsdt = 60_000;

    const createRes = await fetch(`${ctx.baseUrl}/api/bots`, {
      method: 'POST',
      headers: aliceHeaders,
      body: JSON.stringify({
        name: 'Repeating Cycle Bot',
        strategyKind: 'FIXED_PRICE',
        targetBuyPrice: 58_000,
        targetSellPrice: 61_000,
        repeatCycle: true,
        pollIntervalSeconds: 3,
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        mode: 'paper',
        status: 'RUNNING',
        orderAmount: 500,
      }),
    });
    expect(createRes.status).toBe(200);
    const bot = (await createRes.json()) as { id: string };

    // 1. Price at 60,000 -> wait
    await runAllActiveBotsCycle('worker-test');
    let [current] = await getUserBots(aliceUid);
    expect(current.activePosition).toBeNull();
    expect(current.stats.totalTrades).toBe(0);

    // 2. Price drops to 57,500 <= 58,000 -> Cycle #1 BUY executes immediately
    ctx.nobitex.btcPriceUsdt = 57_500;
    await runAllActiveBotsCycle('worker-test');
    [current] = await getUserBots(aliceUid);
    expect(current.activePosition).not.toBeNull();
    expect(current.activePosition?.entryPrice).toBe(57_500);
    expect(current.status).toBe('RUNNING');

    // 3. Price rises to 61,500 >= 61,000 -> Cycle #1 SELL executes immediately, stays RUNNING for Cycle #2
    ctx.nobitex.btcPriceUsdt = 61_500;
    await runAllActiveBotsCycle('worker-test');
    [current] = await getUserBots(aliceUid);
    expect(current.activePosition).toBeNull();
    expect(current.stats.totalTrades).toBe(1);
    expect(current.stats.winningTrades).toBe(1);
    expect(current.stats.realizedPnl).toBeGreaterThan(0);
    expect(current.status).toBe('RUNNING');

    // 4. Price dips back to 57,800 <= 58,000 within the SAME minute -> Cycle #2 BUY executes cleanly!
    ctx.nobitex.btcPriceUsdt = 57_800;
    await runAllActiveBotsCycle('worker-test');
    [current] = await getUserBots(aliceUid);
    expect(current.activePosition).not.toBeNull();
    expect(current.activePosition?.entryPrice).toBe(57_800);

    // 5. Price rebounds to 62,000 -> Cycle #2 SELL executes cleanly!
    ctx.nobitex.btcPriceUsdt = 62_000;
    await runAllActiveBotsCycle('worker-test');
    [current] = await getUserBots(aliceUid);
    expect(current.activePosition).toBeNull();
    expect(current.stats.totalTrades).toBe(2);
    expect(current.stats.winningTrades).toBe(2);
    expect(current.status).toBe('RUNNING');

    const orders = (await getPaperOrders(aliceUid)).filter((o) => o.botId === bot.id);
    expect(orders.filter((o) => o.side === 'BUY')).toHaveLength(2);
    expect(orders.filter((o) => o.side === 'SELL')).toHaveLength(2);
  });

  it('auto-pauses a fixed-price bot after completing a single cycle when repeatCycle is false', async () => {
    const aliceUid = TEST_USERS['token-alice'].uid;
    const aliceHeaders = {
      'Content-Type': 'application/json',
      Authorization: 'Bearer token-alice',
    };

    ctx.nobitex.btcPriceUsdt = 57_000;
    const createRes = await fetch(`${ctx.baseUrl}/api/bots`, {
      method: 'POST',
      headers: aliceHeaders,
      body: JSON.stringify({
        name: 'Single Shot Fixed Bot',
        strategyKind: 'FIXED_PRICE',
        targetBuyPrice: 58_000,
        targetSellPrice: 60_500,
        repeatCycle: false,
        pollIntervalSeconds: 3,
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        mode: 'paper',
        status: 'RUNNING',
        orderAmount: 400,
      }),
    });
    expect(createRes.status).toBe(200);

    // Cycle executes BUY
    await runAllActiveBotsCycle('worker-test');
    let [current] = await getUserBots(aliceUid);
    expect(current.activePosition).not.toBeNull();

    // Price reaches sell target -> SELL and PAUSE
    ctx.nobitex.btcPriceUsdt = 60_600;
    await runAllActiveBotsCycle('worker-test');
    [current] = await getUserBots(aliceUid);
    expect(current.activePosition).toBeNull();
    expect(current.stats.totalTrades).toBe(1);
    expect(current.status).toBe('PAUSED');
  });
});
