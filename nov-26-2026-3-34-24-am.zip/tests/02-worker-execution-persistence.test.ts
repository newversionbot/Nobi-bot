import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { eq } from 'drizzle-orm';
import {
  acquireWorkerLock,
  closeDatabase,
  getDb,
  initDatabase,
  releaseWorkerLock,
} from '../server/db/index.ts';
import {
  createBot,
  evaluateSingleBot,
  getPaperBalances,
  getPaperOrders,
  getUserBots,
  placePaperOrder,
  runAllActiveBotsCycle,
} from '../server/botEngine.ts';
import { placeNobitexLiveOrder } from '../server/nobitexClient.ts';
import { saveUserExchangeCredential } from '../server/securityVault.ts';
import * as schema from '../src/db/schema.ts';
import {
  startIsolatedTestServer,
  TEST_USERS,
  type TestServerContext,
} from './helpers/testHarness.ts';

function buildOversoldPrices(count = 60): number[] {
  // Steady decline from 65000 down to ~50000 triggers RSI_OVERSOLD (< 35)
  const arr: number[] = [];
  let px = 65000;
  for (let i = 0; i < count; i++) {
    px = Math.max(48000, px - (i > 35 ? 450 : 120));
    arr.push(Number(px.toFixed(2)));
  }
  return arr;
}

describe('Worker Locks, Idempotency, Paper Trading Math, Persistence, and Nobitex Resilience', () => {
  let ctx: TestServerContext;

  beforeEach(async () => {
    ctx = await startIsolatedTestServer();
  });

  afterEach(async () => {
    await ctx.close();
  });

  it('prevents concurrent execution via DB lease lock and prevents duplicate candle entries via idempotencyKey', async () => {
    const lockA = await acquireWorkerLock('test_cycle_lock', 'worker-A', 30_000);
    const lockB = await acquireWorkerLock('test_cycle_lock', 'worker-B', 30_000);
    expect(lockA).toBe(true);
    expect(lockB).toBe(false);

    await releaseWorkerLock('test_cycle_lock', 'worker-A');
    const lockBAfterRelease = await acquireWorkerLock('test_cycle_lock', 'worker-B', 30_000);
    expect(lockBAfterRelease).toBe(true);
    await releaseWorkerLock('test_cycle_lock', 'worker-B');

    // Configure oversold candles so bot wants to enter a trade on the latest candle
    const prices = buildOversoldPrices(60);
    ctx.nobitex.ohlcClosePrices = prices;
    ctx.nobitex.btcPriceUsdt = prices[prices.length - 1];

    const uid = TEST_USERS['token-alice'].uid;
    const bot = await createBot(uid, {
      name: 'Idempotent RSI Bot',
      baseAsset: 'BTC',
      quoteCurrency: 'USDT',
      symbol: 'BTCUSDT',
      timeframe: '15m',
      mode: 'paper',
      status: 'RUNNING',
      orderAmount: 500,
      stopLossPercent: 3,
      takeProfitPercent: 6,
      trailingStopEnabled: false,
      trailingStopPercent: 1.5,
      cooldownMinutes: 0, // Zero cooldown to specifically test candle openTime idempotency
      logicOperator: 'AND',
      entryRules: [
        {
          id: 'rsi-low',
          type: 'RSI_OVERSOLD',
          action: 'BUY',
          enabled: true,
          params: { period: 14, threshold: 45 },
        },
      ],
      exitRules: [],
    });

    // Run cycle twice on the exact same candle
    const c1 = await runAllActiveBotsCycle('worker-1');
    expect(c1.acquired).toBe(true);
    expect(c1.evaluatedBots).toBe(1);

    const botsAfterFirst = await getUserBots(uid);
    expect(botsAfterFirst[0].activePosition).not.toBeNull();

    const ordersAfterFirst = await getPaperOrders(uid);
    const botBuys = ordersAfterFirst.filter((o) => o.botId === bot.id && o.side === 'BUY');
    expect(botBuys).toHaveLength(1);

    // Even if activePosition is manually cleared while the same candle openTime remains, idempotencyKey stops duplicate BUY
    const db = getDb();
    await db
      .update(schema.tradingBots)
      .set({ activePositionJson: null })
      .where(eq(schema.tradingBots.id, bot.id));

    await evaluateSingleBot({ ...botsAfterFirst[0], activePosition: null });
    const ordersAfterSecond = await getPaperOrders(uid);
    expect(ordersAfterSecond.filter((o) => o.botId === bot.id && o.side === 'BUY')).toHaveLength(1);
  });

  it('executes paper BUY, Trailing Stop & Take Profit with exact 0.25% Nobitex fees and ledger rows', async () => {
    const uid = TEST_USERS['token-alice'].uid;
    const buyOrder = await placePaperOrder(uid, {
      baseAsset: 'BTC',
      quoteCurrency: 'USDT',
      side: 'BUY',
      type: 'MARKET',
      quantity: 0.1,
      price: 10000,
      source: 'MANUAL',
    });

    expect(buyOrder.status).toBe('FILLED');
    // Balance should have USDT = 5000 - 1000 = 4000; BTC = 0.1 * (1 - 0.0025) = 0.09975
    const bals = await getPaperBalances(uid, [], 70_000);
    const usdtBal = bals.find((b) => b.asset === 'USDT');
    const btcBal = bals.find((b) => b.asset === 'BTC');
    expect(usdtBal?.free).toBeCloseTo(4000, 4);
    expect(btcBal?.free).toBeCloseTo(0.09975, 6);

    // Check bot SL/TP execution + realized PnL tracking
    const prices = buildOversoldPrices(60);
    ctx.nobitex.ohlcClosePrices = prices;
    ctx.nobitex.btcPriceUsdt = prices[prices.length - 1];

    const tpBot = await createBot(uid, {
      name: 'TP Test Bot',
      baseAsset: 'BTC',
      quoteCurrency: 'USDT',
      symbol: 'BTCUSDT',
      timeframe: '15m',
      mode: 'paper',
      status: 'RUNNING',
      orderAmount: 1000,
      stopLossPercent: 3,
      takeProfitPercent: 5,
      trailingStopEnabled: true,
      trailingStopPercent: 2,
      cooldownMinutes: 15,
      logicOperator: 'AND',
      entryRules: [
        {
          id: 'rsi-entry',
          type: 'RSI_OVERSOLD',
          action: 'BUY',
          enabled: true,
          params: { period: 14, threshold: 45 },
        },
      ],
      exitRules: [],
    });

    // Entry on candle 59
    const entered = await evaluateSingleBot(tpBot);
    expect(entered.activePosition).not.toBeNull();
    const entryPrice = entered.activePosition!.entryPrice;

    // Advance to a new candle and pump price +10% above Take-Profit (+5%)
    const newClose = entryPrice * 1.1;
    ctx.nobitex.ohlcClosePrices = [...prices, newClose];
    ctx.nobitex.btcPriceUsdt = newClose;

    const exited = await evaluateSingleBot(entered);
    expect(exited.activePosition).toBeNull();
    expect(exited.stats.totalTrades).toBe(1);
    expect(exited.stats.winningTrades).toBe(1);
    expect(exited.stats.realizedPnl).toBeGreaterThan(0);

    const db = getDb();
    const tradeRows = await db.select().from(schema.trades);
    expect(tradeRows.length).toBeGreaterThanOrEqual(3); // manual buy + bot buy + bot sell
  });

  it('persists state across DB restart using a durable disk PGlite directory', async () => {
    // Shut down memory server DB, open durable PGlite dir, write data, close, and reopen
    await ctx.close();
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'ali-trader-persist-'));

    try {
      await initDatabase({ pgliteDataDir: tempDir, forceReset: true });
      const uid = 'persist-user-001';
      await createBot(uid, {
        name: 'Durable Bot',
        baseAsset: 'BTC',
        quoteCurrency: 'IRT',
        symbol: 'BTCIRT',
        timeframe: '1h',
        mode: 'paper',
        status: 'PAUSED',
        orderAmount: 15_000_000,
        stopLossPercent: 2.5,
        takeProfitPercent: 5,
        trailingStopEnabled: false,
        trailingStopPercent: 1.5,
        cooldownMinutes: 15,
        logicOperator: 'AND',
        entryRules: [{ id: 'e1', type: 'RSI_OVERSOLD', action: 'BUY', enabled: true, params: { period: 14, threshold: 35 } }],
        exitRules: [],
      });
      await placePaperOrder(uid, {
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        side: 'BUY',
        type: 'MARKET',
        quantity: 0.02,
        price: 50000,
        source: 'MANUAL',
      });
      await closeDatabase();

      // Re-open in fresh database lifecycle (simulating process restart)
      await initDatabase({ pgliteDataDir: tempDir, forceReset: true });
      const botsAfterRestart = await getUserBots(uid);
      expect(botsAfterRestart).toHaveLength(1);
      expect(botsAfterRestart[0].name).toBe('Durable Bot');

      const balancesAfterRestart = await getPaperBalances(uid, [], 70_000);
      const usdtAfterRestart = balancesAfterRestart.find((b) => b.asset === 'USDT');
      expect(usdtAfterRestart?.free).toBeCloseTo(4000, 4);
      await closeDatabase();
    } finally {
      fs.rmSync(tempDir, { recursive: true, force: true });
      // Re-initialize in-memory server so afterEach ctx.close succeeds cleanly
      ctx = await startIsolatedTestServer();
    }
  }, 20_000);

  it('retries Nobitex HTTP 429, reconciles timed-out live orders without duplicate send, and auto-pauses live bot on NobitexAuthError', async () => {
    // 1. Test 429 retry + timeout reconciliation
    ctx.nobitex.rateLimit429Count = 1;
    ctx.nobitex.simulateOrderAddTimeoutThenReconcile = true;
    const reconciled = await placeNobitexLiveOrder(
      {
        baseAsset: 'BTC',
        quoteCurrency: 'USDT',
        side: 'BUY',
        type: 'MARKET',
        quantity: 0.01,
        estimatedPrice: 60_000,
      },
      { apiToken: 'MOCK_TOKEN_123' }
    );
    expect(reconciled.orderId).toBe('778899');
    expect(ctx.nobitex.calls.some((c) => c.url.includes('/market/orders/list'))).toBe(true);

    // 2. Test NobitexAuthError auto-pauses failing live bot
    ctx.nobitex.simulateOrderAddTimeoutThenReconcile = false;
    const uid = TEST_USERS['token-alice'].uid;
    await saveUserExchangeCredential(uid, 'Alice Live', 'INVALID_OR_REVOKED_TOKEN', false);
    const prices = buildOversoldPrices(60);
    ctx.nobitex.ohlcClosePrices = prices;
    ctx.nobitex.btcPriceUsdt = prices[prices.length - 1];
    ctx.nobitex.failWalletWith401 = true;

    const liveBot = await createBot(uid, {
      name: 'Live Auto-Pause Bot',
      baseAsset: 'BTC',
      quoteCurrency: 'USDT',
      symbol: 'BTCUSDT',
      timeframe: '15m',
      mode: 'live',
      status: 'RUNNING',
      orderAmount: 600,
      stopLossPercent: 3,
      takeProfitPercent: 6,
      trailingStopEnabled: false,
      trailingStopPercent: 1.5,
      cooldownMinutes: 0,
      logicOperator: 'AND',
      entryRules: [
        {
          id: 'rsi-e',
          type: 'RSI_OVERSOLD',
          action: 'BUY',
          enabled: true,
          params: { period: 14, threshold: 45 },
        },
      ],
      exitRules: [],
    });

    const evaluated = await evaluateSingleBot(liveBot);
    expect(evaluated.status).toBe('PAUSED');
    expect(evaluated.lastSignalSummary).toContain('توقف خودکار');
  });
});
