import type { AddressInfo } from 'node:net';
import { createApp } from '../../server.ts';
import { initDatabase, closeDatabase } from '../../server/db/index.ts';
import { setFirebaseVerifierForTest, type AuthenticatedUser } from '../../server/securityVault.ts';
import { setNobitexFetchForTest } from '../../server/nobitexClient.ts';
import {
  clearTelegramDedupeForTest,
  setTelegramFetchForTest,
} from '../../server/telegramClient.ts';
import { setBillingFetchForTest } from '../../server/billingVault.ts';

export const TEST_USERS: Record<string, AuthenticatedUser> = {
  'token-alice': {
    uid: 'user-alice-001',
    email: 'alice@example.com',
    displayName: 'آلیس معامله‌گر',
    emailVerified: true,
  },
  'token-bob': {
    uid: 'user-bob-002',
    email: 'bob@example.com',
    displayName: 'باب معامله‌گر',
    emailVerified: true,
  },
  'token-admin': {
    uid: 'user-admin-000',
    email: 'shivamdonyam@gmail.com',
    displayName: 'مدیر کل',
    emailVerified: true,
  },
};

export interface MockNobitexRecorder {
  calls: Array<{
    url: string;
    method: string;
    authHeader: string;
    nobitexKey?: string;
    nobitexTimestamp?: string;
    nobitexSignature?: string;
    userAgent?: string;
    body?: string;
  }>;
  btcPriceUsdt: number;
  usdtTomanRate: number;
  ohlcClosePrices: number[];
  failWalletWith401?: boolean;
  rateLimit429Count?: number;
  simulateOrderAddTimeoutThenReconcile?: boolean;
}

export function installMockNobitexFetch(state: Partial<MockNobitexRecorder> = {}): MockNobitexRecorder {
  const recorder: MockNobitexRecorder = {
    calls: [],
    btcPriceUsdt: state.btcPriceUsdt ?? 60_000,
    usdtTomanRate: state.usdtTomanRate ?? 70_000,
    ohlcClosePrices: state.ohlcClosePrices ?? [],
    failWalletWith401: state.failWalletWith401 ?? false,
    rateLimit429Count: state.rateLimit429Count ?? 0,
    simulateOrderAddTimeoutThenReconcile: state.simulateOrderAddTimeoutThenReconcile ?? false,
  };

  setNobitexFetchForTest(async (input, init) => {
    const url = typeof input === 'string' ? input : input.toString();
    const method = (init?.method || 'GET').toUpperCase();
    const headersObj = (init?.headers || {}) as Record<string, string>;
    const authHeader = headersObj.Authorization || headersObj.authorization || '';
    const nobitexKey = headersObj['Nobitex-Key'] || headersObj['nobitex-key'];
    const nobitexTimestamp = headersObj['Nobitex-Timestamp'] || headersObj['nobitex-timestamp'];
    const nobitexSignature = headersObj['Nobitex-Signature'] || headersObj['nobitex-signature'];
    const userAgent = headersObj['User-Agent'] || headersObj['user-agent'];
    const body = typeof init?.body === 'string' ? init.body : undefined;

    recorder.calls.push({
      url,
      method,
      authHeader,
      nobitexKey,
      nobitexTimestamp,
      nobitexSignature,
      userAgent,
      body,
    });

    if (recorder.rateLimit429Count && recorder.rateLimit429Count > 0) {
      recorder.rateLimit429Count -= 1;
      return new Response(JSON.stringify({ status: 'failed', message: 'rate limited' }), {
        status: 429,
        headers: { 'Content-Type': 'application/json', 'retry-after': '0' },
      });
    }

    if (url.includes('/market/stats')) {
      const btcIrt = recorder.btcPriceUsdt * recorder.usdtTomanRate;
      if (url.includes('dstCurrency=rls')) {
        return new Response(
          JSON.stringify({
            stats: {
              'btc-rls': {
                isClosed: false,
                latest: String(btcIrt * 10),
                bestBuy: String(btcIrt * 10),
                bestSell: String(btcIrt * 10),
                dayChange: '2.5',
                volumeSrc: '10',
                volumeDst: String(btcIrt * 100),
              },
              'usdt-rls': {
                isClosed: false,
                latest: String(recorder.usdtTomanRate * 10),
                bestBuy: String(recorder.usdtTomanRate * 10),
                bestSell: String(recorder.usdtTomanRate * 10),
                dayChange: '0.2',
                volumeSrc: '1000',
                volumeDst: String(recorder.usdtTomanRate * 10000),
              },
            },
          }),
          { status: 200, headers: { 'Content-Type': 'application/json' } }
        );
      }
      return new Response(
        JSON.stringify({
          stats: {
            'btc-usdt': {
              isClosed: false,
              latest: String(recorder.btcPriceUsdt),
              bestBuy: String(recorder.btcPriceUsdt),
              bestSell: String(recorder.btcPriceUsdt),
              dayChange: '2.5',
              volumeSrc: '12',
              volumeDst: String(recorder.btcPriceUsdt * 12),
            },
          },
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }

    if (url.includes('/market/udf/history')) {
      const count = Math.max(60, recorder.ohlcClosePrices.length);
      const baseSec = 1_740_000_000;
      const t: number[] = [];
      const o: number[] = [];
      const h: number[] = [];
      const l: number[] = [];
      const c: number[] = [];
      const v: number[] = [];

      const defaultPrice = url.includes('IRT')
        ? recorder.btcPriceUsdt * recorder.usdtTomanRate * 10
        : recorder.btcPriceUsdt;

      for (let i = 0; i < count; i++) {
        t.push(baseSec + i * 900);
        const px =
          recorder.ohlcClosePrices[i] !== undefined
            ? recorder.ohlcClosePrices[i]
            : defaultPrice;
        o.push(px);
        h.push(px * 1.005);
        l.push(px * 0.995);
        c.push(px);
        v.push(20);
      }
      return new Response(
        JSON.stringify({ s: 'ok', t, o, h, l, c, v }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }

    if (url.includes('/users/wallets/list')) {
      if (recorder.failWalletWith401) {
        return new Response(JSON.stringify({ status: 'failed', detail: 'Invalid token' }), {
          status: 401,
          headers: { 'Content-Type': 'application/json' },
        });
      }
      return new Response(
        JSON.stringify({
          status: 'ok',
          wallets: [
            { currency: 'rls', balance: '9000000000', blockedBalance: '0' },
            { currency: 'usdt', balance: '10000', blockedBalance: '0' },
            { currency: 'btc', balance: '1.5', blockedBalance: '0' },
          ],
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }

    if (url.includes('/market/orders/add')) {
      if (recorder.simulateOrderAddTimeoutThenReconcile) {
        throw new Error('Request timeout while sending order');
      }
      const parsedBody = body ? JSON.parse(body) : {};
      return new Response(
        JSON.stringify({
          status: 'ok',
          order: {
            id: 991122,
            type: parsedBody.type || 'buy',
            execution: parsedBody.execution || 'market',
            srcCurrency: parsedBody.srcCurrency || 'btc',
            dstCurrency: parsedBody.dstCurrency || 'usdt',
            price: parsedBody.price || String(recorder.btcPriceUsdt),
            amount: parsedBody.amount || '0.01',
            matchedAmount: parsedBody.amount || '0.01',
            status: 'Done',
          },
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }

    if (url.includes('/market/orders/list')) {
      return new Response(
        JSON.stringify({
          status: 'ok',
          orders: recorder.simulateOrderAddTimeoutThenReconcile
            ? [
                {
                  id: 778899,
                  type: 'buy',
                  execution: 'limit',
                  srcCurrency: 'btc',
                  dstCurrency: 'usdt',
                  price: String(recorder.btcPriceUsdt),
                  amount: '0.01',
                  matchedAmount: '0.01',
                  status: 'Done',
                  created_at: new Date().toISOString(),
                },
              ]
            : [],
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }

    return new Response(JSON.stringify({ status: 'ok' }), {
      status: 200,
      headers: { 'Content-Type': 'application/json' },
    });
  });

  return recorder;
}

export interface MockTelegramRecorder {
  calls: Array<{ botToken: string; method: string; body: Record<string, unknown> }>;
  rateLimit429Count: number;
}

export function installMockTelegramFetch(): MockTelegramRecorder {
  const recorder: MockTelegramRecorder = { calls: [], rateLimit429Count: 0 };
  clearTelegramDedupeForTest();
  setTelegramFetchForTest(async (input, init) => {
    const url = typeof input === 'string' ? input : input.toString();
    const match = url.match(/\/bot([^/]+)\/([a-zA-Z0-9_]+)/);
    const botToken = match?.[1] || 'unknown';
    const method = match?.[2] || 'unknown';
    const body = typeof init?.body === 'string' ? JSON.parse(init.body) : {};

    if (method === 'sendMessage' && recorder.rateLimit429Count > 0) {
      recorder.rateLimit429Count -= 1;
      return new Response(
        JSON.stringify({
          ok: false,
          error_code: 429,
          description: 'Too Many Requests',
          parameters: { retry_after: 0 },
        }),
        { status: 429, headers: { 'Content-Type': 'application/json' } }
      );
    }

    recorder.calls.push({ botToken, method, body });

    if (method === 'getMe') {
      return new Response(
        JSON.stringify({
          ok: true,
          result: {
            id: 123456,
            is_bot: true,
            first_name: `Bot_${botToken.slice(0, 4)}`,
            username: `bot_${botToken.slice(0, 4)}`,
          },
        }),
        { status: 200, headers: { 'Content-Type': 'application/json' } }
      );
    }

    return new Response(
      JSON.stringify({ ok: true, result: { message_id: recorder.calls.length } }),
      { status: 200, headers: { 'Content-Type': 'application/json' } }
    );
  });
  return recorder;
}

export interface TestServerContext {
  baseUrl: string;
  nobitex: MockNobitexRecorder;
  telegram: MockTelegramRecorder;
  close: () => Promise<void>;
}

export async function startIsolatedTestServer(options?: {
  generalRateLimitMax?: number;
  tradeRateLimitMax?: number;
  pgliteDataDir?: string;
}): Promise<TestServerContext> {
  process.env.NODE_ENV = 'test';
  await initDatabase({
    pgliteDataDir: options?.pgliteDataDir ?? 'memory://',
    forceReset: true,
  });

  setFirebaseVerifierForTest(async (token: string) => TEST_USERS[token] || null);
  const nobitex = installMockNobitexFetch();
  const telegram = installMockTelegramFetch();

  const app = await createApp({
    enableViteOrStatic: false,
    startWorker: false,
    generalRateLimitMax: options?.generalRateLimitMax ?? 5000,
    tradeRateLimitMax: options?.tradeRateLimitMax ?? 1000,
  });

  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });
  const addr = server.address() as AddressInfo;
  const baseUrl = `http://127.0.0.1:${addr.port}`;

  return {
    baseUrl,
    nobitex,
    telegram,
    close: async () => {
      setFirebaseVerifierForTest(null);
      setNobitexFetchForTest(null);
      setTelegramFetchForTest(null);
      setBillingFetchForTest(null);
      await new Promise<void>((resolve) => server.close(() => resolve()));
      await closeDatabase();
    },
  };
}
