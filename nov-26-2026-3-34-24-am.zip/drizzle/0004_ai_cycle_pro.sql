-- Idempotent migration for AI Cycle Pro | ربات چرخه هوشمند
-- Tables: ai_cycle_pro_bots, ai_cycle_pro_cycles, ai_cycle_pro_logs

CREATE TABLE IF NOT EXISTS ai_cycle_pro_bots (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  name TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  symbol TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'paper',
  is_active BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'IDLE',
  capital_amount DOUBLE PRECISION NOT NULL,
  capital_usage_mode TEXT NOT NULL DEFAULT 'FULL',
  capital_portion_percent DOUBLE PRECISION NOT NULL DEFAULT 100,
  execution_confirmation_mode TEXT NOT NULL DEFAULT 'AUTO',
  auto_repeat_cycles BOOLEAN NOT NULL DEFAULT TRUE,
  stop_loss_percent DOUBLE PRECISION NOT NULL DEFAULT 3.0,
  max_daily_loss DOUBLE PRECISION NOT NULL DEFAULT 0,
  max_slippage_percent DOUBLE PRECISION NOT NULL DEFAULT 0.6,
  max_spread_percent DOUBLE PRECISION NOT NULL DEFAULT 2.5,
  min_target_net_profit_percent DOUBLE PRECISION NOT NULL DEFAULT 1.2,
  poll_interval_seconds INTEGER NOT NULL DEFAULT 15,
  fee_rate DOUBLE PRECISION NOT NULL DEFAULT 0.0025,
  notify_telegram BOOLEAN NOT NULL DEFAULT TRUE,
  active_position_json JSONB,
  pending_order_json JSONB,
  last_decision_json JSONB,
  daily_stats_json JSONB NOT NULL,
  stats_json JSONB NOT NULL,
  last_price DOUBLE PRECISION NOT NULL DEFAULT 0,
  last_status_reason TEXT NOT NULL DEFAULT '',
  last_error TEXT,
  last_checked_at BIGINT,
  started_at BIGINT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS ai_cycle_pro_bots_user_active_idx ON ai_cycle_pro_bots (user_id, is_active);

CREATE TABLE IF NOT EXISTS ai_cycle_pro_cycles (
  id TEXT PRIMARY KEY,
  bot_id TEXT NOT NULL REFERENCES ai_cycle_pro_bots(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  cycle_index INTEGER NOT NULL,
  symbol TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'paper',
  entry_amount_quote DOUBLE PRECISION NOT NULL,
  actual_buy_avg_price DOUBLE PRECISION NOT NULL,
  bought_qty DOUBLE PRECISION NOT NULL,
  buy_fee_quote DOUBLE PRECISION NOT NULL,
  total_buy_cost_quote DOUBLE PRECISION NOT NULL,
  actual_sell_avg_price DOUBLE PRECISION NOT NULL,
  sold_qty DOUBLE PRECISION NOT NULL,
  gross_sell_proceeds_quote DOUBLE PRECISION NOT NULL,
  sell_fee_quote DOUBLE PRECISION NOT NULL,
  final_net_profit_quote DOUBLE PRECISION NOT NULL,
  target_net_profit_percent DOUBLE PRECISION NOT NULL,
  slippage_percent DOUBLE PRECISION NOT NULL DEFAULT 0,
  exit_reason TEXT NOT NULL,
  ai_entry_summary_fa TEXT NOT NULL DEFAULT '',
  ai_exit_summary_fa TEXT NOT NULL DEFAULT '',
  started_at BIGINT NOT NULL,
  completed_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS ai_cycle_pro_cycles_user_completed_idx ON ai_cycle_pro_cycles (user_id, completed_at DESC);

CREATE TABLE IF NOT EXISTS ai_cycle_pro_logs (
  id TEXT PRIMARY KEY,
  bot_id TEXT NOT NULL REFERENCES ai_cycle_pro_bots(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  cycle_index INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  event TEXT NOT NULL,
  price DOUBLE PRECISION NOT NULL DEFAULT 0,
  net_profit_quote DOUBLE PRECISION,
  message TEXT NOT NULL,
  timestamp BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS ai_cycle_pro_logs_user_ts_idx ON ai_cycle_pro_logs (user_id, timestamp DESC);
