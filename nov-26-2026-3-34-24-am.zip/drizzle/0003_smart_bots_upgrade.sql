-- Idempotent migration for AI NobiBot Smart Multi-Bot Upgrade
-- Tables: bot_risk_settings, grid_bots, dca_bots, pending_bot_confirmations, ai_manager_reports

CREATE TABLE IF NOT EXISTS bot_risk_settings (
  user_id TEXT PRIMARY KEY REFERENCES users(uid) ON DELETE CASCADE,
  total_bots_budget_irt DOUBLE PRECISION NOT NULL DEFAULT 100000000,
  total_bots_budget_usdt DOUBLE PRECISION NOT NULL DEFAULT 2000,
  max_per_bot_capital_irt DOUBLE PRECISION NOT NULL DEFAULT 35000000,
  max_per_bot_capital_usdt DOUBLE PRECISION NOT NULL DEFAULT 1500,
  max_daily_loss_irt DOUBLE PRECISION NOT NULL DEFAULT 5000000,
  max_daily_loss_usdt DOUBLE PRECISION NOT NULL DEFAULT 100,
  max_total_loss_irt DOUBLE PRECISION NOT NULL DEFAULT 20000000,
  max_total_loss_usdt DOUBLE PRECISION NOT NULL DEFAULT 400,
  enable_symbol_conflict_lock BOOLEAN NOT NULL DEFAULT TRUE,
  allow_ai_advisory_only BOOLEAN NOT NULL DEFAULT TRUE,
  kill_switch_active BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS grid_bots (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  name TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  symbol TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'paper',
  is_active BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'PAUSED',
  lower_price DOUBLE PRECISION NOT NULL,
  upper_price DOUBLE PRECISION NOT NULL,
  grid_levels INTEGER NOT NULL DEFAULT 8,
  step_mode TEXT NOT NULL DEFAULT 'ARITHMETIC',
  total_capital DOUBLE PRECISION NOT NULL,
  max_capital_involved DOUBLE PRECISION NOT NULL,
  stop_on_breakout BOOLEAN NOT NULL DEFAULT TRUE,
  alert_on_breakout BOOLEAN NOT NULL DEFAULT TRUE,
  fee_rate DOUBLE PRECISION NOT NULL DEFAULT 0.0025,
  estimated_slippage_percent DOUBLE PRECISION NOT NULL DEFAULT 0.15,
  execution_confirmation_mode TEXT NOT NULL DEFAULT 'AUTO',
  notify_telegram BOOLEAN NOT NULL DEFAULT TRUE,
  allocated_levels_json JSONB NOT NULL,
  stats_json JSONB NOT NULL,
  last_price DOUBLE PRECISION NOT NULL DEFAULT 0,
  last_status_reason TEXT NOT NULL DEFAULT '',
  last_error TEXT,
  last_checked_at BIGINT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS grid_bots_user_active_idx ON grid_bots (user_id, is_active);

CREATE TABLE IF NOT EXISTS dca_bots (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  name TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  symbol TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'paper',
  is_active BOOLEAN NOT NULL DEFAULT FALSE,
  status TEXT NOT NULL DEFAULT 'PAUSED',
  total_capital DOUBLE PRECISION NOT NULL,
  max_involved_capital DOUBLE PRECISION NOT NULL,
  stages_count INTEGER NOT NULL DEFAULT 5,
  step_unit TEXT NOT NULL DEFAULT 'PERCENT',
  step_value DOUBLE PRECISION NOT NULL DEFAULT 2.5,
  trigger_mode TEXT NOT NULL DEFAULT 'MARKET_DROP',
  interval_minutes INTEGER NOT NULL DEFAULT 60,
  pause_new_buys BOOLEAN NOT NULL DEFAULT FALSE,
  stop_loss_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  stop_loss_percent DOUBLE PRECISION NOT NULL DEFAULT 8,
  take_profit_enabled BOOLEAN NOT NULL DEFAULT TRUE,
  take_profit_percent DOUBLE PRECISION NOT NULL DEFAULT 6,
  trailing_tp_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  trailing_tp_activation_percent DOUBLE PRECISION NOT NULL DEFAULT 5,
  trailing_tp_callback_percent DOUBLE PRECISION NOT NULL DEFAULT 1.2,
  take_profit_targets_json JSONB NOT NULL,
  keep_runner_percent DOUBLE PRECISION NOT NULL DEFAULT 0,
  fee_rate DOUBLE PRECISION NOT NULL DEFAULT 0.0025,
  estimated_slippage_percent DOUBLE PRECISION NOT NULL DEFAULT 0.15,
  execution_confirmation_mode TEXT NOT NULL DEFAULT 'AUTO',
  notify_telegram BOOLEAN NOT NULL DEFAULT TRUE,
  state_json JSONB NOT NULL,
  stats_json JSONB NOT NULL,
  last_price DOUBLE PRECISION NOT NULL DEFAULT 0,
  last_status_reason TEXT NOT NULL DEFAULT '',
  last_error TEXT,
  last_checked_at BIGINT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS dca_bots_user_active_idx ON dca_bots (user_id, is_active);

CREATE TABLE IF NOT EXISTS pending_bot_confirmations (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  bot_id TEXT NOT NULL,
  bot_type TEXT NOT NULL,
  bot_name TEXT NOT NULL,
  symbol TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'paper',
  side TEXT NOT NULL,
  order_type TEXT NOT NULL DEFAULT 'MARKET',
  suggested_price DOUBLE PRECISION NOT NULL,
  quantity DOUBLE PRECISION NOT NULL,
  quote_amount DOUBLE PRECISION NOT NULL,
  estimated_fee_quote DOUBLE PRECISION NOT NULL,
  reason_fa TEXT NOT NULL,
  risk_summary_fa TEXT NOT NULL,
  meta_json JSONB,
  status TEXT NOT NULL DEFAULT 'PENDING',
  created_at BIGINT NOT NULL,
  expires_at BIGINT NOT NULL,
  resolved_at BIGINT
);
CREATE INDEX IF NOT EXISTS pending_bot_confirmations_user_status_idx ON pending_bot_confirmations (user_id, status, created_at DESC);

CREATE TABLE IF NOT EXISTS ai_manager_reports (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  report_json JSONB NOT NULL,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS ai_manager_reports_user_idx ON ai_manager_reports (user_id, created_at DESC);
