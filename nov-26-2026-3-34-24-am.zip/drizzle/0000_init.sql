-- ALI Trader Production PostgreSQL Schema Migration (0000_init)

CREATE TABLE IF NOT EXISTS _app_migrations (
  id TEXT PRIMARY KEY,
  applied_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  uid TEXT PRIMARY KEY,
  email TEXT NOT NULL DEFAULT '',
  display_name TEXT NOT NULL DEFAULT 'کاربر',
  is_banned BOOLEAN NOT NULL DEFAULT FALSE,
  ban_reason TEXT,
  admin_note TEXT,
  referral_code TEXT NOT NULL,
  referred_by_uid TEXT,
  referred_by_code TEXT,
  referred_at BIGINT,
  referral_bonus_days_earned INTEGER NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL,
  last_seen_at BIGINT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS users_referral_code_idx ON users (UPPER(referral_code));

CREATE TABLE IF NOT EXISTS exchange_credentials (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  label TEXT NOT NULL,
  masked_api_key TEXT NOT NULL,
  key_id TEXT NOT NULL DEFAULT 'v1',
  encrypted_token TEXT NOT NULL,
  iv TEXT NOT NULL,
  auth_tag TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  last_verified_at BIGINT,
  created_at BIGINT NOT NULL,
  revoked_at BIGINT
);
CREATE INDEX IF NOT EXISTS exchange_credentials_user_status_idx ON exchange_credentials (user_id, status);

CREATE TABLE IF NOT EXISTS telegram_configurations (
  user_id TEXT PRIMARY KEY REFERENCES users(uid) ON DELETE CASCADE,
  key_id TEXT NOT NULL DEFAULT 'v1',
  encrypted_bot_token TEXT NOT NULL,
  iv TEXT NOT NULL,
  auth_tag TEXT NOT NULL,
  masked_bot_token TEXT NOT NULL,
  bot_username TEXT NOT NULL DEFAULT '',
  bot_first_name TEXT NOT NULL DEFAULT '',
  chat_id TEXT NOT NULL,
  enabled BOOLEAN NOT NULL DEFAULT TRUE,
  send_price_alerts BOOLEAN NOT NULL DEFAULT TRUE,
  send_periodic_watchers BOOLEAN NOT NULL DEFAULT TRUE,
  send_trade_reports BOOLEAN NOT NULL DEFAULT TRUE,
  send_bot_trades BOOLEAN NOT NULL DEFAULT TRUE,
  send_bot_monitoring BOOLEAN NOT NULL DEFAULT TRUE,
  bot_monitor_mode TEXT NOT NULL DEFAULT 'EVENTS_AND_STATUS',
  bot_monitor_interval_minutes INTEGER NOT NULL DEFAULT 15,
  updated_at BIGINT NOT NULL,
  last_sent_at BIGINT,
  last_bot_monitor_sent_at BIGINT,
  last_error TEXT,
  recent_logs_json JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE TABLE IF NOT EXISTS trading_bots (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  name TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  symbol TEXT NOT NULL,
  timeframe TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'paper',
  status TEXT NOT NULL DEFAULT 'PAUSED',
  order_amount DOUBLE PRECISION NOT NULL,
  active_position_json JSONB,
  stats_json JSONB NOT NULL,
  last_checked_at BIGINT,
  last_signal_summary TEXT NOT NULL DEFAULT '',
  notify_telegram BOOLEAN NOT NULL DEFAULT TRUE,
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  next_retry_at BIGINT,
  last_error TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS trading_bots_user_idx ON trading_bots (user_id);
CREATE INDEX IF NOT EXISTS trading_bots_status_idx ON trading_bots (status);

CREATE TABLE IF NOT EXISTS bot_configurations (
  bot_id TEXT PRIMARY KEY REFERENCES trading_bots(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  stop_loss_percent DOUBLE PRECISION NOT NULL DEFAULT 2.5,
  take_profit_percent DOUBLE PRECISION NOT NULL DEFAULT 5.0,
  trailing_stop_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  trailing_stop_percent DOUBLE PRECISION NOT NULL DEFAULT 1.5,
  cooldown_minutes INTEGER NOT NULL DEFAULT 15,
  logic_operator TEXT NOT NULL DEFAULT 'AND',
  entry_rules_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  exit_rules_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  updated_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
  order_id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  bot_id TEXT,
  exchange_order_id TEXT,
  idempotency_key TEXT,
  symbol TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  side TEXT NOT NULL,
  type TEXT NOT NULL,
  price DOUBLE PRECISION NOT NULL,
  quantity DOUBLE PRECISION NOT NULL,
  executed_qty DOUBLE PRECISION NOT NULL DEFAULT 0,
  total_quote_amount DOUBLE PRECISION NOT NULL,
  fee_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  stop_loss_price DOUBLE PRECISION,
  take_profit_price DOUBLE PRECISION,
  mode TEXT NOT NULL,
  source TEXT NOT NULL,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS orders_user_created_idx ON orders (user_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS orders_idempotency_key_unique_idx ON orders (idempotency_key) WHERE idempotency_key IS NOT NULL AND idempotency_key <> '';

CREATE TABLE IF NOT EXISTS trades (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  order_id TEXT NOT NULL,
  bot_id TEXT,
  symbol TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  side TEXT NOT NULL,
  price DOUBLE PRECISION NOT NULL,
  quantity DOUBLE PRECISION NOT NULL,
  quote_amount DOUBLE PRECISION NOT NULL,
  fee_amount DOUBLE PRECISION NOT NULL DEFAULT 0,
  realized_pnl_quote DOUBLE PRECISION,
  mode TEXT NOT NULL,
  executed_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS trades_user_executed_idx ON trades (user_id, executed_at DESC);

CREATE TABLE IF NOT EXISTS trading_logs (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  bot_id TEXT NOT NULL,
  bot_name TEXT NOT NULL,
  symbol TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  event TEXT NOT NULL,
  price DOUBLE PRECISION NOT NULL DEFAULT 0,
  quantity DOUBLE PRECISION,
  pnl_quote DOUBLE PRECISION,
  message TEXT NOT NULL,
  mode TEXT NOT NULL,
  timestamp BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS trading_logs_user_ts_idx ON trading_logs (user_id, timestamp DESC);

CREATE TABLE IF NOT EXISTS paper_trading_balances (
  id SERIAL PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  asset TEXT NOT NULL,
  balance DOUBLE PRECISION NOT NULL DEFAULT 0,
  updated_at BIGINT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS paper_balances_user_asset_idx ON paper_trading_balances (user_id, asset);

CREATE TABLE IF NOT EXISTS price_alerts (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  base_asset TEXT NOT NULL,
  persian_name TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  symbol TEXT NOT NULL,
  condition TEXT NOT NULL,
  target_price DOUBLE PRECISION NOT NULL,
  created_price DOUBLE PRECISION NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  send_telegram BOOLEAN NOT NULL DEFAULT TRUE,
  note TEXT,
  created_at BIGINT NOT NULL,
  triggered_at BIGINT,
  triggered_price DOUBLE PRECISION
);
CREATE INDEX IF NOT EXISTS price_alerts_user_status_idx ON price_alerts (user_id, status);

CREATE TABLE IF NOT EXISTS price_watchers (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  base_asset TEXT NOT NULL,
  persian_name TEXT NOT NULL,
  quote_mode TEXT NOT NULL DEFAULT 'BOTH',
  interval_minutes INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  notify_browser BOOLEAN NOT NULL DEFAULT TRUE,
  play_sound BOOLEAN NOT NULL DEFAULT TRUE,
  send_telegram BOOLEAN NOT NULL DEFAULT TRUE,
  webhook_url TEXT,
  last_price_toman DOUBLE PRECISION,
  last_price_usdt DOUBLE PRECISION,
  last_change_24h DOUBLE PRECISION,
  sent_count INTEGER NOT NULL DEFAULT 0,
  created_at BIGINT NOT NULL,
  last_sent_at BIGINT,
  next_send_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS price_watchers_user_status_idx ON price_watchers (user_id, status);

CREATE TABLE IF NOT EXISTS notifications (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  watcher_id TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'PRICE_PULSE',
  base_asset TEXT NOT NULL,
  persian_name TEXT NOT NULL,
  quote_mode TEXT NOT NULL DEFAULT 'BOTH',
  price_toman DOUBLE PRECISION NOT NULL DEFAULT 0,
  price_usdt DOUBLE PRECISION NOT NULL DEFAULT 0,
  change24h_percent DOUBLE PRECISION NOT NULL DEFAULT 0,
  interval_minutes INTEGER NOT NULL DEFAULT 5,
  title TEXT,
  message TEXT,
  sent_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS notifications_user_sent_idx ON notifications (user_id, sent_at DESC);

CREATE TABLE IF NOT EXISTS subscriptions (
  user_id TEXT PRIMARY KEY REFERENCES users(uid) ON DELETE CASCADE,
  email TEXT NOT NULL DEFAULT '',
  display_name TEXT NOT NULL DEFAULT 'کاربر',
  plan TEXT NOT NULL DEFAULT 'FREE',
  status TEXT NOT NULL DEFAULT 'EXPIRED',
  payment_method TEXT NOT NULL DEFAULT 'ADMIN_GRANT',
  start_at BIGINT NOT NULL,
  expires_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  user_email TEXT NOT NULL DEFAULT '',
  user_display_name TEXT NOT NULL DEFAULT 'کاربر',
  method TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'PENDING',
  amount_toman DOUBLE PRECISION NOT NULL,
  amount_usdt DOUBLE PRECISION NOT NULL,
  network TEXT,
  wallet_address TEXT,
  tx_hash TEXT,
  authority TEXT,
  ref_id TEXT,
  note TEXT,
  admin_note TEXT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  reviewed_at BIGINT
);
CREATE INDEX IF NOT EXISTS payments_user_created_idx ON payments (user_id, created_at DESC);
CREATE UNIQUE INDEX IF NOT EXISTS payments_tx_hash_unique_idx ON payments (LOWER(tx_hash)) WHERE tx_hash IS NOT NULL AND tx_hash <> '';
CREATE UNIQUE INDEX IF NOT EXISTS payments_authority_unique_idx ON payments (authority) WHERE authority IS NOT NULL AND authority <> '';

CREATE TABLE IF NOT EXISTS referrals (
  id TEXT PRIMARY KEY,
  referrer_uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  referrer_email TEXT NOT NULL DEFAULT '',
  referrer_display_name TEXT NOT NULL DEFAULT 'کاربر',
  referred_user_uid TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  referred_user_email TEXT NOT NULL DEFAULT '',
  referred_user_display_name TEXT NOT NULL DEFAULT 'کاربر',
  referral_code TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'REGISTERED',
  reward_days INTEGER NOT NULL DEFAULT 4,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  rewarded_at BIGINT
);
CREATE UNIQUE INDEX IF NOT EXISTS referrals_referred_uid_idx ON referrals (referred_user_uid);
CREATE INDEX IF NOT EXISTS referrals_referrer_uid_idx ON referrals (referrer_uid);

CREATE TABLE IF NOT EXISTS admin_settings (
  id TEXT PRIMARY KEY,
  monthly_price_toman INTEGER NOT NULL DEFAULT 950000,
  monthly_price_usdt DOUBLE PRECISION NOT NULL DEFAULT 15,
  auto_usdt_from_rate BOOLEAN NOT NULL DEFAULT TRUE,
  usdt_wallet_address TEXT NOT NULL DEFAULT '',
  usdt_network TEXT NOT NULL DEFAULT 'TRC20',
  usdt_wallet_address2 TEXT NOT NULL DEFAULT '',
  usdt_network2 TEXT NOT NULL DEFAULT 'BEP20',
  zarinpal_sandbox BOOLEAN NOT NULL DEFAULT TRUE,
  merchant_key_id TEXT NOT NULL DEFAULT 'v1',
  encrypted_merchant_json JSONB,
  masked_merchant_id TEXT NOT NULL DEFAULT '',
  maintenance_mode BOOLEAN NOT NULL DEFAULT FALSE,
  maintenance_message TEXT NOT NULL DEFAULT '',
  promo_free_access BOOLEAN NOT NULL DEFAULT FALSE,
  promo_banner_text TEXT NOT NULL DEFAULT '',
  support_phone TEXT NOT NULL DEFAULT '09999961279',
  support_telegram TEXT NOT NULL DEFAULT '',
  feature_policies_json JSONB NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_logs (
  id TEXT PRIMARY KEY,
  actor_email TEXT NOT NULL,
  actor_user_id TEXT,
  action TEXT NOT NULL,
  target TEXT,
  details TEXT NOT NULL,
  ip_address TEXT,
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS audit_logs_created_idx ON audit_logs (created_at DESC);

CREATE TABLE IF NOT EXISTS app_api_keys (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  label TEXT NOT NULL,
  key_prefix TEXT NOT NULL,
  key_hash TEXT NOT NULL,
  scopes_json JSONB NOT NULL DEFAULT '[]'::jsonb,
  status TEXT NOT NULL DEFAULT 'ACTIVE',
  created_at BIGINT NOT NULL,
  revoked_at BIGINT,
  last_used_at BIGINT
);
CREATE UNIQUE INDEX IF NOT EXISTS app_api_keys_hash_idx ON app_api_keys (key_hash);
CREATE INDEX IF NOT EXISTS app_api_keys_user_idx ON app_api_keys (user_id);

CREATE TABLE IF NOT EXISTS cost_basis_overrides (
  id SERIAL PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  mode TEXT NOT NULL,
  asset TEXT NOT NULL,
  price_toman DOUBLE PRECISION NOT NULL,
  price_usdt DOUBLE PRECISION NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS cost_basis_user_mode_asset_idx ON cost_basis_overrides (user_id, mode, asset);

CREATE TABLE IF NOT EXISTS feature_ideas (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  category TEXT NOT NULL DEFAULT 'GENERAL',
  status TEXT NOT NULL DEFAULT 'IDEA',
  created_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS feature_ideas_user_idx ON feature_ideas (user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS broadcasts (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'INFO',
  active BOOLEAN NOT NULL DEFAULT TRUE,
  pinned BOOLEAN NOT NULL DEFAULT FALSE,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  expires_at BIGINT,
  created_by_email TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS direct_messages (
  id TEXT PRIMARY KEY,
  target_user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  target_user_email TEXT NOT NULL DEFAULT '',
  target_user_name TEXT NOT NULL DEFAULT '',
  subject TEXT NOT NULL,
  body TEXT NOT NULL,
  severity TEXT NOT NULL DEFAULT 'INFO',
  read_by_user BOOLEAN NOT NULL DEFAULT FALSE,
  read_at BIGINT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL,
  sender_email TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS direct_messages_target_idx ON direct_messages (target_user_id, created_at DESC);

CREATE TABLE IF NOT EXISTS worker_locks (
  lock_name TEXT PRIMARY KEY,
  owner_id TEXT NOT NULL,
  acquired_at BIGINT NOT NULL,
  expires_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);

CREATE TABLE IF NOT EXISTS profit_bots (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  name TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  symbol TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'paper',
  is_active BOOLEAN NOT NULL DEFAULT FALSE,
  bot_status TEXT NOT NULL DEFAULT 'READY_TO_BUY',
  entry_amount DOUBLE PRECISION NOT NULL,
  target_net_profit DOUBLE PRECISION NOT NULL,
  poll_interval_seconds INTEGER NOT NULL DEFAULT 10,
  max_wait_minutes INTEGER,
  stop_loss_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  stop_loss_percent DOUBLE PRECISION NOT NULL DEFAULT 3,
  stop_loss_action TEXT NOT NULL DEFAULT 'STOP_AND_SELL',
  max_capital_involved DOUBLE PRECISION NOT NULL,
  max_daily_trades INTEGER NOT NULL DEFAULT 10,
  max_daily_loss DOUBLE PRECISION NOT NULL DEFAULT 0,
  order_type TEXT NOT NULL DEFAULT 'LIMIT',
  max_slippage_percent DOUBLE PRECISION NOT NULL DEFAULT 0.5,
  max_spread_percent DOUBLE PRECISION NOT NULL DEFAULT 1.5,
  limit_order_timeout_seconds INTEGER NOT NULL DEFAULT 120,
  limit_unfilled_policy TEXT NOT NULL DEFAULT 'KEEP_WAITING',
  sequence_mode TEXT NOT NULL DEFAULT 'SINGLE',
  fee_rate DOUBLE PRECISION NOT NULL DEFAULT 0.0025,
  other_fees_quote DOUBLE PRECISION NOT NULL DEFAULT 0,
  notify_telegram BOOLEAN NOT NULL DEFAULT TRUE,
  active_position_json JSONB,
  pending_order_json JSONB,
  daily_stats_json JSONB NOT NULL,
  stats_json JSONB NOT NULL,
  last_status_reason TEXT NOT NULL DEFAULT '',
  consecutive_failures INTEGER NOT NULL DEFAULT 0,
  next_retry_at BIGINT,
  last_error TEXT,
  last_checked_at BIGINT,
  started_at BIGINT,
  created_at BIGINT NOT NULL,
  updated_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS profit_bots_user_active_idx ON profit_bots (user_id, is_active);

CREATE TABLE IF NOT EXISTS profit_bot_cycles (
  id TEXT PRIMARY KEY,
  bot_id TEXT NOT NULL REFERENCES profit_bots(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  cycle_index INTEGER NOT NULL,
  symbol TEXT NOT NULL,
  base_asset TEXT NOT NULL,
  quote_currency TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'paper',
  order_type TEXT NOT NULL DEFAULT 'LIMIT',
  entry_amount_quote DOUBLE PRECISION NOT NULL,
  actual_buy_avg_price DOUBLE PRECISION NOT NULL,
  bought_qty DOUBLE PRECISION NOT NULL,
  buy_fee_quote DOUBLE PRECISION NOT NULL,
  total_buy_cost_quote DOUBLE PRECISION NOT NULL,
  actual_sell_avg_price DOUBLE PRECISION NOT NULL,
  sold_qty DOUBLE PRECISION NOT NULL,
  gross_sell_proceeds_quote DOUBLE PRECISION NOT NULL,
  sell_fee_quote DOUBLE PRECISION NOT NULL,
  other_fees_quote DOUBLE PRECISION NOT NULL DEFAULT 0,
  final_net_profit_quote DOUBLE PRECISION NOT NULL,
  target_net_profit_quote DOUBLE PRECISION NOT NULL,
  exit_reason TEXT NOT NULL,
  started_at BIGINT NOT NULL,
  completed_at BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS profit_bot_cycles_user_idx ON profit_bot_cycles (user_id, completed_at DESC);

CREATE TABLE IF NOT EXISTS profit_bot_logs (
  id TEXT PRIMARY KEY,
  bot_id TEXT NOT NULL REFERENCES profit_bots(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(uid) ON DELETE CASCADE,
  cycle_index INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL,
  event TEXT NOT NULL,
  price DOUBLE PRECISION NOT NULL DEFAULT 0,
  net_profit_quote DOUBLE PRECISION,
  message TEXT NOT NULL,
  timestamp BIGINT NOT NULL
);
CREATE INDEX IF NOT EXISTS profit_bot_logs_user_idx ON profit_bot_logs (user_id, timestamp DESC);
