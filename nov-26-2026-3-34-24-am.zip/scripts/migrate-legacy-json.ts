import 'dotenv/config';
import { closeDatabase, getDbRuntime, initDatabase, migrateLegacyJsonFiles } from '../server/db/index.ts';

async function main() {
  const args = new Set(process.argv.slice(2));
  const forceRerun = args.has('--force');
  const verifyOnly = args.has('--verify');

  await initDatabase();

  if (!verifyOnly) {
    const result = await migrateLegacyJsonFiles({ forceRerun });
    console.log('Legacy Migration Result:', JSON.stringify(result, null, 2));
  }

  const rt = getDbRuntime();
  const [counts] = await rt.queryRows<Record<string, string | number>>(`
    SELECT
      (SELECT COUNT(*) FROM users) AS users,
      (SELECT COUNT(*) FROM subscriptions) AS subscriptions,
      (SELECT COUNT(*) FROM payments) AS payments,
      (SELECT COUNT(*) FROM exchange_credentials) AS exchange_credentials,
      (SELECT COUNT(*) FROM app_api_keys) AS app_api_keys,
      (SELECT COUNT(*) FROM telegram_configurations) AS telegram_configurations,
      (SELECT COUNT(*) FROM trading_bots) AS trading_bots,
      (SELECT COUNT(*) FROM orders) AS orders,
      (SELECT COUNT(*) FROM trades) AS trades,
      (SELECT COUNT(*) FROM price_alerts) AS price_alerts,
      (SELECT COUNT(*) FROM price_watchers) AS price_watchers
  `);

  console.log('Database Row Verification Counts:', JSON.stringify(counts, null, 2));
  await closeDatabase();
}

main().catch(async (err) => {
  console.error('Legacy JSON migration failed:', err);
  await closeDatabase().catch(() => {});
  process.exit(1);
});
