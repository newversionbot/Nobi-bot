#!/usr/bin/env bash
set -euo pipefail

# ==============================================================================
# ALI Trader — Verified PostgreSQL Restore & Integrity Check Script
# Usage:
#   ./scripts/restore-db.sh <backup_file.sql.gz|backup_file.sql.gz.enc|backup_file.sql> [--verify-only] [--yes]
# ==============================================================================

if [ $# -lt 1 ]; then
  echo "Usage: $0 <backup_file.sql.gz|backup_file.sql.gz.enc|backup_file.sql> [--verify-only] [--yes]" >&2
  exit 1
fi

BACKUP_FILE="$1"
shift || true

VERIFY_ONLY=0
AUTO_YES=0
for arg in "$@"; do
  case "$arg" in
    --verify-only) VERIFY_ONLY=1 ;;
    --yes) AUTO_YES=1 ;;
    *)
      echo "Unknown option: $arg" >&2
      exit 1
      ;;
  esac
done

if [ ! -f "$BACKUP_FILE" ]; then
  echo "ERROR: Backup file not found: $BACKUP_FILE" >&2
  exit 1
fi

# 1. Verify SHA-256 checksum if sidecar exists
CHECKSUM_FILE="${BACKUP_FILE}.sha256"
if [ -f "$CHECKSUM_FILE" ]; then
  echo "Verifying SHA-256 checksum ($CHECKSUM_FILE)..."
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum -c "$CHECKSUM_FILE"
  else
    shasum -a 256 -c "$CHECKSUM_FILE"
  fi
fi

# 2. Decrypt (if .enc) and decompress into a temporary SQL file for pre-flight integrity verification
TMP_DIR="$(mktemp -d)"
cleanup() {
  rm -rf "$TMP_DIR"
}
trap cleanup EXIT

VERIFIED_SQL="$TMP_DIR/verified_restore.sql"
if [[ "$BACKUP_FILE" == *.enc ]]; then
  if [ -z "${BACKUP_ENCRYPTION_PASSPHRASE:-}" ]; then
    echo "ERROR: Encrypted backup detected; set BACKUP_ENCRYPTION_PASSPHRASE." >&2
    exit 1
  fi
  DECRYPTED_GZ="$TMP_DIR/decrypted.sql.gz"
  openssl enc -d -aes-256-cbc -pbkdf2 -iter 100000 \
    -in "$BACKUP_FILE" -out "$DECRYPTED_GZ" -pass env:BACKUP_ENCRYPTION_PASSPHRASE
  gzip -t "$DECRYPTED_GZ"
  gunzip -c "$DECRYPTED_GZ" > "$VERIFIED_SQL"
elif [[ "$BACKUP_FILE" == *.gz ]]; then
  gzip -t "$BACKUP_FILE"
  gunzip -c "$BACKUP_FILE" > "$VERIFIED_SQL"
else
  cp "$BACKUP_FILE" "$VERIFIED_SQL"
fi

if [ ! -s "$VERIFIED_SQL" ] || ! grep -q "PostgreSQL database dump" "$VERIFIED_SQL"; then
  echo "ERROR: Backup SQL integrity check failed." >&2
  exit 1
fi

echo "Backup archive & SQL structure verified ($(wc -l < "$VERIFIED_SQL") SQL lines)."

# Optional scratch restore verification against VERIFY_DATABASE_URL
if [ "$VERIFY_ONLY" -eq 1 ]; then
  if [ -n "${VERIFY_DATABASE_URL:-}" ]; then
    echo "Running dry-run restore verification into VERIFY_DATABASE_URL..."
    psql "$VERIFY_DATABASE_URL" -v ON_ERROR_STOP=1 -f "$VERIFIED_SQL" >/dev/null
    psql "$VERIFY_DATABASE_URL" -t -A -c "SELECT 'users=' || COUNT(*) FROM users;"
    psql "$VERIFY_DATABASE_URL" -t -A -c "SELECT 'trading_bots=' || COUNT(*) FROM trading_bots;"
    psql "$VERIFY_DATABASE_URL" -t -A -c "SELECT 'orders=' || COUNT(*) FROM orders;"
  fi
  echo "Restore verification (--verify-only) passed."
  exit 0
fi

PG_CONTAINER_NAME="${PG_CONTAINER_NAME:-}"
if [ -z "${DATABASE_URL:-}" ] && [ -z "$PG_CONTAINER_NAME" ]; then
  echo "ERROR: Set DATABASE_URL (or PG_CONTAINER_NAME) before restoring." >&2
  exit 1
fi

if [ "$AUTO_YES" -ne 1 ]; then
  echo "WARNING: Restoring $BACKUP_FILE will overwrite data in the target PostgreSQL database."
  read -r -p "Type RESTORE to continue: " CONFIRM
  if [ "$CONFIRM" != "RESTORE" ]; then
    echo "Restore cancelled."
    exit 1
  fi
fi

echo "Restoring PostgreSQL database from $BACKUP_FILE ..."
if [ -n "$PG_CONTAINER_NAME" ]; then
  PG_USER="${POSTGRES_USER:-alitrader}"
  PG_DB="${POSTGRES_DB:-alitrader}"
  docker exec -i "$PG_CONTAINER_NAME" psql -U "$PG_USER" -d "$PG_DB" -v ON_ERROR_STOP=1 < "$VERIFIED_SQL"
  echo "Post-restore row count verification:"
  docker exec -i "$PG_CONTAINER_NAME" psql -U "$PG_USER" -d "$PG_DB" -t -A -c \
    "SELECT 'users=' || (SELECT COUNT(*) FROM users) || ', bots=' || (SELECT COUNT(*) FROM trading_bots) || ', orders=' || (SELECT COUNT(*) FROM orders) || ', payments=' || (SELECT COUNT(*) FROM payments);"
else
  psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$VERIFIED_SQL"
  echo "Post-restore row count verification:"
  psql "$DATABASE_URL" -t -A -c \
    "SELECT 'users=' || (SELECT COUNT(*) FROM users) || ', bots=' || (SELECT COUNT(*) FROM trading_bots) || ', orders=' || (SELECT COUNT(*) FROM orders) || ', payments=' || (SELECT COUNT(*) FROM payments);"
fi

echo "Database restore and verification completed successfully."
