#!/usr/bin/env bash
set -euo pipefail
umask 077

# ==============================================================================
# ALI Trader — Hardened Daily PostgreSQL Backup Script
# Features:
#   - Secure 0700 directory & 0600 dump permissions
#   - Atomic dump -> gzip -> integrity verification -> SHA-256 checksum
#   - Optional AES-256-CBC (PBKDF2) encryption via BACKUP_ENCRYPTION_PASSPHRASE
#   - Automatic retention pruning (keeping at least the newest backup)
#   - Optional off-site replication via RCLONE_REMOTE, S3_BUCKET, or SCP_TARGET
# ==============================================================================

BACKUP_DIR="${BACKUP_DIR:-./backups}"
RETENTION_DAYS="${RETENTION_DAYS:-14}"
PG_CONTAINER_NAME="${PG_CONTAINER_NAME:-}"
TIMESTAMP="$(date -u +%Y%m%d_%H%M%S)"

mkdir -p "$BACKUP_DIR"
chmod 700 "$BACKUP_DIR"

if [ -z "${DATABASE_URL:-}" ] && [ -z "$PG_CONTAINER_NAME" ]; then
  echo "ERROR: Set DATABASE_URL (or PG_CONTAINER_NAME for docker exec) before running backup-db.sh." >&2
  exit 1
fi

RAW_SQL_TMP="$(mktemp "$BACKUP_DIR/.tmp_dump_${TIMESTAMP}_XXXXXX.sql")"
cleanup() {
  rm -f "$RAW_SQL_TMP"
}
trap cleanup EXIT

echo "[$(date -u +%FT%TZ)] Starting PostgreSQL backup..."

if [ -n "$PG_CONTAINER_NAME" ]; then
  PG_USER="${POSTGRES_USER:-alitrader}"
  PG_DB="${POSTGRES_DB:-alitrader}"
  docker exec -i "$PG_CONTAINER_NAME" pg_dump -U "$PG_USER" -d "$PG_DB" \
    --no-owner --no-privileges --clean --if-exists > "$RAW_SQL_TMP"
else
  pg_dump "$DATABASE_URL" --no-owner --no-privileges --clean --if-exists > "$RAW_SQL_TMP"
fi

# Verify raw SQL dump integrity before compression
if [ ! -s "$RAW_SQL_TMP" ]; then
  echo "ERROR: Generated SQL dump is empty!" >&2
  exit 1
fi

if ! grep -q "PostgreSQL database dump" "$RAW_SQL_TMP"; then
  echo "ERROR: SQL dump header verification failed!" >&2
  exit 1
fi

GZ_FILE="$BACKUP_DIR/ali_trader_${TIMESTAMP}.sql.gz"
gzip -9 -c "$RAW_SQL_TMP" > "$GZ_FILE"
rm -f "$RAW_SQL_TMP"

if ! gzip -t "$GZ_FILE"; then
  echo "ERROR: Gzip integrity check failed for $GZ_FILE!" >&2
  rm -f "$GZ_FILE"
  exit 1
fi

FINAL_FILE="$GZ_FILE"
if [ -n "${BACKUP_ENCRYPTION_PASSPHRASE:-}" ]; then
  ENC_FILE="${GZ_FILE}.enc"
  openssl enc -aes-256-cbc -salt -pbkdf2 -iter 100000 \
    -in "$GZ_FILE" -out "$ENC_FILE" -pass env:BACKUP_ENCRYPTION_PASSPHRASE
  rm -f "$GZ_FILE"
  FINAL_FILE="$ENC_FILE"
fi

chmod 600 "$FINAL_FILE"

CHECKSUM_FILE="${FINAL_FILE}.sha256"
if command -v sha256sum >/dev/null 2>&1; then
  sha256sum "$FINAL_FILE" > "$CHECKSUM_FILE"
  sha256sum -c "$CHECKSUM_FILE" >/dev/null
else
  shasum -a 256 "$FINAL_FILE" > "$CHECKSUM_FILE"
  shasum -a 256 -c "$CHECKSUM_FILE" >/dev/null
fi
chmod 600 "$CHECKSUM_FILE"

echo "[$(date -u +%FT%TZ)] Integrity & checksum verified: $FINAL_FILE ($(du -h "$FINAL_FILE" | cut -f1))"

# Retention pruning — never delete the newest backup
NEWEST_BACKUP="$(ls -1t "$BACKUP_DIR"/ali_trader_*.sql.gz* 2>/dev/null | grep -v '\.sha256$' | head -n 1 || true)"
while IFS= read -r old_file; do
  [ -z "$old_file" ] && continue
  if [ "$old_file" != "$NEWEST_BACKUP" ]; then
    rm -f "$old_file" "${old_file}.sha256"
    echo "[$(date -u +%FT%TZ)] Pruned expired backup: $old_file"
  fi
done < <(find "$BACKUP_DIR" -maxdepth 1 -type f \( -name 'ali_trader_*.sql.gz' -o -name 'ali_trader_*.sql.gz.enc' \) -mtime +"$RETENTION_DAYS")

# Off-site replication (recommended so backups do not live solely on the production VPS)
OFFSITE_COPIED=0

if [ -n "${RCLONE_REMOTE:-}" ] && command -v rclone >/dev/null 2>&1; then
  echo "[$(date -u +%FT%TZ)] Replicating backup to rclone remote: $RCLONE_REMOTE"
  rclone copy "$FINAL_FILE" "$RCLONE_REMOTE"
  rclone copy "$CHECKSUM_FILE" "$RCLONE_REMOTE"
  OFFSITE_COPIED=1
fi

if [ -n "${S3_BUCKET:-}" ] && command -v aws >/dev/null 2>&1; then
  echo "[$(date -u +%FT%TZ)] Replicating backup to S3: $S3_BUCKET"
  aws s3 cp "$FINAL_FILE" "${S3_BUCKET%/}/$(basename "$FINAL_FILE")" --sse AES256
  aws s3 cp "$CHECKSUM_FILE" "${S3_BUCKET%/}/$(basename "$CHECKSUM_FILE")" --sse AES256
  OFFSITE_COPIED=1
fi

if [ -n "${SCP_TARGET:-}" ] && command -v scp >/dev/null 2>&1; then
  echo "[$(date -u +%FT%TZ)] Replicating backup via SCP: $SCP_TARGET"
  scp -o BatchMode=yes -o StrictHostKeyChecking=accept-new "$FINAL_FILE" "$CHECKSUM_FILE" "$SCP_TARGET"
  OFFSITE_COPIED=1
fi

if [ "$OFFSITE_COPIED" -eq 0 ]; then
  echo "WARNING: Backup stored locally ONLY. Configure RCLONE_REMOTE, S3_BUCKET, or SCP_TARGET for off-site redundancy." >&2
fi

echo "[$(date -u +%FT%TZ)] Backup pipeline completed successfully."
