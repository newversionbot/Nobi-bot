export type ExecutionMode = 'paper' | 'live';
export type QuoteCurrency = 'IRT' | 'USDT';
export type Timeframe = '1m' | '5m' | '15m' | '1h' | '4h' | '1d';

export interface UnifiedMarketTicker {
  baseAsset: string;
  persianName: string;
  symbolIrt: string;
  symbolUsdt: string;
  hasIrtMarket: boolean;
  hasUsdtMarket: boolean;
  priceToman: number;
  priceUsdt: number;
  bestBuyToman: number;
  bestSellToman: number;
  bestBuyUsdt: number;
  bestSellUsdt: number;
  high24hToman: number;
  low24hToman: number;
  high24hUsdt: number;
  low24hUsdt: number;
  change24hPercent: number;
  volumeToman: number;
  volumeUsdt: number;
  volumeSrc: number;
  usdtTomanRate: number;
  timestamp: number;
}

export interface KlineCandle {
  openTime: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  closeTime: number;
  quoteVolume: number;
  trades: number;
}

export interface OrderBookLevel {
  price: number;
  quantity: number;
  total: number;
}

export interface OrderBookSnapshot {
  symbol: string;
  quoteCurrency: QuoteCurrency;
  timestamp: number;
  lastTradePrice: number;
  bids: OrderBookLevel[];
  asks: OrderBookLevel[];
  spread: number;
  spreadPercent: number;
}

export interface RecentTrade {
  id: string;
  price: number;
  quantity: number;
  time: number;
  isBuyerMaker: boolean;
}

export interface IndicatorSnapshot {
  symbol: string;
  timeframe: Timeframe;
  price: number;
  timestamp: number;
  rsi14: number;
  stochK: number;
  stochD: number;
  macd: {
    macdLine: number;
    signalLine: number;
    histogram: number;
  };
  ema9: number;
  ema20: number;
  ema50: number;
  ema200: number;
  sma20: number;
  bollinger: {
    upper: number;
    middle: number;
    lower: number;
    bandwidthPercent: number;
    percentB: number;
  };
  atr14: number;
  volumeRatio: number;
  pivots: {
    pivot: number;
    r1: number;
    r2: number;
    r3: number;
    s1: number;
    s2: number;
    s3: number;
  };
  signal: {
    action: 'STRONG_BUY' | 'BUY' | 'NEUTRAL' | 'SELL' | 'STRONG_SELL';
    labelFa: string;
    buyCount: number;
    sellCount: number;
    neutralCount: number;
    reasons: string[];
  };
  series: {
    ema20: (number | null)[];
    ema50: (number | null)[];
    bbUpper: (number | null)[];
    bbLower: (number | null)[];
    rsi: (number | null)[];
    macdLine: (number | null)[];
    macdSignal: (number | null)[];
    macdHistogram: (number | null)[];
  };
}

export interface SpotBalance {
  asset: string;
  persianName?: string;
  free: number;
  locked: number;
  total: number;
  usdtValue: number;
  tomanValue: number;
}

export interface SpotOrder {
  orderId: string;
  symbol: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  side: 'BUY' | 'SELL';
  type: 'LIMIT' | 'MARKET';
  price: number;
  quantity: number;
  executedQty: number;
  totalQuoteAmount: number;
  status: 'NEW' | 'FILLED' | 'CANCELED' | 'PARTIALLY_FILLED';
  stopLossPrice?: number;
  takeProfitPrice?: number;
  mode: ExecutionMode;
  source: 'MANUAL' | 'BOT';
  botId?: string;
  createdAt: number;
}

export type RuleIndicatorType =
  | 'RSI_OVERSOLD'
  | 'RSI_OVERBOUGHT'
  | 'EMA_GOLDEN_CROSS'
  | 'EMA_DEATH_CROSS'
  | 'MACD_BULLISH_CROSS'
  | 'MACD_BEARISH_CROSS'
  | 'BB_LOWER_TOUCH'
  | 'BB_UPPER_TOUCH'
  | 'VOLUME_SPIKE'
  | 'FIXED_BUY_PRICE'
  | 'FIXED_SELL_PRICE'
  | 'BREAKOUT_RESISTANCE'
  | 'BREAKDOWN_SUPPORT'
  | 'TREND_ALIGNMENT'
  | 'VOLATILITY_FILTER';

export type BotStrategyKind = 'INDICATOR' | 'FIXED_PRICE';
export type BotType = 'PROFIT' | 'FIXED_PRICE' | 'STRATEGY' | 'GRID' | 'DCA' | 'AI_CYCLE_PRO';
export type StrategyStyleMode = 'DAY_TRADING' | 'MEDIUM_TERM';
export type BotExecutionConfirmationMode = 'AUTO' | 'MANUAL_CONFIRM';

export interface TakeProfitTarget {
  id: string;
  risePercent: number;
  sellPercent: number;
  executed?: boolean;
}

export interface StrategyRule {
  id: string;
  type: RuleIndicatorType;
  action: 'BUY' | 'SELL';
  enabled: boolean;
  params: {
    period?: number;
    threshold?: number;
    fastPeriod?: number;
    slowPeriod?: number;
    multiplier?: number;
    targetPrice?: number;
    repeatCycle?: boolean;
    maxCycles?: number | null;
    pollSeconds?: number;
    lookbackBars?: number;
    minAtrPercent?: number;
    maxAtrPercent?: number;
  };
}

export type BotFundingMode = 'QUOTE_BUY' | 'EXISTING_ASSET' | 'AUTO_PREFER_EXISTING';

export interface BotStrategyConfig {
  id: string;
  ownerId?: string;
  name: string;
  strategyKind?: BotStrategyKind;
  strategyStyle?: StrategyStyleMode;
  targetBuyPrice?: number;
  targetSellPrice?: number;
  repeatCycle?: boolean;
  maxCycles?: number | null;
  pollIntervalSeconds?: number;
  fundingMode?: BotFundingMode;
  existingBalancePercent?: number;
  executionConfirmationMode?: BotExecutionConfirmationMode;
  maxAllocatedCapital?: number;
  feeRate?: number;
  estimatedSlippagePercent?: number;
  volumeConfirmationEnabled?: boolean;
  minVolumeRatio?: number;
  volatilityFilterEnabled?: boolean;
  volatilityFilterMaxAtrPercent?: number;
  minSignalScore?: number;
  takeProfitTargets?: TakeProfitTarget[];
  trailingTakeProfitEnabled?: boolean;
  trailingTakeProfitActivationPercent?: number;
  trailingTakeProfitCallbackPercent?: number;
  keepRunnerPercent?: number;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  symbol: string; // e.g. BTCIRT or BTCUSDT
  timeframe: Timeframe;
  mode: ExecutionMode;
  status: 'RUNNING' | 'PAUSED';
  orderAmount: number; // in Toman if IRT, in USDT if USDT
  stopLossPercent: number;
  takeProfitPercent: number;
  trailingStopEnabled: boolean;
  trailingStopPercent: number;
  cooldownMinutes: number;
  logicOperator: 'AND' | 'OR';
  entryRules: StrategyRule[];
  exitRules: StrategyRule[];
  activePosition: {
    entryPrice: number;
    quantity: number;
    initialQuantity?: number;
    highestPrice: number;
    stopLossPrice: number;
    takeProfitPrice: number;
    openedAt: number;
    fromExistingBalance?: boolean;
    trailingTpArmed?: boolean;
    executedTpIds?: string[];
    runnerKeptQty?: number;
    buyFeeQuote?: number;
  } | null;
  stats: {
    totalTrades: number;
    winningTrades: number;
    losingTrades: number;
    realizedPnl: number; // in quoteCurrency
    totalFeesPaidQuote?: number;
  };
  lastCheckedAt: number | null;
  lastSignalSummary: string;
  notifyTelegram?: boolean;
  createdAt: number;
}

export type ProfitBotStatus =
  | 'READY_TO_BUY'
  | 'CHECKING_MARKET'
  | 'PLACING_BUY'
  | 'BUY_FILLED'
  | 'WAITING_FOR_PROFIT'
  | 'PROFIT_TARGET_REACHED'
  | 'PLACING_SELL'
  | 'SELL_FILLED'
  | 'STOPPED'
  | 'CONNECTION_ERROR'
  | 'PARTIAL_ORDER'
  | 'NEEDS_USER_REVIEW';

export type ProfitBotOrderType = 'LIMIT' | 'MARKET';
export type ProfitBotSequenceMode = 'SINGLE' | 'PREPARE_NEXT' | 'CYCLE_REPEAT';
export type ProfitBotReentryPolicy = 'WAIT_ENTRY_PRICE' | 'IMMEDIATE';
export type ProfitBotStopLossAction = 'STOP_AND_SELL' | 'STOP_ONLY';
export type ProfitBotLimitUnfilledPolicy = 'KEEP_WAITING' | 'CANCEL_AND_REPRICE' | 'STOP_BOT';

export interface ProfitBotPosition {
  cycleIndex: number;
  buyOrderId: string;
  buyExchangeOrderId?: string;
  buyOrderType: ProfitBotOrderType;
  requestedQuoteAmount: number;
  requestedQty: number;
  filledGrossQty: number;
  netOwnedQty: number;
  actualBuyAvgPrice: number;
  buyPrincipalQuote: number;
  buyFeeQuote: number;
  buyFeeAsset: string;
  totalBuyCostQuote: number;
  otherFeesQuote: number;
  buyFilledAt: number;
  partialFill: boolean;
  fromExistingBalance?: boolean;
  lastExecutableSellPrice?: number;
  lastExecutableProceedsQuote?: number;
  lastEstimatedSellFeeQuote?: number;
  lastEstimatedNetProfitQuote?: number;
  lastHasSufficientDepth?: boolean;
  lastSpreadPercent?: number;
  lastSlippagePercent?: number;
  lastRequiredSellPrice?: number;
  lastProgressPercent?: number;
  lastEvaluatedAt?: number;
}

export interface ProfitBotPendingOrder {
  orderId: string;
  exchangeOrderId?: string;
  side: 'BUY' | 'SELL';
  type: ProfitBotOrderType;
  price: number;
  requestedQty: number;
  executedQty: number;
  totalQuoteAmount: number;
  cycleIndex: number;
  placedAt: number;
  lastCheckedAt: number;
}

export interface ProfitBotDailyStats {
  dateKey: string;
  tradesCount: number;
  lossQuote: number;
  netProfitQuote: number;
}

export interface ProfitBotStats {
  completedCycles: number;
  winningCycles: number;
  losingCycles: number;
  totalNetProfitQuote: number;
  totalFeesPaidQuote: number;
  currentCapitalInvolved: number;
  lastBuyPrice?: number | null;
}

export interface ProfitBotDecisionLog {
  id: string;
  botId: string;
  cycleIndex: number;
  status: ProfitBotStatus;
  event:
    | 'INFO'
    | 'CHECK'
    | 'BUY_PLACED'
    | 'BUY_FILLED'
    | 'PARTIAL_FILL'
    | 'TARGET_REACHED'
    | 'SELL_PLACED'
    | 'SELL_FILLED'
    | 'STOP_LOSS'
    | 'CANCELED'
    | 'STOPPED'
    | 'ERROR'
    | 'NEEDS_REVIEW';
  price: number;
  netProfitQuote?: number | null;
  message: string;
  timestamp: number;
}

export interface ProfitBotCycleRecord {
  id: string;
  botId: string;
  cycleIndex: number;
  symbol: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  mode: ExecutionMode;
  orderType: ProfitBotOrderType;
  entryAmountQuote: number;
  actualBuyAvgPrice: number;
  boughtQty: number;
  buyFeeQuote: number;
  totalBuyCostQuote: number;
  actualSellAvgPrice: number;
  soldQty: number;
  grossSellProceedsQuote: number;
  sellFeeQuote: number;
  otherFeesQuote: number;
  finalNetProfitQuote: number;
  targetNetProfitQuote: number;
  exitReason: 'TARGET_PROFIT' | 'STOP_LOSS' | 'MANUAL_SELL' | 'PARTIAL_EXIT';
  startedAt: number;
  completedAt: number;
}

export interface ProfitBotConfig {
  id: string;
  ownerId?: string;
  name: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  symbol: string;
  mode: ExecutionMode;
  isActive: boolean;
  botStatus: ProfitBotStatus;
  entryAmount: number;
  targetNetProfit: number;
  pollIntervalSeconds: number;
  maxWaitMinutes: number | null;
  stopLossEnabled: boolean;
  stopLossPercent: number;
  stopLossAction: ProfitBotStopLossAction;
  maxCapitalInvolved: number;
  maxDailyTrades: number;
  maxDailyLoss: number;
  orderType: ProfitBotOrderType;
  maxSlippagePercent: number;
  maxSpreadPercent: number;
  limitOrderTimeoutSeconds: number;
  limitUnfilledPolicy: ProfitBotLimitUnfilledPolicy;
  sequenceMode: ProfitBotSequenceMode;
  reentryTargetPrice?: number | null;
  reentryPolicy?: ProfitBotReentryPolicy;
  waitEntryPriceOnFirstBuy?: boolean;
  targetSellPrice?: number | null;
  fundingMode?: BotFundingMode;
  existingBalancePercent?: number;
  existingEntryPrice?: number | null;
  feeRate: number;
  otherFeesQuote: number;
  executionConfirmationMode?: BotExecutionConfirmationMode;
  takeProfitTargets?: TakeProfitTarget[];
  trailingTakeProfitEnabled?: boolean;
  trailingTakeProfitActivationPercent?: number;
  trailingTakeProfitCallbackPercent?: number;
  keepRunnerPercent?: number;
  notifyTelegram: boolean;
  activePosition: ProfitBotPosition | null;
  pendingOrder: ProfitBotPendingOrder | null;
  dailyStats: ProfitBotDailyStats;
  stats: ProfitBotStats;
  lastStatusReason: string;
  lastError: string | null;
  lastCheckedAt: number | null;
  startedAt: number | null;
  createdAt: number;
  updatedAt: number;
}

export interface ProfitBotMarketPreview {
  symbol: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  bestBid: number;
  bestAsk: number;
  spread: number;
  spreadPercent: number;
  buySimulation: {
    canFillFull: boolean;
    fillableQuote: number;
    avgBuyPrice: number;
    slippagePercent: number;
    grossQty: number;
    estimatedBuyFeeQuote: number;
    netQtyReceived: number;
    totalBuyCostQuote: number;
  };
  estimatedRequiredSellPrice: number;
  estimatedRequiredRisePercent: number;
  sellAtCurrentBook: {
    hasSufficientDepth: boolean;
    fillableQty: number;
    executableAvgSellPrice: number;
    grossProceedsQuote: number;
    estimatedSellFeeQuote: number;
    netProfitQuote: number;
  };
}

export interface AppApiKeySummary {
  id: string;
  userId: string;
  label: string;
  keyPrefix: string;
  scopes: string[];
  status: 'ACTIVE' | 'REVOKED';
  createdAt: number;
  revokedAt?: number;
  lastUsedAt?: number;
}

export type NobitexAuthType = 'KEY_PAIR' | 'TOKEN';

export interface ExchangeLinkSummary {
  id: string;
  userId: string;
  label: string;
  authType?: NobitexAuthType;
  maskedApiKey: string;
  status: 'ACTIVE' | 'REVOKED';
  lastVerifiedAt?: number;
  createdAt: number;
  revokedAt?: number;
}

export interface BotExecutionLog {
  id: string;
  botId: string;
  botName: string;
  symbol: string;
  quoteCurrency: QuoteCurrency;
  event: 'BUY_EXECUTED' | 'SELL_TP' | 'SELL_SL' | 'SELL_TRAILING' | 'SELL_SIGNAL' | 'ERROR' | 'INFO';
  price: number;
  quantity?: number;
  pnlQuote?: number;
  message: string;
  mode: ExecutionMode;
  timestamp: number;
}

export interface BacktestTrade {
  entryTime: number;
  exitTime: number;
  entryPrice: number;
  exitPrice: number;
  pnlQuote: number;
  pnlPercent: number;
  feeQuote?: number;
  slippageQuote?: number;
  exitReason:
    | 'TAKE_PROFIT'
    | 'PARTIAL_TP'
    | 'TRAILING_TP'
    | 'STOP_LOSS'
    | 'TRAILING_STOP'
    | 'EXIT_SIGNAL'
    | 'GRID_CYCLE'
    | 'DCA_EXIT'
    | 'END_OF_DATA';
}

export interface BacktestResult {
  symbol: string;
  quoteCurrency: QuoteCurrency;
  timeframe: Timeframe;
  botType?: BotType;
  candlesTested: number;
  initialCapital: number;
  finalCapital: number;
  netProfitQuote: number;
  netProfitPercent: number;
  totalFeesPaidQuote?: number;
  estimatedSlippageQuote?: number;
  avgWinQuote?: number;
  avgLossQuote?: number;
  totalTrades: number;
  winningTrades: number;
  losingTrades: number;
  winRatePercent: number;
  maxDrawdownPercent: number;
  profitFactor: number;
  equityCurve: { time: number; equity: number }[];
  trades: BacktestTrade[];
}

export interface ApiConnectionStatus {
  exchange: string;
  baseUrl: string;
  publicFeedReachable: boolean;
  hasPersonalCredentials: boolean;
  defaultMode: ExecutionMode;
  usdtTomanRate: number;
  activeBotsCount: number;
}

export interface AiCoinAnalysis {
  symbol: string;
  baseAsset: string;
  generatedAt: number;
  stance: 'STRONG_BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG_SELL';
  stanceLabelFa: string;
  verdictHeadline: string;
  confidencePercent: number;
  friendlySummary: string;
  shouldBuyOrSell: string;
  simpleTechnicalExplain: string;
  tradePlan: {
    buyRangeUsd: string;
    buyRangeToman: string;
    target1Usd: string;
    target1Toman: string;
    target2Usd: string;
    target2Toman: string;
    stopLossUsd: string;
    stopLossToman: string;
  };
  keyLevels: {
    support: string;
    resistance: string;
  };
  riskTips: string[];
  customAnswer?: string;
}

export interface AiChatTurn {
  role: 'user' | 'assistant';
  text: string;
  timestamp: number;
}

export interface AiAskResponse {
  answer: string;
  suggestedFollowUps: string[];
  referencedSymbol: string;
  generatedAt: number;
}

export type SentimentSuggestion = 'BUY' | 'SELL' | 'HOLD';

export interface SentimentNewsItem {
  headline: string;
  summary: string;
  impact: 'POSITIVE' | 'NEGATIVE' | 'NEUTRAL';
  dateHint?: string;
}

export interface SentimentSourceLink {
  title: string;
  url: string;
}

export interface CoinSentimentAnalysis {
  baseAsset: string;
  symbol: string;
  generatedAt: number;
  suggestion: SentimentSuggestion;
  suggestionLabelFa: string;
  sentimentScore: number;
  sentimentMoodFa: string;
  marketFearGreed: {
    value: number;
    classification: string;
    classificationFa: string;
  } | null;
  plainSummaryFa: string;
  socialBuzzFa: string;
  newsItems: SentimentNewsItem[];
  sources: SentimentSourceLink[];
}

export type CostBasisSource = 'ORDERS' | 'MANUAL' | 'ESTIMATED';

export interface PortfolioAssetPerformance {
  asset: string;
  persianName: string;
  quantity: number;
  avgBuyPriceToman: number;
  avgBuyPriceUsdt: number;
  currentPriceToman: number;
  currentPriceUsdt: number;
  costBasisToman: number;
  costBasisUsdt: number;
  currentValueToman: number;
  currentValueUsdt: number;
  pnlToman: number;
  pnlUsdt: number;
  pnlPercentToman: number;
  pnlPercentUsdt: number;
  source: CostBasisSource;
}

export interface PortfolioPerformanceSummary {
  mode: ExecutionMode;
  totalCurrentToman: number;
  totalCurrentUsdt: number;
  cashToman: number;
  cashUsdt: number;
  cryptoCurrentToman: number;
  cryptoCurrentUsdt: number;
  cryptoCostBasisToman: number;
  cryptoCostBasisUsdt: number;
  cryptoPnlToman: number;
  cryptoPnlUsdt: number;
  cryptoPnlPercentToman: number;
  cryptoPnlPercentUsdt: number;
  assets: PortfolioAssetPerformance[];
}

export type PriceAlertCondition = 'ABOVE' | 'BELOW';
export type PriceAlertStatus = 'ACTIVE' | 'TRIGGERED';

export interface PriceAlert {
  id: string;
  baseAsset: string;
  persianName: string;
  quoteCurrency: QuoteCurrency;
  symbol: string;
  condition: PriceAlertCondition;
  targetPrice: number;
  createdPrice: number;
  status: PriceAlertStatus;
  sendTelegram?: boolean;
  note?: string;
  createdAt: number;
  triggeredAt?: number;
  triggeredPrice?: number;
}

export type PriceReporterQuoteMode = 'IRT' | 'USDT' | 'BOTH';

export interface PeriodicPriceWatcher {
  id: string;
  baseAsset: string;
  persianName: string;
  quoteMode: PriceReporterQuoteMode;
  intervalMinutes: number;
  status: 'ACTIVE' | 'PAUSED';
  notifyBrowser: boolean;
  playSound: boolean;
  sendTelegram?: boolean;
  webhookUrl?: string;
  lastPriceToman?: number;
  lastPriceUsdt?: number;
  lastChange24h?: number;
  sentCount: number;
  createdAt: number;
  lastSentAt: number | null;
  nextSendAt: number;
}

export interface PricePulseNotification {
  id: string;
  watcherId: string;
  baseAsset: string;
  persianName: string;
  quoteMode: PriceReporterQuoteMode;
  priceToman: number;
  priceUsdt: number;
  change24hPercent: number;
  intervalMinutes: number;
  sentAt: number;
}

export type BotMonitoringTelegramMode =
  | 'MANUAL_ONLY'
  | 'EVENTS_AND_STATUS'
  | 'INTERVAL'
  | 'EVERY_CYCLE';

export type TelegramManualReportKind =
  | 'FULL_SUMMARY'
  | 'TRADES'
  | 'BOTS_MONITOR'
  | 'PORTFOLIO'
  | 'SINGLE_BOT';

export interface TelegramSentLogEntry {
  id: string;
  kind:
    | 'TEST'
    | 'TRADE'
    | 'BOT_TRADE'
    | 'BOT_EVENT'
    | 'BOT_MONITOR'
    | 'PRICE_ALERT'
    | 'PRICE_PULSE'
    | 'MANUAL_REPORT';
  title: string;
  preview: string;
  status: 'SENT' | 'ERROR';
  error?: string;
  sentAt: number;
}

export interface TelegramBotSummary {
  configured: boolean;
  enabled: boolean;
  maskedBotToken: string;
  botUsername: string;
  botFirstName: string;
  chatId: string;
  sendPriceAlerts: boolean;
  sendPeriodicWatchers: boolean;
  sendTradeReports: boolean;
  sendBotTrades: boolean;
  sendBotMonitoring: boolean;
  botMonitorMode: BotMonitoringTelegramMode;
  botMonitorIntervalMinutes: number;
  updatedAt: number | null;
  lastSentAt: number | null;
  lastBotMonitorSentAt?: number | null;
  lastError: string | null;
  recentLogs?: TelegramSentLogEntry[];
}

export interface TelegramDiscoveredChat {
  chatId: string;
  title: string;
  username?: string;
  type: string;
}

export type FeatureIdeaCategory = 'TRADING' | 'ALERTS' | 'AI' | 'BOT' | 'GENERAL';
export type FeatureIdeaStatus = 'IDEA' | 'PLANNED' | 'DONE';

export interface FeatureIdeaItem {
  id: string;
  title: string;
  description: string;
  category: FeatureIdeaCategory;
  status: FeatureIdeaStatus;
  createdAt: number;
}

export type SubscriptionPlan = 'FREE' | 'PRO_MONTHLY';
export type SubscriptionStatus = 'ACTIVE' | 'EXPIRED' | 'REVOKED' | 'NONE';
export type PaymentMethodKind = 'ZARINPAL' | 'USDT' | 'ADMIN_GRANT' | 'REFERRAL_BONUS';

export type ReferralInviteStatus = 'REGISTERED' | 'REWARDED';

export interface ReferralInviteItem {
  id: string;
  referredUserUid: string;
  referredDisplayName: string;
  referredMaskedEmail: string;
  status: ReferralInviteStatus;
  rewardDays: number;
  joinedAt: number;
  rewardedAt: number | null;
}

export interface UserReferralSummary {
  referralCode: string;
  rewardDaysPerConversion: number;
  totalInvitedCount: number;
  convertedCount: number;
  pendingConversionCount: number;
  totalBonusDaysEarned: number;
  referredByCode: string | null;
  canClaimManualCode: boolean;
  invites: ReferralInviteItem[];
}

export interface AdminReferralRecord {
  id: string;
  referrerUid: string;
  referrerEmail: string;
  referrerDisplayName: string;
  referredUserUid: string;
  referredUserEmail: string;
  referredUserDisplayName: string;
  referralCode: string;
  status: ReferralInviteStatus;
  rewardDays: number;
  createdAt: number;
  updatedAt: number;
  rewardedAt: number | null;
}

export interface BillingPublicConfig {
  monthlyPriceToman: number;
  monthlyPriceUsdt: number;
  fixedUsdtPrice: number;
  autoUsdtFromRate: boolean;
  usdtWalletAddress: string;
  usdtNetwork: string;
  usdtWalletAddress2: string;
  usdtNetwork2: string;
  zarinpalEnabled: boolean;
  zarinpalSandbox: boolean;
  updatedAt: number;
}

export interface UserSubscriptionSummary {
  userId: string;
  email: string;
  displayName: string;
  plan: SubscriptionPlan;
  status: 'ACTIVE' | 'EXPIRED' | 'REVOKED';
  paymentMethod: PaymentMethodKind;
  startAt: number;
  expiresAt: number;
  updatedAt: number;
}

export interface UserEntitlement {
  isAuthenticated: boolean;
  isAdmin: boolean;
  hasProAccess: boolean;
  isBanned?: boolean;
  banReason?: string;
  promoFreeAccess?: boolean;
  plan: SubscriptionPlan;
  status: SubscriptionStatus;
  expiresAt: number | null;
  daysRemaining: number;
  subscription: UserSubscriptionSummary | null;
}

export type ModuleAccessPolicy = 'FREE' | 'PRO' | 'DISABLED';

export interface AppFeatureFlags {
  terminal: ModuleAccessPolicy;
  analysis: ModuleAccessPolicy;
  bots: ModuleAccessPolicy;
  telegram: ModuleAccessPolicy;
  watchers: ModuleAccessPolicy;
  alerts: ModuleAccessPolicy;
  pnlCalculator: ModuleAccessPolicy;
}

export interface AppControlConfig {
  maintenanceMode: boolean;
  maintenanceMessage: string;
  promoFreeAccess: boolean;
  promoBannerText: string;
  supportPhone: string;
  supportTelegram: string;
  featurePolicies: AppFeatureFlags;
  updatedAt: number;
}

export type BroadcastSeverity = 'INFO' | 'SUCCESS' | 'WARNING' | 'URGENT';

export interface BroadcastMessage {
  id: string;
  title: string;
  body: string;
  severity: BroadcastSeverity;
  active: boolean;
  pinned: boolean;
  createdAt: number;
  updatedAt: number;
  expiresAt?: number | null;
  createdByEmail: string;
}

export interface DirectMessageRecord {
  id: string;
  targetUserId: string;
  targetUserEmail: string;
  targetUserName: string;
  subject: string;
  body: string;
  severity: BroadcastSeverity;
  readByUser: boolean;
  readAt?: number | null;
  createdAt: number;
  updatedAt: number;
  senderEmail: string;
}

export interface ManagedUserSummary {
  uid: string;
  email: string;
  displayName: string;
  isAdmin: boolean;
  isBanned: boolean;
  banReason?: string;
  adminNote?: string;
  createdAt: number;
  lastSeenAt: number;
  subscription: UserSubscriptionSummary | null;
  hasProAccess: boolean;
  daysRemaining: number;
  paymentRequestsCount: number;
  approvedPaymentsCount: number;
  unreadDirectMessagesCount: number;
  referralCode: string;
  invitedCount: number;
  convertedReferralsCount: number;
  referralBonusDaysEarned: number;
  referredByUid?: string;
}

export interface AdminAuditEntry {
  id: string;
  actorEmail: string;
  action: string;
  target?: string;
  details: string;
  createdAt: number;
}

export interface AdminSystemStats {
  totalUsers: number;
  activeUsers24h: number;
  activeProUsers: number;
  bannedUsers: number;
  pendingPayments: number;
  totalRevenueToman: number;
  totalRevenueUsdt: number;
  runningBotsCount: number;
  totalBotsCount: number;
  activeAlertsCount: number;
  activeWatchersCount: number;
  ideasCount: number;
  activeBroadcastsCount: number;
  unreadDirectMessagesTotal: number;
  totalReferralsCount: number;
  convertedReferralsCount: number;
  totalReferralBonusDaysGranted: number;
}

export interface PaymentRequestRecord {
  id: string;
  userId: string;
  userEmail: string;
  userDisplayName: string;
  method: 'ZARINPAL' | 'USDT';
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  amountToman: number;
  amountUsdt: number;
  network?: string;
  walletAddress?: string;
  txHash?: string;
  authority?: string;
  refId?: string;
  note?: string;
  adminNote?: string;
  createdAt: number;
  updatedAt: number;
  reviewedAt?: number;
}

export interface BillingStatusResponse {
  config: BillingPublicConfig;
  entitlement: UserEntitlement;
  myRequests: PaymentRequestRecord[];
  appControl: AppControlConfig;
  broadcasts: BroadcastMessage[];
  directMessages: DirectMessageRecord[];
  unreadDirectCount: number;
  referral: UserReferralSummary | null;
}

export interface AdminBillingOverview {
  config: BillingPublicConfig & { maskedMerchantId: string };
  appControl: AppControlConfig;
  paymentRequests: PaymentRequestRecord[];
  subscriptions: UserSubscriptionSummary[];
  users: ManagedUserSummary[];
  broadcasts: BroadcastMessage[];
  directMessages: DirectMessageRecord[];
  auditLogs: AdminAuditEntry[];
  stats: AdminSystemStats;
  bots: BotStrategyConfig[];
  referrals: AdminReferralRecord[];
}

// =========================================================================
// Grid Bot, DCA Bot, Shared Risk Governance, Pending Confirmations & AI Manager
// =========================================================================
export type GridStepMode = 'ARITHMETIC' | 'GEOMETRIC';
export type GridBotStatus = 'RUNNING' | 'PAUSED' | 'OUT_OF_RANGE' | 'STOPPED';

export interface GridLevelState {
  index: number;
  price: number;
  side: 'BUY' | 'SELL';
  status: 'IDLE' | 'BUY_PENDING' | 'HOLDING' | 'SELL_PENDING';
  orderId?: string;
  clientOrderId?: string;
  qty: number;
  buyPrice?: number;
  buyFeeQuote?: number;
  updatedAt?: number;
}

export interface GridBotConfig {
  id: string;
  ownerId?: string;
  name: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  symbol: string;
  mode: ExecutionMode;
  isActive: boolean;
  status: GridBotStatus;
  lowerPrice: number;
  upperPrice: number;
  gridLevels: number;
  stepMode: GridStepMode;
  totalCapital: number;
  maxCapitalInvolved: number;
  stopOnBreakout: boolean;
  alertOnBreakout: boolean;
  feeRate: number;
  estimatedSlippagePercent: number;
  executionConfirmationMode: BotExecutionConfirmationMode;
  notifyTelegram: boolean;
  allocatedLevels: GridLevelState[];
  stats: {
    completedCycles: number;
    totalNetProfitQuote: number;
    totalFeesPaidQuote: number;
    openOrdersCount: number;
    currentCapitalInvolved: number;
    netProfitPerCyclePercent: number;
  };
  lastPrice: number;
  lastStatusReason: string;
  lastError: string | null;
  lastCheckedAt: number | null;
  createdAt: number;
  updatedAt: number;
}

export type DcaTriggerMode = 'TIME' | 'MARKET_DROP' | 'INDICATOR';
export type DcaStepUnit = 'PERCENT' | 'PRICE';
export type DcaBotStatus = 'RUNNING' | 'PAUSED' | 'PAUSED_BUYS' | 'COMPLETED' | 'STOPPED';

export interface DcaBotState {
  stagesCompleted: number;
  totalHoldingQty: number;
  netOwnedQty: number;
  avgBuyPrice: number;
  totalInvestedQuote: number;
  totalBuyFeesQuote: number;
  highestPriceSinceEntry: number;
  trailingTpArmed: boolean;
  lastBuyPrice: number;
  nextTriggerAt: number | null;
  pendingOrderId?: string | null;
  executedTpIds: string[];
}

export interface DcaBotConfig {
  id: string;
  ownerId?: string;
  name: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  symbol: string;
  mode: ExecutionMode;
  isActive: boolean;
  status: DcaBotStatus;
  totalCapital: number;
  maxInvolvedCapital: number;
  stagesCount: number;
  stepUnit: DcaStepUnit;
  stepValue: number;
  triggerMode: DcaTriggerMode;
  intervalMinutes: number;
  pauseNewBuys: boolean;
  stopLossEnabled: boolean;
  stopLossPercent: number;
  takeProfitEnabled: boolean;
  takeProfitPercent: number;
  trailingTpEnabled: boolean;
  trailingTpActivationPercent: number;
  trailingTpCallbackPercent: number;
  takeProfitTargets: TakeProfitTarget[];
  keepRunnerPercent: number;
  feeRate: number;
  estimatedSlippagePercent: number;
  executionConfirmationMode: BotExecutionConfirmationMode;
  notifyTelegram: boolean;
  state: DcaBotState;
  stats: {
    completedCycles: number;
    realizedNetProfitQuote: number;
    totalFeesPaidQuote: number;
  };
  lastPrice: number;
  lastStatusReason: string;
  lastError: string | null;
  lastCheckedAt: number | null;
  createdAt: number;
  updatedAt: number;
}

export interface SharedBotRiskSettings {
  userId?: string;
  totalBotsBudgetIrt: number;
  totalBotsBudgetUsdt: number;
  maxPerBotCapitalIrt: number;
  maxPerBotCapitalUsdt: number;
  maxDailyLossIrt: number;
  maxDailyLossUsdt: number;
  maxTotalLossIrt: number;
  maxTotalLossUsdt: number;
  enableSymbolConflictLock: boolean;
  allowAiAdvisoryOnly: boolean;
  killSwitchActive: boolean;
  updatedAt: number;
}

export type PendingConfirmationStatus = 'PENDING' | 'APPROVED' | 'REJECTED' | 'EXPIRED';

export interface PendingBotConfirmation {
  id: string;
  userId?: string;
  botId: string;
  botType: BotType;
  botName: string;
  symbol: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  mode: ExecutionMode;
  side: 'BUY' | 'SELL';
  orderType: 'LIMIT' | 'MARKET';
  suggestedPrice: number;
  quantity: number;
  quoteAmount: number;
  estimatedFeeQuote: number;
  reasonFa: string;
  riskSummaryFa: string;
  metaJson?: Record<string, unknown>;
  status: PendingConfirmationStatus;
  createdAt: number;
  expiresAt: number;
  resolvedAt?: number | null;
}

export type MarketRegimeType = 'BULLISH' | 'BEARISH' | 'RANGING' | 'VOLATILE';

export interface AiBotManagerCoinRank {
  symbol: string;
  baseAsset: string;
  persianName: string;
  score: number;
  liquidityScore: number;
  volatilityLabelFa: string;
  trendLabelFa: string;
  recommendedBotType: BotType;
  reasonFa: string;
}

export interface AiBotManagerBotReview {
  botId: string;
  botName: string;
  botType: BotType | string;
  health: 'HEALTHY' | 'CAUTION' | 'NEEDS_REVIEW';
  summaryFa: string;
  suggestedAction: 'KEEP' | 'PAUSE' | 'ADJUST';
}

export interface AiBotManagerConflictAlert {
  symbol: string;
  botIds: string[];
  botNames: string[];
  severity: 'HIGH' | 'MEDIUM' | 'LOW';
  messageFa: string;
}

export interface AiBotManagerProposal {
  id: string;
  actionType: 'PAUSE_BOT' | 'START_BOT' | 'STOP_BOT' | 'ADJUST_SETTINGS' | 'CREATE_RECOMMENDATION';
  targetBotId?: string;
  targetBotType?: BotType | string;
  recommendedBotType?: BotType;
  recommendedSymbol?: string;
  titleFa: string;
  reasonFa: string;
  withinApprovedLimits: boolean;
}

export interface AiManagerAnalysis {
  id: string;
  generatedAt: number;
  regime: MarketRegimeType;
  regimeLabelFa: string;
  marketSummaryFa: string;
  recommendedPrimaryBotType: BotType;
  recommendedPrimaryBotReasonFa: string;
  rankedCoins: AiBotManagerCoinRank[];
  botReviews: AiBotManagerBotReview[];
  conflictAlerts: AiBotManagerConflictAlert[];
  proposals: AiBotManagerProposal[];
  usedFallback?: boolean;
}

export interface UnifiedBotSummaryRow {
  id: string;
  botType: BotType;
  name: string;
  symbol: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  mode: ExecutionMode;
  isActive: boolean;
  statusLabelFa: string;
  allocatedCapitalQuote: number;
  committedCapitalQuote: number;
  realizedPnlQuote: number;
  unrealizedPnlQuote: number;
  feesPaidQuote: number;
  tradesCount: number;
  winRatePercent: number;
  lastUpdatedAt: number;
}

export interface UnifiedBotsDashboardSummary {
  totalBudgetIrt: number;
  totalBudgetUsdt: number;
  committedCapitalIrt: number;
  committedCapitalUsdt: number;
  freeBudgetIrt: number;
  freeBudgetUsdt: number;
  realizedPnlDailyIrt: number;
  realizedPnlWeeklyIrt: number;
  realizedPnlMonthlyIrt: number;
  unrealizedPnlIrt: number;
  totalFeesPaidIrt: number;
  realizedPnlDailyUsdt: number;
  unrealizedPnlUsdt: number;
  totalFeesPaidUsdt: number;
  openPositionsCount: number;
  closedTradesCount: number;
  overallWinRatePercent: number;
  avgPnlPerTradeIrt: number;
  bestBot: UnifiedBotSummaryRow | null;
  worstBot: UnifiedBotSummaryRow | null;
  activeConflictSymbols: string[];
  pendingConfirmationsCount: number;
  rows: UnifiedBotSummaryRow[];
}

// =========================================================================
// AI Cycle Pro | ربات چرخه هوشمند
// =========================================================================
export type AiCycleProStatus =
  | 'IDLE'
  | 'ANALYZING'
  | 'WAITING_CASH'
  | 'PLACING_BUY'
  | 'HOLDING_POSITION'
  | 'PLACING_SELL'
  | 'PAUSED'
  | 'STOPPED'
  | 'PAUSED_RISK';

export type AiCycleProCapitalUsageMode = 'FULL' | 'PARTIAL';

export interface AiCycleProDecision {
  action: 'BUY' | 'HOLD_CASH' | 'SELL' | 'HOLD_POSITION';
  marketCondition: 'FAVORABLE' | 'NEUTRAL' | 'UNFAVORABLE';
  confidencePercent: number;
  trendScore: number;
  liquidityScore: number;
  volatilityPercent: number;
  spreadPercent: number;
  estimatedSlippagePercent: number;
  recommendedCapitalPortionPercent: number;
  recommendedTargetNetProfitPercent: number;
  recommendedStopLossPercent: number;
  suggestedBuyPrice: number;
  suggestedSellPrice: number;
  regimeLabelFa: string;
  reasoningFa: string;
  riskWarningFa: string;
  usedFallback: boolean;
  analyzedAt: number;
}

export interface AiCycleProPosition {
  cycleIndex: number;
  buyOrderId: string;
  buyExchangeOrderId?: string;
  requestedQuoteAmount: number;
  requestedQty: number;
  filledGrossQty: number;
  netOwnedQty: number;
  actualBuyAvgPrice: number;
  buyFeeQuote: number;
  totalBuyCostQuote: number;
  targetNetProfitPercent: number;
  targetSellPrice: number;
  stopLossPrice: number;
  highestPrice: number;
  buyFilledAt: number;
  lastEstimatedExecutableSellPrice?: number;
  lastEstimatedNetProfitQuote?: number;
  lastEstimatedSlippagePercent?: number;
  lastSpreadPercent?: number;
  lastEvaluatedAt?: number;
}

export interface AiCycleProPendingOrder {
  orderId: string;
  exchangeOrderId?: string;
  side: 'BUY' | 'SELL';
  price: number;
  requestedQty: number;
  executedQty: number;
  totalQuoteAmount: number;
  cycleIndex: number;
  placedAt: number;
}

export interface AiCycleProDailyStats {
  dateKey: string;
  tradesCount: number;
  lossQuote: number;
  netProfitQuote: number;
}

export interface AiCycleProStats {
  completedCycles: number;
  winningCycles: number;
  losingCycles: number;
  totalNetProfitQuote: number;
  totalFeesPaidQuote: number;
  currentCapitalInvolved: number;
  lastBuyPrice?: number | null;
}

export interface AiCycleProConfig {
  id: string;
  ownerId?: string;
  name: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  symbol: string;
  mode: ExecutionMode;
  isActive: boolean;
  status: AiCycleProStatus;
  capitalAmount: number;
  capitalUsageMode: AiCycleProCapitalUsageMode;
  capitalPortionPercent: number;
  executionConfirmationMode: BotExecutionConfirmationMode;
  autoRepeatCycles: boolean;
  stopLossPercent: number;
  maxDailyLoss: number;
  maxSlippagePercent: number;
  maxSpreadPercent: number;
  minTargetNetProfitPercent: number;
  pollIntervalSeconds: number;
  feeRate: number;
  notifyTelegram: boolean;
  activePosition: AiCycleProPosition | null;
  pendingOrder: AiCycleProPendingOrder | null;
  lastDecision: AiCycleProDecision | null;
  dailyStats: AiCycleProDailyStats;
  stats: AiCycleProStats;
  lastPrice: number;
  lastStatusReason: string;
  lastError: string | null;
  lastCheckedAt: number | null;
  startedAt: number | null;
  createdAt: number;
  updatedAt: number;
}

export interface AiCycleProCycleRecord {
  id: string;
  botId: string;
  cycleIndex: number;
  symbol: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  mode: ExecutionMode;
  entryAmountQuote: number;
  actualBuyAvgPrice: number;
  boughtQty: number;
  buyFeeQuote: number;
  totalBuyCostQuote: number;
  actualSellAvgPrice: number;
  soldQty: number;
  grossSellProceedsQuote: number;
  sellFeeQuote: number;
  finalNetProfitQuote: number;
  targetNetProfitPercent: number;
  slippagePercent: number;
  exitReason: 'AI_TARGET_PROFIT' | 'STOP_LOSS' | 'DAILY_LOSS_CAP' | 'MANUAL_SELL';
  aiEntrySummaryFa: string;
  aiExitSummaryFa: string;
  startedAt: number;
  completedAt: number;
}

export interface AiCycleProLog {
  id: string;
  botId: string;
  cycleIndex: number;
  status: AiCycleProStatus;
  event:
    | 'INFO'
    | 'AI_ANALYZED'
    | 'WAIT_CASH'
    | 'BUY_FILLED'
    | 'SELL_FILLED'
    | 'STOP_LOSS'
    | 'RISK_HALT'
    | 'MANUAL_CONFIRM'
    | 'STOPPED'
    | 'ERROR';
  price: number;
  netProfitQuote?: number | null;
  message: string;
  timestamp: number;
}

export interface AiCycleProMarketPreview {
  symbol: string;
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  currentPrice: number;
  bestBid: number;
  bestAsk: number;
  spreadPercent: number;
  bidDepthQuote: number;
  askDepthQuote: number;
  estimatedBuySlippagePercent: number;
  estimatedSellSlippagePercent: number;
  decision: AiCycleProDecision;
}


