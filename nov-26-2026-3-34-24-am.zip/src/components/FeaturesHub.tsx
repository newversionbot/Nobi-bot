import React, { useEffect, useMemo, useState } from 'react';
import {
  Bell,
  BellRing,
  CheckCircle2,
  Clock,
  Layers,
  Lightbulb,
  Pause,
  Play,
  Plus,
  Send,
  Trash2,
  Volume2,
} from 'lucide-react';
import type {
  BotMonitoringTelegramMode,
  FeatureIdeaCategory,
  FeatureIdeaItem,
  FeatureIdeaStatus,
  ModuleAccessPolicy,
  PeriodicPriceWatcher,
  PriceAlert,
  PriceAlertCondition,
  PricePulseNotification,
  PriceReporterQuoteMode,
  QuoteCurrency,
  TelegramBotSummary,
  TelegramDiscoveredChat,
  TelegramManualReportKind,
  UnifiedMarketTicker,
} from '../types/trading';
import {
  formatDateTimeShort,
  formatPercent,
  formatPrice,
  formatTimeShort,
  formatToman,
} from '../utils/format';
import { CoinSearchSelect } from './CoinSearchSelect';
import { NumericInput } from './NumericInput';
import { PriceAlertsWidget } from './PriceAlertsWidget';
import { TelegramBotCard } from './TelegramBotCard';
import { ProFeatureGate } from './ProFeatureGate';

type FeatureSectionTab = 'ALL' | 'TELEGRAM' | 'ALERTS' | 'INTERVAL' | 'IDEAS';

interface FeaturesHubProps {
  markets: UnifiedMarketTicker[];
  defaultBaseAsset: string;
  defaultQuoteCurrency: QuoteCurrency;
  alerts: PriceAlert[];
  watchers: PeriodicPriceWatcher[];
  pulses: PricePulseNotification[];
  ideas: FeatureIdeaItem[];
  telegram: TelegramBotSummary;
  onQuoteCurrencyChange: (qc: QuoteCurrency) => void;
  onSelectForTrade: (baseAsset: string, qc?: QuoteCurrency) => void;
  onCreateAlert: (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    condition: PriceAlertCondition;
    targetPrice: number;
    sendTelegram?: boolean;
    note?: string;
  }) => Promise<void>;
  onRearmAlert: (alertId: string) => Promise<void>;
  onDeleteAlert: (alertId: string) => Promise<void>;
  onCreateWatcher: (payload: {
    baseAsset: string;
    quoteMode: PriceReporterQuoteMode;
    intervalMinutes: number;
    notifyBrowser: boolean;
    playSound: boolean;
    sendTelegram?: boolean;
    webhookUrl?: string;
  }) => Promise<void>;
  onToggleWatcherStatus: (watcherId: string, status: 'ACTIVE' | 'PAUSED') => Promise<void>;
  onSendWatcherNow: (watcherId: string) => Promise<void>;
  onDeleteWatcher: (watcherId: string) => Promise<void>;
  onCreateIdea: (payload: {
    title: string;
    description: string;
    category: FeatureIdeaCategory;
  }) => Promise<void>;
  onUpdateIdeaStatus: (ideaId: string, status: FeatureIdeaStatus) => Promise<void>;
  onDeleteIdea: (ideaId: string) => Promise<void>;
  onSaveTelegramConfig: (payload: {
    botToken?: string;
    chatId: string;
    enabled: boolean;
    sendPriceAlerts: boolean;
    sendPeriodicWatchers: boolean;
    sendTradeReports?: boolean;
    sendBotTrades?: boolean;
    sendBotMonitoring?: boolean;
    botMonitorMode?: BotMonitoringTelegramMode;
    botMonitorIntervalMinutes?: number;
  }) => Promise<void>;
  onDetectTelegramChats: (botToken?: string) => Promise<TelegramDiscoveredChat[]>;
  onSendTelegramTest: (botToken?: string, chatId?: string) => Promise<void>;
  onUpdateTelegramPreferences: (payload: {
    enabled?: boolean;
    sendPriceAlerts?: boolean;
    sendPeriodicWatchers?: boolean;
    sendTradeReports?: boolean;
    sendBotTrades?: boolean;
    sendBotMonitoring?: boolean;
    botMonitorMode?: BotMonitoringTelegramMode;
    botMonitorIntervalMinutes?: number;
  }) => Promise<void>;
  onDisconnectTelegram: () => Promise<void>;
  onSendTelegramReport?: (
    kind: TelegramManualReportKind,
    botId?: string
  ) => Promise<{ title?: string; preview?: string } | void>;
  hasProAccess?: boolean;
  isAdmin?: boolean;
  telegramUnlocked?: boolean;
  watchersUnlocked?: boolean;
  alertsUnlocked?: boolean;
  telegramPolicy?: ModuleAccessPolicy;
  watchersPolicy?: ModuleAccessPolicy;
  alertsPolicy?: ModuleAccessPolicy;
  monthlyPriceToman?: number;
  monthlyPriceUsdt?: number;
  isAuthenticated?: boolean;
  onSignIn?: () => Promise<void>;
  onOpenSubscription?: () => void;
  onEnterDemoMode?: () => void;
  requestedSection?: FeatureSectionTab;
  requestedSectionNonce?: number;
}

const IDEA_CATEGORY_LABELS: Record<FeatureIdeaCategory, string> = {
  TRADING: 'معاملات و کیف پول',
  ALERTS: 'هشدارها و گزارش‌ها',
  AI: 'هوش مصنوعی و تحلیل',
  BOT: 'ربات خودکار',
  GENERAL: 'امکانات عمومی',
};

const IDEA_STATUS_LABELS: Record<FeatureIdeaStatus, string> = {
  IDEA: 'ایده جدید',
  PLANNED: 'در برنامه ساخت',
  DONE: 'اجرا شده',
};

export const FeaturesHub: React.FC<FeaturesHubProps> = ({
  markets,
  defaultBaseAsset,
  defaultQuoteCurrency,
  alerts,
  watchers,
  pulses,
  ideas,
  telegram,
  onQuoteCurrencyChange,
  onSelectForTrade,
  onCreateAlert,
  onRearmAlert,
  onDeleteAlert,
  onCreateWatcher,
  onToggleWatcherStatus,
  onSendWatcherNow,
  onDeleteWatcher,
  onCreateIdea,
  onUpdateIdeaStatus,
  onDeleteIdea,
  onSaveTelegramConfig,
  onDetectTelegramChats,
  onSendTelegramTest,
  onUpdateTelegramPreferences,
  onDisconnectTelegram,
  onSendTelegramReport,
  hasProAccess = true,
  isAdmin = false,
  telegramUnlocked,
  watchersUnlocked,
  alertsUnlocked,
  telegramPolicy = 'PRO',
  watchersPolicy = 'PRO',
  alertsPolicy = 'FREE',
  monthlyPriceToman = 950_000,
  monthlyPriceUsdt = 15,
  isAuthenticated = false,
  onSignIn = async () => {},
  onOpenSubscription = () => {},
  onEnterDemoMode,
  requestedSection,
  requestedSectionNonce,
}) => {
  const canUseTelegram = telegramUnlocked ?? hasProAccess;
  const canUseWatchers = watchersUnlocked ?? hasProAccess;
  const canUseAlerts = alertsUnlocked ?? true;
  const [activeTab, setActiveTab] = useState<FeatureSectionTab>(requestedSection || 'ALL');

  useEffect(() => {
    if (requestedSection) {
      setActiveTab(requestedSection);
    }
  }, [requestedSection, requestedSectionNonce]);
  const [notifPerm, setNotifPerm] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'denied'
  );

  // Periodic Price Watcher Form State
  const [watchAsset, setWatchAsset] = useState(defaultBaseAsset || 'BTC');
  const [quoteMode, setQuoteMode] = useState<PriceReporterQuoteMode>('BOTH');
  const [intervalMinutes, setIntervalMinutes] = useState<number>(5);
  const [notifyBrowser, setNotifyBrowser] = useState(true);
  const [playSound, setPlaySound] = useState(true);
  const [sendTelegram, setSendTelegram] = useState(true);
  const [webhookUrl, setWebhookUrl] = useState('');
  const [showWebhookField, setShowWebhookField] = useState(false);
  const [savingWatcher, setSavingWatcher] = useState(false);
  const [busyWatcherId, setBusyWatcherId] = useState<string | null>(null);
  const [watcherMsg, setWatcherMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Future Ideas Form State
  const [ideaTitle, setIdeaTitle] = useState('');
  const [ideaDescription, setIdeaDescription] = useState('');
  const [ideaCategory, setIdeaCategory] = useState<FeatureIdeaCategory>('GENERAL');
  const [savingIdea, setSavingIdea] = useState(false);
  const [ideaMsg, setIdeaMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    setWatchAsset(defaultBaseAsset || 'BTC');
  }, [defaultBaseAsset]);

  const selectedWatchMarket = useMemo(
    () => markets.find((m) => m.baseAsset === watchAsset) || null,
    [markets, watchAsset]
  );

  const handleRequestNotifications = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    try {
      const perm = await Notification.requestPermission();
      setNotifPerm(perm);
    } catch {
      // Ignore permission rejection
    }
  };

  const handleSubmitWatcher = async (e: React.FormEvent) => {
    e.preventDefault();
    setWatcherMsg(null);
    const mins = Math.round(Number(intervalMinutes));
    if (!Number.isFinite(mins) || mins < 1 || mins > 1440) {
      setWatcherMsg({
        type: 'err',
        text: 'بازه ارسال قیمت باید بین ۱ تا ۱۴۴۰ دقیقه (۲۴ ساعت) باشد.',
      });
      return;
    }

    setSavingWatcher(true);
    try {
      await onCreateWatcher({
        baseAsset: watchAsset,
        quoteMode,
        intervalMinutes: mins,
        notifyBrowser,
        playSound,
        sendTelegram,
        webhookUrl: webhookUrl.trim() || undefined,
      });
      setWebhookUrl('');
      setShowWebhookField(false);
      setWatcherMsg({
        type: 'ok',
        text: `ارسال خودکار قیمت لحظه‌ای ${selectedWatchMarket?.persianName || watchAsset} هر ${mins} دقیقه فعال شد و اولین گزارش ثبت گردید.`,
      });
    } catch (err) {
      setWatcherMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'ثبت ارسال دوره‌ای قیمت ناموفق بود.',
      });
    } finally {
      setSavingWatcher(false);
    }
  };

  const handleSubmitIdea = async (e: React.FormEvent) => {
    e.preventDefault();
    setIdeaMsg(null);
    if (!ideaTitle.trim()) {
      setIdeaMsg({ type: 'err', text: 'لطفاً عنوان ایده یا امکان جدید را بنویسید.' });
      return;
    }

    setSavingIdea(true);
    try {
      await onCreateIdea({
        title: ideaTitle.trim(),
        description: ideaDescription.trim(),
        category: ideaCategory,
      });
      setIdeaTitle('');
      setIdeaDescription('');
      setIdeaMsg({
        type: 'ok',
        text: 'ایده شما در مرکز امکانات ذخیره شد تا هر زمان بخواهید به برنامه اضافه شود.',
      });
    } catch (err) {
      setIdeaMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ذخیره ایده',
      });
    } finally {
      setSavingIdea(false);
    }
  };

  const quoteModeLabel = (mode: PriceReporterQuoteMode) => {
    if (mode === 'IRT') return 'تومانی (IRT)';
    if (mode === 'USDT') return 'تتری (USDT)';
    return 'تومانی + تتری';
  };

  const activeWatchersCount = watchers.filter((w) => w.status === 'ACTIVE').length;
  const activeAlertsCount = alerts.filter((a) => a.status === 'ACTIVE').length;

  return (
    <div className="space-y-6">
      {/* Features Hub Header & Tool Filter */}
      <section className="glass-panel rounded-xl p-5 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <img
              src="/icon.svg"
              alt="AI NobiBot — ainobibot.ir"
              className="w-11 h-11 rounded-lg object-cover border border-cyan-500/40 bg-slate-950/80 p-1 shrink-0"
            />
            <div>
              <h1 className="text-base sm:text-lg font-semibold text-white">
                مرکز امکانات و ابزارهای هوشمند
              </h1>
              <p className="text-xs text-slate-400 mt-0.5">
                مجموعه ابزارهای کمکی بازار نوبیتکس و جایگاه اختصاصی تمام ایده‌ها و قابلیت‌های فعلی و آینده شما
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 text-xs">
            {typeof window !== 'undefined' && 'Notification' in window && (
              <>
                {notifPerm === 'granted' ? (
                  <span className="inline-flex items-center gap-1.5 text-emerald-400 font-medium">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>اعلان دسکتاپ مرورگر فعال است</span>
                  </span>
                ) : notifPerm === 'denied' ? (
                  <span className="text-slate-400">
                    اعلان‌های داخل برنامه و زنگ هشدار فعال هستند
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => void handleRequestNotifications()}
                    className="btn-glass btn-glass-amber inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap shrink-0"
                  >
                    <Bell className="w-4 h-4" />
                    <span>فعال‌سازی نوتیفیکیشن دسکتاپ مرورگر</span>
                  </button>
                )}
              </>
            )}
          </div>
        </div>

        {/* Segmented Filter Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800/80">
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-950/75 p-1.5 rounded-xl border border-slate-800/90 text-xs">
            {(
              [
                { id: 'ALL', label: 'همه امکانات', icon: Layers },
                {
                  id: 'TELEGRAM',
                  label: telegram.configured && telegram.enabled ? 'ربات تلگرام (متصل)' : 'ربات تلگرام',
                  icon: Send,
                },
                { id: 'INTERVAL', label: `ارسال قیمت هر X دقیقه (${activeWatchersCount})`, icon: Clock },
                { id: 'ALERTS', label: `هشدار قیمت دلخواه (${activeAlertsCount})`, icon: BellRing },
                { id: 'IDEAS', label: `ایده‌های آینده (${ideas.length})`, icon: Lightbulb },
              ] as const
            ).map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setActiveTab(tab.id)}
                  className={`btn-glass inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg font-medium whitespace-nowrap shrink-0 ${
                    isActive
                      ? 'btn-glass-primary font-semibold'
                      : 'btn-glass-neutral text-slate-300'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span>{telegram.configured && telegram.enabled ? 'تلگرام متصل' : 'تلگرام غیرفعال'}</span>
            <span aria-hidden="true">·</span>
            <span>{watchers.length} گزارش دوره‌ای</span>
            <span aria-hidden="true">·</span>
            <span>{alerts.length} هشدار هدف</span>
            <span aria-hidden="true">·</span>
            <span>{ideas.length} ایده ثبت‌شده</span>
          </div>
        </div>
      </section>

      {/* Tool 0: Telegram Bot Connection */}
      {(activeTab === 'ALL' || activeTab === 'TELEGRAM') &&
        (telegramPolicy === 'DISABLED' && !isAdmin ? (
          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 text-xs text-slate-400">
            بخش اتصال ربات تلگرام موقتاً توسط مدیریت غیرفعال شده است.
          </section>
        ) : canUseTelegram ? (
          <TelegramBotCard
            telegram={telegram}
            onSaveConfig={onSaveTelegramConfig}
            onDetectChats={onDetectTelegramChats}
            onSendTest={onSendTelegramTest}
            onUpdatePreferences={onUpdateTelegramPreferences}
            onDisconnect={onDisconnectTelegram}
            onSendManualReport={onSendTelegramReport}
          />
        ) : (
          <ProFeatureGate
            featureTitle="اتصال و ارسال خودکار به ربات تلگرام (امکانات تخصصی)"
            featureDescription="ارسال فوری هشدار قیمت‌ها و گزارش‌های لحظه‌ای بازار به ربات تلگرام شخصی شما"
            monthlyPriceToman={monthlyPriceToman}
            monthlyPriceUsdt={monthlyPriceUsdt}
            isAuthenticated={isAuthenticated}
            onSignIn={onSignIn}
            onOpenSubscription={onOpenSubscription}
            onEnterDemoMode={onEnterDemoMode}
          />
        ))}

      {/* Tool 1: Periodic Live Price Reporter (هر X دقیقه قیمت لحظه‌ای بفرسته) */}
      {(activeTab === 'ALL' || activeTab === 'INTERVAL') &&
        (watchersPolicy === 'DISABLED' && !isAdmin ? (
          <section className="glass-panel rounded-xl p-5 text-xs text-slate-400">
            بخش ارسال دوره‌ای قیمت موقتاً توسط مدیریت غیرفعال شده است.
          </section>
        ) : canUseWatchers ? (
        <section className="glass-panel rounded-xl overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-3.5 border-b border-slate-800/90 bg-[#060A14]/75">
            <div className="flex items-center gap-2.5">
              <Clock className="w-4 h-4 text-cyan-400" />
              <div>
                <h2 className="text-sm font-semibold text-white">
                  ارسال خودکار قیمت لحظه‌ای هر X دقیقه
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  ارز و بازه زمانی دلخواه را انتخاب کنید تا قیمت لحظه‌ای نوبیتکس به‌صورت خودکار با نوتیفیکیشن ارسال شود
                </p>
              </div>
            </div>
            <div className="text-xs text-slate-400 font-mono-num">
              {activeWatchersCount} پایش فعال · {pulses.length} گزارش ثبت‌شده
            </div>
          </div>

          <div className="p-5 space-y-5">
            {/* Setup Form */}
            <form
              onSubmit={handleSubmitWatcher}
              className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-4"
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">انتخاب ارز دیجیتال</label>
                  <CoinSearchSelect
                    markets={markets}
                    value={watchAsset}
                    size="sm"
                    onChange={(nextBase) => setWatchAsset(nextBase)}
                    ariaLabel="جستجو و انتخاب ارز پایش دوره‌ای"
                  />
                  {selectedWatchMarket && (
                    <div className="mt-1 flex items-center gap-2 text-[11px] font-mono-num text-slate-400" dir="ltr">
                      <span className="text-amber-300">{formatToman(selectedWatchMarket.priceToman)} ت</span>
                      <span>·</span>
                      <span>${formatPrice(selectedWatchMarket.priceUsdt)}</span>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">واحد قیمت در گزارش</label>
                  <div className="grid grid-cols-3 gap-1 bg-[#0A101D]/80 border border-slate-700 rounded-xl p-1">
                    {(
                      [
                        { id: 'BOTH', label: 'هر دو' },
                        { id: 'IRT', label: 'تومان' },
                        { id: 'USDT', label: 'تتر' },
                      ] as const
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setQuoteMode(opt.id)}
                        className={`btn-glass py-1.5 rounded-lg text-xs font-medium whitespace-nowrap ${
                          quoteMode === opt.id
                            ? opt.id === 'IRT'
                              ? 'btn-glass-amber font-semibold'
                              : 'btn-glass-primary font-semibold'
                            : 'btn-glass-neutral text-slate-300'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">
                    بازه زمانی ارسال (هر چند دقیقه؟)
                  </label>
                  <NumericInput
                    allowDecimal={false}
                    value={intervalMinutes}
                    onValueChange={(v) => setIntervalMinutes(v === '' ? 1 : Number(v))}
                    className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                  <div className="flex flex-wrap items-center gap-1 mt-1.5">
                    {[1, 5, 15, 30, 60].map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => setIntervalMinutes(m)}
                        className={`btn-glass px-2.5 py-0.5 rounded-lg text-[11px] font-mono-num ${
                          intervalMinutes === m
                            ? 'btn-glass-primary'
                            : 'btn-glass-neutral text-slate-300'
                        }`}
                      >
                        {m}د
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex flex-col justify-between gap-2">
                  <div className="space-y-1.5 text-xs pt-1">
                    <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                      <input
                        type="checkbox"
                        checked={sendTelegram}
                        onChange={(e) => setSendTelegram(e.target.checked)}
                        className="accent-cyan-500"
                      />
                      <Send className="w-3.5 h-3.5 text-cyan-400" />
                      <span>ارسال گزارش قیمت به ربات تلگرام</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                      <input
                        type="checkbox"
                        checked={notifyBrowser}
                        onChange={(e) => setNotifyBrowser(e.target.checked)}
                        className="accent-cyan-500"
                      />
                      <span>نوتیفیکیشن دسکتاپ + بنر داخل برنامه</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer text-slate-200">
                      <input
                        type="checkbox"
                        checked={playSound}
                        onChange={(e) => setPlaySound(e.target.checked)}
                        className="accent-cyan-500"
                      />
                      <Volume2 className="w-3.5 h-3.5 text-slate-400" />
                      <span>پخش صدای زنگ هنگام ارسال</span>
                    </label>
                  </div>

                  <button
                    type="submit"
                    disabled={savingWatcher}
                    className="btn-glass btn-glass-telegram w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{savingWatcher ? 'در حال ثبت...' : `شروع ارسال هر ${intervalMinutes || 1} دقیقه`}</span>
                  </button>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80 text-xs">
                <button
                  type="button"
                  onClick={() => setShowWebhookField((v) => !v)}
                  className="text-cyan-400 hover:text-cyan-300 text-[11px]"
                >
                  {showWebhookField
                    ? 'بستن تنظیمات وب‌هوک خارجی'
                    : '+ ارسال همزمان به وب‌هوک یا ربات شخصی (اختیاری)'}
                </button>

                {showWebhookField && (
                  <input
                    type="url"
                    value={webhookUrl}
                    onChange={(e) => setWebhookUrl(e.target.value)}
                    placeholder="https://... آدرس Webhook برای ارسال پیام به سرویس خارجی"
                    dir="ltr"
                    className="flex-1 min-w-[260px] bg-[#0A101D] border border-slate-700 rounded-md px-3 py-1.5 text-xs font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
                  />
                )}
              </div>

              {watcherMsg && (
                <div
                  className={`text-xs px-3 py-2 rounded border ${
                    watcherMsg.type === 'ok'
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                  }`}
                >
                  {watcherMsg.text}
                </div>
              )}
            </form>

            {/* Configured Watchers Table */}
            {watchers.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-400 border border-dashed border-slate-800 rounded-lg">
                هنوز زمان‌بندی ارسال قیمت ثبت نکرده‌اید. از فرم بالا ارز و فاصله زمانی دلخواه (مثلاً هر ۵ دقیقه) را تنظیم کنید.
              </div>
            ) : (
              <div className="overflow-x-auto border border-slate-800 rounded-lg">
                <table className="w-full text-right border-collapse">
                  <thead>
                    <tr className="border-b border-slate-800 text-xs text-slate-400 bg-[#060A14]">
                      <th className="py-2.5 px-4 font-medium">ارز دیجیتال</th>
                      <th className="py-2.5 px-4 font-medium">بازه و واحد</th>
                      <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                        آخرین قیمت ارسالی
                      </th>
                      <th className="py-2.5 px-4 font-medium">دفعات ارسال / زمان بعدی</th>
                      <th className="py-2.5 px-4 font-medium">وضعیت</th>
                      <th className="py-2.5 px-4 font-medium text-left">عملیات</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/70 text-xs">
                    {watchers.map((w) => {
                      const live = markets.find((m) => m.baseAsset === w.baseAsset);
                      const showToman = w.quoteMode === 'IRT' || w.quoteMode === 'BOTH';
                      const showUsdt = w.quoteMode === 'USDT' || w.quoteMode === 'BOTH';
                      const displayToman = live?.priceToman ?? w.lastPriceToman ?? 0;
                      const displayUsdt = live?.priceUsdt ?? w.lastPriceUsdt ?? 0;

                      return (
                        <tr key={w.id} className="hover:bg-slate-900/60 transition-colors">
                          <td className="py-2.5 px-4">
                            <div className="font-semibold text-white">
                              {w.persianName}{' '}
                              <span className="font-mono-num text-cyan-300">({w.baseAsset})</span>
                            </div>
                          </td>
                          <td className="py-2.5 px-4 text-slate-300">
                            <div>هر {w.intervalMinutes} دقیقه</div>
                            <div className="text-[11px] text-slate-500">
                              <span>{quoteModeLabel(w.quoteMode)}</span>
                              {w.sendTelegram !== false &&
                                telegram.configured &&
                                telegram.enabled &&
                                telegram.sendPeriodicWatchers && (
                                  <>
                                    <span aria-hidden="true"> · </span>
                                    <span className="text-cyan-400">تلگرام</span>
                                  </>
                                )}
                            </div>
                          </td>
                          <td className="py-2.5 px-4 text-left font-mono-num" dir="ltr">
                            {showToman && (
                              <div className="text-amber-300 font-semibold">
                                {formatToman(displayToman)} ت
                              </div>
                            )}
                            {showUsdt && (
                              <div className="text-slate-200">${formatPrice(displayUsdt)}</div>
                            )}
                          </td>
                          <td className="py-2.5 px-4 text-slate-300">
                            <div className="font-mono-num">{w.sentCount} بار ارسال شده</div>
                            {w.status === 'ACTIVE' && (
                              <div className="text-[11px] text-slate-500 font-mono-num" dir="ltr">
                                بعدی: {formatTimeShort(w.nextSendAt)}
                              </div>
                            )}
                          </td>
                          <td className="py-2.5 px-4">
                            <span
                              className={
                                w.status === 'ACTIVE'
                                  ? 'text-emerald-400 font-medium'
                                  : 'text-amber-300 font-medium'
                              }
                            >
                              {w.status === 'ACTIVE' ? 'فعال' : 'متوقف'}
                            </span>
                          </td>
                          <td className="py-2.5 px-4 text-left">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                disabled={busyWatcherId === w.id}
                                onClick={async () => {
                                  setBusyWatcherId(w.id);
                                  try {
                                    await onSendWatcherNow(w.id);
                                  } finally {
                                    setBusyWatcherId(null);
                                  }
                                }}
                                className="btn-glass btn-glass-telegram inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] whitespace-nowrap shrink-0"
                              >
                                <Send className="w-3 h-3" />
                                <span>ارسال الان</span>
                              </button>
                              <button
                                type="button"
                                disabled={busyWatcherId === w.id}
                                onClick={async () => {
                                  setBusyWatcherId(w.id);
                                  try {
                                    await onToggleWatcherStatus(
                                      w.id,
                                      w.status === 'ACTIVE' ? 'PAUSED' : 'ACTIVE'
                                    );
                                  } finally {
                                    setBusyWatcherId(null);
                                  }
                                }}
                                className="btn-glass btn-glass-neutral p-1.5 rounded-lg"
                                title={w.status === 'ACTIVE' ? 'توقف موقت' : 'ادامه ارسال'}
                              >
                                {w.status === 'ACTIVE' ? (
                                  <Pause className="w-3.5 h-3.5 text-amber-300" />
                                ) : (
                                  <Play className="w-3.5 h-3.5 text-emerald-400" />
                                )}
                              </button>
                              <button
                                type="button"
                                onClick={() => void onDeleteWatcher(w.id)}
                                className="btn-glass btn-glass-sell p-1.5 rounded-lg"
                                title="حذف"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Recent Sent Price Pulse Feed */}
            {pulses.length > 0 && (
              <div className="border border-slate-800 rounded-lg overflow-hidden">
                <div className="px-4 py-2.5 border-b border-slate-800 bg-[#060A14] flex items-center justify-between text-xs">
                  <span className="font-semibold text-white">آخرین گزارش‌های قیمت ارسال‌شده</span>
                  <span className="text-slate-400">به‌روزرسانی خودکار از نوبیتکس</span>
                </div>
                <div className="divide-y divide-slate-800/60 max-h-60 overflow-y-auto text-xs">
                  {pulses.slice(0, 12).map((p) => (
                    <div
                      key={p.id}
                      className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 hover:bg-slate-900/40"
                    >
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-semibold text-white">
                          {p.persianName} ({p.baseAsset})
                        </span>
                        <span aria-hidden="true" className="text-slate-600">
                          ·
                        </span>
                        <span className="text-slate-400">هر {p.intervalMinutes} دقیقه</span>
                      </div>

                      <div className="flex flex-wrap items-center gap-4 font-mono-num" dir="ltr">
                        {(p.quoteMode === 'IRT' || p.quoteMode === 'BOTH') && (
                          <span className="text-amber-300 font-semibold">
                            {formatToman(p.priceToman)} ت
                          </span>
                        )}
                        {(p.quoteMode === 'USDT' || p.quoteMode === 'BOTH') && (
                          <span className="text-slate-200">${formatPrice(p.priceUsdt)}</span>
                        )}
                        <span
                          className={p.change24hPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}
                        >
                          {formatPercent(p.change24hPercent)}
                        </span>
                        <span className="text-slate-500">{formatDateTimeShort(p.sentAt)}</span>
                        <button
                          type="button"
                          onClick={() =>
                            onSelectForTrade(
                              p.baseAsset,
                              p.quoteMode === 'USDT' ? 'USDT' : 'IRT'
                            )
                          }
                          className="btn-glass btn-glass-primary font-sans px-2.5 py-0.5 rounded-lg text-[11px]"
                        >
                          معامله
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </section>
        ) : (
          <ProFeatureGate
            featureTitle="ارسال خودکار قیمت لحظه‌ای هر X دقیقه (امکانات تخصصی)"
            featureDescription="زمان‌بندی ارسال خودکار قیمت‌های نوبیتکس در بازه‌های ۱ تا ۶۰ دقیقه به مرورگر، وب‌هوک و تلگرام"
            monthlyPriceToman={monthlyPriceToman}
            monthlyPriceUsdt={monthlyPriceUsdt}
            isAuthenticated={isAuthenticated}
            onSignIn={onSignIn}
            onOpenSubscription={onOpenSubscription}
            onEnterDemoMode={onEnterDemoMode}
          />
        ))}

      {/* Tool 2: Target Price Alert (هشدار رسیدن به قیمت دلخواه) */}
      {(activeTab === 'ALL' || activeTab === 'ALERTS') &&
        (alertsPolicy === 'DISABLED' && !isAdmin ? (
          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 text-xs text-slate-400">
            بخش هشدار قیمت هدف موقتاً توسط مدیریت غیرفعال شده است.
          </section>
        ) : canUseAlerts ? (
          <PriceAlertsWidget
            alerts={alerts}
            markets={markets}
            defaultBaseAsset={defaultBaseAsset}
            defaultQuoteCurrency={defaultQuoteCurrency}
            telegramConnected={telegram.configured && telegram.enabled && telegram.sendPriceAlerts}
            onOpenTelegramSettings={() => setActiveTab('TELEGRAM')}
            onQuoteCurrencyChange={onQuoteCurrencyChange}
            onCreateAlert={onCreateAlert}
            onRearmAlert={onRearmAlert}
            onDeleteAlert={onDeleteAlert}
            onSelectForTrade={onSelectForTrade}
          />
        ) : (
          <ProFeatureGate
            featureTitle="هشدار هوشمند رسیدن به قیمت هدف (امکانات تخصصی)"
            featureDescription="ثبت هشدار عبور قیمت از سقف یا کف دلخواه در بازار تومانی و تتری"
            monthlyPriceToman={monthlyPriceToman}
            monthlyPriceUsdt={monthlyPriceUsdt}
            isAuthenticated={isAuthenticated}
            onSignIn={onSignIn}
            onOpenSubscription={onOpenSubscription}
            onEnterDemoMode={onEnterDemoMode}
          />
        ))}

      {/* Tool 3: Future Ideas Vault (دفترچه ایده‌های جدید و امکانات آینده) */}
      {(activeTab === 'ALL' || activeTab === 'IDEAS') && (
        <section className="glass-panel rounded-xl overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-3.5 border-b border-slate-800/90 bg-[#060A14]/75">
            <div className="flex items-center gap-2.5">
              <Lightbulb className="w-4 h-4 text-amber-400" />
              <div>
                <h2 className="text-sm font-semibold text-white">
                  بانک ایده‌ها و امکانات آینده
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  هر ایده جدیدی که به ذهنتان می‌رسد اینجا ثبت کنید تا همیشه در بخش امکانات آماده پیاده‌سازی باشد
                </p>
              </div>
            </div>
            <span className="text-xs text-slate-400 font-mono-num">{ideas.length} ایده ثبت‌شده</span>
          </div>

          <div className="p-5 space-y-5">
            <form
              onSubmit={handleSubmitIdea}
              className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3"
            >
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] text-slate-400 mb-1">
                    عنوان ایده یا قابلیت جدید
                  </label>
                  <input
                    type="text"
                    value={ideaTitle}
                    onChange={(e) => setIdeaTitle(e.target.value)}
                    placeholder="مثلاً: ارسال سیگنال خرید پله‌ای در ریزش‌های ناگهانی"
                    className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-3 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">دسته‌بندی</label>
                  <select
                    value={ideaCategory}
                    onChange={(e) => setIdeaCategory(e.target.value as FeatureIdeaCategory)}
                    className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-3 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                  >
                    {(Object.keys(IDEA_CATEGORY_LABELS) as FeatureIdeaCategory[]).map((cat) => (
                      <option key={cat} value={cat}>
                        {IDEA_CATEGORY_LABELS[cat]}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="flex flex-col justify-end">
                  <button
                    type="submit"
                    disabled={savingIdea}
                    className="btn-glass btn-glass-amber w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{savingIdea ? 'در حال ذخیره...' : 'ثبت ایده جدید'}</span>
                  </button>
                </div>
              </div>

              <div>
                <input
                  type="text"
                  value={ideaDescription}
                  onChange={(e) => setIdeaDescription(e.target.value)}
                  placeholder="توضیحات تکمیلی ایده (اختیاری) — دقیقاً بنویسید دوست دارید چطور کار کند..."
                  className="w-full bg-[#0A101D] border border-slate-800 rounded-md px-3 py-2 text-xs text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
                />
              </div>

              {ideaMsg && (
                <div
                  className={`text-xs px-3 py-2 rounded border ${
                    ideaMsg.type === 'ok'
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                  }`}
                >
                  {ideaMsg.text}
                </div>
              )}
            </form>

            {ideas.length === 0 ? (
              <div className="text-center py-6 text-xs text-slate-400 border border-dashed border-slate-800 rounded-lg">
                هنوز ایده‌ای در دفترچه ثبت نشده است. اولین ایده آینده خود را در کادر بالا یادداشت کنید.
              </div>
            ) : (
              <div className="divide-y divide-slate-800 border border-slate-800 rounded-lg overflow-hidden">
                {ideas.map((idea) => (
                  <div
                    key={idea.id}
                    className="p-4 bg-slate-950/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3 hover:bg-slate-900/40 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center gap-2 text-xs">
                        <span className="font-semibold text-white text-sm">{idea.title}</span>
                        <span aria-hidden="true" className="text-slate-600">
                          ·
                        </span>
                        <span className="text-cyan-300">{IDEA_CATEGORY_LABELS[idea.category]}</span>
                        <span aria-hidden="true" className="text-slate-600">
                          ·
                        </span>
                        <span className="text-slate-500 font-mono-num" dir="ltr">
                          {formatDateTimeShort(idea.createdAt)}
                        </span>
                      </div>
                      {idea.description && (
                        <p className="text-xs text-slate-300 leading-relaxed">{idea.description}</p>
                      )}
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <select
                        value={idea.status}
                        onChange={(e) =>
                          void onUpdateIdeaStatus(idea.id, e.target.value as FeatureIdeaStatus)
                        }
                        className={`bg-[#0A101D] border border-slate-700 rounded-md px-2.5 py-1.5 text-xs font-medium focus:outline-none focus:border-cyan-400 ${
                          idea.status === 'DONE'
                            ? 'text-emerald-400'
                            : idea.status === 'PLANNED'
                              ? 'text-amber-300'
                              : 'text-cyan-300'
                        }`}
                      >
                        {(Object.keys(IDEA_STATUS_LABELS) as FeatureIdeaStatus[]).map((st) => (
                          <option key={st} value={st}>
                            {IDEA_STATUS_LABELS[st]}
                          </option>
                        ))}
                      </select>

                      <button
                        type="button"
                        onClick={() => void onDeleteIdea(idea.id)}
                        className="btn-glass btn-glass-sell p-1.5 rounded-lg"
                        title="حذف ایده"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </section>
      )}
    </div>
  );
};
