import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowDownRight,
  ArrowLeft,
  ArrowUpRight,
  BarChart3,
  BookOpen,
  Bot,
  BrainCircuit,
  CheckCircle2,
  Coins,
  HelpCircle,
  Pause,
  Phone,
  Play,
  Search,
  Send,
  Settings2,
  ShieldCheck,
  TrendingUp,
  Wallet,
} from 'lucide-react';
import type {
  BotExecutionLog,
  BotStrategyConfig,
  ExecutionMode,
  IndicatorSnapshot,
  KlineCandle,
  ModuleAccessPolicy,
  PortfolioPerformanceSummary,
  PriceAlert,
  PriceAlertCondition,
  QuoteCurrency,
  RecentTrade,
  SpotBalance,
  SpotOrder,
  Timeframe,
  UnifiedMarketTicker,
} from '../types/trading';
import {
  formatCompactToman,
  formatCompactUsd,
  formatPercent,
  formatPrice,
  formatQty,
  formatQuotePrice,
  formatTimeShort,
  formatToman,
} from '../utils/format';
import { LiveTickerTape } from './LiveTickerTape';
import { CandlestickChart } from './CandlestickChart';
import { PnlCalculatorWidget } from './PnlCalculatorWidget';
import { PortfolioPerformanceWidget } from './PortfolioPerformanceWidget';
import { PriceAlertsWidget } from './PriceAlertsWidget';
import { ProFeatureGate } from './ProFeatureGate';
import { VipCrownArtwork } from './AliTraderBrand';
import { CoinSearchSelect } from './CoinSearchSelect';

interface MarketOverviewProps {
  markets: UnifiedMarketTicker[];
  usdtTomanRate: number;
  selectedBaseAsset: string;
  selectedQuoteCurrency: QuoteCurrency;
  loading: boolean;
  balances: SpotBalance[];
  portfolioPerformance: PortfolioPerformanceSummary | null;
  alerts: PriceAlert[];
  recentOrders: SpotOrder[];
  recentMarketTrades: RecentTrade[];
  bots: BotStrategyConfig[];
  botLogs: BotExecutionLog[];
  executionMode: ExecutionMode;
  isAuthenticated: boolean;
  candles?: KlineCandle[];
  analysis?: IndicatorSnapshot | null;
  timeframe?: Timeframe;
  onTimeframeChange?: (tf: Timeframe) => void;
  loadingChart?: boolean;
  onSelectPair?: (baseAsset: string, quoteCurrency?: QuoteCurrency) => void;
  onToggleBotStatus?: (botId: string, nextStatus: 'RUNNING' | 'PAUSED') => Promise<void>;
  demoMode?: boolean;
  hasProAccess?: boolean;
  daysRemaining?: number;
  supportTelegram?: string;
  onOpenGuide?: (tab: 'GUIDE' | 'FAQ' | 'SUPPORT') => void;
  onOpenHistory?: () => void;
  onOpenWallet?: () => void;
  onSaveCostBasis: (asset: string, price: number, quoteCurrency: QuoteCurrency) => Promise<void>;
  onResetCostBasis: (asset: string) => Promise<void>;
  onCreateAlert: (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    condition: PriceAlertCondition;
    targetPrice: number;
    sendTelegram?: boolean;
    note?: string;
  }) => Promise<void>;
  onRearmAlert: (alertId: string) => Promise<void>;
  onDeleteAlert: (alertId: string) => Promise<void>;
  onQuoteCurrencyChange: (qc: QuoteCurrency) => void;
  onSelectForTrade: (baseAsset: string, quoteCurrency?: QuoteCurrency) => void;
  onSelectForAnalysis: (baseAsset: string) => void;
  onSelectForBot: (baseAsset: string, quoteCurrency?: QuoteCurrency) => void;
  onOpenSecurity: () => void;
  telegramConnected?: boolean;
  onOpenTelegramSettings?: () => void;
  supportPhone?: string;
  isAdmin?: boolean;
  pnlCalculatorUnlocked?: boolean;
  alertsUnlocked?: boolean;
  pnlPolicy?: ModuleAccessPolicy;
  alertsPolicy?: ModuleAccessPolicy;
  monthlyPriceToman?: number;
  monthlyPriceUsdt?: number;
  onSignIn?: () => Promise<void>;
  onOpenSubscription?: () => void;
  onEnterDemoMode?: () => void;
}

type FilterMode = 'ALL' | 'GAINERS' | 'LOSERS' | 'VOLUME';

const FEATURED_ASSETS = ['BTC', 'ETH', 'USDT', 'SOL', 'TON', 'TRX'];

export const MarketOverview: React.FC<MarketOverviewProps> = ({
  markets,
  usdtTomanRate,
  selectedBaseAsset,
  selectedQuoteCurrency,
  loading,
  balances,
  portfolioPerformance,
  alerts,
  recentOrders,
  recentMarketTrades,
  bots,
  botLogs,
  executionMode,
  isAuthenticated,
  candles = [],
  analysis = null,
  timeframe = '1h',
  onTimeframeChange = () => {},
  loadingChart = false,
  onSelectPair,
  onToggleBotStatus,
  demoMode = false,
  hasProAccess = false,
  daysRemaining = 0,
  supportTelegram = '',
  onOpenGuide,
  onOpenHistory,
  onOpenWallet,
  onSaveCostBasis,
  onResetCostBasis,
  onCreateAlert,
  onRearmAlert,
  onDeleteAlert,
  onQuoteCurrencyChange,
  onSelectForTrade,
  onSelectForAnalysis,
  onSelectForBot,
  onOpenSecurity,
  telegramConnected = false,
  onOpenTelegramSettings,
  supportPhone = '09999961279',
  isAdmin = false,
  pnlCalculatorUnlocked = true,
  alertsUnlocked = true,
  pnlPolicy = 'FREE',
  alertsPolicy = 'FREE',
  monthlyPriceToman = 950_000,
  monthlyPriceUsdt = 15,
  onSignIn = async () => {},
  onOpenSubscription = () => {},
  onEnterDemoMode,
}) => {
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<FilterMode>('ALL');
  const [activityTab, setActivityTab] = useState<'MY_TRADES' | 'MARKET_TRADES'>('MY_TRADES');
  const [selectedBotId, setSelectedBotId] = useState<string>('');
  const [togglingBot, setTogglingBot] = useState(false);
  const [pendingLiveConfirmBotId, setPendingLiveConfirmBotId] = useState<string | null>(null);
  const [botControlMsg, setBotControlMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    if (bots.length === 0) {
      setSelectedBotId('');
      return;
    }
    if (!selectedBotId || !bots.some((b) => b.id === selectedBotId)) {
      const running = bots.find((b) => b.status === 'RUNNING');
      setSelectedBotId((running || bots[0]).id);
    }
  }, [bots, selectedBotId]);

  const activeBot = useMemo(
    () => bots.find((b) => b.id === selectedBotId) || bots[0] || null,
    [bots, selectedBotId]
  );

  const portfolio = useMemo(() => {
    const totalToman = balances.reduce((s, b) => s + b.tomanValue, 0);
    const totalUsdt = balances.reduce((s, b) => s + b.usdtValue, 0);
    const freeToman = balances.find((b) => b.asset === 'IRT')?.free || 0;
    const freeUsdt = balances.find((b) => b.asset === 'USDT')?.free || 0;
    const runningBots = bots.filter((b) => b.status === 'RUNNING').length;
    const pnlToman = bots.reduce((s, b) => {
      if (b.quoteCurrency === 'IRT') return s + b.stats.realizedPnl;
      return s + b.stats.realizedPnl * usdtTomanRate;
    }, 0);
    const pnlUsdt = usdtTomanRate > 0 ? pnlToman / usdtTomanRate : 0;
    const botCapitalToman = bots.reduce((s, b) => {
      return s + (b.quoteCurrency === 'IRT' ? b.orderAmount : b.orderAmount * usdtTomanRate);
    }, 0);
    const botTradesTotal = bots.reduce((s, b) => s + (b.stats?.totalTrades || 0), 0);
    const pnlPercent =
      portfolioPerformance && portfolioPerformance.cryptoCostBasisToman > 0
        ? portfolioPerformance.cryptoPnlPercentToman
        : botCapitalToman > 0
          ? (pnlToman / botCapitalToman) * 100
          : 0;
    return {
      totalToman,
      totalUsdt,
      freeToman,
      freeUsdt,
      runningBots,
      pnlToman,
      pnlUsdt,
      pnlPercent,
      botTradesTotal,
    };
  }, [balances, bots, usdtTomanRate, portfolioPerformance]);

  const totalTradesCount = Math.max(recentOrders.length, portfolio.botTradesTotal);

  const topCoins = useMemo(() => {
    const bySymbol = new Map(markets.map((m) => [m.baseAsset, m]));
    const picked: UnifiedMarketTicker[] = [];
    for (const sym of FEATURED_ASSETS) {
      const m = bySymbol.get(sym);
      if (m) picked.push(m);
    }
    if (picked.length < 5) {
      for (const m of markets) {
        if (!picked.some((p) => p.baseAsset === m.baseAsset)) {
          picked.push(m);
        }
        if (picked.length >= 5) break;
      }
    }
    return picked;
  }, [markets]);

  const marketPulse = useMemo(() => {
    const totalVolToman = markets.reduce((acc, m) => acc + m.volumeToman, 0);
    const totalVolUsdt = usdtTomanRate > 0 ? totalVolToman / usdtTomanRate : 0;
    const gainers = markets.filter((m) => m.change24hPercent > 0).length;
    const losers = markets.filter((m) => m.change24hPercent < 0).length;
    return { totalVolToman, totalVolUsdt, gainers, losers };
  }, [markets, usdtTomanRate]);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    let list = markets.filter((m) => {
      const supportsQuote = selectedQuoteCurrency === 'IRT' ? m.hasIrtMarket : m.hasUsdtMarket;
      if (!supportsQuote) return false;
      return (
        !q ||
        m.baseAsset.toLowerCase().includes(q) ||
        m.persianName.toLowerCase().includes(q) ||
        m.symbolIrt.toLowerCase().includes(q)
      );
    });

    if (filter === 'GAINERS') {
      list = list.slice().sort((a, b) => b.change24hPercent - a.change24hPercent);
    } else if (filter === 'LOSERS') {
      list = list.slice().sort((a, b) => a.change24hPercent - b.change24hPercent);
    } else if (filter === 'VOLUME') {
      list = list.slice().sort((a, b) => b.volumeToman - a.volumeToman);
    }
    return list;
  }, [markets, search, filter, selectedQuoteCurrency]);

  const handleSelectChartPair = (base: string, qc?: QuoteCurrency) => {
    if (onSelectPair) {
      onSelectPair(base, qc);
    } else {
      onSelectForTrade(base, qc);
    }
  };

  const handleQuickBotStart = async () => {
    setBotControlMsg(null);
    if (!isAuthenticated && !demoMode) {
      onOpenSecurity();
      return;
    }
    if (!activeBot) {
      onSelectForBot(selectedBaseAsset, selectedQuoteCurrency);
      return;
    }
    if (activeBot.status === 'RUNNING') {
      setBotControlMsg({
        type: 'ok',
        text: `ربات «${activeBot.name}» هم‌اکنون در حال پایش و اجرا است.`,
      });
      return;
    }
    if (activeBot.mode === 'live' && !demoMode && pendingLiveConfirmBotId !== activeBot.id) {
      setPendingLiveConfirmBotId(activeBot.id);
      return;
    }
    if (!onToggleBotStatus) {
      onSelectForBot(activeBot.baseAsset, activeBot.quoteCurrency);
      return;
    }
    setTogglingBot(true);
    try {
      await onToggleBotStatus(activeBot.id, 'RUNNING');
      setPendingLiveConfirmBotId(null);
      setBotControlMsg({
        type: 'ok',
        text: `ربات «${activeBot.name}» با موفقیت فعال شد.`,
      });
    } catch (err) {
      setBotControlMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در شروع ربات',
      });
    } finally {
      setTogglingBot(false);
    }
  };

  const handleQuickBotStop = async () => {
    setBotControlMsg(null);
    setPendingLiveConfirmBotId(null);
    if (!isAuthenticated && !demoMode) {
      onOpenSecurity();
      return;
    }
    if (!activeBot) {
      onSelectForBot(selectedBaseAsset, selectedQuoteCurrency);
      return;
    }
    if (activeBot.status === 'PAUSED') {
      setBotControlMsg({ type: 'ok', text: `ربات «${activeBot.name}» از قبل متوقف است.` });
      return;
    }
    if (!onToggleBotStatus) return;
    setTogglingBot(true);
    try {
      await onToggleBotStatus(activeBot.id, 'PAUSED');
      setBotControlMsg({
        type: 'ok',
        text: `ربات «${activeBot.name}» متوقف شد.`,
      });
    } catch (err) {
      setBotControlMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در توقف ربات',
      });
    } finally {
      setTogglingBot(false);
    }
  };

  // Account Stats Donut calculations (100% real data)
  const cryptoSharePct = useMemo(() => {
    if (portfolio.totalToman <= 0) return 0;
    const cashTotalToman =
      portfolio.freeToman + portfolio.freeUsdt * (usdtTomanRate > 0 ? usdtTomanRate : 0);
    const cryptoVal = Math.max(0, portfolio.totalToman - cashTotalToman);
    return Math.min(100, Math.max(0, (cryptoVal / portfolio.totalToman) * 100));
  }, [portfolio, usdtTomanRate]);

  const floatingPnlToman = portfolioPerformance?.cryptoPnlToman ?? portfolio.pnlToman;
  const floatingPnlUsdt = portfolioPerformance?.cryptoPnlUsdt ?? portfolio.pnlUsdt;
  const growthPercent = portfolio.pnlPercent;

  const donutRadius = 46;
  const donutCirc = 2 * Math.PI * donutRadius;
  const donutFilled =
    portfolio.totalToman > 0
      ? Math.max(donutCirc * 0.12, (Math.max(cryptoSharePct, 25) / 100) * donutCirc)
      : 0;

  const cleanSupportTelegram = (supportTelegram || '').replace(/^@/, '').trim();

  return (
    <div className="space-y-4 sm:space-y-5">
      {/* Row 1: 4 Colored Frosted Glass KPI Cards (Right-to-Left in RTL matching reference screenshot: Amber -> Emerald -> Blue -> Purple) */}
      <section aria-label="کارت‌های آماری حساب و ربات" className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* Card 1 (Visual Right): Bot Status (Amber Glass) */}
        <button
          type="button"
          onClick={() => onSelectForBot(selectedBaseAsset, selectedQuoteCurrency)}
          className="kpi-glass-amber rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-3 text-right transition-transform duration-200 hover:-translate-y-0.5"
        >
          <div className="space-y-1.5 min-w-0">
            <div className="text-xs text-amber-100/85">وضعیت ربات</div>
            <div className="flex items-center gap-2">
              <span
                className={`w-2.5 h-2.5 rounded-full shrink-0 ${
                  portfolio.runningBots > 0
                    ? 'bg-emerald-400 shadow-[0_0_10px_#34d399]'
                    : bots.length > 0
                      ? 'bg-amber-400'
                      : 'bg-slate-500'
                }`}
              />
              <span
                className={`text-lg font-bold ${
                  portfolio.runningBots > 0
                    ? 'text-emerald-300'
                    : bots.length > 0
                      ? 'text-amber-200'
                      : 'text-slate-300'
                }`}
              >
                {portfolio.runningBots > 0
                  ? 'فعال'
                  : bots.length > 0
                    ? 'متوقف'
                    : 'آماده ساخت'}
              </span>
            </div>
            <div className="text-[11px] text-amber-100/75">
              {bots.length > 0
                ? `${portfolio.runningBots} فعال از ${bots.length} ربات`
                : 'ساخت اولین ربات هوشمند'}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-amber-400/20 border border-amber-300/40 flex items-center justify-center shrink-0">
            <Bot className="w-6 h-6 text-amber-200" />
          </div>
        </button>

        {/* Card 2 (Second from Right): Trade Count (Emerald Glass) */}
        <button
          type="button"
          onClick={() => (onOpenHistory ? onOpenHistory() : onSelectForTrade(selectedBaseAsset, selectedQuoteCurrency))}
          className="kpi-glass-emerald rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-3 text-right transition-transform duration-200 hover:-translate-y-0.5"
        >
          <div className="space-y-1 min-w-0">
            <div className="text-xs text-emerald-100/85">تعداد معاملات</div>
            <div className="text-2xl font-bold font-mono-num text-white" dir="ltr">
              {totalTradesCount.toLocaleString('en-US')}
            </div>
            <div className="text-[11px] text-emerald-200/80">
              {recentOrders.length > 0
                ? `${recentOrders.length} سفارش ثبت‌شده`
                : 'بدون معامله ثبت‌شده'}
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-400/20 border border-emerald-300/35 flex items-center justify-center shrink-0">
            <BarChart3 className="w-6 h-6 text-emerald-200" />
          </div>
        </button>

        {/* Card 3 (Third from Right): Account Balance (Royal Blue Glass) */}
        <button
          type="button"
          onClick={() => (onOpenWallet ? onOpenWallet() : onSelectForTrade(selectedBaseAsset, selectedQuoteCurrency))}
          className="kpi-glass-blue rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-3 text-right transition-transform duration-200 hover:-translate-y-0.5"
        >
          <div className="space-y-1 min-w-0">
            <div className="flex items-center gap-1.5 text-xs text-sky-100/85">
              <span>موجودی حساب</span>
              <span className="text-[10px] text-sky-200/75">
                {demoMode ? '(دمو)' : executionMode === 'live' ? '(واقعی)' : '(آزمایشی)'}
              </span>
            </div>
            {!isAuthenticated && !demoMode && portfolio.totalToman === 0 ? (
              <div className="text-sm font-semibold text-cyan-200 pt-1">
                ورود برای نمایش
              </div>
            ) : (
              <>
                <div className="text-xl sm:text-2xl font-bold font-mono-num text-white truncate" dir="ltr">
                  {selectedQuoteCurrency === 'IRT'
                    ? formatToman(portfolio.totalToman)
                    : `$${portfolio.totalUsdt.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
                </div>
                <div className="text-xs font-mono-num text-cyan-200/85 truncate" dir="ltr">
                  {selectedQuoteCurrency === 'IRT'
                    ? `≈ $${portfolio.totalUsdt.toFixed(2)} USDT`
                    : `≈ ${formatToman(portfolio.totalToman)} تومان`}
                </div>
              </>
            )}
          </div>
          <div className="w-12 h-12 rounded-2xl bg-sky-400/20 border border-sky-300/35 flex items-center justify-center shrink-0">
            <Wallet className="w-6 h-6 text-sky-200" />
          </div>
        </button>

        {/* Card 4 (Visual Left): Total PnL (Purple Glass) */}
        <div className="kpi-glass-purple rounded-2xl p-4 sm:p-5 flex items-center justify-between gap-3">
          <div className="space-y-1 min-w-0">
            <div className="flex items-center gap-1.5 text-xs text-purple-100/85">
              <span>سود کل ({selectedQuoteCurrency === 'IRT' ? 'تومان' : 'USDT'})</span>
              {demoMode && (
                <span className="px-1.5 py-0.5 rounded bg-purple-400/20 text-[10px] text-purple-200">
                  دمو
                </span>
              )}
            </div>
            <div
              className={`text-xl sm:text-2xl font-bold font-mono-num truncate ${
                portfolio.pnlToman >= 0 ? 'text-emerald-300' : 'text-rose-300'
              }`}
              dir="ltr"
            >
              {selectedQuoteCurrency === 'IRT'
                ? `${portfolio.pnlToman >= 0 ? '+' : '-'}${formatToman(Math.abs(portfolio.pnlToman))}`
                : `${portfolio.pnlUsdt >= 0 ? '+' : '-'}$${Math.abs(portfolio.pnlUsdt).toFixed(2)}`}
            </div>
            <div className="flex items-center gap-1.5 text-xs font-mono-num" dir="ltr">
              <span className={growthPercent >= 0 ? 'text-emerald-300' : 'text-rose-300'}>
                {growthPercent >= 0 ? '↗ +' : '↘ '}
                {Math.abs(growthPercent).toFixed(1)}%
              </span>
              <span className="text-purple-200/65 text-[11px] font-sans">
                {selectedQuoteCurrency === 'IRT'
                  ? `($${Math.abs(portfolio.pnlUsdt).toFixed(2)})`
                  : `(${formatToman(Math.abs(portfolio.pnlToman))} ت)`}
              </span>
            </div>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-purple-400/20 border border-purple-300/35 flex items-center justify-center shrink-0">
            <TrendingUp className="w-6 h-6 text-purple-200" />
          </div>
        </div>
      </section>

      {/* Row 2: Quick Bot Control (Visual Right in RTL) + Nobitex Candlestick Chart (Visual Left in RTL) */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Visual Right (lg+): Quick Bot Control Panel */}
        <div className="lg:col-span-3 order-2 lg:order-1 glass-panel rounded-2xl p-5 flex flex-col justify-between gap-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-base font-bold text-white">کنترل سریع ربات</h3>
              {activeBot ? (
                <span
                  className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-lg text-[10px] font-semibold border ${
                    activeBot.mode === 'live' && !demoMode
                      ? 'bg-rose-500/15 border-rose-400/40 text-rose-200'
                      : 'bg-cyan-500/15 border-cyan-400/35 text-cyan-200'
                  }`}
                >
                  <span
                    className={`w-1.5 h-1.5 rounded-full ${
                      activeBot.status === 'RUNNING' ? 'bg-emerald-400' : 'bg-slate-400'
                    }`}
                  />
                  <span>
                    {demoMode
                      ? 'دمو'
                      : activeBot.mode === 'live'
                        ? 'واقعی'
                        : 'آزمایشی'}
                  </span>
                </span>
              ) : (
                <span className="text-[11px] text-slate-400">بدون ربات</span>
              )}
            </div>

            {bots.length > 0 && (
              <select
                aria-label="انتخاب ربات برای کنترل سریع"
                value={activeBot?.id || ''}
                onChange={(e) => {
                  setSelectedBotId(e.target.value);
                  setPendingLiveConfirmBotId(null);
                  setBotControlMsg(null);
                }}
                className="w-full bg-slate-950/85 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 focus:outline-none focus:border-cyan-400"
              >
                {bots.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name} — {b.symbol} ({b.status === 'RUNNING' ? 'فعال' : 'متوقف'})
                  </option>
                ))}
              </select>
            )}
          </div>

          {/* Center Glowing Neon Orb Button */}
          <div className="flex flex-col items-center justify-center py-2 space-y-3">
            <button
              type="button"
              disabled={togglingBot}
              onClick={() => void handleQuickBotStart()}
              className={`bot-orb-button w-32 h-32 rounded-full flex flex-col items-center justify-center gap-1.5 cursor-pointer disabled:opacity-60 ${
                activeBot?.status === 'RUNNING' ? 'is-running' : ''
              }`}
              aria-label={activeBot?.status === 'RUNNING' ? 'ربات در حال اجرا است' : 'شروع ربات'}
            >
              {activeBot?.status === 'RUNNING' ? (
                <Activity className="w-10 h-10 text-emerald-300" />
              ) : (
                <Play className="w-10 h-10 text-cyan-200 fill-cyan-300/85 translate-x-0.5" />
              )}
            </button>

            <div className="text-center space-y-0.5">
              <div
                className={`text-sm font-bold ${
                  activeBot?.status === 'RUNNING' ? 'text-emerald-300' : 'text-cyan-300'
                }`}
              >
                {togglingBot
                  ? 'در حال ارسال دستور...'
                  : activeBot?.status === 'RUNNING'
                    ? 'ربات در حال اجراست'
                    : activeBot
                      ? 'شروع ربات'
                      : 'ساخت و شروع ربات'}
              </div>
              {activeBot && (
                <div className="text-[11px] text-slate-400 font-mono-num" dir="ltr">
                  {activeBot.symbol} · {activeBot.timeframe}
                </div>
              )}
            </div>
          </div>

          {/* Explicit Confirmation Banner when activating a LIVE bot */}
          {pendingLiveConfirmBotId && activeBot && (
            <div className="rounded-xl border border-rose-500/45 bg-rose-500/15 p-3 text-xs space-y-2">
              <div className="flex items-start gap-2 text-rose-100">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                <span>
                  این ربات روی <strong>حساب واقعی (Live)</strong> تنظیم شده است. آیا شروع معاملات واقعی را تأیید می‌کنید؟
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => void handleQuickBotStart()}
                  className="btn-glass btn-glass-sell flex-1 py-1.5 rounded-lg font-semibold"
                >
                  تأیید و شروع واقعی
                </button>
                <button
                  type="button"
                  onClick={() => setPendingLiveConfirmBotId(null)}
                  className="btn-glass btn-glass-neutral px-3 py-1.5 rounded-lg"
                >
                  انصراف
                </button>
              </div>
            </div>
          )}

          {botControlMsg && (
            <div
              className={`rounded-xl px-3 py-2 text-[11px] border ${
                botControlMsg.type === 'ok'
                  ? 'bg-emerald-500/10 border-emerald-500/35 text-emerald-200'
                  : 'bg-rose-500/10 border-rose-500/35 text-rose-200'
              }`}
            >
              {botControlMsg.text}
            </div>
          )}

          {/* Action Buttons Stack matching reference */}
          <div className="space-y-2.5">
            <button
              type="button"
              disabled={togglingBot || !activeBot || activeBot.status !== 'RUNNING'}
              onClick={() => void handleQuickBotStop()}
              className="btn-glass btn-glass-neutral w-full py-2.5 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2"
            >
              <Pause className="w-4 h-4 text-amber-300" />
              <span>توقف ربات</span>
            </button>

            <button
              type="button"
              onClick={() =>
                onSelectForBot(
                  activeBot?.baseAsset || selectedBaseAsset,
                  activeBot?.quoteCurrency || selectedQuoteCurrency
                )
              }
              className="btn-glass btn-glass-primary w-full py-2.5 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2"
            >
              <Settings2 className="w-4 h-4" />
              <span>تنظیمات پیشرفته</span>
            </button>
          </div>
        </div>

        {/* Visual Left (lg+): Nobitex Live Candlestick Chart */}
        <div className="lg:col-span-9 order-1 lg:order-2">
          <CandlestickChart
            symbol={`${selectedBaseAsset}${selectedQuoteCurrency}`}
            timeframe={timeframe}
            onTimeframeChange={onTimeframeChange}
            candles={candles}
            analysis={analysis}
            loading={loadingChart}
            chartTitle="نمودار قیمت نوبیتکس"
            rightSlot={
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => onSelectForAnalysis(selectedBaseAsset)}
                  className="btn-glass btn-glass-ai px-2.5 py-1.5 rounded-xl text-[11px] font-semibold inline-flex items-center gap-1 whitespace-nowrap shrink-0"
                  title="گپ خودمونی و تحلیل هوش مصنوعی درباره این ارز"
                >
                  <BrainCircuit className="w-3.5 h-3.5 text-cyan-300" />
                  <span>از من بپرس!</span>
                </button>
                <div className="w-44 sm:w-52">
                  <CoinSearchSelect
                    markets={markets}
                    value={selectedBaseAsset}
                    onChange={(nextBase) => handleSelectChartPair(nextBase, selectedQuoteCurrency)}
                    quoteCurrency={selectedQuoteCurrency}
                    size="sm"
                    ariaLabel="جستجو و انتخاب ارز نمودار"
                  />
                </div>
                <div className="flex items-center gap-0.5 bg-slate-950/85 p-0.5 rounded-xl border border-slate-800/80 text-[11px]">
                  <button
                    type="button"
                    onClick={() => onQuoteCurrencyChange('IRT')}
                    className={`px-2 py-1 rounded-lg font-medium ${
                      selectedQuoteCurrency === 'IRT'
                        ? 'bg-amber-500/25 text-amber-200 border border-amber-400/40'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    IRT
                  </button>
                  <button
                    type="button"
                    onClick={() => onQuoteCurrencyChange('USDT')}
                    className={`px-2 py-1 rounded-lg font-medium ${
                      selectedQuoteCurrency === 'USDT'
                        ? 'bg-cyan-500/25 text-cyan-200 border border-cyan-400/40'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    USDT
                  </button>
                </div>
              </div>
            }
          />
        </div>
      </section>

      {/* Row 3: 3-Column Bento Analytics (Right: Coin Prices | Middle: Account Stats | Left: Recent Trades) */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Column 1 (Visual Right): Live Nobitex Coin Prices */}
        <div className="lg:col-span-4 glass-panel rounded-2xl overflow-hidden flex flex-col">
          <div className="px-4 py-3 border-b border-slate-800/80 bg-[#050C1D]/75 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-cyan-300" />
              <span>قیمت ارزها</span>
            </h3>
            <span className="text-[11px] font-mono-num text-amber-300" dir="ltr">
              USDT: {formatToman(usdtTomanRate)} ت
            </span>
          </div>

          <div className="divide-y divide-slate-800/65 flex-1">
            {topCoins.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                در حال دریافت نرخ لحظه‌ای از نوبیتکس...
              </div>
            ) : (
              topCoins.map((m) => {
                const isUp = m.change24hPercent >= 0;
                const isSelected = m.baseAsset === selectedBaseAsset;
                return (
                  <button
                    key={m.baseAsset}
                    type="button"
                    onClick={() => handleSelectChartPair(m.baseAsset, selectedQuoteCurrency)}
                    className={`w-full px-4 py-3 flex items-center justify-between gap-3 text-right transition-colors hover:bg-slate-900/65 ${
                      isSelected ? 'bg-cyan-500/10' : ''
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-cyan-500/15 border border-cyan-400/35 flex items-center justify-center font-mono-num text-[11px] font-bold text-cyan-200 shrink-0">
                        {m.baseAsset.slice(0, 3)}
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-semibold text-white truncate">
                          {m.persianName}{' '}
                          <span className="font-mono-num text-slate-400">({m.baseAsset})</span>
                        </div>
                        <div className="text-[11px] text-amber-300/85 font-mono-num" dir="ltr">
                          {formatToman(m.priceToman)} تومان
                        </div>
                      </div>
                    </div>

                    <div className="text-left font-mono-num shrink-0" dir="ltr">
                      <div className="text-xs font-semibold text-white">
                        ${formatPrice(m.priceUsdt)}
                      </div>
                      <div
                        className={`text-[11px] font-medium ${
                          isUp ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {formatPercent(m.change24hPercent)}
                      </div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>

        {/* Column 2 (Visual Middle): Account Statistics Donut Ring */}
        <div className="lg:col-span-3 glass-panel rounded-2xl p-4 sm:p-5 flex flex-col justify-between gap-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">آمار حساب</h3>
            <span className="w-8 h-8 rounded-xl bg-cyan-500/15 border border-cyan-400/30 flex items-center justify-center">
              <BarChart3 className="w-4 h-4 text-cyan-300" />
            </span>
          </div>

          <div className="flex items-center justify-center">
            <div className="relative w-32 h-32 flex items-center justify-center">
              <svg viewBox="0 0 116 116" className="w-full h-full -rotate-90">
                <defs>
                  <linearGradient id="accountDonutGrad" x1="0" y1="0" x2="116" y2="116" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="#10B981" />
                    <stop offset="55%" stopColor="#06B6D4" />
                    <stop offset="100%" stopColor="#3B82F6" />
                  </linearGradient>
                </defs>
                <circle
                  cx="58"
                  cy="58"
                  r={donutRadius}
                  fill="none"
                  stroke="rgba(30, 41, 59, 0.85)"
                  strokeWidth="12"
                />
                {donutFilled > 0 && (
                  <circle
                    cx="58"
                    cy="58"
                    r={donutRadius}
                    fill="none"
                    stroke="url(#accountDonutGrad)"
                    strokeWidth="12"
                    strokeLinecap="round"
                    strokeDasharray={`${donutFilled} ${donutCirc}`}
                  />
                )}
              </svg>
              <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-2">
                <span className="text-sm font-bold font-mono-num text-white" dir="ltr">
                  {selectedQuoteCurrency === 'IRT'
                    ? formatCompactToman(portfolio.totalToman).replace(' تومان', '')
                    : `$${portfolio.totalUsdt.toFixed(0)}`}
                </span>
                <span className="text-[10px] text-slate-400">
                  {selectedQuoteCurrency === 'IRT' ? 'تومان' : 'تتر'}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-2.5 text-xs border-t border-slate-800/70 pt-3">
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-400">موجودی نقدی</span>
              <span className="font-mono-num font-semibold text-white" dir="ltr">
                {selectedQuoteCurrency === 'IRT'
                  ? `${formatToman(portfolio.freeToman)} ت`
                  : `$${portfolio.freeUsdt.toFixed(2)}`}
              </span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-400">سود شناور</span>
              <span
                className={`font-mono-num font-semibold ${
                  floatingPnlToman >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
                dir="ltr"
              >
                {selectedQuoteCurrency === 'IRT'
                  ? `${floatingPnlToman >= 0 ? '+' : '-'}${formatToman(Math.abs(floatingPnlToman))}`
                  : `${floatingPnlUsdt >= 0 ? '+' : '-'}$${Math.abs(floatingPnlUsdt).toFixed(2)}`}
              </span>
            </div>
            <div className="flex items-center justify-between gap-2">
              <span className="text-slate-400">درصد رشد</span>
              <span
                className={`font-mono-num font-semibold ${
                  growthPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
                dir="ltr"
              >
                {growthPercent >= 0 ? '+' : ''}
                {growthPercent.toFixed(2)}%
              </span>
            </div>
          </div>
        </div>

        {/* Column 3 (Visual Left): Recent Trades Table */}
        <div className="lg:col-span-5 glass-panel rounded-2xl overflow-hidden flex flex-col">
          <div className="px-4 py-3 border-b border-slate-800/80 bg-[#050C1D]/75 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-bold text-white">آخرین معاملات</h3>
              {demoMode && (
                <span className="px-2 py-0.5 rounded-md bg-cyan-500/15 border border-cyan-400/35 text-[10px] text-cyan-200">
                  دمو
                </span>
              )}
            </div>
            <div className="flex items-center gap-1 bg-slate-950/80 p-0.5 rounded-xl border border-slate-800 text-[11px]">
              <button
                type="button"
                onClick={() => setActivityTab('MY_TRADES')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  activityTab === 'MY_TRADES'
                    ? 'bg-cyan-500/20 text-cyan-200'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                حساب و ربات
              </button>
              <button
                type="button"
                onClick={() => setActivityTab('MARKET_TRADES')}
                className={`px-2.5 py-1 rounded-lg font-medium transition-colors ${
                  activityTab === 'MARKET_TRADES'
                    ? 'bg-cyan-500/20 text-cyan-200'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                بازار زنده
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-x-auto">
            {activityTab === 'MY_TRADES' ? (
              recentOrders.length === 0 ? (
                <div className="p-8 text-center space-y-2 text-xs text-slate-400">
                  <p>هنوز معامله‌ای در حساب شما ثبت نشده است.</p>
                  <button
                    type="button"
                    onClick={() => onSelectForTrade(selectedBaseAsset, selectedQuoteCurrency)}
                    className="btn-glass btn-glass-primary px-3 py-1.5 rounded-lg font-semibold inline-flex items-center gap-1"
                  >
                    <span>ثبت اولین معامله</span>
                    <ArrowLeft className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <table className="w-full text-right border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-slate-800/80 text-slate-400 bg-[#050C1B]/50">
                      <th className="py-2.5 px-3 font-medium">نوع</th>
                      <th className="py-2.5 px-3 font-medium">قیمت</th>
                      <th className="py-2.5 px-3 font-medium">مقدار</th>
                      <th className="py-2.5 px-3 font-medium text-left">زمان</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60">
                    {recentOrders.slice(0, 6).map((ord) => (
                      <tr key={ord.orderId} className="hover:bg-slate-900/50 transition-colors">
                        <td className="py-2.5 px-3">
                          <span
                            className={`inline-flex items-center gap-1 font-semibold ${
                              ord.side === 'BUY' ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            {ord.side === 'BUY' ? (
                              <ArrowUpRight className="w-3.5 h-3.5" />
                            ) : (
                              <ArrowDownRight className="w-3.5 h-3.5" />
                            )}
                            <span>{ord.side === 'BUY' ? 'خرید' : 'فروش'}</span>
                          </span>
                          <div className="text-[10px] text-slate-500 font-mono-num">{ord.baseAsset}</div>
                        </td>
                        <td className="py-2.5 px-3 font-mono-num text-slate-100" dir="ltr">
                          {formatQuotePrice(ord.price, ord.quoteCurrency)}
                        </td>
                        <td className="py-2.5 px-3 font-mono-num text-slate-300" dir="ltr">
                          {formatQty(ord.quantity)}
                        </td>
                        <td className="py-2.5 px-3 text-left font-mono-num text-slate-400">
                          {formatTimeShort(ord.createdAt)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )
            ) : recentMarketTrades.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-400">
                در حال دریافت معاملات زنده نوبیتکس...
              </div>
            ) : (
              <table className="w-full text-right border-collapse text-xs">
                <thead>
                  <tr className="border-b border-slate-800/80 text-slate-400 bg-[#050C1B]/50">
                    <th className="py-2.5 px-3 font-medium">نوع</th>
                    <th className="py-2.5 px-3 font-medium">قیمت ({selectedQuoteCurrency})</th>
                    <th className="py-2.5 px-3 font-medium">مقدار</th>
                    <th className="py-2.5 px-3 font-medium text-left">زمان</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {recentMarketTrades.slice(0, 6).map((tr) => (
                    <tr key={tr.id} className="hover:bg-slate-900/50 transition-colors">
                      <td className="py-2.5 px-3">
                        <span
                          className={`inline-flex items-center gap-1 font-semibold ${
                            tr.isBuyerMaker ? 'text-rose-400' : 'text-emerald-400'
                          }`}
                        >
                          {tr.isBuyerMaker ? 'فروش' : 'خرید'}
                        </span>
                      </td>
                      <td className="py-2.5 px-3 font-mono-num text-slate-100" dir="ltr">
                        {formatQuotePrice(tr.price, selectedQuoteCurrency)}
                      </td>
                      <td className="py-2.5 px-3 font-mono-num text-slate-300" dir="ltr">
                        {formatQty(tr.quantity)}
                      </td>
                      <td className="py-2.5 px-3 text-left font-mono-num text-slate-400">
                        {formatTimeShort(tr.time)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>

          {onOpenHistory && (
            <div className="px-4 py-2.5 border-t border-slate-800/70 bg-[#050C1B]/50 flex items-center justify-between text-[11px]">
              <span className="text-slate-400">
                {botLogs.length > 0 ? `${botLogs.length} گزارش اجرای ربات` : 'گزارش لحظه‌ای سفارش‌ها'}
              </span>
              <button
                type="button"
                onClick={onOpenHistory}
                className="text-cyan-300 hover:text-cyan-200 font-semibold inline-flex items-center gap-1"
              >
                <span>تاریخچه کامل</span>
                <ArrowLeft className="w-3 h-3" />
              </button>
            </div>
          )}
        </div>
      </section>

      {/* Row 4: Right: Support & Quick Access 4-Orb Card | Left: VIP Upgrade Banner */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
        {/* Visual Right: Support & Quick Access 4-Orb Card */}
        <div className="lg:col-span-5 glass-panel rounded-2xl p-5 flex flex-col justify-between gap-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm sm:text-base font-bold text-white">پشتیبانی و دسترسی سریع</h3>
            <span className="text-[11px] font-mono-num text-cyan-300" dir="ltr">
              {supportPhone}
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-1">
            <a
              href={`tel:${supportPhone}`}
              className="group flex flex-col items-center gap-2 text-center"
            >
              <span className="w-12 h-12 rounded-full bg-cyan-500/15 border-2 border-cyan-400/55 flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.2)] transition-transform duration-200 group-hover:scale-105 group-hover:border-cyan-300">
                <Phone className="w-5 h-5 text-cyan-300" />
              </span>
              <span className="text-xs text-slate-200 font-medium">تماس با ما</span>
            </a>

            <button
              type="button"
              onClick={() => (onOpenGuide ? onOpenGuide('FAQ') : onOpenSecurity())}
              className="group flex flex-col items-center gap-2 text-center"
            >
              <span className="w-12 h-12 rounded-full bg-cyan-500/15 border-2 border-cyan-400/55 flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.2)] transition-transform duration-200 group-hover:scale-105 group-hover:border-cyan-300">
                <HelpCircle className="w-5 h-5 text-cyan-300" />
              </span>
              <span className="text-xs text-slate-200 font-medium">سوالات متداول</span>
            </button>

            <button
              type="button"
              onClick={() => (onOpenGuide ? onOpenGuide('GUIDE') : onOpenSecurity())}
              className="group flex flex-col items-center gap-2 text-center"
            >
              <span className="w-12 h-12 rounded-full bg-cyan-500/15 border-2 border-cyan-400/55 flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.2)] transition-transform duration-200 group-hover:scale-105 group-hover:border-cyan-300">
                <BookOpen className="w-5 h-5 text-cyan-300" />
              </span>
              <span className="text-xs text-slate-200 font-medium">راهنمای کامل</span>
            </button>

            {cleanSupportTelegram ? (
              <a
                href={`https://t.me/${cleanSupportTelegram}`}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex flex-col items-center gap-2 text-center"
              >
                <span className="w-12 h-12 rounded-full bg-cyan-500/15 border-2 border-cyan-400/55 flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.2)] transition-transform duration-200 group-hover:scale-105 group-hover:border-cyan-300">
                  <Send className="w-5 h-5 text-cyan-300" />
                </span>
                <span className="text-xs text-slate-200 font-medium">تلگرام ربات</span>
              </a>
            ) : (
              <button
                type="button"
                onClick={() => (onOpenTelegramSettings ? onOpenTelegramSettings() : onOpenSecurity())}
                className="group flex flex-col items-center gap-2 text-center"
              >
                <span className="w-12 h-12 rounded-full bg-cyan-500/15 border-2 border-cyan-400/55 flex items-center justify-center shadow-[0_0_20px_rgba(34,211,238,0.2)] transition-transform duration-200 group-hover:scale-105 group-hover:border-cyan-300">
                  <Send className="w-5 h-5 text-cyan-300" />
                </span>
                <span className="text-xs text-slate-200 font-medium">تلگرام ربات</span>
              </button>
            )}
          </div>
        </div>

        {/* Visual Left: VIP Trader Pro Banner */}
        <div className="lg:col-span-7 vip-glass-gold rounded-2xl p-5 flex flex-col sm:flex-row items-center justify-between gap-4 overflow-hidden">
          <div className="space-y-2.5 text-center sm:text-right">
            <div className="inline-flex items-center gap-2 text-amber-300">
              <span className="text-base sm:text-lg font-bold text-amber-200">
                نسخه ویژه تریدر حرفه‌ای
              </span>
            </div>
            {hasProAccess ? (
              <p className="text-xs sm:text-sm text-amber-100/90 leading-relaxed max-w-md">
                اشتراک حرفه‌ای شما فعال است
                {daysRemaining > 0 ? ` (${daysRemaining} روز باقی‌مانده)` : ''}. تمامی ابزارهای ربات، هوش مصنوعی و گزارش تلگرام در دسترس است.
              </p>
            ) : (
              <p className="text-xs sm:text-sm text-amber-100/85 leading-relaxed max-w-md">
                با پلن‌های حرفه‌ای ({formatToman(monthlyPriceToman)} تومان / ${monthlyPriceUsdt} USDT ماهانه)، دسترسی نامحدود به ربات خودکار و تحلیل هوش مصنوعی دریافت کنید.
              </p>
            )}
            <div className="pt-1">
              <button
                type="button"
                onClick={onOpenSubscription}
                className="btn-glass btn-glass-amber inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-bold"
              >
                <span>{hasProAccess ? 'مدیریت اشتراک و دعوت دوستان' : 'مشاهده پلن‌ها'}</span>
                <ArrowLeft className="w-4 h-4" />
              </button>
            </div>
          </div>

          <VipCrownArtwork />
        </div>
      </section>

      {/* Live Nobitex Ticker Tape */}
      <LiveTickerTape
        markets={markets}
        selectedBaseAsset={selectedBaseAsset}
        quoteCurrency={selectedQuoteCurrency}
        onQuoteCurrencyChange={onQuoteCurrencyChange}
        onSelectCoin={(base, qc) => handleSelectChartPair(base, qc)}
      />

      {/* Portfolio Performance Detailed Breakdown */}
      <PortfolioPerformanceWidget
        performance={portfolioPerformance}
        loading={loading && !portfolioPerformance}
        quoteCurrency={selectedQuoteCurrency}
        onQuoteCurrencyChange={onQuoteCurrencyChange}
        onSaveCostBasis={onSaveCostBasis}
        onResetCostBasis={onResetCostBasis}
        onStartTrade={onSelectForTrade}
      />

      {/* Full Searchable Nobitex Markets & Wallet Distribution */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 items-start">
        <div className="xl:col-span-8 glass-panel rounded-2xl overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-3 border-b border-slate-800/80 bg-[#050C1D]/65">
            <div className="flex flex-wrap items-center gap-2">
              <div className="flex flex-wrap items-center gap-1 bg-slate-950/80 p-1 rounded-xl border border-slate-800/80">
                {(
                  [
                    { id: 'ALL', label: 'همه ارزهای نوبیتکس' },
                    { id: 'VOLUME', label: 'پرحجم‌ترین' },
                    { id: 'GAINERS', label: 'بیشترین رشد' },
                    { id: 'LOSERS', label: 'بیشترین افت' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setFilter(tab.id)}
                    className={`btn-glass px-2.5 py-1 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 ${
                      filter === tab.id
                        ? 'btn-glass-primary font-semibold'
                        : 'border border-transparent bg-transparent shadow-none text-slate-400 hover:text-slate-100'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <div className="text-[11px] font-mono-num text-slate-400 hidden sm:flex items-center gap-2" dir="ltr">
                <span className="text-emerald-400">{marketPulse.gainers}↑</span>
                <span>/</span>
                <span className="text-rose-400">{marketPulse.losers}↓</span>
                <span className="text-slate-500">· {formatCompactToman(marketPulse.totalVolToman)}</span>
              </div>
            </div>

            <div className="relative w-full sm:w-64">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="جستجو (بیت‌کوین، BTC، تون، سولانا...)"
                className="w-full bg-slate-950/90 border border-slate-800 rounded-xl pr-8 pl-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-400 bg-[#050C1B]">
                  <th className="py-2.5 px-4 font-medium">ارز (نوبیتکس)</th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    قیمت تومانی (IRT)
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    قیمت دلاری (USDT)
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    تغییر ۲۴h
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left hidden lg:table-cell">
                    حجم ۲۴h
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 text-xs">
                {loading && markets.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-12 text-center text-slate-400">
                      در حال دریافت قیمت‌های لحظه‌ای از صرافی نوبیتکس...
                    </td>
                  </tr>
                ) : filtered.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-10 text-center text-slate-400">
                      ارزی با این نام در نوبیتکس یافت نشد.
                    </td>
                  </tr>
                ) : (
                  filtered.map((m) => {
                    const isUp = m.change24hPercent >= 0;
                    return (
                      <tr
                        key={m.baseAsset}
                        className={`hover:bg-slate-900/60 transition-colors ${
                          selectedBaseAsset === m.baseAsset ? 'bg-cyan-500/10' : ''
                        }`}
                      >
                        <td className="py-2.5 px-4">
                          <button
                            type="button"
                            onClick={() => handleSelectChartPair(m.baseAsset, selectedQuoteCurrency)}
                            className="flex items-center gap-2 text-right hover:text-cyan-300"
                          >
                            <span className="font-mono-num font-semibold text-white">
                              {m.baseAsset}
                            </span>
                            <span className="text-slate-400 text-[11px]">{m.persianName}</span>
                          </button>
                        </td>

                        <td
                          className="py-2.5 px-4 text-left font-mono-num text-amber-300 font-medium"
                          dir="ltr"
                        >
                          {formatToman(m.priceToman)}{' '}
                          <span className="text-[10px] font-sans text-slate-400">ت</span>
                        </td>

                        <td className="py-2.5 px-4 text-left font-mono-num text-slate-100" dir="ltr">
                          ${formatPrice(m.priceUsdt)}
                        </td>

                        <td className="py-2.5 px-4 text-left font-mono-num" dir="ltr">
                          <span
                            className={`inline-flex items-center gap-0.5 font-medium ${
                              isUp ? 'text-emerald-400' : 'text-rose-400'
                            }`}
                          >
                            {isUp ? (
                              <ArrowUpRight className="w-3.5 h-3.5" />
                            ) : (
                              <ArrowDownRight className="w-3.5 h-3.5" />
                            )}
                            {formatPercent(m.change24hPercent)}
                          </span>
                        </td>

                        <td className="py-2.5 px-4 text-left font-mono-num text-slate-300 hidden lg:table-cell">
                          <div>{formatCompactToman(m.volumeToman)}</div>
                          <div className="text-[10px] text-slate-500" dir="ltr">
                            {formatCompactUsd(m.volumeUsdt)}
                          </div>
                        </td>

                        <td className="py-2.5 px-4 text-left">
                          <div className="flex items-center justify-end gap-1.5">
                            {m.hasIrtMarket && (
                              <button
                                type="button"
                                onClick={() => onSelectForTrade(m.baseAsset, 'IRT')}
                                className="btn-glass btn-glass-amber px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap shrink-0"
                                title="معامله با تومان"
                              >
                                تومانی
                              </button>
                            )}
                            {m.hasUsdtMarket && (
                              <button
                                type="button"
                                onClick={() => onSelectForTrade(m.baseAsset, 'USDT')}
                                className="btn-glass btn-glass-primary px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap shrink-0"
                                title="معامله با تتر (دلاری)"
                              >
                                تتری
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() => onSelectForAnalysis(m.baseAsset)}
                              className="btn-glass btn-glass-ai p-1.5 rounded-lg"
                              title="تحلیل ساده AI"
                            >
                              <BrainCircuit className="w-3.5 h-3.5 text-cyan-300" />
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                onSelectForBot(m.baseAsset, selectedQuoteCurrency)
                              }
                              className="btn-glass btn-glass-neutral p-1.5 rounded-lg"
                              title="ساخت ربات خودکار"
                            >
                              <Bot className="w-3.5 h-3.5 text-amber-300" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Wallet Asset Breakdown Side Card */}
        <div className="xl:col-span-4 space-y-6">
          <div className="glass-panel rounded-2xl overflow-hidden">
            <div className="px-4 py-3 border-b border-slate-800/80 bg-[#050C1D]/70 flex items-center justify-between">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-300" />
                <span>ترکیب دارایی‌های کیف پول</span>
              </h3>
              <span className="text-xs text-slate-400">{balances.length} دارایی</span>
            </div>
            <div className="divide-y divide-slate-800/70 text-xs">
              {balances.length === 0 ? (
                <div className="p-6 text-center space-y-2 text-slate-400">
                  <p>موجودی فعالی ثبت نشده است.</p>
                  {!isAuthenticated && !demoMode && (
                    <button
                      type="button"
                      onClick={onOpenSecurity}
                      className="btn-glass btn-glass-neutral inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs"
                    >
                      <ShieldCheck className="w-3.5 h-3.5 text-cyan-300" />
                      <span>ورود و اتصال کیف پول</span>
                    </button>
                  )}
                </div>
              ) : (
                balances.slice(0, 7).map((b) => {
                  const share =
                    portfolio.totalToman > 0 ? (b.tomanValue / portfolio.totalToman) * 100 : 0;
                  return (
                    <div key={b.asset} className="px-4 py-2.5 space-y-1.5">
                      <div className="flex items-center justify-between gap-2">
                        <div>
                          <span className="font-mono-num font-semibold text-white">{b.asset}</span>
                          {b.persianName && (
                            <span className="text-slate-500 text-[11px] mr-1.5">
                              ({b.persianName})
                            </span>
                          )}
                        </div>
                        <div className="font-mono-num text-left" dir="ltr">
                          <div className="text-amber-300 font-medium">
                            {formatToman(b.tomanValue)} ت
                          </div>
                          <div className="text-[11px] text-slate-400">
                            {formatQty(b.total)} · ${b.usdtValue.toFixed(2)}
                          </div>
                        </div>
                      </div>
                      <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-l from-cyan-400 to-blue-500 rounded-full"
                          style={{ width: `${Math.min(100, share)}%` }}
                        />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Real Auth / Connection Status Reminder Card */}
          <div className="glass-panel rounded-2xl p-4 space-y-2.5 text-xs">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-white">وضعیت اتصال و امنیت</span>
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            </div>
            <p className="text-slate-400 leading-relaxed">
              نرخ‌ها و کندل‌ها مستقیماً از API رسمی نوبیتکس دریافت می‌شوند. هیچ سفارش واقعی بدون تأیید صریح شما ارسال نخواهد شد.
            </p>
            <button
              type="button"
              onClick={onOpenSecurity}
              className="btn-glass btn-glass-neutral w-full py-2 rounded-xl font-semibold flex items-center justify-center gap-1.5"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-300" />
              <span>{isAuthenticated ? 'مدیریت کلیدهای API نوبیتکس' : 'ورود و تنظیم امنیت'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Professional PnL Calculator */}
      {pnlPolicy === 'DISABLED' && !isAdmin ? null : pnlCalculatorUnlocked ? (
        <PnlCalculatorWidget
          markets={markets}
          usdtTomanRate={usdtTomanRate}
          defaultBaseAsset={selectedBaseAsset}
          defaultQuoteCurrency={selectedQuoteCurrency}
          onQuoteCurrencyChange={onQuoteCurrencyChange}
          onCreateAlert={onCreateAlert}
          onSelectForTrade={onSelectForTrade}
        />
      ) : (
        <ProFeatureGate
          featureTitle="ماشین‌حساب حرفه‌ای سود و زیان"
          featureDescription="محاسبه دقیق سود، زیان و نقطه سربه‌سر به تومان و تتر قبل از ثبت معامله"
          monthlyPriceToman={monthlyPriceToman}
          monthlyPriceUsdt={monthlyPriceUsdt}
          isAuthenticated={isAuthenticated}
          onSignIn={onSignIn}
          onOpenSubscription={onOpenSubscription}
          onEnterDemoMode={onEnterDemoMode}
        />
      )}

      {/* Price Threshold Alerts Widget */}
      {alertsPolicy === 'DISABLED' && !isAdmin ? null : alertsUnlocked ? (
        <PriceAlertsWidget
          alerts={alerts}
          markets={markets}
          defaultBaseAsset={selectedBaseAsset}
          defaultQuoteCurrency={selectedQuoteCurrency}
          telegramConnected={telegramConnected}
          onOpenTelegramSettings={onOpenTelegramSettings}
          onQuoteCurrencyChange={onQuoteCurrencyChange}
          onCreateAlert={onCreateAlert}
          onRearmAlert={onRearmAlert}
          onDeleteAlert={onDeleteAlert}
          onSelectForTrade={onSelectForTrade}
        />
      ) : (
        <ProFeatureGate
          featureTitle="هشدار هوشمند رسیدن به قیمت هدف"
          featureDescription="ثبت هشدار عبور قیمت از سقف یا کف دلخواه در بازار تومانی و تتری"
          monthlyPriceToman={monthlyPriceToman}
          monthlyPriceUsdt={monthlyPriceUsdt}
          isAuthenticated={isAuthenticated}
          onSignIn={onSignIn}
          onOpenSubscription={onOpenSubscription}
          onEnterDemoMode={onEnterDemoMode}
        />
      )}
    </div>
  );
};
