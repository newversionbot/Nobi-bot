import React, { useMemo, useState } from 'react';
import type { IndicatorSnapshot, KlineCandle, Timeframe } from '../types/trading';
import { formatPrice, formatQty } from '../utils/format';

interface CandlestickChartProps {
  symbol: string;
  timeframe: Timeframe;
  onTimeframeChange: (tf: Timeframe) => void;
  candles: KlineCandle[];
  analysis: IndicatorSnapshot | null;
  loading?: boolean;
  entryPrice?: number;
  stopLossPrice?: number;
  takeProfitPrice?: number;
  chartTitle?: string;
  rightSlot?: React.ReactNode;
}

const TIMEFRAMES: Timeframe[] = ['1m', '5m', '15m', '1h', '4h', '1d'];

export const CandlestickChart: React.FC<CandlestickChartProps> = ({
  symbol,
  timeframe,
  onTimeframeChange,
  candles,
  analysis,
  loading = false,
  entryPrice,
  stopLossPrice,
  takeProfitPrice,
  chartTitle,
  rightSlot,
}) => {
  const [showEma20, setShowEma20] = useState(true);
  const [showEma50, setShowEma50] = useState(true);
  const [showBB, setShowBB] = useState(false);
  const [subPanel, setSubPanel] = useState<'VOLUME' | 'RSI' | 'MACD'>('RSI');
  const [hoverIdx, setHoverIdx] = useState<number | null>(null);

  const visibleCount = Math.min(candles.length, 96);
  const startIdx = Math.max(0, candles.length - visibleCount);

  const slice = useMemo(() => candles.slice(startIdx), [candles, startIdx]);

  const width = 920;
  const priceHeight = 310;
  const subHeight = 96;
  const totalHeight = priceHeight + subHeight + 34;
  const padLeft = 14;
  const padRight = 78;
  const padTop = 18;
  const chartW = width - padLeft - padRight;

  const { minPrice, maxPrice, maxVol } = useMemo(() => {
    if (slice.length === 0) {
      return { minPrice: 0, maxPrice: 100, maxVol: 1 };
    }
    let min = Infinity;
    let max = -Infinity;
    let mVol = 0;

    slice.forEach((c, i) => {
      if (c.low < min) min = c.low;
      if (c.high > max) max = c.high;
      if (c.volume > mVol) mVol = c.volume;

      const globalIdx = startIdx + i;
      if (showBB && analysis?.series.bbUpper[globalIdx] != null) {
        const u = analysis.series.bbUpper[globalIdx] as number;
        const l = analysis.series.bbLower[globalIdx] as number;
        if (u > max) max = u;
        if (l < min) min = l;
      }
    });

    if (entryPrice && entryPrice > 0) {
      min = Math.min(min, entryPrice);
      max = Math.max(max, entryPrice);
    }
    if (stopLossPrice && stopLossPrice > 0) {
      min = Math.min(min, stopLossPrice);
      max = Math.max(max, stopLossPrice);
    }
    if (takeProfitPrice && takeProfitPrice > 0) {
      min = Math.min(min, takeProfitPrice);
      max = Math.max(max, takeProfitPrice);
    }

    const span = max - min || max * 0.02 || 1;
    return {
      minPrice: min - span * 0.06,
      maxPrice: max + span * 0.06,
      maxVol: mVol || 1,
    };
  }, [slice, startIdx, showBB, analysis, entryPrice, stopLossPrice, takeProfitPrice]);

  const yForPrice = (p: number) => {
    const span = maxPrice - minPrice || 1;
    return padTop + ((maxPrice - p) / span) * (priceHeight - padTop - 10);
  };

  const candleSlot = slice.length > 0 ? chartW / slice.length : 10;
  const candleBodyW = Math.max(2.5, Math.min(8, candleSlot * 0.64));

  const buildPolyline = (arr: (number | null)[] | undefined) => {
    if (!arr || slice.length === 0) return '';
    const pts: string[] = [];
    for (let i = 0; i < slice.length; i++) {
      const v = arr[startIdx + i];
      if (v !== null && v !== undefined) {
        const x = padLeft + i * candleSlot + candleSlot / 2;
        const y = yForPrice(v);
        pts.push(`${x.toFixed(1)},${y.toFixed(1)}`);
      }
    }
    return pts.join(' ');
  };

  const ema20Line = showEma20 ? buildPolyline(analysis?.series.ema20) : '';
  const ema50Line = showEma50 ? buildPolyline(analysis?.series.ema50) : '';
  const bbUpperLine = showBB ? buildPolyline(analysis?.series.bbUpper) : '';
  const bbLowerLine = showBB ? buildPolyline(analysis?.series.bbLower) : '';

  const activeIdx = hoverIdx !== null && slice[hoverIdx] ? hoverIdx : slice.length - 1;
  const activeCandle = slice[activeIdx];
  const activeGlobalIdx = startIdx + activeIdx;
  const activeRsi = analysis?.series.rsi[activeGlobalIdx] ?? null;
  const activeEma20 = analysis?.series.ema20[activeGlobalIdx] ?? null;

  const priceTicks = useMemo(() => {
    const ticks: number[] = [];
    const steps = 4;
    for (let i = 0; i <= steps; i++) {
      ticks.push(minPrice + ((maxPrice - minPrice) * i) / steps);
    }
    return ticks;
  }, [minPrice, maxPrice]);

  // MACD range for subpanel
  const macdRange = useMemo(() => {
    if (!analysis) return 1;
    let m = 0.0001;
    for (let i = 0; i < slice.length; i++) {
      const gi = startIdx + i;
      const a = Math.abs(analysis.series.macdLine[gi] ?? 0);
      const b = Math.abs(analysis.series.macdSignal[gi] ?? 0);
      const h = Math.abs(analysis.series.macdHistogram[gi] ?? 0);
      m = Math.max(m, a, b, h);
    }
    return m * 1.15;
  }, [analysis, slice.length, startIdx]);

  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (slice.length === 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const relX = ((e.clientX - rect.left) / rect.width) * width;
    const idx = Math.floor((relX - padLeft) / candleSlot);
    if (idx >= 0 && idx < slice.length) {
      setHoverIdx(idx);
    }
  };

  return (
    <div className="glass-panel rounded-2xl overflow-hidden flex flex-col h-full">
      {/* Compact Reference-Style Chart Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 px-4 py-3 border-b border-cyan-500/15 bg-[#050C1D]/85">
        <div className="flex flex-wrap items-center gap-2.5">
          {chartTitle && (
            <div className="flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-purple-500/20 border border-purple-400/50 flex items-center justify-center text-[10px] font-bold text-purple-200 font-mono-num">
                N
              </span>
              <h3 className="text-sm sm:text-base font-bold text-white">{chartTitle}</h3>
            </div>
          )}
          {rightSlot && <div className="flex flex-wrap items-center gap-1.5">{rightSlot}</div>}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-950/85 p-1 rounded-xl border border-slate-800/80">
            {TIMEFRAMES.map((tf) => (
              <button
                key={tf}
                type="button"
                onClick={() => onTimeframeChange(tf)}
                className={`btn-glass px-2.5 py-1 text-xs font-mono-num rounded-lg whitespace-nowrap shrink-0 ${
                  timeframe === tf
                    ? 'btn-glass-primary font-semibold'
                    : 'border border-transparent bg-transparent shadow-none text-slate-400 hover:text-slate-100'
                }`}
              >
                {tf}
              </button>
            ))}
          </div>

          <div className="hidden xl:flex items-center gap-1">
            <button
              type="button"
              onClick={() => setShowEma20((v) => !v)}
              className={`px-2 py-1 text-[11px] rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                showEma20
                  ? 'border-cyan-500/60 bg-cyan-500/15 text-cyan-300'
                  : 'border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              EMA20
            </button>
            <button
              type="button"
              onClick={() => setShowEma50((v) => !v)}
              className={`px-2 py-1 text-[11px] rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                showEma50
                  ? 'border-amber-500/60 bg-amber-500/15 text-amber-300'
                  : 'border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              EMA50
            </button>
            <button
              type="button"
              onClick={() => setShowBB((v) => !v)}
              className={`px-2 py-1 text-[11px] rounded-lg border transition-colors whitespace-nowrap shrink-0 ${
                showBB
                  ? 'border-slate-500 bg-slate-700/40 text-slate-200'
                  : 'border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              BB
            </button>
          </div>

          <div className="flex items-center gap-1 bg-slate-950/85 p-0.5 rounded-lg border border-slate-800">
            {(['RSI', 'MACD', 'VOLUME'] as const).map((panel) => (
              <button
                key={panel}
                type="button"
                onClick={() => setSubPanel(panel)}
                className={`px-2 py-1 text-[11px] font-mono-num rounded-md transition-colors whitespace-nowrap shrink-0 ${
                  subPanel === panel
                    ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {panel === 'VOLUME' ? 'حجم' : panel}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Crosshair OHLC Telemetry Line */}
      <div
        dir="ltr"
        className="flex flex-wrap items-center justify-between gap-3 px-4 py-1.5 bg-[#040B1A] border-b border-slate-800/70 text-xs font-mono-num"
      >
        {activeCandle ? (
          <div className="flex flex-wrap items-center gap-3 text-slate-300">
            <span className="font-semibold text-white">{symbol}</span>
            <span className="text-slate-500">
              O: <span className="text-slate-200">{formatPrice(activeCandle.open)}</span>
            </span>
            <span className="text-slate-500">
              H: <span className="text-emerald-400">{formatPrice(activeCandle.high)}</span>
            </span>
            <span className="text-slate-500">
              L: <span className="text-rose-400">{formatPrice(activeCandle.low)}</span>
            </span>
            <span className="text-slate-500">
              C:{' '}
              <span
                className={
                  activeCandle.close >= activeCandle.open ? 'text-emerald-400' : 'text-rose-400'
                }
              >
                {formatPrice(activeCandle.close)}
              </span>
            </span>
            <span className="text-slate-500">
              Vol: <span className="text-slate-200">{formatQty(activeCandle.volume)}</span>
            </span>
            {activeEma20 !== null && (
              <span className="text-cyan-400">EMA20: {formatPrice(activeEma20)}</span>
            )}
            {activeRsi !== null && (
              <span className="text-amber-300">RSI(14): {activeRsi.toFixed(1)}</span>
            )}
          </div>
        ) : (
          <span className="text-slate-500">در حال بارگذاری کندل‌ها...</span>
        )}
        <span className="text-slate-500 text-[11px] font-mono-num" dir="ltr">
          {activeCandle ? new Date(activeCandle.openTime).toLocaleString('fa-IR-u-nu-latn') : ''}
        </span>
      </div>

      {/* Main SVG Viewport */}
      <div className="relative w-full bg-[#040917]">
        {loading && slice.length === 0 ? (
          <div className="h-[440px] flex items-center justify-center text-sm text-slate-400">
            در حال دریافت کندل‌های زنده از صرافی نوبیتکس...
          </div>
        ) : (
          <svg
            viewBox={`0 0 ${width} ${totalHeight}`}
            className="w-full h-auto block select-none cursor-crosshair"
            onMouseMove={handleMouseMove}
            onMouseLeave={() => setHoverIdx(null)}
          >
            {/* Horizontal Price Grid */}
            {priceTicks.map((tick, idx) => {
              const y = yForPrice(tick);
              return (
                <g key={idx}>
                  <line
                    x1={padLeft}
                    y1={y}
                    x2={width - padRight}
                    y2={y}
                    stroke="#1E293B"
                    strokeDasharray="3 3"
                    strokeWidth="1"
                  />
                  <text
                    x={width - padRight + 6}
                    y={y + 3}
                    fill="#94A3B8"
                    fontSize="10"
                    fontFamily="JetBrains Mono, monospace"
                  >
                    {formatPrice(tick)}
                  </text>
                </g>
              );
            })}

            {/* Bollinger Envelope */}
            {showBB && bbUpperLine && (
              <polyline
                fill="none"
                stroke="#64748B"
                strokeWidth="1"
                strokeDasharray="4 3"
                points={bbUpperLine}
              />
            )}
            {showBB && bbLowerLine && (
              <polyline
                fill="none"
                stroke="#64748B"
                strokeWidth="1"
                strokeDasharray="4 3"
                points={bbLowerLine}
              />
            )}

            {/* EMA 50 & EMA 20 */}
            {ema50Line && (
              <polyline fill="none" stroke="#F59E0B" strokeWidth="1.4" points={ema50Line} />
            )}
            {ema20Line && (
              <polyline fill="none" stroke="#06B6D4" strokeWidth="1.5" points={ema20Line} />
            )}

            {/* Entry / SL / TP Guide Lines */}
            {entryPrice && entryPrice > 0 && (
              <g>
                <line
                  x1={padLeft}
                  y1={yForPrice(entryPrice)}
                  x2={width - padRight}
                  y2={yForPrice(entryPrice)}
                  stroke="#06B6D4"
                  strokeDasharray="5 4"
                  strokeWidth="1.2"
                />
                <text
                  x={padLeft + 6}
                  y={yForPrice(entryPrice) - 4}
                  fill="#22D3EE"
                  fontSize="10"
                  fontFamily="JetBrains Mono, monospace"
                >
                  Entry {formatPrice(entryPrice)}
                </text>
              </g>
            )}
            {takeProfitPrice && takeProfitPrice > 0 && (
              <g>
                <line
                  x1={padLeft}
                  y1={yForPrice(takeProfitPrice)}
                  x2={width - padRight}
                  y2={yForPrice(takeProfitPrice)}
                  stroke="#10B981"
                  strokeDasharray="5 4"
                  strokeWidth="1.2"
                />
                <text
                  x={padLeft + 6}
                  y={yForPrice(takeProfitPrice) - 4}
                  fill="#34D399"
                  fontSize="10"
                  fontFamily="JetBrains Mono, monospace"
                >
                  TP {formatPrice(takeProfitPrice)}
                </text>
              </g>
            )}
            {stopLossPrice && stopLossPrice > 0 && (
              <g>
                <line
                  x1={padLeft}
                  y1={yForPrice(stopLossPrice)}
                  x2={width - padRight}
                  y2={yForPrice(stopLossPrice)}
                  stroke="#EF4444"
                  strokeDasharray="5 4"
                  strokeWidth="1.2"
                />
                <text
                  x={padLeft + 6}
                  y={yForPrice(stopLossPrice) + 12}
                  fill="#F87171"
                  fontSize="10"
                  fontFamily="JetBrains Mono, monospace"
                >
                  SL {formatPrice(stopLossPrice)}
                </text>
              </g>
            )}

            {/* Candlesticks */}
            {slice.map((c, i) => {
              const xCenter = padLeft + i * candleSlot + candleSlot / 2;
              const isBull = c.close >= c.open;
              const color = isBull ? '#10B981' : '#EF4444';
              const yHigh = yForPrice(c.high);
              const yLow = yForPrice(c.low);
              const yOpen = yForPrice(c.open);
              const yClose = yForPrice(c.close);
              const bodyTop = Math.min(yOpen, yClose);
              const bodyH = Math.max(1.5, Math.abs(yClose - yOpen));

              return (
                <g key={c.openTime}>
                  <line
                    x1={xCenter}
                    y1={yHigh}
                    x2={xCenter}
                    y2={yLow}
                    stroke={color}
                    strokeWidth="1.1"
                  />
                  <rect
                    x={xCenter - candleBodyW / 2}
                    y={bodyTop}
                    width={candleBodyW}
                    height={bodyH}
                    fill={color}
                    rx="0.8"
                  />
                </g>
              );
            })}

            {/* Current Last Price Marker */}
            {slice.length > 0 && (
              <g>
                <line
                  x1={padLeft}
                  y1={yForPrice(slice[slice.length - 1].close)}
                  x2={width - padRight}
                  y2={yForPrice(slice[slice.length - 1].close)}
                  stroke={
                    slice[slice.length - 1].close >= slice[slice.length - 1].open
                      ? '#10B981'
                      : '#EF4444'
                  }
                  strokeOpacity="0.45"
                  strokeWidth="1"
                />
                <rect
                  x={width - padRight + 2}
                  y={yForPrice(slice[slice.length - 1].close) - 9}
                  width={padRight - 6}
                  height={18}
                  rx={3}
                  fill={
                    slice[slice.length - 1].close >= slice[slice.length - 1].open
                      ? '#059669'
                      : '#DC2626'
                  }
                />
                <text
                  x={width - padRight + 6}
                  y={yForPrice(slice[slice.length - 1].close) + 3.5}
                  fill="#FFFFFF"
                  fontSize="10"
                  fontWeight="600"
                  fontFamily="JetBrains Mono, monospace"
                >
                  {formatPrice(slice[slice.length - 1].close)}
                </text>
              </g>
            )}

            {/* Divider between Price and SubPanel */}
            <line
              x1={padLeft}
              y1={priceHeight + 8}
              x2={width - padRight}
              y2={priceHeight + 8}
              stroke="#1E293B"
              strokeWidth="1"
            />

            {/* Sub-panel Header Label */}
            <text
              x={width - padRight + 6}
              y={priceHeight + 24}
              fill="#64748B"
              fontSize="10"
              fontFamily="JetBrains Mono, monospace"
            >
              {subPanel}
            </text>

            {/* Sub-panel Content */}
            {subPanel === 'VOLUME' &&
              slice.map((c, i) => {
                const xCenter = padLeft + i * candleSlot + candleSlot / 2;
                const h = (c.volume / maxVol) * (subHeight - 10);
                const y = priceHeight + 16 + (subHeight - 10 - h);
                const color = c.close >= c.open ? '#10B981' : '#EF4444';
                return (
                  <rect
                    key={c.openTime}
                    x={xCenter - candleBodyW / 2}
                    y={y}
                    width={candleBodyW}
                    height={Math.max(1, h)}
                    fill={color}
                    fillOpacity="0.55"
                  />
                );
              })}

            {subPanel === 'RSI' && analysis && (
              <g>
                {/* 70 and 30 Reference lines */}
                <line
                  x1={padLeft}
                  y1={priceHeight + 16 + ((100 - 70) / 100) * (subHeight - 10)}
                  x2={width - padRight}
                  y2={priceHeight + 16 + ((100 - 70) / 100) * (subHeight - 10)}
                  stroke="#EF4444"
                  strokeOpacity="0.35"
                  strokeDasharray="3 3"
                />
                <line
                  x1={padLeft}
                  y1={priceHeight + 16 + ((100 - 30) / 100) * (subHeight - 10)}
                  x2={width - padRight}
                  y2={priceHeight + 16 + ((100 - 30) / 100) * (subHeight - 10)}
                  stroke="#10B981"
                  strokeOpacity="0.35"
                  strokeDasharray="3 3"
                />
                <text
                  x={width - padRight + 6}
                  y={priceHeight + 16 + ((100 - 70) / 100) * (subHeight - 10) + 3}
                  fill="#64748B"
                  fontSize="9"
                  fontFamily="JetBrains Mono, monospace"
                >
                  70
                </text>
                <text
                  x={width - padRight + 6}
                  y={priceHeight + 16 + ((100 - 30) / 100) * (subHeight - 10) + 3}
                  fill="#64748B"
                  fontSize="9"
                  fontFamily="JetBrains Mono, monospace"
                >
                  30
                </text>
                <polyline
                  fill="none"
                  stroke="#22D3EE"
                  strokeWidth="1.5"
                  points={slice
                    .map((_, i) => {
                      const val = analysis.series.rsi[startIdx + i];
                      if (val === null || val === undefined) return null;
                      const x = padLeft + i * candleSlot + candleSlot / 2;
                      const y = priceHeight + 16 + ((100 - val) / 100) * (subHeight - 10);
                      return `${x.toFixed(1)},${y.toFixed(1)}`;
                    })
                    .filter(Boolean)
                    .join(' ')}
                />
              </g>
            )}

            {subPanel === 'MACD' && analysis && (
              <g>
                {(() => {
                  const midY = priceHeight + 16 + (subHeight - 10) / 2;
                  const halfH = (subHeight - 14) / 2;
                  return (
                    <>
                      <line
                        x1={padLeft}
                        y1={midY}
                        x2={width - padRight}
                        y2={midY}
                        stroke="#334155"
                        strokeWidth="1"
                      />
                      {slice.map((_, i) => {
                        const hist = analysis.series.macdHistogram[startIdx + i];
                        if (hist === null || hist === undefined) return null;
                        const xCenter = padLeft + i * candleSlot + candleSlot / 2;
                        const h = (Math.abs(hist) / macdRange) * halfH;
                        const y = hist >= 0 ? midY - h : midY;
                        return (
                          <rect
                            key={i}
                            x={xCenter - candleBodyW / 2}
                            y={y}
                            width={candleBodyW}
                            height={Math.max(1, h)}
                            fill={hist >= 0 ? '#10B981' : '#EF4444'}
                            fillOpacity="0.6"
                          />
                        );
                      })}
                      <polyline
                        fill="none"
                        stroke="#06B6D4"
                        strokeWidth="1.3"
                        points={slice
                          .map((_, i) => {
                            const v = analysis.series.macdLine[startIdx + i];
                            if (v === null || v === undefined) return null;
                            const x = padLeft + i * candleSlot + candleSlot / 2;
                            const y = midY - (v / macdRange) * halfH;
                            return `${x.toFixed(1)},${y.toFixed(1)}`;
                          })
                          .filter(Boolean)
                          .join(' ')}
                      />
                      <polyline
                        fill="none"
                        stroke="#F59E0B"
                        strokeWidth="1.3"
                        points={slice
                          .map((_, i) => {
                            const v = analysis.series.macdSignal[startIdx + i];
                            if (v === null || v === undefined) return null;
                            const x = padLeft + i * candleSlot + candleSlot / 2;
                            const y = midY - (v / macdRange) * halfH;
                            return `${x.toFixed(1)},${y.toFixed(1)}`;
                          })
                          .filter(Boolean)
                          .join(' ')}
                      />
                    </>
                  );
                })()}
              </g>
            )}

            {/* Hover Crosshair */}
            {hoverIdx !== null && slice[hoverIdx] && (
              <line
                x1={padLeft + hoverIdx * candleSlot + candleSlot / 2}
                y1={padTop}
                x2={padLeft + hoverIdx * candleSlot + candleSlot / 2}
                y2={priceHeight + subHeight + 12}
                stroke="#475569"
                strokeDasharray="3 3"
                strokeWidth="1"
              />
            )}
          </svg>
        )}
      </div>
    </div>
  );
};
