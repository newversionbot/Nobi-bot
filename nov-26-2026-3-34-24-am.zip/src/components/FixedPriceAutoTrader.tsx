import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowRight,
  BookOpen,
  Check,
  Coins,
  Edit3,
  Hand,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Repeat,
  Send,
  Shield,
  Target,
  Trash2,
  X,
} from 'lucide-react';
import type {
  BotExecutionConfirmationMode,
  BotFundingMode,
  BotStrategyConfig,
  ExecutionMode,
  PendingBotConfirmation,
  QuoteCurrency,
  SpotBalance,
  UnifiedMarketTicker,
} from '../types/trading';
import {
  formatQty,
  formatQuoteAmount,
  formatQuotePrice,
  formatToman,
} from '../utils/format';
import {
  computeExistingBalanceAllocation,
  getMinimumOrderNotional,
} from '../utils/profitBotMath';
import { CoinSearchSelect } from './CoinSearchSelect';
import { NumericInput } from './NumericInput';
import type { GuideBotTopic } from './BotEducationModal';

interface FixedPriceAutoTraderProps {
  defaultBaseAsset: string;
  defaultQuoteCurrency: QuoteCurrency;
  onQuoteCurrencyChange?: (qc: QuoteCurrency) => void;
  markets: UnifiedMarketTicker[];
  balances?: SpotBalance[];
  usdtTomanRate: number;
  fixedBots: BotStrategyConfig[];
  hasExchangeKeys: boolean;
  isAuthenticated: boolean;
  onRequireAuth: () => void;
  onCreateBot: (payload: Record<string, unknown>) => Promise<void>;
  onUpdateFixedTargets?: (
    botId: string,
    updates: {
      targetBuyPrice?: number;
      targetSellPrice: number;
      orderAmount?: number;
      repeatCycle?: boolean;
      maxCycles?: number | null;
      pollIntervalSeconds?: number;
      fundingMode?: BotFundingMode;
      existingBalancePercent?: number;
    }
  ) => Promise<void>;
  onToggleBotStatus: (botId: string, nextStatus: 'RUNNING' | 'PAUSED') => Promise<void>;
  onToggleBotMode: (
    botId: string,
    nextMode: ExecutionMode,
    confirmLive?: boolean
  ) => Promise<void>;
  onEvaluateBotNow: (botId: string) => Promise<void>;
  onDeleteBot: (botId: string) => Promise<void>;
  onToggleBotTelegram?: (botId: string, notifyTelegram: boolean) => Promise<void>;
  onSendBotReportToTelegram?: (
    botId?: string
  ) => Promise<{ title?: string; preview?: string } | void>;
  onBack?: () => void;
  onOpenGuide?: (topic: GuideBotTopic) => void;
  pendingConfirmations?: PendingBotConfirmation[];
  onResolveConfirmation?: (conf: PendingBotConfirmation, decision: 'APPROVE' | 'REJECT') => Promise<void>;
}

const NOBITEX_FEE_RATE = 0.0025;
const POLL_OPTIONS = [
  { seconds: 3, label: 'هر ۳ ثانیه (فوق‌سریع)' },
  { seconds: 5, label: 'هر ۵ ثانیه (پیشنهادی)' },
  { seconds: 10, label: 'هر ۱۰ ثانیه' },
  { seconds: 15, label: 'هر ۱۵ ثانیه' },
];

export const FixedPriceAutoTrader: React.FC<FixedPriceAutoTraderProps> = ({
  defaultBaseAsset,
  defaultQuoteCurrency,
  onQuoteCurrencyChange,
  markets,
  balances,
  usdtTomanRate,
  fixedBots,
  hasExchangeKeys,
  isAuthenticated,
  onRequireAuth,
  onCreateBot,
  onUpdateFixedTargets,
  onToggleBotStatus,
  onToggleBotMode,
  onEvaluateBotNow,
  onDeleteBot,
  onToggleBotTelegram,
  onSendBotReportToTelegram,
  onBack,
  onOpenGuide,
  pendingConfirmations = [],
  onResolveConfirmation,
}) => {
  const [baseAsset, setBaseAsset] = useState(defaultBaseAsset || 'BTC');
  const [quoteCurrency, setQuoteCurrency] = useState<QuoteCurrency>(
    defaultQuoteCurrency || 'IRT'
  );
  const [customName, setCustomName] = useState('');
  const [amountIrt, setAmountIrt] = useState<number>(5_000_000);
  const [amountUsdt, setAmountUsdt] = useState<number>(100);
  const [targetBuyPrice, setTargetBuyPrice] = useState<number>(0);
  const [targetSellPrice, setTargetSellPrice] = useState<number>(0);
  const [repeatCycle, setRepeatCycle] = useState<boolean>(true);
  const [hasMaxCycles, setHasMaxCycles] = useState<boolean>(false);
  const [maxCyclesCount, setMaxCyclesCount] = useState<number>(5);
  const [pollIntervalSeconds, setPollIntervalSeconds] = useState<number>(5);
  const [mode, setMode] = useState<ExecutionMode>('paper');
  const [confirmLive, setConfirmLive] = useState<boolean>(false);
  const [notifyTelegram, setNotifyTelegram] = useState<boolean>(true);
  const [fundingMode, setFundingMode] = useState<BotFundingMode>('QUOTE_BUY');
  const [existingBalancePercent, setExistingBalancePercent] = useState<number>(100);
  const [executionConfirmationMode, setExecutionConfirmationMode] =
    useState<BotExecutionConfirmationMode>('AUTO');

  const [creating, setCreating] = useState(false);
  const [busyBotId, setBusyBotId] = useState<string | null>(null);
  const [pendingLiveBotId, setPendingLiveBotId] = useState<string | null>(null);
  const [editingBotId, setEditingBotId] = useState<string | null>(null);
  const [editBuyPrice, setEditBuyPrice] = useState<number>(0);
  const [editSellPrice, setEditSellPrice] = useState<number>(0);
  const [editOrderAmount, setEditOrderAmount] = useState<number>(0);
  const [editRepeatCycle, setEditRepeatCycle] = useState<boolean>(true);
  const [editPollSeconds, setEditPollSeconds] = useState<number>(5);
  const [editFundingMode, setEditFundingMode] = useState<BotFundingMode>('QUOTE_BUY');
  const [editExistingBalancePercent, setEditExistingBalancePercent] = useState<number>(100);

  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    setBaseAsset(defaultBaseAsset || 'BTC');
  }, [defaultBaseAsset]);

  useEffect(() => {
    setQuoteCurrency(defaultQuoteCurrency || 'IRT');
  }, [defaultQuoteCurrency]);

  useEffect(() => {
    if (mode !== 'live') setConfirmLive(false);
  }, [mode]);

  const selectedMarket = useMemo(
    () => markets.find((m) => m.baseAsset === baseAsset) || null,
    [markets, baseAsset]
  );

  const livePrice = useMemo(() => {
    if (!selectedMarket) return 0;
    return quoteCurrency === 'IRT'
      ? selectedMarket.priceToman || selectedMarket.bestSellToman || 0
      : selectedMarket.priceUsdt || selectedMarket.bestSellUsdt || 0;
  }, [selectedMarket, quoteCurrency]);

  // Seed sensible initial targets whenever user switches coin/currency and inputs are still 0
  useEffect(() => {
    if (livePrice <= 0) return;
    const roundForQuote = (val: number) =>
      quoteCurrency === 'IRT'
        ? Math.max(1, Math.round(val))
        : Number(val.toFixed(val >= 10 ? 2 : val >= 0.1 ? 4 : 6));
    setTargetBuyPrice(roundForQuote(livePrice * 0.99));
    setTargetSellPrice(roundForQuote(livePrice * 1.015));
  }, [baseAsset, quoteCurrency, livePrice > 0]); // eslint-disable-line react-hooks/exhaustive-deps

  const freeBaseBalance = useMemo(() => {
    const found = (balances || []).find(
      (b) => b.asset.toUpperCase() === baseAsset.toUpperCase()
    );
    return found ? Math.max(0, Number(found.free) || 0) : 0;
  }, [balances, baseAsset]);

  const existingAlloc = useMemo(
    () =>
      computeExistingBalanceAllocation({
        freeBase: freeBaseBalance,
        percent: existingBalancePercent,
        referencePrice: livePrice,
        minNotional: getMinimumOrderNotional(quoteCurrency),
        baseAsset,
        quoteCurrency,
      }),
    [freeBaseBalance, existingBalancePercent, livePrice, baseAsset, quoteCurrency]
  );

  const orderAmount = quoteCurrency === 'IRT' ? amountIrt : amountUsdt;

  const cycleMetrics = useMemo(() => {
    if (fundingMode === 'EXISTING_ASSET') {
      if (livePrice <= 0 || targetSellPrice <= 0 || existingAlloc.allocatedQty <= 0) {
        return null;
      }
      const costBasis = existingAlloc.allocatedQty * livePrice;
      const grossSpreadPct = ((targetSellPrice - livePrice) / livePrice) * 100;
      const netProceeds = existingAlloc.allocatedQty * targetSellPrice * (1 - NOBITEX_FEE_RATE);
      const netProfitQuote = netProceeds - costBasis;
      const netProfitPct = costBasis > 0 ? (netProfitQuote / costBasis) * 100 : 0;
      return {
        grossSpreadPct,
        netProfitQuote,
        netProfitPct,
      };
    }
    if (targetBuyPrice <= 0 || targetSellPrice <= targetBuyPrice || orderAmount <= 0) {
      return null;
    }
    const grossSpreadPct = ((targetSellPrice - targetBuyPrice) / targetBuyPrice) * 100;
    const qtyPurchased = (orderAmount / targetBuyPrice) * (1 - NOBITEX_FEE_RATE);
    const netProceeds = qtyPurchased * targetSellPrice * (1 - NOBITEX_FEE_RATE);
    const netProfitQuote = netProceeds - orderAmount;
    const netProfitPct = (netProfitQuote / orderAmount) * 100;
    return {
      grossSpreadPct,
      netProfitQuote,
      netProfitPct,
    };
  }, [fundingMode, targetBuyPrice, targetSellPrice, orderAmount, livePrice, existingAlloc.allocatedQty]);

  const roundTarget = (val: number) =>
    quoteCurrency === 'IRT'
      ? Math.max(1, Math.round(val))
      : Number(val.toFixed(val >= 10 ? 2 : val >= 0.1 ? 4 : 6));

  const handleSelectQuote = (qc: QuoteCurrency) => {
    setQuoteCurrency(qc);
    onQuoteCurrencyChange?.(qc);
  };

  const handleCreate = async (startImmediately: boolean) => {
    setFeedback(null);
    if (!isAuthenticated) {
      onRequireAuth();
      return;
    }
    if (fundingMode !== 'EXISTING_ASSET' && !(targetBuyPrice > 0)) {
      setFeedback({ type: 'err', text: 'لطفاً قیمت هدف خرید را وارد کنید.' });
      return;
    }
    if (!(targetSellPrice > 0)) {
      setFeedback({ type: 'err', text: 'لطفاً قیمت هدف فروش را وارد کنید.' });
      return;
    }
    if (fundingMode !== 'EXISTING_ASSET' && !(targetSellPrice > targetBuyPrice)) {
      setFeedback({
        type: 'err',
        text: 'قیمت هدف فروش باید بیشتر از قیمت هدف خرید باشد.',
      });
      return;
    }
    if (fundingMode !== 'EXISTING_ASSET' && !(orderAmount > 0)) {
      setFeedback({ type: 'err', text: 'میزان مبلغ هر خرید باید بزرگ‌تر از صفر باشد.' });
      return;
    }
    if (fundingMode === 'EXISTING_ASSET' && startImmediately && !existingAlloc.ok) {
      setFeedback({
        type: 'err',
        text:
          existingAlloc.reason ||
          `موجودی آزاد ${baseAsset} برای ورود به معامله کافی نیست.`,
      });
      return;
    }
    if (mode === 'live' && !confirmLive) {
      setFeedback({
        type: 'err',
        text: 'برای ساخت معامله خودکار روی حساب واقعی نوبیتکس، ابتدا تیک تایید سرمایه واقعی را فعال کنید.',
      });
      return;
    }

    const coinLabel = selectedMarket?.persianName || baseAsset;
    const botName =
      customName.trim() ||
      `معامله قیمتی ${coinLabel} (${quoteCurrency === 'IRT' ? 'تومانی' : 'تتری'})`;
    const effectiveMaxCycles = repeatCycle && hasMaxCycles ? Math.max(1, maxCyclesCount) : null;
    const minNotional = getMinimumOrderNotional(quoteCurrency);
    const effectiveOrderAmount =
      fundingMode === 'EXISTING_ASSET' && !(orderAmount > 0) ? minNotional : orderAmount;
    const effectiveBuyPrice = fundingMode === 'EXISTING_ASSET' ? 0 : targetBuyPrice;

    setCreating(true);
    try {
      await onCreateBot({
        name: botName,
        strategyKind: 'FIXED_PRICE',
        targetBuyPrice: effectiveBuyPrice,
        targetSellPrice,
        repeatCycle,
        maxCycles: effectiveMaxCycles,
        pollIntervalSeconds,
        baseAsset,
        quoteCurrency,
        symbol: `${baseAsset}${quoteCurrency}`,
        timeframe: '1m',
        mode,
        confirmLive: mode === 'live' ? confirmLive : undefined,
        status: startImmediately ? 'RUNNING' : 'PAUSED',
        orderAmount: effectiveOrderAmount,
        fundingMode,
        existingBalancePercent: Math.min(100, Math.max(1, Math.round(existingBalancePercent))),
        stopLossPercent: 0,
        takeProfitPercent: 0,
        trailingStopEnabled: false,
        trailingStopPercent: 1,
        cooldownMinutes: 0,
        logicOperator: 'AND',
        entryRules: [
          {
            id: `fixed-buy-${Date.now()}`,
            type: 'FIXED_BUY_PRICE',
            action: 'BUY',
            enabled: true,
            params: {
              targetPrice: effectiveBuyPrice,
              repeatCycle,
              maxCycles: effectiveMaxCycles,
              pollSeconds: pollIntervalSeconds,
            },
          },
        ],
        exitRules: [
          {
            id: `fixed-sell-${Date.now()}`,
            type: 'FIXED_SELL_PRICE',
            action: 'SELL',
            enabled: true,
            params: {
              targetPrice: targetSellPrice,
            },
          },
        ],
        notifyTelegram,
        executionConfirmationMode,
      });
      setConfirmLive(false);
      setCustomName('');
      setFeedback({
        type: 'ok',
        text: startImmediately
          ? `ربات قیمتی «${botName}» فعال شد و هر ${pollIntervalSeconds} ثانیه قیمت نوبیتکس را رصد می‌کند.`
          : `ربات قیمتی «${botName}» ذخیره شد. هر زمان بخواهید دکمه شروع را بزنید.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ساخت ربات معامله قیمتی.',
      });
    } finally {
      setCreating(false);
    }
  };

  const openEditRow = (bot: BotStrategyConfig) => {
    setEditingBotId(bot.id);
    setEditBuyPrice(bot.targetBuyPrice || 0);
    setEditSellPrice(bot.targetSellPrice || 0);
    setEditOrderAmount(bot.orderAmount || 0);
    setEditRepeatCycle(bot.repeatCycle !== false);
    setEditPollSeconds(bot.pollIntervalSeconds || 5);
    setEditFundingMode(bot.fundingMode || 'QUOTE_BUY');
    setEditExistingBalancePercent(bot.existingBalancePercent ?? 100);
  };

  const saveEditRow = async (botId: string) => {
    if (!onUpdateFixedTargets) return;
    if (!(editSellPrice > 0)) {
      setFeedback({
        type: 'err',
        text: 'قیمت هدف فروش باید بزرگ‌تر از صفر باشد.',
      });
      return;
    }
    if (
      editFundingMode !== 'EXISTING_ASSET' &&
      (!(editBuyPrice > 0) || !(editSellPrice > editBuyPrice))
    ) {
      setFeedback({
        type: 'err',
        text: 'قیمت هدف فروش باید بیشتر از قیمت هدف خرید باشد.',
      });
      return;
    }
    setBusyBotId(botId);
    setFeedback(null);
    try {
      await onUpdateFixedTargets(botId, {
        targetBuyPrice: editFundingMode === 'EXISTING_ASSET' ? 0 : editBuyPrice,
        targetSellPrice: editSellPrice,
        orderAmount: editOrderAmount > 0 ? editOrderAmount : undefined,
        repeatCycle: editRepeatCycle,
        pollIntervalSeconds: editPollSeconds,
        fundingMode: editFundingMode,
        existingBalancePercent: Math.min(100, Math.max(1, Math.round(editExistingBalancePercent))),
      });
      setEditingBotId(null);
      setFeedback({
        type: 'ok',
        text: 'قیمت‌های هدف و تنظیمات چرخه با موفقیت به‌روزرسانی شد.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ذخیره قیمت‌های جدید.',
      });
    } finally {
      setBusyBotId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Simple Preset Order Builder */}
      <div className="glass-panel rounded-xl p-5 space-y-5">
        <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800/80 pb-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/15 border border-cyan-500/35 flex items-center justify-center shrink-0">
              <Target className="w-5 h-5 text-cyan-300" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-white">
                معامله خودکار با قیمت ثابت (خرید و فروش قیمتی نوبیتکس)
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                فقط ارز، قیمت خرید، قیمت فروش و میزان سرمایه را مشخص کنید؛ بدون نیاز به اندیکاتور، حد سود یا حد ضرر اضافی. ربات هر چند ثانیه بازار نوبیتکس را رصد کرده و در صورت تکرار چرخه، خرید و فروش را پیاپی انجام می‌دهد.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 shrink-0">
            <div className="text-xs text-slate-400 flex items-center gap-2">
              <span>قیمت فعلی نوبیتکس:</span>
              <span className="font-mono-num font-semibold text-amber-300" dir="ltr">
                {livePrice > 0 ? formatQuotePrice(livePrice, quoteCurrency) : 'در حال دریافت...'}
              </span>
            </div>
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold"
              >
                <ArrowRight className="w-4 h-4" />
                <span>بازگشت</span>
              </button>
            )}
            {onOpenGuide && (
              <button
                type="button"
                onClick={() => onOpenGuide('FIXED_PRICE')}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-cyan-500/35 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-200 text-xs font-bold"
              >
                <BookOpen className="w-4 h-4" />
                <span>راهنمای استفاده</span>
              </button>
            )}
          </div>
        </div>

        {pendingConfirmations.length > 0 && (
          <div className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-3.5 space-y-2 text-xs">
            <div className="flex items-center gap-2 text-amber-200 font-bold">
              <Hand className="w-4 h-4 text-amber-400" />
              سفارش قیمت ثابت در انتظار تأیید دستی شما ({pendingConfirmations.length})
            </div>
            {pendingConfirmations.map((conf) => (
              <div
                key={conf.id}
                className="rounded-lg border border-amber-500/30 bg-[#0A101D]/90 p-2.5 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
              >
                <div>
                  <span className="font-bold text-white">
                    {conf.side === 'BUY' ? 'خرید' : 'فروش'} {conf.symbol} ·{' '}
                    <span className="font-mono-num text-cyan-300">
                      {conf.suggestedPrice.toLocaleString('en-US')}
                    </span>
                  </span>
                  <div className="text-[11px] text-slate-300">{conf.reasonFa}</div>
                </div>
                {onResolveConfirmation && (
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => void onResolveConfirmation(conf, 'APPROVE')}
                      className="min-h-[38px] px-3 rounded-lg bg-emerald-600 text-white font-bold"
                    >
                      تأیید و اجرا
                    </button>
                    <button
                      type="button"
                      onClick={() => void onResolveConfirmation(conf, 'REJECT')}
                      className="min-h-[38px] px-3 rounded-lg border border-rose-500/40 bg-rose-500/10 text-rose-200 font-bold"
                    >
                      رد
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Row 1: Asset + Market + Order Amount */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs text-slate-300 mb-1.5 font-medium">
              ۱. انتخاب ارز دیجیتال
            </label>
            <CoinSearchSelect
              markets={markets}
              value={baseAsset}
              quoteCurrency={quoteCurrency}
              onChange={(nextBase) => {
                setBaseAsset(nextBase);
                const nextM = markets.find((m) => m.baseAsset === nextBase);
                if (quoteCurrency === 'IRT' && nextM && !nextM.hasIrtMarket) {
                  handleSelectQuote('USDT');
                }
              }}
              ariaLabel="جستجو و انتخاب ارز ربات قیمت ثابت"
            />
          </div>

          <div>
            <label className="block text-xs text-slate-300 mb-1.5 font-medium">
              ۲. بازار معامله (تومان یا تتر)
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                disabled={selectedMarket ? !selectedMarket.hasIrtMarket : false}
                onClick={() => handleSelectQuote('IRT')}
                className={`btn-glass min-h-[44px] px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap ${
                  quoteCurrency === 'IRT'
                    ? 'btn-glass-amber'
                    : 'btn-glass-neutral text-slate-300'
                }`}
              >
                بازار تومانی (IRT)
              </button>
              <button
                type="button"
                disabled={selectedMarket ? !selectedMarket.hasUsdtMarket : false}
                onClick={() => handleSelectQuote('USDT')}
                className={`btn-glass min-h-[44px] px-3 py-2 rounded-lg text-xs font-semibold whitespace-nowrap ${
                  quoteCurrency === 'USDT'
                    ? 'btn-glass-primary'
                    : 'btn-glass-neutral text-slate-300'
                }`}
              >
                بازار تتری (USDT)
              </button>
            </div>
          </div>

          <div className={fundingMode === 'EXISTING_ASSET' ? 'opacity-55 transition' : 'transition'}>
            <label className="block text-xs text-slate-300 mb-1.5 font-medium">
              {fundingMode === 'EXISTING_ASSET'
                ? '۳. مبلغ خرید جدید (غیرفعال در حالت موجودی فعلی)'
                : fundingMode === 'AUTO_PREFER_EXISTING'
                  ? `۳. مبلغ خرید جایگزین (${quoteCurrency === 'IRT' ? 'تومان' : 'تتر'})`
                  : `۳. میزان هر خرید (${quoteCurrency === 'IRT' ? 'تومان' : 'تتر'})`}
            </label>
            <NumericInput
              value={orderAmount}
              allowDecimal={quoteCurrency === 'USDT'}
              onValueChange={(val) => {
                const parsed = Number(val || 0);
                if (quoteCurrency === 'IRT') setAmountIrt(parsed);
                else setAmountUsdt(parsed);
              }}
              placeholder={quoteCurrency === 'IRT' ? 'مثلاً 5000000' : 'مثلاً 100'}
              className="w-full min-h-[44px] bg-[#0A101D] border border-slate-700 rounded-lg px-3 py-2 text-sm font-mono-num text-white focus:outline-none focus:border-cyan-400"
            />
            <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
              <span>
                {quoteCurrency === 'IRT'
                  ? usdtTomanRate > 0
                    ? `≈ $${(orderAmount / usdtTomanRate).toFixed(2)} تتر`
                    : ''
                  : usdtTomanRate > 0
                    ? `≈ ${formatToman(orderAmount * usdtTomanRate)} تومان`
                    : ''}
              </span>
              <div className="flex items-center gap-1.5">
                {(quoteCurrency === 'IRT'
                  ? [
                      { label: '۲م', val: 2_000_000 },
                      { label: '۵م', val: 5_000_000 },
                      { label: '۱۰م', val: 10_000_000 },
                    ]
                  : [
                      { label: '50$', val: 50 },
                      { label: '100$', val: 100 },
                      { label: '250$', val: 250 },
                    ]
                ).map((preset) => (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() =>
                      quoteCurrency === 'IRT' ? setAmountIrt(preset.val) : setAmountUsdt(preset.val)
                    }
                    className="px-1.5 py-0.5 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-300 font-mono-num"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Funding Source: Quote Balance vs Existing Coin Holding */}
        <div className="rounded-xl border border-indigo-500/25 bg-indigo-950/20 p-3.5 space-y-3 text-xs">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="font-semibold text-indigo-200 flex items-center gap-2">
              <Coins className="w-4 h-4 text-indigo-400" />
              <span>منبع سرمایه ورود (خرید جدید یا موجودی فعلی {baseAsset})</span>
            </div>
            <div className="font-mono-num text-[11px] text-slate-300">
              موجودی آزاد فعلی {baseAsset}:{' '}
              <span className="text-emerald-300 font-semibold">
                {formatQty(freeBaseBalance)} {baseAsset}
              </span>
              {livePrice > 0 && freeBaseBalance > 0 && (
                <span className="text-slate-400 mr-1.5">
                  (≈ {formatQuoteAmount(freeBaseBalance * livePrice, quoteCurrency)})
                </span>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
            {(
              [
                {
                  value: 'QUOTE_BUY' as BotFundingMode,
                  title: 'خرید با موجودی ریال / تتر',
                  desc: 'ابتدا با رسیدن به قیمت خرید، خرید می‌کند و سپس با قیمت هدف می‌فروشد.',
                },
                {
                  value: 'EXISTING_ASSET' as BotFundingMode,
                  title: `فقط با موجودی فعلی ${baseAsset}`,
                  desc: `بدون خرید اول؛ مستقیماً درصد مشخصی از ${baseAsset} فعلی را به قیمت فروش می‌فروشد.`,
                },
                {
                  value: 'AUTO_PREFER_EXISTING' as BotFundingMode,
                  title: 'هوشمند (اول موجودی ارز، در غیر این صورت خرید)',
                  desc: `اگر موجودی ${baseAsset} کافی بود مستقیم وارد فروش می‌شود؛ وگرنه در قیمت هدف می‌خرد.`,
                },
              ] as const
            ).map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setFundingMode(opt.value)}
                className={`text-right rounded-lg p-2.5 border transition ${
                  fundingMode === opt.value
                    ? 'bg-indigo-500/20 border-indigo-400/60 text-white'
                    : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                }`}
              >
                <div className="font-semibold">{opt.title}</div>
                <div className="text-[11px] text-slate-400 mt-0.5 leading-relaxed">{opt.desc}</div>
              </button>
            ))}
          </div>

          {fundingMode !== 'QUOTE_BUY' && (
            <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950/70 border border-slate-800 rounded-lg px-3 py-2.5">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-slate-300">درصد از موجودی {baseAsset}:</span>
                <input
                  type="range"
                  min={1}
                  max={100}
                  value={existingBalancePercent}
                  onChange={(e) => setExistingBalancePercent(Number(e.target.value))}
                  className="w-28 accent-indigo-400"
                />
                <NumericInput
                  value={existingBalancePercent}
                  allowDecimal={false}
                  onValueChange={(v) => {
                    const num = v === '' ? 100 : Number(v);
                    if (Number.isFinite(num)) {
                      setExistingBalancePercent(Math.min(100, Math.max(1, Math.round(num))));
                    }
                  }}
                  className="w-14 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center font-mono-num text-white"
                />
                {[25, 50, 75, 100].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => setExistingBalancePercent(pct)}
                    className={`px-2 py-0.5 rounded text-[11px] font-mono-num border ${
                      existingBalancePercent === pct
                        ? 'bg-indigo-500/25 border-indigo-400/50 text-indigo-200'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {pct}٪
                  </button>
                ))}
              </div>
              <div className="font-mono-num text-[11px]">
                {existingAlloc.ok ? (
                  <span className="text-emerald-300">
                    سهم ورودی: {formatQty(existingAlloc.allocatedQty)} {baseAsset}{' '}
                    {existingAlloc.notionalQuote > 0 &&
                      `(≈ ${formatQuoteAmount(existingAlloc.notionalQuote, quoteCurrency)})`}
                  </span>
                ) : (
                  <span className="text-amber-300">
                    {existingAlloc.reason || `موجودی ${baseAsset} کافی نیست.`}
                  </span>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Row 2: Preset Buy Price & Sell Price */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div
            className={`bg-slate-950/70 border rounded-xl p-4 space-y-2.5 transition ${
              fundingMode === 'EXISTING_ASSET'
                ? 'border-slate-800/60 opacity-55'
                : 'border-emerald-500/25'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <label className="text-xs font-semibold text-emerald-300">
                {fundingMode === 'EXISTING_ASSET'
                  ? 'قیمت خرید هدف (غیرفعال در حالت استفاده از موجودی فعلی)'
                  : 'قیمت خرید هدف (ورود خودکار وقتی قیمت ≤ این عدد شد)'}
              </label>
              {livePrice > 0 && (
                <div className="flex items-center gap-1 text-[11px]">
                  <button
                    type="button"
                    onClick={() => setTargetBuyPrice(roundTarget(livePrice))}
                    className="px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 whitespace-nowrap"
                  >
                    قیمت فعلی
                  </button>
                  <button
                    type="button"
                    onClick={() => setTargetBuyPrice(roundTarget(livePrice * 0.99))}
                    className="px-2 py-0.5 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 font-mono-num whitespace-nowrap"
                  >
                    -1%
                  </button>
                  <button
                    type="button"
                    onClick={() => setTargetBuyPrice(roundTarget(livePrice * 0.98))}
                    className="px-2 py-0.5 rounded bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 font-mono-num whitespace-nowrap"
                  >
                    -2%
                  </button>
                </div>
              )}
            </div>
            <NumericInput
              value={targetBuyPrice}
              allowDecimal={quoteCurrency === 'USDT' || livePrice < 1000}
              onValueChange={(val) => setTargetBuyPrice(Number(val || 0))}
              placeholder="قیمت خرید به ازای ۱ واحد ارز"
              className="w-full min-h-[44px] bg-[#0A101D] border border-emerald-500/35 rounded-lg px-3 py-2 text-base font-mono-num font-semibold text-white focus:outline-none focus:border-emerald-400"
            />
            <div className="text-[11px] text-slate-400 font-mono-num">
              {targetBuyPrice > 0
                ? `هر زمان قیمت ${baseAsset} به ${formatQuotePrice(
                    targetBuyPrice,
                    quoteCurrency
                  )} یا پایین‌تر برسد خرید فوری انجام می‌شود.`
                : 'قیمت خرید را وارد کنید.'}
            </div>
          </div>

          <div className="bg-slate-950/70 border border-rose-500/25 rounded-xl p-4 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <label className="text-xs font-semibold text-rose-300">
                قیمت فروش هدف (فروش خودکار وقتی قیمت ≥ این عدد شد)
              </label>
              {livePrice > 0 && (
                <div className="flex items-center gap-1 text-[11px]">
                  <button
                    type="button"
                    onClick={() =>
                      setTargetSellPrice(
                        roundTarget((targetBuyPrice > 0 ? targetBuyPrice : livePrice) * 1.01)
                      )
                    }
                    className="px-2 py-0.5 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 font-mono-num whitespace-nowrap"
                  >
                    +1%
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setTargetSellPrice(
                        roundTarget((targetBuyPrice > 0 ? targetBuyPrice : livePrice) * 1.02)
                      )
                    }
                    className="px-2 py-0.5 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 font-mono-num whitespace-nowrap"
                  >
                    +2%
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setTargetSellPrice(
                        roundTarget((targetBuyPrice > 0 ? targetBuyPrice : livePrice) * 1.04)
                      )
                    }
                    className="px-2 py-0.5 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 font-mono-num whitespace-nowrap"
                  >
                    +4%
                  </button>
                </div>
              )}
            </div>
            <NumericInput
              value={targetSellPrice}
              allowDecimal={quoteCurrency === 'USDT' || livePrice < 1000}
              onValueChange={(val) => setTargetSellPrice(Number(val || 0))}
              placeholder="قیمت فروش به ازای ۱ واحد ارز"
              className="w-full min-h-[44px] bg-[#0A101D] border border-rose-500/35 rounded-lg px-3 py-2 text-base font-mono-num font-semibold text-white focus:outline-none focus:border-rose-400"
            />
            <div className="text-[11px] text-slate-400 font-mono-num">
              {targetSellPrice > 0
                ? `پس از خرید، هر زمان قیمت به ${formatQuotePrice(
                    targetSellPrice,
                    quoteCurrency
                  )} یا بالاتر برسد فروش فوری انجام می‌شود.`
                : 'قیمت فروش را وارد کنید.'}
            </div>
          </div>
        </div>

        {/* Spread & Cycle Preview */}
        {cycleMetrics && (
          <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950/60 border border-slate-800/80 rounded-xl px-4 py-3 text-xs">
            <div className="flex flex-wrap items-center gap-3 text-slate-300">
              <span>اختلاف قیمتی خرید و فروش:</span>
              <span className="font-mono-num font-semibold text-cyan-300" dir="ltr">
                +{cycleMetrics.grossSpreadPct.toFixed(2)}%
              </span>
              <span className="text-slate-600">·</span>
              <span>سود خالص هر چرخه (بعد از کارمزد ۰.۲۵٪ نوبیتکس):</span>
              <span
                dir="ltr"
                className={`font-mono-num font-semibold ${
                  cycleMetrics.netProfitQuote > 0 ? 'text-emerald-400' : 'text-amber-300'
                }`}
              >
                {cycleMetrics.netProfitQuote >= 0 ? '+' : ''}
                {formatQuoteAmount(cycleMetrics.netProfitQuote, quoteCurrency)} (
                {cycleMetrics.netProfitPct >= 0 ? '+' : ''}
                {cycleMetrics.netProfitPct.toFixed(2)}%)
              </span>
            </div>
            {cycleMetrics.netProfitQuote <= 0 && (
              <span className="text-amber-300">
                توجه: فاصله قیمتی کمتر از کارمزد خرید و فروش نوبیتکس (۰.۵٪ رفت و برگشت) است.
              </span>
            )}
          </div>
        )}

        {/* Row 3: Repeating Cycle & Fast Polling Speed */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-white">
                <Repeat className="w-4 h-4 text-cyan-400" />
                <span>چرخه تکراری معامله</span>
              </div>
              <button
                type="button"
                onClick={() => setRepeatCycle((v) => !v)}
                className={`btn-glass px-3 py-1 rounded-lg text-xs font-semibold whitespace-nowrap ${
                  repeatCycle ? 'btn-glass-buy' : 'btn-glass-neutral text-slate-300'
                }`}
              >
                {repeatCycle ? 'چرخه تکراری: روشن' : 'فقط یک بار (تک‌چرخه)'}
              </button>
            </div>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {repeatCycle
                ? 'پس از فروش در قیمت هدف، ربات دوباره منتظر رسیدن به قیمت خرید می‌ماند و چرخه را تکرار می‌کند.'
                : 'فقط یک بار در قیمت خرید وارد شده و پس از فروش خودکار متوقف می‌شود.'}
            </p>
            {repeatCycle && (
              <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
                <label className="inline-flex items-center gap-1.5 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={hasMaxCycles}
                    onChange={(e) => setHasMaxCycles(e.target.checked)}
                    className="rounded border-slate-600 bg-slate-900 text-cyan-500"
                  />
                  <span>تعداد چرخه مشخص:</span>
                </label>
                {hasMaxCycles ? (
                  <NumericInput
                    value={maxCyclesCount}
                    allowDecimal={false}
                    onValueChange={(v) =>
                      setMaxCyclesCount(Math.max(1, Math.round(Number(v || 1) || 1)))
                    }
                    className="w-20 bg-[#0A101D] border border-slate-700 rounded-md px-2 py-1 text-xs font-mono-num text-white"
                  />
                ) : (
                  <span className="text-cyan-300 text-[11px]">نامحدود تا زمان توقف دستی</span>
                )}
              </div>
            )}
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-2.5">
            <div className="text-xs font-semibold text-white">
              سرعت رصد لحظه‌ای بازار نوبیتکس
            </div>
            <div className="grid grid-cols-2 gap-1.5 text-xs">
              {POLL_OPTIONS.map((opt) => (
                <button
                  key={opt.seconds}
                  type="button"
                  onClick={() => setPollIntervalSeconds(opt.seconds)}
                  className={`btn-glass min-h-[38px] px-2.5 py-1.5 rounded-lg text-[11px] font-medium whitespace-nowrap ${
                    pollIntervalSeconds === opt.seconds
                      ? 'btn-glass-primary font-semibold'
                      : 'btn-glass-neutral text-slate-300'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 space-y-3">
            <div>
              <label className="block text-xs text-slate-300 mb-1">نام ربات (اختیاری)</label>
              <input
                type="text"
                value={customName}
                onChange={(e) => setCustomName(e.target.value)}
                placeholder={`معامله قیمتی ${baseAsset}`}
                className="w-full min-h-[38px] bg-[#0A101D] border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setMode('paper')}
                  className={`btn-glass px-3 py-1.5 rounded-lg font-medium whitespace-nowrap ${
                    mode === 'paper'
                      ? 'btn-glass-primary'
                      : 'btn-glass-neutral text-slate-300'
                  }`}
                >
                  حساب تمرینی
                </button>
                <button
                  type="button"
                  disabled={!hasExchangeKeys}
                  onClick={() => setMode('live')}
                  className={`btn-glass px-3 py-1.5 rounded-lg font-medium whitespace-nowrap ${
                    mode === 'live'
                      ? 'btn-glass-buy'
                      : 'btn-glass-neutral text-slate-300'
                  } disabled:opacity-45`}
                  title={
                    hasExchangeKeys
                      ? 'اجرای سفارش واقعی در صرافی نوبیتکس'
                      : 'برای حالت واقعی، ابتدا کلید API نوبیتکس را ثبت کنید'
                  }
                >
                  حساب واقعی
                </button>
              </div>

              <label className="inline-flex items-center gap-1.5 text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={notifyTelegram}
                  onChange={(e) => setNotifyTelegram(e.target.checked)}
                  className="rounded border-slate-600 bg-slate-900 text-cyan-500"
                />
                <span>گزارش تلگرام</span>
              </label>
            </div>

            <div className="grid grid-cols-2 gap-1.5 pt-1 text-[11px]">
              <button
                type="button"
                onClick={() => setExecutionConfirmationMode('AUTO')}
                className={`min-h-[36px] rounded-lg border font-bold ${
                  executionConfirmationMode === 'AUTO'
                    ? 'border-emerald-500/50 bg-emerald-500/15 text-emerald-200'
                    : 'border-slate-800 bg-slate-900 text-slate-400'
                }`}
              >
                اجرای خودکار
              </button>
              <button
                type="button"
                onClick={() => setExecutionConfirmationMode('MANUAL_CONFIRM')}
                className={`min-h-[36px] rounded-lg border font-bold ${
                  executionConfirmationMode === 'MANUAL_CONFIRM'
                    ? 'border-amber-500/50 bg-amber-500/15 text-amber-200'
                    : 'border-slate-800 bg-slate-900 text-slate-400'
                }`}
              >
                تأیید دستی
              </button>
            </div>
          </div>
        </div>

        {mode === 'live' && (
          <div className="bg-amber-500/10 border border-amber-500/35 rounded-xl p-3 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2 text-amber-200">
              <Shield className="w-4 h-4 shrink-0" />
              <span>
                در حالت واقعی، به محض رسیدن قیمت نوبیتکس به اهداف تعیین‌شده، سفارش خرید و فروش واقعی با موجودی حساب شما ثبت می‌شود.
              </span>
            </div>
            <label className="inline-flex items-center gap-2 text-white font-semibold cursor-pointer">
              <input
                type="checkbox"
                checked={confirmLive}
                onChange={(e) => setConfirmLive(e.target.checked)}
                className="rounded border-amber-400 bg-slate-950 text-emerald-500"
              />
              <span>تأیید معامله خودکار با سرمایه واقعی</span>
            </label>
          </div>
        )}

        {feedback && (
          <div
            className={`text-xs px-4 py-2.5 rounded-lg border ${
              feedback.type === 'ok'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
            }`}
          >
            {feedback.text}
          </div>
        )}

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            disabled={creating}
            onClick={() => void handleCreate(true)}
            className="btn-glass btn-glass-buy inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>
              {creating
                ? 'در حال ثبت...'
                : isAuthenticated
                  ? 'ساخت و شروع رصد فوری بازار'
                  : 'ورود و فعال‌سازی'}
            </span>
          </button>
          <button
            type="button"
            disabled={creating}
            onClick={() => void handleCreate(false)}
            className="btn-glass btn-glass-neutral px-4 py-2.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0"
          >
            ذخیره به‌صورت متوقف
          </button>
        </div>
      </div>

      {/* Dedicated Fixed-Price Bots Monitor List */}
      <div className="glass-panel rounded-xl overflow-hidden">
        <div className="px-5 py-3.5 border-b border-slate-800/90 bg-[#060A14]/75 flex flex-wrap items-center justify-between gap-2">
          <div>
            <h4 className="text-sm font-semibold text-white">
              ربات‌های خرید و فروش قیمتی فعال و ذخیره‌شده ({fixedBots.length})
            </h4>
            <p className="text-xs text-slate-400 mt-0.5">
              رصد مستقیم قیمت لحظه‌ای نوبیتکس و اجرای فوری به محض رسیدن به قیمت خرید یا فروش تعیین‌شده
            </p>
          </div>
        </div>

        {fixedBots.length === 0 ? (
          <div className="p-8 text-center text-xs text-slate-400">
            هنوز ربات معامله قیمتی ایجاد نکرده‌اید. از فرم بالا قیمت خرید و فروش دلخواه خود را وارد و فعال کنید.
          </div>
        ) : (
          <div className="divide-y divide-slate-800/80">
            {fixedBots.map((bot) => {
              const m = markets.find((x) => x.baseAsset === bot.baseAsset);
              const px =
                bot.quoteCurrency === 'IRT'
                  ? m?.priceToman || m?.bestSellToman || 0
                  : m?.priceUsdt || m?.bestSellUsdt || 0;
              const buyP = bot.targetBuyPrice || 0;
              const sellP = bot.targetSellPrice || 0;
              const range = sellP - buyP;
              const progressPct =
                range > 0 && px > 0
                  ? Math.max(0, Math.min(100, ((px - buyP) / range) * 100))
                  : 50;
              const isEditing = editingBotId === bot.id;

              return (
                <div key={bot.id} className="p-4 space-y-3 hover:bg-slate-800/15">
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                    <div className="space-y-1.5 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-semibold text-white">{bot.name}</span>
                        <span className="text-xs text-amber-300 font-mono-num" dir="ltr">
                          {bot.symbol} · هر {bot.pollIntervalSeconds || 5}s ·{' '}
                          {bot.fundingMode === 'EXISTING_ASSET'
                            ? `${bot.existingBalancePercent ?? 100}٪ موجودی ${bot.baseAsset}`
                            : formatQuoteAmount(bot.orderAmount, bot.quoteCurrency)}
                        </span>
                        {(bot.fundingMode === 'EXISTING_ASSET' ||
                          bot.fundingMode === 'AUTO_PREFER_EXISTING' ||
                          bot.activePosition?.fromExistingBalance) && (
                          <span className="px-1.5 py-0.5 rounded border border-indigo-500/35 bg-indigo-500/15 text-[11px] text-indigo-200">
                            {bot.fundingMode === 'EXISTING_ASSET'
                              ? `موجودی فعلی (${bot.existingBalancePercent ?? 100}٪)`
                              : bot.activePosition?.fromExistingBalance
                                ? 'ورود از موجودی فعلی'
                                : `اول موجودی (${bot.existingBalancePercent ?? 100}٪)`}
                          </span>
                        )}
                        <span className="text-slate-600">·</span>
                        <span
                          className={`text-xs font-medium ${
                            bot.status === 'RUNNING' ? 'text-emerald-400' : 'text-amber-300'
                          }`}
                        >
                          {bot.status === 'RUNNING' ? 'فعال (در حال رصد)' : 'متوقف'}
                        </span>
                        <span className="text-slate-600">·</span>
                        <span className="text-xs text-cyan-300">
                          {bot.repeatCycle !== false
                            ? bot.maxCycles
                              ? `چرخه تکراری (${bot.stats.totalTrades}/${bot.maxCycles})`
                              : `چرخه تکراری (${bot.stats.totalTrades} تکمیل شده)`
                            : `تک‌چرخه`}
                        </span>
                        <span className="text-slate-600">·</span>
                        <span className="text-xs text-slate-300">
                          {bot.mode === 'live' ? 'حساب واقعی' : 'حساب تمرینی'}
                        </span>
                      </div>

                      {/* Target Price Range Bar */}
                      {sellP > 0 && (buyP > 0 || bot.fundingMode === 'EXISTING_ASSET') && (
                        <div className="pt-1 max-w-2xl space-y-1.5">
                          <div className="flex flex-wrap items-center justify-between gap-2 text-xs font-mono-num">
                            <span className="text-emerald-400">
                              {bot.fundingMode === 'EXISTING_ASSET' && !(buyP > 0)
                                ? 'ورود مستقیم از موجودی ارز'
                                : `خرید ≤ ${formatQuotePrice(buyP, bot.quoteCurrency)}`}
                            </span>
                            {px > 0 && (
                              <span className="text-white">
                                فعلی: {formatQuotePrice(px, bot.quoteCurrency)}
                              </span>
                            )}
                            <span className="text-rose-400">
                              فروش ≥ {formatQuotePrice(sellP, bot.quoteCurrency)}
                            </span>
                          </div>
                          {buyP > 0 && (
                            <div className="h-2 rounded-full bg-slate-900 border border-slate-800 overflow-hidden relative">
                              <div
                                className="h-full bg-gradient-to-l from-rose-500/70 via-cyan-400/80 to-emerald-500/70 transition-all duration-300"
                                style={{ width: `${progressPct}%` }}
                              />
                            </div>
                          )}
                        </div>
                      )}

                      <div className="text-xs text-slate-300">{bot.lastSignalSummary}</div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <div className="text-left pl-3 border-l border-slate-800" dir="ltr">
                        <div className="text-[11px] text-slate-400">سود/زیان تحقق‌یافته</div>
                        <div
                          className={`text-sm font-mono-num font-semibold ${
                            bot.stats.realizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {bot.stats.realizedPnl >= 0 ? '+' : ''}
                          {formatQuoteAmount(bot.stats.realizedPnl, bot.quoteCurrency)}
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={busyBotId === bot.id}
                        onClick={async () => {
                          if (!isAuthenticated) {
                            onRequireAuth();
                            return;
                          }
                          setBusyBotId(bot.id);
                          try {
                            await onToggleBotStatus(
                              bot.id,
                              bot.status === 'RUNNING' ? 'PAUSED' : 'RUNNING'
                            );
                          } finally {
                            setBusyBotId(null);
                          }
                        }}
                        className={`btn-glass inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap ${
                          bot.status === 'RUNNING' ? 'btn-glass-amber' : 'btn-glass-buy'
                        }`}
                      >
                        {bot.status === 'RUNNING' ? (
                          <>
                            <Pause className="w-3.5 h-3.5" />
                            <span>توقف</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3.5 h-3.5" />
                            <span>شروع</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        disabled={busyBotId === bot.id}
                        onClick={async () => {
                          if (!isAuthenticated) {
                            onRequireAuth();
                            return;
                          }
                          setBusyBotId(bot.id);
                          try {
                            await onEvaluateBotNow(bot.id);
                          } finally {
                            setBusyBotId(null);
                          }
                        }}
                        className="btn-glass btn-glass-sync inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs whitespace-nowrap"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                        <span>بررسی الان</span>
                      </button>

                      {onUpdateFixedTargets && (
                        <button
                          type="button"
                          onClick={() =>
                            isEditing ? setEditingBotId(null) : openEditRow(bot)
                          }
                          className="btn-glass btn-glass-neutral inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs whitespace-nowrap"
                        >
                          <Edit3 className="w-3.5 h-3.5 text-cyan-300" />
                          <span>ویرایش قیمت</span>
                        </button>
                      )}

                      {hasExchangeKeys &&
                        (bot.mode === 'paper' && pendingLiveBotId === bot.id ? (
                          <div className="flex items-center gap-1 rounded-lg border border-amber-500/45 bg-amber-500/10 px-2 py-1 text-[11px]">
                            <button
                              type="button"
                              disabled={busyBotId === bot.id}
                              onClick={async () => {
                                setBusyBotId(bot.id);
                                try {
                                  await onToggleBotMode(bot.id, 'live', true);
                                  setPendingLiveBotId(null);
                                } finally {
                                  setBusyBotId(null);
                                }
                              }}
                              className="px-2 py-0.5 rounded bg-emerald-500/25 text-emerald-200 font-semibold"
                            >
                              تایید واقعی
                            </button>
                            <button
                              type="button"
                              onClick={() => setPendingLiveBotId(null)}
                              className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300"
                            >
                              لغو
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              if (!isAuthenticated) {
                                onRequireAuth();
                                return;
                              }
                              if (bot.mode === 'paper') setPendingLiveBotId(bot.id);
                              else void onToggleBotMode(bot.id, 'paper');
                            }}
                            className="btn-glass btn-glass-neutral px-2.5 py-1.5 rounded-lg text-xs whitespace-nowrap"
                          >
                            {bot.mode === 'paper' ? 'انتقال به واقعی' : 'حالت تمرینی'}
                          </button>
                        ))}

                      {onToggleBotTelegram && (
                        <button
                          type="button"
                          disabled={busyBotId === bot.id}
                          onClick={() =>
                            void onToggleBotTelegram(bot.id, !(bot.notifyTelegram !== false))
                          }
                          className={`btn-glass inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs whitespace-nowrap ${
                            bot.notifyTelegram !== false
                              ? 'btn-glass-telegram'
                              : 'btn-glass-neutral text-slate-400'
                          }`}
                        >
                          <Send className="w-3 h-3" />
                          <span>{bot.notifyTelegram !== false ? 'تلگرام روشن' : 'تلگرام خاموش'}</span>
                        </button>
                      )}

                      {onSendBotReportToTelegram && (
                        <button
                          type="button"
                          onClick={() => void onSendBotReportToTelegram(bot.id)}
                          className="btn-glass btn-glass-telegram inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs whitespace-nowrap"
                          title="ارسال فوری گزارش به تلگرام"
                        >
                          <Send className="w-3 h-3" />
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => {
                          if (!isAuthenticated) {
                            onRequireAuth();
                            return;
                          }
                          void onDeleteBot(bot.id);
                        }}
                        className="btn-glass btn-glass-sell p-1.5 rounded-lg"
                        title="حذف ربات"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Inline Target Editor */}
                  {isEditing && (
                    <div className="bg-slate-950/85 border border-cyan-500/30 rounded-xl p-3.5 space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 items-end">
                        <div>
                          <label className="block text-[11px] text-indigo-300 mb-1">منبع سرمایه</label>
                          <select
                            value={editFundingMode}
                            onChange={(e) => setEditFundingMode(e.target.value as BotFundingMode)}
                            className="w-full bg-[#0A101D] border border-slate-700 rounded-lg px-2 py-1.5 text-xs text-white"
                          >
                            <option value="QUOTE_BUY">خرید ریال/تتر</option>
                            <option value="EXISTING_ASSET">موجودی فعلی ارز</option>
                            <option value="AUTO_PREFER_EXISTING">اول موجودی، بعد خرید</option>
                          </select>
                        </div>
                        {editFundingMode !== 'QUOTE_BUY' && (
                          <div>
                            <label className="block text-[11px] text-indigo-300 mb-1">
                              درصد موجودی {bot.baseAsset}
                            </label>
                            <NumericInput
                              value={editExistingBalancePercent}
                              allowDecimal={false}
                              onValueChange={(v) => {
                                const num = v === '' ? 100 : Number(v);
                                if (Number.isFinite(num)) {
                                  setEditExistingBalancePercent(
                                    Math.min(100, Math.max(1, Math.round(num)))
                                  );
                                }
                              }}
                              className="w-full bg-[#0A101D] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-mono-num text-white"
                            />
                          </div>
                        )}
                        <div>
                          <label className="block text-[11px] text-emerald-300 mb-1">
                            قیمت خرید هدف جدید
                          </label>
                          <NumericInput
                            value={editBuyPrice}
                            allowDecimal={bot.quoteCurrency === 'USDT' || editBuyPrice < 1000}
                            onValueChange={(v) => setEditBuyPrice(Number(v || 0))}
                            className="w-full bg-[#0A101D] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-mono-num text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-rose-300 mb-1">
                            قیمت فروش هدف جدید
                          </label>
                          <NumericInput
                            value={editSellPrice}
                            allowDecimal={bot.quoteCurrency === 'USDT' || editSellPrice < 1000}
                            onValueChange={(v) => setEditSellPrice(Number(v || 0))}
                            className="w-full bg-[#0A101D] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-mono-num text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">
                            مبلغ خرید ({bot.quoteCurrency})
                          </label>
                          <NumericInput
                            value={editOrderAmount}
                            allowDecimal={bot.quoteCurrency === 'USDT'}
                            onValueChange={(v) => setEditOrderAmount(Number(v || 0))}
                            className="w-full bg-[#0A101D] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs font-mono-num text-white"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-300 mb-1">سرعت رصد</label>
                          <select
                            value={editPollSeconds}
                            onChange={(e) => setEditPollSeconds(Number(e.target.value))}
                            className="w-full bg-[#0A101D] border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white"
                          >
                            {POLL_OPTIONS.map((o) => (
                              <option key={o.seconds} value={o.seconds}>
                                هر {o.seconds} ثانیه
                              </option>
                            ))}
                          </select>
                        </div>
                      </div>
                      <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                        <label className="inline-flex items-center gap-1.5 text-xs text-slate-200 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={editRepeatCycle}
                            onChange={(e) => setEditRepeatCycle(e.target.checked)}
                            className="rounded border-slate-600 bg-slate-900 text-cyan-500"
                          />
                          <span>چرخه تکراری</span>
                        </label>
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            disabled={busyBotId === bot.id}
                            onClick={() => void saveEditRow(bot.id)}
                            className="btn-glass btn-glass-buy inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap"
                          >
                            <Check className="w-3.5 h-3.5" />
                            <span>ذخیره</span>
                          </button>
                          <button
                            type="button"
                            onClick={() => setEditingBotId(null)}
                            className="btn-glass btn-glass-neutral p-1.5 rounded-lg"
                            title="انصراف"
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
