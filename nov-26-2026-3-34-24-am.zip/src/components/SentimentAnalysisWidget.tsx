import React, { useCallback, useEffect, useState } from 'react';
import {
  ExternalLink,
  Flame,
  MessageSquareText,
  Newspaper,
  RefreshCw,
} from 'lucide-react';
import { getFirebaseAuthHeaders } from '../firebase';
import { parseApiJson } from '../utils/api';
import type { CoinSentimentAnalysis, SentimentNewsItem, UnifiedMarketTicker } from '../types/trading';
import { computeDemoSentiment } from '../utils/demoSandbox';
import { formatDateTimeShort } from '../utils/format';

interface SentimentAnalysisWidgetProps {
  baseAsset: string;
  persianName: string;
  symbol: string;
  demoMode?: boolean;
  market?: UnifiedMarketTicker | null;
}

export const SentimentAnalysisWidget: React.FC<SentimentAnalysisWidgetProps> = ({
  baseAsset,
  persianName,
  symbol,
  demoMode = false,
  market = null,
}) => {
  const [data, setData] = useState<CoinSentimentAnalysis | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const marketRef = React.useRef(market);
  marketRef.current = market;
  const persianNameRef = React.useRef(persianName);
  persianNameRef.current = persianName;

  const loadSentiment = useCallback(
    async (refresh = false, signal?: AbortSignal) => {
      setLoading(true);
      setError(null);
      if (demoMode) {
        setData(
          computeDemoSentiment(baseAsset, persianNameRef.current, symbol, marketRef.current)
        );
        setLoading(false);
        return;
      }
      try {
        const qs = new URLSearchParams({
          symbol,
          ...(refresh ? { refresh: '1' } : {}),
        });
        const headers = await getFirebaseAuthHeaders();
        const res = await fetch(`/api/ai/sentiment?${qs.toString()}`, { headers, signal });
        const json = await parseApiJson<CoinSentimentAnalysis>(
          res,
          'خطا در دریافت اخبار و احساسات بازار'
        );
        if (!signal?.aborted) {
          setData(json);
        }
      } catch (err) {
        if ((err as { name?: string })?.name === 'AbortError') return;
        if (!signal?.aborted) {
          setError(
            err instanceof Error ? err.message : 'خطا در دریافت احساسات و اخبار بازار'
          );
        }
      } finally {
        if (!signal?.aborted) {
          setLoading(false);
        }
      }
    },
    [symbol, baseAsset, demoMode]
  );

  useEffect(() => {
    const controller = new AbortController();
    loadSentiment(false, controller.signal);
    return () => controller.abort();
  }, [loadSentiment]);

  const suggestionStyles = (suggestion: CoinSentimentAnalysis['suggestion']) => {
    if (suggestion === 'BUY') {
      return {
        box: 'bg-emerald-500/10 border-emerald-500/40',
        badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40',
        label: 'جو بازار: وقت خرید خوبه!',
      };
    }
    if (suggestion === 'SELL') {
      return {
        box: 'bg-rose-500/10 border-rose-500/40',
        badge: 'bg-rose-500/20 text-rose-300 border-rose-500/40',
        label: 'جو بازار: حواست باشه، سیو سود بهتره',
      };
    }
    return {
      box: 'bg-amber-500/10 border-amber-500/40',
      badge: 'bg-amber-500/20 text-amber-300 border-amber-500/40',
      label: 'جو بازار: فعلاً دست نگه دار و تماشا کن',
    };
  };

  const impactTag = (impact: SentimentNewsItem['impact']) => {
    if (impact === 'POSITIVE') {
      return { text: 'خبر مثبت', cls: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30' };
    }
    if (impact === 'NEGATIVE') {
      return { text: 'خبر منفی', cls: 'text-rose-400 bg-rose-500/10 border-rose-500/30' };
    }
    return { text: 'خنثی', cls: 'text-slate-300 bg-slate-800 border-slate-700' };
  };

  const scoreColor = (score: number) => {
    if (score >= 60) return 'bg-emerald-500';
    if (score <= 40) return 'bg-rose-500';
    return 'bg-amber-400';
  };

  return (
    <div className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 space-y-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/90 pb-4">
        <div className="flex items-center gap-2.5">
          <Flame className="w-5 h-5 text-amber-400" />
          <div>
            <h3 className="text-sm font-semibold text-white">
              خبرها و حال‌وهوای بازار برای {persianName} چطوره؟
            </h3>
            <p className="text-xs text-slate-400">
              یه چرخی تو خبرهای داغ، X و ردیت زدیم تا ببینیم ملت در مورد این ارز چی میگن
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {data && (
            <span className="text-xs text-slate-400 font-mono-num" dir="ltr">
              {formatDateTimeShort(data.generatedAt)}
            </span>
          )}
          <button
            type="button"
            onClick={() => loadSentiment(true)}
            disabled={loading}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-700 hover:border-cyan-500/50 text-slate-100 transition-colors disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-cyan-400 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'دارم خبرها رو چک می‌کنم...' : 'چک دوباره خبرها و جو'}</span>
          </button>
        </div>
      </div>

      {/* Loading State */}
      {loading && !data && (
        <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-6 text-center text-xs text-slate-400">
          وایسا یه لحظه! دارم خبرهای تازه و پچ‌پچ‌های توییتر و ردیت رو برای {persianName} ({baseAsset}) چک می‌کنم...
        </div>
      )}

      {/* Error State */}
      {error && (
        <div className="bg-rose-500/10 border border-rose-500/40 rounded-lg p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs text-rose-300">
          <span>{error}</span>
          <button
            type="button"
            onClick={() => loadSentiment(true)}
            className="px-3 py-1 rounded bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 font-medium"
          >
            تلاش مجدد
          </button>
        </div>
      )}

      {/* Main Content */}
      {data && (
        <div className={`space-y-4 ${loading ? 'opacity-65 transition-opacity' : ''}`}>
          {/* Top Verdict + Sentiment Meter */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Plain Persian Buy / Sell / Hold Suggestion */}
            {(() => {
              const st = suggestionStyles(data.suggestion);
              return (
                <div className={`lg:col-span-2 border rounded-lg p-4 space-y-3 ${st.box}`}>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span
                      className={`inline-flex items-center px-3 py-1 rounded-md border text-xs font-bold ${st.badge}`}
                    >
                      {st.label}
                    </span>
                    <span className="text-xs font-semibold text-white">
                      {data.suggestionLabelFa}
                    </span>
                  </div>
                  <p className="text-xs text-slate-100 leading-relaxed">{data.plainSummaryFa}</p>
                </div>
              );
            })()}

            {/* Sentiment Score & Global Fear/Greed */}
            <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-4 flex flex-col justify-between gap-3">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400">شاخص حال‌وهوای {baseAsset}</span>
                  <span className="font-mono-num font-bold text-white" dir="ltr">
                    {data.sentimentScore} / 100
                  </span>
                </div>
                <div className="w-full h-2 bg-slate-800 rounded-full overflow-hidden" dir="ltr">
                  <div
                    className={`h-full transition-all ${scoreColor(data.sentimentScore)}`}
                    style={{ width: `${data.sentimentScore}%` }}
                  />
                </div>
                <div className="text-xs text-slate-200 font-medium">{data.sentimentMoodFa}</div>
              </div>

              {data.marketFearGreed && (
                <div className="pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-xs">
                  <span className="text-slate-400">ترس و طمع کل بازار:</span>
                  <div className="flex items-center gap-2">
                    <span className="text-slate-200">{data.marketFearGreed.classificationFa}</span>
                    <span className="font-mono-num font-semibold text-amber-300" dir="ltr">
                      {data.marketFearGreed.value}
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Social Sentiment + Recent News */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 text-xs">
            {/* Social Buzz */}
            <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-4 space-y-2.5">
              <div className="flex items-center gap-2 font-semibold text-white pb-2 border-b border-slate-800">
                <MessageSquareText className="w-4 h-4 text-cyan-400" />
                <span>نبض شبکه‌های اجتماعی</span>
              </div>
              <p className="text-slate-200 leading-relaxed">{data.socialBuzzFa}</p>

              {data.sources.length > 0 && (
                <div className="pt-3 border-t border-slate-800/80 space-y-1.5">
                  <div className="text-[11px] text-slate-400">منابع زنده بررسی‌شده:</div>
                  <div className="flex flex-col gap-1.5">
                    {data.sources.slice(0, 4).map((src, i) => (
                      <a
                        key={`${src.url}-${i}`}
                        href={src.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center justify-between gap-2 text-[11px] text-cyan-400 hover:text-cyan-300 truncate"
                      >
                        <span className="truncate">{src.title}</span>
                        <ExternalLink className="w-3 h-3 shrink-0" />
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Recent News Items */}
            <div className="lg:col-span-2 bg-slate-950 border border-slate-800/90 rounded-lg p-4 space-y-3">
              <div className="flex items-center gap-2 font-semibold text-white pb-2 border-b border-slate-800">
                <Newspaper className="w-4 h-4 text-emerald-400" />
                <span>اخبار تازه مرتبط با {persianName}</span>
              </div>

              {data.newsItems.length === 0 ? (
                <div className="text-slate-400 py-3">
                  الان خبر خیلی خاص و جنجالی نیومده بیرون؛ اوضاع رو بر اساس حال‌وهوای کلی بازار سنجیدیم.
                </div>
              ) : (
                <div className="divide-y divide-slate-800/80">
                  {data.newsItems.map((news, idx) => {
                    const tag = impactTag(news.impact);
                    return (
                      <div key={idx} className="py-2.5 first:pt-0 last:pb-0 space-y-1">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <span className="font-semibold text-slate-100">{news.headline}</span>
                          <div className="flex items-center gap-2 shrink-0">
                            {news.dateHint && (
                              <span className="text-[11px] text-slate-400">{news.dateHint}</span>
                            )}
                            <span
                              className={`text-[11px] px-2 py-0.5 rounded border ${tag.cls}`}
                            >
                              {tag.text}
                            </span>
                          </div>
                        </div>
                        {news.summary && (
                          <p className="text-slate-400 leading-relaxed">{news.summary}</p>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
