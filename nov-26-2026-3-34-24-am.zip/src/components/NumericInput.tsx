import React, { useEffect, useState } from 'react';
import { normalizeEnglishNumberInput } from '../utils/format';

interface NumericInputProps
  extends Omit<
    React.InputHTMLAttributes<HTMLInputElement>,
    'type' | 'value' | 'onChange' | 'dir' | 'lang'
  > {
  value: string | number;
  onValueChange: (normalizedEnglishValue: string) => void;
  allowDecimal?: boolean;
}

export const NumericInput: React.FC<NumericInputProps> = ({
  value,
  onValueChange,
  allowDecimal = true,
  className = '',
  inputMode,
  ...rest
}) => {
  const propAsString = value === undefined || value === null ? '' : String(value);
  const [draft, setDraft] = useState<string>(propAsString);

  // Sync external prop changes while preserving intermediate decimal typing like "2." or "0.0"
  useEffect(() => {
    if (typeof value === 'string') {
      setDraft(value);
      return;
    }
    const parsedDraft = draft === '' || draft === '.' ? 0 : Number(draft);
    if (!Number.isFinite(parsedDraft) || parsedDraft !== value) {
      setDraft(propAsString);
    }
  }, [value, propAsString, draft]);

  return (
    <input
      {...rest}
      type="text"
      inputMode={inputMode ?? (allowDecimal ? 'decimal' : 'numeric')}
      dir="ltr"
      lang="en"
      autoComplete="off"
      spellCheck={false}
      value={typeof value === 'string' ? value : draft}
      onChange={(e) => {
        const clean = normalizeEnglishNumberInput(e.target.value, allowDecimal);
        setDraft(clean);
        onValueChange(clean);
      }}
      className={`font-mono-num ${className}`}
    />
  );
};
