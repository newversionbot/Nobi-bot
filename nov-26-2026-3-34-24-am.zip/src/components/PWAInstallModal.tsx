import React, { useEffect, useState } from 'react';
import {
  Check,
  CheckCircle2,
  Copy,
  Download,
  Eye,
  MoreVertical,
  PlusSquare,
  Share,
  Share2,
  Smartphone,
  WifiOff,
  X,
} from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';

interface PWAInstallModalProps {
  open: boolean;
  onClose: () => void;
  demoMode?: boolean;
  onToggleDemoMode?: () => void;
}

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-lg bg-amber-500 px-3.5 py-2 text-xs font-semibold text-slate-950 shadow-lg">
      <WifiOff className="w-4 h-4 shrink-0" />
      <span>اتصال اینترنت قطع است — نمایش اطلاعات ذخیره‌شده</span>
    </div>
  );
};

export const PWAInstallModal: React.FC<PWAInstallModalProps> = ({
  open,
  onClose,
  demoMode = false,
  onToggleDemoMode,
}) => {
  const { isInstallable, isInstalled, isIOS, install } = usePWAInstall();
  const [platformTab, setPlatformTab] = useState<'ANDROID' | 'IOS'>(isIOS ? 'IOS' : 'ANDROID');
  const [installing, setInstalling] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [includeDemoQuery, setIncludeDemoQuery] = useState(true);

  useEffect(() => {
    if (isIOS) setPlatformTab('IOS');
  }, [isIOS]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  const handleDirectInstall = async () => {
    setInstalling(true);
    try {
      await install();
    } finally {
      setInstalling(false);
    }
  };

  const baseOrigin =
    typeof window !== 'undefined' ? window.location.origin : 'https://ainobibot.ir';
  const mobileInstallUrl = baseOrigin
    ? `${baseOrigin}${includeDemoQuery ? '/?demo=1' : '/'}`
    : 'https://ainobibot.ir/';

  const handleCopyMobileUrl = async () => {
    if (!mobileInstallUrl) return;
    try {
      await navigator.clipboard.writeText(mobileInstallUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      // Ignore clipboard failures
    }
  };

  const handleShareMobileUrl = async () => {
    if (!mobileInstallUrl || typeof navigator === 'undefined' || !navigator.share) return;
    try {
      await navigator.share({
        title: 'AI NobiBot — ainobibot.ir',
        text: 'اپلیکیشن معاملاتی AI NobiBot (ainobibot.ir) — برای نصب روی گوشی در مرورگر باز کنید و Add to Home Screen را بزنید:',
        url: mobileInstallUrl,
      });
    } catch {
      // Ignore share cancellation
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="pwa-install-title"
    >
      <div
        className="w-full max-w-xl bg-[#0A101D] border border-slate-800 rounded-xl overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-800 bg-[#060A14]">
          <div className="flex items-center gap-3">
            <img
              src="/icon.svg"
              alt="AI NobiBot — ainobibot.ir"
              referrerPolicy="no-referrer"
              className="w-10 h-10 rounded-lg object-cover border border-cyan-500/40 shrink-0"
            />
            <div>
              <h2 id="pwa-install-title" className="text-sm sm:text-base font-semibold text-white">
                نصب اپلیکیشن AI NobiBot (ainobibot.ir) روی گوشی
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                راهنمای گام‌به‌گام نصب مستقیم به صورت برنامه مستقل (PWA) از داخل مرورگر گوشی
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="بستن"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          {isInstalled ? (
            <div className="bg-emerald-500/10 border border-emerald-500/30 rounded-lg p-3.5 flex items-center gap-2.5 text-xs text-emerald-300">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>
                شما هم‌اکنون در حال استفاده از نسخه نصب‌شده (Standalone) برنامه روی دستگاه خود هستید.
              </span>
            </div>
          ) : isInstallable ? (
            <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-4 flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs text-slate-200 space-y-0.5">
                <div className="font-semibold text-cyan-300">
                  مرورگر شما آماده نصب فوری با یک کلیک است
                </div>
                <div className="text-slate-400">
                  با زدن دکمه مقابل، آیکون برنامه مستقیماً کنار برنامه‌های گوشی شما اضافه می‌شود.
                </div>
              </div>
              <button
                type="button"
                disabled={installing}
                onClick={() => void handleDirectInstall()}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors whitespace-nowrap shrink-0"
              >
                <Download className="w-4 h-4" />
                <span>{installing ? 'در حال نصب...' : 'نصب مستقیم برنامه'}</span>
              </button>
            </div>
          ) : null}

          {/* Pre-Host / Pre-Domain Quick Phone Link & Demo Mode Toggle */}
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="font-semibold text-white">
                نصب سریع روی گوشی بدون نیاز به خرید هاست و دامنه
              </div>
              {onToggleDemoMode && (
                <button
                  type="button"
                  onClick={onToggleDemoMode}
                  className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-md font-semibold transition-colors whitespace-nowrap shrink-0 ${
                    demoMode
                      ? 'bg-emerald-500/20 border border-emerald-500/40 text-emerald-300'
                      : 'bg-cyan-500 hover:bg-cyan-400 text-slate-950'
                  }`}
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>{demoMode ? 'حالت نمایشی فعال است' : 'فعال‌سازی حالت نمایشی (دمو)'}</span>
                </button>
              )}
            </div>

            <p className="text-slate-400 leading-relaxed">
              اگر هنوز هاست و دامنه نخریده‌اید، لینک زیر را کپی کرده و در مرورگر Chrome (اندروید) یا Safari (آیفون) گوشی خود باز کنید و طبق مراحل پایین گزینه Add to Home Screen را بزنید.
            </p>

            {mobileInstallUrl && (
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2 bg-[#0A101D] border border-slate-800 rounded-md px-3 py-2">
                  <span className="font-mono-num text-[11px] text-cyan-300 truncate" dir="ltr">
                    {mobileInstallUrl}
                  </span>
                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      type="button"
                      onClick={() => void handleCopyMobileUrl()}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-100 font-medium whitespace-nowrap shrink-0"
                    >
                      {copiedLink ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-emerald-400" />
                          <span className="text-emerald-300">کپی شد</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3.5 h-3.5 text-cyan-300" />
                          <span>کپی لینک</span>
                        </>
                      )}
                    </button>

                    {typeof navigator !== 'undefined' && typeof navigator.share === 'function' && (
                      <button
                        type="button"
                        onClick={() => void handleShareMobileUrl()}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-cyan-500/15 border border-cyan-500/40 hover:bg-cyan-500/25 text-cyan-200 font-medium whitespace-nowrap shrink-0"
                      >
                        <Share2 className="w-3.5 h-3.5" />
                        <span>ارسال به گوشی</span>
                      </button>
                    )}
                  </div>
                </div>

                <label className="inline-flex items-center gap-2 text-[11px] text-slate-400 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={includeDemoQuery}
                    onChange={(e) => setIncludeDemoQuery(e.target.checked)}
                    className="accent-cyan-500"
                  />
                  <span>باز شدن مستقیم در «حالت نمایشی (دمو)» روی گوشی (?demo=1)</span>
                </label>
              </div>
            )}
          </div>

          {/* Platform Switcher */}
          <div className="grid grid-cols-2 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setPlatformTab('ANDROID')}
              className={`py-2 px-3 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 ${
                platformTab === 'ANDROID'
                  ? 'bg-cyan-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              گوشی اندروید (مرورگر Chrome)
            </button>
            <button
              type="button"
              onClick={() => setPlatformTab('IOS')}
              className={`py-2 px-3 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 ${
                platformTab === 'IOS'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              آیفون و آیپد (مرورگر Safari)
            </button>
          </div>

          {platformTab === 'ANDROID' ? (
            <div className="space-y-3">
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-md bg-cyan-500/15 text-cyan-300 font-mono-num font-bold flex items-center justify-center shrink-0">
                    1
                  </span>
                  <div className="space-y-1">
                    <div className="font-semibold text-white">
                      لینک برنامه را در مرورگر Chrome گوشی باز کنید
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      آدرس سایت را در گوگل کروم (Chrome) باز کنید. توجه کنید داخل مرورگر اینستاگرام یا تلگرام نباشید.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-2 border-t border-slate-800/70">
                  <span className="w-6 h-6 rounded-md bg-cyan-500/15 text-cyan-300 font-mono-num font-bold flex items-center justify-center shrink-0">
                    2
                  </span>
                  <div className="space-y-1">
                    <div className="font-semibold text-white flex items-center gap-1.5">
                      <span>روی منوی سه نقطه بالای صفحه بزنید</span>
                      <MoreVertical className="w-4 h-4 text-cyan-400 inline" />
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      در گوشه بالا سمت راست یا چپ مرورگر Chrome، آیکون سه نقطه عمودی را لمس کنید.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-2 border-t border-slate-800/70">
                  <span className="w-6 h-6 rounded-md bg-cyan-500/15 text-cyan-300 font-mono-num font-bold flex items-center justify-center shrink-0">
                    3
                  </span>
                  <div className="space-y-1">
                    <div className="font-semibold text-white flex items-center gap-1.5">
                      <span>گزینه Add to Home screen یا Install app را انتخاب کنید</span>
                      <PlusSquare className="w-4 h-4 text-amber-400 inline" />
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      در منوی باز شده، روی <span className="text-slate-200 font-medium">«افزودن به صفحه اصلی» (Add to Home screen)</span> یا{' '}
                      <span className="text-slate-200 font-medium">«نصب برنامه» (Install app)</span> بزنید و سپس گزینه{' '}
                      <span className="text-cyan-300 font-semibold">Install / Add</span> را تایید کنید.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-2 border-t border-slate-800/70">
                  <span className="w-6 h-6 rounded-md bg-emerald-500/15 text-emerald-300 font-mono-num font-bold flex items-center justify-center shrink-0">
                    4
                  </span>
                  <div className="space-y-1">
                    <div className="font-semibold text-emerald-300">
                      آماده اجرا مثل اپلیکیشن اختصاصی!
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      آیکون اختصاصی <span className="text-white">AI NobiBot</span> روی صفحه اصلی گوشی شما ساخته می‌شود و تمام‌صفحه (بدون نوار آدرس مرورگر) باز خواهد شد.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3 text-xs">
                <div className="flex items-start gap-3">
                  <span className="w-6 h-6 rounded-md bg-amber-500/15 text-amber-300 font-mono-num font-bold flex items-center justify-center shrink-0">
                    1
                  </span>
                  <div className="space-y-1">
                    <div className="font-semibold text-white">
                      لینک برنامه را حتماً با مرورگر Safari باز کنید
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      در آیفون و آیپد، نصب وب‌اپلیکیشن فقط از داخل مرورگر اصلی <span className="text-slate-200 font-medium">Safari</span> انجام می‌شود.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-2 border-t border-slate-800/70">
                  <span className="w-6 h-6 rounded-md bg-amber-500/15 text-amber-300 font-mono-num font-bold flex items-center justify-center shrink-0">
                    2
                  </span>
                  <div className="space-y-1">
                    <div className="font-semibold text-white flex items-center gap-1.5">
                      <span>دکمه Share (اشتراک‌گذاری) پایین صفحه را بزنید</span>
                      <Share className="w-4 h-4 text-cyan-400 inline" />
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      در نوار پایین Safari، مربع کوچکی که یک فلش رو به بالا دارد (Share) را لمس کنید.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-2 border-t border-slate-800/70">
                  <span className="w-6 h-6 rounded-md bg-amber-500/15 text-amber-300 font-mono-num font-bold flex items-center justify-center shrink-0">
                    3
                  </span>
                  <div className="space-y-1">
                    <div className="font-semibold text-white flex items-center gap-1.5">
                      <span>صفحه را کمی بالا بکشید و Add to Home Screen را بزنید</span>
                      <PlusSquare className="w-4 h-4 text-amber-400 inline" />
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      گزینه <span className="text-slate-200 font-medium">Add to Home Screen</span> (یا افزودن به صفحه اصلی) را انتخاب کنید و در گوشه بالا روی <span className="text-amber-300 font-semibold">Add</span> بزنید.
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 pt-2 border-t border-slate-800/70">
                  <span className="w-6 h-6 rounded-md bg-emerald-500/15 text-emerald-300 font-mono-num font-bold flex items-center justify-center shrink-0">
                    4
                  </span>
                  <div className="space-y-1">
                    <div className="font-semibold text-emerald-300">
                      اجرای مستقیم با آیکون اپلیکیشن
                    </div>
                    <p className="text-slate-400 leading-relaxed">
                      اپلیکیشن با نام <span className="text-white">AI NobiBot</span> روی صفحه اصلی آیفون قرار می‌گیرد و شبیه یک اپ بومی باز می‌شود.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Note about APK vs PWA */}
          <div className="bg-slate-950/70 border border-slate-800/90 rounded-lg p-3.5 text-[11px] text-slate-400 leading-relaxed flex items-start gap-2.5">
            <Smartphone className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <span className="text-slate-200 font-medium">مزیت نصب به روش PWA بدون نیاز به کامپیوتر:</span>{' '}
              حجم بسیار کم، بدون نیاز به دانلود فایل APK و نصب دستی، دریافت خودکار تمام آپدیت‌های جدید و اتصال همیشگی به نرخ لحظه‌ای نوبیتکس.
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-[#060A14] flex items-center justify-end gap-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-slate-100 transition-colors whitespace-nowrap shrink-0"
          >
            متوجه شدم، بستن راهنما
          </button>
        </div>
      </div>
    </div>
  );
};
