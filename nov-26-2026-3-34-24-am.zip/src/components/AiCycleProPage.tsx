import React, { useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Bot,
  CheckCircle2,
  Coins,
  Cpu,
  Hand,
  History,
  Pause,
  Play,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  Trash2,
  TrendingUp,
} from 'lucide-react';
import type {
  AiCycleProCapitalUsageMode,
  AiCycleProConfig,
  AiCycleProCycleRecord,
  AiCycleProLog,
  AiCycleProMarketPreview,
  AiCycleProStatus,
  BotExecutionConfirmationMode,
  ExecutionMode,
  PendingBotConfirmation,
  QuoteCurrency,
  SharedBotRiskSettings,
  SpotBalance,
  UnifiedMarketTicker,
} from '../types/trading';
import {
  formatDateTimeShort,
  formatQty,
  formatQuoteAmount,
  formatQuotePrice,
} from '../utils/format';
import { getMinimumOrderNotional } from '../utils/profitBotMath';
import { CoinSearchSelect } from './CoinSearchSelect';
import { NumericInput } from './NumericInput';
import {
  BotPageShell,
  ExecutionEnvironmentSelector,
  StopBotSafetyModal,
  type BotPageKpi,
  type DedicatedBotTabId,
} from './BotPageShell';
import type { GuideBotTopic } from './BotEducationModal';

interface AiCycleProPageProps {
  defaultBaseAsset: string;
  defaultQuoteCurrency: QuoteCurrency;
  markets: UnifiedMarketTicker[];
  balances: SpotBalance[];
  usdtTomanRate: number;
  hasExchangeKeys: boolean;
  isAuthenticated: boolean;
  demoMode: boolean;
  riskSettings: SharedBotRiskSettings;
  bots: AiCycleProConfig[];
  cycles: AiCycleProCycleRecord[];
  logs: AiCycleProLog[];
  pendingConfirmations: PendingBotConfirmation[];
  onBack: () => void;
  onOpenGuide: (topic: GuideBotTopic) => void;
  onRequireAuth: () => void;
  onCreateBot: (payload: Record<string, unknown>) => Promise<void>;
  onUpdateBot: (botId: string, payload: Record<string, unknown>) => Promise<void>;
  onStartBot: (botId: string, confirmLive?: boolean) => Promise<void>;
  onStopBot: (botId: string) => Promise<void>;
  onEvaluateBot: (botId: string) => Promise<void>;
  onManualSellBot: (botId: string) => Promise<void>;
  onDeleteBot: (botId: string) => Promise<void>;
  onPreviewMarket?: (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    capitalAmount: number;
    capitalUsageMode: AiCycleProCapitalUsageMode;
    capitalPortionPercent: number;
    minTargetNetProfitPercent: number;
    stopLossPercent: number;
    maxSlippagePercent: number;
    maxSpreadPercent: number;
  }) => Promise<AiCycleProMarketPreview>;
  onResolveConfirmation: (
    conf: PendingBotConfirmation,
    decision: 'APPROVE' | 'REJECT'
  ) => Promise<void>;
}

const STATUS_BADGE: Record<AiCycleProStatus, { label: string; cls: string }> = {
  IDLE: { label: 'آماده شروع', cls: 'bg-slate-800 text-slate-300 border-slate-700' },
  ANALYZING: { label: 'در حال تحلیل بازار', cls: 'bg-cyan-500/15 text-cyan-300 border-cyan-500/35' },
  WAITING_CASH: {
    label: 'نقد (انتظار شرایط بهتر)',
    cls: 'bg-amber-500/15 text-amber-300 border-amber-500/35',
  },
  PLACING_BUY: { label: 'ثبت سفارش خرید', cls: 'bg-sky-500/15 text-sky-300 border-sky-500/35' },
  HOLDING_POSITION: {
    label: 'پوزیشن باز · پایش فروش',
    cls: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/35',
  },
  PLACING_SELL: { label: 'ثبت سفارش فروش', cls: 'bg-teal-500/15 text-teal-300 border-teal-500/35' },
  PAUSED: { label: 'متوقف', cls: 'bg-slate-800 text-slate-300 border-slate-700' },
  STOPPED: { label: 'خاموش', cls: 'bg-slate-800 text-slate-400 border-slate-700' },
  PAUSED_RISK: { label: 'توقف حفاظتی (سقف ریسک)', cls: 'bg-rose-500/15 text-rose-300 border-rose-500/35' },
};

const EXIT_REASON_FA: Record<AiCycleProCycleRecord['exitReason'], string> = {
  AI_TARGET_PROFIT: 'تحقق هدف سود خالص',
  STOP_LOSS: 'حد ضرر (Stop-Loss)',
  DAILY_LOSS_CAP: 'سقف زیان روزانه',
  MANUAL_SELL: 'فروش دستی',
};

function getCycleStepIndex(bot: AiCycleProConfig): number {
  if (!bot.isActive && bot.stats.completedCycles > 0 && !bot.activePosition) return 5;
  if (!bot.isActive) return 0;
  if (bot.status === 'PLACING_SELL') return 4;
  if (bot.status === 'HOLDING_POSITION' || bot.activePosition) return 3;
  if (bot.status === 'PLACING_BUY') return 2;
  return 1;
}

export const AiCycleProPage: React.FC<AiCycleProPageProps> = ({
  defaultBaseAsset,
  defaultQuoteCurrency,
  markets,
  balances,
  usdtTomanRate,
  hasExchangeKeys,
  isAuthenticated,
  demoMode,
  riskSettings,
  bots,
  cycles,
  logs,
  pendingConfirmations,
  onBack,
  onOpenGuide,
  onRequireAuth,
  onCreateBot,
  onUpdateBot,
  onStartBot,
  onStopBot,
  onEvaluateBot,
  onManualSellBot,
  onDeleteBot,
  onPreviewMarket,
  onResolveConfirmation,
}) => {
  const [activeTab, setActiveTab] = useState<DedicatedBotTabId>('OVERVIEW');

  // Beginner Launcher State (just Coin + Capital + Mode + Start!)
  const [baseAsset, setBaseAsset] = useState(defaultBaseAsset || 'BTC');
  const [quoteCurrency, setQuoteCurrency] = useState<QuoteCurrency>(
    defaultQuoteCurrency || 'IRT'
  );
  const [capitalAmount, setCapitalAmount] = useState<number>(
    defaultQuoteCurrency === 'USDT' ? 100 : 10_000_000
  );
  const [capitalUsageMode, setCapitalUsageMode] =
    useState<AiCycleProCapitalUsageMode>('FULL');
  const [capitalPortionPercent, setCapitalPortionPercent] = useState<number>(50);
  const [executionMode, setExecutionMode] = useState<ExecutionMode>('paper');
  const [confirmationMode, setConfirmationMode] =
    useState<BotExecutionConfirmationMode>('AUTO');
  const [liveConfirmed, setLiveConfirmed] = useState(false);

  // Safety & Strategy Parameters (Pre-tuned safe defaults, editable in Settings)
  const [autoRepeatCycles, setAutoRepeatCycles] = useState(true);
  const [stopLossPercent, setStopLossPercent] = useState(3.0);
  const [maxDailyLoss, setMaxDailyLoss] = useState(
    defaultQuoteCurrency === 'USDT' ? 8 : 800_000
  );
  const [maxSlippagePercent, setMaxSlippagePercent] = useState(0.6);
  const [maxSpreadPercent, setMaxSpreadPercent] = useState(2.5);
  const [minTargetNetProfitPercent, setMinTargetNetProfitPercent] = useState(1.2);
  const [notifyTelegram, setNotifyTelegram] = useState(true);

  // Preview & UI State
  const [preview, setPreview] = useState<AiCycleProMarketPreview | null>(null);
  const [previewBusy, setPreviewBusy] = useState(false);
  const [busy, setBusy] = useState(false);
  const [busyBotId, setBusyBotId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [stopTarget, setStopTarget] = useState<AiCycleProConfig | null>(null);

  const selectedMarket = useMemo(
    () => markets.find((m) => m.baseAsset.toUpperCase() === baseAsset.toUpperCase()) || null,
    [markets, baseAsset]
  );

  const livePrice = useMemo(() => {
    if (!selectedMarket) return 0;
    return quoteCurrency === 'IRT' ? selectedMarket.priceToman : selectedMarket.priceUsdt;
  }, [selectedMarket, quoteCurrency]);

  const freeQuote = balances.find((b) => b.asset.toUpperCase() === quoteCurrency)?.free ?? 0;
  const activeCount = bots.filter((b) => b.isActive).length;
  const completedCount = bots.reduce((s, b) => s + b.stats.completedCycles, 0);
  const winningCount = bots.reduce((s, b) => s + b.stats.winningCycles, 0);
  const totalNetProfitIrt = bots
    .filter((b) => b.quoteCurrency === 'IRT')
    .reduce((s, b) => s + b.stats.totalNetProfitQuote, 0);
  const totalNetProfitUsdt = bots
    .filter((b) => b.quoteCurrency === 'USDT')
    .reduce((s, b) => s + b.stats.totalNetProfitQuote, 0);
  const winRatePct = completedCount > 0 ? (winningCount / completedCount) * 100 : 0;

  const kpis: BotPageKpi[] = [
    {
      label: 'وضعیت ربات‌های چرخه هوشمند',
      value: `${activeCount} فعال از ${bots.length}`,
      subtext: `${bots.filter((b) => b.activePosition).length} پوزیشن باز`,
      tone: activeCount > 0 ? 'positive' : 'neutral',
    },
    {
      label: 'کل سود خالص تحقق‌یافته',
      value:
        totalNetProfitIrt !== 0 || totalNetProfitUsdt === 0
          ? `${totalNetProfitIrt >= 0 ? '+' : '-'}${formatQuoteAmount(
              Math.abs(totalNetProfitIrt),
              'IRT'
            )}`
          : `${totalNetProfitUsdt >= 0 ? '+' : '-'}$${Math.abs(totalNetProfitUsdt).toFixed(2)}`,
      subtext:
        totalNetProfitUsdt !== 0 && totalNetProfitIrt !== 0
          ? `تتری: ${totalNetProfitUsdt >= 0 ? '+' : '-'}$${Math.abs(totalNetProfitUsdt).toFixed(2)}`
          : 'پس از کسر کارمزد خرید و فروش',
      tone: totalNetProfitIrt + totalNetProfitUsdt >= 0 ? 'positive' : 'negative',
    },
    {
      label: 'چرخه‌های تکمیل‌شده و نرخ برد',
      value: `${completedCount} چرخه`,
      subtext: `نرخ موفقیت: ${winRatePct.toFixed(0)}٪`,
      tone: winRatePct >= 50 ? 'accent' : 'neutral',
    },
    {
      label: 'موجودی آزاد در دسترس',
      value: formatQuoteAmount(freeQuote, quoteCurrency),
      subtext:
        quoteCurrency === 'IRT' && usdtTomanRate > 0 && freeQuote > 0
          ? `≈ $${(freeQuote / usdtTomanRate).toFixed(2)} USDT`
          : `بازار ${baseAsset}/${quoteCurrency}`,
      tone: 'neutral',
    },
  ];

  const handleQuoteSwitch = (qc: QuoteCurrency) => {
    setQuoteCurrency(qc);
    if (qc === 'IRT') {
      setCapitalAmount(10_000_000);
      setMaxDailyLoss(800_000);
    } else {
      setCapitalAmount(100);
      setMaxDailyLoss(8);
    }
    setPreview(null);
  };

  const handlePreview = async () => {
    setFeedback(null);
    if (!onPreviewMarket) return;
    setPreviewBusy(true);
    try {
      const res = await onPreviewMarket({
        baseAsset,
        quoteCurrency,
        capitalAmount,
        capitalUsageMode,
        capitalPortionPercent: capitalUsageMode === 'PARTIAL' ? capitalPortionPercent : 100,
        minTargetNetProfitPercent,
        stopLossPercent,
        maxSlippagePercent,
        maxSpreadPercent,
      });
      setPreview(res);
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در تحلیل زنده بازار نوبیتکس',
      });
    } finally {
      setPreviewBusy(false);
    }
  };

  const handleCreateAndStart = async (startImmediately: boolean) => {
    setFeedback(null);
    if (!isAuthenticated && !demoMode) {
      onRequireAuth();
      return;
    }
    const minNotional = getMinimumOrderNotional(quoteCurrency);
    if (!(capitalAmount >= minNotional)) {
      setFeedback({
        type: 'err',
        text: `حداقل سرمایه برای بازار ${quoteCurrency === 'IRT' ? 'تومانی ۵۰,۰۰۰ تومان' : 'تتری ۰.۵ USDT'} است.`,
      });
      return;
    }
    if (executionMode === 'live' && !liveConfirmed) {
      setFeedback({
        type: 'err',
        text: 'برای اجرای ربات با سرمایه واقعی نوبیتکس، تیک تأیید ریسک را فعال کنید.',
      });
      return;
    }
    setBusy(true);
    try {
      await onCreateBot({
        name: `چرخه هوشمند ${baseAsset}`,
        baseAsset,
        quoteCurrency,
        capitalAmount,
        mode: executionMode,
        confirmLive: executionMode === 'live' ? liveConfirmed : undefined,
        startImmediately,
        capitalUsageMode,
        capitalPortionPercent: capitalUsageMode === 'PARTIAL' ? capitalPortionPercent : 100,
        executionConfirmationMode: confirmationMode,
        autoRepeatCycles,
        stopLossPercent,
        maxDailyLoss,
        maxSlippagePercent,
        maxSpreadPercent,
        minTargetNetProfitPercent,
        notifyTelegram,
      });
      setLiveConfirmed(false);
      setFeedback({
        type: 'ok',
        text: startImmediately
          ? `ربات AI Cycle Pro برای ${baseAsset} ساخته شد و تحلیل بازار را آغاز کرد.`
          : `ربات AI Cycle Pro ذخیره شد و آماده شروع است.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ایجاد ربات AI Cycle Pro',
      });
    } finally {
      setBusy(false);
    }
  };

  const runBotAction = async (botId: string, fn: () => Promise<void>) => {
    setFeedback(null);
    setBusyBotId(botId);
    try {
      await fn();
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'عملیات ربات با خطا مواجه شد.',
      });
    } finally {
      setBusyBotId(null);
    }
  };

  return (
    <BotPageShell
      topic="AI_CYCLE_PRO"
      title="AI Cycle Pro | ربات چرخه هوشمند"
      subtitle="ربات کاملاً خودکار مخصوص مبتدی‌ها: فقط ارز، مبلغ سرمایه و حالت اجرا را انتخاب کنید؛ تحلیل بازار، خرید، مدیریت سود خالص و چرخه بعدی با هوش مصنوعی انجام می‌شود."
      icon={<Sparkles className="w-5 h-5 text-cyan-300" />}
      accentGradient="from-cyan-400 via-teal-400 to-emerald-400"
      statusLabel={activeCount > 0 ? `${activeCount} چرخه هوشمند فعال` : 'آماده شروع'}
      statusTone={
        riskSettings.killSwitchActive
          ? 'error'
          : activeCount > 0
            ? 'active'
            : 'paused'
      }
      kpis={kpis}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      onBack={onBack}
      onOpenGuide={onOpenGuide}
      pendingConfirmations={pendingConfirmations}
      onApproveConfirmation={(c) => void onResolveConfirmation(c, 'APPROVE')}
      onRejectConfirmation={(c) => void onResolveConfirmation(c, 'REJECT')}
    >
      <StopBotSafetyModal
        open={Boolean(stopTarget)}
        botName={stopTarget?.name || ''}
        hasOpenPosition={Boolean(stopTarget?.activePosition)}
        holdingSummary={
          stopTarget?.activePosition
            ? `${formatQty(stopTarget.activePosition.netOwnedQty)} ${stopTarget.baseAsset} به ارزش خرید ${formatQuoteAmount(
                stopTarget.activePosition.totalBuyCostQuote,
                stopTarget.quoteCurrency
              )}`
            : undefined
        }
        onCancel={() => setStopTarget(null)}
        onConfirmStopOnly={() => {
          if (!stopTarget) return;
          const targetId = stopTarget.id;
          setStopTarget(null);
          void runBotAction(targetId, () => onStopBot(targetId));
        }}
      />

      {feedback && (
        <div
          className={`mb-4 rounded-xl border px-4 py-3 text-xs font-bold flex items-center gap-2 ${
            feedback.type === 'ok'
              ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
              : 'border-rose-500/40 bg-rose-500/10 text-rose-200'
          }`}
        >
          {feedback.type === 'ok' ? (
            <CheckCircle2 className="w-4 h-4 shrink-0" />
          ) : (
            <AlertTriangle className="w-4 h-4 shrink-0" />
          )}
          <span>{feedback.text}</span>
        </div>
      )}

      {activeTab === 'OVERVIEW' && (
        <div className="space-y-5">
          {/* Ultra-simple 3-step Beginner Launcher */}
          <div className="rounded-2xl border border-cyan-500/30 bg-[#0A101D] p-4 sm:p-5 space-y-5 relative overflow-hidden">
            <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-cyan-400 via-teal-400 to-emerald-400" />
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-sm sm:text-base font-extrabold text-white flex items-center gap-2">
                  <Cpu className="w-4 h-4 text-cyan-300" />
                  راه‌اندازی سریع ۳ مرحله‌ای برای همه
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  بدون نیاز به تنظیم اندیکاتور یا قیمت؛ اگر بازار مناسب نباشد ربات نمی‌خرد و پول شما نقد می‌ماند.
                </p>
              </div>
              {livePrice > 0 && (
                <div className="rounded-xl border border-slate-800 bg-slate-900/70 px-3 py-2 text-xs font-mono-num tabular-nums text-cyan-200">
                  قیمت لحظه‌ای {baseAsset}: {formatQuotePrice(livePrice, quoteCurrency)}
                </div>
              )}
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* Step 1: Coin & Quote Market */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 space-y-3">
                <div className="flex items-center gap-2 text-xs font-extrabold text-white">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-mono-num flex items-center justify-center">
                    1
                  </span>
                  انتخاب ارز دیجیتال و بازار
                </div>
                <CoinSearchSelect
                  markets={markets}
                  value={baseAsset}
                  quoteCurrency={quoteCurrency}
                  onChange={(nextBase) => {
                    setBaseAsset(nextBase);
                    setPreview(null);
                  }}
                  ariaLabel="انتخاب ارز برای AI Cycle Pro"
                />
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    disabled={selectedMarket ? !selectedMarket.hasIrtMarket : false}
                    onClick={() => handleQuoteSwitch('IRT')}
                    className={`min-h-[40px] rounded-xl border text-xs font-bold whitespace-nowrap transition ${
                      quoteCurrency === 'IRT'
                        ? 'border-amber-400/60 bg-amber-500/15 text-amber-200'
                        : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    بازار تومان (IRT)
                  </button>
                  <button
                    type="button"
                    disabled={selectedMarket ? !selectedMarket.hasUsdtMarket : false}
                    onClick={() => handleQuoteSwitch('USDT')}
                    className={`min-h-[40px] rounded-xl border text-xs font-bold whitespace-nowrap transition ${
                      quoteCurrency === 'USDT'
                        ? 'border-cyan-400/60 bg-cyan-500/15 text-cyan-200'
                        : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    بازار تتر (USDT)
                  </button>
                </div>
              </div>

              {/* Step 2: Capital Amount & Full/Partial */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 space-y-3">
                <div className="flex items-center gap-2 text-xs font-extrabold text-white">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-mono-num flex items-center justify-center">
                    2
                  </span>
                  مبلغ سقف سرمایه ربات
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between text-[11px] text-slate-400">
                    <span>حداکثر سرمایه مجاز ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})</span>
                    <span className="font-mono-num tabular-nums text-slate-300">
                      آزاد: {formatQuoteAmount(freeQuote, quoteCurrency)}
                    </span>
                  </div>
                  <NumericInput
                    value={capitalAmount}
                    onValueChange={(v) => setCapitalAmount(Math.max(0, Number(v) || 0))}
                    className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-sm font-mono-num text-white"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCapitalUsageMode('FULL')}
                    className={`min-h-[38px] rounded-lg border text-xs font-bold whitespace-nowrap ${
                      capitalUsageMode === 'FULL'
                        ? 'border-emerald-500/60 bg-emerald-500/15 text-emerald-200'
                        : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    کل سرمایه (۱۰۰٪)
                  </button>
                  <button
                    type="button"
                    onClick={() => setCapitalUsageMode('PARTIAL')}
                    className={`min-h-[38px] rounded-lg border text-xs font-bold whitespace-nowrap ${
                      capitalUsageMode === 'PARTIAL'
                        ? 'border-cyan-500/60 bg-cyan-500/15 text-cyan-200'
                        : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    بخشی ({capitalPortionPercent}٪)
                  </button>
                </div>
                {capitalUsageMode === 'PARTIAL' && (
                  <div className="flex items-center gap-1.5">
                    {[25, 50, 75].map((pct) => (
                      <button
                        key={pct}
                        type="button"
                        onClick={() => setCapitalPortionPercent(pct)}
                        className={`flex-1 min-h-[32px] rounded-lg border text-[11px] font-mono-num font-bold ${
                          capitalPortionPercent === pct
                            ? 'border-cyan-400/60 bg-cyan-500/20 text-cyan-200'
                            : 'border-slate-800 bg-slate-900 text-slate-400'
                        }`}
                      >
                        {pct}٪
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Step 3: Execution Mode & Confirmation */}
              <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-4 space-y-3">
                <div className="flex items-center gap-2 text-xs font-extrabold text-white">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-mono-num flex items-center justify-center">
                    3
                  </span>
                  انتخاب حالت اجرا
                </div>
                <ExecutionEnvironmentSelector
                  executionMode={executionMode}
                  hasExchangeKeys={hasExchangeKeys}
                  liveConfirmed={liveConfirmed}
                  onChangeExecutionMode={(m) => {
                    setExecutionMode(m);
                    if (m !== 'live') setLiveConfirmed(false);
                  }}
                  onToggleLiveConfirm={setLiveConfirmed}
                />
                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    type="button"
                    onClick={() => setConfirmationMode('AUTO')}
                    className={`min-h-[38px] rounded-lg border text-xs font-bold whitespace-nowrap ${
                      confirmationMode === 'AUTO'
                        ? 'border-emerald-500/50 bg-emerald-500/15 text-emerald-200'
                        : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    اجرای کاملاً خودکار
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmationMode('MANUAL_CONFIRM')}
                    className={`min-h-[38px] rounded-lg border text-xs font-bold whitespace-nowrap ${
                      confirmationMode === 'MANUAL_CONFIRM'
                        ? 'border-amber-500/50 bg-amber-500/15 text-amber-200'
                        : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    نیازمند تأیید من
                  </button>
                </div>
              </div>
            </div>

            {/* Live AI & Orderbook Preview Box */}
            {preview && (
              <div className="rounded-xl border border-cyan-500/35 bg-slate-900/70 p-4 space-y-3 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 font-extrabold text-white">
                    <Sparkles className="w-4 h-4 text-cyan-300" />
                    نتیجه تحلیل زنده هوش مصنوعی و دفتر سفارش {preview.symbol}
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-lg border font-bold ${
                      preview.decision.action === 'BUY'
                        ? 'border-emerald-500/40 bg-emerald-500/15 text-emerald-200'
                        : 'border-amber-500/40 bg-amber-500/15 text-amber-200'
                    }`}
                  >
                    {preview.decision.action === 'BUY'
                      ? 'شرایط ورود مساعد است (آماده خرید)'
                      : 'فعلاً نقد بمان (ورود مناسب نیست)'}
                  </span>
                </div>
                <p className="text-slate-200 leading-6">{preview.decision.reasoningFa}</p>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 font-mono-num tabular-nums">
                  <div className="rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2">
                    <div className="text-[10px] text-slate-400">امتیاز روند / نقدشوندگی</div>
                    <div className="font-bold text-cyan-200">
                      {preview.decision.trendScore} / {preview.decision.liquidityScore}
                    </div>
                  </div>
                  <div className="rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2">
                    <div className="text-[10px] text-slate-400">اسپرد / لغزش برآوردی</div>
                    <div className="font-bold text-slate-100">
                      {preview.spreadPercent.toFixed(2)}٪ / {preview.estimatedBuySlippagePercent.toFixed(2)}٪
                    </div>
                  </div>
                  <div className="rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2">
                    <div className="text-[10px] text-slate-400">هدف سود خالص چرخه</div>
                    <div className="font-bold text-emerald-300">
                      +{preview.decision.recommendedTargetNetProfitPercent.toFixed(2)}٪
                    </div>
                  </div>
                  <div className="rounded-lg border border-slate-800 bg-slate-950/70 px-3 py-2">
                    <div className="text-[10px] text-slate-400">قیمت فروش هدف تخمینی</div>
                    <div className="font-bold text-white">
                      {formatQuotePrice(preview.decision.suggestedSellPrice, preview.quoteCurrency)}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Main Start CTA Row */}
            <div className="flex flex-wrap items-center gap-3">
              <button
                type="button"
                disabled={busy}
                onClick={() => void handleCreateAndStart(true)}
                className="min-h-[48px] px-6 rounded-xl bg-gradient-to-l from-cyan-500 to-emerald-500 hover:brightness-110 disabled:opacity-60 text-slate-950 text-sm font-extrabold flex items-center gap-2 whitespace-nowrap transition shadow-lg shadow-cyan-500/20"
              >
                <Play className="w-4 h-4 fill-current" />
                {busy ? 'در حال راه‌اندازی...' : 'شروع ربات چرخه هوشمند'}
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={() => void handleCreateAndStart(false)}
                className="min-h-[48px] px-4 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold whitespace-nowrap"
              >
                ذخیره بدون شروع
              </button>
              {onPreviewMarket && (
                <button
                  type="button"
                  disabled={previewBusy}
                  onClick={() => void handlePreview()}
                  className="min-h-[48px] px-4 rounded-xl border border-cyan-500/40 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-200 text-xs font-bold flex items-center gap-2 whitespace-nowrap"
                >
                  <RefreshCw className={`w-4 h-4 ${previewBusy ? 'animate-spin' : ''}`} />
                  {previewBusy ? 'در حال تحلیل...' : 'پیش‌نمایش تحلیل هوشمند بازار'}
                </button>
              )}
            </div>
          </div>

          {/* Active & Saved AI Cycle Pro Bots List */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <Bot className="w-4 h-4 text-cyan-400" />
                ربات‌های چرخه هوشمند شما ({bots.length})
              </h3>
            </div>

            {bots.length === 0 ? (
              <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-6 text-center text-xs text-slate-400">
                هنوز ربات AI Cycle Pro نساخته‌اید. از بخش بالا فقط ارز و مبلغ سرمایه را انتخاب کرده و دکمه «شروع ربات چرخه هوشمند» را بزنید.
              </div>
            ) : (
              <div className="space-y-3">
                {bots.map((bot) => {
                  const badge = STATUS_BADGE[bot.status] || STATUS_BADGE.IDLE;
                  const stepIdx = getCycleStepIndex(bot);
                  const pos = bot.activePosition;
                  const isBusy = busyBotId === bot.id;
                  const estPct =
                    pos && pos.totalBuyCostQuote > 0 && pos.lastEstimatedNetProfitQuote !== undefined
                      ? (pos.lastEstimatedNetProfitQuote / pos.totalBuyCostQuote) * 100
                      : 0;

                  const pipelineSteps = [
                    '۱. تحلیل بازار',
                    '۲. خرید هوشمند',
                    '۳. پایش پوزیشن',
                    '۴. فروش و سود خالص',
                    '۵. چرخه بعدی',
                  ];

                  return (
                    <div
                      key={bot.id}
                      className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-4"
                    >
                      {/* Header Row */}
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-3">
                        <div className="space-y-1">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="text-sm sm:text-base font-extrabold text-white">
                              {bot.name}
                            </span>
                            <span className="text-xs font-mono-num text-cyan-300 font-bold">
                              {bot.symbol}
                            </span>
                            <span
                              className={`px-2 py-0.5 rounded-md border text-[11px] font-bold ${
                                bot.mode === 'live'
                                  ? 'border-rose-500/40 bg-rose-500/15 text-rose-300'
                                  : 'border-cyan-500/35 bg-cyan-500/10 text-cyan-300'
                              }`}
                            >
                              {bot.mode === 'live' ? 'واقعی' : 'تمرینی'}
                            </span>
                            <span className={`px-2.5 py-0.5 rounded-lg border text-[11px] font-bold ${badge.cls}`}>
                              {badge.label}
                            </span>
                          </div>
                          <div className="text-xs text-slate-300 leading-6">
                            {bot.lastStatusReason || 'آماده تحلیل بازار نوبیتکس'}
                          </div>
                        </div>

                        <div className="flex flex-wrap items-center gap-2 shrink-0">
                          {bot.isActive ? (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() => setStopTarget(bot)}
                              className="min-h-[40px] px-3.5 rounded-xl bg-amber-500/15 hover:bg-amber-500/25 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <Pause className="w-3.5 h-3.5" />
                              توقف
                            </button>
                          ) : (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() =>
                                void runBotAction(bot.id, () =>
                                  onStartBot(bot.id, bot.mode === 'live')
                                )
                              }
                              className="min-h-[40px] px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <Play className="w-3.5 h-3.5" />
                              شروع
                            </button>
                          )}

                          {bot.isActive && (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() =>
                                void runBotAction(bot.id, () => onEvaluateBot(bot.id))
                              }
                              className="min-h-[40px] px-3 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-cyan-200 text-xs font-bold flex items-center gap-1.5 whitespace-nowrap"
                            >
                              <RefreshCw className={`w-3.5 h-3.5 ${isBusy ? 'animate-spin' : ''}`} />
                              بررسی فوری
                            </button>
                          )}

                          {pos && (
                            <button
                              type="button"
                              disabled={isBusy}
                              onClick={() =>
                                void runBotAction(bot.id, () => onManualSellBot(bot.id))
                              }
                              className="min-h-[40px] px-3 rounded-xl border border-emerald-500/40 bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-200 text-xs font-bold whitespace-nowrap"
                            >
                              فروش دستی
                            </button>
                          )}

                          <button
                            type="button"
                            disabled={isBusy}
                            onClick={() =>
                              void runBotAction(bot.id, () => onDeleteBot(bot.id))
                            }
                            className="min-h-[40px] px-2.5 rounded-xl border border-rose-500/35 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300"
                            title="حذف ربات"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      {/* 5-step Visual Cycle Pipeline */}
                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[11px]">
                        {pipelineSteps.map((label, idx) => {
                          const stepNum = idx + 1;
                          const done = stepIdx > stepNum;
                          const current = stepIdx === stepNum;
                          return (
                            <div
                              key={label}
                              className={`rounded-lg border px-2.5 py-2 text-center font-bold transition ${
                                current
                                  ? 'border-cyan-400/70 bg-cyan-500/15 text-cyan-200'
                                  : done
                                    ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
                                    : 'border-slate-800 bg-slate-900/50 text-slate-500'
                              }`}
                            >
                              {label}
                            </div>
                          );
                        })}
                      </div>

                      {/* Metrics & Position Strip */}
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono-num tabular-nums">
                        <div className="rounded-xl border border-slate-800/90 bg-slate-900/50 p-3">
                          <div className="text-[11px] text-slate-400">سقف سرمایه / استفاده</div>
                          <div className="font-bold text-white mt-0.5">
                            {formatQuoteAmount(bot.capitalAmount, bot.quoteCurrency)}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            {bot.capitalUsageMode === 'PARTIAL'
                              ? `بخشی (${bot.capitalPortionPercent}٪)`
                              : 'کل سرمایه مجاز'}
                          </div>
                        </div>

                        <div className="rounded-xl border border-slate-800/90 bg-slate-900/50 p-3">
                          <div className="text-[11px] text-slate-400">عملکرد چرخه‌ها</div>
                          <div
                            className={`font-bold mt-0.5 ${
                              bot.stats.totalNetProfitQuote >= 0
                                ? 'text-emerald-300'
                                : 'text-rose-300'
                            }`}
                          >
                            {bot.stats.totalNetProfitQuote >= 0 ? '+' : '-'}
                            {formatQuoteAmount(
                              Math.abs(bot.stats.totalNetProfitQuote),
                              bot.quoteCurrency
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">
                            {bot.stats.completedCycles} چرخه ({bot.stats.winningCycles} برد)
                          </div>
                        </div>

                        {pos ? (
                          <>
                            <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/5 p-3">
                              <div className="text-[11px] text-emerald-300">خرید واقعی / دارایی خالص</div>
                              <div className="font-bold text-white mt-0.5">
                                {formatQuotePrice(pos.actualBuyAvgPrice, bot.quoteCurrency)}
                              </div>
                              <div className="text-[10px] text-slate-300 mt-0.5">
                                {formatQty(pos.netOwnedQty)} {bot.baseAsset}
                              </div>
                            </div>
                            <div className="rounded-xl border border-cyan-500/30 bg-cyan-500/5 p-3">
                              <div className="text-[11px] text-cyan-300">هدف فروش / بازده فعلی</div>
                              <div className="font-bold text-white mt-0.5">
                                {formatQuotePrice(pos.targetSellPrice, bot.quoteCurrency)}
                              </div>
                              <div
                                className={`text-[10px] font-bold mt-0.5 ${
                                  estPct >= 0 ? 'text-emerald-300' : 'text-rose-300'
                                }`}
                              >
                                {estPct >= 0 ? '+' : ''}
                                {estPct.toFixed(2)}٪ · حد ضرر: {formatQuotePrice(pos.stopLossPrice, bot.quoteCurrency)}
                              </div>
                            </div>
                          </>
                        ) : (
                          <>
                            <div className="rounded-xl border border-slate-800/90 bg-slate-900/50 p-3">
                              <div className="text-[11px] text-slate-400">حد ضرر / زیان روزانه</div>
                              <div className="font-bold text-slate-200 mt-0.5">
                                -{bot.stopLossPercent}٪ SL
                              </div>
                              <div className="text-[10px] text-slate-400 mt-0.5">
                                زیان امروز: {formatQuoteAmount(bot.dailyStats.lossQuote, bot.quoteCurrency)} /{' '}
                                {formatQuoteAmount(bot.maxDailyLoss, bot.quoteCurrency)}
                              </div>
                            </div>
                            <div className="rounded-xl border border-slate-800/90 bg-slate-900/50 p-3">
                              <div className="text-[11px] text-slate-400">کارمزد پرداختی کل</div>
                              <div className="font-bold text-slate-200 mt-0.5">
                                {formatQuoteAmount(bot.stats.totalFeesPaidQuote, bot.quoteCurrency)}
                              </div>
                              <div className="text-[10px] text-slate-400 mt-0.5">
                                {bot.executionConfirmationMode === 'MANUAL_CONFIRM'
                                  ? 'تأیید دستی کاربر'
                                  : 'اجرای تمام‌خودکار'}
                              </div>
                            </div>
                          </>
                        )}
                      </div>

                      {/* Last AI Decision Snapshot */}
                      {bot.lastDecision && (
                        <div className="rounded-xl border border-slate-800/80 bg-slate-950/70 p-3 text-xs space-y-1">
                          <div className="flex flex-wrap items-center justify-between gap-2">
                            <span className="font-bold text-cyan-300 flex items-center gap-1.5">
                              <Sparkles className="w-3.5 h-3.5" />
                              آخرین تحلیل AI ({bot.lastDecision.regimeLabelFa})
                            </span>
                            <span className="text-[11px] font-mono-num text-slate-400">
                              روند {bot.lastDecision.trendScore}/100 · نقدشوندگی{' '}
                              {bot.lastDecision.liquidityScore}/100 · اسپرد{' '}
                              {bot.lastDecision.spreadPercent.toFixed(2)}٪
                            </span>
                          </div>
                          <p className="text-slate-300 leading-6">{bot.lastDecision.reasoningFa}</p>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'SETTINGS' && (
        <div className="space-y-4">
          <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-5 space-y-4 text-xs">
            <div className="flex items-center gap-2 text-sm font-extrabold text-white">
              <ShieldCheck className="w-4 h-4 text-cyan-400" />
              تنظیمات پیش‌فرض مدیریت سرمایه و ریسک AI Cycle Pro
            </div>
            <p className="text-slate-400">
              این مقادیر برای ساخت ربات‌های جدید اعمال می‌شوند و ربات به صورت خودکار به سقف سرمایه و محدودیت‌های صرافی پایبند است.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">حد ضرر پیش‌فرض (٪)</label>
                <NumericInput
                  value={stopLossPercent}
                  onValueChange={(v) => setStopLossPercent(Math.min(30, Math.max(0.5, Number(v) || 0.5)))}
                  className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-white font-mono-num"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">
                  سقف زیان روزانه ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})
                </label>
                <NumericInput
                  value={maxDailyLoss}
                  onValueChange={(v) => setMaxDailyLoss(Math.max(0, Number(v) || 0))}
                  className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-white font-mono-num"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">حداقل هدف سود خالص چرخه (٪)</label>
                <NumericInput
                  value={minTargetNetProfitPercent}
                  onValueChange={(v) => setMinTargetNetProfitPercent(Math.min(15, Math.max(0.4, Number(v) || 0.4)))}
                  className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-white font-mono-num"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">حداکثر لغزش مجاز قیمت (٪)</label>
                <NumericInput
                  value={maxSlippagePercent}
                  onValueChange={(v) => setMaxSlippagePercent(Math.min(10, Math.max(0.05, Number(v) || 0.05)))}
                  className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-white font-mono-num"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-bold mb-1.5">حداکثر اسپرد مجاز بازار (٪)</label>
                <NumericInput
                  value={maxSpreadPercent}
                  onValueChange={(v) => setMaxSpreadPercent(Math.min(15, Math.max(0.05, Number(v) || 0.05)))}
                  className="w-full min-h-[42px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-white font-mono-num"
                />
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <label className="flex items-center gap-2 cursor-pointer text-slate-200 font-bold">
                <input
                  type="checkbox"
                  checked={autoRepeatCycles}
                  onChange={(e) => setAutoRepeatCycles(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
                شروع خودکار تحلیل برای چرخه بعدی پس از هر فروش موفق
              </label>
              <label className="flex items-center gap-2 cursor-pointer text-slate-200 font-bold">
                <input
                  type="checkbox"
                  checked={notifyTelegram}
                  onChange={(e) => setNotifyTelegram(e.target.checked)}
                  className="w-4 h-4 accent-cyan-500 rounded"
                />
                ارسال گزارش خرید و فروش چرخه در تلگرام
              </label>
            </div>
          </div>

          {/* Update existing bots quickly */}
          {bots.length > 0 && (
            <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-5 space-y-3 text-xs">
              <div className="text-sm font-extrabold text-white">به‌روزرسانی سریع تنظیمات ربات‌های موجود</div>
              <div className="space-y-2.5">
                {bots.map((b) => (
                  <div
                    key={b.id}
                    className="rounded-xl border border-slate-800 bg-slate-900/50 p-3 flex flex-wrap items-center justify-between gap-2"
                  >
                    <div>
                      <span className="font-bold text-white">{b.name}</span>{' '}
                      <span className="font-mono-num text-cyan-300">({b.symbol})</span>
                      <div className="text-[11px] text-slate-400">
                        تکرار خودکار: {b.autoRepeatCycles ? 'فعال' : 'تک‌چرخه'} · حد ضرر: -{b.stopLossPercent}٪
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        void runBotAction(b.id, () =>
                          onUpdateBot(b.id, {
                            autoRepeatCycles: !b.autoRepeatCycles,
                          })
                        )
                      }
                      className="min-h-[38px] px-3 rounded-lg border border-cyan-500/40 bg-cyan-500/10 text-cyan-200 font-bold"
                    >
                      {b.autoRepeatCycles ? 'تغییر به تک‌چرخه' : 'فعال‌سازی تکرار چرخه'}
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'EXECUTION' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-5 space-y-4 text-xs leading-7 text-slate-300">
          <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
            <Activity className="w-4 h-4 text-cyan-400" />
            مکانیزم هوشمند چرخه معامله در AI Cycle Pro
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-1.5">
              <div className="font-extrabold text-cyan-300">۱. تحلیل زنده بازار و دفتر سفارش نوبیتکس</div>
              <p>
                ربات قبل از هر خرید، روند ۱۵ دقیقه‌ای و ساعتی، حجم معاملات، نوسان و عمق دفتر سفارشات واقعی نوبیتکس را همراه با هوش مصنوعی Gemini بررسی می‌کند. اگر اسپرد زیاد باشد یا عمق خرید/فروش کافی نباشد، خرید انجام نمی‌شود و پول شما نقد می‌ماند.
              </p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-1.5">
              <div className="font-extrabold text-emerald-300">۲. خرید، محاسبه کارمزد واقعی و هدف فروش</div>
              <p>
                بعد از ثبت خرید، قیمت میانگین اجراشده، مقدار دارایی خالص و کارمزد ۰.۲۵٪ دقیق ثبت می‌شود. سپس قیمت فروش هدف با لحاظ کارمزد رفت‌وبرگشت و لغزش احتمالی هنگام فروش محاسبه می‌گردد تا سود خالص چرخه واقعی باشد.
              </p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-1.5">
              <div className="font-extrabold text-amber-300">۳. مدیریت سرمایه و جلوگیری از مصرف تکراری</div>
              <p>
                مبلغ انتخابی شما سقف سرمایه این ربات است. تا وقتی چرخه فعلی بسته نشده یا سفارش باز وجود دارد، خرید جدید تکراری ثبت نمی‌شود. همچنین حد ضرر و سقف زیان روزانه به صورت پیوسته محافظت می‌شوند.
              </p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-1.5">
              <div className="font-extrabold text-sky-300">۴. پایان چرخه و آغاز چرخه جدید</div>
              <p>
                به محض فروش و تحقق سود خالص، کارنامه چرخه با جزئیات کارمزد و سود خالص ثبت می‌شود و اگر گزینه تکرار خودکار فعال باشد، ربات دوباره از صفر بازار را برای فرصت بعدی تحلیل می‌کند.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'HISTORY' && (
        <div className="space-y-4">
          {/* Completed Cycles Table */}
          <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              تاریخچه چرخه‌های تکمیل‌شده ({cycles.length})
            </h3>
            {cycles.length === 0 ? (
              <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5 text-center text-xs text-slate-400">
                هنوز هیچ چرخه‌ای در AI Cycle Pro کامل نشده است.
              </div>
            ) : (
              <div className="space-y-2.5">
                {cycles.map((cy) => (
                  <div
                    key={cy.id}
                    className="rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 space-y-2 text-xs"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2 font-bold text-white">
                        <span className="font-mono-num text-cyan-300">#{cy.cycleIndex}</span>
                        <span>{cy.symbol}</span>
                        <span className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px]">
                          {EXIT_REASON_FA[cy.exitReason] || cy.exitReason}
                        </span>
                      </div>
                      <div
                        className={`font-mono-num font-extrabold ${
                          cy.finalNetProfitQuote >= 0 ? 'text-emerald-300' : 'text-rose-300'
                        }`}
                      >
                        {cy.finalNetProfitQuote >= 0 ? '+' : '-'}
                        {formatQuoteAmount(Math.abs(cy.finalNetProfitQuote), cy.quoteCurrency)}
                      </div>
                    </div>
                    <div className="flex flex-wrap items-center gap-4 text-[11px] font-mono-num text-slate-400">
                      <span>خرید: {formatQuotePrice(cy.actualBuyAvgPrice, cy.quoteCurrency)}</span>
                      <span>فروش: {formatQuotePrice(cy.actualSellAvgPrice, cy.quoteCurrency)}</span>
                      <span>
                        کارمزد کل:{' '}
                        {formatQuoteAmount(cy.buyFeeQuote + cy.sellFeeQuote, cy.quoteCurrency)}
                      </span>
                      <span>لغزش: {cy.slippagePercent.toFixed(2)}٪</span>
                      <span>{formatDateTimeShort(cy.completedAt)}</span>
                    </div>
                    {cy.aiExitSummaryFa && (
                      <div className="text-[11px] text-slate-300">{cy.aiExitSummaryFa}</div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Decision & Execution Logs */}
          <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <History className="w-4 h-4 text-cyan-400" />
              گزارش تصمیمات و رویدادهای ربات ({logs.length})
            </h3>
            {logs.length === 0 ? (
              <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-5 text-center text-xs text-slate-400">
                هنوز رویدادی ثبت نشده است.
              </div>
            ) : (
              <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
                {logs.map((lg) => (
                  <div
                    key={lg.id}
                    className="rounded-xl border border-slate-800/80 bg-slate-900/40 px-3 py-2.5 text-xs flex flex-col sm:flex-row sm:items-center justify-between gap-1.5"
                  >
                    <div className="space-y-0.5">
                      <span className="font-bold text-cyan-300 ml-2">[{lg.event}]</span>
                      <span className="text-slate-200">{lg.message}</span>
                    </div>
                    <span className="text-[10px] font-mono-num text-slate-500 shrink-0">
                      {formatDateTimeShort(lg.timestamp)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </BotPageShell>
  );
};
