import React, { useCallback, useEffect, useRef, useState } from 'react';
import { BrowserMultiFormatReader } from '@zxing/browser';
import { DecodeHintType } from '@zxing/library';
import jsQR from 'jsqr';
import {
  AlertCircle,
  Camera,
  ImageUp,
  QrCode,
  RefreshCw,
  SwitchCamera,
  Upload,
  X,
} from 'lucide-react';
import type { QrScanTarget } from '../utils/apiQrParser';

export type ScannerMode = 'CAMERA' | 'GALLERY';

interface QrBarcodeScannerModalProps {
  isOpen: boolean;
  initialMode?: ScannerMode;
  target: QrScanTarget;
  onClose: () => void;
  onDetected: (rawText: string) => void;
}

const TARGET_LABELS: Record<QrScanTarget, string> = {
  AUTO: 'تشخیص هوشمند API Key / Secret Key',
  API_KEY: 'اسکن کلید API (API Key)',
  SECRET_KEY: 'اسکن کلید مخفی (Secret Key)',
  TOKEN: 'اسکن توکن قدیمی نوبیتکس',
};

function createZxingReader(): BrowserMultiFormatReader {
  const hints = new Map<DecodeHintType, unknown>();
  hints.set(DecodeHintType.TRY_HARDER, true);
  return new BrowserMultiFormatReader(hints);
}

function decodeCanvasWithEngines(
  canvas: HTMLCanvasElement,
  zxingReader: BrowserMultiFormatReader
): string | null {
  const ctx = canvas.getContext('2d', { willReadFrequently: true });
  if (ctx && canvas.width > 0 && canvas.height > 0) {
    try {
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const qrResult = jsQR(imageData.data, imageData.width, imageData.height, {
        inversionAttempts: 'attemptBoth',
      });
      if (qrResult?.data?.trim()) {
        return qrResult.data;
      }
    } catch {
      // Fall through to ZXing
    }
  }

  try {
    const zxingResult = zxingReader.decodeFromCanvas(canvas);
    const text = zxingResult?.getText();
    if (text?.trim()) {
      return text;
    }
  } catch {
    // Expected NotFoundException when frame/pass has no code
  }
  return null;
}

async function loadImageFromFile(file: File): Promise<{
  width: number;
  height: number;
  draw: (ctx: CanvasRenderingContext2D, w: number, h: number) => void;
  cleanup: () => void;
}> {
  if (typeof createImageBitmap === 'function') {
    try {
      const bitmap = await createImageBitmap(file);
      return {
        width: bitmap.width,
        height: bitmap.height,
        draw: (ctx, w, h) => ctx.drawImage(bitmap, 0, 0, w, h),
        cleanup: () => bitmap.close(),
      };
    } catch {
      // Fallback to HTMLImageElement
    }
  }

  const objectUrl = URL.createObjectURL(file);
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      resolve({
        width: img.naturalWidth || img.width,
        height: img.naturalHeight || img.height,
        draw: (ctx, w, h) => ctx.drawImage(img, 0, 0, w, h),
        cleanup: () => URL.revokeObjectURL(objectUrl),
      });
    };
    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('فرمت تصویر انتخاب‌شده قابل خواندن نیست.'));
    };
    img.src = objectUrl;
  });
}

async function decodeImageFile(file: File): Promise<string | null> {
  const zxingReader = createZxingReader();
  const loaded = await loadImageFromFile(file);
  try {
    const maxEdge = Math.max(loaded.width, loaded.height);
    if (maxEdge <= 0) return null;

    const targetEdges = [Math.min(maxEdge, 1600), 900, 520];
    const uniqueWidths = Array.from(
      new Set(
        targetEdges.map((edge) => {
          const scale = edge / maxEdge;
          return Math.max(64, Math.round(loaded.width * scale));
        })
      )
    );

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d', { willReadFrequently: true });
    if (!ctx) return null;

    for (const targetW of uniqueWidths) {
      const targetH = Math.max(64, Math.round((loaded.height / loaded.width) * targetW));
      canvas.width = targetW;
      canvas.height = targetH;
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, targetW, targetH);
      loaded.draw(ctx, targetW, targetH);

      const hit = decodeCanvasWithEngines(canvas, zxingReader);
      if (hit) return hit;
    }

    return null;
  } finally {
    loaded.cleanup();
  }
}

export const QrBarcodeScannerModal: React.FC<QrBarcodeScannerModalProps> = ({
  isOpen,
  initialMode = 'CAMERA',
  target,
  onClose,
  onDetected,
}) => {
  const [mode, setMode] = useState<ScannerMode>(initialMode);
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [cameraStatus, setCameraStatus] = useState<'idle' | 'starting' | 'active' | 'error'>(
    'idle'
  );
  const [cameraError, setCameraError] = useState<string | null>(null);

  const [galleryPreviewUrl, setGalleryPreviewUrl] = useState<string | null>(null);
  const [galleryBusy, setGalleryBusy] = useState(false);
  const [galleryError, setGalleryError] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const zxingRef = useRef<BrowserMultiFormatReader | null>(null);
  const handledDetectionRef = useRef(false);

  const stopCameraStream = useCallback(() => {
    if (streamRef.current) {
      for (const track of streamRef.current.getTracks()) {
        try {
          track.stop();
        } catch {
          // Ignore track cleanup error
        }
      }
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
  }, []);

  useEffect(() => {
    if (!isOpen) {
      stopCameraStream();
      setCameraStatus('idle');
      setCameraError(null);
      setGalleryError(null);
      handledDetectionRef.current = false;
      return;
    }
    setMode(initialMode);
    setCameraError(null);
    setGalleryError(null);
    handledDetectionRef.current = false;
  }, [isOpen, initialMode, stopCameraStream]);

  useEffect(() => {
    return () => {
      stopCameraStream();
      if (galleryPreviewUrl) {
        URL.revokeObjectURL(galleryPreviewUrl);
      }
    };
  }, [stopCameraStream, galleryPreviewUrl]);

  const handleSuccessDetection = useCallback(
    (rawText: string) => {
      if (handledDetectionRef.current) return;
      handledDetectionRef.current = true;
      stopCameraStream();
      onDetected(rawText);
    },
    [onDetected, stopCameraStream]
  );

  // Start / manage live camera stream & scan interval
  useEffect(() => {
    if (!isOpen || mode !== 'CAMERA') {
      stopCameraStream();
      return;
    }

    if (!navigator.mediaDevices?.getUserMedia) {
      setCameraStatus('error');
      setCameraError(
        'مرورگر شما از دسترسی مستقیم به دوربین پشتیبانی نمی‌کند. لطفاً از تب گالری تصویر QR را انتخاب کنید.'
      );
      return;
    }

    let cancelled = false;
    let scanTimer: number | null = null;

    const startCamera = async () => {
      setCameraStatus('starting');
      setCameraError(null);
      stopCameraStream();

      try {
        const videoConstraints: MediaTrackConstraints = selectedDeviceId
          ? { deviceId: { exact: selectedDeviceId }, width: { ideal: 1280 }, height: { ideal: 720 } }
          : { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } };

        const stream = await navigator.mediaDevices.getUserMedia({
          video: videoConstraints,
          audio: false,
        });

        if (cancelled) {
          stream.getTracks().forEach((t) => t.stop());
          return;
        }

        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play().catch(() => undefined);
        }

        // Refresh enumerated cameras now that permission is granted
        if (navigator.mediaDevices.enumerateDevices) {
          const allDevices = await navigator.mediaDevices.enumerateDevices().catch(() => []);
          const cams = allDevices.filter((d) => d.kind === 'videoinput');
          if (!cancelled) {
            setDevices(cams);
            if (!selectedDeviceId && cams.length > 0) {
              const activeTrack = stream.getVideoTracks()[0];
              const activeId = activeTrack?.getSettings?.().deviceId;
              if (activeId) setSelectedDeviceId(activeId);
            }
          }
        }

        if (!zxingRef.current) {
          zxingRef.current = createZxingReader();
        }
        if (!scanCanvasRef.current) {
          scanCanvasRef.current = document.createElement('canvas');
        }

        setCameraStatus('active');

        scanTimer = window.setInterval(() => {
          if (cancelled || handledDetectionRef.current) return;
          const video = videoRef.current;
          const canvas = scanCanvasRef.current;
          const zxing = zxingRef.current;
          if (!video || !canvas || !zxing) return;
          if (video.readyState < 2 || video.videoWidth <= 0 || video.videoHeight <= 0) return;

          const maxDim = 960;
          const scale = Math.min(1, maxDim / Math.max(video.videoWidth, video.videoHeight));
          const w = Math.max(120, Math.round(video.videoWidth * scale));
          const h = Math.max(120, Math.round(video.videoHeight * scale));
          if (canvas.width !== w || canvas.height !== h) {
            canvas.width = w;
            canvas.height = h;
          }
          const ctx = canvas.getContext('2d', { willReadFrequently: true });
          if (!ctx) return;
          ctx.drawImage(video, 0, 0, w, h);

          const detected = decodeCanvasWithEngines(canvas, zxing);
          if (detected) {
            handleSuccessDetection(detected);
          }
        }, 180);
      } catch (err) {
        if (cancelled) return;
        setCameraStatus('error');
        const name = err instanceof Error ? err.name : '';
        if (name === 'NotAllowedError' || name === 'PermissionDeniedError') {
          setCameraError(
            'دسترسی به دوربین مسدود شده است. مجوز دوربین را در مرورگر فعال کنید یا تصویر بارکد را از گالری انتخاب کنید.'
          );
        } else if (name === 'NotFoundError' || name === 'DevicesNotFoundError') {
          setCameraError(
            'هیچ دوربینی روی دستگاه یافت نشد. می‌توانید از تب «انتخاب از گالری» تصویر QR را بارگذاری کنید.'
          );
        } else if (name === 'NotReadableError' || name === 'TrackStartError') {
          setCameraError(
            'دوربین در حال استفاده توسط برنامه دیگری است. آن را ببندید یا از گالری اسکن کنید.'
          );
        } else {
          setCameraError(
            'راه‌اندازی دوربین ناموفق بود. لطفاً مجوز مرورگر را بررسی کنید یا تصویر بارکد را از گالری بارگذاری نمایید.'
          );
        }
      }
    };

    void startCamera();

    return () => {
      cancelled = true;
      if (scanTimer !== null) {
        window.clearInterval(scanTimer);
      }
      stopCameraStream();
    };
  }, [isOpen, mode, selectedDeviceId, handleSuccessDetection, stopCameraStream]);

  const handleGalleryFile = async (file: File | undefined | null) => {
    if (!file) return;
    setGalleryError(null);
    if (!file.type.startsWith('image/') && !/\.(png|jpe?g|webp|gif|bmp|svg)$/i.test(file.name)) {
      setGalleryError('لطفاً یک فایل تصویری معتبر (PNG، JPG یا WebP) انتخاب کنید.');
      return;
    }

    if (galleryPreviewUrl) {
      URL.revokeObjectURL(galleryPreviewUrl);
    }
    const nextUrl = URL.createObjectURL(file);
    setGalleryPreviewUrl(nextUrl);
    setGalleryBusy(true);

    try {
      const result = await decodeImageFile(file);
      if (result) {
        handleSuccessDetection(result);
      } else {
        setGalleryError(
          'بارکد یا QR کد معتبری در این تصویر شناسایی نشد. لطفاً تصویر واضح‌تری را برش داده و دوباره انتخاب کنید.'
        );
      }
    } catch (err) {
      setGalleryError(
        err instanceof Error ? err.message : 'خطا در پردازش تصویر انتخاب‌شده.'
      );
    } finally {
      setGalleryBusy(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleCycleCamera = () => {
    if (devices.length < 2) return;
    const idx = devices.findIndex((d) => d.deviceId === selectedDeviceId);
    const next = devices[(idx + 1) % devices.length];
    if (next) {
      setSelectedDeviceId(next.deviceId);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/85 backdrop-blur-md p-4"
      role="dialog"
      aria-modal="true"
      aria-label="اسکنر بارکد و QR کلید API"
    >
      <div className="glass-panel w-full max-w-lg rounded-2xl border border-cyan-500/30 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-800/90 bg-slate-950/60">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-500/35 flex items-center justify-center text-cyan-300 shrink-0">
              <QrCode className="w-5 h-5" />
            </div>
            <div>
              <h4 className="text-sm font-semibold text-white">اسکنر بارکد و QR کلید API</h4>
              <p className="text-[11px] text-cyan-300/90">{TARGET_LABELS[target]}</p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="بستن اسکنر"
            className="btn-glass btn-glass-neutral p-2 rounded-lg text-slate-300 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Mode Switcher */}
        <div className="px-5 pt-4">
          <div className="grid grid-cols-2 gap-1.5 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => {
                setMode('CAMERA');
                setGalleryError(null);
              }}
              className={`btn-glass inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg font-medium ${
                mode === 'CAMERA'
                  ? 'btn-glass-primary font-semibold'
                  : 'btn-glass-neutral text-slate-400'
              }`}
            >
              <Camera className="w-4 h-4" />
              <span>اسکن با دوربین</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setMode('GALLERY');
                setCameraError(null);
              }}
              className={`btn-glass inline-flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg font-medium ${
                mode === 'GALLERY'
                  ? 'btn-glass-primary font-semibold'
                  : 'btn-glass-neutral text-slate-400'
              }`}
            >
              <ImageUp className="w-4 h-4" />
              <span>انتخاب تصویر از گالری</span>
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4">
          {mode === 'CAMERA' ? (
            <div className="space-y-3">
              <div className="relative aspect-[4/3] w-full overflow-hidden rounded-xl border border-slate-800 bg-slate-950 flex items-center justify-center">
                <video
                  ref={videoRef}
                  muted
                  playsInline
                  autoPlay
                  className={`w-full h-full object-cover ${
                    cameraStatus === 'active' ? 'opacity-100' : 'opacity-0'
                  }`}
                />

                {/* Scanning Reticle Overlay */}
                {cameraStatus === 'active' && (
                  <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                    <div className="w-52 h-52 sm:w-56 sm:h-56 relative">
                      <span className="absolute top-0 left-0 w-7 h-7 border-t-2 border-l-2 border-cyan-400 rounded-tl-lg" />
                      <span className="absolute top-0 right-0 w-7 h-7 border-t-2 border-r-2 border-cyan-400 rounded-tr-lg" />
                      <span className="absolute bottom-0 left-0 w-7 h-7 border-b-2 border-l-2 border-cyan-400 rounded-bl-lg" />
                      <span className="absolute bottom-0 right-0 w-7 h-7 border-b-2 border-r-2 border-cyan-400 rounded-br-lg" />
                      <div className="absolute inset-x-3 top-1/2 h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent animate-pulse" />
                    </div>
                  </div>
                )}

                {cameraStatus === 'starting' && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-xs text-slate-300">
                    <RefreshCw className="w-6 h-6 text-cyan-400 animate-spin" />
                    <span>در حال راه‌اندازی دوربین...</span>
                  </div>
                )}

                {cameraStatus === 'error' && (
                  <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-5 text-center">
                    <AlertCircle className="w-8 h-8 text-rose-400" />
                    <p className="text-xs text-rose-200 leading-relaxed max-w-xs">
                      {cameraError}
                    </p>
                    <button
                      type="button"
                      onClick={() => setMode('GALLERY')}
                      className="btn-glass btn-glass-primary inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold"
                    >
                      <ImageUp className="w-4 h-4" />
                      <span>انتخاب تصویر از گالری</span>
                    </button>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                <span>QR یا بارکد API Key / Secret Key را داخل کادر قرار دهید.</span>
                {devices.length > 1 && (
                  <button
                    type="button"
                    onClick={handleCycleCamera}
                    className="btn-glass btn-glass-neutral inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs text-cyan-300"
                  >
                    <SwitchCamera className="w-3.5 h-3.5" />
                    <span>تعویض دوربین</span>
                  </button>
                )}
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => void handleGalleryFile(e.target.files?.[0])}
              />

              <div
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  void handleGalleryFile(e.dataTransfer.files?.[0]);
                }}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    fileInputRef.current?.click();
                  }
                }}
                className={`cursor-pointer rounded-xl border-2 border-dashed p-6 text-center transition-all flex flex-col items-center justify-center gap-3 min-h-[210px] ${
                  isDragging
                    ? 'border-cyan-400 bg-cyan-500/10'
                    : 'border-slate-700 hover:border-cyan-500/60 bg-slate-950/60'
                }`}
              >
                {galleryPreviewUrl ? (
                  <img
                    src={galleryPreviewUrl}
                    alt="پیش‌نمایش تصویر بارکد"
                    className="max-h-40 rounded-lg border border-slate-700 object-contain"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-2xl bg-cyan-500/15 border border-cyan-500/30 flex items-center justify-center text-cyan-300">
                    <Upload className="w-6 h-6" />
                  </div>
                )}

                <div className="space-y-1">
                  <div className="text-xs font-semibold text-white">
                    {galleryBusy
                      ? 'در حال اسکن و رمزگشایی تصویر...'
                      : 'برای انتخاب عکس یا اسکرین‌شات بارکد از گالری کلیک کنید'}
                  </div>
                  <div className="text-[11px] text-slate-400">
                    یا تصویر QR / بارکد را به این کادر بکشید و رها کنید
                  </div>
                </div>
              </div>

              {galleryError && (
                <div className="rounded-lg border border-rose-500/35 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-200 flex items-start gap-2">
                  <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                  <span>{galleryError}</span>
                </div>
              )}
            </div>
          )}

          <div className="rounded-lg border border-slate-800 bg-slate-950/70 px-3.5 py-2.5 text-[11px] text-slate-400 leading-relaxed">
            پشتیبانی از QR Code، بارکدهای استاندارد (Code128 / DataMatrix)، کلید تکی و بارکدهای ترکیبی شامل هر دو مقدار API Key و Secret Key — تمام پردازش اسکن به‌صورت محلی روی دستگاه شما انجام می‌شود.
          </div>
        </div>
      </div>
    </div>
  );
};
