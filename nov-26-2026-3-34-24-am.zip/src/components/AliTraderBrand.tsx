import React from 'react';

export const SITE_BRAND_NAME = 'AI NobiBot';
export const SITE_DOMAIN = 'ainobibot.ir';
export const SITE_URL = 'https://ainobibot.ir';
export const USER_BRAND_LOGO_SRC =
  '/assets/aistudio/file_000000001f9c81f5bfb6600a368b4cc4_b124af47.png';

interface AiNobiBotMarkProps {
  className?: string;
}

export const AiNobiBotMark: React.FC<AiNobiBotMarkProps> = ({ className = 'w-10 h-10 sm:w-11 sm:h-11' }) => (
  <svg
    viewBox="0 0 64 64"
    fill="none"
    aria-hidden="true"
    className={`${className} rounded-xl border border-cyan-400/55 shadow-[0_0_22px_rgba(34,211,238,0.28)] shrink-0`}
  >
    <defs>
      <linearGradient id="ainobiBg" x1="0" y1="0" x2="64" y2="64" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#071936" />
        <stop offset="100%" stopColor="#030816" />
      </linearGradient>
      <linearGradient id="ainobiLine" x1="12" y1="48" x2="52" y2="14" gradientUnits="userSpaceOnUse">
        <stop offset="0%" stopColor="#06B6D4" />
        <stop offset="60%" stopColor="#38BDF8" />
        <stop offset="100%" stopColor="#F59E0B" />
      </linearGradient>
    </defs>
    <rect width="64" height="64" rx="14" fill="url(#ainobiBg)" />
    <path d="M16 44V31" stroke="#06B6D4" strokeWidth="4" strokeLinecap="round" />
    <path d="M26 44V22" stroke="#22D3EE" strokeWidth="4" strokeLinecap="round" />
    <path d="M36 44V27" stroke="#38BDF8" strokeWidth="4" strokeLinecap="round" />
    <path d="M46 44V16" stroke="#F59E0B" strokeWidth="4" strokeLinecap="round" />
    <path
      d="M14 25L26 16L36 21L48 12"
      stroke="url(#ainobiLine)"
      strokeWidth="2.4"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
    <circle cx="48" cy="12" r="3.5" fill="#FDE047" />
    <path d="M13 50H51" stroke="#38BDF8" strokeOpacity="0.45" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

interface AliTraderLogoProps {
  compact?: boolean;
}

export const AliTraderLogo: React.FC<AliTraderLogoProps> = ({ compact = false }) => {
  return (
    <div className="inline-flex items-center gap-2.5 select-none" dir="ltr">
      <AiNobiBotMark />

      {!compact && (
        <div className="text-left leading-tight">
          <div className="text-base sm:text-lg font-bold tracking-tight text-white font-display whitespace-nowrap">
            AI <span className="text-cyan-300">NobiBot</span>
          </div>
          <div className="text-[11px] font-medium tracking-wide text-amber-300/90 font-mono-num whitespace-nowrap">
            ainobibot.ir
          </div>
        </div>
      )}
    </div>
  );
};

interface SidebarPromoCardProps {
  onClick: () => void;
}

export const SidebarPromoCard: React.FC<SidebarPromoCardProps> = ({ onClick }) => {
  return (
    <button
      type="button"
      onClick={onClick}
      className="group relative w-full overflow-hidden rounded-2xl border border-cyan-400/35 bg-gradient-to-b from-[#072B4B] via-[#061836] to-[#030A1B] p-3.5 text-center shadow-[0_12px_32px_rgba(6,182,212,0.18)] transition-all duration-200 hover:border-cyan-300/70 hover:-translate-y-0.5"
    >
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-10 left-1/2 -translate-x-1/2 w-36 h-36 rounded-full bg-cyan-400/20 blur-2xl"
      />

      {/* Smart Trading Bot Holographic Art */}
      <div className="relative mx-auto w-28 h-24 flex items-center justify-center">
        <svg viewBox="0 0 120 100" className="w-full h-full drop-shadow-[0_6px_18px_rgba(34,211,238,0.32)]" fill="none">
          <defs>
            <linearGradient id="botShell" x1="20" y1="15" x2="80" y2="90" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#1E3A8A" />
              <stop offset="50%" stopColor="#0E7490" />
              <stop offset="100%" stopColor="#082F49" />
            </linearGradient>
            <linearGradient id="holoScreen" x1="65" y1="22" x2="112" y2="66" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="rgba(34,211,238,0.38)" />
              <stop offset="100%" stopColor="rgba(14,116,144,0.14)" />
            </linearGradient>
          </defs>

          <rect x="68" y="22" width="44" height="40" rx="6" fill="url(#holoScreen)" stroke="#22D3EE" strokeWidth="1.2" strokeOpacity="0.7" />
          <line x1="76" y1="50" x2="76" y2="38" stroke="#34D399" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="84" y1="53" x2="84" y2="41" stroke="#F43F5E" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="92" y1="48" x2="92" y2="32" stroke="#34D399" strokeWidth="2.5" strokeLinecap="round" />
          <line x1="100" y1="44" x2="100" y2="27" stroke="#67E8F9" strokeWidth="2.5" strokeLinecap="round" />
          <path d="M74 52L84 44L93 38L104 28" stroke="#67E8F9" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />

          <line x1="42" y1="14" x2="42" y2="22" stroke="#67E8F9" strokeWidth="2.2" strokeLinecap="round" />
          <circle cx="42" cy="11" r="3" fill="#22D3EE" />
          <rect x="22" y="22" width="40" height="30" rx="11" fill="url(#botShell)" stroke="#67E8F9" strokeWidth="1.6" />
          <rect x="27" y="28" width="30" height="17" rx="6" fill="#030816" stroke="#22D3EE" strokeOpacity="0.45" />
          <circle cx="35.5" cy="36.5" r="3" fill="#67E8F9" />
          <circle cx="48.5" cy="36.5" r="3" fill="#67E8F9" />

          <rect x="24" y="55" width="36" height="32" rx="9" fill="url(#botShell)" stroke="#38BDF8" strokeWidth="1.5" />
          <circle cx="42" cy="70" r="6" fill="#030816" stroke="#22D3EE" strokeWidth="1.5" />
          <circle cx="42" cy="70" r="2.5" fill="#22D3EE" />
          <path d="M60 64C67 64 71 58 75 54" stroke="#67E8F9" strokeWidth="4" strokeLinecap="round" />
        </svg>
      </div>

      <div className="relative space-y-0.5 mt-1">
        <div className="text-xs font-bold text-white group-hover:text-cyan-200 transition-colors">
          معامله هوشمند نوبیتکس
        </div>
        <div className="text-[11px] font-semibold text-cyan-300 font-mono-num" dir="ltr">
          ainobibot.ir
        </div>
      </div>
    </button>
  );
};

export const VipCrownArtwork: React.FC = () => {
  return (
    <div className="relative w-32 h-24 sm:w-40 sm:h-28 shrink-0 flex items-center justify-center select-none">
      <div
        aria-hidden="true"
        className="absolute inset-0 rounded-full bg-amber-400/25 blur-2xl"
      />
      <svg viewBox="0 0 160 112" className="relative w-full h-full drop-shadow-[0_10px_22px_rgba(245,158,11,0.38)]" fill="none">
        <defs>
          <linearGradient id="crownGold" x1="34" y1="18" x2="126" y2="78" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#FEF08A" />
            <stop offset="45%" stopColor="#F59E0B" />
            <stop offset="100%" stopColor="#B45309" />
          </linearGradient>
          <linearGradient id="pedestalDark" x1="25" y1="74" x2="135" y2="106" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#334155" />
            <stop offset="100%" stopColor="#090D16" />
          </linearGradient>
        </defs>

        <ellipse cx="80" cy="96" rx="58" ry="10" fill="url(#pedestalDark)" stroke="#FBBF24" strokeOpacity="0.32" />
        <ellipse cx="80" cy="86" rx="46" ry="8" fill="#1E293B" stroke="#FBBF24" strokeOpacity="0.48" />
        <ellipse cx="80" cy="76" rx="34" ry="6" fill="#0F172A" stroke="#FDE047" strokeOpacity="0.65" />

        <path
          d="M46 72L38 35L61 52L80 24L99 52L122 35L114 72H46Z"
          fill="url(#crownGold)"
          stroke="#FEF9C3"
          strokeWidth="1.6"
          strokeLinejoin="round"
        />
        <rect x="45" y="68" width="70" height="7" rx="3.5" fill="#FDE047" stroke="#92400E" strokeWidth="1" />
        <circle cx="38" cy="32" r="3.5" fill="#FEF08A" />
        <circle cx="80" cy="20" r="4.5" fill="#FEF08A" />
        <circle cx="122" cy="32" r="3.5" fill="#FEF08A" />
        <circle cx="80" cy="54" r="4" fill="#FFFBEB" opacity="0.85" />
      </svg>
    </div>
  );
};
