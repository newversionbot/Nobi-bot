import React, { useEffect, useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import {
  AiNobiBotMark,
  SITE_BRAND_NAME,
  SITE_DOMAIN,
  USER_BRAND_LOGO_SRC,
} from './AliTraderBrand';

interface StartupSplashProps {
  onComplete: () => void;
}

export const StartupSplash: React.FC<StartupSplashProps> = ({ onComplete }) => {
  const [exiting, setExiting] = useState(false);
  const [imgFailed, setImgFailed] = useState(false);

  useEffect(() => {
    const exitTimer = window.setTimeout(() => {
      setExiting(true);
    }, 1500);
    const doneTimer = window.setTimeout(() => {
      onComplete();
    }, 1850);

    return () => {
      window.clearTimeout(exitTimer);
      window.clearTimeout(doneTimer);
    };
  }, [onComplete]);

  const handleSkip = () => {
    setExiting(true);
    window.setTimeout(onComplete, 200);
  };

  return (
    <div
      role="status"
      aria-label={`در حال راه‌اندازی داشبورد ${SITE_BRAND_NAME} (${SITE_DOMAIN})`}
      className={`fixed inset-0 z-50 flex items-center justify-center bg-[#030816]/96 backdrop-blur-2xl px-4 transition-all duration-300 ${
        exiting ? 'opacity-0 scale-[1.02] pointer-events-none' : 'opacity-100 scale-100'
      }`}
    >
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-[520px] h-[520px] rounded-full bg-cyan-500/12 blur-3xl" />
        <div className="absolute left-1/2 top-1/2 -translate-x-1/3 -translate-y-2/3 w-[320px] h-[320px] rounded-full bg-amber-400/10 blur-3xl" />
      </div>

      <div className="relative z-10 w-full max-w-md glass-panel rounded-2xl p-8 text-center space-y-6 splash-card-enter shadow-[0_24px_80px_rgba(2,6,23,0.85)]">
        <div className="relative mx-auto w-36 h-36 flex items-center justify-center">
          <div
            aria-hidden="true"
            className="absolute inset-0 rounded-full border border-cyan-400/35 border-t-cyan-400/95 border-l-amber-400/55 splash-orbit-cw"
          />
          <div
            aria-hidden="true"
            className="absolute inset-2.5 rounded-full border border-slate-700/40 border-b-cyan-300/70 splash-orbit-ccw"
          />
          <div className="relative w-28 h-28 rounded-full overflow-hidden border-2 border-cyan-400/65 shadow-[0_0_36px_rgba(6,182,212,0.38)] bg-slate-950 flex items-center justify-center">
            {imgFailed ? (
              <AiNobiBotMark className="w-full h-full border-0 shadow-none" />
            ) : (
              <img
                src={USER_BRAND_LOGO_SRC}
                alt={`عکس اختصاصی مدیر ${SITE_BRAND_NAME} — ${SITE_DOMAIN}`}
                referrerPolicy="no-referrer"
                onError={() => setImgFailed(true)}
                className="w-full h-full object-cover object-top"
              />
            )}
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="text-2xl font-bold tracking-tight text-white font-display" dir="ltr">
            AI <span className="text-cyan-300">NobiBot</span>
          </div>
          <div className="text-xs font-semibold text-amber-300/95 font-mono-num" dir="ltr">
            {SITE_DOMAIN}
          </div>
          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pt-1">
            سلام رفیق! ربات‌های شکارچی سود دارن موتورها رو گرم می‌کنن، یه چشم به هم بزنی آماده‌ایم...
          </p>
        </div>

        <div className="space-y-2">
          <div className="h-1.5 w-full rounded-full bg-slate-900/90 border border-slate-800/80 overflow-hidden">
            <div className="h-full rounded-full bg-gradient-to-l from-cyan-400 via-sky-300 to-amber-300 splash-progress-fill" />
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>اتصال زنده به نبض نوبیتکس</span>
            <button
              type="button"
              onClick={handleSkip}
              className="btn-glass btn-glass-primary inline-flex items-center gap-1 px-3 py-1 rounded-md text-[11px] font-semibold"
            >
              <span>بزن بریم</span>
              <ArrowLeft className="w-3 h-3" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
