import React, { useEffect, useMemo, useState } from 'react';
import { RefreshCw, Send, Trash2 } from 'lucide-react';
import type {
  ExecutionMode,
  IndicatorSnapshot,
  KlineCandle,
  OrderBookSnapshot,
  PriceAlert,
  PriceAlertCondition,
  QuoteCurrency,
  RecentTrade,
  SpotBalance,
  SpotOrder,
  Timeframe,
  UnifiedMarketTicker,
} from '../types/trading';
import { CandlestickChart } from './CandlestickChart';
import { CoinSearchSelect } from './CoinSearchSelect';
import { NumericInput } from './NumericInput';
import { PriceAlertsWidget } from './PriceAlertsWidget';
import {
  formatCompactToman,
  formatCompactUsd,
  formatPercent,
  formatPrice,
  formatQty,
  formatQuoteAmount,
  formatQuotePrice,
  formatTimeShort,
  formatToman,
} from '../utils/format';

interface TradingTerminalProps {
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  onSelectPair: (baseAsset: string, quoteCurrency: QuoteCurrency) => void;
  timeframe: Timeframe;
  onTimeframeChange: (tf: Timeframe) => void;
  markets: UnifiedMarketTicker[];
  usdtTomanRate: number;
  candles: KlineCandle[];
  analysis: IndicatorSnapshot | null;
  orderBook: OrderBookSnapshot | null;
  recentTrades: RecentTrade[];
  balances: SpotBalance[];
  openOrders: SpotOrder[];
  orderHistory: SpotOrder[];
  alerts: PriceAlert[];
  executionMode: ExecutionMode;
  isAuthenticated: boolean;
  loadingChart: boolean;
  onRequireAuth: () => void;
  onPlaceOrder: (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    side: 'BUY' | 'SELL';
    type: 'LIMIT' | 'MARKET';
    quantity: number;
    price?: number;
    stopLossPrice?: number;
    takeProfitPrice?: number;
    confirmLive?: boolean;
  }) => Promise<void>;
  onCancelOrder: (orderId: string) => Promise<void>;
  onResetPaperWallet: () => Promise<void>;
  onCreateAlert: (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    condition: PriceAlertCondition;
    targetPrice: number;
    sendTelegram?: boolean;
    note?: string;
  }) => Promise<void>;
  onRearmAlert: (alertId: string) => Promise<void>;
  onDeleteAlert: (alertId: string) => Promise<void>;
  telegramConnected?: boolean;
  onOpenTelegramSettings?: () => void;
  onSendTradesReportToTelegram?: () => Promise<{ title?: string; preview?: string } | void>;
  requestedBottomTab?: 'OPEN' | 'HISTORY' | 'BALANCES' | 'ALERTS';
  requestedBottomTabNonce?: number;
}

export const TradingTerminal: React.FC<TradingTerminalProps> = ({
  baseAsset,
  quoteCurrency,
  onSelectPair,
  timeframe,
  onTimeframeChange,
  markets,
  usdtTomanRate,
  candles,
  analysis,
  orderBook,
  recentTrades,
  balances,
  openOrders,
  orderHistory,
  alerts,
  executionMode,
  isAuthenticated,
  loadingChart,
  onRequireAuth,
  onPlaceOrder,
  onCancelOrder,
  onResetPaperWallet,
  onCreateAlert,
  onRearmAlert,
  onDeleteAlert,
  telegramConnected = false,
  onOpenTelegramSettings,
  onSendTradesReportToTelegram,
  requestedBottomTab,
  requestedBottomTabNonce,
}) => {
  const market = useMemo(
    () => markets.find((m) => m.baseAsset === baseAsset) || null,
    [markets, baseAsset]
  );

  const symbol = `${baseAsset}${quoteCurrency}`;
  const [side, setSide] = useState<'BUY' | 'SELL'>('BUY');
  const [orderType, setOrderType] = useState<'MARKET' | 'LIMIT'>('LIMIT');
  const [limitPrice, setLimitPrice] = useState<string>('');
  const [quantity, setQuantity] = useState<string>('');
  const [slPrice, setSlPrice] = useState<string>('');
  const [tpPrice, setTpPrice] = useState<string>('');
  const [bookTab, setBookTab] = useState<'BOOK' | 'TRADES'>('BOOK');
  const [bottomTab, setBottomTab] = useState<'OPEN' | 'HISTORY' | 'BALANCES' | 'ALERTS'>(
    requestedBottomTab || 'OPEN'
  );
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (requestedBottomTab) {
      setBottomTab(requestedBottomTab);
    }
  }, [requestedBottomTab, requestedBottomTabNonce]);
  const [orderMsg, setOrderMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [confirmLiveOrder, setConfirmLiveOrder] = useState(false);
  const [sendingTgReport, setSendingTgReport] = useState(false);
  const [tgReportMsg, setTgReportMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    setConfirmLiveOrder(false);
  }, [executionMode, side, baseAsset, quoteCurrency]);

  const currentPrice =
    quoteCurrency === 'IRT'
      ? market?.priceToman || candles[candles.length - 1]?.close || 0
      : market?.priceUsdt || candles[candles.length - 1]?.close || 0;

  const effectivePrice =
    orderType === 'LIMIT' && Number(limitPrice) > 0 ? Number(limitPrice) : currentPrice;

  const freeQuote = balances.find((b) => b.asset === quoteCurrency)?.free || 0;
  const freeBase = balances.find((b) => b.asset === baseAsset)?.free || 0;

  const orderTotalQuote = (Number(quantity) || 0) * effectivePrice;
  const orderEquivalentOther =
    quoteCurrency === 'IRT'
      ? usdtTomanRate > 0
        ? orderTotalQuote / usdtTomanRate
        : 0
      : orderTotalQuote * usdtTomanRate;

  const handlePercentClick = (pct: number) => {
    if (side === 'BUY') {
      if (effectivePrice <= 0) return;
      const spend = (freeQuote * pct) / 100;
      const qty = spend / effectivePrice;
      setQuantity(qty > 0 ? qty.toFixed(6) : '');
    } else {
      const qty = (freeBase * pct) / 100;
      setQuantity(qty > 0 ? qty.toFixed(6) : '');
    }
  };

  const handleFillPrice = (p: number) => {
    setOrderType('LIMIT');
    setLimitPrice(String(p));
  };

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setOrderMsg(null);
    if (!isAuthenticated) {
      onRequireAuth();
      return;
    }
    const qtyNum = Number(quantity);
    if (!qtyNum || qtyNum <= 0) {
      setOrderMsg({ type: 'err', text: 'مقدار سفارش را به‌درستی وارد کنید.' });
      return;
    }
    if (orderType === 'LIMIT' && (!limitPrice || Number(limitPrice) <= 0)) {
      setOrderMsg({ type: 'err', text: 'قیمت لیمیت معتبر وارد کنید.' });
      return;
    }
    if (executionMode === 'live' && !confirmLiveOrder) {
      setOrderMsg({
        type: 'err',
        text: 'برای ارسال سفارش واقعی روی صرافی نوبیتکس، ابتدا تیک تأیید معامله واقعی را فعال کنید.',
      });
      return;
    }

    setSubmitting(true);
    try {
      await onPlaceOrder({
        baseAsset,
        quoteCurrency,
        side,
        type: orderType,
        quantity: qtyNum,
        price: orderType === 'LIMIT' ? Number(limitPrice) : undefined,
        stopLossPrice: Number(slPrice) > 0 ? Number(slPrice) : undefined,
        takeProfitPrice: Number(tpPrice) > 0 ? Number(tpPrice) : undefined,
        confirmLive: executionMode === 'live' ? confirmLiveOrder : undefined,
      });
      setOrderMsg({
        type: 'ok',
        text: `سفارش ${side === 'BUY' ? 'خرید' : 'فروش'} ${orderType === 'MARKET' ? 'آنی' : 'لیمیت'} روی نوبیتکس ثبت شد.`,
      });
      setQuantity('');
      setConfirmLiveOrder(false);
    } catch (err) {
      setOrderMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'ثبت سفارش ناموفق بود.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const maxAskTotal = orderBook?.asks[orderBook.asks.length - 1]?.total || 1;
  const maxBidTotal = orderBook?.bids[orderBook.bids.length - 1]?.total || 1;
  const isUp = (market?.change24hPercent ?? 0) >= 0;

  return (
    <div className="space-y-4">
      {/* Top Pair Telemetry Strip (Dual Toman + USD) */}
      <div className="glass-strip rounded-xl px-4 py-3 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3">
          <div className="w-52 sm:w-60">
            <CoinSearchSelect
              markets={markets}
              value={baseAsset}
              quoteCurrency={quoteCurrency}
              onChange={(nextBase) => {
                const nextM = markets.find((m) => m.baseAsset === nextBase);
                const nextQc =
                  quoteCurrency === 'IRT' && nextM && !nextM.hasIrtMarket
                    ? 'USDT'
                    : quoteCurrency === 'USDT' && nextM && !nextM.hasUsdtMarket
                      ? 'IRT'
                      : quoteCurrency;
                onSelectPair(nextBase, nextQc);
                setLimitPrice('');
              }}
              ariaLabel="جستجو و انتخاب ارز ترمینال"
            />
          </div>

          {/* IRT / USDT Market Switch */}
          <div className="flex items-center gap-1.5 bg-slate-950/70 p-1 rounded-xl border border-slate-800/80 text-xs">
            <button
              type="button"
              disabled={market ? !market.hasIrtMarket : false}
              onClick={() => {
                onSelectPair(baseAsset, 'IRT');
                setLimitPrice('');
              }}
              className={`btn-glass px-3 py-1.5 rounded-lg font-medium whitespace-nowrap shrink-0 ${
                quoteCurrency === 'IRT'
                  ? 'btn-glass-amber font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              بازار تومانی (IRT)
            </button>
            <button
              type="button"
              disabled={market ? !market.hasUsdtMarket : false}
              onClick={() => {
                onSelectPair(baseAsset, 'USDT');
                setLimitPrice('');
              }}
              className={`btn-glass px-3 py-1.5 rounded-lg font-medium whitespace-nowrap shrink-0 ${
                quoteCurrency === 'USDT'
                  ? 'btn-glass-primary font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              بازار تتری (USDT)
            </button>
          </div>

          <div className="flex items-baseline gap-3" dir="ltr">
            <span
              className={`text-lg font-bold font-mono-num ${
                isUp ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {formatToman(market?.priceToman ?? (quoteCurrency === 'IRT' ? currentPrice : currentPrice * usdtTomanRate))}{' '}
              <span className="text-xs font-sans">تومان</span>
            </span>
            <span className="text-sm font-mono-num text-slate-300">
              ${formatPrice(market?.priceUsdt ?? (quoteCurrency === 'USDT' ? currentPrice : usdtTomanRate > 0 ? currentPrice / usdtTomanRate : 0))}
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-5 text-xs" dir="ltr">
          <div>
            <div className="text-slate-500 mb-0.5 text-right">تغییر ۲۴h</div>
            <div
              className={`font-mono-num font-medium ${
                isUp ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {formatPercent(market?.change24hPercent)}
            </div>
          </div>
          <div>
            <div className="text-slate-500 mb-0.5 text-right">سقف ۲۴h</div>
            <div className="font-mono-num text-slate-200">
              {quoteCurrency === 'IRT'
                ? `${formatToman(market?.high24hToman)} ت`
                : `$${formatPrice(market?.high24hUsdt)}`}
            </div>
          </div>
          <div>
            <div className="text-slate-500 mb-0.5 text-right">کف ۲۴h</div>
            <div className="font-mono-num text-slate-200">
              {quoteCurrency === 'IRT'
                ? `${formatToman(market?.low24hToman)} ت`
                : `$${formatPrice(market?.low24hUsdt)}`}
            </div>
          </div>
          <div>
            <div className="text-slate-500 mb-0.5 text-right">حجم ۲۴h</div>
            <div className="font-mono-num text-slate-200">
              {quoteCurrency === 'IRT'
                ? formatCompactToman(market?.volumeToman)
                : formatCompactUsd(market?.volumeUsdt)}
            </div>
          </div>
          {analysis && (
            <div>
              <div className="text-slate-500 mb-0.5 text-right">سیگنال</div>
              <div
                className={`font-medium text-right ${
                  analysis.signal.action.includes('BUY')
                    ? 'text-emerald-400'
                    : analysis.signal.action.includes('SELL')
                      ? 'text-rose-400'
                      : 'text-slate-300'
                }`}
                dir="rtl"
              >
                {analysis.signal.labelFa}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Main 3-Column Trading Workspace */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 items-start">
        <div className="xl:col-span-7">
          <CandlestickChart
            symbol={symbol}
            timeframe={timeframe}
            onTimeframeChange={onTimeframeChange}
            candles={candles}
            analysis={analysis}
            loading={loadingChart}
            stopLossPrice={Number(slPrice) > 0 ? Number(slPrice) : undefined}
            takeProfitPrice={Number(tpPrice) > 0 ? Number(tpPrice) : undefined}
          />
        </div>

        {/* Order Book & Recent Trades */}
        <div className="xl:col-span-2 glass-panel rounded-xl overflow-hidden">
          <div className="flex items-center gap-1 border-b border-slate-800/90 p-1.5 bg-[#060A14]/75">
            <button
              type="button"
              onClick={() => setBookTab('BOOK')}
              className={`btn-glass flex-1 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 ${
                bookTab === 'BOOK' ? 'btn-glass-primary' : 'btn-glass-neutral text-slate-400'
              }`}
            >
              دفتر سفارش
            </button>
            <button
              type="button"
              onClick={() => setBookTab('TRADES')}
              className={`btn-glass flex-1 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 ${
                bookTab === 'TRADES'
                  ? 'btn-glass-primary'
                  : 'btn-glass-neutral text-slate-400'
              }`}
            >
              معاملات اخیر
            </button>
          </div>

          {bookTab === 'BOOK' ? (
            <div className="p-2 text-[11px] font-mono-num" dir="ltr">
              <div className="flex justify-between text-slate-500 px-1.5 pb-1.5 border-b border-slate-800/70">
                <span>Price ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})</span>
                <span>Qty</span>
              </div>

              <div className="space-y-0.5 py-1">
                {(orderBook?.asks || [])
                  .slice(0, 9)
                  .reverse()
                  .map((a, idx) => (
                    <button
                      key={`ask-${idx}`}
                      type="button"
                      onClick={() => handleFillPrice(a.price)}
                      className="w-full relative flex justify-between px-1.5 py-0.5 rounded hover:bg-slate-800/60 text-left"
                    >
                      <span
                        className="absolute inset-y-0 right-0 bg-rose-500/10 pointer-events-none"
                        style={{ width: `${Math.min(100, (a.total / maxAskTotal) * 100)}%` }}
                      />
                      <span className="text-rose-400 relative z-10">
                        {quoteCurrency === 'IRT' ? formatToman(a.price) : formatPrice(a.price)}
                      </span>
                      <span className="text-slate-300 relative z-10">{formatQty(a.quantity)}</span>
                    </button>
                  ))}
              </div>

              <div className="my-1.5 py-1.5 px-2 rounded bg-slate-950 border border-slate-800/90 flex items-center justify-between">
                <span className="text-slate-200 font-semibold">
                  {formatQuotePrice(currentPrice, quoteCurrency)}
                </span>
                <span className="text-[10px] text-slate-500">
                  Spread {orderBook ? `${orderBook.spreadPercent.toFixed(2)}%` : '—'}
                </span>
              </div>

              <div className="space-y-0.5 py-1">
                {(orderBook?.bids || []).slice(0, 9).map((b, idx) => (
                  <button
                    key={`bid-${idx}`}
                    type="button"
                    onClick={() => handleFillPrice(b.price)}
                    className="w-full relative flex justify-between px-1.5 py-0.5 rounded hover:bg-slate-800/60 text-left"
                  >
                    <span
                      className="absolute inset-y-0 right-0 bg-emerald-500/10 pointer-events-none"
                      style={{ width: `${Math.min(100, (b.total / maxBidTotal) * 100)}%` }}
                    />
                    <span className="text-emerald-400 relative z-10">
                      {quoteCurrency === 'IRT' ? formatToman(b.price) : formatPrice(b.price)}
                    </span>
                    <span className="text-slate-300 relative z-10">{formatQty(b.quantity)}</span>
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <div className="p-2 text-[11px] font-mono-num max-h-[430px] overflow-y-auto" dir="ltr">
              <div className="flex justify-between text-slate-500 px-1.5 pb-1.5 border-b border-slate-800/70">
                <span>Price</span>
                <span>Qty</span>
                <span>Time</span>
              </div>
              <div className="divide-y divide-slate-800/40">
                {recentTrades.map((tr) => (
                  <div key={tr.id} className="flex justify-between px-1.5 py-1">
                    <span className={tr.isBuyerMaker ? 'text-rose-400' : 'text-emerald-400'}>
                      {quoteCurrency === 'IRT' ? formatToman(tr.price) : formatPrice(tr.price)}
                    </span>
                    <span className="text-slate-300">{formatQty(tr.quantity)}</span>
                    <span className="text-slate-500">{formatTimeShort(tr.time)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Spot Order Execution Ticket (Dual Currency Summary) */}
        <div className="xl:col-span-3 glass-panel rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-white">خرید و فروش اسپات نوبیتکس</h3>
            <span className="text-xs text-slate-400">
              {executionMode === 'live' ? 'حساب واقعی' : 'حساب تمرینی'}
            </span>
          </div>

          <div className="grid grid-cols-2 gap-1.5 bg-slate-950/75 p-1 rounded-xl border border-slate-800/80">
            <button
              type="button"
              onClick={() => setSide('BUY')}
              className={`btn-glass py-2 text-xs font-semibold rounded-lg ${
                side === 'BUY'
                  ? 'btn-glass-buy'
                  : 'btn-glass-neutral text-slate-400'
              }`}
            >
              خرید {baseAsset}
            </button>
            <button
              type="button"
              onClick={() => setSide('SELL')}
              className={`btn-glass py-2 text-xs font-semibold rounded-lg ${
                side === 'SELL'
                  ? 'btn-glass-sell'
                  : 'btn-glass-neutral text-slate-400'
              }`}
            >
              فروش {baseAsset}
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <button
              type="button"
              onClick={() => setOrderType('LIMIT')}
              className={`btn-glass px-3 py-1.5 rounded-lg whitespace-nowrap shrink-0 ${
                orderType === 'LIMIT'
                  ? 'btn-glass-primary'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              قیمت دلخواه (Limit)
            </button>
            <button
              type="button"
              onClick={() => setOrderType('MARKET')}
              className={`btn-glass px-3 py-1.5 rounded-lg whitespace-nowrap shrink-0 ${
                orderType === 'MARKET'
                  ? 'btn-glass-primary'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              خرید/فروش آنی (Market)
            </button>
          </div>

          <form onSubmit={handleSubmitOrder} className="space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>موجودی قابل استفاده:</span>
              <span className="font-mono-num text-slate-200" dir="ltr">
                {side === 'BUY'
                  ? formatQuoteAmount(freeQuote, quoteCurrency)
                  : `${formatQty(freeBase)} ${baseAsset}`}
              </span>
            </div>

            {orderType === 'LIMIT' ? (
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  قیمت سفارش ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})
                </label>
                <NumericInput
                  value={limitPrice}
                  onValueChange={setLimitPrice}
                  placeholder={
                    quoteCurrency === 'IRT'
                      ? String(Math.round(currentPrice))
                      : formatPrice(currentPrice)
                  }
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-400"
                />
              </div>
            ) : (
              <div className="bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs text-slate-400 flex items-center justify-between">
                <span>قیمت اجرا:</span>
                <span className="font-mono-num text-slate-200" dir="ltr">
                  ~{formatQuotePrice(currentPrice, quoteCurrency)}
                </span>
              </div>
            )}

            <div>
              <label className="block text-xs text-slate-400 mb-1">مقدار ({baseAsset})</label>
              <NumericInput
                value={quantity}
                onValueChange={setQuantity}
                placeholder="0.0000"
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {[25, 50, 75, 100].map((pct) => (
                <button
                  key={pct}
                  type="button"
                  onClick={() => handlePercentClick(pct)}
                  className="btn-glass btn-glass-neutral py-1 text-xs font-mono-num rounded-lg"
                >
                  {pct}%
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">حد ضرر (اختیاری)</label>
                <NumericInput
                  value={slPrice}
                  onValueChange={setSlPrice}
                  placeholder="SL"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-rose-300 focus:outline-none focus:border-rose-500"
                />
              </div>
              <div>
                <label className="block text-[11px] text-slate-400 mb-1">حد سود (اختیاری)</label>
                <NumericInput
                  value={tpPrice}
                  onValueChange={setTpPrice}
                  placeholder="TP"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-emerald-300 focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="pt-2 border-t border-slate-800 space-y-1 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400">ارزش کل سفارش:</span>
                <span className="font-mono-num font-semibold text-white" dir="ltr">
                  {formatQuoteAmount(orderTotalQuote, quoteCurrency)}
                </span>
              </div>
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <span>معادل {quoteCurrency === 'IRT' ? 'دلاری (تتر)' : 'تومانی'}:</span>
                <span className="font-mono-num" dir="ltr">
                  {quoteCurrency === 'IRT'
                    ? `≈ $${orderEquivalentOther.toFixed(2)} USDT`
                    : `≈ ${formatToman(orderEquivalentOther)} تومان`}
                </span>
              </div>
            </div>

            {executionMode === 'live' && isAuthenticated && (
              <label className="flex items-start gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-[11px] text-amber-200 cursor-pointer">
                <input
                  type="checkbox"
                  checked={confirmLiveOrder}
                  onChange={(e) => setConfirmLiveOrder(e.target.checked)}
                  className="mt-0.5 accent-amber-400 shrink-0"
                />
                <span>
                  تأیید می‌کنم این سفارش با دارایی واقعی حساب نوبیتکس من ثبت شود.
                </span>
              </label>
            )}

            {orderMsg && (
              <div
                className={`text-xs px-3 py-2 rounded border ${
                  orderMsg.type === 'ok'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                }`}
              >
                {orderMsg.text}
              </div>
            )}

            <button
              type="submit"
              disabled={submitting}
              className={`btn-glass w-full py-2.5 px-4 rounded-xl text-sm font-semibold ${
                side === 'BUY' ? 'btn-glass-buy' : 'btn-glass-sell'
              }`}
            >
              {!isAuthenticated
                ? 'برای ثبت سفارش وارد حساب شوید'
                : submitting
                  ? 'در حال ارسال سفارش...'
                  : `${side === 'BUY' ? 'ثبت خرید' : 'ثبت فروش'} ${baseAsset} (${quoteCurrency === 'IRT' ? 'تومانی' : 'تتری'})`}
            </button>
          </form>
        </div>
      </div>

      {/* Bottom Open Orders / History / Balances Panel */}
      <div className="glass-panel rounded-xl overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 px-4 py-2.5 border-b border-slate-800/90 bg-[#060A14]/75">
          <div className="flex flex-wrap items-center gap-1.5">
            <button
              type="button"
              onClick={() => setBottomTab('OPEN')}
              className={`btn-glass px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 ${
                bottomTab === 'OPEN'
                  ? 'btn-glass-primary font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              سفارش‌های باز ({openOrders.length})
            </button>
            <button
              type="button"
              onClick={() => setBottomTab('HISTORY')}
              className={`btn-glass px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 ${
                bottomTab === 'HISTORY'
                  ? 'btn-glass-primary font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              تاریخچه معاملات ({orderHistory.length})
            </button>
            <button
              type="button"
              onClick={() => setBottomTab('BALANCES')}
              className={`btn-glass px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 ${
                bottomTab === 'BALANCES'
                  ? 'btn-glass-primary font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              کیف پول تومانی و دلاری ({balances.length})
            </button>
            <button
              type="button"
              onClick={() => setBottomTab('ALERTS')}
              className={`btn-glass px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0 ${
                bottomTab === 'ALERTS'
                  ? 'btn-glass-amber font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              هشدار قیمت ({alerts.length})
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onSendTradesReportToTelegram && isAuthenticated && (
              <button
                type="button"
                disabled={sendingTgReport}
                onClick={async () => {
                  setTgReportMsg(null);
                  setSendingTgReport(true);
                  try {
                    const res = await onSendTradesReportToTelegram();
                    setTgReportMsg({
                      type: 'ok',
                      text: res?.title
                        ? `${res.title} با موفقیت به تلگرام ارسال شد.`
                        : 'گزارش خرید و فروش‌ها با موفقیت به ربات تلگرام ارسال شد.',
                    });
                  } catch (err) {
                    setTgReportMsg({
                      type: 'err',
                      text:
                        err instanceof Error
                          ? err.message
                          : 'ارسال گزارش خرید و فروش به تلگرام ناموفق بود.',
                    });
                  } finally {
                    setSendingTgReport(false);
                  }
                }}
                className="btn-glass btn-glass-telegram inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium rounded-lg whitespace-nowrap shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>
                  {sendingTgReport ? 'در حال ارسال...' : 'ارسال گزارش خرید و فروش به تلگرام'}
                </span>
              </button>
            )}

            {executionMode === 'paper' && isAuthenticated && (
              <button
                type="button"
                onClick={() => void onResetPaperWallet()}
                className="btn-glass btn-glass-sync inline-flex items-center gap-1.5 px-3 py-1.5 text-xs rounded-lg whitespace-nowrap shrink-0"
              >
                <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                <span>بازنشانی اعتبار تمرینی (۵۰۰ میلیون ت + ۵,۰۰۰ تتر)</span>
              </button>
            )}
          </div>
        </div>

        {tgReportMsg && (
          <div
            className={`mx-4 mt-3 text-xs px-3 py-2 rounded border ${
              tgReportMsg.type === 'ok'
                ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
            }`}
          >
            {tgReportMsg.text}
          </div>
        )}

        <div className="overflow-x-auto">
          {bottomTab === 'OPEN' && (
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-slate-800/90 text-slate-400 bg-slate-950/60">
                  <th className="py-2.5 px-4 font-medium">نماد</th>
                  <th className="py-2.5 px-4 font-medium">جهت / نوع</th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    قیمت
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    مقدار
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    ارزش کل
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {openOrders.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      سفارش بازی وجود ندارد.
                    </td>
                  </tr>
                ) : (
                  openOrders.map((ord) => (
                    <tr key={ord.orderId} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-4 font-mono-num font-medium text-slate-100">
                        {ord.symbol}
                      </td>
                      <td className="py-2.5 px-4">
                        <span
                          className={
                            ord.side === 'BUY' ? 'text-emerald-400 font-medium' : 'text-rose-400 font-medium'
                          }
                        >
                          {ord.side === 'BUY' ? 'خرید' : 'فروش'} · {ord.type}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num" dir="ltr">
                        {formatQuotePrice(ord.price, ord.quoteCurrency)}
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num" dir="ltr">
                        {formatQty(ord.quantity)}
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num" dir="ltr">
                        {formatQuoteAmount(ord.totalQuoteAmount, ord.quoteCurrency)}
                      </td>
                      <td className="py-2.5 px-4 text-left">
                        <button
                          type="button"
                          onClick={() => void onCancelOrder(ord.orderId)}
                          className="btn-glass btn-glass-sell inline-flex items-center gap-1 px-2.5 py-1 rounded-lg"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>لغو</span>
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}

          {bottomTab === 'HISTORY' && (
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-slate-800/90 text-slate-400 bg-slate-950/60">
                  <th className="py-2.5 px-4 font-medium">نماد</th>
                  <th className="py-2.5 px-4 font-medium">جهت / منبع</th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    قیمت
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    مقدار
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    مجموع
                  </th>
                  <th className="py-2.5 px-4 font-medium">وضعیت</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {orderHistory.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-8 text-center text-slate-500">
                      هنوز معامله‌ای ثبت نشده است.
                    </td>
                  </tr>
                ) : (
                  orderHistory.map((ord) => (
                    <tr key={ord.orderId} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-4 font-mono-num text-slate-100">{ord.symbol}</td>
                      <td className="py-2.5 px-4">
                        <span className={ord.side === 'BUY' ? 'text-emerald-400' : 'text-rose-400'}>
                          {ord.side === 'BUY' ? 'خرید' : 'فروش'}
                        </span>
                        <span className="text-slate-500">
                          {' '}
                          · {ord.source === 'BOT' ? 'ربات خودکار' : 'دستی'}
                        </span>
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num" dir="ltr">
                        {formatQuotePrice(ord.price, ord.quoteCurrency)}
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num" dir="ltr">
                        {formatQty(ord.quantity)}
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num" dir="ltr">
                        {formatQuoteAmount(ord.totalQuoteAmount, ord.quoteCurrency)}
                      </td>
                      <td className="py-2.5 px-4 text-slate-300">
                        {ord.status === 'FILLED' ? 'تکمیل شده' : 'لغو شده'}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}

          {bottomTab === 'BALANCES' && (
            <table className="w-full text-right text-xs">
              <thead>
                <tr className="border-b border-slate-800/90 text-slate-400 bg-slate-950/60">
                  <th className="py-2.5 px-4 font-medium">دارایی</th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    موجودی آزاد
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    در سفارش
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    ارزش تومانی
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    ارزش دلاری (USDT)
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {balances.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="py-8 text-center text-slate-500">
                      موجودی‌ای یافت نشد.
                    </td>
                  </tr>
                ) : (
                  balances.map((b) => (
                    <tr key={b.asset} className="hover:bg-slate-800/30">
                      <td className="py-2.5 px-4 font-semibold text-white">
                        <span className="font-mono-num">{b.asset}</span>
                        {b.persianName && (
                          <span className="text-slate-400 text-[11px] mr-1.5">
                            ({b.persianName})
                          </span>
                        )}
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num text-slate-200" dir="ltr">
                        {formatQty(b.free)}
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num text-slate-400" dir="ltr">
                        {formatQty(b.locked)}
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num text-amber-300" dir="ltr">
                        {formatToman(b.tomanValue)} ت
                      </td>
                      <td className="py-2.5 px-4 text-left font-mono-num text-emerald-400" dir="ltr">
                        ${b.usdtValue.toFixed(2)}
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          )}

          {bottomTab === 'ALERTS' && (
            <PriceAlertsWidget
              alerts={alerts}
              markets={markets}
              defaultBaseAsset={baseAsset}
              defaultQuoteCurrency={quoteCurrency}
              compact
              telegramConnected={telegramConnected}
              onOpenTelegramSettings={onOpenTelegramSettings}
              onQuoteCurrencyChange={(qc) => onSelectPair(baseAsset, qc)}
              onCreateAlert={onCreateAlert}
              onRearmAlert={onRearmAlert}
              onDeleteAlert={onDeleteAlert}
              onSelectForTrade={(asset, qc) => {
                if (qc) onSelectPair(asset, qc);
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
};
