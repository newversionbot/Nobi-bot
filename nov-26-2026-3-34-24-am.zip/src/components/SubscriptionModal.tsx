import React, { useEffect, useState } from 'react';
import {
  Check,
  CheckCircle2,
  Clock,
  Copy,
  CreditCard,
  Gift,
  ShieldCheck,
  Sparkles,
  Wallet,
  X,
  XCircle,
} from 'lucide-react';
import type {
  BillingPublicConfig,
  PaymentRequestRecord,
  UserEntitlement,
  UserReferralSummary,
} from '../types/trading';
import { formatDateTimeShort, formatPrice, formatToman } from '../utils/format';
import { ReferralProgramCard } from './ReferralProgramCard';

interface SubscriptionModalProps {
  open: boolean;
  initialTab?: 'ZARINPAL' | 'USDT' | 'REFERRAL';
  onClose: () => void;
  config: BillingPublicConfig;
  entitlement: UserEntitlement;
  myRequests: PaymentRequestRecord[];
  referral: UserReferralSummary | null;
  isAuthenticated: boolean;
  onSignIn: () => Promise<void>;
  onRequestZarinpal: () => Promise<{
    mode: 'GATEWAY_REDIRECT' | 'READY_NOT_CONFIGURED';
    paymentUrl?: string;
    message: string;
    request: PaymentRequestRecord;
  }>;
  onSubmitCryptoPayment: (payload: {
    txHash: string;
    network: string;
    walletAddress: string;
    note?: string;
  }) => Promise<PaymentRequestRecord>;
  onClaimReferralCode: (code: string) => Promise<{
    claimed: boolean;
    alreadyLinked: boolean;
    message: string;
  }>;
}

export const SubscriptionModal: React.FC<SubscriptionModalProps> = ({
  open,
  initialTab = 'ZARINPAL',
  onClose,
  config,
  entitlement,
  myRequests,
  referral,
  isAuthenticated,
  onSignIn,
  onRequestZarinpal,
  onSubmitCryptoPayment,
  onClaimReferralCode,
}) => {
  const [tab, setTab] = useState<'ZARINPAL' | 'USDT' | 'REFERRAL'>(initialTab);
  const [selectedWalletIdx, setSelectedWalletIdx] = useState<0 | 1>(0);
  const [copiedAddr, setCopiedAddr] = useState(false);
  const [txHash, setTxHash] = useState('');
  const [note, setNote] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'info' | 'err'; text: string } | null>(
    null
  );

  useEffect(() => {
    if (open) {
      setTab(initialTab);
      setFeedback(null);
    }
  }, [open, initialTab]);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  const wallets = [
    {
      network: config.usdtNetwork || 'TRC20',
      address: config.usdtWalletAddress || '',
    },
    ...(config.usdtWalletAddress2
      ? [
          {
            network: config.usdtNetwork2 || 'BEP20',
            address: config.usdtWalletAddress2,
          },
        ]
      : []),
  ];
  const activeWallet = wallets[selectedWalletIdx] || wallets[0];

  const handleCopyWallet = async (addr: string) => {
    if (!addr) return;
    try {
      await navigator.clipboard.writeText(addr);
      setCopiedAddr(true);
      setTimeout(() => setCopiedAddr(false), 1800);
    } catch {
      // Ignore clipboard errors
    }
  };

  const handleZarinpalPay = async () => {
    setFeedback(null);
    setSubmitting(true);
    try {
      const res = await onRequestZarinpal();
      if (res.mode === 'GATEWAY_REDIRECT' && res.paymentUrl) {
        setFeedback({ type: 'ok', text: res.message });
        window.location.href = res.paymentUrl;
      } else {
        setFeedback({ type: 'info', text: res.message });
      }
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در اتصال به درگاه زرین‌پال',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const handleCryptoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    if (!activeWallet.address) {
      setFeedback({
        type: 'err',
        text: 'هنوز آدرس کیف پول دلاری توسط مدیر سایت ثبت نشده است.',
      });
      return;
    }
    setSubmitting(true);
    try {
      await onSubmitCryptoPayment({
        txHash,
        network: activeWallet.network,
        walletAddress: activeWallet.address,
        note: note.trim() || undefined,
      });
      setTxHash('');
      setNote('');
      setFeedback({
        type: 'ok',
        text: 'فیش پرداخت دلاری (USDT) با موفقیت ثبت شد. پس از بررسی توسط مدیر، اشتراک ۳۰ روزه شما بلافاصله فعال می‌شود.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ثبت پرداخت دلاری',
      });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="subscription-modal-title"
    >
      <div
        className="w-full max-w-3xl bg-[#0A101D] border border-slate-800 rounded-xl overflow-hidden shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 bg-[#060A14] flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <h2 id="subscription-modal-title" className="text-sm sm:text-base font-semibold text-white">
                خرید اشتراک حرفه‌ای AI NobiBot (ماهانه {formatToman(config.monthlyPriceToman)} تومان)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                دسترسی کامل به ترمینال معاملات نوبیتکس، تحلیل هوش مصنوعی، ربات خودکار و هشدارهای تلگرام
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="بستن"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 space-y-4 max-h-[82vh] overflow-y-auto">
          {/* Current Status Banner */}
          {entitlement.hasProAccess ? (
            <div className="bg-emerald-500/10 border border-emerald-500/35 rounded-lg p-3.5 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 text-emerald-300 font-medium">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>
                  {entitlement.isAdmin
                    ? 'حساب مدیر سیستم: دسترسی کامل به تمام امکانات تخصصی و پنل مدیریت فعال است.'
                    : `اشتراک حرفه‌ای شما فعال است (${entitlement.daysRemaining} روز باقی‌مانده تا تمدید).`}
                </span>
              </div>
              {entitlement.expiresAt && !entitlement.isAdmin && (
                <span className="font-mono-num text-emerald-200" dir="ltr">
                  انقضا: {formatDateTimeShort(entitlement.expiresAt)}
                </span>
              )}
            </div>
          ) : null}

          {/* Free vs Pro Comparison */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 space-y-2">
              <div className="font-semibold text-slate-200 flex items-center justify-between">
                <span>پلن رایگان (عمومی)</span>
                <span className="font-mono-num text-slate-400">0 تومان</span>
              </div>
              <ul className="space-y-1 text-[11px] text-slate-400">
                <li>• مشاهده قیمت‌های لحظه‌ای تومانی و تتری نوبیتکس</li>
                <li>• ماشین‌حساب حرفه‌ای سود و ضرر (PnL)</li>
                <li>• هشدار قیمت ساده داخل مرورگر و نصب اپ موبایل (PWA)</li>
              </ul>
            </div>

            <div className="bg-slate-950 border border-amber-500/40 rounded-lg p-3.5 space-y-2">
              <div className="font-semibold text-amber-300 flex items-center justify-between">
                <span>اشتراک ماهانه حرفه‌ای (همه امکانات)</span>
                <span className="font-mono-num text-white" dir="ltr">
                  {formatToman(config.monthlyPriceToman)} ت / ${formatPrice(config.monthlyPriceUsdt)}
                </span>
              </div>
              <ul className="space-y-1 text-[11px] text-slate-300">
                <li>• ترمینال معاملات اسپات واقعی و تمرینی نوبیتکس + پرتفوی</li>
                <li>• تحلیلگر هوش مصنوعی (Gemini AI) و اخبار و احساسات بازار</li>
                <li>• ربات معامله‌گر خودکار، بک‌تست، ربات تلگرام و ارسال دوره‌ای</li>
              </ul>
            </div>
          </div>

          {/* Mode Tabs (Always Visible) */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => {
                setTab('ZARINPAL');
                setFeedback(null);
              }}
              className={`py-2 px-3 rounded-md font-medium flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap ${
                tab === 'ZARINPAL'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <CreditCard className="w-4 h-4" />
              <span>پرداخت ریالی (زرین‌پال)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('USDT');
                setFeedback(null);
              }}
              className={`py-2 px-3 rounded-md font-medium flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap ${
                tab === 'USDT'
                  ? 'bg-cyan-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Wallet className="w-4 h-4" />
              <span>پرداخت دلاری (تتر / USDT)</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setTab('REFERRAL');
                setFeedback(null);
              }}
              className={`py-2 px-3 rounded-md font-medium flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap ${
                tab === 'REFERRAL'
                  ? 'bg-emerald-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Gift className="w-4 h-4" />
              <span>دعوت دوستان (+۴ روز هدیه)</span>
            </button>
          </div>

          {tab === 'REFERRAL' ? (
            <ReferralProgramCard
              referral={referral}
              isAuthenticated={isAuthenticated}
              onSignIn={onSignIn}
              onClaimReferralCode={onClaimReferralCode}
              compact
            />
          ) : !isAuthenticated ? (
            <div className="bg-slate-950 border border-cyan-500/35 rounded-lg p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div>
                <div className="font-semibold text-white">ابتدا وارد حساب کاربری شوید</div>
                <div className="text-slate-400 mt-0.5">
                  برای ثبت اشتراک روی ایمیل شما، ابتدا با دکمه گوگل وارد شوید و سپس پرداخت را انجام دهید.
                </div>
              </div>
              <button
                type="button"
                onClick={() => void onSignIn()}
                className="px-4 py-2 rounded-lg font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors whitespace-nowrap shrink-0"
              >
                ورود سریع با گوگل
              </button>
            </div>
          ) : (
            <>
              {tab === 'ZARINPAL' ? (
                <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-4 text-xs">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-sm font-semibold text-white">
                        درگاه پرداخت آنلاین زرین‌پال
                      </div>
                      <div className="text-[11px] text-slate-400 mt-1">
                        مبلغ قابل پرداخت برای ۳۰ روز اشتراک حرفه‌ای:
                      </div>
                    </div>
                    <div className="text-lg font-bold font-mono-num text-amber-300" dir="ltr">
                      {formatToman(config.monthlyPriceToman)} تومان
                    </div>
                  </div>

                  <div
                    className={`rounded-lg p-3 border text-[11px] flex items-start gap-2 ${
                      config.zarinpalEnabled
                        ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                        : 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                    }`}
                  >
                    <ShieldCheck className="w-4 h-4 shrink-0 mt-0.5" />
                    <div>
                      {config.zarinpalEnabled ? (
                        <span>
                          درگاه زرین‌پال متصل و فعال است{' '}
                          {config.zarinpalSandbox ? '(حالت تست Sandbox)' : '(درگاه واقعی شتاب)'}.
                          پس از پرداخت موفق، اشتراک شما به‌صورت خودکار فعال می‌شود.
                        </span>
                      ) : (
                        <span>
                          درگاه زرین‌پال آماده اتصال است. مدیر سایت می‌تواند هر زمان کد پذیرنده (Merchant ID) خود را در پنل مدیریت وارد کند تا پرداخت کارت بانکی شتاب بلافاصله فعال شود.
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={submitting}
                    onClick={() => void handleZarinpalPay()}
                    className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors disabled:opacity-50 whitespace-nowrap"
                  >
                    {submitting
                      ? 'در حال اتصال به زرین‌پال...'
                      : config.zarinpalEnabled
                        ? `پرداخت آنلاین ${formatToman(config.monthlyPriceToman)} تومان با زرین‌پال`
                        : `تست و بررسی اتصال زرین‌پال (${formatToman(config.monthlyPriceToman)} تومان)`}
                  </button>
                </div>
              ) : (
                <form
                  onSubmit={(e) => void handleCryptoSubmit(e)}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-4 text-xs"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="text-sm font-semibold text-white">
                        پرداخت دلاری با تتر (USDT)
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        مبلغ تتر را به یکی از آدرس‌های زیر واریز کنید و هش تراکنش (TXID) را ثبت نمایید
                      </div>
                    </div>
                    <div className="text-lg font-bold font-mono-num text-cyan-300" dir="ltr">
                      ${formatPrice(config.monthlyPriceUsdt)} USDT
                    </div>
                  </div>

                  {wallets.every((w) => !w.address) ? (
                    <div className="bg-amber-500/10 border border-amber-500/30 rounded-lg p-3 text-amber-200 text-[11px]">
                      هنوز آدرس کیف پول دلاری توسط مدیر سایت در «پنل مدیریت» ثبت نشده است.
                    </div>
                  ) : (
                    <>
                      {wallets.length > 1 && (
                        <div className="flex flex-wrap items-center gap-2">
                          {wallets.map((w, idx) => (
                            <button
                              key={`${w.network}-${idx}`}
                              type="button"
                              onClick={() => setSelectedWalletIdx(idx as 0 | 1)}
                              className={`px-3 py-1.5 rounded-md font-mono-num text-xs transition-colors ${
                                selectedWalletIdx === idx
                                  ? 'bg-cyan-500 text-slate-950 font-semibold'
                                  : 'bg-[#0A101D] border border-slate-800 text-slate-300'
                              }`}
                            >
                              شبکه {w.network}
                            </button>
                          ))}
                        </div>
                      )}

                      <div className="bg-[#0A101D] border border-slate-800 rounded-lg p-3 space-y-2">
                        <div className="flex items-center justify-between text-[11px] text-slate-400">
                          <span>آدرس کیف پول مقصد ({activeWallet.network}):</span>
                          <button
                            type="button"
                            onClick={() => void handleCopyWallet(activeWallet.address)}
                            className="inline-flex items-center gap-1 text-cyan-300 hover:text-cyan-200 font-medium"
                          >
                            {copiedAddr ? (
                              <>
                                <Check className="w-3.5 h-3.5 text-emerald-400" />
                                <span className="text-emerald-300">کپی شد</span>
                              </>
                            ) : (
                              <>
                                <Copy className="w-3.5 h-3.5" />
                                <span>کپی آدرس</span>
                              </>
                            )}
                          </button>
                        </div>
                        <div
                          className="font-mono-num text-xs text-white bg-slate-950 border border-slate-800 rounded px-3 py-2 break-all select-all"
                          dir="ltr"
                        >
                          {activeWallet.address || 'ثبت نشده'}
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">
                            هش تراکنش (TXID / Transaction Hash)
                          </label>
                          <input
                            type="text"
                            value={txHash}
                            onChange={(e) => setTxHash(e.target.value)}
                            placeholder="مثلاً 0x8f3a... یا 9c7e..."
                            dir="ltr"
                            className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-3 py-2 text-xs font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] text-slate-400 mb-1">
                            توضیح یا آیدی تلگرام (اختیاری)
                          </label>
                          <input
                            type="text"
                            value={note}
                            onChange={(e) => setNote(e.target.value)}
                            placeholder="مثلاً واریز از کیف پول تراست والت"
                            className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-3 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
                          />
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={submitting}
                        className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors disabled:opacity-50 whitespace-nowrap"
                      >
                        {submitting ? 'در حال ثبت...' : 'ثبت فیش پرداخت دلاری (USDT) و ارسال به مدیر'}
                      </button>
                    </>
                  )}
                </form>
              )}

              {feedback && (
                <div
                  className={`text-xs px-3.5 py-2.5 rounded-lg border ${
                    feedback.type === 'ok'
                      ? 'bg-emerald-500/10 border-emerald-500/35 text-emerald-300'
                      : feedback.type === 'info'
                        ? 'bg-amber-500/10 border-amber-500/35 text-amber-200'
                        : 'bg-rose-500/10 border-rose-500/35 text-rose-300'
                  }`}
                >
                  {feedback.text}
                </div>
              )}

              {/* User Payment History */}
              {myRequests.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-slate-800">
                  <div className="text-xs font-semibold text-slate-300">
                    سابقه درخواست‌های پرداخت شما
                  </div>
                  <div className="divide-y divide-slate-800/70 bg-slate-950 border border-slate-800 rounded-lg">
                    {myRequests.slice(0, 6).map((req) => (
                      <div
                        key={req.id}
                        className="px-3.5 py-2.5 flex flex-wrap items-center justify-between gap-2 text-[11px]"
                      >
                        <div className="space-y-0.5">
                          <div className="flex items-center gap-2 text-white font-medium">
                            <span>{req.method === 'USDT' ? `تتر (${req.network || 'USDT'})` : 'زرین‌پال'}</span>
                            <span className="font-mono-num text-amber-300" dir="ltr">
                              {req.method === 'USDT'
                                ? `$${formatPrice(req.amountUsdt)} USDT`
                                : `${formatToman(req.amountToman)} تومان`}
                            </span>
                          </div>
                          {(req.txHash || req.authority) && (
                            <div className="font-mono-num text-slate-500 break-all" dir="ltr">
                              {req.txHash || req.authority}
                            </div>
                          )}
                          {req.adminNote && (
                            <div className="text-slate-400">{req.adminNote}</div>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-0.5 rounded font-medium ${
                              req.status === 'APPROVED'
                                ? 'bg-emerald-500/15 text-emerald-300'
                                : req.status === 'REJECTED'
                                  ? 'bg-rose-500/15 text-rose-300'
                                  : 'bg-amber-500/15 text-amber-300'
                            }`}
                          >
                            {req.status === 'APPROVED' ? (
                              <CheckCircle2 className="w-3 h-3" />
                            ) : req.status === 'REJECTED' ? (
                              <XCircle className="w-3 h-3" />
                            ) : (
                              <Clock className="w-3 h-3" />
                            )}
                            <span>
                              {req.status === 'APPROVED'
                                ? 'تایید و فعال‌شده'
                                : req.status === 'REJECTED'
                                  ? 'رد شده'
                                  : 'در انتظار تایید'}
                            </span>
                          </span>
                          <span className="font-mono-num text-slate-500" dir="ltr">
                            {formatDateTimeShort(req.createdAt)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};
