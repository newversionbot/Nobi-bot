import React, { useState } from 'react';
import type { User } from 'firebase/auth';
import {
  Camera,
  Check,
  Copy,
  Eye,
  EyeOff,
  ImageUp,
  KeyRound,
  LogIn,
  LogOut,
  Phone,
  QrCode,
  ShieldAlert,
  Trash2,
} from 'lucide-react';
import type {
  ApiConnectionStatus,
  AppApiKeySummary,
  ExchangeLinkSummary,
  ExecutionMode,
  NobitexAuthType,
  UserReferralSummary,
} from '../types/trading';
import { formatDateTimeShort } from '../utils/format';
import {
  parseScannedCredentialsPayload,
  type QrScanTarget,
} from '../utils/apiQrParser';
import { QrBarcodeScannerModal, type ScannerMode } from './QrBarcodeScannerModal';
import { ReferralProgramCard } from './ReferralProgramCard';

interface AuthAndKeysPanelProps {
  user: User | null;
  authLoading: boolean;
  connectionStatus: ApiConnectionStatus | null;
  executionMode: ExecutionMode;
  onChangeExecutionMode: (m: ExecutionMode) => void;
  appKeys: AppApiKeySummary[];
  exchangeLinks: ExchangeLinkSummary[];
  hasEnvFallback: boolean;
  onSignIn: () => Promise<void>;
  onSignOut: () => Promise<void>;
  onGenerateAppKey: (label: string, scopes: string[]) => Promise<{ rawKey: string }>;
  onRevokeAppKey: (keyId: string) => Promise<void>;
  onSaveExchangeKey: (payload: {
    label: string;
    authType?: NobitexAuthType;
    apiToken?: string;
    apiKey?: string;
    secretKey?: string;
    verifyFirst: boolean;
  }) => Promise<{ verified?: boolean } | void>;
  onTestExchangeKey: () => Promise<{
    canTrade: boolean;
    balancesCount: number;
    authType?: NobitexAuthType;
  }>;
  onRevokeExchangeKey: (credId: string) => Promise<void>;
  referral: UserReferralSummary | null;
  onClaimReferralCode: (code: string) => Promise<{
    claimed: boolean;
    alreadyLinked: boolean;
    message: string;
  }>;
}

const SCOPE_OPTIONS = [
  { id: 'market:read', label: 'خواندن داده‌های بازار' },
  { id: 'trade:spot', label: 'ثبت و لغو سفارش اسپات' },
  { id: 'bot:manage', label: 'مدیریت ربات‌های معامله‌گر' },
];

export const AuthAndKeysPanel: React.FC<AuthAndKeysPanelProps> = ({
  user,
  authLoading,
  connectionStatus,
  executionMode,
  onChangeExecutionMode,
  appKeys,
  exchangeLinks,
  hasEnvFallback,
  onSignIn,
  onSignOut,
  onGenerateAppKey,
  onRevokeAppKey,
  onSaveExchangeKey,
  onTestExchangeKey,
  onRevokeExchangeKey,
  referral,
  onClaimReferralCode,
}) => {
  const [appKeyLabel, setAppKeyLabel] = useState('ربات و وب‌هوک ترید');
  const [selectedScopes, setSelectedScopes] = useState<string[]>([
    'market:read',
    'trade:spot',
    'bot:manage',
  ]);
  const [newlyGeneratedSecret, setNewlyGeneratedSecret] = useState<string | null>(null);
  const [copiedSecret, setCopiedSecret] = useState(false);

  // Nobitex Exchange Credentials state (API Key + Secret Key Ed25519 or Legacy Token)
  const [exLabel, setExLabel] = useState('حساب اصلی نوبیتکس');
  const [exAuthType, setExAuthType] = useState<NobitexAuthType>('KEY_PAIR');
  const [exApiKey, setExApiKey] = useState('');
  const [exSecretKey, setExSecretKey] = useState('');
  const [exApiToken, setExApiToken] = useState('');
  const [showExSecret, setShowExSecret] = useState(false);
  const [verifyBeforeSave, setVerifyBeforeSave] = useState(true);

  const [scannerOpen, setScannerOpen] = useState(false);
  const [scannerTarget, setScannerTarget] = useState<QrScanTarget>('AUTO');
  const [scannerInitialMode, setScannerInitialMode] = useState<ScannerMode>('CAMERA');

  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const openScanner = (target: QrScanTarget, initialMode: ScannerMode = 'CAMERA') => {
    setMsg(null);
    setScannerTarget(target);
    setScannerInitialMode(initialMode);
    setScannerOpen(true);
  };

  const handleScannerDetected = (rawText: string) => {
    setScannerOpen(false);
    try {
      const parsed = parseScannedCredentialsPayload(rawText, scannerTarget, {
        apiKey: exApiKey,
        secretKey: exSecretKey,
      });

      if (parsed.apiKey) {
        setExApiKey(parsed.apiKey);
      }
      if (parsed.secretKey) {
        setExSecretKey(parsed.secretKey);
      }
      if (parsed.apiToken) {
        setExApiToken(parsed.apiToken);
      }

      if (parsed.apiKey || parsed.secretKey) {
        setExAuthType('KEY_PAIR');
      } else if (parsed.apiToken) {
        setExAuthType('TOKEN');
      }

      setMsg({ type: 'ok', text: parsed.summary });
    } catch (err) {
      setMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'خواندن اطلاعات بارکد/QR ناموفق بود.',
      });
    }
  };

  const toggleScope = (scopeId: string) => {
    setSelectedScopes((prev) =>
      prev.includes(scopeId) ? prev.filter((s) => s !== scopeId) : [...prev, scopeId]
    );
  };

  const handleGenerateKey = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    if (selectedScopes.length === 0) {
      setMsg({ type: 'err', text: 'حداقل یک سطح دسترسی انتخاب کنید.' });
      return;
    }
    setBusy(true);
    try {
      const res = await onGenerateAppKey(appKeyLabel, selectedScopes);
      setNewlyGeneratedSecret(res.rawKey);
      setCopiedSecret(false);
      setMsg({
        type: 'ok',
        text: 'کلید API جدید تولید شد. این کلید فقط همین یک‌بار نمایش داده می‌شود.',
      });
    } catch (err) {
      setMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در تولید کلید API',
      });
    } finally {
      setBusy(false);
    }
  };

  const handleLinkExchange = async (e: React.FormEvent) => {
    e.preventDefault();
    setMsg(null);
    setBusy(true);
    try {
      const result = await onSaveExchangeKey(
        exAuthType === 'KEY_PAIR'
          ? {
              label: exLabel,
              authType: 'KEY_PAIR',
              apiKey: exApiKey.trim(),
              secretKey: exSecretKey.trim(),
              verifyFirst: verifyBeforeSave,
            }
          : {
              label: exLabel,
              authType: 'TOKEN',
              apiToken: exApiToken.trim(),
              verifyFirst: verifyBeforeSave,
            }
      );
      setExApiKey('');
      setExSecretKey('');
      setExApiToken('');
      const isVerified = result && typeof result === 'object' ? result.verified !== false : verifyBeforeSave;
      setMsg({
        type: 'ok',
        text: isVerified
          ? 'اتصال واقعی به حساب نوبیتکس تایید و با رمزنگاری AES-256-GCM در سرور ذخیره شد.'
          : 'کلیدهای نوبیتکس با رمزنگاری AES-256-GCM در سرور ذخیره شدند (بدون تست لحظه‌ای).',
      });
    } catch (err) {
      setMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ذخیره کلیدهای نوبیتکس',
      });
    } finally {
      setBusy(false);
    }
  };

  const handleTestExchange = async () => {
    setMsg(null);
    setBusy(true);
    try {
      const info = await onTestExchangeKey();
      const methodLabel = info.authType === 'KEY_PAIR' ? 'API Key + Secret Key' : 'توکن قدیمی';
      setMsg({
        type: 'ok',
        text: `اتصال واقعی به حساب نوبیتکس (${methodLabel}) تایید شد · تعداد کیف‌پول‌های دارای موجودی: ${info.balancesCount}`,
      });
    } catch (err) {
      setMsg({
        type: 'err',
        text: err instanceof Error ? err.message : 'تست اتصال به نوبیتکس ناموفق بود.',
      });
    } finally {
      setBusy(false);
    }
  };

  const handleCopy = () => {
    if (!newlyGeneratedSecret) return;
    void navigator.clipboard.writeText(newlyGeneratedSecret);
    setCopiedSecret(true);
  };

  const handleSignInClick = async () => {
    setMsg(null);
    setBusy(true);
    try {
      await onSignIn();
    } catch (err) {
      setMsg({
        type: 'err',
        text:
          err instanceof Error
            ? err.message
            : 'ورود با حساب گوگل انجام نشد. لطفاً پنجره پاپ‌آپ را بررسی کنید.',
      });
    } finally {
      setBusy(false);
    }
  };

  const hasActiveExchangeLink =
    exchangeLinks.some((c) => c.status === 'ACTIVE') || hasEnvFallback;

  return (
    <div className="space-y-6">
      {/* User Authentication & Mode Card */}
      <div className="glass-panel rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <img
            src={
              user?.photoURL ||
              '/assets/aistudio/file_000000001f9c81f5bfb6600a368b4cc4_b124af47.png'
            }
            alt={user?.displayName || 'لوگوی AI NobiBot'}
            referrerPolicy="no-referrer"
            className="w-12 h-12 rounded-xl border border-cyan-500/50 object-cover object-top shrink-0"
          />

          <div>
            {user ? (
              <>
                <div className="text-sm font-semibold text-white">
                  {user.displayName || 'معامله‌گر احرازشده'} · AI NobiBot
                </div>
                <div className="text-xs text-slate-400 font-mono-num" dir="ltr">
                  {user.email} · UID: {user.uid.slice(0, 10)}...
                </div>
              </>
            ) : (
              <>
                <div className="text-sm font-semibold text-white">
                  AI NobiBot (ainobibot.ir) — ورود امن و مدیریت کلیدهای نوبیتکس
                </div>
                <div className="text-xs text-slate-400">
                  برای اتصال توکن API نوبیتکس (بازار تومانی و تتری)، ساخت ربات و مدیریت امن کلیدها وارد شوید.
                </div>
              </>
            )}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 bg-slate-950/75 p-1 rounded-xl border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => onChangeExecutionMode('paper')}
              className={`btn-glass px-3 py-1.5 rounded-lg whitespace-nowrap shrink-0 ${
                executionMode === 'paper'
                  ? 'btn-glass-amber font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              حالت تمرینی (Paper)
            </button>
            <button
              type="button"
              disabled={!hasActiveExchangeLink}
              onClick={() => onChangeExecutionMode('live')}
              className={`btn-glass px-3 py-1.5 rounded-lg whitespace-nowrap shrink-0 ${
                executionMode === 'live'
                  ? 'btn-glass-primary font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              حساب واقعی نوبیتکس (Live)
            </button>
          </div>

          {user ? (
            <button
              type="button"
              onClick={() => void onSignOut()}
              className="btn-glass btn-glass-neutral inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0"
            >
              <LogOut className="w-4 h-4" />
              <span>خروج</span>
            </button>
          ) : (
            <button
              type="button"
              disabled={authLoading || busy}
              onClick={() => void handleSignInClick()}
              className="btn-glass btn-glass-primary inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0"
            >
              <LogIn className="w-4 h-4" />
              <span>{authLoading || busy ? 'در حال اتصال...' : 'ورود با حساب گوگل'}</span>
            </button>
          )}
        </div>
      </div>

      {connectionStatus && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div className="glass-panel rounded-xl p-4">
            <div className="text-slate-400 mb-1">ارتباط با سرور نوبیتکس</div>
            <div
              className={`font-semibold ${
                connectionStatus.publicFeedReachable ? 'text-emerald-400' : 'text-rose-400'
              }`}
            >
              {connectionStatus.publicFeedReachable ? 'متصل و زنده' : 'عدم دسترسی'}
            </div>
            <div className="text-slate-500 font-mono-num mt-1" dir="ltr">
              {connectionStatus.baseUrl}
            </div>
          </div>

          <div className="glass-panel rounded-xl p-4">
            <div className="text-slate-400 mb-1">توکن شخصی نوبیتکس</div>
            <div
              className={`font-semibold ${
                hasActiveExchangeLink ? 'text-emerald-400' : 'text-amber-300'
              }`}
            >
              {hasActiveExchangeLink ? 'ثبت و رمزنگاری شده' : 'هنوز متصل نشده'}
            </div>
            <div className="text-slate-500 mt-1">ذخیره با رمزنگاری AES-256-GCM در سرور</div>
          </div>

          <div className="glass-panel rounded-xl p-4">
            <div className="text-slate-400 mb-1">کلیدهای دسترسی اپلیکیشن</div>
            <div className="font-semibold text-white font-mono-num">
              {appKeys.filter((k) => k.status === 'ACTIVE').length} کلید فعال
            </div>
            <div className="text-slate-500 mt-1">نگهداری امن به‌صورت هش SHA-256</div>
          </div>
        </div>
      )}

      {msg && (
        <div
          className={`text-xs px-4 py-3 rounded-lg border ${
            msg.type === 'ok'
              ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
          }`}
        >
          {msg.text}
        </div>
      )}

      <ReferralProgramCard
        referral={referral}
        isAuthenticated={Boolean(user)}
        onSignIn={onSignIn}
        onClaimReferralCode={onClaimReferralCode}
      />

      {!user ? (
        <div className="glass-panel rounded-xl p-8 sm:p-10 flex flex-col md:flex-row items-center justify-center gap-8 text-center md:text-right">
          <img
            src="/icon.svg"
            alt="لوگوی AI NobiBot — ainobibot.ir"
            className="w-32 h-32 rounded-2xl border border-cyan-500/45 bg-slate-950/70 p-2 shrink-0 shadow-[0_0_28px_rgba(6,182,212,0.22)]"
          />
          <div className="space-y-4 max-w-lg">
            <div className="space-y-1.5">
              <h3 className="text-base font-semibold text-white">
                اتصال امن حساب نوبیتکس — AI NobiBot (ainobibot.ir)
              </h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                توکن API نوبیتکس شما با رمزنگاری AES-256-GCM در سرور نگهداری می‌شود و هیچ‌وقت در
                مرورگر ذخیره نمی‌گردد. پس از ورود می‌توانید در بازارهای تومانی و تتری به‌صورت خودکار معامله کنید.
              </p>
            </div>
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
              <button
                type="button"
                disabled={authLoading || busy}
                onClick={() => void handleSignInClick()}
                className="btn-glass btn-glass-primary inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold"
              >
                <LogIn className="w-4 h-4" />
                <span>ورود با گوگل و ثبت توکن نوبیتکس</span>
              </button>
              <a
                href="tel:09999961279"
                className="btn-glass btn-glass-neutral inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-medium whitespace-nowrap shrink-0"
              >
                <Phone className="w-3.5 h-3.5 text-cyan-400" />
                <span>پشتیبانی مستقیم:</span>
                <span className="font-mono-num text-cyan-300" dir="ltr">
                  09999961279
                </span>
              </a>
            </div>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
          {/* Left: Nobitex Exchange Credentials Vault */}
          <div className="glass-panel rounded-xl p-5 space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <KeyRound className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-white">
                  اتصال حساب صرافی نوبیتکس (API Key & Secret Key)
                </h3>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                پشتیبانی از سیستم جدید کلید جفتی نوبیتکس (API Key + Secret Key با امضای Ed25519) و توکن قدیمی.
              </p>
            </div>

            {/* Auth Method Toggle */}
            <div className="grid grid-cols-2 gap-1.5 bg-slate-950/80 p-1 rounded-xl border border-slate-800 text-xs">
              <button
                type="button"
                onClick={() => {
                  setExAuthType('KEY_PAIR');
                  setMsg(null);
                }}
                className={`btn-glass px-3 py-2 rounded-lg font-medium transition-all ${
                  exAuthType === 'KEY_PAIR'
                    ? 'btn-glass-primary font-semibold'
                    : 'btn-glass-neutral text-slate-400'
                }`}
              >
                API Key + Secret Key (جدید)
              </button>
              <button
                type="button"
                onClick={() => {
                  setExAuthType('TOKEN');
                  setMsg(null);
                }}
                className={`btn-glass px-3 py-2 rounded-lg font-medium transition-all ${
                  exAuthType === 'TOKEN'
                    ? 'btn-glass-primary font-semibold'
                    : 'btn-glass-neutral text-slate-400'
                }`}
              >
                توکن قدیمی (Legacy Token)
              </button>
            </div>

            <div className="rounded-lg border border-amber-500/35 bg-amber-500/10 px-3.5 py-2.5 text-[11px] text-amber-200 leading-relaxed">
              <strong>توصیه امنیتی مهم:</strong> هنگام ساخت کلید در پنل نوبیتکس، فقط دسترسی‌های{' '}
              <strong>خواندن (Read)</strong> و <strong>معامله (Trade)</strong> را فعال کنید و{' '}
              <strong>هرگز دسترسی برداشت (Withdraw)</strong> ندهید.
            </div>

            <form onSubmit={handleLinkExchange} className="space-y-3 text-xs">
              {/* Quick Smart QR / Barcode Scanner Toolbar */}
              <div className="rounded-xl border border-cyan-500/25 bg-cyan-500/5 p-3 flex flex-wrap items-center justify-between gap-2.5">
                <div className="flex items-center gap-2 text-cyan-200">
                  <QrCode className="w-4 h-4 text-cyan-400 shrink-0" />
                  <span className="text-[11px] font-medium">
                    ورود سریع کلیدها با اسکن بارکد یا QR کد:
                  </span>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() =>
                      openScanner(exAuthType === 'TOKEN' ? 'TOKEN' : 'AUTO', 'CAMERA')
                    }
                    className="btn-glass btn-glass-primary inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-semibold whitespace-nowrap"
                  >
                    <Camera className="w-3.5 h-3.5" />
                    <span>اسکن با دوربین</span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      openScanner(exAuthType === 'TOKEN' ? 'TOKEN' : 'AUTO', 'GALLERY')
                    }
                    className="btn-glass btn-glass-neutral inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px] font-medium text-cyan-200 whitespace-nowrap"
                  >
                    <ImageUp className="w-3.5 h-3.5 text-cyan-400" />
                    <span>انتخاب از گالری</span>
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1">نام دلخواه اتصال</label>
                <input
                  type="text"
                  value={exLabel}
                  onChange={(e) => setExLabel(e.target.value)}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              {exAuthType === 'KEY_PAIR' ? (
                <>
                  <div>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                      <label className="text-slate-400">
                        کلید API نوبیتکس (API Key / Nobitex-Key)
                      </label>
                      <button
                        type="button"
                        onClick={() => openScanner('API_KEY', 'CAMERA')}
                        className="inline-flex items-center gap-1 text-[11px] text-cyan-300 hover:text-cyan-200 transition-colors"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>اسکن بارکد API Key</span>
                      </button>
                    </div>
                    <input
                      type="text"
                      value={exApiKey}
                      onChange={(e) => setExApiKey(e.target.value)}
                      placeholder="API Key دریافت‌شده از پنل نوبیتکس را جای‌گذاری یا اسکن کنید..."
                      required
                      dir="ltr"
                      autoComplete="off"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 font-mono-num text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                      <label className="text-slate-400">
                        کلید مخفی نوبیتکس (Secret Key · Ed25519 Private Key)
                      </label>
                      <button
                        type="button"
                        onClick={() => openScanner('SECRET_KEY', 'CAMERA')}
                        className="inline-flex items-center gap-1 text-[11px] text-cyan-300 hover:text-cyan-200 transition-colors"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>اسکن بارکد Secret Key</span>
                      </button>
                    </div>
                    <div className="relative">
                      <input
                        type={showExSecret ? 'text' : 'password'}
                        value={exSecretKey}
                        onChange={(e) => setExSecretKey(e.target.value)}
                        placeholder="Secret Key (فرمت Base64 / Hex / PEM) را اینجا وارد یا اسکن کنید..."
                        required
                        dir="ltr"
                        autoComplete="new-password"
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-10 pr-3 py-2 font-mono-num text-white focus:outline-none focus:border-cyan-400"
                      />
                      <button
                        type="button"
                        onClick={() => setShowExSecret((s) => !s)}
                        aria-label={showExSecret ? 'مخفی کردن Secret Key' : 'نمایش Secret Key'}
                        className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-cyan-300"
                      >
                        {showExSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>
                </>
              ) : (
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-2 mb-1">
                    <label className="text-slate-400">
                      توکن شخصی قدیمی نوبیتکس (Authorization Token)
                    </label>
                    <button
                      type="button"
                      onClick={() => openScanner('TOKEN', 'CAMERA')}
                      className="inline-flex items-center gap-1 text-[11px] text-cyan-300 hover:text-cyan-200 transition-colors"
                    >
                      <QrCode className="w-3.5 h-3.5" />
                      <span>اسکن بارکد توکن</span>
                    </button>
                  </div>
                  <div className="relative">
                    <input
                      type={showExSecret ? 'text' : 'password'}
                      value={exApiToken}
                      onChange={(e) => setExApiToken(e.target.value)}
                      placeholder="توکن API قدیمی دریافت‌شده از نوبیتکس را جای‌گذاری یا اسکن کنید..."
                      required
                      dir="ltr"
                      autoComplete="new-password"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg pl-10 pr-3 py-2 font-mono-num text-white focus:outline-none focus:border-cyan-400"
                    />
                    <button
                      type="button"
                      onClick={() => setShowExSecret((s) => !s)}
                      aria-label={showExSecret ? 'مخفی کردن توکن' : 'نمایش توکن'}
                      className="absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-cyan-300"
                    >
                      {showExSecret ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
              )}

              <label className="flex items-center gap-2 text-slate-300 cursor-pointer pt-1">
                <input
                  type="checkbox"
                  checked={verifyBeforeSave}
                  onChange={(e) => setVerifyBeforeSave(e.target.checked)}
                  className="accent-cyan-500"
                />
                <span>تست اعتبار اتصال در نوبیتکس (`/users/wallets/list`) پیش از ذخیره</span>
              </label>

              <div className="flex flex-wrap gap-2 pt-2">
                <button
                  type="submit"
                  disabled={busy}
                  className="btn-glass btn-glass-primary px-4 py-2 rounded-lg font-semibold"
                >
                  {busy ? 'در حال بررسی و رمزنگاری...' : 'ذخیره رمزنگاری‌شده و اتصال به نوبیتکس'}
                </button>
                {hasActiveExchangeLink && (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => void handleTestExchange()}
                    className="btn-glass btn-glass-sync px-4 py-2 rounded-lg font-medium"
                  >
                    تست اتصال واقعی
                  </button>
                )}
              </div>
            </form>

            {/* Troubleshooting Help Box */}
            <div className="rounded-lg border border-slate-800 bg-slate-950/75 p-3 text-[11px] text-slate-300 space-y-1.5 leading-relaxed">
              <div className="flex items-center gap-1.5 font-semibold text-cyan-300">
                <ShieldAlert className="w-3.5 h-3.5 shrink-0" />
                <span>راهنمای رفع خطای اتصال نوبیتکس:</span>
              </div>
              <ul className="list-disc pr-4 space-y-1 text-slate-400">
                <li>
                  اگر از پنل جدید نوبیتکس هر دو مقدار <strong className="text-slate-200">API Key</strong> و{' '}
                  <strong className="text-slate-200">Secret Key</strong> را گرفته‌اید، حتماً تب{' '}
                  <strong className="text-cyan-300">API Key + Secret Key</strong> را انتخاب کنید.
                </li>
                <li>
                  مطمئن شوید کلید خصوصی (Secret Key) دقیقاً متعلق به همین API Key بوده و بدون فاصله یا کاراکتر اضافه کپی شده باشد (کلید عمومی پذیرفته نمی‌شود).
                </li>
                <li>
                  در صورت محدودیت IP یا اجرای برنامه روی سرور خارج از ایران (خطای 403)، تیک «تست اعتبار پیش از ذخیره» را بردارید تا کلیدها امن ذخیره شوند و پس از انتقال به VPS ایران تست کنید.
                </li>
              </ul>
            </div>

            <div className="border-t border-slate-800 pt-4 space-y-2">
              <div className="text-xs font-medium text-slate-300">تاریخچه اتصالات نوبیتکس</div>
              {exchangeLinks.length === 0 ? (
                <div className="text-xs text-slate-500 py-3">
                  هنوز کلید یا توکن نوبیتکس برای این حساب ثبت نشده است.
                </div>
              ) : (
                <div className="divide-y divide-slate-800/70 border border-slate-800 rounded-lg overflow-hidden">
                  {exchangeLinks.map((link) => {
                    const isKeyPair =
                      link.authType === 'KEY_PAIR' || link.maskedApiKey.startsWith('key_');
                    return (
                      <div
                        key={link.id}
                        className="px-3 py-2.5 bg-slate-950 flex items-center justify-between gap-3 text-xs"
                      >
                        <div>
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-medium text-white">{link.label}</span>
                            <span className="px-1.5 py-0.5 rounded bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-[10px]">
                              {isKeyPair ? 'API Key + Secret' : 'Token'}
                            </span>
                            <span
                              className={
                                link.status === 'ACTIVE' ? 'text-emerald-400' : 'text-rose-400'
                              }
                            >
                              · {link.status === 'ACTIVE' ? 'فعال' : 'لغوشده'}
                            </span>
                          </div>
                          <div className="font-mono-num text-slate-400 text-[11px] mt-0.5" dir="ltr">
                            {link.maskedApiKey} · {formatDateTimeShort(link.createdAt)}
                          </div>
                        </div>

                        {link.status === 'ACTIVE' && (
                          <button
                            type="button"
                            onClick={() => void onRevokeExchangeKey(link.id)}
                            className="btn-glass btn-glass-sell inline-flex items-center gap-1 px-2.5 py-1 rounded-lg"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>لغو اتصال</span>
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Right: Application API Keys */}
          <div className="glass-panel rounded-xl p-5 space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <h3 className="text-sm font-semibold text-white">
                تولید و لغو کلیدهای API اپلیکیشن
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                برای اتصال وب‌هوک یا ربات‌های خارجی به حساب شما در این برنامه (`X-APP-APIKEY`).
              </p>
            </div>

            <form onSubmit={handleGenerateKey} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1">نام کلید</label>
                <input
                  type="text"
                  value={appKeyLabel}
                  onChange={(e) => setAppKeyLabel(e.target.value)}
                  required
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1.5">سطوح دسترسی</label>
                <div className="flex flex-wrap gap-2">
                  {SCOPE_OPTIONS.map((sc) => {
                    const checked = selectedScopes.includes(sc.id);
                    return (
                      <button
                        key={sc.id}
                        type="button"
                        onClick={() => toggleScope(sc.id)}
                        className={`btn-glass px-2.5 py-1.5 rounded-lg text-xs ${
                          checked
                            ? 'btn-glass-primary'
                            : 'btn-glass-neutral text-slate-400'
                        }`}
                      >
                        {sc.label}
                      </button>
                    );
                  })}
                </div>
              </div>

              <button
                type="submit"
                disabled={busy}
                className="btn-glass btn-glass-primary px-4 py-2 rounded-lg font-semibold"
              >
                تولید کلید API جدید
              </button>
            </form>

            {newlyGeneratedSecret && (
              <div className="bg-emerald-500/10 border border-emerald-500/40 rounded-lg p-3.5 space-y-2 text-xs">
                <div className="font-semibold text-emerald-300">
                  کلید جدید آماده است — لطفاً همین الان کپی کنید (دیگر نمایش داده نمی‌شود):
                </div>
                <div className="flex items-center justify-between gap-2 bg-slate-950 border border-slate-800 rounded px-3 py-2">
                  <code className="font-mono-num text-emerald-200 truncate" dir="ltr">
                    {newlyGeneratedSecret}
                  </code>
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="btn-glass btn-glass-neutral inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-white shrink-0"
                  >
                    {copiedSecret ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                        <span>کپی شد</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>کپی</span>
                      </>
                    )}
                  </button>
                </div>
              </div>
            )}

            <div className="border-t border-slate-800 pt-4 space-y-2">
              <div className="text-xs font-medium text-slate-300">
                فهرست کلیدهای تولیدشده ({appKeys.length})
              </div>
              {appKeys.length === 0 ? (
                <div className="text-xs text-slate-500 py-3">
                  هنوز کلید دسترسی‌ای تولید نکرده‌اید.
                </div>
              ) : (
                <div className="divide-y divide-slate-800/70 border border-slate-800 rounded-lg overflow-hidden">
                  {appKeys.map((k) => (
                    <div
                      key={k.id}
                      className="px-3 py-2.5 bg-slate-950 flex flex-wrap items-center justify-between gap-3 text-xs"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-white">{k.label}</span>
                          <span
                            className={
                              k.status === 'ACTIVE' ? 'text-emerald-400' : 'text-rose-400'
                            }
                          >
                            · {k.status === 'ACTIVE' ? 'فعال' : 'لغوشده'}
                          </span>
                        </div>
                        <div className="font-mono-num text-slate-400 text-[11px]" dir="ltr">
                          {k.keyPrefix} · {k.scopes.join(', ')}
                        </div>
                      </div>

                      {k.status === 'ACTIVE' && (
                        <button
                          type="button"
                          onClick={() => void onRevokeAppKey(k.id)}
                          className="btn-glass btn-glass-sell inline-flex items-center gap-1 px-2.5 py-1 rounded-lg"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>لغو کلید</span>
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <QrBarcodeScannerModal
        isOpen={scannerOpen}
        initialMode={scannerInitialMode}
        target={scannerTarget}
        onClose={() => setScannerOpen(false)}
        onDetected={handleScannerDetected}
      />
    </div>
  );
};
