import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  Clock,
  Coins,
  Edit3,
  Hand,
  History,
  Layers,
  Pause,
  Play,
  Plus,
  RefreshCw,
  ShieldAlert,
  SlidersHorizontal,
  Square,
  Trash2,
  TrendingUp,
  X,
} from 'lucide-react';
import type {
  BotExecutionConfirmationMode,
  BotFundingMode,
  ExecutionMode,
  OrderBookSnapshot,
  PendingBotConfirmation,
  ProfitBotConfig,
  ProfitBotCycleRecord,
  ProfitBotDecisionLog,
  ProfitBotLimitUnfilledPolicy,
  ProfitBotMarketPreview,
  ProfitBotOrderType,
  ProfitBotReentryPolicy,
  ProfitBotSequenceMode,
  ProfitBotStatus,
  ProfitBotStopLossAction,
  QuoteCurrency,
  SpotBalance,
  UnifiedMarketTicker,
} from '../types/trading';
import type { GuideBotTopic } from './BotEducationModal';
import { CoinSearchSelect } from './CoinSearchSelect';
import {
  formatDateTimeShort,
  formatPrice,
  formatQty,
  formatQuoteAmount,
  formatQuotePrice,
  formatRawDecimalPrice,
  formatToman,
} from '../utils/format';
import {
  buildProfitBotMarketPreview,
  computeExistingBalanceAllocation,
  computeProfitBotTargetProgress,
  computeProfitProgressPercent,
  computeRequiredSellPrice,
  DEFAULT_NOBITEX_FEE_RATE,
  getMinimumOrderNotional,
  getProfitBotStatusMeta,
} from '../utils/profitBotMath';
import { NumericInput } from './NumericInput';

export interface ProfitBotModuleProps {
  defaultBaseAsset: string;
  defaultQuoteCurrency: QuoteCurrency;
  onQuoteCurrencyChange?: (qc: QuoteCurrency) => void;
  markets: UnifiedMarketTicker[];
  balances?: SpotBalance[];
  usdtTomanRate: number;
  profitBots: ProfitBotConfig[];
  cycles: ProfitBotCycleRecord[];
  logs: ProfitBotDecisionLog[];
  hasExchangeKeys: boolean;
  isAuthenticated: boolean;
  demoMode: boolean;
  onRequireAuth: () => void;
  onCreateProfitBot: (payload: Record<string, unknown>) => Promise<void>;
  onUpdateProfitBot: (botId: string, payload: Record<string, unknown>) => Promise<void>;
  onStartProfitBot: (botId: string, confirmLive?: boolean) => Promise<void>;
  onStopProfitBot: (botId: string) => Promise<void>;
  onEvaluateProfitBot: (botId: string) => Promise<void>;
  onManualSellProfitBot: (botId: string) => Promise<void>;
  onDeleteProfitBot: (botId: string) => Promise<void>;
  onFetchPreview?: (params: {
    symbol: string;
    entryAmount: number;
    targetNetProfit: number;
    feeRate: number;
    otherFeesQuote: number;
    fundingMode?: BotFundingMode;
    existingBalancePercent?: number;
    existingQty?: number;
    existingEntryPrice?: number;
  }) => Promise<ProfitBotMarketPreview>;
  onBack?: () => void;
  onOpenGuide?: (topic: GuideBotTopic) => void;
  pendingConfirmations?: PendingBotConfirmation[];
  onResolveConfirmation?: (conf: PendingBotConfirmation, decision: 'APPROVE' | 'REJECT') => Promise<void>;
}

const POLL_PRESETS = [
  { seconds: 5, label: 'هر ۵ ثانیه' },
  { seconds: 10, label: 'هر ۱۰ ثانیه' },
  { seconds: 30, label: 'هر ۳۰ ثانیه' },
  { seconds: 60, label: 'هر ۶۰ ثانیه' },
];

const SEQUENCE_OPTIONS: Array<{
  value: ProfitBotSequenceMode;
  title: string;
  desc: string;
}> = [
  {
    value: 'SINGLE',
    title: '۱. فقط یک معامله و توقف',
    desc: 'پس از خرید و فروش با سود هدف، ربات به‌طور خودکار متوقف می‌شود.',
  },
  {
    value: 'PREPARE_NEXT',
    title: '۲. آماده‌سازی برای خرید بعدی',
    desc: 'پس از تکمیل فروش، ربات به وضعیت آماده خرید برمی‌گردد؛ خرید جدید فقط با دستور شما شروع می‌شود.',
  },
  {
    value: 'CYCLE_REPEAT',
    title: '۳. تکرار چرخه‌ای خودکار',
    desc: 'تا زمان توقف دستی یا رسیدن به سقف معاملات روزانه، سقف سرمایه درگیر یا سقف ضرر روزانه تکرار می‌شود.',
  },
];

function getStatusBadgeClass(tone: 'cyan' | 'emerald' | 'amber' | 'rose' | 'slate'): string {
  switch (tone) {
    case 'emerald':
      return 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300';
    case 'amber':
      return 'bg-amber-500/15 border-amber-500/40 text-amber-200';
    case 'rose':
      return 'bg-rose-500/15 border-rose-500/40 text-rose-300';
    case 'cyan':
      return 'bg-cyan-500/15 border-cyan-500/40 text-cyan-200';
    default:
      return 'bg-slate-800/80 border-slate-700 text-slate-300';
  }
}

function formatDurationFa(ms: number): string {
  if (!Number.isFinite(ms) || ms <= 0) return '۰ ثانیه';
  const totalSec = Math.floor(ms / 1000);
  const hours = Math.floor(totalSec / 3600);
  const mins = Math.floor((totalSec % 3600) / 60);
  const secs = totalSec % 60;
  if (hours > 0) return `${hours} ساعت و ${mins} دقیقه`;
  if (mins > 0) return `${mins} دقیقه و ${secs} ثانیه`;
  return `${secs} ثانیه`;
}

function formatSignedQuote(amount: number, quoteCurrency: QuoteCurrency): string {
  const sign = amount > 0 ? '+' : amount < 0 ? '-' : '';
  return `${sign}${formatQuoteAmount(Math.abs(amount), quoteCurrency)}`;
}

export const ProfitBotModule: React.FC<ProfitBotModuleProps> = ({
  defaultBaseAsset,
  defaultQuoteCurrency,
  onQuoteCurrencyChange,
  markets,
  balances,
  usdtTomanRate,
  profitBots,
  cycles,
  logs,
  hasExchangeKeys,
  isAuthenticated,
  demoMode,
  onRequireAuth,
  onCreateProfitBot,
  onUpdateProfitBot,
  onStartProfitBot,
  onStopProfitBot,
  onEvaluateProfitBot,
  onManualSellProfitBot,
  onDeleteProfitBot,
  onFetchPreview,
  onBack,
  onOpenGuide,
  pendingConfirmations = [],
  onResolveConfirmation,
}) => {
  const [selectedBotId, setSelectedBotId] = useState<string | null>(null);
  const [showConfigForm, setShowConfigForm] = useState<boolean>(profitBots.length === 0);
  const [editingBotId, setEditingBotId] = useState<string | null>(null);
  const [showAdvanced, setShowAdvanced] = useState<boolean>(false);
  const [historyTab, setHistoryTab] = useState<'CYCLES' | 'LOGS'>('CYCLES');

  // Form state
  const [botName, setBotName] = useState<string>('');
  const [baseAsset, setBaseAsset] = useState<string>(defaultBaseAsset || 'BTC');
  const [quoteCurrency, setQuoteCurrency] = useState<QuoteCurrency>(
    defaultQuoteCurrency || 'IRT'
  );
  const [mode, setMode] = useState<ExecutionMode>('paper');
  const [confirmLive, setConfirmLive] = useState<boolean>(false);
  const [entryIrt, setEntryIrt] = useState<number>(10_000_000);
  const [entryUsdt, setEntryUsdt] = useState<number>(100);
  const [targetIrt, setTargetIrt] = useState<number>(100_000);
  const [targetUsdt, setTargetUsdt] = useState<number>(5);
  const [pollIntervalSeconds, setPollIntervalSeconds] = useState<number>(10);
  const [hasMaxWait, setHasMaxWait] = useState<boolean>(true);
  const [maxWaitMinutes, setMaxWaitMinutes] = useState<number>(240);
  const [stopLossEnabled, setStopLossEnabled] = useState<boolean>(true);
  const [stopLossPercent, setStopLossPercent] = useState<number>(3);
  const [stopLossAction, setStopLossAction] = useState<ProfitBotStopLossAction>('STOP_AND_SELL');
  const [maxCapitalIrt, setMaxCapitalIrt] = useState<number>(20_000_000);
  const [maxCapitalUsdt, setMaxCapitalUsdt] = useState<number>(200);
  const [maxDailyTrades, setMaxDailyTrades] = useState<number>(10);
  const [maxDailyLossIrt, setMaxDailyLossIrt] = useState<number>(500_000);
  const [maxDailyLossUsdt, setMaxDailyLossUsdt] = useState<number>(15);
  const [orderType, setOrderType] = useState<ProfitBotOrderType>('MARKET');
  const [maxSlippagePercent, setMaxSlippagePercent] = useState<number>(0.5);
  const [maxSpreadPercent, setMaxSpreadPercent] = useState<number>(2.5);
  const [limitOrderTimeoutSeconds, setLimitOrderTimeoutSeconds] = useState<number>(120);
  const [limitUnfilledPolicy, setLimitUnfilledPolicy] =
    useState<ProfitBotLimitUnfilledPolicy>('KEEP_WAITING');
  const [sequenceMode, setSequenceMode] = useState<ProfitBotSequenceMode>('CYCLE_REPEAT');
  const [reentryTargetPriceInput, setReentryTargetPriceInput] = useState<string>('');
  const [reentryPolicy, setReentryPolicy] = useState<ProfitBotReentryPolicy>('WAIT_ENTRY_PRICE');
  const [waitEntryPriceOnFirstBuy, setWaitEntryPriceOnFirstBuy] = useState<boolean>(false);
  const [targetSellPriceInput, setTargetSellPriceInput] = useState<string>('');
  const [feeRatePercent, setFeeRatePercent] = useState<number>(0.25);
  const [otherFeesQuote, setOtherFeesQuote] = useState<number>(0);
  const [notifyTelegram, setNotifyTelegram] = useState<boolean>(true);
  const [fundingMode, setFundingMode] = useState<BotFundingMode>('QUOTE_BUY');
  const [existingBalancePercent, setExistingBalancePercent] = useState<number>(100);
  const [existingEntryPriceInput, setExistingEntryPriceInput] = useState<string>('');
  const [executionConfirmationMode, setExecutionConfirmationMode] =
    useState<BotExecutionConfirmationMode>('AUTO');

  const [preview, setPreview] = useState<ProfitBotMarketPreview | null>(null);
  const [loadingPreview, setLoadingPreview] = useState<boolean>(false);
  const [saving, setSaving] = useState<boolean>(false);
  const [busyBotId, setBusyBotId] = useState<string | null>(null);
  const [pendingLiveStartId, setPendingLiveStartId] = useState<string | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [nowTick, setNowTick] = useState<number>(() => Date.now());

  useEffect(() => {
    const t = setInterval(() => setNowTick(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (!editingBotId) {
      setBaseAsset(defaultBaseAsset || 'BTC');
    }
  }, [defaultBaseAsset, editingBotId]);

  useEffect(() => {
    if (!editingBotId) {
      setQuoteCurrency(defaultQuoteCurrency || 'IRT');
    }
  }, [defaultQuoteCurrency, editingBotId]);

  useEffect(() => {
    if (profitBots.length === 0) {
      setSelectedBotId(null);
      return;
    }
    if (!selectedBotId || !profitBots.some((b) => b.id === selectedBotId)) {
      const activeOne = profitBots.find((b) => b.isActive) || profitBots[0];
      setSelectedBotId(activeOne.id);
    }
  }, [profitBots, selectedBotId]);

  useEffect(() => {
    if (mode !== 'live') setConfirmLive(false);
  }, [mode]);

  const selectedMarket = useMemo(
    () => markets.find((m) => m.baseAsset === baseAsset) || null,
    [markets, baseAsset]
  );

  const freeBaseBalance = useMemo(() => {
    const found = (balances || []).find(
      (b) => b.asset.toUpperCase() === baseAsset.toUpperCase()
    );
    return found ? Math.max(0, Number(found.free) || 0) : 0;
  }, [balances, baseAsset]);

  const liveBidForBase = useMemo(() => {
    if (!selectedMarket) return 0;
    return quoteCurrency === 'IRT'
      ? selectedMarket.bestBuyToman || selectedMarket.priceToman || 0
      : selectedMarket.bestBuyUsdt || selectedMarket.priceUsdt || 0;
  }, [selectedMarket, quoteCurrency]);

  const parsedExistingEntryPrice = useMemo(() => {
    const num = Number(existingEntryPriceInput.trim());
    return Number.isFinite(num) && num > 0 ? num : null;
  }, [existingEntryPriceInput]);

  const existingAlloc = useMemo(() => {
    const refPrice = parsedExistingEntryPrice || preview?.bestBid || liveBidForBase || 0;
    return computeExistingBalanceAllocation({
      freeBase: freeBaseBalance,
      percent: existingBalancePercent,
      referencePrice: refPrice,
      minNotional: getMinimumOrderNotional(quoteCurrency),
      baseAsset,
      quoteCurrency,
    });
  }, [
    freeBaseBalance,
    existingBalancePercent,
    parsedExistingEntryPrice,
    preview?.bestBid,
    liveBidForBase,
    baseAsset,
    quoteCurrency,
  ]);

  const entryAmount = quoteCurrency === 'IRT' ? entryIrt : entryUsdt;
  const targetNetProfit = quoteCurrency === 'IRT' ? targetIrt : targetUsdt;
  const maxCapitalInvolved = Math.max(
    entryAmount,
    quoteCurrency === 'IRT' ? maxCapitalIrt : maxCapitalUsdt
  );
  const maxDailyLoss = quoteCurrency === 'IRT' ? maxDailyLossIrt : maxDailyLossUsdt;
  const feeRate = Math.min(0.05, Math.max(0, feeRatePercent / 100));

  const selectedBot = useMemo(
    () => profitBots.find((b) => b.id === selectedBotId) || profitBots[0] || null,
    [profitBots, selectedBotId]
  );

  const activeCount = useMemo(() => profitBots.filter((b) => b.isActive).length, [profitBots]);
  const totalCyclesCompleted = useMemo(
    () => profitBots.reduce((s, b) => s + b.stats.completedCycles, 0),
    [profitBots]
  );
  const totalRealizedToman = useMemo(() => {
    const rate = usdtTomanRate > 0 ? usdtTomanRate : 80_000;
    return profitBots.reduce(
      (s, b) =>
        s +
        (b.quoteCurrency === 'IRT'
          ? b.stats.totalNetProfitQuote
          : b.stats.totalNetProfitQuote * rate),
      0
    );
  }, [profitBots, usdtTomanRate]);

  // Live orderbook preview fetch when config form is open (initial + periodic 5s live refresh)
  useEffect(() => {
    if (!showConfigForm) return;
    let cancelled = false;
    setPreview(null);
    const symbol = `${baseAsset}${quoteCurrency}`;

    const fetchLatestPreview = async (showSpinner: boolean) => {
      if (showSpinner) setLoadingPreview(true);
      try {
        if (onFetchPreview && isAuthenticated && !demoMode) {
          const data = await onFetchPreview({
            symbol,
            entryAmount,
            targetNetProfit,
            feeRate,
            otherFeesQuote,
            fundingMode,
            existingBalancePercent,
            existingQty: freeBaseBalance,
            existingEntryPrice: parsedExistingEntryPrice ?? undefined,
          });
          if (!cancelled) setPreview(data);
        } else {
          const res = await fetch(
            `/api/market/depth?symbol=${encodeURIComponent(symbol)}&limit=30`
          );
          if (res.ok) {
            const book = (await res.json()) as OrderBookSnapshot;
            if (!cancelled) {
              setPreview(
                buildProfitBotMarketPreview(
                  book,
                  entryAmount,
                  targetNetProfit,
                  feeRate,
                  otherFeesQuote,
                  {
                    fundingMode,
                    freeBaseBalance,
                    existingBalancePercent,
                    existingEntryPrice: parsedExistingEntryPrice,
                  }
                )
              );
            }
          }
        }
      } catch {
        // Ignore transient depth errors
      } finally {
        if (!cancelled && showSpinner) setLoadingPreview(false);
      }
    };

    const timer = setTimeout(() => {
      void fetchLatestPreview(true);
    }, 200);

    const interval = setInterval(() => {
      void fetchLatestPreview(false);
    }, 5000);

    return () => {
      cancelled = true;
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [
    showConfigForm,
    baseAsset,
    quoteCurrency,
    entryAmount,
    targetNetProfit,
    feeRate,
    otherFeesQuote,
    fundingMode,
    existingBalancePercent,
    freeBaseBalance,
    parsedExistingEntryPrice,
    onFetchPreview,
    isAuthenticated,
    demoMode,
  ]);

  const loadBotIntoForm = (bot: ProfitBotConfig) => {
    setEditingBotId(bot.id);
    setBotName(bot.name);
    setBaseAsset(bot.baseAsset);
    setQuoteCurrency(bot.quoteCurrency);
    setMode(bot.mode);
    setConfirmLive(false);
    if (bot.quoteCurrency === 'IRT') {
      setEntryIrt(bot.entryAmount);
      setTargetIrt(bot.targetNetProfit);
      setMaxCapitalIrt(bot.maxCapitalInvolved);
      setMaxDailyLossIrt(bot.maxDailyLoss);
    } else {
      setEntryUsdt(bot.entryAmount);
      setTargetUsdt(bot.targetNetProfit);
      setMaxCapitalUsdt(bot.maxCapitalInvolved);
      setMaxDailyLossUsdt(bot.maxDailyLoss);
    }
    setPollIntervalSeconds(bot.pollIntervalSeconds);
    setHasMaxWait(Boolean(bot.maxWaitMinutes && bot.maxWaitMinutes > 0));
    setMaxWaitMinutes(bot.maxWaitMinutes || 240);
    setStopLossEnabled(bot.stopLossEnabled);
    setStopLossPercent(bot.stopLossPercent);
    setStopLossAction(bot.stopLossAction);
    setMaxDailyTrades(bot.maxDailyTrades);
    setOrderType(bot.orderType);
    setMaxSlippagePercent(bot.maxSlippagePercent);
    setMaxSpreadPercent(bot.maxSpreadPercent);
    setLimitOrderTimeoutSeconds(bot.limitOrderTimeoutSeconds);
    setLimitUnfilledPolicy(bot.limitUnfilledPolicy);
    setSequenceMode(bot.sequenceMode);
    setReentryTargetPriceInput(
      bot.reentryTargetPrice && bot.reentryTargetPrice > 0 ? String(bot.reentryTargetPrice) : ''
    );
    setReentryPolicy(bot.reentryPolicy || 'WAIT_ENTRY_PRICE');
    setWaitEntryPriceOnFirstBuy(Boolean(bot.waitEntryPriceOnFirstBuy));
    setTargetSellPriceInput(
      bot.targetSellPrice && bot.targetSellPrice > 0 ? String(bot.targetSellPrice) : ''
    );
    setFeeRatePercent(Number((bot.feeRate * 100).toFixed(3)));
    setOtherFeesQuote(bot.otherFeesQuote);
    setNotifyTelegram(bot.notifyTelegram);
    setFundingMode(bot.fundingMode || 'QUOTE_BUY');
    setExistingBalancePercent(bot.existingBalancePercent ?? 100);
    setExistingEntryPriceInput(
      bot.existingEntryPrice && bot.existingEntryPrice > 0 ? String(bot.existingEntryPrice) : ''
    );
    setExecutionConfirmationMode(bot.executionConfirmationMode || 'AUTO');
    setShowConfigForm(true);
    setFeedback(null);
  };

  const resetFormForNew = () => {
    setEditingBotId(null);
    setBotName('');
    setMode('paper');
    setConfirmLive(false);
    setOrderType('MARKET');
    setMaxSpreadPercent(2.5);
    setSequenceMode('CYCLE_REPEAT');
    setReentryTargetPriceInput('');
    setReentryPolicy('WAIT_ENTRY_PRICE');
    setWaitEntryPriceOnFirstBuy(false);
    setTargetSellPriceInput('');
    setFundingMode('QUOTE_BUY');
    setExistingBalancePercent(100);
    setExistingEntryPriceInput('');
    setExecutionConfirmationMode('AUTO');
    setFeedback(null);
    setShowConfigForm(true);
  };

  const handleSave = async (startImmediately: boolean) => {
    setFeedback(null);
    if (!isAuthenticated) {
      onRequireAuth();
      return;
    }

    const minNotional = getMinimumOrderNotional(quoteCurrency);
    if (fundingMode !== 'EXISTING_ASSET' && entryAmount + 1e-6 < minNotional) {
      setFeedback({
        type: 'err',
        text: `حداقل مبلغ ورود در بازار ${
          quoteCurrency === 'IRT' ? 'تومانی ۵۰,۰۰۰ تومان' : 'تتری ۰.۵ USDT'
        } است.`,
      });
      return;
    }
    if (fundingMode === 'EXISTING_ASSET' && startImmediately && !existingAlloc.ok) {
      setFeedback({
        type: 'err',
        text:
          existingAlloc.reason ||
          `موجودی آزاد ${baseAsset} برای ورود به معامله کافی نیست.`,
      });
      return;
    }
    if (targetNetProfit <= 0) {
      setFeedback({ type: 'err', text: 'سود خالص هدف باید بزرگ‌تر از صفر باشد.' });
      return;
    }
    if (mode === 'live' && !demoMode) {
      if (!hasExchangeKeys) {
        setFeedback({
          type: 'err',
          text: 'برای اجرای ربات سود روی حساب واقعی، ابتدا کلید API نوبیتکس را در تنظیمات حساب متصل کنید.',
        });
        return;
      }
      if (!confirmLive) {
        setFeedback({
          type: 'err',
          text: 'قبل از فعال‌سازی حالت واقعی (Live)، تیک تأیید صریح معامله با سرمایه واقعی را بزنید.',
        });
        return;
      }
    }

    const parsedReentry =
      reentryTargetPriceInput.trim() && Number(reentryTargetPriceInput) > 0
        ? Number(reentryTargetPriceInput)
        : null;
    const parsedTargetSell =
      targetSellPriceInput.trim() && Number(targetSellPriceInput) > 0
        ? Number(targetSellPriceInput)
        : null;

    const payload: Record<string, unknown> = {
      name: botName.trim() || undefined,
      baseAsset,
      quoteCurrency,
      mode: demoMode ? 'paper' : mode,
      confirmLive: !demoMode && mode === 'live' ? confirmLive : undefined,
      startImmediately,
      entryAmount: fundingMode === 'EXISTING_ASSET' && entryAmount <= 0 ? minNotional : entryAmount,
      targetNetProfit,
      pollIntervalSeconds,
      maxWaitMinutes: hasMaxWait ? maxWaitMinutes : null,
      stopLossEnabled,
      stopLossPercent,
      stopLossAction,
      maxCapitalInvolved,
      maxDailyTrades,
      maxDailyLoss,
      orderType,
      maxSlippagePercent,
      maxSpreadPercent,
      limitOrderTimeoutSeconds,
      limitUnfilledPolicy,
      sequenceMode,
      reentryTargetPrice: parsedReentry,
      reentryPolicy,
      waitEntryPriceOnFirstBuy,
      targetSellPrice: parsedTargetSell,
      feeRate,
      otherFeesQuote,
      notifyTelegram,
      fundingMode,
      existingBalancePercent: Math.min(100, Math.max(1, Math.round(existingBalancePercent))),
      existingEntryPrice: parsedExistingEntryPrice,
      executionConfirmationMode,
    };

    setSaving(true);
    try {
      if (editingBotId) {
        await onUpdateProfitBot(editingBotId, payload);
        if (startImmediately) {
          await onStartProfitBot(editingBotId, mode === 'live' ? confirmLive : undefined);
        }
        setFeedback({
          type: 'ok',
          text: startImmediately
            ? 'تنظیمات ربات سود ذخیره شد و ربات شروع به کار کرد.'
            : 'تنظیمات ربات سود با موفقیت ذخیره شد.',
        });
      } else {
        await onCreateProfitBot(payload);
        setFeedback({
          type: 'ok',
          text: startImmediately
            ? 'ربات سود ساخته شد و بررسی لحظه‌ای بازار نوبیتکس آغاز گردید.'
            : 'ربات سود ذخیره شد و آماده شروع است.',
        });
      }
      setEditingBotId(null);
      setShowConfigForm(false);
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ذخیره ربات سود.',
      });
    } finally {
      setSaving(false);
    }
  };

  // Telemetry derivations for selectedBot
  const telemetry = useMemo(() => {
    if (!selectedBot) return null;
    const pos = selectedBot.activePosition;
    const mkt = markets.find((m) => m.baseAsset === selectedBot.baseAsset);
    const liveMarketPrice = mkt
      ? selectedBot.quoteCurrency === 'IRT'
        ? pos
          ? mkt.bestBuyToman || mkt.priceToman
          : mkt.bestSellToman || mkt.priceToman
        : pos
          ? mkt.bestBuyUsdt || mkt.priceUsdt
          : mkt.bestSellUsdt || mkt.priceUsdt
      : 0;

    const currentSellPrice = pos?.lastExecutableSellPrice || liveMarketPrice || 0;
    const buyFee =
      pos?.buyFeeQuote ??
      (selectedBot.fundingMode === 'EXISTING_ASSET'
        ? 0
        : selectedBot.entryAmount * selectedBot.feeRate);
    const estSellFee =
      pos?.lastEstimatedSellFeeQuote ??
      (pos ? pos.netOwnedQty * currentSellPrice * selectedBot.feeRate : 0);
    const currentNetProfit = pos
      ? pos.lastEstimatedNetProfitQuote ?? 0
      : selectedBot.stats.totalNetProfitQuote;
    const progressPercent = pos
      ? pos.lastProgressPercent ??
        computeProfitProgressPercent(currentNetProfit, selectedBot.targetNetProfit)
      : selectedBot.botStatus === 'SELL_FILLED' || selectedBot.stats.completedCycles > 0
        ? 100
        : 0;

    const targetSellPriceForTel =
      selectedBot.targetSellPrice && selectedBot.targetSellPrice > 0
        ? selectedBot.targetSellPrice
        : pos?.lastRequiredSellPrice || 0;
    const targetProgress = computeProfitBotTargetProgress({
      actualBuyAvgPrice: pos?.actualBuyAvgPrice,
      currentPrice: currentSellPrice,
      targetSellPrice: targetSellPriceForTel,
      currentNetProfitQuote: currentNetProfit,
      targetNetProfit: selectedBot.targetNetProfit,
      hasActivePosition: Boolean(pos),
      isSellCompleted: selectedBot.botStatus === 'SELL_FILLED',
    });

    const elapsedAnchor = pos?.buyFilledAt || selectedBot.startedAt || null;
    const elapsedMs =
      elapsedAnchor && (selectedBot.isActive || pos) ? Math.max(0, nowTick - elapsedAnchor) : 0;

    return {
      pos,
      currentSellPrice,
      buyFee,
      estSellFee,
      currentNetProfit,
      progressPercent,
      targetProgress,
      elapsedMs,
      hasDepthIssue: Boolean(pos && pos.lastHasSufficientDepth === false),
    };
  }, [selectedBot, markets, nowTick]);

  const selectedStatusMeta = selectedBot
    ? getProfitBotStatusMeta(selectedBot.botStatus)
    : null;

  return (
    <div className="space-y-6">
      {/* Independent Profit Bot Header Card */}
      <div className="glass-panel rounded-xl p-5 border border-emerald-500/25 bg-gradient-to-br from-emerald-950/30 via-[#071022]/85 to-[#060C19]/95">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-3.5 max-w-3xl">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500/30 to-cyan-500/20 border border-emerald-400/40 flex items-center justify-center shrink-0 shadow-lg shadow-emerald-950/50">
              <TrendingUp className="w-6 h-6 text-emerald-300" />
            </div>
            <div>
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white">
                  ربات سود (Profit Bot)
                </h2>
                <span className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-emerald-500/15 border border-emerald-500/35 text-emerald-300">
                  مستقل · محاسبه واقعی دفتر سفارش و کارمزد
                </span>
                {demoMode && (
                  <span className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-amber-500/15 border border-amber-500/35 text-amber-200">
                    حالت دمو فعال
                  </span>
                )}
              </div>
              <p className="text-xs text-slate-300/90 mt-1.5 leading-relaxed">
                این ربات به‌صورت مستقل یک ارز را خریداری می‌کند و با رصد مداوم عمق خریداران در دفتر سفارش نوبیتکس، کارمزد واقعی خرید، کارمزد تخمینی فروش و اسپرد، زمانی می‌فروشد که{' '}
                <span className="text-emerald-300 font-semibold">سود خالص هدف شما پس از کسر تمام هزینه‌ها</span>{' '}
                قابل تحقق باشد.
              </p>
              <p className="text-[11px] text-amber-200/80 mt-1 flex items-center gap-1.5">
                <ShieldAlert className="w-3.5 h-3.5 shrink-0 text-amber-300" />
                <span>
                  توجه: هدف سود به معنی تضمین سود نیست؛ در صورت نامناسب بودن نقدینگی یا افت بازار ربات طبق حد ضرر و محدودیت‌های شما عمل می‌کند.
                </span>
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {onBack && (
              <button
                type="button"
                onClick={onBack}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3 py-2 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold"
              >
                <ArrowRight className="w-4 h-4" />
                <span>بازگشت</span>
              </button>
            )}
            {onOpenGuide && (
              <button
                type="button"
                onClick={() => onOpenGuide('PROFIT')}
                className="min-h-[40px] inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-cyan-500/35 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-200 text-xs font-bold"
              >
                <BookOpen className="w-4 h-4" />
                <span>راهنمای استفاده</span>
              </button>
            )}
            <button
              type="button"
              onClick={() => {
                if (showConfigForm && !editingBotId) {
                  setShowConfigForm(false);
                } else {
                  resetFormForNew();
                }
              }}
              className="btn-glass btn-glass-buy min-h-[40px] inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0"
            >
              <Plus className="w-4 h-4" />
              <span>{showConfigForm && !editingBotId ? 'بستن فرم تنظیمات' : 'ساخت / تنظیم ربات سود'}</span>
            </button>
          </div>
        </div>

        {/* Top KPI Strip */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-4 pt-4 border-t border-slate-800/70 text-xs">
          <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 px-3.5 py-2.5">
            <div className="text-slate-400">تعداد ربات‌های سود</div>
            <div className="text-base font-bold text-white font-mono-num mt-0.5">
              {profitBots.length}{' '}
              <span className="text-xs font-normal text-emerald-300">({activeCount} فعال)</span>
            </div>
          </div>
          <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 px-3.5 py-2.5">
            <div className="text-slate-400">چرخه‌های تکمیل‌شده</div>
            <div className="text-base font-bold text-cyan-300 font-mono-num mt-0.5">
              {totalCyclesCompleted} معامله
            </div>
          </div>
          <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 px-3.5 py-2.5">
            <div className="text-slate-400">سود خالص کل محقق‌شده</div>
            <div
              className={`text-base font-bold font-mono-num mt-0.5 ${
                totalRealizedToman >= 0 ? 'text-emerald-300' : 'text-rose-300'
              }`}
            >
              {totalRealizedToman >= 0 ? '+' : '-'}
              {formatToman(Math.abs(Math.round(totalRealizedToman)))} تومان
            </div>
          </div>
          <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 px-3.5 py-2.5">
            <div className="text-slate-400">مبنای تشخیص سود</div>
            <div className="text-xs font-medium text-slate-200 mt-1">
              عمق واقعی دفتر سفارش + کسر کارمزدها
            </div>
          </div>
        </div>
      </div>

      {pendingConfirmations.length > 0 && (
        <div className="rounded-2xl border border-amber-500/40 bg-amber-500/10 p-4 space-y-2.5 text-xs">
          <div className="flex items-center gap-2 text-amber-200 font-bold">
            <Hand className="w-4 h-4 text-amber-400" />
            سفارش ربات سود در انتظار تأیید دستی شما ({pendingConfirmations.length})
          </div>
          {pendingConfirmations.map((conf) => (
            <div
              key={conf.id}
              className="rounded-xl border border-amber-500/30 bg-[#0A101D]/90 p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
            >
              <div className="space-y-1">
                <div className="font-bold text-white">
                  {conf.side === 'BUY' ? 'خرید' : 'فروش'} {conf.symbol} ·{' '}
                  <span className="font-mono-num text-cyan-300">
                    {conf.suggestedPrice.toLocaleString('en-US')}
                  </span>
                </div>
                <div className="text-slate-300">{conf.reasonFa}</div>
              </div>
              {onResolveConfirmation && (
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => void onResolveConfirmation(conf, 'APPROVE')}
                    className="min-h-[40px] px-3.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold"
                  >
                    تأیید و اجرا
                  </button>
                  <button
                    type="button"
                    onClick={() => void onResolveConfirmation(conf, 'REJECT')}
                    className="min-h-[40px] px-3 rounded-xl border border-rose-500/40 bg-rose-500/10 text-rose-200 font-bold"
                  >
                    رد کردن
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {feedback && (
        <div
          className={`rounded-xl px-4 py-3 text-xs flex items-center justify-between gap-3 border ${
            feedback.type === 'ok'
              ? 'bg-emerald-500/12 border-emerald-500/40 text-emerald-200'
              : 'bg-rose-500/12 border-rose-500/40 text-rose-200'
          }`}
        >
          <span>{feedback.text}</span>
          <button
            type="button"
            onClick={() => setFeedback(null)}
            className="text-slate-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Create / Edit Configuration Panel */}
      {showConfigForm && (
        <div className="glass-panel rounded-xl p-5 border border-cyan-500/25 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
              <h3 className="text-sm font-bold text-white">
                {editingBotId ? 'ویرایش تنظیمات ربات سود' : 'تنظیمات اولیه ربات سود جدید'}
              </h3>
            </div>
            <button
              type="button"
              onClick={() => {
                setShowConfigForm(false);
                setEditingBotId(null);
              }}
              className="text-xs text-slate-400 hover:text-white inline-flex items-center gap-1"
            >
              <X className="w-4 h-4" />
              <span>بستن</span>
            </button>
          </div>

          {/* 1. Coin, Quote Currency & Execution Mode */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
            <div>
              <label className="block text-slate-400 mb-1.5">نام ربات (اختیاری)</label>
              <input
                type="text"
                value={botName}
                onChange={(e) => setBotName(e.target.value)}
                placeholder={`ربات سود ${baseAsset}/${quoteCurrency === 'IRT' ? 'تومان' : 'تتر'}`}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-emerald-500/60"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1.5">انتخاب ارز دیجیتال</label>
              <CoinSearchSelect
                markets={markets}
                value={baseAsset}
                onChange={(nextBase) => setBaseAsset(nextBase)}
                quoteCurrency={quoteCurrency}
                ariaLabel="جستجو و انتخاب ارز ربات سود"
              />
            </div>

            <div>
              <label className="block text-slate-400 mb-1.5">جفت‌ارز معاملاتی</label>
              <div className="grid grid-cols-2 gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800">
                <button
                  type="button"
                  disabled={selectedMarket ? !selectedMarket.hasIrtMarket : false}
                  onClick={() => {
                    setQuoteCurrency('IRT');
                    onQuoteCurrencyChange?.('IRT');
                  }}
                  className={`py-1.5 rounded-md font-medium transition ${
                    quoteCurrency === 'IRT'
                      ? 'bg-amber-500/20 text-amber-200 border border-amber-500/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  تومانی ({baseAsset}/IRT)
                </button>
                <button
                  type="button"
                  disabled={selectedMarket ? !selectedMarket.hasUsdtMarket : false}
                  onClick={() => {
                    setQuoteCurrency('USDT');
                    onQuoteCurrencyChange?.('USDT');
                  }}
                  className={`py-1.5 rounded-md font-medium transition ${
                    quoteCurrency === 'USDT'
                      ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  تتری ({baseAsset}/USDT)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-slate-400 mb-1.5">حالت اجرا (پیش‌فرض دمو)</label>
              <div className="grid grid-cols-2 gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800">
                <button
                  type="button"
                  onClick={() => setMode('paper')}
                  className={`py-1.5 rounded-md font-medium transition ${
                    mode === 'paper'
                      ? 'bg-cyan-500/20 text-cyan-200 border border-cyan-500/40'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  دمو / تمرینی
                </button>
                <button
                  type="button"
                  disabled={demoMode}
                  onClick={() => setMode('live')}
                  className={`py-1.5 rounded-md font-medium transition ${
                    mode === 'live'
                      ? 'bg-rose-500/20 text-rose-200 border border-rose-500/40'
                      : 'text-slate-400 hover:text-white disabled:opacity-40'
                  }`}
                >
                  واقعی (Live)
                </button>
              </div>
            </div>
          </div>

          {/* 1.5 Funding Source: Quote Buy vs Existing Asset Holding */}
          <div className="rounded-xl border border-indigo-500/25 bg-indigo-950/20 p-4 space-y-3 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="font-semibold text-indigo-200 flex items-center gap-2">
                <Coins className="w-4 h-4 text-indigo-400" />
                <span>منبع سرمایه ورود به معامله</span>
              </div>
              <div className="text-[11px] font-mono-num text-slate-300">
                موجودی آزاد فعلی {baseAsset}:{' '}
                <span className="text-emerald-300 font-semibold">
                  {formatQty(freeBaseBalance)} {baseAsset}
                </span>
                {liveBidForBase > 0 && freeBaseBalance > 0 && (
                  <span className="text-slate-400 mr-1.5">
                    (≈ {formatQuoteAmount(freeBaseBalance * liveBidForBase, quoteCurrency)})
                  </span>
                )}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-2">
              {(
                [
                  {
                    value: 'QUOTE_BUY' as BotFundingMode,
                    title: 'خرید با موجودی ریال / تتر',
                    desc: 'ابتدا با تومان یا تتر ارز را می‌خرد و بعد دنبال سود هدف می‌گردد.',
                  },
                  {
                    value: 'EXISTING_ASSET' as BotFundingMode,
                    title: `فقط از موجودی فعلی ${baseAsset}`,
                    desc: `بدون خرید جدید؛ مستقیماً درصد مشخصی از ${baseAsset} موجود را برای فروش با سود وارد چرخه می‌کند.`,
                  },
                  {
                    value: 'AUTO_PREFER_EXISTING' as BotFundingMode,
                    title: 'هوشمند (اول موجودی ارز، در غیر این صورت خرید)',
                    desc: `اگر موجودی ${baseAsset} کافی بود از آن استفاده می‌کند؛ وگرنه با تومان/تتر می‌خرد.`,
                  },
                ] as const
              ).map((opt) => {
                const active = fundingMode === opt.value;
                return (
                  <button
                    key={opt.value}
                    type="button"
                    onClick={() => setFundingMode(opt.value)}
                    className={`text-right rounded-lg p-3 border transition ${
                      active
                        ? 'bg-indigo-500/20 border-indigo-400/60 text-white'
                        : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className="font-semibold text-[12px]">{opt.title}</div>
                    <div className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                      {opt.desc}
                    </div>
                  </button>
                );
              })}
            </div>

            {fundingMode !== 'QUOTE_BUY' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                <div className="rounded-lg bg-slate-950/70 border border-slate-800 p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <label className="text-slate-300 font-medium">
                      درصد استفاده از موجودی آزاد {baseAsset}
                    </label>
                    <span className="font-mono-num font-bold text-indigo-300">
                      {existingBalancePercent}٪
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <input
                      type="range"
                      min={1}
                      max={100}
                      value={existingBalancePercent}
                      onChange={(e) => setExistingBalancePercent(Number(e.target.value))}
                      className="flex-1 accent-indigo-400"
                    />
                    <NumericInput
                      value={existingBalancePercent}
                      onValueChange={(raw) => {
                        const v = raw === '' ? 100 : Number(raw);
                        if (Number.isFinite(v)) {
                          setExistingBalancePercent(Math.min(100, Math.max(1, Math.round(v))));
                        }
                      }}
                      allowDecimal={false}
                      className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-center text-white font-mono-num"
                    />
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {[25, 50, 75, 100].map((pct) => (
                      <button
                        key={pct}
                        type="button"
                        onClick={() => setExistingBalancePercent(pct)}
                        className={`px-2.5 py-0.5 rounded text-[11px] font-mono-num border ${
                          existingBalancePercent === pct
                            ? 'bg-indigo-500/25 border-indigo-400/50 text-indigo-200'
                            : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {pct}٪
                      </button>
                    ))}
                  </div>
                  <div className="text-[11px] font-mono-num pt-0.5">
                    {existingAlloc.ok ? (
                      <span className="text-emerald-300">
                        مقدار تخصیص‌یافته: {formatQty(existingAlloc.allocatedQty)} {baseAsset}{' '}
                        {existingAlloc.notionalQuote > 0 &&
                          `(ارزش: ${formatQuoteAmount(existingAlloc.notionalQuote, quoteCurrency)})`}
                      </span>
                    ) : (
                      <span className="text-amber-300">
                        {existingAlloc.reason || `موجودی ${baseAsset} برای ورود کافی نیست.`}
                      </span>
                    )}
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/70 border border-slate-800 p-3 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <label className="text-slate-300 font-medium">
                      قیمت مبنای خرید قبلی ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'} · اختیاری)
                    </label>
                    {liveBidForBase > 0 && (
                      <button
                        type="button"
                        onClick={() =>
                          setExistingEntryPriceInput(formatRawDecimalPrice(liveBidForBase))
                        }
                        className="text-[10px] text-cyan-300 hover:text-cyan-200 underline"
                      >
                        درج قیمت لحظه‌ای
                      </button>
                    )}
                  </div>
                  <NumericInput
                    value={existingEntryPriceInput}
                    onValueChange={setExistingEntryPriceInput}
                    allowDecimal
                    placeholder="مثلاً خالی = قیمت لحظه‌ای فروش بازار"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono-num focus:outline-none focus:border-indigo-400"
                  />
                  <div className="text-[11px] text-slate-400 leading-relaxed">
                    اگر خالی بماند، ارزش فعلی دارایی در لحظه شروع معیار محاسبه سود خالص هدف قرار می‌گیرد (کارمزد خرید: ۰).
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 2. Entry Amount, Max Capital Involved, Target Net Profit, Poll Interval */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-xs">
            <div
              className={`rounded-xl bg-slate-950/60 border p-3.5 space-y-2 transition ${
                fundingMode === 'EXISTING_ASSET'
                  ? 'border-slate-800/50 opacity-60'
                  : 'border-slate-800/80'
              }`}
            >
              <div className="flex items-center justify-between gap-1">
                <label className="text-slate-300 font-medium">
                  {fundingMode === 'EXISTING_ASSET'
                    ? 'مبلغ خرید (غیرفعال در حالت موجودی فعلی)'
                    : fundingMode === 'AUTO_PREFER_EXISTING'
                      ? `مبلغ خرید جایگزین (${quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})`
                      : `مبلغ ورود به معامله (${quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})`}
                </label>
                {fundingMode !== 'EXISTING_ASSET' && (
                  <span className="text-[10px] text-slate-400 font-mono-num">
                    حداقل: {quoteCurrency === 'IRT' ? '۵۰K' : '۰.۵$'}
                  </span>
                )}
              </div>
              <NumericInput
                value={quoteCurrency === 'IRT' ? entryIrt : entryUsdt}
                onValueChange={(raw) => {
                  const val = raw === '' || raw === '.' ? 0 : Number(raw);
                  if (!Number.isFinite(val)) return;
                  if (quoteCurrency === 'IRT') setEntryIrt(val);
                  else setEntryUsdt(val);
                }}
                allowDecimal={quoteCurrency === 'USDT'}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono-num focus:outline-none focus:border-emerald-500/60"
              />
              <div className="flex flex-wrap gap-1.5">
                {(quoteCurrency === 'IRT'
                  ? [100_000, 500_000, 1_000_000, 5_000_000, 10_000_000]
                  : [50, 100, 250, 500]
                ).map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() =>
                      quoteCurrency === 'IRT' ? setEntryIrt(preset) : setEntryUsdt(preset)
                    }
                    className={`px-2 py-0.5 rounded text-[11px] font-mono-num border ${
                      entryAmount === preset
                        ? 'bg-emerald-500/20 border-emerald-500/45 text-emerald-200'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {quoteCurrency === 'IRT'
                      ? preset >= 1_000_000
                        ? `${(preset / 1_000_000).toLocaleString('fa-IR')}M`
                        : `${(preset / 1_000).toLocaleString('fa-IR')}K`
                      : `$${preset}`}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-xl bg-slate-950/60 border border-cyan-500/25 p-3.5 space-y-2">
              <label className="block text-cyan-200 font-medium">
                سقف سرمایه درگیر ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})
              </label>
              <NumericInput
                value={quoteCurrency === 'IRT' ? maxCapitalIrt : maxCapitalUsdt}
                onValueChange={(raw) => {
                  const v = raw === '' || raw === '.' ? 0 : Number(raw);
                  if (!Number.isFinite(v)) return;
                  if (quoteCurrency === 'IRT') setMaxCapitalIrt(v);
                  else setMaxCapitalUsdt(v);
                }}
                allowDecimal={quoteCurrency === 'USDT'}
                className="w-full bg-slate-900 border border-cyan-500/35 rounded-lg px-3 py-2 text-white font-mono-num focus:outline-none focus:border-cyan-400"
              />
              <div className="text-[11px] text-slate-400">
                حداکثر سرمایه‌ای که هم‌زمان وارد چرخه می‌شود
              </div>
            </div>

            <div className="rounded-xl bg-slate-950/60 border border-emerald-500/25 p-3.5 space-y-2">
              <div className="flex items-center justify-between gap-1">
                <label className="text-emerald-300 font-semibold">
                  سود خالص هدف ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})
                </label>
                <span className="text-[10px] text-emerald-400/80">با کسر کارمزد</span>
              </div>
              <NumericInput
                value={quoteCurrency === 'IRT' ? targetIrt : targetUsdt}
                onValueChange={(raw) => {
                  const val = raw === '' || raw === '.' ? 0 : Number(raw);
                  if (!Number.isFinite(val)) return;
                  if (quoteCurrency === 'IRT') setTargetIrt(val);
                  else setTargetUsdt(val);
                }}
                allowDecimal={quoteCurrency === 'USDT'}
                className="w-full bg-slate-900 border border-emerald-500/35 rounded-lg px-3 py-2 text-emerald-200 font-mono-num font-bold focus:outline-none focus:border-emerald-400"
              />
              <div className="flex flex-wrap gap-1.5">
                {(quoteCurrency === 'IRT'
                  ? [10_000, 50_000, 100_000, 500_000]
                  : [2, 5, 10, 25]
                ).map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() =>
                      quoteCurrency === 'IRT' ? setTargetIrt(preset) : setTargetUsdt(preset)
                    }
                    className={`px-2 py-0.5 rounded text-[11px] font-mono-num border ${
                      targetNetProfit === preset
                        ? 'bg-emerald-500/25 border-emerald-400/50 text-emerald-200'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {quoteCurrency === 'IRT'
                      ? `${(preset / 1000).toLocaleString('fa-IR')}K`
                      : `$${preset}`}
                  </button>
                ))}
              </div>
            </div>

            <div className="rounded-xl bg-slate-950/60 border border-slate-800/80 p-3.5 space-y-2">
              <label className="block text-slate-300 font-medium">فاصله بررسی بازار</label>
              <div className="grid grid-cols-2 gap-1.5">
                {POLL_PRESETS.map((opt) => (
                  <button
                    key={opt.seconds}
                    type="button"
                    onClick={() => setPollIntervalSeconds(opt.seconds)}
                    className={`py-1.5 px-2 rounded-lg text-[11px] font-medium border ${
                      pollIntervalSeconds === opt.seconds
                        ? 'bg-cyan-500/20 border-cyan-500/45 text-cyan-200'
                        : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              <div className="flex items-center gap-2 pt-1">
                <span className="text-[11px] text-slate-400">دلخواه (ثانیه):</span>
                <NumericInput
                  value={pollIntervalSeconds}
                  onValueChange={(raw) => {
                    const v = Number(raw);
                    if (Number.isFinite(v) && raw !== '') {
                      setPollIntervalSeconds(Math.max(2, Math.min(300, Math.round(v))));
                    }
                  }}
                  allowDecimal={false}
                  className="w-20 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white font-mono-num text-center"
                />
              </div>
            </div>
          </div>

          {/* 3. Risk Caps, Max Wait, Stop Loss */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            <div className="rounded-xl bg-slate-950/60 border border-slate-800/80 p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-slate-300 font-medium">حداکثر زمان انتظار سود</label>
                <input
                  type="checkbox"
                  checked={hasMaxWait}
                  onChange={(e) => setHasMaxWait(e.target.checked)}
                  className="accent-cyan-400"
                />
              </div>
              {hasMaxWait ? (
                <div className="flex items-center gap-2">
                  <NumericInput
                    value={maxWaitMinutes}
                    onValueChange={(raw) => {
                      const v = Number(raw);
                      if (Number.isFinite(v) && raw !== '') {
                        setMaxWaitMinutes(Math.max(1, Math.round(v)));
                      }
                    }}
                    allowDecimal={false}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-white font-mono-num"
                  />
                  <span className="text-slate-400 shrink-0">دقیقه</span>
                </div>
              ) : (
                <div className="text-[11px] text-slate-500 py-1.5">
                  نامحدود (تا زمان رسیدن به هدف یا توقف دستی)
                </div>
              )}
            </div>

            <div className="rounded-xl bg-slate-950/60 border border-slate-800/80 p-3.5 space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-slate-300 font-medium">حد ضرر اختیاری (SL)</label>
                <input
                  type="checkbox"
                  checked={stopLossEnabled}
                  onChange={(e) => setStopLossEnabled(e.target.checked)}
                  className="accent-rose-400"
                />
              </div>
              {stopLossEnabled ? (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <NumericInput
                      value={stopLossPercent}
                      onValueChange={(raw) => {
                        const v = raw === '' || raw === '.' ? 0.2 : Number(raw);
                        if (Number.isFinite(v)) {
                          setStopLossPercent(Math.max(0.2, Math.min(90, v)));
                        }
                      }}
                      allowDecimal
                      className="w-24 bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-rose-200 font-mono-num"
                    />
                    <span className="text-slate-400">درصد افت</span>
                  </div>
                  <select
                    value={stopLossAction}
                    onChange={(e) =>
                      setStopLossAction(e.target.value as ProfitBotStopLossAction)
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-[11px] text-slate-200"
                  >
                    <option value="STOP_AND_SELL">فروش فوری و توقف ربات</option>
                    <option value="STOP_ONLY">فقط توقف ربات (نگهداری ارز)</option>
                  </select>
                </div>
              ) : (
                <div className="text-[11px] text-slate-500 py-1.5">حد ضرر غیرفعال است</div>
              )}
            </div>

            <div className="rounded-xl bg-slate-950/60 border border-slate-800/80 p-3.5 space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-slate-300 font-medium mb-1">سقف معامله روزانه</label>
                  <NumericInput
                    value={maxDailyTrades}
                    onValueChange={(raw) => {
                      const v = Number(raw);
                      if (Number.isFinite(v) && raw !== '') {
                        setMaxDailyTrades(Math.max(1, Math.round(v)));
                      }
                    }}
                    allowDecimal={false}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono-num"
                  />
                </div>
                <div>
                  <label className="block text-slate-300 font-medium mb-1">
                    سقف ضرر روزانه ({quoteCurrency})
                  </label>
                  <NumericInput
                    value={quoteCurrency === 'IRT' ? maxDailyLossIrt : maxDailyLossUsdt}
                    onValueChange={(raw) => {
                      const v = raw === '' || raw === '.' ? 0 : Number(raw);
                      if (!Number.isFinite(v)) return;
                      if (quoteCurrency === 'IRT') setMaxDailyLossIrt(Math.max(0, v));
                      else setMaxDailyLossUsdt(Math.max(0, v));
                    }}
                    allowDecimal={quoteCurrency === 'USDT'}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-white font-mono-num"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* 4. Sequential Execution Mode & Custom Entry/Exit Price Rules */}
          <div className="space-y-3 text-xs">
            <label className="block text-slate-300 font-semibold">
              نحوه اجرای معاملات متوالی پس از پایان هر معامله
            </label>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              {SEQUENCE_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => setSequenceMode(opt.value)}
                  className={`text-right rounded-xl p-3 border transition ${
                    sequenceMode === opt.value
                      ? 'bg-emerald-500/15 border-emerald-500/45 text-white'
                      : 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="font-semibold text-emerald-300">{opt.title}</div>
                  <div className="text-[11px] text-slate-400 mt-1 leading-relaxed">{opt.desc}</div>
                </button>
              ))}
            </div>

            <div className="rounded-xl bg-slate-950/70 border border-cyan-500/25 p-4 grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <label className="text-cyan-200 font-semibold">
                    قیمت بازگشت برای تکرار خرید ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'} — اختیاری)
                  </label>
                  {(() => {
                    // On Nobitex: preview.bestAsk (or stats bestSell) is the price you pay to BUY immediately
                    const liveBuyAskPrice =
                      preview && preview.symbol === `${baseAsset}${quoteCurrency}` && preview.bestAsk > 0
                        ? preview.bestAsk
                        : quoteCurrency === 'IRT'
                          ? selectedMarket?.bestSellToman || selectedMarket?.priceToman || 0
                          : selectedMarket?.bestSellUsdt || selectedMarket?.priceUsdt || 0;
                    return liveBuyAskPrice > 0 ? (
                      <button
                        type="button"
                        onClick={async () => {
                          setReentryTargetPriceInput(formatRawDecimalPrice(liveBuyAskPrice));
                          try {
                            const res = await fetch(
                              `/api/market/depth?symbol=${encodeURIComponent(`${baseAsset}${quoteCurrency}`)}&limit=30`
                            );
                            if (res.ok) {
                              const book = (await res.json()) as OrderBookSnapshot;
                              const freshAsk = [...(book.asks || [])]
                                .map((lvl) => Number(lvl.price))
                                .filter((p) => Number.isFinite(p) && p > 0)
                                .sort((a, b) => a - b)[0];
                              if (freshAsk && freshAsk > 0) {
                                setReentryTargetPriceInput(formatRawDecimalPrice(freshAsk));
                              }
                            }
                          } catch {
                            // Keep already inserted liveBuyAskPrice
                          }
                        }}
                        className="text-[11px] text-cyan-300 hover:text-cyan-200 underline"
                      >
                        درج قیمت خرید لحظه‌ای ({formatQuotePrice(liveBuyAskPrice, quoteCurrency)})
                      </button>
                    ) : null;
                  })()}
                </div>
                <NumericInput
                  value={reentryTargetPriceInput}
                  onValueChange={(raw) => setReentryTargetPriceInput(raw)}
                  allowDecimal
                  placeholder="خالی = قیمت خرید چرخه اول (خودکار · قابل ورود به‌صورت اعشاری)"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono-num placeholder:text-slate-500 placeholder:text-[11px]"
                />
                {reentryTargetPriceInput.trim() && Number(reentryTargetPriceInput) > 0 && (
                  <div className="text-[11px] text-cyan-300/90 font-mono-num">
                    نرخ ثبت‌شده: {formatQuotePrice(Number(reentryTargetPriceInput), quoteCurrency)}
                  </div>
                )}
                <div className="grid grid-cols-2 gap-1.5 pt-0.5">
                  <button
                    type="button"
                    onClick={() => setReentryPolicy('WAIT_ENTRY_PRICE')}
                    className={`py-1.5 px-2 rounded-lg text-[11px] border ${
                      reentryPolicy === 'WAIT_ENTRY_PRICE'
                        ? 'bg-cyan-500/20 border-cyan-500/45 text-cyan-200 font-medium'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    صبر برای بازگشت به این قیمت
                  </button>
                  <button
                    type="button"
                    onClick={() => setReentryPolicy('IMMEDIATE')}
                    className={`py-1.5 px-2 rounded-lg text-[11px] border ${
                      reentryPolicy === 'IMMEDIATE'
                        ? 'bg-emerald-500/20 border-emerald-500/45 text-emerald-200 font-medium'
                        : 'bg-slate-900 border-slate-800 text-slate-400'
                    }`}
                  >
                    خرید فوری بدون صبر قیمت
                  </button>
                </div>
                <label className="flex items-center gap-2 text-[11px] text-slate-300 cursor-pointer pt-0.5">
                  <input
                    type="checkbox"
                    checked={waitEntryPriceOnFirstBuy}
                    onChange={(e) => setWaitEntryPriceOnFirstBuy(e.target.checked)}
                    className="accent-cyan-400"
                  />
                  <span>
                    در خرید اول هم منتظر این قیمت بمان (در غیر این صورت بلافاصله پس از استارت می‌خرد)
                  </span>
                </label>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between gap-2">
                  <label className="text-emerald-200 font-semibold">
                    قیمت دقیق فروش هدف ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'} — اختیاری)
                  </label>
                  {preview?.estimatedRequiredSellPrice ? (
                    <button
                      type="button"
                      onClick={() =>
                        setTargetSellPriceInput(
                          formatRawDecimalPrice(preview.estimatedRequiredSellPrice)
                        )
                      }
                      className="text-[11px] text-emerald-300 hover:text-emerald-200 underline"
                    >
                      درج قیمت سود هدف ({formatQuotePrice(preview.estimatedRequiredSellPrice, quoteCurrency)})
                    </button>
                  ) : null}
                </div>
                <NumericInput
                  value={targetSellPriceInput}
                  onValueChange={(raw) => setTargetSellPriceInput(raw)}
                  allowDecimal
                  placeholder="خالی = فروش خودکار در سود هدف (قابل ورود به‌صورت اعشاری)"
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono-num placeholder:text-slate-500 placeholder:text-[11px]"
                />
                <div className="text-[11px] text-slate-400 leading-relaxed">
                  {targetSellPriceInput.trim() && Number(targetSellPriceInput) > 0 && preview?.buySimulation.netQtyReceived ? (
                    (() => {
                      const customPx = Number(targetSellPriceInput);
                      const gross = preview.buySimulation.netQtyReceived * customPx;
                      const net =
                        gross -
                        gross * feeRate -
                        otherFeesQuote -
                        preview.buySimulation.totalBuyCostQuote;
                      return (
                        <span>
                          در صورت فروش در{' '}
                          <strong className="text-white font-mono-num">
                            {formatQuotePrice(customPx, quoteCurrency)}
                          </strong>
                          ، سود خالص تخمینی پس از کسر کارمزد خرید و فروش حدود{' '}
                          <strong
                            className={`font-mono-num ${
                              net >= 0 ? 'text-emerald-300' : 'text-rose-300'
                            }`}
                          >
                            {formatSignedQuote(net, quoteCurrency)}
                          </strong>{' '}
                          خواهد بود.
                        </span>
                      );
                    })()
                  ) : (
                    <span>
                      در حالت خودکار، ربات به محض اینکه سود خالص قابل فروش از مبلغ{' '}
                      <strong className="text-emerald-300 font-mono-num">
                        {formatQuoteAmount(targetNetProfit, quoteCurrency)}
                      </strong>{' '}
                      عبور کند (با احتساب کارمزد خرید/فروش و اسپرد) درجا می‌فروشد.
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* 5. Advanced Order & Fee Settings */}
          <div className="rounded-xl border border-slate-800/90 bg-slate-950/50 overflow-hidden">
            <button
              type="button"
              onClick={() => setShowAdvanced((s) => !s)}
              className="w-full px-4 py-3 flex items-center justify-between text-xs font-semibold text-slate-200 hover:bg-slate-900/50"
            >
              <span className="inline-flex items-center gap-2">
                <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
                <span>تنظیمات پیشرفته (نوع سفارش Market / Limit، لغزش، اسپرد و کارمزد)</span>
              </span>
              {showAdvanced ? (
                <ChevronUp className="w-4 h-4 text-slate-400" />
              ) : (
                <ChevronDown className="w-4 h-4 text-slate-400" />
              )}
            </button>

            {showAdvanced && (
              <div className="p-4 border-t border-slate-800/80 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1.5">نوع سفارش</label>
                  <select
                    value={orderType}
                    onChange={(e) => setOrderType(e.target.value as ProfitBotOrderType)}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="MARKET">
                      سفارش بازار (Market — اجرای فوری خرید و فروش با کنترل لغزش)
                    </option>
                    <option value="LIMIT">سفارش محدود (Limit — انتظار در دفتر سفارش)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1.5">
                    مدیریت سفارش محدود تکمیل‌نشده
                  </label>
                  <select
                    value={limitUnfilledPolicy}
                    onChange={(e) =>
                      setLimitUnfilledPolicy(e.target.value as ProfitBotLimitUnfilledPolicy)
                    }
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="KEEP_WAITING">ادامه انتظار در دفتر سفارش</option>
                    <option value="CANCEL_AND_REPRICE">لغو و قیمت‌گذاری مجدد با نرخ جدید</option>
                    <option value="STOP_BOT">لغو سفارش و توقف ربات</option>
                  </select>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1.5">تایم‌اوت سفارش محدود (ثانیه)</label>
                  <NumericInput
                    value={limitOrderTimeoutSeconds}
                    onValueChange={(raw) => {
                      const v = Number(raw);
                      if (Number.isFinite(v) && raw !== '') {
                        setLimitOrderTimeoutSeconds(Math.max(10, Math.round(v)));
                      }
                    }}
                    allowDecimal={false}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono-num"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1.5">حداکثر لغزش قیمت مجاز (٪)</label>
                  <NumericInput
                    value={maxSlippagePercent}
                    onValueChange={(raw) => {
                      const v = raw === '' || raw === '.' ? 0.05 : Number(raw);
                      if (Number.isFinite(v)) {
                        setMaxSlippagePercent(Math.max(0.05, Math.min(20, v)));
                      }
                    }}
                    allowDecimal
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono-num"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1.5">حداکثر اسپرد خرید/فروش (٪)</label>
                  <NumericInput
                    value={maxSpreadPercent}
                    onValueChange={(raw) => {
                      const v = raw === '' || raw === '.' ? 0.05 : Number(raw);
                      if (Number.isFinite(v)) {
                        setMaxSpreadPercent(Math.max(0.05, Math.min(20, v)));
                      }
                    }}
                    allowDecimal
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono-num"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block text-slate-400 mb-1.5">کارمزد صرافی (٪)</label>
                    <NumericInput
                      value={feeRatePercent}
                      onValueChange={(raw) => {
                        const v = raw === '' || raw === '.' ? 0 : Number(raw);
                        if (Number.isFinite(v)) {
                          setFeeRatePercent(Math.max(0, Math.min(5, v)));
                        }
                      }}
                      allowDecimal
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-2 text-white font-mono-num"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1.5">سایر هزینه‌ها ({quoteCurrency})</label>
                    <NumericInput
                      value={otherFeesQuote}
                      onValueChange={(raw) => {
                        const v = raw === '' || raw === '.' ? 0 : Number(raw);
                        if (Number.isFinite(v)) {
                          setOtherFeesQuote(Math.max(0, v));
                        }
                      }}
                      allowDecimal={quoteCurrency === 'USDT'}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-2 text-white font-mono-num"
                    />
                  </div>
                </div>

                <div className="md:col-span-3 flex flex-wrap items-center justify-between gap-3 pt-1">
                  <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={notifyTelegram}
                      onChange={(e) => setNotifyTelegram(e.target.checked)}
                      className="accent-cyan-400"
                    />
                    <span>ارسال گزارش خرید، فروش و هشدارهای ربات سود به ربات تلگرام</span>
                  </label>
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-400">نحوه ثبت سفارش:</span>
                    <button
                      type="button"
                      onClick={() => setExecutionConfirmationMode('AUTO')}
                      className={`px-2.5 py-1 rounded-lg border font-bold ${
                        executionConfirmationMode === 'AUTO'
                          ? 'border-emerald-500/50 bg-emerald-500/15 text-emerald-200'
                          : 'border-slate-700 bg-slate-900 text-slate-400'
                      }`}
                    >
                      اجرای خودکار
                    </button>
                    <button
                      type="button"
                      onClick={() => setExecutionConfirmationMode('MANUAL_CONFIRM')}
                      className={`px-2.5 py-1 rounded-lg border font-bold ${
                        executionConfirmationMode === 'MANUAL_CONFIRM'
                          ? 'border-amber-500/50 bg-amber-500/15 text-amber-200'
                          : 'border-slate-700 bg-slate-900 text-slate-400'
                      }`}
                    >
                      با تأیید دستی شما
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* 6. Live Nobitex Order Book & Net Profit Math Preview */}
          <div className="rounded-xl border border-cyan-500/25 bg-cyan-950/20 p-4 text-xs space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="font-semibold text-cyan-200 flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                <span>پیش‌نمایش لحظه‌ای دفتر سفارش نوبیتکس و محاسبه سود خالص</span>
              </div>
              {loadingPreview && (
                <span className="text-[11px] text-cyan-300 animate-pulse">در حال محاسبه...</span>
              )}
            </div>

            {preview ? (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pt-1">
                <div>
                  <div className="text-slate-400">قیمت خرید فوری (Ask)</div>
                  <div className="text-white font-mono-num font-semibold mt-0.5">
                    {formatQuotePrice(preview.bestAsk, preview.quoteCurrency)}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 font-mono-num">
                    فروش فوری (Bid): {formatQuotePrice(preview.bestBid, preview.quoteCurrency)} · اسپرد:{' '}
                    {preview.spreadPercent.toFixed(2)}٪
                  </div>
                </div>

                <div>
                  <div className="text-slate-400">
                    {fundingMode === 'EXISTING_ASSET' ||
                    (fundingMode === 'AUTO_PREFER_EXISTING' && existingAlloc.ok)
                      ? 'کارمزد خرید (ورود از موجودی فعلی)'
                      : 'کارمزد تخمینی خرید'}
                  </div>
                  <div className="text-amber-200 font-mono-num font-semibold mt-0.5">
                    {formatQuoteAmount(preview.buySimulation.estimatedBuyFeeQuote, preview.quoteCurrency)}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5 font-mono-num">
                    مقدار درگیر: {formatQty(preview.buySimulation.netQtyReceived)} {preview.baseAsset}
                  </div>
                </div>

                <div>
                  <div className="text-slate-400">قیمت فروش لازم برای سود هدف</div>
                  <div className="text-emerald-300 font-mono-num font-bold mt-0.5">
                    {formatQuotePrice(preview.estimatedRequiredSellPrice, preview.quoteCurrency)}
                  </div>
                  <div className="text-[11px] text-emerald-400/90 mt-0.5 font-mono-num">
                    رشد لازم: +{preview.estimatedRequiredRisePercent.toFixed(2)}٪
                  </div>
                </div>

                <div>
                  <div className="text-slate-400">عمق دفتر سفارش برای ورود</div>
                  <div
                    className={`font-semibold mt-0.5 ${
                      preview.buySimulation.canFillFull ? 'text-emerald-300' : 'text-rose-300'
                    }`}
                  >
                    {preview.buySimulation.canFillFull
                      ? 'عمق کافی است (قابل اجرا)'
                      : 'عمق سفارش کافی نیست!'}
                  </div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    لغزش تخمینی: {preview.buySimulation.slippagePercent.toFixed(2)}٪
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-slate-400">
                در حال دریافت دفتر سفارش زنده برای محاسبه دقیق کارمزد خرید و فروش...
              </div>
            )}
          </div>

          {/* Live Confirmation Guard */}
          {mode === 'live' && !demoMode && (
            <div className="rounded-xl border border-rose-500/40 bg-rose-500/10 p-3.5 text-xs space-y-2">
              <div className="font-semibold text-rose-200 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-300" />
                <span>تأییدیه اجباری معامله با سرمایه واقعی در نوبیتکس</span>
              </div>
              <label className="flex items-start gap-2 text-rose-100 cursor-pointer">
                <input
                  type="checkbox"
                  checked={confirmLive}
                  onChange={(e) => setConfirmLive(e.target.checked)}
                  className="mt-0.5 accent-rose-500"
                />
                <span>
                  تأیید می‌کنم که ربات سود با موجودی واقعی حساب نوبیتکس من معامله کند و می‌دانم که هدف سود به معنی تضمین سود نیست.
                </span>
              </label>
            </div>
          )}

          {/* Save / Start Buttons */}
          <div className="flex flex-wrap items-center justify-end gap-3 pt-2">
            <button
              type="button"
              disabled={saving}
              onClick={() => void handleSave(false)}
              className="btn-glass btn-glass-neutral px-4 py-2 rounded-lg text-xs font-medium"
            >
              {saving ? 'در حال ذخیره...' : 'ذخیره تنظیمات (آماده خرید)'}
            </button>
            <button
              type="button"
              disabled={saving}
              onClick={() => void handleSave(true)}
              className="btn-glass btn-glass-buy inline-flex items-center gap-1.5 px-5 py-2 rounded-lg text-xs font-semibold"
            >
              <Play className="w-4 h-4" />
              <span>{saving ? 'در حال شروع...' : 'ذخیره و شروع فوری ربات سود'}</span>
            </button>
          </div>
        </div>
      )}

      {/* Main Split: Independent Profit Bot Cards + Selected Bot Live Telemetry Panel */}
      <div className="grid grid-cols-1 xl:grid-cols-12 gap-5">
        {/* Profit Bot Cards List */}
        <div className="xl:col-span-5 space-y-3">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span>لیست ربات‌های سود ({profitBots.length})</span>
            <span>برای مشاهده پنل زنده روی هر کارت کلیک کنید</span>
          </div>

          {profitBots.length === 0 ? (
            <div className="glass-panel rounded-xl p-8 text-center space-y-3">
              <Coins className="w-10 h-10 text-emerald-400/70 mx-auto" />
              <div className="text-sm font-semibold text-white">
                هنوز هیچ «ربات سود» نساخته‌اید
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                روی دکمه «ساخت / تنظیم ربات سود» کلیک کنید، مبلغ ورود و سود خالص هدف را مشخص کنید تا ربات پس از کسر کارمزدها به هدف برسد.
              </p>
            </div>
          ) : (
            profitBots.map((bot) => {
              const meta = getProfitBotStatusMeta(bot.botStatus);
              const isSelected = selectedBot?.id === bot.id;
              const mkt = markets.find((m) => m.baseAsset === bot.baseAsset);
              const liveMarketPrice = mkt
                ? bot.quoteCurrency === 'IRT'
                  ? bot.activePosition
                    ? mkt.bestBuyToman || mkt.priceToman
                    : mkt.bestSellToman || mkt.priceToman
                  : bot.activePosition
                    ? mkt.bestBuyUsdt || mkt.priceUsdt
                    : mkt.bestSellUsdt || mkt.priceUsdt
                : 0;
              const currentPrice = bot.activePosition?.lastExecutableSellPrice || liveMarketPrice || 0;
              const theoreticalTargetSell =
                !bot.activePosition && currentPrice > 0
                  ? computeRequiredSellPrice(
                      (bot.entryAmount / currentPrice) * (1 - bot.feeRate),
                      bot.entryAmount,
                      bot.targetNetProfit,
                      bot.feeRate,
                      bot.otherFeesQuote
                    )
                  : 0;
              const resolvedTargetSellPrice =
                bot.targetSellPrice && bot.targetSellPrice > 0
                  ? bot.targetSellPrice
                  : bot.activePosition?.lastRequiredSellPrice || theoreticalTargetSell;

              const liveProfit = bot.activePosition
                ? bot.activePosition.lastEstimatedNetProfitQuote ?? 0
                : bot.stats.totalNetProfitQuote;

              const targetProgress = computeProfitBotTargetProgress({
                actualBuyAvgPrice: bot.activePosition?.actualBuyAvgPrice,
                currentPrice,
                targetSellPrice: resolvedTargetSellPrice,
                currentNetProfitQuote: liveProfit,
                targetNetProfit: bot.targetNetProfit,
                hasActivePosition: Boolean(bot.activePosition),
                isSellCompleted: bot.botStatus === 'SELL_FILLED',
              });

              const progressPct = bot.activePosition
                ? bot.activePosition.lastProgressPercent ?? targetProgress.profitProgressPercent
                : targetProgress.profitProgressPercent;

              return (
                <div
                  key={bot.id}
                  onClick={() => setSelectedBotId(bot.id)}
                  className={`glass-panel rounded-xl p-4 cursor-pointer transition border ${
                    isSelected
                      ? 'border-emerald-400/60 shadow-lg shadow-emerald-950/30'
                      : 'border-slate-800/90 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className="w-9 h-9 rounded-lg bg-emerald-500/15 border border-emerald-500/35 flex items-center justify-center shrink-0">
                        <TrendingUp className="w-4 h-4 text-emerald-300" />
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-sm text-white truncate">
                          {bot.name}
                        </div>
                        <div className="flex flex-wrap items-center gap-1.5 mt-0.5 text-[11px]">
                          <span className="font-mono-num text-cyan-300 font-semibold">
                            {bot.symbol}
                          </span>
                          <span
                            className={`px-1.5 py-0.5 rounded border ${
                              bot.mode === 'live'
                                ? 'bg-rose-500/15 border-rose-500/35 text-rose-200'
                                : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-200'
                            }`}
                          >
                            {bot.mode === 'live' ? 'واقعی' : 'دمو'}
                          </span>
                          {(bot.fundingMode === 'EXISTING_ASSET' ||
                            bot.fundingMode === 'AUTO_PREFER_EXISTING' ||
                            bot.activePosition?.fromExistingBalance) && (
                            <span className="px-1.5 py-0.5 rounded border bg-indigo-500/15 border-indigo-500/35 text-indigo-200">
                              {bot.fundingMode === 'EXISTING_ASSET'
                                ? `موجودی فعلی (${bot.existingBalancePercent ?? 100}٪)`
                                : bot.activePosition?.fromExistingBalance
                                  ? 'ورود از موجودی فعلی'
                                  : `اول موجودی (${bot.existingBalancePercent ?? 100}٪)`}
                            </span>
                          )}
                          <span className="text-slate-400">
                            هر {bot.pollIntervalSeconds} ثانیه
                          </span>
                        </div>
                      </div>
                    </div>

                    <span
                      className={`px-2 py-0.5 rounded-md border text-[11px] font-medium shrink-0 ${getStatusBadgeClass(
                        meta.tone
                      )}`}
                    >
                      {meta.labelFa}
                    </span>
                  </div>

                  {/* Card Metrics: Target Profit vs Current Net Profit */}
                  <div className="grid grid-cols-2 gap-2.5 mt-3 text-xs">
                    <div className="rounded-lg bg-slate-950/70 border border-slate-800/80 px-2.5 py-2">
                      <div className="text-[11px] text-slate-400">سود هدف</div>
                      <div className="font-mono-num font-semibold text-emerald-300 mt-0.5">
                        +{formatQuoteAmount(bot.targetNetProfit, bot.quoteCurrency)}
                      </div>
                    </div>
                    <div className="rounded-lg bg-slate-950/70 border border-slate-800/80 px-2.5 py-2">
                      <div className="text-[11px] text-slate-400">
                        {bot.activePosition ? 'سود خالص فعلی' : 'سود خالص کل'}
                      </div>
                      <div
                        className={`font-mono-num font-semibold mt-0.5 ${
                          liveProfit >= 0 ? 'text-emerald-300' : 'text-rose-300'
                        }`}
                      >
                        {formatSignedQuote(liveProfit, bot.quoteCurrency)}
                      </div>
                    </div>
                  </div>

                  {/* Active Target Sell Price Distance & Realized Profit Progress Bar */}
                  {bot.isActive || bot.activePosition ? (
                    <div className="mt-2.5 rounded-lg bg-slate-950/70 border border-slate-800/90 p-2.5 space-y-1.5">
                      <div className="flex flex-wrap items-center justify-between gap-1 text-[11px]">
                        <span className="text-slate-300 font-medium">
                          فاصله تا فروش هدف
                        </span>
                        <div className="flex items-center gap-2 font-mono-num">
                          <span
                            className={`font-semibold ${
                              targetProgress.isPriceReached
                                ? 'text-emerald-300'
                                : 'text-cyan-300'
                            }`}
                          >
                            {resolvedTargetSellPrice > 0 && currentPrice > 0
                              ? targetProgress.isPriceReached
                                ? '۰.۰۰٪ (در هدف فروش)'
                                : `${targetProgress.distanceToTargetPercent.toFixed(2)}٪ مانده`
                              : 'در حال استعلام'}
                          </span>
                          <span className="text-slate-600">|</span>
                          <span className="text-emerald-300 font-bold">
                            سود: {progressPct.toFixed(1)}٪
                          </span>
                        </div>
                      </div>

                      <div className="h-2.5 w-full rounded-full bg-slate-900 border border-slate-800 overflow-hidden p-0.5">
                        <div
                          className={`h-full rounded-full transition-all duration-500 ${
                            targetProgress.isPriceReached || progressPct >= 100
                              ? 'bg-gradient-to-r from-emerald-400 to-teal-300'
                              : bot.activePosition && liveProfit < 0
                                ? 'bg-gradient-to-r from-amber-500 to-cyan-400'
                                : 'bg-gradient-to-r from-cyan-400 to-emerald-400'
                          }`}
                          style={{
                            width: `${Math.min(
                              100,
                              Math.max(bot.activePosition ? 4 : 2, targetProgress.visualBarPercent)
                            )}%`,
                          }}
                        />
                      </div>

                      <div className="flex flex-wrap items-center justify-between gap-1 text-[10px] text-slate-400 font-mono-num">
                        <span>
                          فعلی:{' '}
                          <strong className="text-slate-200">
                            {currentPrice > 0
                              ? formatQuotePrice(currentPrice, bot.quoteCurrency)
                              : '—'}
                          </strong>
                        </span>
                        <span>
                          فروش هدف:{' '}
                          <strong className="text-emerald-300">
                            {resolvedTargetSellPrice > 0
                              ? formatQuotePrice(resolvedTargetSellPrice, bot.quoteCurrency)
                              : '—'}
                          </strong>
                        </span>
                      </div>

                      {bot.stats.completedCycles > 0 && (
                        <div className="flex items-center justify-between text-[10px] text-emerald-300/90 pt-0.5 border-t border-slate-800/60">
                          <span>سود محقق‌شده ({bot.stats.completedCycles} چرخه):</span>
                          <span className="font-mono-num font-semibold">
                            {formatSignedQuote(bot.stats.totalNetProfitQuote, bot.quoteCurrency)}
                          </span>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="mt-2.5">
                      <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                        <span>پیشرفت سود</span>
                        <span className="font-mono-num text-slate-200">{progressPct.toFixed(1)}٪</span>
                      </div>
                      <div className="h-1.5 w-full rounded-full bg-slate-900 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-emerald-400 transition-all duration-300"
                          style={{ width: `${Math.min(100, Math.max(0, progressPct))}%` }}
                        />
                      </div>
                    </div>
                  )}

                  {/* Card Action Buttons */}
                  <div
                    className="flex flex-wrap items-center gap-1.5 mt-3 pt-3 border-t border-slate-800/70"
                    onClick={(e) => e.stopPropagation()}
                  >
                    {bot.isActive ? (
                      <button
                        type="button"
                        disabled={busyBotId === bot.id}
                        onClick={async () => {
                          setBusyBotId(bot.id);
                          try {
                            await onStopProfitBot(bot.id);
                          } finally {
                            setBusyBotId(null);
                          }
                        }}
                        className="btn-glass btn-glass-sell inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium"
                      >
                        <Square className="w-3 h-3" />
                        <span>توقف</span>
                      </button>
                    ) : pendingLiveStartId === bot.id ? (
                      <div className="flex items-center gap-1.5 bg-rose-500/15 border border-rose-500/40 rounded-lg px-2 py-1 text-[11px]">
                        <span className="text-rose-200">تأیید اولین معامله واقعی؟</span>
                        <button
                          type="button"
                          onClick={async () => {
                            setBusyBotId(bot.id);
                            try {
                              await onStartProfitBot(bot.id, true);
                              setPendingLiveStartId(null);
                            } finally {
                              setBusyBotId(null);
                            }
                          }}
                          className="px-2 py-0.5 rounded bg-emerald-500/30 text-emerald-100 font-semibold"
                        >
                          تأیید و شروع
                        </button>
                        <button
                          type="button"
                          onClick={() => setPendingLiveStartId(null)}
                          className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300"
                        >
                          لغو
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        disabled={busyBotId === bot.id}
                        onClick={async () => {
                          if (!isAuthenticated) {
                            onRequireAuth();
                            return;
                          }
                          if (bot.mode === 'live' && !bot.startedAt && !demoMode) {
                            setPendingLiveStartId(bot.id);
                            return;
                          }
                          setBusyBotId(bot.id);
                          try {
                            await onStartProfitBot(bot.id);
                          } catch (err) {
                            setFeedback({
                              type: 'err',
                              text: err instanceof Error ? err.message : 'خطا در شروع ربات سود',
                            });
                          } finally {
                            setBusyBotId(null);
                          }
                        }}
                        className="btn-glass btn-glass-buy inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium"
                      >
                        <Play className="w-3 h-3" />
                        <span>شروع</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => loadBotIntoForm(bot)}
                      className="btn-glass btn-glass-neutral inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs"
                    >
                      <Edit3 className="w-3 h-3" />
                      <span>تنظیم ربات</span>
                    </button>

                    <button
                      type="button"
                      disabled={busyBotId === bot.id || !bot.isActive}
                      onClick={async () => {
                        setBusyBotId(bot.id);
                        try {
                          await onEvaluateProfitBot(bot.id);
                        } finally {
                          setBusyBotId(null);
                        }
                      }}
                      className="btn-glass btn-glass-sync inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs disabled:opacity-40"
                    >
                      <RefreshCw className="w-3 h-3 text-cyan-400" />
                      <span>بررسی الان</span>
                    </button>

                    <button
                      type="button"
                      disabled={busyBotId === bot.id}
                      onClick={async () => {
                        setBusyBotId(bot.id);
                        try {
                          await onDeleteProfitBot(bot.id);
                        } finally {
                          setBusyBotId(null);
                        }
                      }}
                      className="btn-glass btn-glass-sell p-1.5 rounded-lg mr-auto"
                      title="حذف ربات سود"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Dedicated Live Telemetry Panel (Section 4) */}
        <div className="xl:col-span-7">
          {selectedBot && telemetry && selectedStatusMeta ? (
            <div className="glass-panel rounded-xl p-5 border border-slate-800/90 space-y-4">
              <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800/80 pb-3.5">
                <div>
                  <div className="flex flex-wrap items-center gap-2">
                    <h3 className="text-base font-bold text-white">{selectedBot.name}</h3>
                    <span
                      className={`px-2.5 py-0.5 rounded-md border text-xs font-medium ${getStatusBadgeClass(
                        selectedStatusMeta.tone
                      )}`}
                    >
                      {selectedStatusMeta.labelFa}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">{selectedBot.lastStatusReason}</p>
                </div>

                {selectedBot.activePosition && (
                  <button
                    type="button"
                    disabled={busyBotId === selectedBot.id}
                    onClick={async () => {
                      setBusyBotId(selectedBot.id);
                      try {
                        await onManualSellProfitBot(selectedBot.id);
                      } catch (err) {
                        setFeedback({
                          type: 'err',
                          text: err instanceof Error ? err.message : 'فروش دستی ناموفق بود',
                        });
                      } finally {
                        setBusyBotId(null);
                      }
                    }}
                    className="btn-glass btn-glass-amber inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0"
                  >
                    <Coins className="w-3.5 h-3.5" />
                    <span>فروش دستی با نرخ دفتر سفارش</span>
                  </button>
                )}
              </div>

              {/* Depth Warning if insufficient */}
              {telemetry.hasDepthIssue && (
                <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 px-3.5 py-2.5 text-xs text-amber-200 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 text-amber-300 shrink-0" />
                  <span>
                    عمق دفتر سفارش (Bids) در حال حاضر برای فروش کل دارایی کافی نیست؛ ربات سود فرضی را قطعی اعلام نمی‌کند و منتظر نقدینگی کافی می‌ماند.
                  </span>
                </div>
              )}

              {/* Visual Progress Bar to Target Net Profit */}
              <div className="rounded-xl bg-slate-950/75 border border-emerald-500/25 p-4 space-y-2.5">
                <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                  <span className="text-slate-300 font-medium">
                    نوار پیشرفت تا سود خالص هدف
                  </span>
                  <div className="flex items-center gap-3 font-mono-num">
                    <span
                      className={`font-bold ${
                        telemetry.currentNetProfit >= 0 ? 'text-emerald-300' : 'text-rose-300'
                      }`}
                    >
                      {formatSignedQuote(telemetry.currentNetProfit, selectedBot.quoteCurrency)}
                    </span>
                    <span className="text-slate-500">/</span>
                    <span className="text-emerald-200 font-semibold">
                      +{formatQuoteAmount(selectedBot.targetNetProfit, selectedBot.quoteCurrency)}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 font-bold">
                      {telemetry.progressPercent.toFixed(1)}٪
                    </span>
                  </div>
                </div>
                <div className="h-3 w-full rounded-full bg-slate-900 border border-slate-800 overflow-hidden p-0.5">
                  <div
                    className={`h-full rounded-full transition-all duration-500 ${
                      telemetry.progressPercent >= 100
                        ? 'bg-gradient-to-r from-emerald-400 to-teal-300'
                        : telemetry.currentNetProfit < 0
                          ? 'bg-gradient-to-r from-rose-500 to-amber-500'
                          : 'bg-gradient-to-r from-cyan-500 to-emerald-400'
                    }`}
                    style={{
                      width: `${Math.min(100, Math.max(2, telemetry.progressPercent))}%`,
                    }}
                  />
                </div>
                {telemetry.pos?.lastRequiredSellPrice ? (
                  <div className="flex flex-wrap items-center justify-between text-[11px] text-slate-400 pt-0.5 gap-2">
                    <span>
                      {selectedBot.targetSellPrice && selectedBot.targetSellPrice > 0
                        ? 'قیمت هدف فروش تعیین‌شده:'
                        : 'قیمت فروش مورد نیاز برای تحقق هدف پس از کسر کارمزدها:'}{' '}
                      <strong className="text-cyan-300 font-mono-num">
                        {formatQuotePrice(
                          telemetry.pos.lastRequiredSellPrice,
                          selectedBot.quoteCurrency
                        )}
                      </strong>
                      {telemetry.targetProgress.targetSellPrice > 0 &&
                        telemetry.targetProgress.currentPrice > 0 && (
                          <span className="mr-2 font-mono-num text-emerald-300">
                            (فاصله تا هدف:{' '}
                            {telemetry.targetProgress.isPriceReached
                              ? '۰.۰۰٪'
                              : `${telemetry.targetProgress.distanceToTargetPercent.toFixed(2)}٪`}
                            )
                          </span>
                        )}
                    </span>
                    {telemetry.pos && (
                      <span className="font-mono-num">
                        مقدار خالص تحت مدیریت: {formatQty(telemetry.pos.netOwnedQty)}{' '}
                        {selectedBot.baseAsset}
                      </span>
                    )}
                  </div>
                ) : selectedBot.isActive &&
                  !telemetry.pos &&
                  (selectedBot.reentryTargetPrice || selectedBot.stats.lastBuyPrice) ? (
                  <div className="flex flex-wrap items-center justify-between text-[11px] text-cyan-200/90 pt-0.5 gap-2">
                    <span>
                      هدف قیمت خرید مجدد در تکرار چرخه:{' '}
                      <strong className="text-cyan-300 font-mono-num">
                        {formatQuotePrice(
                          selectedBot.reentryTargetPrice || selectedBot.stats.lastBuyPrice || 0,
                          selectedBot.quoteCurrency
                        )}
                      </strong>
                    </span>
                    <span>چرخه جدید به محض بازگشت قیمت به این سطح آغاز می‌شود</span>
                  </div>
                ) : null}
              </div>

              {/* All 12 Required Telemetry Fields */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400">۱. نام ارز انتخاب‌شده</div>
                  <div className="text-white font-semibold mt-1">
                    {markets.find((m) => m.baseAsset === selectedBot.baseAsset)?.persianName ||
                      selectedBot.baseAsset}{' '}
                    <span className="font-mono-num text-cyan-300">({selectedBot.symbol})</span>
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400">۲. مبلغ سرمایه‌گذاری</div>
                  <div className="text-white font-mono-num font-semibold mt-1">
                    {formatQuoteAmount(
                      telemetry.pos?.totalBuyCostQuote || selectedBot.entryAmount,
                      selectedBot.quoteCurrency
                    )}
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400">
                    ۳. {telemetry.pos?.fromExistingBalance ? 'قیمت مبنا (موجودی فعلی)' : 'قیمت واقعی خرید'}
                  </div>
                  <div className="text-white font-mono-num font-semibold mt-1">
                    {telemetry.pos
                      ? formatQuotePrice(
                          telemetry.pos.actualBuyAvgPrice,
                          selectedBot.quoteCurrency
                        )
                      : 'هنوز ورود انجام نشده'}
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400">۴. قیمت فعلی قابل فروش</div>
                  <div className="text-cyan-300 font-mono-num font-semibold mt-1">
                    {telemetry.currentSellPrice > 0
                      ? formatQuotePrice(telemetry.currentSellPrice, selectedBot.quoteCurrency)
                      : '—'}
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400">۵. کارمزد خرید</div>
                  <div className="text-amber-200 font-mono-num font-semibold mt-1">
                    {formatQuoteAmount(telemetry.buyFee, selectedBot.quoteCurrency)}
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400">۶. کارمزد تخمینی فروش</div>
                  <div className="text-amber-200 font-mono-num font-semibold mt-1">
                    {formatQuoteAmount(telemetry.estSellFee, selectedBot.quoteCurrency)}
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-emerald-500/25 p-3">
                  <div className="text-slate-400">۷. سود خالص فعلی</div>
                  <div
                    className={`font-mono-num font-bold mt-1 ${
                      telemetry.currentNetProfit >= 0 ? 'text-emerald-300' : 'text-rose-300'
                    }`}
                  >
                    {formatSignedQuote(telemetry.currentNetProfit, selectedBot.quoteCurrency)}
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-emerald-500/25 p-3">
                  <div className="text-slate-400">۸. سود خالص هدف</div>
                  <div className="text-emerald-300 font-mono-num font-bold mt-1">
                    +{formatQuoteAmount(selectedBot.targetNetProfit, selectedBot.quoteCurrency)}
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400">۹. درصد پیشرفت تا هدف</div>
                  <div className="text-white font-mono-num font-bold mt-1">
                    {telemetry.progressPercent.toFixed(1)}٪
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    <span>۱۰. مدت زمان سپری‌شده</span>
                  </div>
                  <div className="text-slate-200 font-mono-num font-semibold mt-1">
                    {telemetry.elapsedMs > 0 ? formatDurationFa(telemetry.elapsedMs) : 'در انتظار شروع'}
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400">۱۱. فاصله بررسی بازار</div>
                  <div className="text-slate-200 font-semibold mt-1">
                    هر {selectedBot.pollIntervalSeconds} ثانیه
                  </div>
                </div>

                <div className="rounded-lg bg-slate-950/60 border border-slate-800/80 p-3">
                  <div className="text-slate-400">۱۲. وضعیت فعلی ربات</div>
                  <div className="text-cyan-200 font-semibold mt-1">
                    {selectedStatusMeta.labelFa}
                  </div>
                </div>
              </div>

              {/* Exact Accounting Formula Note */}
              <div className="rounded-lg bg-slate-950/60 border border-slate-800/70 px-3.5 py-2.5 text-[11px] text-slate-400 flex flex-wrap items-center justify-between gap-2">
                <span>
                  فرمول دقیق: <strong className="text-slate-200">سود خالص</strong> = مبلغ دریافتی فروش − هزینه واقعی خرید (شامل کارمزد خرید) − کارمزد فروش − سایر هزینه‌ها
                </span>
                <span className="font-mono-num text-slate-300">
                  معامله امروز: {selectedBot.dailyStats.tradesCount}/{selectedBot.maxDailyTrades}
                </span>
              </div>
            </div>
          ) : (
            <div className="glass-panel rounded-xl p-10 text-center text-xs text-slate-400">
              یک ربات سود را از سمت راست انتخاب کنید یا ربات سود جدیدی بسازید تا داشبورد لحظه‌ای و نوار پیشرفت تا سود هدف اینجا نمایش داده شود.
            </div>
          )}
        </div>
      </div>

      {/* Independent Cycles History & Decision Logs */}
      <div className="glass-panel rounded-xl overflow-hidden">
        <div className="px-5 py-3 border-b border-slate-800/90 bg-[#060A14]/75 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-white">
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>تاریخچه معاملات و گزارش تصمیم‌های ربات سود</span>
          </div>
          <div className="flex items-center gap-1.5 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              type="button"
              onClick={() => setHistoryTab('CYCLES')}
              className={`px-3 py-1 rounded-md font-medium ${
                historyTab === 'CYCLES'
                  ? 'bg-emerald-500/20 text-emerald-200'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              معاملات تکمیل‌شده ({cycles.length})
            </button>
            <button
              type="button"
              onClick={() => setHistoryTab('LOGS')}
              className={`px-3 py-1 rounded-md font-medium ${
                historyTab === 'LOGS'
                  ? 'bg-cyan-500/20 text-cyan-200'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              گزارش تصمیم‌ها ({logs.length})
            </button>
          </div>
        </div>

        {historyTab === 'CYCLES' ? (
          <div className="overflow-x-auto">
            {cycles.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                هنوز معامله تکمیل‌شده‌ای در تاریخچه ربات سود ثبت نشده است.
              </div>
            ) : (
              <table className="w-full text-xs text-right">
                <thead className="bg-slate-950/60 text-slate-400 border-b border-slate-800/80">
                  <tr>
                    <th className="py-2.5 px-4 font-medium">بازار / چرخه</th>
                    <th className="py-2.5 px-4 font-medium">میانگین خرید</th>
                    <th className="py-2.5 px-4 font-medium">میانگین فروش</th>
                    <th className="py-2.5 px-4 font-medium">کل کارمزدها</th>
                    <th className="py-2.5 px-4 font-medium">سود خالص نهایی</th>
                    <th className="py-2.5 px-4 font-medium">سود هدف</th>
                    <th className="py-2.5 px-4 font-medium">زمان ثبت</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {cycles.map((c) => (
                    <tr key={c.id} className="hover:bg-slate-900/40">
                      <td className="py-2.5 px-4">
                        <div className="font-mono-num font-semibold text-white">
                          {c.symbol} <span className="text-slate-400">#{c.cycleIndex}</span>
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {c.mode === 'live' ? 'واقعی' : 'دمو'} · {c.orderType}
                        </div>
                      </td>
                      <td className="py-2.5 px-4 font-mono-num text-slate-200">
                        {formatQuotePrice(c.actualBuyAvgPrice, c.quoteCurrency)}
                      </td>
                      <td className="py-2.5 px-4 font-mono-num text-cyan-200">
                        {formatQuotePrice(c.actualSellAvgPrice, c.quoteCurrency)}
                      </td>
                      <td className="py-2.5 px-4 font-mono-num text-amber-200">
                        {formatQuoteAmount(c.buyFeeQuote + c.sellFeeQuote + c.otherFeesQuote, c.quoteCurrency)}
                      </td>
                      <td
                        className={`py-2.5 px-4 font-mono-num font-bold ${
                          c.finalNetProfitQuote >= 0 ? 'text-emerald-300' : 'text-rose-300'
                        }`}
                      >
                        {formatSignedQuote(c.finalNetProfitQuote, c.quoteCurrency)}
                      </td>
                      <td className="py-2.5 px-4 font-mono-num text-slate-300">
                        +{formatQuoteAmount(c.targetNetProfitQuote, c.quoteCurrency)}
                      </td>
                      <td className="py-2.5 px-4 font-mono-num text-slate-400" dir="ltr">
                        {formatDateTimeShort(c.completedAt)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
          </div>
        ) : (
          <div className="divide-y divide-slate-800/60 max-h-72 overflow-y-auto text-xs">
            {logs.length === 0 ? (
              <div className="p-8 text-center text-slate-500">
                هنوز گزارشی در لاگ تصمیم‌های ربات سود ثبت نشده است.
              </div>
            ) : (
              logs.map((l) => {
                const st = getProfitBotStatusMeta(l.status);
                return (
                  <div
                    key={l.id}
                    className="px-5 py-2.5 flex flex-wrap items-center justify-between gap-2"
                  >
                    <div className="flex items-center gap-2 flex-wrap">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                      <span
                        className={`px-1.5 py-0.5 rounded border text-[10px] ${getStatusBadgeClass(
                          st.tone
                        )}`}
                      >
                        {st.labelFa}
                      </span>
                      <span className="text-slate-200">{l.message}</span>
                    </div>
                    <span className="text-slate-500 font-mono-num" dir="ltr">
                      {formatDateTimeShort(l.timestamp)}
                    </span>
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>
    </div>
  );
};
