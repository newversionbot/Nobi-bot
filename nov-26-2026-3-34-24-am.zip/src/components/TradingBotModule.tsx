import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  BarChart3,
  BookOpen,
  Bot,
  Coins,
  Cpu,
  Grid,
  Hand,
  Layers,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Send,
  Shield,
  SlidersHorizontal,
  Sparkles,
  Target,
  Trash2,
  TrendingUp,
} from 'lucide-react';
import { AiBotManagerPage } from './AiBotManagerPage';
import { AiCycleProPage } from './AiCycleProPage';
import { BotEducationModal, type GuideBotTopic } from './BotEducationModal';
import { CoinSearchSelect } from './CoinSearchSelect';
import { DcaBotPage } from './DcaBotPage';
import { FixedPriceAutoTrader } from './FixedPriceAutoTrader';
import { GridBotPage } from './GridBotPage';
import { NumericInput } from './NumericInput';
import { ProfitBotModule } from './ProfitBotModule';
import { UnifiedBotsDashboardPage } from './UnifiedBotsDashboardPage';
import type {
  AiCycleProCapitalUsageMode,
  AiCycleProConfig,
  AiCycleProCycleRecord,
  AiCycleProLog,
  AiCycleProMarketPreview,
  AiManagerAnalysis,
  BacktestResult,
  BotExecutionConfirmationMode,
  BotExecutionLog,
  BotFundingMode,
  BotStrategyConfig,
  BotType,
  DcaBotConfig,
  ExecutionMode,
  GridBotConfig,
  PendingBotConfirmation,
  ProfitBotConfig,
  ProfitBotCycleRecord,
  ProfitBotDecisionLog,
  ProfitBotMarketPreview,
  QuoteCurrency,
  RuleIndicatorType,
  SharedBotRiskSettings,
  SpotBalance,
  StrategyRule,
  StrategyStyleMode,
  TakeProfitTarget,
  TelegramBotSummary,
  Timeframe,
  UnifiedBotsDashboardSummary,
  UnifiedMarketTicker,
} from '../types/trading';
import {
  formatDateTimeShort,
  formatPercent,
  formatPrice,
  formatQty,
  formatQuoteAmount,
  formatQuotePrice,
  formatToman,
} from '../utils/format';
import {
  computeExistingBalanceAllocation,
  getMinimumOrderNotional,
} from '../utils/profitBotMath';

export type HubPageId =
  | 'HUB'
  | 'AI_CYCLE_PRO'
  | 'PROFIT_BOT'
  | 'FIXED_PRICE'
  | 'GRID'
  | 'DCA'
  | 'STRATEGY'
  | 'AI_MANAGER'
  | 'UNIFIED_DASHBOARD';

interface TradingBotModuleProps {
  defaultBaseAsset: string;
  defaultQuoteCurrency: QuoteCurrency;
  onQuoteCurrencyChange?: (qc: QuoteCurrency) => void;
  markets: UnifiedMarketTicker[];
  balances?: SpotBalance[];
  usdtTomanRate: number;
  bots: BotStrategyConfig[];
  logs: BotExecutionLog[];
  hasExchangeKeys: boolean;
  isAuthenticated: boolean;
  onRequireAuth: () => void;
  onCreateBot: (payload: Record<string, unknown>) => Promise<void>;
  onToggleBotStatus: (botId: string, nextStatus: 'RUNNING' | 'PAUSED') => Promise<void>;
  onToggleBotMode: (
    botId: string,
    nextMode: ExecutionMode,
    confirmLive?: boolean
  ) => Promise<void>;
  onEvaluateBotNow: (botId: string) => Promise<void>;
  onDeleteBot: (botId: string) => Promise<void>;
  onRunBacktest: (payload: Record<string, unknown>) => Promise<BacktestResult>;
  telegram?: TelegramBotSummary;
  onToggleBotTelegram?: (botId: string, notifyTelegram: boolean) => Promise<void>;
  onSendBotReportToTelegram?: (
    botId?: string
  ) => Promise<{ title?: string; preview?: string } | void>;
  onOpenTelegramSettings?: () => void;
  onUpdateFixedTargets?: (
    botId: string,
    updates: {
      targetBuyPrice?: number;
      targetSellPrice: number;
      orderAmount?: number;
      repeatCycle?: boolean;
      maxCycles?: number | null;
      pollIntervalSeconds?: number;
      fundingMode?: BotFundingMode;
      existingBalancePercent?: number;
    }
  ) => Promise<void>;
  requestedMode?:
    | 'HUB'
    | 'AI_CYCLE_PRO'
    | 'PROFIT_BOT'
    | 'BEGINNER'
    | 'FIXED_PRICE'
    | 'ADVANCED'
    | 'GRID'
    | 'DCA'
    | 'AI_MANAGER'
    | 'UNIFIED_DASHBOARD';
  requestedModeNonce?: number;
  demoMode?: boolean;
  aiCycleProBots?: AiCycleProConfig[];
  aiCycleProCycles?: AiCycleProCycleRecord[];
  aiCycleProLogs?: AiCycleProLog[];
  onCreateAiCycleProBot?: (payload: Record<string, unknown>) => Promise<void>;
  onUpdateAiCycleProBot?: (botId: string, payload: Record<string, unknown>) => Promise<void>;
  onStartAiCycleProBot?: (botId: string, confirmLive?: boolean) => Promise<void>;
  onStopAiCycleProBot?: (botId: string) => Promise<void>;
  onEvaluateAiCycleProBot?: (botId: string) => Promise<void>;
  onManualSellAiCycleProBot?: (botId: string) => Promise<void>;
  onDeleteAiCycleProBot?: (botId: string) => Promise<void>;
  onPreviewAiCycleProMarket?: (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    capitalAmount: number;
    capitalUsageMode: AiCycleProCapitalUsageMode;
    capitalPortionPercent: number;
    minTargetNetProfitPercent: number;
    stopLossPercent: number;
    maxSlippagePercent: number;
    maxSpreadPercent: number;
  }) => Promise<AiCycleProMarketPreview>;
  profitBots?: ProfitBotConfig[];
  profitBotCycles?: ProfitBotCycleRecord[];
  profitBotLogs?: ProfitBotDecisionLog[];
  onCreateProfitBot?: (payload: Record<string, unknown>) => Promise<void>;
  onUpdateProfitBot?: (botId: string, payload: Record<string, unknown>) => Promise<void>;
  onStartProfitBot?: (botId: string, confirmLive?: boolean) => Promise<void>;
  onStopProfitBot?: (botId: string) => Promise<void>;
  onEvaluateProfitBot?: (botId: string) => Promise<void>;
  onManualSellProfitBot?: (botId: string) => Promise<void>;
  onDeleteProfitBot?: (botId: string) => Promise<void>;
  onFetchProfitBotPreview?: (params: {
    symbol: string;
    entryAmount: number;
    targetNetProfit: number;
    feeRate: number;
    otherFeesQuote: number;
    fundingMode?: BotFundingMode;
    existingBalancePercent?: number;
    existingQty?: number;
    existingEntryPrice?: number;
  }) => Promise<ProfitBotMarketPreview>;
  // New smart-bot props
  gridBots?: GridBotConfig[];
  dcaBots?: DcaBotConfig[];
  riskSettings?: SharedBotRiskSettings;
  pendingConfirmations?: PendingBotConfirmation[];
  aiManagerReport?: AiManagerAnalysis | null;
  unifiedDashboard?: UnifiedBotsDashboardSummary | null;
  onCreateGridBot?: (payload: Record<string, unknown>) => Promise<void>;
  onStartGridBot?: (botId: string, confirmLive?: boolean) => Promise<void>;
  onStopGridBot?: (botId: string) => Promise<void>;
  onEvaluateGridBot?: (botId: string) => Promise<void>;
  onDeleteGridBot?: (botId: string) => Promise<void>;
  onCreateDcaBot?: (payload: Record<string, unknown>) => Promise<void>;
  onUpdateDcaBot?: (botId: string, payload: Record<string, unknown>) => Promise<void>;
  onStartDcaBot?: (botId: string, confirmLive?: boolean) => Promise<void>;
  onStopDcaBot?: (botId: string) => Promise<void>;
  onEvaluateDcaBot?: (botId: string) => Promise<void>;
  onDeleteDcaBot?: (botId: string) => Promise<void>;
  onUpdateRiskSettings?: (updates: Partial<SharedBotRiskSettings>) => Promise<void>;
  onToggleKillSwitch?: (active: boolean) => Promise<void>;
  onResolveConfirmation?: (
    conf: PendingBotConfirmation,
    decision: 'APPROVE' | 'REJECT'
  ) => Promise<void>;
  onRunAiManagerAnalysis?: () => Promise<void>;
}

const DEFAULT_RISK_SETTINGS: SharedBotRiskSettings = {
  totalBotsBudgetIrt: 100_000_000,
  totalBotsBudgetUsdt: 2000,
  maxPerBotCapitalIrt: 35_000_000,
  maxPerBotCapitalUsdt: 1500,
  maxDailyLossIrt: 5_000_000,
  maxDailyLossUsdt: 100,
  maxTotalLossIrt: 20_000_000,
  maxTotalLossUsdt: 400,
  enableSymbolConflictLock: true,
  allowAiAdvisoryOnly: true,
  killSwitchActive: false,
  updatedAt: 0,
};

const EMPTY_DASHBOARD: UnifiedBotsDashboardSummary = {
  totalBudgetIrt: 100_000_000,
  totalBudgetUsdt: 2000,
  committedCapitalIrt: 0,
  committedCapitalUsdt: 0,
  freeBudgetIrt: 100_000_000,
  freeBudgetUsdt: 2000,
  realizedPnlDailyIrt: 0,
  realizedPnlWeeklyIrt: 0,
  realizedPnlMonthlyIrt: 0,
  unrealizedPnlIrt: 0,
  totalFeesPaidIrt: 0,
  realizedPnlDailyUsdt: 0,
  unrealizedPnlUsdt: 0,
  totalFeesPaidUsdt: 0,
  openPositionsCount: 0,
  closedTradesCount: 0,
  overallWinRatePercent: 0,
  avgPnlPerTradeIrt: 0,
  bestBot: null,
  worstBot: null,
  activeConflictSymbols: [],
  pendingConfirmationsCount: 0,
  rows: [],
};

const RULE_LABELS: Record<RuleIndicatorType, string> = {
  RSI_OVERSOLD: 'RSI کمتر از حد اشباع فروش',
  RSI_OVERBOUGHT: 'RSI بیشتر از حد اشباع خرید',
  EMA_GOLDEN_CROSS: 'تقاطع صعودی EMA (سریع > کند)',
  EMA_DEATH_CROSS: 'تقاطع نزولی EMA (سریع < کند)',
  MACD_BULLISH_CROSS: 'کراس صعودی MACD',
  MACD_BEARISH_CROSS: 'کراس نزولی MACD',
  BB_LOWER_TOUCH: 'برخورد قیمت به باند پایینی بولینگر',
  BB_UPPER_TOUCH: 'برخورد قیمت به باند بالایی بولینگر',
  VOLUME_SPIKE: 'جهش غیرعادی حجم معاملات',
  BREAKOUT_RESISTANCE: 'شکست مقاومت (Breakout صعودی)',
  BREAKDOWN_SUPPORT: 'شکست حمایت (Breakdown نزولی)',
  TREND_ALIGNMENT: 'هم‌جهتی روند EMA20 و EMA50',
  VOLATILITY_FILTER: 'فیلتر تعادل نوسان بازار (ATR%)',
  FIXED_BUY_PRICE: 'خرید خودکار با رسیدن به قیمت هدف',
  FIXED_SELL_PRICE: 'فروش خودکار با رسیدن به قیمت هدف',
};

interface SimpleStrategyCard {
  id: string;
  title: string;
  friendlyDesc: string;
  bestFor: string;
  timeframe: Timeframe;
  style: StrategyStyleMode;
  entryRules: StrategyRule[];
  exitRules: StrategyRule[];
  logic: 'AND' | 'OR';
}

const SIMPLE_STRATEGIES: SimpleStrategyCard[] = [
  {
    id: 'dip-buyer',
    title: 'شکار کف و فروش در سود',
    friendlyDesc:
      'وقتی ارز به خاطر هیجان فروش بیش از حد ارزان شد می‌خرد و وقتی قیمت برگشت بالا، خودکار می‌فروشد.',
    bestFor: 'مناسب نوسان‌های روزانه و برگشت قیمت',
    timeframe: '15m',
    style: 'DAY_TRADING',
    logic: 'AND',
    entryRules: [
      {
        id: 's1-e1',
        type: 'RSI_OVERSOLD',
        action: 'BUY',
        enabled: true,
        params: { period: 14, threshold: 35 },
      },
    ],
    exitRules: [
      {
        id: 's1-x1',
        type: 'RSI_OVERBOUGHT',
        action: 'SELL',
        enabled: true,
        params: { period: 14, threshold: 70 },
      },
    ],
  },
  {
    id: 'breakout-hunter',
    title: 'شکار شکست مقاومت با تایید حجم',
    friendlyDesc:
      'صبر می‌کند قیمت سقف مقاومت اخیر را با حجم معاملات بالا بشکند؛ بعد وارد می‌شود و با حد سود متحرک معامله را دنبال می‌کند.',
    bestFor: 'مناسب حرکت‌های پرقدرت روزانه و میان‌مدت',
    timeframe: '1h',
    style: 'MEDIUM_TERM',
    logic: 'AND',
    entryRules: [
      {
        id: 'sb-e1',
        type: 'BREAKOUT_RESISTANCE',
        action: 'BUY',
        enabled: true,
        params: { lookbackBars: 20 },
      },
      {
        id: 'sb-e2',
        type: 'TREND_ALIGNMENT',
        action: 'BUY',
        enabled: true,
        params: {},
      },
    ],
    exitRules: [
      {
        id: 'sb-x1',
        type: 'BREAKDOWN_SUPPORT',
        action: 'SELL',
        enabled: true,
        params: { lookbackBars: 14 },
      },
    ],
  },
  {
    id: 'wave-rider',
    title: 'همراه با موج صعودی (EMA + MACD)',
    friendlyDesc:
      'صبر می‌کند تا جهت بازار واقعاً صعودی شود، بعد سوار موج می‌شود و اگر روند برگشت سریع خارج می‌شود.',
    bestFor: 'مناسب حرکت‌های روندی میان‌مدت',
    timeframe: '4h',
    style: 'MEDIUM_TERM',
    logic: 'AND',
    entryRules: [
      {
        id: 's2-e1',
        type: 'EMA_GOLDEN_CROSS',
        action: 'BUY',
        enabled: true,
        params: { fastPeriod: 9, slowPeriod: 21 },
      },
      {
        id: 's2-e2',
        type: 'MACD_BULLISH_CROSS',
        action: 'BUY',
        enabled: true,
        params: {},
      },
    ],
    exitRules: [
      {
        id: 's2-x1',
        type: 'EMA_DEATH_CROSS',
        action: 'SELL',
        enabled: true,
        params: { fastPeriod: 9, slowPeriod: 21 },
      },
    ],
  },
];

type RiskProfile = 'LOW' | 'MEDIUM' | 'HIGH';

const RISK_PROFILES: Record<
  RiskProfile,
  { label: string; desc: string; sl: number; tp: number; trailing: boolean; trailPct: number }
> = {
  LOW: {
    label: 'کم‌ریسک (محافظه‌کار)',
    desc: 'حد ضرر ۲٪ · حد سود ۴٪',
    sl: 2.0,
    tp: 4.0,
    trailing: true,
    trailPct: 1.2,
  },
  MEDIUM: {
    label: 'متعادل (پیشنهادی)',
    desc: 'حد ضرر ۳٪ · حد سود ۶٪',
    sl: 3.0,
    tp: 6.0,
    trailing: true,
    trailPct: 1.8,
  },
  HIGH: {
    label: 'پُرریسک (روند بلندتر)',
    desc: 'حد ضرر ۵٪ · حد سود ۱۱٪',
    sl: 5.0,
    tp: 11.0,
    trailing: true,
    trailPct: 2.5,
  },
};

function mapRequestedModeToPage(req?: TradingBotModuleProps['requestedMode']): HubPageId {
  switch (req) {
    case 'AI_CYCLE_PRO':
      return 'AI_CYCLE_PRO';
    case 'PROFIT_BOT':
      return 'PROFIT_BOT';
    case 'FIXED_PRICE':
      return 'FIXED_PRICE';
    case 'GRID':
      return 'GRID';
    case 'DCA':
      return 'DCA';
    case 'BEGINNER':
    case 'ADVANCED':
      return 'STRATEGY';
    case 'AI_MANAGER':
      return 'AI_MANAGER';
    case 'UNIFIED_DASHBOARD':
      return 'UNIFIED_DASHBOARD';
    default:
      return 'HUB';
  }
}

export const TradingBotModule: React.FC<TradingBotModuleProps> = ({
  defaultBaseAsset,
  defaultQuoteCurrency,
  onQuoteCurrencyChange,
  markets,
  balances = [],
  usdtTomanRate,
  bots,
  logs,
  hasExchangeKeys,
  isAuthenticated,
  onRequireAuth,
  onCreateBot,
  onToggleBotStatus,
  onToggleBotMode,
  onEvaluateBotNow,
  onDeleteBot,
  onRunBacktest,
  telegram,
  onToggleBotTelegram,
  onSendBotReportToTelegram,
  onOpenTelegramSettings,
  onUpdateFixedTargets,
  requestedMode,
  requestedModeNonce,
  demoMode = false,
  aiCycleProBots = [],
  aiCycleProCycles = [],
  aiCycleProLogs = [],
  onCreateAiCycleProBot,
  onUpdateAiCycleProBot,
  onStartAiCycleProBot,
  onStopAiCycleProBot,
  onEvaluateAiCycleProBot,
  onManualSellAiCycleProBot,
  onDeleteAiCycleProBot,
  onPreviewAiCycleProMarket,
  profitBots = [],
  profitBotCycles = [],
  profitBotLogs = [],
  onCreateProfitBot,
  onUpdateProfitBot,
  onStartProfitBot,
  onStopProfitBot,
  onEvaluateProfitBot,
  onManualSellProfitBot,
  onDeleteProfitBot,
  onFetchProfitBotPreview,
  gridBots = [],
  dcaBots = [],
  riskSettings = DEFAULT_RISK_SETTINGS,
  pendingConfirmations = [],
  aiManagerReport = null,
  unifiedDashboard = null,
  onCreateGridBot,
  onStartGridBot,
  onStopGridBot,
  onEvaluateGridBot,
  onDeleteGridBot,
  onCreateDcaBot,
  onUpdateDcaBot,
  onStartDcaBot,
  onStopDcaBot,
  onEvaluateDcaBot,
  onDeleteDcaBot,
  onUpdateRiskSettings,
  onToggleKillSwitch,
  onResolveConfirmation,
  onRunAiManagerAnalysis,
}) => {
  const [activePage, setActivePage] = useState<HubPageId>(() =>
    mapRequestedModeToPage(requestedMode)
  );
  const [strategyEditorMode, setStrategyEditorMode] = useState<'BEGINNER' | 'ADVANCED'>(
    requestedMode === 'ADVANCED' ? 'ADVANCED' : 'BEGINNER'
  );
  const [guideTopic, setGuideTopic] = useState<GuideBotTopic | null>(null);

  useEffect(() => {
    if (!requestedMode) return;
    setActivePage(mapRequestedModeToPage(requestedMode));
    if (requestedMode === 'ADVANCED') setStrategyEditorMode('ADVANCED');
    else if (requestedMode === 'BEGINNER') setStrategyEditorMode('BEGINNER');
  }, [requestedMode, requestedModeNonce]);

  // Shared Core Target State (Dual Currency IRT & USDT)
  const [baseAsset, setBaseAsset] = useState(defaultBaseAsset || 'BTC');
  const [quoteCurrency, setQuoteCurrency] = useState<QuoteCurrency>(
    defaultQuoteCurrency || 'IRT'
  );
  const [mode, setMode] = useState<ExecutionMode>('paper');
  const [notifyTelegram, setNotifyTelegram] = useState(true);
  const [fundingMode, setFundingMode] = useState<BotFundingMode>('QUOTE_BUY');
  const [existingBalancePercent, setExistingBalancePercent] = useState<number>(100);
  const [executionConfirmationMode, setExecutionConfirmationMode] =
    useState<BotExecutionConfirmationMode>('AUTO');

  // Strategy Bot state
  const [strategyStyle, setStrategyStyle] = useState<StrategyStyleMode>('DAY_TRADING');
  const [selectedStrategyId, setSelectedStrategyId] = useState<string>('dip-buyer');
  const [riskProfile, setRiskProfile] = useState<RiskProfile>('MEDIUM');
  const [amountIrt, setAmountIrt] = useState<number>(10_000_000);
  const [amountUsdt, setAmountUsdt] = useState<number>(150);

  const [name, setName] = useState('ربات استراتژی هوشمند نوبیتکس');
  const [timeframe, setTimeframe] = useState<Timeframe>('15m');
  const [stopLossPercent, setStopLossPercent] = useState(3.0);
  const [takeProfitPercent, setTakeProfitPercent] = useState(6.0);
  const [trailingStopEnabled, setTrailingStopEnabled] = useState(true);
  const [trailingStopPercent, setTrailingStopPercent] = useState(1.8);
  const [cooldownMinutes, setCooldownMinutes] = useState(15);
  const [logicOperator, setLogicOperator] = useState<'AND' | 'OR'>('AND');
  const [entryRules, setEntryRules] = useState<StrategyRule[]>(SIMPLE_STRATEGIES[0].entryRules);
  const [exitRules, setExitRules] = useState<StrategyRule[]>(SIMPLE_STRATEGIES[0].exitRules);

  // Filters & upgraded sell management
  const [volumeConfirmationEnabled, setVolumeConfirmationEnabled] = useState<boolean>(true);
  const [minVolumeRatio, setMinVolumeRatio] = useState<number>(1.2);
  const [volatilityFilterEnabled, setVolatilityFilterEnabled] = useState<boolean>(true);
  const [volatilityFilterMaxAtrPercent, setVolatilityFilterMaxAtrPercent] = useState<number>(6.0);
  const [minSignalScore, setMinSignalScore] = useState<number>(55);
  const [multiTpEnabled, setMultiTpEnabled] = useState<boolean>(true);
  const [takeProfitTargets, setTakeProfitTargets] = useState<TakeProfitTarget[]>([
    { id: 'tp1', risePercent: 3.5, sellPercent: 50 },
    { id: 'tp2', risePercent: 7.0, sellPercent: 50 },
  ]);
  const [trailingTpEnabled, setTrailingTpEnabled] = useState<boolean>(true);
  const [trailingTpActivation, setTrailingTpActivation] = useState<number>(3.0);
  const [trailingTpCallback, setTrailingTpCallback] = useState<number>(1.0);
  const [keepRunnerPercent, setKeepRunnerPercent] = useState<number>(10);

  const [backtest, setBacktest] = useState<BacktestResult | null>(null);
  const [runningBacktest, setRunningBacktest] = useState(false);
  const [creating, setCreating] = useState(false);
  const [busyBotId, setBusyBotId] = useState<string | null>(null);
  const [sendingTelegramId, setSendingTelegramId] = useState<string | null>(null);
  const [telegramFeedback, setTelegramFeedback] = useState<{
    type: 'ok' | 'err';
    text: string;
  } | null>(null);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [confirmLiveBot, setConfirmLiveBot] = useState(false);
  const [pendingLiveBotId, setPendingLiveBotId] = useState<string | null>(null);

  useEffect(() => {
    if (mode !== 'live') setConfirmLiveBot(false);
  }, [mode]);

  useEffect(() => {
    setBaseAsset(defaultBaseAsset || 'BTC');
  }, [defaultBaseAsset]);

  useEffect(() => {
    setQuoteCurrency(defaultQuoteCurrency || 'IRT');
  }, [defaultQuoteCurrency]);

  const fixedBots = useMemo(
    () =>
      bots.filter(
        (b) =>
          b.strategyKind === 'FIXED_PRICE' ||
          b.entryRules.some((r) => r.type === 'FIXED_BUY_PRICE')
      ),
    [bots]
  );

  const strategyBots = useMemo(
    () =>
      bots.filter(
        (b) =>
          b.strategyKind !== 'FIXED_PRICE' &&
          !b.entryRules.some((r) => r.type === 'FIXED_BUY_PRICE')
      ),
    [bots]
  );

  const selectedMarket = useMemo(
    () => markets.find((m) => m.baseAsset === baseAsset) || null,
    [markets, baseAsset]
  );

  const freeBaseBalance = useMemo(() => {
    const found = balances.find((b) => b.asset.toUpperCase() === baseAsset.toUpperCase());
    return found ? Math.max(0, Number(found.free) || 0) : 0;
  }, [balances, baseAsset]);

  const livePriceForBase = useMemo(() => {
    if (!selectedMarket) return 0;
    return quoteCurrency === 'IRT'
      ? selectedMarket.bestBuyToman || selectedMarket.priceToman || 0
      : selectedMarket.bestBuyUsdt || selectedMarket.priceUsdt || 0;
  }, [selectedMarket, quoteCurrency]);

  const existingAlloc = useMemo(
    () =>
      computeExistingBalanceAllocation({
        freeBase: freeBaseBalance,
        percent: existingBalancePercent,
        referencePrice: livePriceForBase,
        minNotional: getMinimumOrderNotional(quoteCurrency),
        baseAsset,
        quoteCurrency,
      }),
    [freeBaseBalance, existingBalancePercent, livePriceForBase, baseAsset, quoteCurrency]
  );

  const handleSelectQuoteCurrency = (qc: QuoteCurrency) => {
    setQuoteCurrency(qc);
    onQuoteCurrencyChange?.(qc);
  };

  const applyStrategyStylePreset = (style: StrategyStyleMode) => {
    setStrategyStyle(style);
    if (style === 'DAY_TRADING') {
      setTimeframe('15m');
      setStopLossPercent(2.5);
      setTakeProfitPercent(5.0);
      setTrailingStopPercent(1.4);
      setCooldownMinutes(10);
      setTakeProfitTargets([
        { id: 'tp1', risePercent: 2.5, sellPercent: 50 },
        { id: 'tp2', risePercent: 5.0, sellPercent: 50 },
      ]);
      setKeepRunnerPercent(0);
    } else {
      setTimeframe('4h');
      setStopLossPercent(4.5);
      setTakeProfitPercent(11.0);
      setTrailingStopPercent(2.2);
      setCooldownMinutes(60);
      setTakeProfitTargets([
        { id: 'tp1', risePercent: 5.0, sellPercent: 40 },
        { id: 'tp2', risePercent: 10.0, sellPercent: 40 },
      ]);
      setKeepRunnerPercent(20);
    }
  };

  const orderAmount = quoteCurrency === 'IRT' ? amountIrt : amountUsdt;
  const equivalentText =
    quoteCurrency === 'IRT'
      ? usdtTomanRate > 0
        ? `≈ $${(amountIrt / usdtTomanRate).toFixed(2)} USDT`
        : ''
      : `≈ ${formatToman(amountUsdt * usdtTomanRate)} تومان`;

  const applySimpleCard = (card: SimpleStrategyCard) => {
    setSelectedStrategyId(card.id);
    setName(`${card.title} (${baseAsset})`);
    setTimeframe(card.timeframe);
    setStrategyStyle(card.style);
    setLogicOperator(card.logic);
    setEntryRules(card.entryRules.map((r) => ({ ...r, params: { ...r.params } })));
    setExitRules(card.exitRules.map((r) => ({ ...r, params: { ...r.params } })));
  };

  const applyRiskProfile = (rp: RiskProfile) => {
    setRiskProfile(rp);
    const cfg = RISK_PROFILES[rp];
    setStopLossPercent(cfg.sl);
    setTakeProfitPercent(cfg.tp);
    setTrailingStopEnabled(cfg.trailing);
    setTrailingStopPercent(cfg.trailPct);
  };

  const addRule = (target: 'ENTRY' | 'EXIT', type: RuleIndicatorType) => {
    const newRule: StrategyRule = {
      id: `rule-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
      type,
      action: target === 'ENTRY' ? 'BUY' : 'SELL',
      enabled: true,
      params:
        type === 'RSI_OVERSOLD'
          ? { period: 14, threshold: 35 }
          : type === 'RSI_OVERBOUGHT'
            ? { period: 14, threshold: 70 }
            : type === 'EMA_GOLDEN_CROSS' || type === 'EMA_DEATH_CROSS'
              ? { fastPeriod: 9, slowPeriod: 21 }
              : type === 'VOLUME_SPIKE'
                ? { multiplier: 1.6 }
                : type === 'BREAKOUT_RESISTANCE' || type === 'BREAKDOWN_SUPPORT'
                  ? { lookbackBars: 20 }
                  : type === 'VOLATILITY_FILTER'
                    ? { minAtrPercent: 0.25, maxAtrPercent: 6.0 }
                    : {},
    };
    if (target === 'ENTRY') setEntryRules((prev) => [...prev, newRule]);
    else setExitRules((prev) => [...prev, newRule]);
  };

  const updateRuleParam = (
    target: 'ENTRY' | 'EXIT',
    ruleId: string,
    key: keyof StrategyRule['params'],
    val: number
  ) => {
    const setter = target === 'ENTRY' ? setEntryRules : setExitRules;
    setter((prev) =>
      prev.map((r) =>
        r.id === ruleId ? { ...r, params: { ...r.params, [key]: val } } : r
      )
    );
  };

  const removeRule = (target: 'ENTRY' | 'EXIT', ruleId: string) => {
    const setter = target === 'ENTRY' ? setEntryRules : setExitRules;
    setter((prev) => prev.filter((r) => r.id !== ruleId));
  };

  const handleBacktest = async () => {
    setFeedback(null);
    setRunningBacktest(true);
    try {
      const result = await onRunBacktest({
        botType: 'STRATEGY',
        baseAsset,
        quoteCurrency,
        symbol: `${baseAsset}${quoteCurrency}`,
        timeframe,
        orderAmount,
        stopLossPercent,
        takeProfitPercent,
        trailingStopEnabled,
        trailingStopPercent,
        logicOperator,
        entryRules,
        exitRules,
        volumeConfirmationEnabled,
        minVolumeRatio,
        volatilityFilterEnabled,
        volatilityFilterMaxAtrPercent,
        takeProfitTargets: multiTpEnabled ? takeProfitTargets : [],
        trailingTakeProfitEnabled: trailingTpEnabled,
        trailingTakeProfitActivationPercent: trailingTpActivation,
        trailingTakeProfitCallbackPercent: trailingTpCallback,
        keepRunnerPercent,
        estimatedSlippagePercent: 0.15,
        limit: 300,
      });
      setBacktest(result);
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'اجرای بک‌تست ناموفق بود.',
      });
    } finally {
      setRunningBacktest(false);
    }
  };

  const handleCreate = async (startImmediately: boolean) => {
    setFeedback(null);
    if (!isAuthenticated) {
      onRequireAuth();
      return;
    }

    const activeStrat =
      SIMPLE_STRATEGIES.find((s) => s.id === selectedStrategyId) || SIMPLE_STRATEGIES[0];
    const botName =
      strategyEditorMode === 'BEGINNER'
        ? `${activeStrat.title} · ${selectedMarket?.persianName || baseAsset} (${quoteCurrency === 'IRT' ? 'تومانی' : 'تتری'})`
        : name;
    const finalEntryRules = strategyEditorMode === 'BEGINNER' ? activeStrat.entryRules : entryRules;
    const finalExitRules = strategyEditorMode === 'BEGINNER' ? activeStrat.exitRules : exitRules;

    if (finalEntryRules.filter((r) => r.enabled).length === 0) {
      setFeedback({ type: 'err', text: 'حداقل یک شرط خرید برای ربات انتخاب کنید.' });
      return;
    }
    if (fundingMode === 'EXISTING_ASSET' && startImmediately && !existingAlloc.ok) {
      setFeedback({
        type: 'err',
        text: existingAlloc.reason || `موجودی آزاد ${baseAsset} برای ورود به معامله کافی نیست.`,
      });
      return;
    }
    if (mode === 'live' && !confirmLiveBot) {
      setFeedback({
        type: 'err',
        text: 'برای ساخت ربات در حالت واقعی (Live)، ابتدا تیک تأیید معامله با سرمایه واقعی را فعال کنید.',
      });
      return;
    }

    const effectiveOrderAmount =
      fundingMode === 'EXISTING_ASSET' && !(orderAmount > 0)
        ? getMinimumOrderNotional(quoteCurrency)
        : orderAmount;

    setCreating(true);
    try {
      await onCreateBot({
        name: botName,
        strategyKind: 'INDICATOR',
        strategyStyle,
        baseAsset,
        quoteCurrency,
        symbol: `${baseAsset}${quoteCurrency}`,
        timeframe: strategyEditorMode === 'BEGINNER' ? activeStrat.timeframe : timeframe,
        mode,
        confirmLive: mode === 'live' ? confirmLiveBot : undefined,
        status: startImmediately ? 'RUNNING' : 'PAUSED',
        orderAmount: effectiveOrderAmount,
        fundingMode,
        existingBalancePercent: Math.min(100, Math.max(1, Math.round(existingBalancePercent))),
        executionConfirmationMode,
        stopLossPercent,
        takeProfitPercent,
        trailingStopEnabled,
        trailingStopPercent,
        cooldownMinutes,
        logicOperator: strategyEditorMode === 'BEGINNER' ? activeStrat.logic : logicOperator,
        entryRules: finalEntryRules,
        exitRules: finalExitRules,
        volumeConfirmationEnabled,
        minVolumeRatio,
        volatilityFilterEnabled,
        volatilityFilterMaxAtrPercent,
        minSignalScore,
        takeProfitTargets: multiTpEnabled ? takeProfitTargets : [],
        trailingTakeProfitEnabled: trailingTpEnabled,
        trailingTakeProfitActivationPercent: trailingTpActivation,
        trailingTakeProfitCallbackPercent: trailingTpCallback,
        keepRunnerPercent,
        notifyTelegram,
      });
      setConfirmLiveBot(false);
      setFeedback({
        type: 'ok',
        text: startImmediately
          ? `ربات «${botName}» روی نوبیتکس ساخته شد و همین الان شروع به رصد کرد.`
          : `ربات «${botName}» ذخیره شد و هر زمان بخواهید می‌توانید روشنش کنید.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ساخت ربات.',
      });
    } finally {
      setCreating(false);
    }
  };

  const navigateToBotType = (botType: BotType, asset?: string) => {
    if (asset) setBaseAsset(asset);
    switch (botType) {
      case 'AI_CYCLE_PRO':
        setActivePage('AI_CYCLE_PRO');
        break;
      case 'PROFIT':
        setActivePage('PROFIT_BOT');
        break;
      case 'FIXED_PRICE':
        setActivePage('FIXED_PRICE');
        break;
      case 'GRID':
        setActivePage('GRID');
        break;
      case 'DCA':
        setActivePage('DCA');
        break;
      case 'STRATEGY':
      default:
        setActivePage('STRATEGY');
        break;
    }
  };

  const handleResolveConfirmationSafe = async (
    conf: PendingBotConfirmation,
    decision: 'APPROVE' | 'REJECT'
  ) => {
    if (onResolveConfirmation) {
      await onResolveConfirmation(conf, decision);
    }
  };

  const equityPolyline = (() => {
    if (!backtest || backtest.equityCurve.length < 2) return '';
    const w = 640;
    const h = 130;
    const vals = backtest.equityCurve.map((p) => p.equity);
    const min = Math.min(...vals);
    const max = Math.max(...vals);
    const span = max - min || 1;
    return backtest.equityCurve
      .map((pt, i) => {
        const x = (i / (backtest.equityCurve.length - 1)) * w;
        const y = h - 10 - ((pt.equity - min) / span) * (h - 20);
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(' ');
  })();

  const totalActiveBotsCount =
    aiCycleProBots.filter((b) => b.isActive).length +
    profitBots.filter((b) => b.isActive).length +
    fixedBots.filter((b) => b.status === 'RUNNING').length +
    gridBots.filter((b) => b.isActive).length +
    dcaBots.filter((b) => b.isActive).length +
    strategyBots.filter((b) => b.status === 'RUNNING').length;

  const effectiveDashboard = unifiedDashboard || EMPTY_DASHBOARD;

  // =========================================================================
  // Render Selected Dedicated Page or Clean Categorized Hub
  // =========================================================================
  return (
    <div className="space-y-5">
      {/* Global Educational Modal */}
      {guideTopic && <BotEducationModal topic={guideTopic} onClose={() => setGuideTopic(null)} />}

      {activePage === 'AI_CYCLE_PRO' ? (
        <AiCycleProPage
          defaultBaseAsset={baseAsset}
          defaultQuoteCurrency={quoteCurrency}
          markets={markets}
          balances={balances}
          usdtTomanRate={usdtTomanRate}
          hasExchangeKeys={hasExchangeKeys}
          isAuthenticated={isAuthenticated}
          demoMode={demoMode}
          riskSettings={riskSettings}
          bots={aiCycleProBots}
          cycles={aiCycleProCycles}
          logs={aiCycleProLogs}
          pendingConfirmations={pendingConfirmations.filter((c) => c.botType === 'AI_CYCLE_PRO')}
          onBack={() => setActivePage('HUB')}
          onOpenGuide={setGuideTopic}
          onRequireAuth={onRequireAuth}
          onCreateBot={onCreateAiCycleProBot || (async () => {})}
          onUpdateBot={onUpdateAiCycleProBot || (async () => {})}
          onStartBot={onStartAiCycleProBot || (async () => {})}
          onStopBot={onStopAiCycleProBot || (async () => {})}
          onEvaluateBot={onEvaluateAiCycleProBot || (async () => {})}
          onManualSellBot={onManualSellAiCycleProBot || (async () => {})}
          onDeleteBot={onDeleteAiCycleProBot || (async () => {})}
          onPreviewMarket={onPreviewAiCycleProMarket}
          onResolveConfirmation={handleResolveConfirmationSafe}
        />
      ) : activePage === 'PROFIT_BOT' ? (
        <ProfitBotModule
          defaultBaseAsset={baseAsset}
          defaultQuoteCurrency={quoteCurrency}
          onQuoteCurrencyChange={handleSelectQuoteCurrency}
          markets={markets}
          balances={balances}
          usdtTomanRate={usdtTomanRate}
          profitBots={profitBots}
          cycles={profitBotCycles}
          logs={profitBotLogs}
          hasExchangeKeys={hasExchangeKeys}
          isAuthenticated={isAuthenticated}
          demoMode={demoMode}
          onRequireAuth={onRequireAuth}
          onCreateProfitBot={onCreateProfitBot || (async () => {})}
          onUpdateProfitBot={onUpdateProfitBot || (async () => {})}
          onStartProfitBot={onStartProfitBot || (async () => {})}
          onStopProfitBot={onStopProfitBot || (async () => {})}
          onEvaluateProfitBot={onEvaluateProfitBot || (async () => {})}
          onManualSellProfitBot={onManualSellProfitBot || (async () => {})}
          onDeleteProfitBot={onDeleteProfitBot || (async () => {})}
          onFetchPreview={onFetchProfitBotPreview}
          onBack={() => setActivePage('HUB')}
          onOpenGuide={setGuideTopic}
          pendingConfirmations={pendingConfirmations.filter((c) => c.botType === 'PROFIT')}
          onResolveConfirmation={handleResolveConfirmationSafe}
        />
      ) : activePage === 'FIXED_PRICE' ? (
        <FixedPriceAutoTrader
          defaultBaseAsset={baseAsset}
          defaultQuoteCurrency={quoteCurrency}
          onQuoteCurrencyChange={handleSelectQuoteCurrency}
          markets={markets}
          balances={balances}
          usdtTomanRate={usdtTomanRate}
          fixedBots={fixedBots}
          hasExchangeKeys={hasExchangeKeys}
          isAuthenticated={isAuthenticated}
          onRequireAuth={onRequireAuth}
          onCreateBot={onCreateBot}
          onUpdateFixedTargets={onUpdateFixedTargets}
          onToggleBotStatus={onToggleBotStatus}
          onToggleBotMode={onToggleBotMode}
          onEvaluateBotNow={onEvaluateBotNow}
          onDeleteBot={onDeleteBot}
          onToggleBotTelegram={onToggleBotTelegram}
          onSendBotReportToTelegram={onSendBotReportToTelegram}
          onBack={() => setActivePage('HUB')}
          onOpenGuide={setGuideTopic}
          pendingConfirmations={pendingConfirmations.filter((c) => c.botType === 'FIXED_PRICE')}
          onResolveConfirmation={handleResolveConfirmationSafe}
        />
      ) : activePage === 'GRID' ? (
        <GridBotPage
          defaultBaseAsset={baseAsset}
          defaultQuoteCurrency={quoteCurrency}
          markets={markets}
          balances={balances}
          hasExchangeKeys={hasExchangeKeys}
          isAuthenticated={isAuthenticated}
          riskSettings={riskSettings}
          gridBots={gridBots}
          pendingConfirmations={pendingConfirmations.filter((c) => c.botType === 'GRID')}
          onBack={() => setActivePage('HUB')}
          onOpenGuide={setGuideTopic}
          onRequireAuth={onRequireAuth}
          onCreateGridBot={onCreateGridBot || (async () => {})}
          onStartGridBot={onStartGridBot || (async () => {})}
          onStopGridBot={onStopGridBot || (async () => {})}
          onEvaluateGridBot={onEvaluateGridBot || (async () => {})}
          onDeleteGridBot={onDeleteGridBot || (async () => {})}
          onRunBacktest={onRunBacktest}
          onResolveConfirmation={handleResolveConfirmationSafe}
        />
      ) : activePage === 'DCA' ? (
        <DcaBotPage
          defaultBaseAsset={baseAsset}
          defaultQuoteCurrency={quoteCurrency}
          markets={markets}
          balances={balances}
          hasExchangeKeys={hasExchangeKeys}
          isAuthenticated={isAuthenticated}
          riskSettings={riskSettings}
          dcaBots={dcaBots}
          pendingConfirmations={pendingConfirmations.filter((c) => c.botType === 'DCA')}
          onBack={() => setActivePage('HUB')}
          onOpenGuide={setGuideTopic}
          onRequireAuth={onRequireAuth}
          onCreateDcaBot={onCreateDcaBot || (async () => {})}
          onUpdateDcaBot={onUpdateDcaBot || (async () => {})}
          onStartDcaBot={onStartDcaBot || (async () => {})}
          onStopDcaBot={onStopDcaBot || (async () => {})}
          onEvaluateDcaBot={onEvaluateDcaBot || (async () => {})}
          onDeleteDcaBot={onDeleteDcaBot || (async () => {})}
          onRunBacktest={onRunBacktest}
          onResolveConfirmation={handleResolveConfirmationSafe}
        />
      ) : activePage === 'AI_MANAGER' ? (
        <AiBotManagerPage
          isAuthenticated={isAuthenticated}
          demoMode={demoMode}
          riskSettings={riskSettings}
          pendingConfirmations={pendingConfirmations}
          aiReport={aiManagerReport}
          dashboardSummary={effectiveDashboard}
          onBack={() => setActivePage('HUB')}
          onOpenGuide={setGuideTopic}
          onRequireAuth={onRequireAuth}
          onRunAiAnalysis={onRunAiManagerAnalysis || (async () => {})}
          onUpdateRiskSettings={onUpdateRiskSettings || (async () => {})}
          onToggleKillSwitch={onToggleKillSwitch || (async () => {})}
          onResolveConfirmation={handleResolveConfirmationSafe}
          onNavigateToBot={(bt, asset) => navigateToBotType(bt, asset)}
          onStopBotByType={async (bt, botId) => {
            if (bt === 'AI_CYCLE_PRO' && onStopAiCycleProBot) await onStopAiCycleProBot(botId);
            else if (bt === 'PROFIT' && onStopProfitBot) await onStopProfitBot(botId);
            else if (bt === 'GRID' && onStopGridBot) await onStopGridBot(botId);
            else if (bt === 'DCA' && onStopDcaBot) await onStopDcaBot(botId);
            else await onToggleBotStatus(botId, 'PAUSED');
          }}
        />
      ) : activePage === 'UNIFIED_DASHBOARD' ? (
        <UnifiedBotsDashboardPage
          dashboard={effectiveDashboard}
          riskSettings={riskSettings}
          pendingConfirmations={pendingConfirmations}
          aiReport={aiManagerReport}
          onBack={() => setActivePage('HUB')}
          onOpenGuide={setGuideTopic}
          onNavigateToBot={(bt) => navigateToBotType(bt)}
          onOpenAiManager={() => setActivePage('AI_MANAGER')}
          onToggleKillSwitch={onToggleKillSwitch || (async () => {})}
          onResolveConfirmation={handleResolveConfirmationSafe}
        />
      ) : activePage === 'STRATEGY' ? (
        /* =================================================================
           DEDICATED STRATEGY BOT PAGE (Beginner + Pro + Breakout + Multi-TP)
        ================================================================== */
        <div className="space-y-5" dir="rtl">
          <div className="rounded-2xl border border-indigo-500/30 bg-[#0A101D] p-4 sm:p-5 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={() => setActivePage('HUB')}
                className="min-w-[44px] min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 flex items-center justify-center shrink-0"
                title="بازگشت به رباتهای معاملاتی من"
              >
                <ArrowRight className="w-5 h-5" />
              </button>
              <div className="w-11 h-11 rounded-xl border border-indigo-500/35 bg-indigo-500/15 flex items-center justify-center shrink-0">
                <SlidersHorizontal className="w-5 h-5 text-indigo-300" />
              </div>
              <div>
                <h2 className="text-base sm:text-lg font-extrabold text-white">
                  ربات استراتژی هوشمند (Strategy Bot)
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  معامله با ترکیب شکست مقاومت/حمایت، RSI، EMA، MACD، فیلتر حجم و فروش پله‌ای با کارمزد شفاف
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setGuideTopic('STRATEGY')}
                className="min-h-[42px] px-3.5 rounded-xl border border-cyan-500/35 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-200 text-xs font-bold flex items-center gap-1.5"
              >
                <BookOpen className="w-4 h-4" />
                راهنمای استفاده
              </button>
              <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
                <button
                  type="button"
                  onClick={() => setStrategyEditorMode('BEGINNER')}
                  className={`min-h-[38px] px-3 rounded-lg font-bold transition ${
                    strategyEditorMode === 'BEGINNER'
                      ? 'bg-indigo-600/30 border border-indigo-400/50 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  حالت ساده
                </button>
                <button
                  type="button"
                  onClick={() => setStrategyEditorMode('ADVANCED')}
                  className={`min-h-[38px] px-3 rounded-lg font-bold transition ${
                    strategyEditorMode === 'ADVANCED'
                      ? 'bg-indigo-600/30 border border-indigo-400/50 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  حالت پیشرفته و بک‌تست
                </button>
              </div>
            </div>
          </div>

          {/* Pending Strategy Confirmations */}
          {pendingConfirmations.filter((c) => c.botType === 'STRATEGY').length > 0 && (
            <div className="rounded-2xl border border-amber-500/40 bg-amber-500/10 p-4 space-y-2.5 text-xs">
              <div className="flex items-center gap-2 text-amber-200 font-bold">
                <Hand className="w-4 h-4 text-amber-400" />
                سفارش ربات استراتژی در انتظار تأیید دستی (
                {pendingConfirmations.filter((c) => c.botType === 'STRATEGY').length})
              </div>
              {pendingConfirmations
                .filter((c) => c.botType === 'STRATEGY')
                .map((conf) => (
                  <div
                    key={conf.id}
                    className="rounded-xl border border-amber-500/30 bg-[#0A101D]/90 p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-2"
                  >
                    <div>
                      <div className="font-bold text-white">
                        {conf.side === 'BUY' ? 'خرید' : 'فروش'} {conf.symbol} ·{' '}
                        <span className="font-mono-num text-cyan-300">
                          {conf.suggestedPrice.toLocaleString('en-US')}
                        </span>
                      </div>
                      <div className="text-slate-300">{conf.reasonFa}</div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => void handleResolveConfirmationSafe(conf, 'APPROVE')}
                        className="min-h-[40px] px-3.5 rounded-xl bg-emerald-600 text-white font-bold"
                      >
                        تأیید و اجرا
                      </button>
                      <button
                        type="button"
                        onClick={() => void handleResolveConfirmationSafe(conf, 'REJECT')}
                        className="min-h-[40px] px-3 rounded-xl border border-rose-500/40 bg-rose-500/10 text-rose-200 font-bold"
                      >
                        رد
                      </button>
                    </div>
                  </div>
                ))}
            </div>
          )}

          {/* Day-Trading vs Medium-Term Preset Strip */}
          <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-200">سبک زمانی معامله:</span>
              <button
                type="button"
                onClick={() => applyStrategyStylePreset('DAY_TRADING')}
                className={`min-h-[40px] px-3.5 rounded-xl border font-bold ${
                  strategyStyle === 'DAY_TRADING'
                    ? 'border-cyan-400/60 bg-cyan-500/15 text-cyan-200'
                    : 'border-slate-800 bg-slate-900 text-slate-400'
                }`}
              >
                معامله روزانه (Day Trading · 15m)
              </button>
              <button
                type="button"
                onClick={() => applyStrategyStylePreset('MEDIUM_TERM')}
                className={`min-h-[40px] px-3.5 rounded-xl border font-bold ${
                  strategyStyle === 'MEDIUM_TERM'
                    ? 'border-indigo-400/60 bg-indigo-500/15 text-indigo-200'
                    : 'border-slate-800 bg-slate-900 text-slate-400'
                }`}
              >
                روند میان‌مدت (Swing · 4h)
              </button>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-slate-400">نحوه اجرا:</span>
              <button
                type="button"
                onClick={() => setExecutionConfirmationMode('AUTO')}
                className={`min-h-[38px] px-3 rounded-lg border font-bold ${
                  executionConfirmationMode === 'AUTO'
                    ? 'border-emerald-500/50 bg-emerald-500/15 text-emerald-200'
                    : 'border-slate-800 bg-slate-900 text-slate-400'
                }`}
              >
                خودکار
              </button>
              <button
                type="button"
                onClick={() => setExecutionConfirmationMode('MANUAL_CONFIRM')}
                className={`min-h-[38px] px-3 rounded-lg border font-bold ${
                  executionConfirmationMode === 'MANUAL_CONFIRM'
                    ? 'border-amber-500/50 bg-amber-500/15 text-amber-200'
                    : 'border-slate-800 bg-slate-900 text-slate-400'
                }`}
              >
                تأیید دستی
              </button>
            </div>
          </div>

          {strategyEditorMode === 'BEGINNER' ? (
            <div className="glass-panel rounded-xl p-5 space-y-6">
              {/* Step 1 */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-bold text-xs flex items-center justify-center font-mono-num">
                    1
                  </span>
                  <span>انتخاب ارز و بازار معامله (تومان یا تتر)</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center bg-slate-950 border border-slate-800/90 rounded-lg p-4">
                  <div>
                    <label className="block text-xs text-slate-400 mb-1.5">کدام ارز معامله شود؟</label>
                    <CoinSearchSelect
                      markets={markets}
                      value={baseAsset}
                      quoteCurrency={quoteCurrency}
                      onChange={(nextBase) => {
                        setBaseAsset(nextBase);
                        const nextM = markets.find((m) => m.baseAsset === nextBase);
                        if (quoteCurrency === 'IRT' && nextM && !nextM.hasIrtMarket) {
                          setQuoteCurrency('USDT');
                        }
                      }}
                      ariaLabel="جستجو و انتخاب ارز ربات"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1.5">ربات با چه پولی کار کند؟</label>
                    <div className="grid grid-cols-2 gap-1.5">
                      <button
                        type="button"
                        disabled={selectedMarket ? !selectedMarket.hasIrtMarket : false}
                        onClick={() => handleSelectQuoteCurrency('IRT')}
                        className={`btn-glass py-2 px-3 rounded-lg text-xs font-semibold ${
                          quoteCurrency === 'IRT'
                            ? 'btn-glass-amber'
                            : 'btn-glass-neutral text-slate-300'
                        }`}
                      >
                        بازار تومانی (IRT)
                      </button>
                      <button
                        type="button"
                        disabled={selectedMarket ? !selectedMarket.hasUsdtMarket : false}
                        onClick={() => handleSelectQuoteCurrency('USDT')}
                        className={`btn-glass py-2 px-3 rounded-lg text-xs font-semibold ${
                          quoteCurrency === 'USDT'
                            ? 'btn-glass-primary'
                            : 'btn-glass-neutral text-slate-300'
                        }`}
                      >
                        بازار تتری (USDT)
                      </button>
                    </div>
                  </div>
                  <div className="text-xs space-y-1">
                    <div className="text-slate-400">قیمت لحظه‌ای در نوبیتکس:</div>
                    <div className="font-mono-num text-amber-300 font-semibold" dir="ltr">
                      {formatToman(selectedMarket?.priceToman)} تومان
                    </div>
                    <div className="font-mono-num text-slate-300" dir="ltr">
                      ${formatPrice(selectedMarket?.priceUsdt)} USDT
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 2 */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-bold text-xs flex items-center justify-center font-mono-num">
                    2
                  </span>
                  <span>روش کار ربات استراتژی را انتخاب کنید</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {SIMPLE_STRATEGIES.map((card) => {
                    const active = selectedStrategyId === card.id;
                    return (
                      <button
                        key={card.id}
                        type="button"
                        onClick={() => applySimpleCard(card)}
                        className={`btn-glass text-right p-4 rounded-xl flex flex-col justify-between gap-2 ${
                          active ? 'btn-glass-primary' : 'btn-glass-neutral text-slate-300'
                        }`}
                      >
                        <div className="space-y-1.5">
                          <div className="text-sm font-semibold text-white">{card.title}</div>
                          <p className="text-xs text-slate-300 leading-relaxed">{card.friendlyDesc}</p>
                        </div>
                        <div className="text-[11px] text-cyan-300 pt-2 border-t border-slate-800/80">
                          {card.bestFor}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Step 3 */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-sm font-semibold text-white">
                  <span className="w-6 h-6 rounded-full bg-cyan-500 text-slate-950 font-bold text-xs flex items-center justify-center font-mono-num">
                    3
                  </span>
                  <span>مبلغ هر معامله، منبع سرمایه و سطح ریسک</span>
                </div>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 bg-slate-950 border border-slate-800/90 rounded-lg p-4">
                  <div className="space-y-3">
                    <div className="rounded-lg border border-indigo-500/25 bg-indigo-950/20 p-3 space-y-2.5 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-semibold text-indigo-200 inline-flex items-center gap-1.5">
                          <Coins className="w-3.5 h-3.5 text-indigo-400" />
                          <span>منبع سرمایه ورود</span>
                        </span>
                        <span className="font-mono-num text-[11px] text-slate-300">
                          موجودی آزاد {baseAsset}:{' '}
                          <strong className="text-emerald-300">{formatQty(freeBaseBalance)}</strong>
                        </span>
                      </div>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(
                          [
                            { value: 'QUOTE_BUY' as BotFundingMode, label: 'خرید ریال/تتر' },
                            { value: 'EXISTING_ASSET' as BotFundingMode, label: `موجودی ${baseAsset}` },
                            { value: 'AUTO_PREFER_EXISTING' as BotFundingMode, label: 'اول ارز، بعد خرید' },
                          ] as const
                        ).map((opt) => (
                          <button
                            key={opt.value}
                            type="button"
                            onClick={() => setFundingMode(opt.value)}
                            className={`py-1.5 px-2 rounded-md border text-[11px] font-medium transition ${
                              fundingMode === opt.value
                                ? 'bg-indigo-500/25 border-indigo-400/60 text-white'
                                : 'bg-slate-900 border-slate-800 text-slate-300 hover:text-white'
                            }`}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className={fundingMode === 'EXISTING_ASSET' ? 'opacity-50 space-y-2' : 'space-y-3'}>
                      <label className="block text-xs text-slate-300">
                        مبلغ هر معامله ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})
                      </label>
                      <div className="flex items-center gap-3">
                        <NumericInput
                          value={orderAmount}
                          onValueChange={(v) => {
                            const num = v === '' || v === '.' ? 0 : Number(v);
                            if (quoteCurrency === 'IRT') setAmountIrt(num);
                            else setAmountUsdt(num);
                          }}
                          className="w-48 bg-[#0A101D] border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-none focus:border-cyan-400"
                        />
                        <span className="text-xs font-mono-num text-slate-400" dir="ltr">
                          {equivalentText}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="block text-xs text-slate-300">میزان ریسک و حد سود/ضرر خودکار:</label>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      {(Object.keys(RISK_PROFILES) as RiskProfile[]).map((rp) => {
                        const info = RISK_PROFILES[rp];
                        const active = riskProfile === rp;
                        return (
                          <button
                            key={rp}
                            type="button"
                            onClick={() => applyRiskProfile(rp)}
                            className={`btn-glass text-right p-2.5 rounded-xl ${
                              active ? 'btn-glass-buy' : 'btn-glass-neutral text-slate-300'
                            }`}
                          >
                            <div className="text-xs font-semibold flex items-center gap-1">
                              <Shield className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                              <span>{info.label}</span>
                            </div>
                            <div className="text-[11px] text-slate-400 mt-1">{info.desc}</div>
                          </button>
                        );
                      })}
                    </div>

                    <div className="flex flex-wrap items-center gap-3 pt-1 text-xs">
                      <span className="text-slate-400">حالت اجرا:</span>
                      <label className="inline-flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="radio"
                          checked={mode === 'paper'}
                          onChange={() => setMode('paper')}
                          className="accent-cyan-500"
                        />
                        <span className="text-slate-200">تمرینی بدون ریسک</span>
                      </label>
                      <label className="inline-flex items-center gap-1.5 cursor-pointer">
                        <input
                          type="radio"
                          disabled={!hasExchangeKeys}
                          checked={mode === 'live'}
                          onChange={() => setMode('live')}
                          className="accent-emerald-500"
                        />
                        <span className={hasExchangeKeys ? 'text-emerald-300' : 'text-slate-500'}>
                          واقعی روی نوبیتکس
                        </span>
                      </label>
                    </div>

                    {mode === 'live' && (
                      <label className="flex items-start gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-[11px] text-amber-200 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={confirmLiveBot}
                          onChange={(e) => setConfirmLiveBot(e.target.checked)}
                          className="mt-0.5 accent-amber-400 shrink-0"
                        />
                        <span>تأیید می‌کنم این ربات با سرمایه واقعی نوبیتکس من معامله کند.</span>
                      </label>
                    )}
                  </div>
                </div>
              </div>

              {feedback && (
                <div
                  className={`text-xs px-3 py-2 rounded border ${
                    feedback.type === 'ok'
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                  }`}
                >
                  {feedback.text}
                </div>
              )}

              <div className="flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => void handleCreate(true)}
                  disabled={creating}
                  className="btn-glass btn-glass-buy inline-flex items-center gap-2 px-5 py-2.5 rounded-xl text-sm font-semibold"
                >
                  <Play className="w-4 h-4" />
                  <span>{isAuthenticated ? 'فعال‌سازی ربات استراتژی' : 'ورود و فعال‌سازی ربات'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => void handleBacktest()}
                  disabled={runningBacktest}
                  className="btn-glass btn-glass-ai inline-flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-medium"
                >
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span>{runningBacktest ? 'در حال بررسی...' : 'تست عملکرد روی روزهای گذشته (بک‌تست)'}</span>
                </button>
              </div>
            </div>
          ) : (
            /* ADVANCED STRATEGY BUILDER */
            <div className="glass-panel rounded-xl p-5 space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">نام ربات</label>
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">ارز و بازار</label>
                  <div className="flex gap-1.5">
                    <div className="flex-1 min-w-0">
                      <CoinSearchSelect
                        markets={markets}
                        value={baseAsset}
                        quoteCurrency={quoteCurrency}
                        size="sm"
                        onChange={(nextBase) => {
                          setBaseAsset(nextBase);
                          const nextM = markets.find((m) => m.baseAsset === nextBase);
                          if (quoteCurrency === 'IRT' && nextM && !nextM.hasIrtMarket) {
                            setQuoteCurrency('USDT');
                          }
                        }}
                      />
                    </div>
                    <button
                      type="button"
                      onClick={() =>
                        handleSelectQuoteCurrency(quoteCurrency === 'IRT' ? 'USDT' : 'IRT')
                      }
                      className="px-2.5 rounded-lg border border-slate-700 bg-slate-900 text-amber-300 font-bold"
                    >
                      {quoteCurrency}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">تایم‌فریم کندل</label>
                  <select
                    value={timeframe}
                    onChange={(e) => setTimeframe(e.target.value as Timeframe)}
                    dir="ltr"
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 font-mono-num text-white"
                  >
                    {(['1m', '5m', '15m', '1h', '4h', '1d'] as Timeframe[]).map((tf) => (
                      <option key={tf} value={tf}>
                        {tf}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">
                    حجم هر معامله ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})
                  </label>
                  <NumericInput
                    value={orderAmount}
                    onValueChange={(v) => {
                      const num = v === '' || v === '.' ? 0 : Number(v);
                      if (quoteCurrency === 'IRT') setAmountIrt(num);
                      else setAmountUsdt(num);
                    }}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">حالت اجرا</label>
                  <select
                    value={mode}
                    onChange={(e) => setMode(e.target.value as ExecutionMode)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="paper">شبیه‌سازی (تمرینی)</option>
                    <option value="live" disabled={!hasExchangeKeys}>
                      حساب واقعی نوبیتکس {hasExchangeKeys ? '' : '(نیازمند توکن)'}
                    </option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 mb-1">فاصله حداقل بین معاملات (دقیقه)</label>
                  <NumericInput
                    allowDecimal={false}
                    value={cooldownMinutes}
                    onValueChange={(v) => setCooldownMinutes(v === '' ? 0 : Number(v))}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-white"
                  />
                </div>
              </div>

              {/* Signal Filters & Risk Parameters */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs border-t border-slate-800 pt-4">
                <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-3 space-y-2">
                  <label className="flex items-center gap-2 text-slate-200 font-bold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={volumeConfirmationEnabled}
                      onChange={(e) => setVolumeConfirmationEnabled(e.target.checked)}
                      className="accent-cyan-400"
                    />
                    تأیید سیگنال با حجم معاملات
                  </label>
                  <NumericInput
                    disabled={!volumeConfirmationEnabled}
                    value={minVolumeRatio}
                    onValueChange={(v) => setMinVolumeRatio(Number(v || 1))}
                    allowDecimal
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white font-mono-num"
                  />
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-3 space-y-2">
                  <label className="flex items-center gap-2 text-slate-200 font-bold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={volatilityFilterEnabled}
                      onChange={(e) => setVolatilityFilterEnabled(e.target.checked)}
                      className="accent-amber-400"
                    />
                    فیلتر نوسان شدید (حداکثر ATR%)
                  </label>
                  <NumericInput
                    disabled={!volatilityFilterEnabled}
                    value={volatilityFilterMaxAtrPercent}
                    onValueChange={(v) => setVolatilityFilterMaxAtrPercent(Number(v || 6))}
                    allowDecimal
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white font-mono-num"
                  />
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-3 space-y-2">
                  <label className="block text-slate-200 font-bold">حداقل امتیاز قدرت سیگنال (۰ تا ۱۰۰)</label>
                  <NumericInput
                    value={minSignalScore}
                    onValueChange={(v) => setMinSignalScore(Number(v || 50))}
                    allowDecimal={false}
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white font-mono-num"
                  />
                </div>
              </div>

              {/* Stop Loss / Multi-TP / Trailing Take Profit / Keep Runner */}
              <div className="rounded-xl border border-emerald-500/25 bg-slate-900/40 p-4 space-y-3 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="font-bold text-emerald-300">مدیریت پیشرفته فروش، چند هدف سود و نگهداری بخشی از دارایی</span>
                  <div className="flex items-center gap-3">
                    <label className="inline-flex items-center gap-1.5 text-slate-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={multiTpEnabled}
                        onChange={(e) => setMultiTpEnabled(e.target.checked)}
                        className="accent-emerald-400"
                      />
                      فروش پله‌ای چندهدفه
                    </label>
                    <label className="inline-flex items-center gap-1.5 text-amber-200 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={trailingTpEnabled}
                        onChange={(e) => setTrailingTpEnabled(e.target.checked)}
                        className="accent-amber-400"
                      />
                      حد سود متحرک
                    </label>
                  </div>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div>
                    <label className="block text-rose-300 mb-1">حد ضرر (%)</label>
                    <NumericInput
                      value={stopLossPercent}
                      onValueChange={(v) => setStopLossPercent(Number(v || 0))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-rose-300"
                    />
                  </div>
                  <div>
                    <label className="block text-emerald-300 mb-1">حد سود نهایی (%)</label>
                    <NumericInput
                      value={takeProfitPercent}
                      onValueChange={(v) => setTakeProfitPercent(Number(v || 0))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-emerald-300"
                    />
                  </div>
                  <div>
                    <label className="block text-amber-300 mb-1">حد ضرر متحرک (%)</label>
                    <NumericInput
                      value={trailingStopPercent}
                      onValueChange={(v) => setTrailingStopPercent(Number(v || 0))}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-amber-300"
                    />
                  </div>
                  <div>
                    <label className="block text-cyan-300 mb-1">نگهداری برای ادامه روند (%)</label>
                    <NumericInput
                      value={keepRunnerPercent}
                      onValueChange={(v) => setKeepRunnerPercent(Math.min(50, Math.max(0, Number(v || 0))))}
                      allowDecimal={false}
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-cyan-300"
                    />
                  </div>
                </div>

                {multiTpEnabled && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                    {takeProfitTargets.map((tp, idx) => (
                      <div
                        key={tp.id}
                        className="flex items-center gap-2 rounded-lg border border-slate-800 bg-slate-950 p-2"
                      >
                        <span className="text-slate-400">هدف {idx + 1}:</span>
                        <span className="text-emerald-300">+</span>
                        <NumericInput
                          value={tp.risePercent}
                          onValueChange={(v) =>
                            setTakeProfitTargets((prev) =>
                              prev.map((x) =>
                                x.id === tp.id ? { ...x, risePercent: Number(v || 0) } : x
                              )
                            )
                          }
                          className="w-16 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                        />
                        <span className="text-slate-400">٪ رشد · فروش</span>
                        <NumericInput
                          value={tp.sellPercent}
                          onValueChange={(v) =>
                            setTakeProfitTargets((prev) =>
                              prev.map((x) =>
                                x.id === tp.id ? { ...x, sellPercent: Number(v || 0) } : x
                              )
                            )
                          }
                          allowDecimal={false}
                          className="w-14 bg-slate-900 border border-slate-700 rounded px-2 py-1 text-white"
                        />
                        <span className="text-slate-400">٪</span>
                      </div>
                    ))}
                  </div>
                )}

                {trailingTpEnabled && (
                  <div className="grid grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-slate-400 mb-1">سود فعال‌سازی حد سود متحرک (%)</label>
                      <NumericInput
                        value={trailingTpActivation}
                        onValueChange={(v) => setTrailingTpActivation(Number(v || 1))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">حد برگشت از سقف برای فروش (%)</label>
                      <NumericInput
                        value={trailingTpCallback}
                        onValueChange={(v) => setTrailingTpCallback(Number(v || 0.5))}
                        className="w-full bg-slate-950 border border-slate-800 rounded-lg px-2.5 py-1.5 text-white"
                      />
                    </div>
                  </div>
                )}
              </div>

              {/* Entry Rules */}
              <div className="border-t border-slate-800 pt-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-3">
                    <h3 className="text-xs font-semibold text-emerald-400">شروط ورود (خرید)</h3>
                    <div className="flex items-center gap-1 bg-slate-950 p-0.5 rounded border border-slate-800 text-[11px]">
                      <button
                        type="button"
                        onClick={() => setLogicOperator('AND')}
                        className={`px-2 py-0.5 rounded ${
                          logicOperator === 'AND' ? 'bg-cyan-500 text-slate-950 font-semibold' : 'text-slate-400'
                        }`}
                      >
                        همه شرط‌ها (AND)
                      </button>
                      <button
                        type="button"
                        onClick={() => setLogicOperator('OR')}
                        className={`px-2 py-0.5 rounded ${
                          logicOperator === 'OR' ? 'bg-cyan-500 text-slate-950 font-semibold' : 'text-slate-400'
                        }`}
                      >
                        حداقل یک شرط (OR)
                      </button>
                    </div>
                  </div>

                  <select
                    value=""
                    onChange={(e) => {
                      if (e.target.value) addRule('ENTRY', e.target.value as RuleIndicatorType);
                    }}
                    className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-xs text-slate-200"
                  >
                    <option value="">+ افزودن شرط یا شکست مقاومت</option>
                    <option value="BREAKOUT_RESISTANCE">{RULE_LABELS.BREAKOUT_RESISTANCE}</option>
                    <option value="TREND_ALIGNMENT">{RULE_LABELS.TREND_ALIGNMENT}</option>
                    <option value="VOLATILITY_FILTER">{RULE_LABELS.VOLATILITY_FILTER}</option>
                    <option value="RSI_OVERSOLD">{RULE_LABELS.RSI_OVERSOLD}</option>
                    <option value="EMA_GOLDEN_CROSS">{RULE_LABELS.EMA_GOLDEN_CROSS}</option>
                    <option value="MACD_BULLISH_CROSS">{RULE_LABELS.MACD_BULLISH_CROSS}</option>
                    <option value="BB_LOWER_TOUCH">{RULE_LABELS.BB_LOWER_TOUCH}</option>
                    <option value="VOLUME_SPIKE">{RULE_LABELS.VOLUME_SPIKE}</option>
                  </select>
                </div>

                <div className="space-y-2">
                  {entryRules.map((rule) => (
                    <div
                      key={rule.id}
                      className="flex flex-wrap items-center justify-between gap-3 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={rule.enabled}
                          onChange={() =>
                            setEntryRules((prev) =>
                              prev.map((r) => (r.id === rule.id ? { ...r, enabled: !r.enabled } : r))
                            )
                          }
                          className="accent-emerald-500"
                        />
                        <span className="text-slate-200">{RULE_LABELS[rule.type]}</span>
                      </div>
                      <div className="flex items-center gap-2 font-mono-num">
                        {rule.type === 'RSI_OVERSOLD' && (
                          <NumericInput
                            allowDecimal={false}
                            value={rule.params.threshold ?? 35}
                            onValueChange={(v) =>
                              updateRuleParam('ENTRY', rule.id, 'threshold', v === '' ? 0 : Number(v))
                            }
                            className="w-16 bg-[#0A101D] border border-slate-700 rounded px-2 py-1 text-white"
                          />
                        )}
                        <button
                          type="button"
                          onClick={() => removeRule('ENTRY', rule.id)}
                          className="text-slate-500 hover:text-rose-400 p-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Exit Rules */}
              <div className="border-t border-slate-800 pt-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <h3 className="text-xs font-semibold text-rose-400">شروط خروج اندیکاتوری / شکست حمایت</h3>
                  <select
                    value=""
                    onChange={(e) => {
                      if (e.target.value) addRule('EXIT', e.target.value as RuleIndicatorType);
                    }}
                    className="bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-xs text-slate-200"
                  >
                    <option value="">+ افزودن شرط خروج</option>
                    <option value="BREAKDOWN_SUPPORT">{RULE_LABELS.BREAKDOWN_SUPPORT}</option>
                    <option value="RSI_OVERBOUGHT">{RULE_LABELS.RSI_OVERBOUGHT}</option>
                    <option value="EMA_DEATH_CROSS">{RULE_LABELS.EMA_DEATH_CROSS}</option>
                    <option value="MACD_BEARISH_CROSS">{RULE_LABELS.MACD_BEARISH_CROSS}</option>
                    <option value="BB_UPPER_TOUCH">{RULE_LABELS.BB_UPPER_TOUCH}</option>
                  </select>
                </div>
                <div className="space-y-2">
                  {exitRules.map((rule) => (
                    <div
                      key={rule.id}
                      className="flex flex-wrap items-center justify-between gap-3 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2 text-xs"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={rule.enabled}
                          onChange={() =>
                            setExitRules((prev) =>
                              prev.map((r) => (r.id === rule.id ? { ...r, enabled: !r.enabled } : r))
                            )
                          }
                          className="accent-rose-500"
                        />
                        <span className="text-slate-200">{RULE_LABELS[rule.type]}</span>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeRule('EXIT', rule.id)}
                        className="text-slate-500 hover:text-rose-400 p-1"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {mode === 'live' && (
                <label className="flex items-start gap-2 rounded-lg border border-amber-500/40 bg-amber-500/10 px-3 py-2 text-xs text-amber-200 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={confirmLiveBot}
                    onChange={(e) => setConfirmLiveBot(e.target.checked)}
                    className="mt-0.5 accent-amber-400 shrink-0"
                  />
                  <span>
                    تأیید می‌کنم این ربات در حالت واقعی (Live) با سرمایه واقعی حساب نوبیتکس من معامله کند.
                  </span>
                </label>
              )}

              {feedback && (
                <div
                  className={`text-xs px-3 py-2 rounded border ${
                    feedback.type === 'ok'
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                  }`}
                >
                  {feedback.text}
                </div>
              )}

              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => void handleBacktest()}
                  disabled={runningBacktest}
                  className="btn-glass btn-glass-ai inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-medium"
                >
                  <Activity className="w-4 h-4 text-cyan-400" />
                  <span>{runningBacktest ? 'در حال شبیه‌سازی...' : 'اجرای بک‌تست روی داده نوبیتکس'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => void handleCreate(true)}
                  disabled={creating}
                  className="btn-glass btn-glass-primary inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold"
                >
                  <Plus className="w-4 h-4" />
                  <span>{isAuthenticated ? 'ساخت و شروع ربات' : 'ورود و فعال‌سازی ربات'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => void handleCreate(false)}
                  disabled={creating}
                  className="btn-glass btn-glass-neutral px-4 py-2.5 rounded-xl text-xs font-medium"
                >
                  ذخیره به‌صورت متوقف
                </button>
              </div>
            </div>
          )}

          {/* Backtest Summary Card with Fees & Slippage */}
          {backtest && (
            <div className="glass-panel rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800/90 pb-3">
                <div>
                  <h3 className="text-sm font-semibold text-white">
                    نتیجه آزمایش استراتژی روی داده‌های واقعی نوبیتکس ({backtest.symbol})
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    بررسی‌شده روی {backtest.candlesTested} کندل اخیر با احتساب کارمزد و لغزش تخمینی
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
                <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-3">
                  <div className="text-slate-400 mb-1">سود / زیان خالص</div>
                  <div
                    dir="ltr"
                    className={`font-mono-num font-semibold text-sm ${
                      backtest.netProfitQuote >= 0 ? 'text-emerald-400' : 'text-rose-400'
                    }`}
                  >
                    {backtest.netProfitQuote >= 0 ? '+' : ''}
                    {formatQuoteAmount(backtest.netProfitQuote, backtest.quoteCurrency)}
                  </div>
                  <div className="text-[11px] font-mono-num text-slate-500" dir="ltr">
                    {formatPercent(backtest.netProfitPercent)}
                  </div>
                </div>
                <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-3">
                  <div className="text-slate-400 mb-1">نرخ موفقیت</div>
                  <div className="font-mono-num font-semibold text-sm text-white" dir="ltr">
                    {backtest.winRatePercent}%
                  </div>
                  <div className="text-[11px] font-mono-num text-slate-500" dir="ltr">
                    {backtest.winningTrades} برد / {backtest.losingTrades} باخت
                  </div>
                </div>
                <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-3">
                  <div className="text-slate-400 mb-1">حداکثر افت سرمایه</div>
                  <div className="font-mono-num font-semibold text-sm text-rose-400" dir="ltr">
                    -{backtest.maxDrawdownPercent}%
                  </div>
                </div>
                <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-3">
                  <div className="text-slate-400 mb-1">کارمزد کل معاملات</div>
                  <div className="font-mono-num font-semibold text-sm text-amber-300" dir="ltr">
                    {formatQuoteAmount(backtest.totalFeesPaidQuote || 0, backtest.quoteCurrency)}
                  </div>
                </div>
                <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-3">
                  <div className="text-slate-400 mb-1">لغزش تخمینی قیمت</div>
                  <div className="font-mono-num font-semibold text-sm text-cyan-300" dir="ltr">
                    {formatQuoteAmount(backtest.estimatedSlippageQuote || 0, backtest.quoteCurrency)}
                  </div>
                </div>
              </div>

              {equityPolyline && (
                <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-3">
                  <div className="flex justify-between text-[11px] text-slate-400 mb-2">
                    <span>نمودار تغییر سرمایه</span>
                    <span className="font-mono-num" dir="ltr">
                      {formatQuoteAmount(backtest.initialCapital, backtest.quoteCurrency)} →{' '}
                      {formatQuoteAmount(backtest.finalCapital, backtest.quoteCurrency)}
                    </span>
                  </div>
                  <svg viewBox="0 0 640 130" className="w-full h-32 block">
                    <polyline
                      fill="none"
                      stroke={backtest.netProfitQuote >= 0 ? '#10B981' : '#EF4444'}
                      strokeWidth="2"
                      points={equityPolyline}
                    />
                  </svg>
                </div>
              )}
            </div>
          )}

          {/* Strategy Bots List */}
          <div className="glass-panel rounded-xl overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-800/90 bg-[#060A14]/75 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-semibold text-white">
                  ربات‌های استراتژی شما ({strategyBots.length})
                </h3>
                <span className="text-xs text-slate-400">
                  پایش خودکار اندیکاتورها، شکست مقاومت و حد سود چندپله‌ای
                </span>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-xs">
                {onOpenTelegramSettings && (
                  <button
                    type="button"
                    onClick={onOpenTelegramSettings}
                    className="btn-glass btn-glass-neutral px-3 py-1.5 rounded-lg whitespace-nowrap"
                  >
                    {telegram?.configured && telegram.enabled ? 'تلگرام متصل' : 'اتصال تلگرام'}
                  </button>
                )}
              </div>
            </div>

            {telegramFeedback && (
              <div
                className={`mx-4 mt-3 text-xs px-3 py-2 rounded border ${
                  telegramFeedback.type === 'ok'
                    ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                    : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
                }`}
              >
                {telegramFeedback.text}
              </div>
            )}

            <div className="divide-y divide-slate-800">
              {strategyBots.length === 0 ? (
                <div className="p-10 text-center text-xs text-slate-500">
                  هنوز ربات استراتژی ساخته نشده است. از فرم بالا اولین ربات استراتژی خود را بسازید.
                </div>
              ) : (
                strategyBots.map((bot) => (
                  <div
                    key={bot.id}
                    className="p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4 hover:bg-slate-800/20"
                  >
                    <div className="space-y-1.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="text-sm font-semibold text-white">{bot.name}</span>
                        <span className="text-xs text-amber-300 font-mono-num" dir="ltr">
                          {bot.symbol} · {bot.timeframe} ·{' '}
                          {formatQuoteAmount(bot.orderAmount, bot.quoteCurrency)}
                        </span>
                        <span
                          className={`text-xs font-medium ${
                            bot.status === 'RUNNING' ? 'text-emerald-400' : 'text-amber-300'
                          }`}
                        >
                          {bot.status === 'RUNNING' ? 'فعال' : 'متوقف'}
                        </span>
                        <span className="text-xs text-cyan-400">
                          {bot.mode === 'live' ? 'حساب واقعی' : 'تمرینی'}
                        </span>
                      </div>
                      <div className="text-xs text-slate-300">{bot.lastSignalSummary}</div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2.5">
                      <div className="text-left pl-3 border-l border-slate-800 font-mono-num" dir="ltr">
                        <div className="text-[11px] text-slate-400">سود خالص</div>
                        <div
                          className={`text-sm font-semibold ${
                            bot.stats.realizedPnl >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {bot.stats.realizedPnl >= 0 ? '+' : ''}
                          {formatQuoteAmount(bot.stats.realizedPnl, bot.quoteCurrency)}
                        </div>
                      </div>

                      <button
                        type="button"
                        disabled={busyBotId === bot.id}
                        onClick={async () => {
                          setBusyBotId(bot.id);
                          try {
                            await onToggleBotStatus(
                              bot.id,
                              bot.status === 'RUNNING' ? 'PAUSED' : 'RUNNING'
                            );
                          } finally {
                            setBusyBotId(null);
                          }
                        }}
                        className={`btn-glass inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium ${
                          bot.status === 'RUNNING' ? 'btn-glass-amber' : 'btn-glass-buy'
                        }`}
                      >
                        {bot.status === 'RUNNING' ? (
                          <>
                            <Pause className="w-3.5 h-3.5" />
                            <span>توقف</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3.5 h-3.5" />
                            <span>شروع</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        disabled={busyBotId === bot.id}
                        onClick={async () => {
                          setBusyBotId(bot.id);
                          try {
                            await onEvaluateBotNow(bot.id);
                          } finally {
                            setBusyBotId(null);
                          }
                        }}
                        className="btn-glass btn-glass-sync inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-cyan-400" />
                        <span>بررسی الان</span>
                      </button>

                      {hasExchangeKeys &&
                        (bot.mode === 'paper' && pendingLiveBotId === bot.id ? (
                          <div className="flex items-center gap-1 rounded-lg border border-amber-500/45 bg-amber-500/10 px-2 py-1 text-[11px]">
                            <button
                              type="button"
                              onClick={async () => {
                                await onToggleBotMode(bot.id, 'live', true);
                                setPendingLiveBotId(null);
                              }}
                              className="px-2 py-0.5 rounded bg-emerald-500/25 text-emerald-200 font-semibold"
                            >
                              تأیید واقعی
                            </button>
                            <button
                              type="button"
                              onClick={() => setPendingLiveBotId(null)}
                              className="px-1.5 py-0.5 rounded bg-slate-800 text-slate-300"
                            >
                              لغو
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() =>
                              bot.mode === 'paper'
                                ? setPendingLiveBotId(bot.id)
                                : void onToggleBotMode(bot.id, 'paper')
                            }
                            className="btn-glass btn-glass-neutral px-2.5 py-1.5 rounded-lg text-xs"
                          >
                            {bot.mode === 'paper' ? 'واقعی' : 'تمرینی'}
                          </button>
                        ))}

                      {onSendBotReportToTelegram && (
                        <button
                          type="button"
                          onClick={async () => {
                            setSendingTelegramId(bot.id);
                            try {
                              await onSendBotReportToTelegram(bot.id);
                              setTelegramFeedback({ type: 'ok', text: `گزارش «${bot.name}» ارسال شد.` });
                            } finally {
                              setSendingTelegramId(null);
                            }
                          }}
                          className="btn-glass btn-glass-telegram p-1.5 rounded-lg"
                          title="ارسال به تلگرام"
                        >
                          <Send className="w-3.5 h-3.5" />
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => void onDeleteBot(bot.id)}
                        className="btn-glass btn-glass-sell p-1.5 rounded-lg"
                        title="حذف ربات"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>

          {/* Strategy Execution Logs */}
          <div className="glass-panel rounded-xl overflow-hidden">
            <div className="px-5 py-3 border-b border-slate-800/90 bg-[#060A14]/75 text-sm font-semibold text-white">
              گزارش عملکرد ربات‌های استراتژی
            </div>
            <div className="divide-y divide-slate-800/60 max-h-64 overflow-y-auto text-xs">
              {logs.length === 0 ? (
                <div className="p-6 text-center text-slate-500">هنوز گزارشی ثبت نشده است.</div>
              ) : (
                logs.map((l) => (
                  <div key={l.id} className="px-5 py-2.5 flex flex-wrap items-center justify-between gap-2">
                    <div className="flex items-center gap-2">
                      <Bot className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                      <span className="font-medium text-white">{l.botName}</span>
                      <span className="font-mono-num text-slate-400">({l.symbol})</span>
                      <span className="text-slate-300">{l.message}</span>
                    </div>
                    <span className="text-slate-500 font-mono-num" dir="ltr">
                      {formatDateTimeShort(l.timestamp)}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : (
        /* =================================================================
           DEFAULT HUB: «رباتهای معاملاتی من»
        ================================================================== */
        <div className="space-y-6" dir="rtl">
          {/* Hub Top Governance & Quick Actions Header */}
          <div className="rounded-2xl border border-cyan-500/25 bg-[#0A101D] p-4 sm:p-6 space-y-4">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="flex items-start sm:items-center gap-3.5">
                <img
                  src="/icon.svg"
                  alt="AI NobiBot — ainobibot.ir"
                  className="w-12 h-12 rounded-xl object-cover border border-cyan-500/40 bg-slate-950 p-1 shrink-0"
                />
                <div>
                  <h2 className="text-lg sm:text-xl font-extrabold text-white">
                    رباتهای معاملاتی من
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-400 mt-0.5 leading-6">
                    هر ربات صفحه و نمودار اختصاصی خودش را دارد. روی هر کارت بزنید تا وارد محیط ساده و مستقل آن ربات شوید.
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActivePage('UNIFIED_DASHBOARD')}
                  className="min-h-[44px] px-4 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-white text-xs sm:text-sm font-bold flex items-center gap-2 transition"
                >
                  <BarChart3 className="w-4 h-4 text-cyan-400" />
                  داشبورد یکپارچه
                </button>
                <button
                  type="button"
                  onClick={() => setActivePage('AI_MANAGER')}
                  className="min-h-[44px] px-4 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/45 text-cyan-200 text-xs sm:text-sm font-bold flex items-center gap-2 transition"
                >
                  <Cpu className="w-4 h-4 text-cyan-300" />
                  مدیر هوشمند AI
                  {pendingConfirmations.length > 0 && (
                    <span className="px-2 py-0.5 rounded-full bg-amber-500 text-slate-950 font-mono-num text-[11px] font-extrabold">
                      {pendingConfirmations.length}
                    </span>
                  )}
                </button>
              </div>
            </div>

            {/* Compact System Telemetry Strip */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 pt-2 border-t border-slate-800/80">
              <div className="rounded-xl border border-slate-800 bg-slate-900/50 px-3.5 py-2.5">
                <div className="text-[11px] text-slate-400">کل ربات‌های فعال</div>
                <div className="text-sm sm:text-base font-extrabold font-mono-num text-emerald-300 mt-0.5">
                  {totalActiveBotsCount} ربات فعال
                </div>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-900/50 px-3.5 py-2.5">
                <div className="text-[11px] text-slate-400">بودجه آزاد مشترک (تومانی)</div>
                <div className="text-sm sm:text-base font-extrabold font-mono-num text-cyan-300 mt-0.5">
                  {formatToman(Math.round(effectiveDashboard.freeBudgetIrt))} ت
                </div>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-900/50 px-3.5 py-2.5">
                <div className="text-[11px] text-slate-400">سود تحقق‌یافته روزانه</div>
                <div
                  className={`text-sm sm:text-base font-extrabold font-mono-num mt-0.5 ${
                    effectiveDashboard.realizedPnlDailyIrt >= 0
                      ? 'text-emerald-300'
                      : 'text-rose-300'
                  }`}
                >
                  {effectiveDashboard.realizedPnlDailyIrt >= 0 ? '+' : '-'}
                  {formatToman(Math.abs(Math.round(effectiveDashboard.realizedPnlDailyIrt)))} ت
                </div>
              </div>
              <div className="rounded-xl border border-slate-800 bg-slate-900/50 px-3.5 py-2.5">
                <div className="text-[11px] text-slate-400">در انتظار تأیید دستی</div>
                <div
                  className={`text-sm sm:text-base font-extrabold font-mono-num mt-0.5 ${
                    pendingConfirmations.length > 0 ? 'text-amber-300' : 'text-slate-200'
                  }`}
                >
                  {pendingConfirmations.length} سفارش
                </div>
              </div>
            </div>

            {riskSettings.killSwitchActive && (
              <div className="rounded-xl border border-rose-500/45 bg-rose-500/15 px-4 py-3 text-xs text-rose-100 flex items-center justify-between gap-3">
                <span className="flex items-center gap-2 font-bold">
                  <AlertTriangle className="w-4 h-4 text-rose-400" />
                  قفل توقف اضطراری (Kill Switch) روشن است؛ برای شروع مجدد ربات‌ها به صفحه مدیر هوشمند بروید.
                </span>
                <button
                  type="button"
                  onClick={() => setActivePage('AI_MANAGER')}
                  className="px-3 py-1.5 rounded-lg bg-rose-600 text-white font-bold shrink-0"
                >
                  مدیریت قفل
                </button>
              </div>
            )}
          </div>

          {/* Pending Confirmations Alert on Hub */}
          {pendingConfirmations.length > 0 && (
            <div className="rounded-2xl border border-amber-500/40 bg-amber-500/10 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-amber-200 font-bold">
                <Hand className="w-4 h-4 text-amber-400 shrink-0" />
                <span>
                  {pendingConfirmations.length} سفارش پیشنهادی در حالت «تأیید دستی» منتظر بررسی و تایید شماست.
                </span>
              </div>
              <button
                type="button"
                onClick={() => setActivePage('AI_MANAGER')}
                className="min-h-[40px] px-4 rounded-xl bg-amber-500 text-slate-950 font-extrabold shrink-0"
              >
                مشاهده و تایید سفارش‌ها
              </button>
            </div>
          )}

          {/* Featured Beginner AI Bot: AI Cycle Pro */}
          <div className="rounded-2xl border border-cyan-500/40 bg-gradient-to-l from-[#0A1426] via-[#0B172B] to-[#0A101D] p-5 relative overflow-hidden">
            <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-cyan-400 via-teal-400 to-emerald-400" />
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
              <div className="space-y-2">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-md border border-cyan-400/50 bg-cyan-500/15 text-cyan-200 text-[11px] font-extrabold">
                    جدید · ویژه مبتدی‌ها
                  </span>
                  <span className="text-xs font-mono-num text-emerald-300 font-bold">
                    {aiCycleProBots.filter((b) => b.isActive).length} فعال / {aiCycleProBots.length} کل
                  </span>
                </div>
                <h4 className="text-base sm:text-lg font-extrabold text-white flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-cyan-300" />
                  AI Cycle Pro | ربات چرخه هوشمند
                </h4>
                <p className="text-xs text-slate-300 leading-6 max-w-3xl">
                  فقط ارز، مبلغ سرمایه و حالت اجرا را مشخص کنید؛ هوش مصنوعی Gemini همراه با داده‌های زنده دفتر سفارش نوبیتکس، خرید، هدف سود خالص پس از کارمزد و لغزش، حد ضرر و شروع چرخه بعدی را کامل مدیریت می‌کند. اگر بازار مناسب نباشد سرمایه نقد می‌ماند.
                </p>
              </div>

              <div className="flex flex-wrap items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => setActivePage('AI_CYCLE_PRO')}
                  className="min-h-[46px] px-5 rounded-xl bg-gradient-to-l from-cyan-500 to-emerald-500 hover:brightness-110 text-slate-950 text-xs font-extrabold whitespace-nowrap transition"
                >
                  ورود به AI Cycle Pro
                </button>
                <button
                  type="button"
                  onClick={() => setGuideTopic('AI_CYCLE_PRO')}
                  className="min-h-[46px] px-3.5 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold flex items-center gap-1.5 whitespace-nowrap"
                >
                  <BookOpen className="w-4 h-4 text-cyan-300" />
                  راهنما
                </button>
              </div>
            </div>
          </div>

          {/* Category A: ربات‌های سود روزانه */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-sm sm:text-base font-extrabold text-emerald-300">
                الف) ربات‌های سود روزانه و نوسان‌گیری سریع
              </h3>
              <span className="text-[11px] text-slate-400">مناسب فرصت‌های کوتاه‌مدت و بازار رِنج</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Profit Bot Card */}
              <div className="rounded-2xl border border-emerald-500/30 bg-[#0A101D] p-5 flex flex-col justify-between gap-4 relative overflow-hidden">
                <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-emerald-400 to-teal-500" />
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/35 flex items-center justify-center text-emerald-300">
                      <TrendingUp className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono-num text-emerald-300 font-bold">
                      {profitBots.filter((b) => b.isActive).length} فعال / {profitBots.length} کل
                    </span>
                  </div>
                  <h4 className="text-base font-extrabold text-white">ربات سود (Profit Bot)</h4>
                  <p className="text-xs text-slate-300 leading-6">
                    تعیین سود خالص هدف به تومان یا تتر؛ ربات کارمزد واقعی خرید، فروش و عمق بازار را حساب می‌کند و سر سود دلخواه می‌فروشد.
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => setActivePage('PROFIT_BOT')}
                    className="flex-1 min-h-[44px] rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-extrabold transition"
                  >
                    ورود به صفحه ربات
                  </button>
                  <button
                    type="button"
                    onClick={() => setGuideTopic('PROFIT')}
                    className="min-h-[44px] px-3 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold flex items-center gap-1"
                  >
                    <BookOpen className="w-4 h-4 text-cyan-300" />
                    راهنما
                  </button>
                </div>
              </div>

              {/* Fixed Price Card */}
              <div className="rounded-2xl border border-teal-500/30 bg-[#0A101D] p-5 flex flex-col justify-between gap-4 relative overflow-hidden">
                <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-teal-400 to-cyan-500" />
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-teal-500/15 border border-teal-500/35 flex items-center justify-center text-teal-300">
                      <Target className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono-num text-teal-300 font-bold">
                      {fixedBots.filter((b) => b.status === 'RUNNING').length} فعال / {fixedBots.length} کل
                    </span>
                  </div>
                  <h4 className="text-base font-extrabold text-white">ربات قیمت ثابت</h4>
                  <p className="text-xs text-slate-300 leading-6">
                    قیمت خرید و فروش دقیق خود را بدهید (یا از موجودی قبلی‌تان استفاده کنید)؛ ربات هر چند ثانیه بازار را چک و معامله می‌کند.
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => setActivePage('FIXED_PRICE')}
                    className="flex-1 min-h-[44px] rounded-xl bg-teal-600 hover:bg-teal-500 text-white text-xs font-extrabold transition"
                  >
                    ورود به صفحه ربات
                  </button>
                  <button
                    type="button"
                    onClick={() => setGuideTopic('FIXED_PRICE')}
                    className="min-h-[44px] px-3 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold flex items-center gap-1"
                  >
                    <BookOpen className="w-4 h-4 text-cyan-300" />
                    راهنما
                  </button>
                </div>
              </div>

              {/* Grid Bot Card */}
              <div className="rounded-2xl border border-amber-500/30 bg-[#0A101D] p-5 flex flex-col justify-between gap-4 relative overflow-hidden">
                <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-amber-400 to-orange-500" />
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/35 flex items-center justify-center text-amber-300">
                      <Grid className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono-num text-amber-300 font-bold">
                      {gridBots.filter((b) => b.isActive).length} فعال / {gridBots.length} کل
                    </span>
                  </div>
                  <h4 className="text-base font-extrabold text-white">ربات گرید (Grid Bot)</h4>
                  <p className="text-xs text-slate-300 leading-6">
                    ساخت پله‌های خرید در پایین و فروش در بالا داخل بازه قیمتی؛ مناسب بازارهای رِنج با محاسبه سود خالص هر چرخه و توقف خروج از محدوده.
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => setActivePage('GRID')}
                    className="flex-1 min-h-[44px] rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-extrabold transition"
                  >
                    ورود به صفحه ربات
                  </button>
                  <button
                    type="button"
                    onClick={() => setGuideTopic('GRID')}
                    className="min-h-[44px] px-3 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold flex items-center gap-1"
                  >
                    <BookOpen className="w-4 h-4 text-cyan-300" />
                    راهنما
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Category B: ربات‌های میان‌مدت */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-sm sm:text-base font-extrabold text-sky-300">
                ب) ربات‌های میان‌مدت، روندی و پله‌ای
              </h3>
              <span className="text-[11px] text-slate-400">مناسب صبر روی روندها و اصلاح قیمت</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* DCA Bot Card */}
              <div className="rounded-2xl border border-sky-500/30 bg-[#0A101D] p-5 flex flex-col justify-between gap-4 relative overflow-hidden">
                <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-sky-400 to-cyan-500" />
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-sky-500/15 border border-sky-500/35 flex items-center justify-center text-sky-300">
                      <Layers className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono-num text-sky-300 font-bold">
                      {dcaBots.filter((b) => b.isActive).length} فعال / {dcaBots.length} کل
                    </span>
                  </div>
                  <h4 className="text-base font-extrabold text-white">ربات خرید پله‌ای (DCA Bot)</h4>
                  <p className="text-xs text-slate-300 leading-6">
                    تقسیم سرمایه در چند مرحله خرید زمانی یا هنگام افت قیمت برای کاهش میانگین خرید، همراه با فروش چندهدفه، حد سود متحرک و دکمه توقف خریدهای جدید.
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => setActivePage('DCA')}
                    className="flex-1 min-h-[44px] rounded-xl bg-sky-600 hover:bg-sky-500 text-white text-xs font-extrabold transition"
                  >
                    ورود به صفحه ربات
                  </button>
                  <button
                    type="button"
                    onClick={() => setGuideTopic('DCA')}
                    className="min-h-[44px] px-3 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold flex items-center gap-1"
                  >
                    <BookOpen className="w-4 h-4 text-cyan-300" />
                    راهنما
                  </button>
                </div>
              </div>

              {/* Strategy Bot Card */}
              <div className="rounded-2xl border border-indigo-500/30 bg-[#0A101D] p-5 flex flex-col justify-between gap-4 relative overflow-hidden">
                <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-l from-indigo-400 to-violet-500" />
                <div className="space-y-2.5">
                  <div className="flex items-center justify-between">
                    <div className="w-10 h-10 rounded-xl bg-indigo-500/15 border border-indigo-500/35 flex items-center justify-center text-indigo-300">
                      <SlidersHorizontal className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-mono-num text-indigo-300 font-bold">
                      {strategyBots.filter((b) => b.status === 'RUNNING').length} فعال / {strategyBots.length} کل
                    </span>
                  </div>
                  <h4 className="text-base font-extrabold text-white">ربات استراتژی تکنیکال</h4>
                  <p className="text-xs text-slate-300 leading-6">
                    تشخیص شکست مقاومت/حمایت با تایید حجم، RSI، EMA، MACD، فیلتر نوسان شدید، فروش پله‌ای، نگهداری بخشی از دارایی و بک‌تست روی کندل‌های واقعی.
                  </p>
                </div>
                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <button
                    type="button"
                    onClick={() => setActivePage('STRATEGY')}
                    className="flex-1 min-h-[44px] rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-extrabold transition"
                  >
                    ورود به صفحه ربات
                  </button>
                  <button
                    type="button"
                    onClick={() => setGuideTopic('STRATEGY')}
                    className="min-h-[44px] px-3 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold flex items-center gap-1"
                  >
                    <BookOpen className="w-4 h-4 text-cyan-300" />
                    راهنما
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Category C: ابزارهای هوشمند و نظارتی */}
          <div className="space-y-3">
            <div className="flex items-center justify-between px-1">
              <h3 className="text-sm sm:text-base font-extrabold text-cyan-300">
                ج) هوش مصنوعی مرکزی و مدیریت یکپارچه ریسک
              </h3>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="rounded-2xl border border-cyan-500/30 bg-[#0A101D] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-xl bg-cyan-500/15 border border-cyan-500/35 flex items-center justify-center text-cyan-300 shrink-0">
                    <Sparkles className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm sm:text-base font-extrabold text-white">مدیر هوشمند مرکزی (AI Manager)</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-6">
                      تحلیل وضعیت بازار، پیشنهاد ربات مناسب، کنترل تداخل ارزها، تنظیم بودجه مشترک و کلید توقف اضطراری.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActivePage('AI_MANAGER')}
                  className="min-h-[44px] px-4 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-extrabold shrink-0"
                >
                  باز کردن
                </button>
              </div>

              <div className="rounded-2xl border border-slate-700/80 bg-[#0A101D] p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-start gap-3">
                  <div className="w-11 h-11 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-300 shrink-0">
                    <BarChart3 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm sm:text-base font-extrabold text-white">داشبورد یکپارچه همه ربات‌ها</h4>
                    <p className="text-xs text-slate-400 mt-1 leading-6">
                      مشاهده یکجای سود روزانه/هفتگی/ماهانه، سرمایه آزاد، کارمزد کل و مقایسه عملکرد تمام ربات‌ها.
                    </p>
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setActivePage('UNIFIED_DASHBOARD')}
                  className="min-h-[44px] px-4 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-white text-xs font-extrabold shrink-0"
                >
                  مشاهده گزارش
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
