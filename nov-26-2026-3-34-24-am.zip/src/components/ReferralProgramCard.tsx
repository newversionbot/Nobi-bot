import React, { useState } from 'react';
import { Check, Copy, Gift, Link2, Share2, UserPlus, Users } from 'lucide-react';
import type { UserReferralSummary } from '../types/trading';
import { formatDateTimeShort } from '../utils/format';

interface ReferralProgramCardProps {
  referral: UserReferralSummary | null;
  isAuthenticated: boolean;
  onSignIn: () => Promise<void>;
  onClaimReferralCode: (code: string) => Promise<{
    claimed: boolean;
    alreadyLinked: boolean;
    message: string;
  }>;
  compact?: boolean;
}

export const ReferralProgramCard: React.FC<ReferralProgramCardProps> = ({
  referral,
  isAuthenticated,
  onSignIn,
  onClaimReferralCode,
  compact = false,
}) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [claiming, setClaiming] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  const origin =
    typeof window !== 'undefined' ? window.location.origin : 'https://ainobibot.ir';
  const inviteUrl = referral?.referralCode
    ? `${origin}/?ref=${encodeURIComponent(referral.referralCode)}`
    : '';

  const copyText = async (val: string, kind: 'link' | 'code') => {
    if (!val) return;
    try {
      await navigator.clipboard.writeText(val);
      if (kind === 'link') {
        setCopiedLink(true);
        setTimeout(() => setCopiedLink(false), 1800);
      } else {
        setCopiedCode(true);
        setTimeout(() => setCopiedCode(false), 1800);
      }
    } catch {
      // Ignore clipboard failures
    }
  };

  const handleShare = async () => {
    if (!inviteUrl || typeof navigator === 'undefined' || !navigator.share) return;
    try {
      await navigator.share({
        title: 'دعوت به پلتفرم معاملاتی AI NobiBot (ainobibot.ir)',
        text: `با لینک دعوت من عضو AI NobiBot شو و از تحلیل هوش مصنوعی و ربات معامله‌گر نوبیتکس استفاده کن (کد دعوت: ${referral?.referralCode}):`,
        url: inviteUrl,
      });
    } catch {
      // Ignore user cancel
    }
  };

  const handleManualSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualCode.trim()) return;
    setClaiming(true);
    setFeedback(null);
    try {
      const res = await onClaimReferralCode(manualCode.trim());
      setManualCode('');
      setFeedback({ type: 'ok', text: res.message });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ثبت کد معرف',
      });
    } finally {
      setClaiming(false);
    }
  };

  const canWebShare = typeof navigator !== 'undefined' && typeof navigator.share === 'function';

  return (
    <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden text-xs">
      {/* Header Row */}
      <div className="px-5 py-4 border-b border-slate-800 bg-[#060A14] flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-emerald-500/15 border border-emerald-500/40 flex items-center justify-center shrink-0">
            <Gift className="w-4 h-4 text-emerald-400" />
          </div>
          <div>
            <h3 className="text-sm font-semibold text-white">
              دعوت از دوستان — ۴ روز اشتراک رایگان برای هر دعوت موفق
            </h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              لینک اختصاصی خود را بفرستید؛ هر دوستی که وارد شود و اشتراک بخرد، ۴ روز استفاده رایگان خودکار به حساب شما اضافه می‌شود.
            </p>
          </div>
        </div>

        {isAuthenticated && referral && (
          <div className="text-[11px] text-emerald-300 font-medium whitespace-nowrap shrink-0">
            پاداش هر خرید: <span className="font-mono-num font-bold">+۴</span> روز رایگان
          </div>
        )}
      </div>

      {!isAuthenticated || !referral ? (
        <div className="p-6 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="text-sm font-semibold text-white">
              برای دریافت لینک دعوت اختصاصی وارد شوید
            </div>
            <p className="text-xs text-slate-400">
              پس از ورود با گوگل، لینک اختصاصی شما ساخته می‌شود و می‌توانید تعداد دعوت‌ها و پاداش ۴ روزه هر خرید را همین‌جا ببینید.
            </p>
          </div>
          <button
            type="button"
            onClick={() => void onSignIn()}
            className="px-4 py-2 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors whitespace-nowrap shrink-0"
          >
            ورود با گوگل و دریافت لینک دعوت
          </button>
        </div>
      ) : (
        <div>
          {/* Invite Link & Code Controls */}
          <div className="p-5 space-y-3 bg-[#0A101D]">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-slate-300 font-medium inline-flex items-center gap-1.5">
                <Link2 className="w-3.5 h-3.5 text-cyan-400" />
                <span>لینک اختصاصی دعوت شما:</span>
              </span>
              <button
                type="button"
                onClick={() => void copyText(referral.referralCode, 'code')}
                className="inline-flex items-center gap-1.5 text-[11px] text-slate-400 hover:text-cyan-300 transition-colors whitespace-nowrap shrink-0"
              >
                <span>کد معرف:</span>
                <span className="font-mono-num text-white font-semibold" dir="ltr">
                  {referral.referralCode}
                </span>
                {copiedCode ? (
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                ) : (
                  <Copy className="w-3.5 h-3.5" />
                )}
              </button>
            </div>

            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
              <div
                className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-2.5 font-mono-num text-xs text-cyan-300 truncate select-all"
                dir="ltr"
              >
                {inviteUrl}
              </div>

              <div className="flex items-center gap-2 shrink-0">
                <button
                  type="button"
                  onClick={() => void copyText(inviteUrl, 'link')}
                  className="flex-1 sm:flex-none inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors whitespace-nowrap shrink-0"
                >
                  {copiedLink ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>لینک کپی شد</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>کپی لینک دعوت</span>
                    </>
                  )}
                </button>

                {canWebShare && (
                  <button
                    type="button"
                    onClick={() => void handleShare()}
                    className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-700 hover:border-cyan-500/50 text-slate-200 transition-colors whitespace-nowrap shrink-0"
                  >
                    <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>اشتراک‌گذاری</span>
                  </button>
                )}
              </div>
            </div>
          </div>

          {/* 4-Metric Hairline Strip (Single Elevation) */}
          <div className="grid grid-cols-2 sm:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x sm:divide-x-reverse divide-slate-800 border-y border-slate-800 bg-slate-950/70">
            <div className="p-3.5">
              <div className="text-[11px] text-slate-400">تعداد دعوت‌های شما</div>
              <div className="text-lg font-semibold font-mono-num text-white mt-0.5" dir="ltr">
                {referral.totalInvitedCount} <span className="text-xs font-normal text-slate-400">نفر</span>
              </div>
            </div>
            <div className="p-3.5">
              <div className="text-[11px] text-slate-400">خرید اشتراک موفق</div>
              <div className="text-lg font-semibold font-mono-num text-emerald-400 mt-0.5" dir="ltr">
                {referral.convertedCount} <span className="text-xs font-normal text-slate-400">نفر</span>
              </div>
            </div>
            <div className="p-3.5">
              <div className="text-[11px] text-slate-400">در انتظار خرید اشتراک</div>
              <div className="text-lg font-semibold font-mono-num text-amber-300 mt-0.5" dir="ltr">
                {referral.pendingConversionCount} <span className="text-xs font-normal text-slate-400">نفر</span>
              </div>
            </div>
            <div className="p-3.5">
              <div className="text-[11px] text-slate-400">کل پاداش دریافت‌شده</div>
              <div className="text-lg font-semibold font-mono-num text-cyan-300 mt-0.5" dir="ltr">
                +{referral.totalBonusDaysEarned}{' '}
                <span className="text-xs font-normal text-slate-400">روز رایگان</span>
              </div>
            </div>
          </div>

          {/* Invited Friends Status List */}
          <div className="bg-[#0A101D]">
            <div className="px-5 py-3 border-b border-slate-800/80 flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-200 inline-flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-cyan-400" />
                <span>وضعیت دوستان دعوت‌شده ({referral.invites.length})</span>
              </span>
              <span className="text-[11px] text-slate-400">
                تمدید خودکار +۴ روز روی اشتراک فعلی شما
              </span>
            </div>

            {referral.invites.length === 0 ? (
              <div className="px-5 py-6 text-center text-slate-400 space-y-1">
                <div>هنوز کاربری با لینک دعوت شما وارد نشده است.</div>
                <div className="text-[11px] text-slate-500">
                  لینک بالا را در تلگرام، واتساپ یا برای دوستان معامله‌گر خود بفرستید تا به ازای هر خرید اشتراک، ۴ روز هدیه رایگان بگیرید.
                </div>
              </div>
            ) : (
              <div
                className={`divide-y divide-slate-800/80 ${compact ? 'max-h-52' : 'max-h-72'} overflow-y-auto`}
              >
                {referral.invites.map((inv) => (
                  <div
                    key={inv.id}
                    className="px-5 py-3 flex flex-wrap items-center justify-between gap-2 hover:bg-slate-950/60 transition-colors"
                  >
                    <div className="space-y-0.5 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-medium text-white">{inv.referredDisplayName}</span>
                        <span className="font-mono-num text-[11px] text-slate-500" dir="ltr">
                          ({inv.referredMaskedEmail})
                        </span>
                      </div>
                      <div className="text-[11px] font-mono-num text-slate-500" dir="ltr">
                        عضویت: {formatDateTimeShort(inv.joinedAt)}
                        {inv.rewardedAt ? ` · زمان خرید: ${formatDateTimeShort(inv.rewardedAt)}` : ''}
                      </div>
                    </div>

                    <div className="text-[11px] font-medium whitespace-nowrap shrink-0">
                      {inv.status === 'REWARDED' ? (
                        <span className="text-emerald-400">
                          اشتراک خریداری شد · +{inv.rewardDays} روز رایگان واریز شد
                        </span>
                      ) : (
                        <span className="text-amber-300">عضو شده · در انتظار خرید اشتراک</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Optional Manual Referral Code Claim */}
          {(referral.referredByCode || referral.canClaimManualCode) && (
            <div className="px-5 py-3.5 border-t border-slate-800 bg-slate-950/60">
              {referral.referredByCode ? (
                <div className="text-[11px] text-slate-400 flex flex-wrap items-center gap-1.5">
                  <UserPlus className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                  <span>حساب شما با کد دعوت</span>
                  <span className="font-mono-num text-emerald-300 font-semibold" dir="ltr">
                    {referral.referredByCode}
                  </span>
                  <span>ثبت شده است.</span>
                </div>
              ) : (
                <form
                  onSubmit={(e) => void handleManualSubmit(e)}
                  className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5"
                >
                  <label className="text-[11px] text-slate-400 shrink-0">
                    اگر دوستتان کد معرف به شما داده است (پیش از خرید اشتراک):
                  </label>
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={manualCode}
                      onChange={(e) => setManualCode(e.target.value)}
                      placeholder="مثلاً ALI-X7K9P2"
                      dir="ltr"
                      className="bg-[#0A101D] border border-slate-700 rounded-md px-3 py-1.5 text-xs font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400 uppercase w-40"
                    />
                    <button
                      type="submit"
                      disabled={claiming || !manualCode.trim()}
                      className="px-3 py-1.5 rounded-md text-xs font-semibold bg-slate-800 hover:bg-cyan-500 hover:text-slate-950 text-white transition-colors disabled:opacity-40 whitespace-nowrap shrink-0"
                    >
                      {claiming ? 'در حال ثبت...' : 'ثبت کد معرف'}
                    </button>
                  </div>
                </form>
              )}

              {feedback && (
                <div
                  className={`mt-2 text-[11px] ${
                    feedback.type === 'ok' ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {feedback.text}
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </section>
  );
};
