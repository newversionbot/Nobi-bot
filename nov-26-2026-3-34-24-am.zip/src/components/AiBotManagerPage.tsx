import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  Bot,
  CheckCircle2,
  Cpu,
  Flame,
  Hand,
  PauseCircle,
  Power,
  RefreshCw,
  ShieldAlert,
  ShieldCheck,
  Sparkles,
  TrendingUp,
} from 'lucide-react';
import type {
  AiManagerAnalysis,
  BotType,
  PendingBotConfirmation,
  SharedBotRiskSettings,
  UnifiedBotsDashboardSummary,
} from '../types/trading';
import { formatDateTimeShort, formatToman } from '../utils/format';
import { NumericInput } from './NumericInput';
import {
  BotPageShell,
  type BotPageKpi,
  type DedicatedBotTabId,
} from './BotPageShell';
import type { GuideBotTopic } from './BotEducationModal';

interface AiBotManagerPageProps {
  isAuthenticated: boolean;
  demoMode: boolean;
  riskSettings: SharedBotRiskSettings;
  pendingConfirmations: PendingBotConfirmation[];
  aiReport: AiManagerAnalysis | null;
  dashboardSummary: UnifiedBotsDashboardSummary;
  onBack: () => void;
  onOpenGuide: (topic: GuideBotTopic) => void;
  onRequireAuth: () => void;
  onRunAiAnalysis: () => Promise<void>;
  onUpdateRiskSettings: (updates: Partial<SharedBotRiskSettings>) => Promise<void>;
  onToggleKillSwitch: (active: boolean) => Promise<void>;
  onResolveConfirmation: (conf: PendingBotConfirmation, decision: 'APPROVE' | 'REJECT') => Promise<void>;
  onNavigateToBot: (botType: BotType, baseAsset?: string) => void;
  onStopBotByType?: (botType: BotType, botId: string) => Promise<void>;
}

const BOT_TYPE_LABELS_FA: Record<BotType, string> = {
  AI_CYCLE_PRO: 'AI Cycle Pro | ربات چرخه هوشمند',
  PROFIT: 'ربات سود',
  FIXED_PRICE: 'ربات قیمت ثابت',
  GRID: 'ربات گرید',
  DCA: 'ربات خرید پله‌ای (DCA)',
  STRATEGY: 'ربات استراتژی',
};

export const AiBotManagerPage: React.FC<AiBotManagerPageProps> = ({
  isAuthenticated,
  demoMode,
  riskSettings,
  pendingConfirmations,
  aiReport,
  dashboardSummary,
  onBack,
  onOpenGuide,
  onRequireAuth,
  onRunAiAnalysis,
  onUpdateRiskSettings,
  onToggleKillSwitch,
  onResolveConfirmation,
  onNavigateToBot,
  onStopBotByType,
}) => {
  const [activeTab, setActiveTab] = useState<DedicatedBotTabId>('OVERVIEW');
  const [runningAi, setRunningAi] = useState(false);
  const [savingRisk, setSavingRisk] = useState(false);
  const [togglingKill, setTogglingKill] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  // Editable Shared Risk Settings form state
  const [totalBudgetIrt, setTotalBudgetIrt] = useState(riskSettings.totalBotsBudgetIrt);
  const [totalBudgetUsdt, setTotalBudgetUsdt] = useState(riskSettings.totalBotsBudgetUsdt);
  const [maxPerBotIrt, setMaxPerBotIrt] = useState(riskSettings.maxPerBotCapitalIrt);
  const [maxPerBotUsdt, setMaxPerBotUsdt] = useState(riskSettings.maxPerBotCapitalUsdt);
  const [maxDailyLossIrt, setMaxDailyLossIrt] = useState(riskSettings.maxDailyLossIrt);
  const [maxDailyLossUsdt, setMaxDailyLossUsdt] = useState(riskSettings.maxDailyLossUsdt);
  const [maxTotalLossIrt, setMaxTotalLossIrt] = useState(riskSettings.maxTotalLossIrt);
  const [maxTotalLossUsdt, setMaxTotalLossUsdt] = useState(riskSettings.maxTotalLossUsdt);
  const [conflictLock, setConflictLock] = useState(riskSettings.enableSymbolConflictLock);

  useEffect(() => {
    setTotalBudgetIrt(riskSettings.totalBotsBudgetIrt);
    setTotalBudgetUsdt(riskSettings.totalBotsBudgetUsdt);
    setMaxPerBotIrt(riskSettings.maxPerBotCapitalIrt);
    setMaxPerBotUsdt(riskSettings.maxPerBotCapitalUsdt);
    setMaxDailyLossIrt(riskSettings.maxDailyLossIrt);
    setMaxDailyLossUsdt(riskSettings.maxDailyLossUsdt);
    setMaxTotalLossIrt(riskSettings.maxTotalLossIrt);
    setMaxTotalLossUsdt(riskSettings.maxTotalLossUsdt);
    setConflictLock(riskSettings.enableSymbolConflictLock);
  }, [riskSettings]);

  const handleRunAnalysis = async () => {
    setFeedback(null);
    if (!isAuthenticated && !demoMode) {
      onRequireAuth();
      return;
    }
    setRunningAi(true);
    try {
      await onRunAiAnalysis();
      setFeedback({ type: 'ok', text: 'تحلیل جدید مدیر هوشمند مرکزی بر اساس بازار زنده نوبیتکس و ربات‌های شما ثبت شد.' });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'خطا در تحلیل هوش مصنوعی' });
    } finally {
      setRunningAi(false);
    }
  };

  const handleSaveRisk = async () => {
    setFeedback(null);
    if (!isAuthenticated && !demoMode) {
      onRequireAuth();
      return;
    }
    setSavingRisk(true);
    try {
      await onUpdateRiskSettings({
        totalBotsBudgetIrt: Math.max(0, totalBudgetIrt),
        totalBotsBudgetUsdt: Math.max(0, totalBudgetUsdt),
        maxPerBotCapitalIrt: Math.max(0, maxPerBotIrt),
        maxPerBotCapitalUsdt: Math.max(0, maxPerBotUsdt),
        maxDailyLossIrt: Math.max(0, maxDailyLossIrt),
        maxDailyLossUsdt: Math.max(0, maxDailyLossUsdt),
        maxTotalLossIrt: Math.max(0, maxTotalLossIrt),
        maxTotalLossUsdt: Math.max(0, maxTotalLossUsdt),
        enableSymbolConflictLock: conflictLock,
        allowAiAdvisoryOnly: true,
      });
      setFeedback({ type: 'ok', text: 'سقف سرمایه مشترک و محدودیت‌های ریسک ذخیره شد. هوش مصنوعی نمی‌تواند این اعداد را تغییر دهد.' });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'خطا در ذخیره تنظیمات ریسک' });
    } finally {
      setSavingRisk(false);
    }
  };

  const handleKillSwitch = async (nextActive: boolean) => {
    setFeedback(null);
    if (!isAuthenticated && !demoMode) {
      onRequireAuth();
      return;
    }
    setTogglingKill(true);
    try {
      await onToggleKillSwitch(nextActive);
      setFeedback({
        type: nextActive ? 'err' : 'ok',
        text: nextActive
          ? 'کلید توقف اضطراری فعال شد و همه ربات‌های فعال متوقف شدند.'
          : 'کلید توقف اضطراری غیرفعال شد؛ اکنون می‌توانید ربات‌های مورد نظر را دوباره روشن کنید.',
      });
    } catch (err) {
      setFeedback({ type: 'err', text: err instanceof Error ? err.message : 'خطا در تغییر وضعیت کلید اضطراری' });
    } finally {
      setTogglingKill(false);
    }
  };

  const kpis: BotPageKpi[] = [
    {
      label: 'وضعیت فعلی بازار',
      value: aiReport?.regimeLabelFa || 'در انتظار تحلیل',
      subtext: aiReport?.usedFallback ? 'پایش داخلی بازار' : 'تحلیل هوشمند Gemini',
      tone: aiReport?.regime === 'BULLISH' ? 'positive' : aiReport?.regime === 'BEARISH' ? 'negative' : 'accent',
    },
    {
      label: 'بودجه آزاد تومانی',
      value: `${formatToman(dashboardSummary.freeBudgetIrt)} ت`,
      subtext: `از کل ${formatToman(dashboardSummary.totalBudgetIrt)} تومان`,
      tone: 'accent',
    },
    {
      label: 'ربات‌های فعال / تداخل‌ها',
      value: `${dashboardSummary.rows.filter((r) => r.isActive).length} فعال`,
      subtext:
        dashboardSummary.activeConflictSymbols.length > 0
          ? `${dashboardSummary.activeConflictSymbols.length} هشدار تداخل ارز`
          : 'بدون تداخل معاملاتی',
      tone: dashboardSummary.activeConflictSymbols.length > 0 ? 'negative' : 'positive',
    },
    {
      label: 'در انتظار تأیید دستی',
      value: `${pendingConfirmations.length} سفارش`,
      subtext: riskSettings.killSwitchActive ? 'توقف اضطراری فعال است' : 'قفل ایمنی آماده',
      tone: pendingConfirmations.length > 0 || riskSettings.killSwitchActive ? 'negative' : 'neutral',
    },
  ];

  return (
    <BotPageShell
      topic="AI_MANAGER"
      title="مدیر هوشمند مرکزی ربات‌ها (AI Bot Manager)"
      subtitle="تشخیص وضعیت بازار، رتبه‌بندی ارزهای نقدشونده نوبیتکس، پایش عملکرد ربات‌ها، جلوگیری از سفارش متناقض و کنترل سقف سرمایه مشترک"
      icon={<Cpu className="w-5 h-5 text-cyan-300" />}
      accentGradient="from-cyan-400 via-sky-500 to-teal-400"
      statusLabel={riskSettings.killSwitchActive ? 'توقف اضطراری فعال' : 'فعال و آماده پایش'}
      statusTone={riskSettings.killSwitchActive ? 'error' : 'active'}
      kpis={kpis}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      onBack={onBack}
      onOpenGuide={onOpenGuide}
      pendingConfirmations={pendingConfirmations}
      onApproveConfirmation={(c) => void onResolveConfirmation(c, 'APPROVE')}
      onRejectConfirmation={(c) => void onResolveConfirmation(c, 'REJECT')}
    >
      {feedback && (
        <div
          className={`mb-4 rounded-xl border px-4 py-3 text-xs font-medium ${
            feedback.type === 'ok'
              ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
              : 'border-rose-500/40 bg-rose-500/10 text-rose-200'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {activeTab === 'OVERVIEW' && (
        <div className="space-y-4">
          {/* Action Header Card */}
          <div className="rounded-2xl border border-cyan-500/30 bg-[#0A101D] p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-sm font-extrabold text-cyan-200">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                تحلیل جامع بازار و پیشنهادهای مدیر هوشمند
              </div>
              <p className="text-xs text-slate-300 leading-6">
                مدیر هوشمند فقط نقش مشاوره، رتبه‌بندی و هشدار دارد و هیچ‌گاه بدون تأیید شما سقف بودجه یا محدودیت ضرر ربات‌ها را تغییر نمی‌دهد.
              </p>
              {aiReport?.generatedAt && (
                <div className="text-[11px] text-slate-500">
                  آخرین به‌روزرسانی: {formatDateTimeShort(aiReport.generatedAt)}
                </div>
              )}
            </div>

            <button
              type="button"
              disabled={runningAi}
              onClick={() => void handleRunAnalysis()}
              className="min-h-[46px] px-5 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-60 text-white text-xs sm:text-sm font-extrabold flex items-center justify-center gap-2 shrink-0 transition"
            >
              <RefreshCw className={`w-4 h-4 ${runningAi ? 'animate-spin' : ''}`} />
              {runningAi ? 'در حال تحلیل بازار...' : 'تحلیل هوشمند بازار'}
            </button>
          </div>

          {!aiReport ? (
            <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-8 text-center space-y-3">
              <Bot className="w-10 h-10 text-cyan-400 mx-auto" />
              <div className="text-sm font-bold text-white">هنوز تحلیل جدیدی اجرا نشده است</div>
              <p className="text-xs text-slate-400 max-w-md mx-auto leading-6">
                روی دکمه «تحلیل هوشمند بازار» کلیک کنید تا وضعیت بازار، بهترین ارزهای امروز نوبیتکس و پیشنهاد ربات مناسب را دریافت کنید.
              </p>
            </div>
          ) : (
            <>
              {/* Market Regime + Primary Recommendation */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-400 font-bold">تشخیص وضعیت فعلی بازار</span>
                    <span className="px-2.5 py-1 rounded-lg border border-cyan-500/35 bg-cyan-500/10 text-cyan-200 text-xs font-extrabold">
                      {aiReport.regimeLabelFa}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-200 leading-7">{aiReport.marketSummaryFa}</p>
                </div>

                <div className="rounded-2xl border border-emerald-500/25 bg-[#0A101D] p-4 sm:p-5 space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-xs text-slate-400 font-bold">ربات پیشنهادی برای این شرایط</span>
                    <span className="px-2.5 py-1 rounded-lg border border-emerald-500/35 bg-emerald-500/10 text-emerald-300 text-xs font-extrabold">
                      {BOT_TYPE_LABELS_FA[aiReport.recommendedPrimaryBotType]}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-200 leading-7">
                    {aiReport.recommendedPrimaryBotReasonFa}
                  </p>
                  <button
                    type="button"
                    onClick={() => onNavigateToBot(aiReport.recommendedPrimaryBotType)}
                    className="min-h-[42px] px-4 rounded-xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/40 text-emerald-200 text-xs font-bold inline-flex items-center gap-2"
                  >
                    <TrendingUp className="w-4 h-4" />
                    رفتن به صفحه {BOT_TYPE_LABELS_FA[aiReport.recommendedPrimaryBotType]}
                  </button>
                </div>
              </div>

              {/* Conflict Alerts */}
              {aiReport.conflictAlerts.length > 0 && (
                <div className="rounded-2xl border border-rose-500/40 bg-rose-500/10 p-4 space-y-2.5">
                  <div className="flex items-center gap-2 text-rose-200 text-sm font-extrabold">
                    <AlertTriangle className="w-4 h-4 text-rose-400" />
                    هشدار تداخل ربات‌ها روی یک ارز
                  </div>
                  {aiReport.conflictAlerts.map((alert, idx) => (
                    <div
                      key={idx}
                      className="rounded-xl border border-rose-500/30 bg-[#0A101D]/90 p-3 text-xs text-rose-100 leading-6"
                    >
                      <strong className="font-mono-num text-white ml-2">{alert.symbol}:</strong>
                      {alert.messageFa}
                    </div>
                  ))}
                </div>
              )}

              {/* Top Ranked Coins */}
              <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                    <Flame className="w-4 h-4 text-amber-400" />
                    رتبه‌بندی ارزهای مناسب نوبیتکس
                  </h3>
                  <span className="text-[11px] text-slate-400">بر اساس حجم، نقدینگی و نوسان</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {aiReport.rankedCoins.map((coin, i) => (
                    <div
                      key={`${coin.symbol}-${i}`}
                      className="rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 space-y-2.5 flex flex-col justify-between"
                    >
                      <div className="space-y-2">
                        <div className="flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            <span className="w-6 h-6 rounded-lg bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-xs font-extrabold font-mono-num flex items-center justify-center">
                              {i + 1}
                            </span>
                            <div>
                              <div className="text-xs font-extrabold text-white">{coin.persianName}</div>
                              <div className="text-[11px] font-mono-num text-slate-400">{coin.symbol}</div>
                            </div>
                          </div>
                          <div className="text-left">
                            <div className="text-xs font-extrabold font-mono-num text-emerald-300">
                              امتیاز {coin.score}/100
                            </div>
                            <div className="text-[10px] text-slate-400">{coin.trendLabelFa}</div>
                          </div>
                        </div>

                        <div className="text-[11px] text-slate-300 leading-5">{coin.reasonFa}</div>
                      </div>

                      <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-2">
                        <span className="text-[11px] text-amber-300 font-bold">
                          پیشنهاد: {BOT_TYPE_LABELS_FA[coin.recommendedBotType]}
                        </span>
                        <button
                          type="button"
                          onClick={() => onNavigateToBot(coin.recommendedBotType, coin.baseAsset)}
                          className="min-h-[36px] px-3 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/35 text-cyan-200 text-[11px] font-bold"
                        >
                          ساخت ربات
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Bot Health Audits */}
              <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                  <Activity className="w-4 h-4 text-cyan-400" />
                  ارزیابی عملکرد ربات‌های شما ({aiReport.botReviews.length})
                </h3>
                {aiReport.botReviews.length === 0 ? (
                  <div className="text-xs text-slate-400 py-3">
                    هنوز رباتی ثبت نشده است؛ از منوی ربات‌های معاملاتی من اولین ربات را بسازید.
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {aiReport.botReviews.map((rev) => {
                      const badgeCls =
                        rev.health === 'HEALTHY'
                          ? 'bg-emerald-500/15 border-emerald-500/35 text-emerald-300'
                          : rev.health === 'CAUTION'
                            ? 'bg-amber-500/15 border-amber-500/35 text-amber-300'
                            : 'bg-rose-500/15 border-rose-500/35 text-rose-300';
                      const healthLabel =
                        rev.health === 'HEALTHY'
                          ? 'سالم'
                          : rev.health === 'CAUTION'
                            ? 'نیاز به بررسی'
                            : 'توقف پیشنهادی';
                      return (
                        <div
                          key={rev.botId}
                          className="rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                        >
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-xs font-extrabold text-white">{rev.botName}</span>
                              <span className={`px-2 py-0.5 rounded-md border text-[10px] font-bold ${badgeCls}`}>
                                {healthLabel}
                              </span>
                            </div>
                            <p className="text-xs text-slate-300">{rev.summaryFa}</p>
                          </div>
                          {rev.suggestedAction === 'PAUSE' && onStopBotByType && (
                            <button
                              type="button"
                              onClick={() => void onStopBotByType(rev.botType as BotType, rev.botId)}
                              className="min-h-[40px] px-3 rounded-xl border border-rose-500/40 bg-rose-500/10 hover:bg-rose-500/20 text-rose-200 text-xs font-bold flex items-center gap-1.5 shrink-0"
                            >
                              <PauseCircle className="w-4 h-4" />
                              توقف این ربات
                            </button>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      )}

      {activeTab === 'SETTINGS' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-5">
          <div className="flex items-start gap-3 rounded-xl border border-cyan-500/30 bg-cyan-500/10 p-3.5">
            <ShieldCheck className="w-5 h-5 text-cyan-300 shrink-0 mt-0.5" />
            <div className="text-xs text-cyan-100 leading-6">
              <strong className="block text-white mb-0.5">حاکمیت مشترک سرمایه و قفل ایمنی ربات‌ها</strong>
              همه ۵ نوع ربات قبل از هر خرید از این سقف‌ها پیروی می‌کنند تا سرمایه‌ی رزروشده دو بار خرج نشود. هوش مصنوعی هرگز بدون دستور مستقیم شما نمی‌تواند این اعداد را افزایش دهد.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="space-y-1.5">
              <label className="block text-slate-300 font-bold">بودجه کل ربات‌ها (تومان)</label>
              <NumericInput
                value={totalBudgetIrt}
                onValueChange={(v) => setTotalBudgetIrt(Number(v || 0))}
                allowDecimal={false}
                className="w-full min-h-[44px] rounded-xl bg-slate-900 border border-slate-700 px-3 text-white font-mono-num"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-slate-300 font-bold">بودجه کل ربات‌ها (USDT)</label>
              <NumericInput
                value={totalBudgetUsdt}
                onValueChange={(v) => setTotalBudgetUsdt(Number(v || 0))}
                allowDecimal
                className="w-full min-h-[44px] rounded-xl bg-slate-900 border border-slate-700 px-3 text-white font-mono-num"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-slate-300 font-bold">حداکثر سرمایه برای هر ربات (تومان)</label>
              <NumericInput
                value={maxPerBotIrt}
                onValueChange={(v) => setMaxPerBotIrt(Number(v || 0))}
                allowDecimal={false}
                className="w-full min-h-[44px] rounded-xl bg-slate-900 border border-slate-700 px-3 text-white font-mono-num"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-slate-300 font-bold">حداکثر سرمایه برای هر ربات (USDT)</label>
              <NumericInput
                value={maxPerBotUsdt}
                onValueChange={(v) => setMaxPerBotUsdt(Number(v || 0))}
                allowDecimal
                className="w-full min-h-[44px] rounded-xl bg-slate-900 border border-slate-700 px-3 text-white font-mono-num"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-slate-300 font-bold">سقف ضرر روزانه کل سیستم (تومان)</label>
              <NumericInput
                value={maxDailyLossIrt}
                onValueChange={(v) => setMaxDailyLossIrt(Number(v || 0))}
                allowDecimal={false}
                className="w-full min-h-[44px] rounded-xl bg-slate-900 border border-slate-700 px-3 text-white font-mono-num"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-slate-300 font-bold">سقف ضرر روزانه کل سیستم (USDT)</label>
              <NumericInput
                value={maxDailyLossUsdt}
                onValueChange={(v) => setMaxDailyLossUsdt(Number(v || 0))}
                allowDecimal
                className="w-full min-h-[44px] rounded-xl bg-slate-900 border border-slate-700 px-3 text-white font-mono-num"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-slate-300 font-bold">سقف ضرر کل (تومان)</label>
              <NumericInput
                value={maxTotalLossIrt}
                onValueChange={(v) => setMaxTotalLossIrt(Number(v || 0))}
                allowDecimal={false}
                className="w-full min-h-[44px] rounded-xl bg-slate-900 border border-slate-700 px-3 text-white font-mono-num"
              />
            </div>

            <div className="space-y-1.5">
              <label className="block text-slate-300 font-bold">سقف ضرر کل (USDT)</label>
              <NumericInput
                value={maxTotalLossUsdt}
                onValueChange={(v) => setMaxTotalLossUsdt(Number(v || 0))}
                allowDecimal
                className="w-full min-h-[44px] rounded-xl bg-slate-900 border border-slate-700 px-3 text-white font-mono-num"
              />
            </div>
          </div>

          <label className="flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 cursor-pointer text-xs text-slate-200">
            <input
              type="checkbox"
              checked={conflictLock}
              onChange={(e) => setConflictLock(e.target.checked)}
              className="w-4 h-4 accent-cyan-500"
            />
            <div>
              <div className="font-bold text-white">قفل جلوگیری از معاملات متناقض روی یک ارز</div>
              <div className="text-[11px] text-slate-400 mt-0.5">
                اگر یک ربات روی نمادی سفارش/موقعیت باز داشته باشد، ربات دوم اجازه ثبت معامله متضاد روی همان نماد را نخواهد داشت.
              </div>
            </div>
          </label>

          <button
            type="button"
            disabled={savingRisk}
            onClick={() => void handleSaveRisk()}
            className="min-h-[46px] px-6 rounded-xl bg-cyan-600 hover:bg-cyan-500 disabled:opacity-60 text-white text-xs sm:text-sm font-extrabold"
          >
            {savingRisk ? 'در حال ذخیره...' : 'ذخیره قوانین مدیریت سرمایه مشترک'}
          </button>
        </div>
      )}

      {activeTab === 'EXECUTION' && (
        <div className="space-y-4">
          {/* Global Kill Switch */}
          <div
            className={`rounded-2xl border p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 ${
              riskSettings.killSwitchActive
                ? 'border-rose-500/50 bg-rose-950/30'
                : 'border-slate-800 bg-[#0A101D]'
            }`}
          >
            <div className="flex items-start gap-3">
              <div className="w-11 h-11 rounded-xl border border-rose-500/40 bg-rose-500/15 text-rose-300 flex items-center justify-center shrink-0">
                <Power className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-extrabold text-white">کلید توقف اضطراری کل ربات‌ها (Kill Switch)</h3>
                <p className="text-xs text-slate-300 mt-1 leading-6">
                  با زدن این کلید، تمام ربات‌های فعال (سود، قیمت ثابت، گرید، خرید پله‌ای و استراتژی) فوراً متوقف می‌شوند. دارایی‌های فعلی شما حفظ می‌شوند.
                </p>
              </div>
            </div>
            <button
              type="button"
              disabled={togglingKill}
              onClick={() => void handleKillSwitch(!riskSettings.killSwitchActive)}
              className={`min-h-[46px] px-5 rounded-xl text-xs sm:text-sm font-extrabold shrink-0 transition ${
                riskSettings.killSwitchActive
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-rose-600 hover:bg-rose-500 text-white'
              }`}
            >
              {togglingKill
                ? 'در حال اجرا...'
                : riskSettings.killSwitchActive
                  ? 'آزادسازی قفل اضطراری'
                  : 'توقف فوری همه ربات‌ها'}
            </button>
          </div>

          {/* Manual Approval Queue */}
          <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <Hand className="w-4 h-4 text-amber-400" />
                صف تأیید دستی سفارش‌ها ({pendingConfirmations.length})
              </h3>
            </div>
            {pendingConfirmations.length === 0 ? (
              <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-6 text-center text-xs text-slate-400">
                در حال حاضر هیچ سفارش منتظر تأیید دستی وجود ندارد. برای ربات‌هایی که روی «تأیید دستی» تنظیم شده‌اند، پیشنهادها اینجا هم نمایش داده می‌شوند.
              </div>
            ) : (
              <div className="space-y-3">
                {pendingConfirmations.map((conf) => (
                  <div
                    key={conf.id}
                    className="rounded-xl border border-amber-500/35 bg-slate-900/70 p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-3"
                  >
                    <div className="space-y-1.5 text-xs">
                      <div className="font-extrabold text-white">
                        {conf.botName} · {conf.side === 'BUY' ? 'خرید' : 'فروش'} {conf.symbol}
                      </div>
                      <div className="text-slate-300">{conf.reasonFa}</div>
                      <div className="text-[11px] text-slate-400 font-mono-num">
                        قیمت پیشنهادی: {conf.suggestedPrice.toLocaleString('en-US')} · مبلغ:{' '}
                        {Math.round(conf.quoteAmount).toLocaleString('en-US')} · کارمزد تخمینی:{' '}
                        {Math.round(conf.estimatedFeeQuote).toLocaleString('en-US')}
                      </div>
                      <div className="text-[11px] text-amber-200">{conf.riskSummaryFa}</div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => void onResolveConfirmation(conf, 'APPROVE')}
                        className="min-h-[44px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        تأیید و ارسال سفارش
                      </button>
                      <button
                        type="button"
                        onClick={() => void onResolveConfirmation(conf, 'REJECT')}
                        className="min-h-[44px] px-4 rounded-xl border border-rose-500/40 bg-rose-500/10 text-rose-200 text-xs font-bold"
                      >
                        رد کردن
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'HISTORY' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
          <h3 className="text-sm font-extrabold text-white">پیشنهادهای اخیر مدیر هوشمند</h3>
          {!aiReport || aiReport.proposals.length === 0 ? (
            <div className="text-xs text-slate-400 py-4">هنوز پیشنهادی ثبت نشده است.</div>
          ) : (
            <div className="space-y-2.5">
              {aiReport.proposals.map((p) => (
                <div
                  key={p.id}
                  className="rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                >
                  <div className="space-y-1 text-xs">
                    <div className="font-extrabold text-white flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-cyan-400 shrink-0" />
                      {p.titleFa}
                    </div>
                    <div className="text-slate-300 leading-6">{p.reasonFa}</div>
                  </div>
                  {p.recommendedBotType && (
                    <button
                      type="button"
                      onClick={() =>
                        onNavigateToBot(
                          p.recommendedBotType!,
                          p.recommendedSymbol?.replace(/(IRT|USDT)$/i, '')
                        )
                      }
                      className="min-h-[40px] px-3.5 rounded-xl bg-cyan-600/20 border border-cyan-500/35 text-cyan-200 text-xs font-bold shrink-0"
                    >
                      باز کردن ربات پیشنهادی
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </BotPageShell>
  );
};
