import React, { useEffect, useState } from 'react';
import {
  Activity,
  AlertCircle,
  Bot,
  CheckCircle2,
  Clock,
  FileText,
  Pause,
  Play,
  Search,
  Send,
  Trash2,
  Wallet,
} from 'lucide-react';
import type {
  BotMonitoringTelegramMode,
  TelegramBotSummary,
  TelegramDiscoveredChat,
  TelegramManualReportKind,
  TelegramSentLogEntry,
} from '../types/trading';
import { formatDateTimeShort } from '../utils/format';
import { NumericInput } from './NumericInput';

interface TelegramBotCardProps {
  telegram: TelegramBotSummary;
  onSaveConfig: (payload: {
    botToken?: string;
    chatId: string;
    enabled: boolean;
    sendPriceAlerts: boolean;
    sendPeriodicWatchers: boolean;
    sendTradeReports?: boolean;
    sendBotTrades?: boolean;
    sendBotMonitoring?: boolean;
    botMonitorMode?: BotMonitoringTelegramMode;
    botMonitorIntervalMinutes?: number;
  }) => Promise<void>;
  onDetectChats: (botToken?: string) => Promise<TelegramDiscoveredChat[]>;
  onSendTest: (botToken?: string, chatId?: string) => Promise<void>;
  onUpdatePreferences: (payload: {
    enabled?: boolean;
    sendPriceAlerts?: boolean;
    sendPeriodicWatchers?: boolean;
    sendTradeReports?: boolean;
    sendBotTrades?: boolean;
    sendBotMonitoring?: boolean;
    botMonitorMode?: BotMonitoringTelegramMode;
    botMonitorIntervalMinutes?: number;
  }) => Promise<void>;
  onDisconnect: () => Promise<void>;
  onSendManualReport?: (
    kind: TelegramManualReportKind,
    botId?: string
  ) => Promise<{ title?: string; preview?: string } | void>;
}

const LOG_KIND_LABELS: Record<TelegramSentLogEntry['kind'], string> = {
  TEST: 'تست اتصال',
  TRADE: 'خرید/فروش دستی',
  BOT_TRADE: 'معامله ربات',
  BOT_EVENT: 'رویداد ربات',
  BOT_MONITOR: 'پایش ربات',
  PRICE_ALERT: 'هشدار قیمت',
  PRICE_PULSE: 'گزارش قیمت',
  MANUAL_REPORT: 'گزارش دستی',
};

const MONITOR_MODE_OPTIONS: {
  id: BotMonitoringTelegramMode;
  title: string;
  desc: string;
}[] = [
  {
    id: 'MANUAL_ONLY',
    title: 'فقط ارسال دستی',
    desc: 'فقط وقتی خودتان دکمه ارسال گزارش را بزنید به تلگرام پیام می‌فرستد',
  },
  {
    id: 'EVENTS_AND_STATUS',
    title: 'رویدادهای مهم ربات',
    desc: 'شروع، توقف، تغییر حالت، خطاها و ارزیابی فوری ربات (بدون شلوغی چت)',
  },
  {
    id: 'INTERVAL',
    title: 'هر X دقیقه به‌صورت دوره‌ای',
    desc: 'در بازه دقیقه‌ای دلخواه شما گزارش وضعیت پایش ربات‌ها را ارسال می‌کند',
  },
  {
    id: 'EVERY_CYCLE',
    title: 'همه چرخه‌های پایش (هر ۱۵ ثانیه)',
    desc: 'گزارش کامل تک‌تک چرخه‌های پایش سرور (مناسب رصد دقیق کوتاه‌مدت)',
  },
];

export const TelegramBotCard: React.FC<TelegramBotCardProps> = ({
  telegram,
  onSaveConfig,
  onDetectChats,
  onSendTest,
  onUpdatePreferences,
  onDisconnect,
  onSendManualReport,
}) => {
  const [botToken, setBotToken] = useState('');
  const [chatId, setChatId] = useState(telegram.chatId || '');
  const [sendPriceAlerts, setSendPriceAlerts] = useState(telegram.sendPriceAlerts);
  const [sendPeriodicWatchers, setSendPeriodicWatchers] = useState(telegram.sendPeriodicWatchers);
  const [sendTradeReports, setSendTradeReports] = useState(telegram.sendTradeReports ?? true);
  const [sendBotTrades, setSendBotTrades] = useState(telegram.sendBotTrades ?? true);
  const [sendBotMonitoring, setSendBotMonitoring] = useState(telegram.sendBotMonitoring ?? true);
  const [botMonitorMode, setBotMonitorMode] = useState<BotMonitoringTelegramMode>(
    telegram.botMonitorMode || 'EVENTS_AND_STATUS'
  );
  const [botMonitorIntervalMinutes, setBotMonitorIntervalMinutes] = useState<number>(
    telegram.botMonitorIntervalMinutes || 15
  );
  const [saving, setSaving] = useState(false);
  const [detecting, setDetecting] = useState(false);
  const [testing, setTesting] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [sendingReportKind, setSendingReportKind] = useState<TelegramManualReportKind | null>(null);
  const [discoveredChats, setDiscoveredChats] = useState<TelegramDiscoveredChat[]>([]);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);

  useEffect(() => {
    setChatId((prev) => (telegram.chatId ? telegram.chatId : prev));
    setSendPriceAlerts(telegram.sendPriceAlerts);
    setSendPeriodicWatchers(telegram.sendPeriodicWatchers);
    setSendTradeReports(telegram.sendTradeReports ?? true);
    setSendBotTrades(telegram.sendBotTrades ?? true);
    setSendBotMonitoring(telegram.sendBotMonitoring ?? true);
    setBotMonitorMode(telegram.botMonitorMode || 'EVENTS_AND_STATUS');
    setBotMonitorIntervalMinutes(telegram.botMonitorIntervalMinutes || 15);
  }, [
    telegram.chatId,
    telegram.sendPriceAlerts,
    telegram.sendPeriodicWatchers,
    telegram.sendTradeReports,
    telegram.sendBotTrades,
    telegram.sendBotMonitoring,
    telegram.botMonitorMode,
    telegram.botMonitorIntervalMinutes,
  ]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);

    const cleanToken = botToken.trim();
    const cleanChatId = chatId.trim();

    if (!telegram.configured && !cleanToken) {
      setFeedback({
        type: 'err',
        text: 'برای اتصال اولیه، وارد کردن توکن ربات تلگرام (از @BotFather) الزامی است.',
      });
      return;
    }
    if (!cleanChatId) {
      setFeedback({
        type: 'err',
        text: 'لطفاً شناسه چت (Chat ID) را وارد یا به‌صورت خودکار دریافت کنید.',
      });
      return;
    }

    const safeInterval = Math.max(1, Math.min(1440, Math.round(botMonitorIntervalMinutes || 15)));

    setSaving(true);
    try {
      await onSaveConfig({
        botToken: cleanToken || undefined,
        chatId: cleanChatId,
        enabled: true,
        sendPriceAlerts,
        sendPeriodicWatchers,
        sendTradeReports,
        sendBotTrades,
        sendBotMonitoring,
        botMonitorMode,
        botMonitorIntervalMinutes: safeInterval,
      });
      setBotToken('');
      setDiscoveredChats([]);
      setFeedback({
        type: 'ok',
        text: 'ربات تلگرام و تنظیمات دستی ارسال گزارش‌ها با موفقیت ذخیره شد.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ذخیره تنظیمات تلگرام',
      });
    } finally {
      setSaving(false);
    }
  };

  const handlePrefPatch = async (
    patch: Parameters<TelegramBotCardProps['onUpdatePreferences']>[0],
    okMessage?: string
  ) => {
    if (!telegram.configured) return;
    setFeedback(null);
    try {
      await onUpdatePreferences(patch);
      if (okMessage) {
        setFeedback({ type: 'ok', text: okMessage });
      }
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در به‌روزرسانی تنظیمات ارسال تلگرام',
      });
    }
  };

  const handleDetectChats = async () => {
    setFeedback(null);
    setDetecting(true);
    try {
      const chats = await onDetectChats(botToken.trim() || undefined);
      setDiscoveredChats(chats);
      if (chats.length === 0) {
        setFeedback({
          type: 'err',
          text: 'پیامی در ربات یافت نشد. لطفاً در تلگرام وارد ربات خود شوید، /start را بزنید و دوباره تلاش کنید.',
        });
      } else {
        if (!chatId.trim()) {
          setChatId(chats[0].chatId);
        }
        setFeedback({
          type: 'ok',
          text: `${chats.length} گفتگو یافت شد. روی گفتگوی مورد نظر کلیک کنید تا Chat ID انتخاب شود.`,
        });
      }
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'دریافت خودکار Chat ID ناموفق بود.',
      });
    } finally {
      setDetecting(false);
    }
  };

  const handleSendTest = async () => {
    setFeedback(null);
    const tok = botToken.trim() || undefined;
    const cid = chatId.trim() || undefined;
    if (!telegram.configured && (!tok || !cid)) {
      setFeedback({
        type: 'err',
        text: 'ابتدا توکن ربات و Chat ID را وارد کنید یا تنظیمات را ذخیره نمایید.',
      });
      return;
    }

    setTesting(true);
    try {
      await onSendTest(tok, cid);
      setFeedback({
        type: 'ok',
        text: 'پیام آزمایشی با موفقیت به تلگرام شما ارسال شد. تلگرام خود را بررسی کنید.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'ارسال پیام تست ناموفق بود.',
      });
    } finally {
      setTesting(false);
    }
  };

  const handleManualReportClick = async (kind: TelegramManualReportKind) => {
    if (!onSendManualReport) return;
    setFeedback(null);
    if (!telegram.configured) {
      setFeedback({
        type: 'err',
        text: 'ابتدا توکن ربات و Chat ID را وارد و ذخیره کنید تا امکان ارسال گزارش به تلگرام فعال شود.',
      });
      return;
    }
    setSendingReportKind(kind);
    try {
      const res = await onSendManualReport(kind);
      setFeedback({
        type: 'ok',
        text: res?.title
          ? `${res.title} با موفقیت به ربات تلگرام ارسال شد.`
          : 'گزارش درخواستی با موفقیت به ربات تلگرام ارسال شد.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'ارسال دستی گزارش به تلگرام ناموفق بود.',
      });
    } finally {
      setSendingReportKind(null);
    }
  };

  const handleToggleEnabled = async () => {
    setFeedback(null);
    setToggling(true);
    try {
      await onUpdatePreferences({ enabled: !telegram.enabled });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در تغییر وضعیت ارسال تلگرام',
      });
    } finally {
      setToggling(false);
    }
  };

  const handleDisconnect = async () => {
    setFeedback(null);
    setToggling(true);
    try {
      await onDisconnect();
      setBotToken('');
      setChatId('');
      setDiscoveredChats([]);
      setFeedback({
        type: 'ok',
        text: 'اتصال بات تلگرام قطع شد و توکن رمزنگاری‌شده از سرور حذف گردید.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در قطع اتصال تلگرام',
      });
    } finally {
      setToggling(false);
    }
  };

  const recentLogs = telegram.recentLogs || [];

  return (
    <section className="glass-panel rounded-xl overflow-hidden">
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-3.5 border-b border-slate-800/90 bg-[#060A14]/75">
        <div className="flex items-center gap-2.5">
          <Send className="w-4 h-4 text-cyan-400" />
          <div>
            <h2 className="text-sm font-semibold text-white">
              مرکز کنترل و ارسال گزارش به ربات تلگرام
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              تنظیم دستی گزارش‌های خرید و فروش، پایش ربات‌ها، تمام رویدادهای ربات، هشدار قیمت و ارسال فوری با یک کلیک
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 text-xs">
          {telegram.configured ? (
            <>
              {telegram.enabled ? (
                <span className="inline-flex items-center gap-1.5 text-emerald-400 font-semibold">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>
                    متصل {telegram.botUsername ? `(@${telegram.botUsername})` : ''}
                  </span>
                </span>
              ) : (
                <span className="text-amber-300 font-semibold">متوقف موقت</span>
              )}
              <span aria-hidden="true" className="text-slate-700">
                ·
              </span>
              <span className="text-slate-400 font-mono-num" dir="ltr">
                Chat: {telegram.chatId}
              </span>
              {telegram.lastSentAt && (
                <>
                  <span aria-hidden="true" className="text-slate-700">
                    ·
                  </span>
                  <span className="text-slate-400 font-mono-num" dir="ltr">
                    آخرین پیام: {formatDateTimeShort(telegram.lastSentAt)}
                  </span>
                </>
              )}
            </>
          ) : (
            <span className="text-slate-400">هنوز ربات تلگرام متصل نشده است</span>
          )}
        </div>
      </div>

      <div className="p-5 space-y-4">
        {/* Quick Setup Guide */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 text-xs text-slate-300 space-y-1.5">
          <div className="font-semibold text-amber-300">راهنمای سریع اتصال در ۳۰ ثانیه:</div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[11px] text-slate-400 leading-relaxed">
            <div>
              <span className="text-cyan-300 font-semibold">۱. ساخت ربات:</span> در تلگرام وارد{' '}
              <span className="font-mono-num text-slate-200" dir="ltr">
                @BotFather
              </span>{' '}
              شوید، دستور <code className="text-slate-200">/newbot</code> را ارسال کنید و توکن دریافتی را در کادر زیر بگذارید.
            </div>
            <div>
              <span className="text-cyan-300 font-semibold">۲. شروع چت و Chat ID:</span> ربات جدید خود را در تلگرام باز کرده و{' '}
              <code className="text-slate-200">/start</code> بزنید؛ سپس روی دکمه{' '}
              <span className="text-slate-200">«یافتن خودکار Chat ID»</span> کلیک کنید.
            </div>
            <div>
              <span className="text-cyan-300 font-semibold">۳. انتخاب دستی گزارش‌ها:</span> دقیقاً مشخص کنید کدام گزارش‌ها (خرید و فروش، معاملات ربات، پایش ربات و...) ارسال شوند.
            </div>
          </div>
        </div>

        <form
          onSubmit={handleSave}
          className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-5"
        >
          {/* Credentials */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                <span>توکن ربات تلگرام (Bot Token)</span>
                {telegram.configured && (
                  <span className="font-mono-num text-emerald-400" dir="ltr">
                    ذخیره‌شده: {telegram.maskedBotToken}
                  </span>
                )}
              </div>
              <input
                type="password"
                value={botToken}
                onChange={(e) => setBotToken(e.target.value)}
                placeholder={
                  telegram.configured
                    ? 'توکن قبلی رمزنگاری و محفوظ است (فقط برای تغییر، توکن جدید بنویسید)'
                    : 'مثال: 7123456789:AAHxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'
                }
                dir="ltr"
                autoComplete="off"
                className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-3 py-2 text-xs font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                شناسه چت / کانال مقصد (Chat ID)
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="text"
                  value={chatId}
                  onChange={(e) => setChatId(e.target.value)}
                  placeholder="مثال: 123456789 یا -100... یا @channel"
                  dir="ltr"
                  className="flex-1 bg-[#0A101D] border border-slate-700 rounded-md px-3 py-2 text-xs font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
                />
                <button
                  type="button"
                  disabled={detecting}
                  onClick={() => void handleDetectChats()}
                  className="btn-glass btn-glass-sync inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium text-cyan-300 whitespace-nowrap shrink-0"
                >
                  <Search className="w-3.5 h-3.5" />
                  <span>{detecting ? 'در حال جستجو...' : 'یافتن خودکار Chat ID'}</span>
                </button>
              </div>
            </div>
          </div>

          {/* Auto-discovered Chats Picker */}
          {discoveredChats.length > 0 && (
            <div className="border border-slate-800 rounded-md p-3 bg-[#0A101D] space-y-2">
              <div className="text-[11px] text-slate-400">
                گفتگوهای شناسایی‌شده (برای انتخاب روی هر مورد کلیک کنید):
              </div>
              <div className="flex flex-wrap gap-2">
                {discoveredChats.map((c) => (
                  <button
                    key={c.chatId}
                    type="button"
                    onClick={() => setChatId(c.chatId)}
                    className={`btn-glass px-3 py-1.5 rounded-lg text-xs whitespace-nowrap shrink-0 ${
                      chatId.trim() === c.chatId
                        ? 'btn-glass-primary font-semibold'
                        : 'btn-glass-neutral text-slate-200'
                    }`}
                  >
                    <span>{c.title}</span>
                    <span className="font-mono-num text-[11px] text-slate-400 mr-2" dir="ltr">
                      ({c.chatId})
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Granular Manual Category Toggles */}
          <div className="pt-3 border-t border-slate-800/80 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-xs font-semibold text-white">
                تنظیم دستی انواع گزارش‌های ارسالی به تلگرام
              </h3>
              <span className="text-[11px] text-slate-400">
                هر مورد را می‌توانید به‌صورت مستقل روشن یا خاموش کنید
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2.5 text-xs">
              <label className="flex items-start gap-2.5 p-2.5 rounded-md bg-[#0A101D] border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={sendTradeReports}
                  onChange={(e) => {
                    const next = e.target.checked;
                    setSendTradeReports(next);
                    void handlePrefPatch({ sendTradeReports: next });
                  }}
                  className="accent-emerald-500 mt-0.5 shrink-0"
                />
                <div>
                  <div className="font-medium text-slate-100">گزارش خرید و فروش‌های دستی</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    ثبت سفارش جدید، تکمیل سفارش لیمیت و لغو سفارش در ترمینال
                  </div>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-2.5 rounded-md bg-[#0A101D] border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={sendBotTrades}
                  onChange={(e) => {
                    const next = e.target.checked;
                    setSendBotTrades(next);
                    void handlePrefPatch({ sendBotTrades: next });
                  }}
                  className="accent-cyan-500 mt-0.5 shrink-0"
                />
                <div>
                  <div className="font-medium text-slate-100">گزارش خرید و فروش خودکار ربات</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    هر معامله خرید یا فروش ربات همراه با قیمت، حجم و سود/زیان
                  </div>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-2.5 rounded-md bg-[#0A101D] border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={sendBotMonitoring}
                  onChange={(e) => {
                    const next = e.target.checked;
                    setSendBotMonitoring(next);
                    void handlePrefPatch({ sendBotMonitoring: next });
                  }}
                  className="accent-cyan-500 mt-0.5 shrink-0"
                />
                <div>
                  <div className="font-medium text-slate-100">گزارش پایش و تمام کارهای ربات</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    شروع، توقف، تغییر حالت، خطاها و گزارش‌های پایش اندیکاتورها
                  </div>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-2.5 rounded-md bg-[#0A101D] border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={sendPriceAlerts}
                  onChange={(e) => {
                    const next = e.target.checked;
                    setSendPriceAlerts(next);
                    void handlePrefPatch({ sendPriceAlerts: next });
                  }}
                  className="accent-amber-500 mt-0.5 shrink-0"
                />
                <div>
                  <div className="font-medium text-slate-100">هشدارهای رسیدن قیمت به هدف</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    اطلاع‌رسانی لحظه‌ای هنگام عبور قیمت ارز از سقف یا کف تعیین‌شده
                  </div>
                </div>
              </label>

              <label className="flex items-start gap-2.5 p-2.5 rounded-md bg-[#0A101D] border border-slate-800 hover:border-slate-700 cursor-pointer">
                <input
                  type="checkbox"
                  checked={sendPeriodicWatchers}
                  onChange={(e) => {
                    const next = e.target.checked;
                    setSendPeriodicWatchers(next);
                    void handlePrefPatch({ sendPeriodicWatchers: next });
                  }}
                  className="accent-cyan-500 mt-0.5 shrink-0"
                />
                <div>
                  <div className="font-medium text-slate-100">گزارش‌های دوره‌ای قیمت لحظه‌ای</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">
                    ارسال قیمت تومانی و دلاری ارزهای منتخب هر X دقیقه به تلگرام
                  </div>
                </div>
              </label>
            </div>
          </div>

          {/* Bot Monitoring Cadence Control */}
          {sendBotMonitoring && (
            <div className="pt-3 border-t border-slate-800/80 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-cyan-300">
                  <Activity className="w-3.5 h-3.5" />
                  <span>نحوه و زمان‌بندی ارسال گزارش پایش ربات‌ها به تلگرام</span>
                </div>
                {telegram.lastBotMonitorSentAt && (
                  <span className="text-[11px] text-slate-400 font-mono-num" dir="ltr">
                    آخرین گزارش پایش: {formatDateTimeShort(telegram.lastBotMonitorSentAt)}
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-xs">
                {MONITOR_MODE_OPTIONS.map((opt) => {
                  const active = botMonitorMode === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => {
                        setBotMonitorMode(opt.id);
                        void handlePrefPatch(
                          { botMonitorMode: opt.id },
                          `حالت ارسال پایش ربات به «${opt.title}» تغییر کرد.`
                        );
                      }}
                      className={`btn-glass text-right p-3 rounded-xl ${
                        active
                          ? 'btn-glass-primary'
                          : 'btn-glass-neutral text-slate-300'
                      }`}
                    >
                      <div className="font-semibold text-xs">{opt.title}</div>
                      <div className="text-[11px] text-slate-400 mt-1 leading-relaxed">
                        {opt.desc}
                      </div>
                    </button>
                  );
                })}
              </div>

              {botMonitorMode === 'INTERVAL' && (
                <div className="flex flex-wrap items-center gap-3 bg-[#0A101D]/80 border border-slate-800 rounded-xl p-3 text-xs">
                  <div className="flex items-center gap-1.5 text-slate-300">
                    <Clock className="w-3.5 h-3.5 text-cyan-400" />
                    <span>فاصله ارسال گزارش پایش ربات (دقیقه):</span>
                  </div>
                  <div className="w-24">
                    <NumericInput
                      allowDecimal={false}
                      value={botMonitorIntervalMinutes}
                      onValueChange={(v) => setBotMonitorIntervalMinutes(v === '' ? 1 : Number(v))}
                      className="w-full bg-slate-950 border border-slate-700 rounded px-2.5 py-1 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                  <div className="flex items-center gap-1.5">
                    {[5, 15, 30, 60].map((m) => (
                      <button
                        key={m}
                        type="button"
                        onClick={() => {
                          setBotMonitorIntervalMinutes(m);
                          void handlePrefPatch(
                            { botMonitorMode: 'INTERVAL', botMonitorIntervalMinutes: m },
                            `گزارش پایش ربات هر ${m} دقیقه یک‌بار به تلگرام ارسال می‌شود.`
                          );
                        }}
                        className={`btn-glass px-2.5 py-1 rounded-lg text-[11px] font-mono-num whitespace-nowrap shrink-0 ${
                          botMonitorIntervalMinutes === m
                            ? 'btn-glass-primary'
                            : 'btn-glass-neutral text-slate-300'
                        }`}
                      >
                        {m}د
                      </button>
                    ))}
                  </div>
                  {telegram.configured && (
                    <button
                      type="button"
                      onClick={() => {
                        const safe = Math.max(
                          1,
                          Math.min(1440, Math.round(botMonitorIntervalMinutes || 15))
                        );
                        void handlePrefPatch(
                          { botMonitorMode: 'INTERVAL', botMonitorIntervalMinutes: safe },
                          `فاصله ارسال پایش ربات روی هر ${safe} دقیقه ذخیره شد.`
                        );
                      }}
                      className="btn-glass btn-glass-primary px-3 py-1 rounded-lg font-semibold text-xs whitespace-nowrap shrink-0"
                    >
                      ذخیره بازه
                    </button>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Save / Test / Pause / Disconnect Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80 text-xs">
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="submit"
                disabled={saving}
                className="btn-glass btn-glass-primary inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>
                  {saving
                    ? 'در حال ذخیره...'
                    : telegram.configured
                      ? 'ذخیره تنظیمات تلگرام'
                      : 'ذخیره و اتصال ربات تلگرام'}
                </span>
              </button>

              <button
                type="button"
                disabled={testing}
                onClick={() => void handleSendTest()}
                className="btn-glass btn-glass-amber inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap shrink-0"
              >
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{testing ? 'در حال ارسال...' : 'ارسال پیام تست'}</span>
              </button>

              {telegram.configured && (
                <>
                  <button
                    type="button"
                    disabled={toggling}
                    onClick={() => void handleToggleEnabled()}
                    className="btn-glass btn-glass-neutral inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0"
                    title={telegram.enabled ? 'توقف موقت ارسال تلگرام' : 'فعال‌سازی ارسال تلگرام'}
                  >
                    {telegram.enabled ? (
                      <>
                        <Pause className="w-3.5 h-3.5 text-amber-300" />
                        <span>توقف موقت</span>
                      </>
                    ) : (
                      <>
                        <Play className="w-3.5 h-3.5 text-emerald-400" />
                        <span>فعال‌سازی</span>
                      </>
                    )}
                  </button>

                  <button
                    type="button"
                    disabled={toggling}
                    onClick={() => void handleDisconnect()}
                    className="btn-glass btn-glass-sell inline-flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0"
                    title="قطع اتصال و حذف توکن"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>قطع اتصال</span>
                  </button>
                </>
              )}
            </div>
          </div>

          {telegram.lastError && !feedback && (
            <div className="flex items-center gap-2 text-xs px-3 py-2 rounded border bg-rose-500/10 border-rose-500/30 text-rose-300">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>آخرین خطای ارسال تلگرام: {telegram.lastError}</span>
            </div>
          )}

          {feedback && (
            <div
              className={`text-xs px-3 py-2 rounded border ${
                feedback.type === 'ok'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
              }`}
            >
              {feedback.text}
            </div>
          )}
        </form>

        {/* Manual On-Demand Dispatch Panel */}
        {onSendManualReport && (
          <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-xs font-semibold text-white">
                  ارسال دستی فوری گزارش به تلگرام (هر زمان که بخواهید)
                </h3>
                <p className="text-[11px] text-slate-400 mt-0.5">
                  حتی اگر ارسال خودکار را روی «فقط دستی» گذاشته باشید، با زدن هر دکمه گزارش همان لحظه به تلگرام ارسال می‌شود.
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 text-xs">
              <button
                type="button"
                disabled={sendingReportKind !== null}
                onClick={() => void handleManualReportClick('FULL_SUMMARY')}
                className="btn-glass btn-glass-primary inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-semibold whitespace-nowrap shrink-0"
              >
                <FileText className="w-3.5 h-3.5" />
                <span>
                  {sendingReportKind === 'FULL_SUMMARY'
                    ? 'در حال ارسال...'
                    : 'ارسال گزارش جامع کامل'}
                </span>
              </button>

              <button
                type="button"
                disabled={sendingReportKind !== null}
                onClick={() => void handleManualReportClick('TRADES')}
                className="btn-glass btn-glass-buy inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
                <span>
                  {sendingReportKind === 'TRADES'
                    ? 'در حال ارسال...'
                    : 'ارسال گزارش خرید و فروش‌ها'}
                </span>
              </button>

              <button
                type="button"
                disabled={sendingReportKind !== null}
                onClick={() => void handleManualReportClick('BOTS_MONITOR')}
                className="btn-glass btn-glass-telegram inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap shrink-0"
              >
                <Bot className="w-3.5 h-3.5" />
                <span>
                  {sendingReportKind === 'BOTS_MONITOR'
                    ? 'در حال ارسال...'
                    : 'ارسال گزارش پایش و کارهای ربات'}
                </span>
              </button>

              <button
                type="button"
                disabled={sendingReportKind !== null}
                onClick={() => void handleManualReportClick('PORTFOLIO')}
                className="btn-glass btn-glass-amber inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg font-medium whitespace-nowrap shrink-0"
              >
                <Wallet className="w-3.5 h-3.5" />
                <span>
                  {sendingReportKind === 'PORTFOLIO'
                    ? 'در حال ارسال...'
                    : 'ارسال گزارش کیف پول و پرتفوی'}
                </span>
              </button>
            </div>
          </div>
        )}

        {/* Recent Sent Telegram Dispatch Log */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg overflow-hidden">
          <div className="px-4 py-2.5 border-b border-slate-800 bg-[#060A14] flex items-center justify-between text-xs">
            <span className="font-semibold text-white">
              گزارش‌های اخیر ارسالی به تلگرام ({recentLogs.length})
            </span>
            <span className="text-slate-400">۲۰ پیام آخر ثبت‌شده در ربات تلگرام</span>
          </div>
          {recentLogs.length === 0 ? (
            <div className="px-4 py-6 text-center text-xs text-slate-500">
              هنوز پیامی به تلگرام ارسال نشده است. با ثبت معامله، فعالیت ربات یا زدن دکمه‌های ارسال فوری، تاریخچه اینجا ثبت می‌شود.
            </div>
          ) : (
            <div className="divide-y divide-slate-800/70 max-h-64 overflow-y-auto text-xs">
              {recentLogs.slice(0, 15).map((entry) => (
                <div
                  key={entry.id}
                  className="px-4 py-2.5 flex flex-wrap items-start justify-between gap-3 hover:bg-slate-900/40"
                >
                  <div className="space-y-0.5 min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`font-medium ${
                          entry.status === 'SENT' ? 'text-emerald-400' : 'text-rose-400'
                        }`}
                      >
                        {entry.status === 'SENT' ? 'ارسال شد' : 'خطا'}
                      </span>
                      <span className="text-slate-600">·</span>
                      <span className="text-cyan-300">
                        {LOG_KIND_LABELS[entry.kind] || entry.kind}
                      </span>
                      <span className="text-slate-600">·</span>
                      <span className="font-semibold text-white">{entry.title}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 truncate">
                      {entry.error ? `خطا: ${entry.error}` : entry.preview}
                    </div>
                  </div>
                  <span className="text-[11px] text-slate-500 font-mono-num shrink-0" dir="ltr">
                    {formatDateTimeShort(entry.sentAt)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

