import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Check, ChevronDown, Search, X } from 'lucide-react';
import type { QuoteCurrency, UnifiedMarketTicker } from '../types/trading';
import { formatPercent, formatPrice, formatToman } from '../utils/format';

interface CoinSearchSelectProps {
  markets: UnifiedMarketTicker[];
  value: string;
  onChange: (baseAsset: string) => void;
  quoteCurrency?: QuoteCurrency;
  size?: 'sm' | 'md';
  disabled?: boolean;
  className?: string;
  ariaLabel?: string;
  showPriceInTrigger?: boolean;
}

function normalizeFaSearch(input: string): string {
  return input
    .trim()
    .toLowerCase()
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/ة/g, 'ه')
    .replace(/\u200c/g, ' ');
}

export const CoinSearchSelect: React.FC<CoinSearchSelectProps> = ({
  markets,
  value,
  onChange,
  quoteCurrency = 'IRT',
  size = 'md',
  disabled = false,
  className = '',
  ariaLabel = 'جستجو و انتخاب ارز دیجیتال',
  showPriceInTrigger = false,
}) => {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [highlightedIdx, setHighlightedIdx] = useState(0);

  const rootRef = useRef<HTMLDivElement | null>(null);
  const searchInputRef = useRef<HTMLInputElement | null>(null);

  const effectiveMarkets = useMemo<UnifiedMarketTicker[]>(() => {
    if (markets.length > 0) return markets;
    return [
      {
        baseAsset: 'BTC',
        persianName: 'بیت‌کوین',
        symbolIrt: 'BTCIRT',
        symbolUsdt: 'BTCUSDT',
        hasIrtMarket: true,
        hasUsdtMarket: true,
        priceToman: 0,
        priceUsdt: 0,
        bestBuyToman: 0,
        bestSellToman: 0,
        bestBuyUsdt: 0,
        bestSellUsdt: 0,
        high24hToman: 0,
        low24hToman: 0,
        high24hUsdt: 0,
        low24hUsdt: 0,
        change24hPercent: 0,
        volumeToman: 0,
        volumeUsdt: 0,
        volumeSrc: 0,
        usdtTomanRate: 0,
        timestamp: 0,
      },
    ];
  }, [markets]);

  const selectedMarket = useMemo(
    () =>
      effectiveMarkets.find((m) => m.baseAsset.toUpperCase() === value.toUpperCase()) ||
      effectiveMarkets[0],
    [effectiveMarkets, value]
  );

  const filteredMarkets = useMemo(() => {
    const q = normalizeFaSearch(query);
    if (!q) return effectiveMarkets;
    return effectiveMarkets.filter((m) => {
      const symbol = m.baseAsset.toLowerCase();
      const fa = normalizeFaSearch(m.persianName || '');
      const irt = m.symbolIrt.toLowerCase();
      const usdt = m.symbolUsdt.toLowerCase();
      return (
        symbol.includes(q) ||
        fa.includes(q) ||
        irt.includes(q) ||
        usdt.includes(q)
      );
    });
  }, [effectiveMarkets, query]);

  useEffect(() => {
    if (!open) return;
    setHighlightedIdx(0);
    const t = window.setTimeout(() => {
      searchInputRef.current?.focus();
    }, 20);
    return () => window.clearTimeout(t);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const handleOutside = (e: MouseEvent) => {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    };
    const handleEsc = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setOpen(false);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    document.addEventListener('keydown', handleEsc);
    return () => {
      document.removeEventListener('mousedown', handleOutside);
      document.removeEventListener('keydown', handleEsc);
    };
  }, [open]);

  const pickCoin = (baseAsset: string) => {
    onChange(baseAsset);
    setOpen(false);
    setQuery('');
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      setHighlightedIdx((prev) =>
        filteredMarkets.length === 0 ? 0 : Math.min(filteredMarkets.length - 1, prev + 1)
      );
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlightedIdx((prev) => Math.max(0, prev - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      const target = filteredMarkets[highlightedIdx] || filteredMarkets[0];
      if (target) {
        pickCoin(target.baseAsset);
      }
    }
  };

  const triggerPadding = size === 'sm' ? 'px-2.5 py-1.5 text-xs' : 'px-3 py-2 text-xs sm:text-sm';

  return (
    <div ref={rootRef} className={`relative ${className}`}>
      <button
        type="button"
        disabled={disabled}
        aria-label={ariaLabel}
        aria-expanded={open}
        aria-haspopup="listbox"
        onClick={() => setOpen((v) => !v)}
        className={`w-full flex items-center justify-between gap-2 bg-slate-950/95 border border-slate-700/90 hover:border-cyan-400/70 rounded-xl text-white transition-colors focus:outline-none focus:border-cyan-400 disabled:opacity-50 ${triggerPadding}`}
      >
        <div className="flex items-center gap-2 min-w-0 truncate">
          <span className="font-mono-num font-bold text-cyan-300 shrink-0" dir="ltr">
            {selectedMarket?.baseAsset || value}
          </span>
          <span className="text-slate-200 font-medium truncate">
            {selectedMarket?.persianName || value}
          </span>
          {showPriceInTrigger && selectedMarket && selectedMarket.priceToman > 0 && (
            <span className="hidden sm:inline font-mono-num text-[11px] text-amber-300/90 shrink-0" dir="ltr">
              ({quoteCurrency === 'USDT' && selectedMarket.priceUsdt > 0
                ? `$${formatPrice(selectedMarket.priceUsdt)}`
                : `${formatToman(selectedMarket.priceToman)} ت`})
            </span>
          )}
        </div>
        <ChevronDown
          className={`w-3.5 h-3.5 text-slate-400 shrink-0 transition-transform duration-150 ${
            open ? 'rotate-180 text-cyan-300' : ''
          }`}
        />
      </button>

      {open && (
        <div
          role="listbox"
          aria-label="لیست ارزهای دیجیتال نوبیتکس"
          className="absolute right-0 mt-1.5 z-50 w-72 sm:w-80 max-w-[92vw] rounded-2xl border border-cyan-500/35 bg-[#060D1F]/98 backdrop-blur-xl shadow-[0_20px_50px_rgba(2,6,23,0.9)] overflow-hidden"
        >
          {/* Search Input Header */}
          <div className="p-2.5 border-b border-slate-800/90 bg-[#040916]">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-cyan-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                ref={searchInputRef}
                type="text"
                value={query}
                onChange={(e) => {
                  setQuery(e.target.value);
                  setHighlightedIdx(0);
                }}
                onKeyDown={handleKeyDown}
                placeholder="جستجو (مثلاً BTC، بیت‌کوین، پپه، تون...)"
                className="w-full bg-slate-950 border border-slate-700/80 rounded-xl pr-8 pl-7 py-2 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
              />
              {query && (
                <button
                  type="button"
                  onClick={() => {
                    setQuery('');
                    setHighlightedIdx(0);
                    searchInputRef.current?.focus();
                  }}
                  className="absolute left-2 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white p-0.5"
                  aria-label="پاک کردن جستجو"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
            <div className="mt-1.5 flex items-center justify-between px-1 text-[10px] text-slate-400">
              <span>
                {query.trim()
                  ? `${filteredMarkets.length} ارز پیدا شد`
                  : `همه ارزهای نوبیتکس (${effectiveMarkets.length} ارز)`}
              </span>
              <span className="text-cyan-300/80">تومانی و تتری</span>
            </div>
          </div>

          {/* Options List */}
          <div className="max-h-72 overflow-y-auto divide-y divide-slate-800/50">
            {filteredMarkets.length === 0 ? (
              <div className="py-8 px-4 text-center text-xs text-slate-400 space-y-1">
                <div>هیچ ارزی با «{query}» توی نوبیتکس پیدا نشد 😅</div>
                <div className="text-[11px] text-slate-500">
                  اسم انگلیسی (مثل SOL یا PEPE) یا فارسی رو امتحان کن.
                </div>
              </div>
            ) : (
              filteredMarkets.map((m, idx) => {
                const isSelected = m.baseAsset.toUpperCase() === value.toUpperCase();
                const isHighlighted = idx === highlightedIdx;
                const priceDisplay =
                  quoteCurrency === 'USDT' && m.hasUsdtMarket && m.priceUsdt > 0
                    ? `$${formatPrice(m.priceUsdt)}`
                    : m.priceToman > 0
                      ? `${formatToman(m.priceToman)} ت`
                      : m.priceUsdt > 0
                        ? `$${formatPrice(m.priceUsdt)}`
                        : '—';

                return (
                  <button
                    key={m.baseAsset}
                    type="button"
                    role="option"
                    aria-selected={isSelected}
                    onMouseEnter={() => setHighlightedIdx(idx)}
                    onClick={() => pickCoin(m.baseAsset)}
                    className={`w-full px-3 py-2.5 flex items-center justify-between gap-2 text-right text-xs transition-colors ${
                      isSelected
                        ? 'bg-cyan-500/15 text-white'
                        : isHighlighted
                          ? 'bg-slate-800/75 text-white'
                          : 'text-slate-200 hover:bg-slate-900/80'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className={`font-mono-num font-bold text-[11px] px-1.5 py-0.5 rounded bg-slate-900 border shrink-0 ${
                          isSelected
                            ? 'border-cyan-400/60 text-cyan-300'
                            : 'border-slate-700/80 text-slate-200'
                        }`}
                        dir="ltr"
                      >
                        {m.baseAsset}
                      </span>
                      <span className="truncate font-medium">{m.persianName}</span>
                      {isSelected && <Check className="w-3.5 h-3.5 text-cyan-400 shrink-0" />}
                    </div>

                    <div className="flex items-center gap-2 shrink-0 font-mono-num" dir="ltr">
                      <span className="text-[11px] text-amber-300">{priceDisplay}</span>
                      {m.priceToman > 0 && (
                        <span
                          className={`text-[10px] w-12 text-right ${
                            m.change24hPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {formatPercent(m.change24hPercent)}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
