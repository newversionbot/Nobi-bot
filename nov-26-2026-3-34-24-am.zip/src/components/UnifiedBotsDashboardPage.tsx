import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowUpRight,
  Award,
  BarChart3,
  Bot,
  Cpu,
  Hand,
  Layers,
  Power,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
} from 'lucide-react';
import type {
  AiManagerAnalysis,
  BotType,
  PendingBotConfirmation,
  SharedBotRiskSettings,
  UnifiedBotsDashboardSummary,
  UnifiedBotSummaryRow,
} from '../types/trading';
import { formatQuoteAmount, formatToman } from '../utils/format';
import {
  BotPageShell,
  type BotPageKpi,
  type DedicatedBotTabId,
} from './BotPageShell';
import type { GuideBotTopic } from './BotEducationModal';

interface UnifiedBotsDashboardPageProps {
  dashboard: UnifiedBotsDashboardSummary;
  riskSettings: SharedBotRiskSettings;
  pendingConfirmations: PendingBotConfirmation[];
  aiReport: AiManagerAnalysis | null;
  onBack: () => void;
  onOpenGuide: (topic: GuideBotTopic) => void;
  onNavigateToBot: (botType: BotType) => void;
  onOpenAiManager: () => void;
  onToggleKillSwitch: (active: boolean) => Promise<void>;
  onResolveConfirmation: (conf: PendingBotConfirmation, decision: 'APPROVE' | 'REJECT') => Promise<void>;
}

const BOT_TYPE_BADGE: Record<BotType, { label: string; cls: string }> = {
  AI_CYCLE_PRO: { label: 'چرخه هوشمند AI', cls: 'bg-cyan-500/15 text-cyan-200 border-cyan-500/40' },
  PROFIT: { label: 'ربات سود', cls: 'bg-emerald-500/15 text-emerald-300 border-emerald-500/35' },
  FIXED_PRICE: { label: 'قیمت ثابت', cls: 'bg-teal-500/15 text-teal-300 border-teal-500/35' },
  GRID: { label: 'ربات گرید', cls: 'bg-amber-500/15 text-amber-300 border-amber-500/35' },
  DCA: { label: 'خرید پله‌ای', cls: 'bg-sky-500/15 text-sky-300 border-sky-500/35' },
  STRATEGY: { label: 'استراتژی', cls: 'bg-indigo-500/15 text-indigo-300 border-indigo-500/35' },
};

export const UnifiedBotsDashboardPage: React.FC<UnifiedBotsDashboardPageProps> = ({
  dashboard,
  riskSettings,
  pendingConfirmations,
  aiReport,
  onBack,
  onOpenGuide,
  onNavigateToBot,
  onOpenAiManager,
  onToggleKillSwitch,
  onResolveConfirmation,
}) => {
  const [activeTab, setActiveTab] = useState<DedicatedBotTabId>('OVERVIEW');
  const [filterType, setFilterType] = useState<BotType | 'ALL'>('ALL');

  const filteredRows: UnifiedBotSummaryRow[] =
    filterType === 'ALL'
      ? dashboard.rows
      : dashboard.rows.filter((r) => r.botType === filterType);

  const kpis: BotPageKpi[] = [
    {
      label: 'سود/زیان روزانه و ماهانه (تومان)',
      value: `${dashboard.realizedPnlDailyIrt >= 0 ? '+' : '-'}${formatToman(
        Math.abs(Math.round(dashboard.realizedPnlDailyIrt))
      )} ت`,
      subtext: `ماهانه: ${dashboard.realizedPnlMonthlyIrt >= 0 ? '+' : '-'}${formatToman(
        Math.abs(Math.round(dashboard.realizedPnlMonthlyIrt))
      )} ت`,
      tone: dashboard.realizedPnlDailyIrt >= 0 ? 'positive' : 'negative',
    },
    {
      label: 'سرمایه درگیر / بودجه آزاد',
      value: `${formatToman(Math.round(dashboard.committedCapitalIrt))} ت`,
      subtext: `آزاد: ${formatToman(Math.round(dashboard.freeBudgetIrt))} از ${formatToman(
        Math.round(dashboard.totalBudgetIrt)
      )} ت`,
      tone: 'accent',
    },
    {
      label: 'نرخ موفقیت کل (Win Rate)',
      value: `${dashboard.overallWinRatePercent.toFixed(1)}%`,
      subtext: `${dashboard.closedTradesCount} بسته · ${dashboard.openPositionsCount} باز`,
      tone: dashboard.overallWinRatePercent >= 50 ? 'positive' : 'neutral',
    },
    {
      label: 'کارمزد کل پرداخت‌شده',
      value: `${formatToman(Math.round(dashboard.totalFeesPaidIrt))} ت`,
      subtext: `تتری: $${dashboard.totalFeesPaidUsdt.toFixed(2)}`,
      tone: 'neutral',
    },
  ];

  return (
    <BotPageShell
      topic="AI_MANAGER"
      title="داشبورد یکپارچه همه ربات‌ها"
      subtitle="نمای کامل سود و زیان تحقق‌یافته و تحقق‌نیافته، سرمایه آزاد و درگیر، بهترین و ضعیف‌ترین ربات و کارمزدها"
      icon={<BarChart3 className="w-5 h-5 text-cyan-300" />}
      accentGradient="from-cyan-400 via-indigo-400 to-emerald-400"
      statusLabel={`${dashboard.rows.filter((r) => r.isActive).length} ربات فعال از ${dashboard.rows.length}`}
      statusTone={riskSettings.killSwitchActive ? 'error' : 'active'}
      kpis={kpis}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      onBack={onBack}
      onOpenGuide={onOpenGuide}
      pendingConfirmations={pendingConfirmations}
      onApproveConfirmation={(c) => void onResolveConfirmation(c, 'APPROVE')}
      onRejectConfirmation={(c) => void onResolveConfirmation(c, 'REJECT')}
    >
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-4">
          {/* Realized vs Unrealized & Weekly/Monthly breakdown */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 space-y-1.5">
              <div className="text-xs text-slate-400">سود/زیان هفتگی و ماهانه</div>
              <div className="flex items-center justify-between text-xs font-mono-num">
                <span className="text-slate-300">هفتگی (IRT):</span>
                <span className={dashboard.realizedPnlWeeklyIrt >= 0 ? 'text-emerald-300 font-bold' : 'text-rose-300 font-bold'}>
                  {dashboard.realizedPnlWeeklyIrt >= 0 ? '+' : '-'}
                  {formatToman(Math.abs(Math.round(dashboard.realizedPnlWeeklyIrt)))} ت
                </span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono-num">
                <span className="text-slate-300">ماهانه (IRT):</span>
                <span className={dashboard.realizedPnlMonthlyIrt >= 0 ? 'text-emerald-300 font-bold' : 'text-rose-300 font-bold'}>
                  {dashboard.realizedPnlMonthlyIrt >= 0 ? '+' : '-'}
                  {formatToman(Math.abs(Math.round(dashboard.realizedPnlMonthlyIrt)))} ت
                </span>
              </div>
              <div className="flex items-center justify-between text-xs font-mono-num">
                <span className="text-slate-300">روزانه (USDT):</span>
                <span className={dashboard.realizedPnlDailyUsdt >= 0 ? 'text-emerald-300 font-bold' : 'text-rose-300 font-bold'}>
                  {dashboard.realizedPnlDailyUsdt >= 0 ? '+' : '-'}${Math.abs(dashboard.realizedPnlDailyUsdt).toFixed(2)}
                </span>
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 space-y-1.5">
              <div className="text-xs text-slate-400">سود/زیان تحقق‌نیافته (دارایی‌های باز)</div>
              <div
                className={`text-lg font-extrabold font-mono-num ${
                  dashboard.unrealizedPnlIrt >= 0 ? 'text-emerald-300' : 'text-rose-300'
                }`}
              >
                {dashboard.unrealizedPnlIrt >= 0 ? '+' : '-'}
                {formatToman(Math.abs(Math.round(dashboard.unrealizedPnlIrt)))} ت
              </div>
              <div className="text-[11px] text-slate-400 font-mono-num">
                بخش تتری: {dashboard.unrealizedPnlUsdt >= 0 ? '+' : '-'}$
                {Math.abs(dashboard.unrealizedPnlUsdt).toFixed(2)} · میانگین هر معامله:{' '}
                {formatToman(Math.round(dashboard.avgPnlPerTradeIrt))} ت
              </div>
            </div>

            <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 space-y-2">
              <div className="text-xs text-slate-400">بهترین و ضعیف‌ترین ربات</div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-emerald-300 flex items-center gap-1 font-bold">
                  <Award className="w-3.5 h-3.5" />
                  بهترین:
                </span>
                <span className="text-white truncate max-w-[160px]">
                  {dashboard.bestBot ? dashboard.bestBot.name : '—'}
                </span>
              </div>
              <div className="flex items-center justify-between text-xs">
                <span className="text-rose-300 flex items-center gap-1 font-bold">
                  <TrendingDown className="w-3.5 h-3.5" />
                  ضعیف‌ترین:
                </span>
                <span className="text-white truncate max-w-[160px]">
                  {dashboard.worstBot ? dashboard.worstBot.name : '—'}
                </span>
              </div>
            </div>
          </div>

          {/* Conflict & AI Suggestion Strip */}
          {dashboard.activeConflictSymbols.length > 0 && (
            <div className="rounded-2xl border border-rose-500/40 bg-rose-500/10 p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs text-rose-100">
                <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0" />
                <span>
                  هشدار هم‌زمانی روی نمادهای:{' '}
                  <strong className="font-mono-num text-white">
                    {dashboard.activeConflictSymbols.join('، ')}
                  </strong>
                </span>
              </div>
              <button
                type="button"
                onClick={onOpenAiManager}
                className="min-h-[38px] px-3.5 rounded-xl bg-rose-600/25 border border-rose-500/40 text-rose-100 text-xs font-bold shrink-0"
              >
                بررسی در مدیر هوشمند
              </button>
            </div>
          )}

          {aiReport && (
            <div className="rounded-2xl border border-cyan-500/30 bg-[#0A101D] p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="text-xs font-extrabold text-cyan-300 flex items-center gap-1.5">
                  <Cpu className="w-4 h-4" />
                  پیشنهاد فعلی مدیر هوشمند AI ({aiReport.regimeLabelFa})
                </div>
                <p className="text-xs text-slate-300 leading-6">{aiReport.recommendedPrimaryBotReasonFa}</p>
              </div>
              <button
                type="button"
                onClick={onOpenAiManager}
                className="min-h-[42px] px-4 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/30 border border-cyan-500/40 text-cyan-200 text-xs font-bold shrink-0 flex items-center gap-1.5"
              >
                باز کردن مدیر هوشمند
                <ArrowUpRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Unified Bots Filter + Table/Cards */}
          <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400" />
                وضعیت همه ربات‌های شما ({filteredRows.length})
              </h3>
              <div className="flex flex-wrap items-center gap-1.5 text-xs">
                {(
                  [
                    { id: 'ALL', label: 'همه' },
                    { id: 'AI_CYCLE_PRO', label: 'AI Cycle Pro' },
                    { id: 'PROFIT', label: 'سود' },
                    { id: 'FIXED_PRICE', label: 'قیمت ثابت' },
                    { id: 'GRID', label: 'گرید' },
                    { id: 'DCA', label: 'خرید پله‌ای' },
                    { id: 'STRATEGY', label: 'استراتژی' },
                  ] as const
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setFilterType(tab.id)}
                    className={`min-h-[36px] px-3 rounded-lg border font-bold transition ${
                      filterType === tab.id
                        ? 'border-cyan-500/50 bg-cyan-500/15 text-cyan-200'
                        : 'border-slate-800 bg-slate-900/50 text-slate-400 hover:text-white'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>
            </div>

            {filteredRows.length === 0 ? (
              <div className="rounded-xl border border-slate-800 bg-slate-900/40 p-6 text-center text-xs text-slate-400">
                هنوز رباتی در این دسته ثبت نشده است.
              </div>
            ) : (
              <div className="space-y-2.5">
                {filteredRows.map((row) => {
                  const badge = BOT_TYPE_BADGE[row.botType];
                  return (
                    <div
                      key={row.id}
                      className="rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 flex flex-col lg:flex-row lg:items-center justify-between gap-3"
                    >
                      <div className="space-y-1.5">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className={`px-2 py-0.5 rounded-md border text-[10px] font-bold ${badge.cls}`}>
                            {badge.label}
                          </span>
                          <span className="text-xs sm:text-sm font-extrabold text-white">{row.name}</span>
                          <span className="text-[11px] font-mono-num text-cyan-300">{row.symbol}</span>
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                              row.isActive
                                ? 'bg-emerald-500/15 text-emerald-300'
                                : 'bg-slate-800 text-slate-400'
                            }`}
                          >
                            {row.statusLabelFa}
                          </span>
                        </div>
                        <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-400 font-mono-num">
                          <span>سرمایه درگیر: {formatQuoteAmount(row.committedCapitalQuote, row.quoteCurrency)}</span>
                          <span className={row.realizedPnlQuote >= 0 ? 'text-emerald-300' : 'text-rose-300'}>
                            سود قطعی: {row.realizedPnlQuote >= 0 ? '+' : '-'}
                            {formatQuoteAmount(Math.abs(row.realizedPnlQuote), row.quoteCurrency)}
                          </span>
                          <span className={row.unrealizedPnlQuote >= 0 ? 'text-cyan-300' : 'text-amber-300'}>
                            سود شناور: {row.unrealizedPnlQuote >= 0 ? '+' : '-'}
                            {formatQuoteAmount(Math.abs(row.unrealizedPnlQuote), row.quoteCurrency)}
                          </span>
                          <span>کارمزد: {formatQuoteAmount(row.feesPaidQuote, row.quoteCurrency)}</span>
                          <span>برد: {row.winRatePercent.toFixed(0)}%</span>
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => onNavigateToBot(row.botType)}
                        className="min-h-[40px] px-4 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-cyan-200 text-xs font-bold shrink-0 flex items-center gap-1.5"
                      >
                        <Bot className="w-3.5 h-3.5" />
                        مدیریت ربات
                      </button>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'SETTINGS' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-5 space-y-3 text-xs">
          <div className="flex items-center gap-2 text-sm font-extrabold text-white">
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            محدودیت‌های سرمایه مشترک فعال
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 font-mono-num">
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
              بودجه کل تومانی: {formatToman(riskSettings.totalBotsBudgetIrt)} تومان
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
              سقف هر ربات تومانی: {formatToman(riskSettings.maxPerBotCapitalIrt)} تومان
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
              سقف ضرر روزانه: {formatToman(riskSettings.maxDailyLossIrt)} تومان
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
              قفل تداخل ارز: {riskSettings.enableSymbolConflictLock ? 'روشن' : 'خاموش'}
            </div>
          </div>
          <button
            type="button"
            onClick={onOpenAiManager}
            className="min-h-[42px] px-4 rounded-xl bg-cyan-600/20 border border-cyan-500/40 text-cyan-200 font-bold"
          >
            ویرایش سقف‌ها در صفحه مدیر هوشمند AI
          </button>
        </div>
      )}

      {activeTab === 'EXECUTION' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-5 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                <Power className="w-4 h-4 text-rose-400" />
                توقف اضطراری کل سیستم (Kill Switch)
              </h3>
              <p className="text-xs text-slate-400 mt-1">
                برای توقف هم‌زمان تمام ربات‌ها در شرایط غیرمنتظره بازار استفاده کنید.
              </p>
            </div>
            <button
              type="button"
              onClick={() => void onToggleKillSwitch(!riskSettings.killSwitchActive)}
              className={`min-h-[44px] px-5 rounded-xl text-xs font-extrabold ${
                riskSettings.killSwitchActive
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                  : 'bg-rose-600 hover:bg-rose-500 text-white'
              }`}
            >
              {riskSettings.killSwitchActive ? 'آزادسازی کل سیستم' : 'توقف همه ربات‌ها'}
            </button>
          </div>
          <div className="text-xs text-slate-400 flex items-center gap-1.5">
            <Hand className="w-4 h-4 text-amber-300" />
            تعداد سفارش‌های در انتظار تأیید دستی: {pendingConfirmations.length}
          </div>
        </div>
      )}

      {activeTab === 'HISTORY' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-5 space-y-3 text-xs text-slate-300">
          <div className="flex items-center gap-2 text-sm font-extrabold text-white">
            <TrendingUp className="w-4 h-4 text-emerald-400" />
            خلاصه آماری تاریخچه کل ربات‌ها
          </div>
          <div>مجموع معاملات بسته‌شده: {dashboard.closedTradesCount} معامله</div>
          <div>موقعیت‌های باز فعلی: {dashboard.openPositionsCount} موقعیت</div>
          <div>کارمزد کل پرداختی (تومانی): {formatToman(Math.round(dashboard.totalFeesPaidIrt))} تومان</div>
        </div>
      )}
    </BotPageShell>
  );
};
