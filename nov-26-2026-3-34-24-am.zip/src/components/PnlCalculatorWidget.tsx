import React, { useEffect, useMemo, useState } from 'react';
import { BellPlus, Calculator, RotateCcw, TrendingDown, TrendingUp } from 'lucide-react';
import type {
  PriceAlertCondition,
  QuoteCurrency,
  UnifiedMarketTicker,
} from '../types/trading';
import {
  formatPercent,
  formatPrice,
  formatQuoteAmount,
  formatQuotePrice,
  formatToman,
} from '../utils/format';
import { CoinSearchSelect } from './CoinSearchSelect';
import { NumericInput } from './NumericInput';

interface PnlCalculatorWidgetProps {
  markets: UnifiedMarketTicker[];
  usdtTomanRate: number;
  defaultBaseAsset: string;
  defaultQuoteCurrency: QuoteCurrency;
  onQuoteCurrencyChange?: (qc: QuoteCurrency) => void;
  onCreateAlert?: (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    condition: PriceAlertCondition;
    targetPrice: number;
    sendTelegram?: boolean;
    note?: string;
  }) => Promise<void>;
  onSelectForTrade?: (baseAsset: string, quoteCurrency?: QuoteCurrency) => void;
}

export const PnlCalculatorWidget: React.FC<PnlCalculatorWidgetProps> = ({
  markets,
  usdtTomanRate,
  defaultBaseAsset,
  defaultQuoteCurrency,
  onQuoteCurrencyChange,
  onCreateAlert,
  onSelectForTrade,
}) => {
  const [baseAsset, setBaseAsset] = useState(defaultBaseAsset || 'BTC');
  const [quoteCurrency, setQuoteCurrency] = useState<QuoteCurrency>(defaultQuoteCurrency);
  const [buyPriceStr, setBuyPriceStr] = useState('');
  const [quantityStr, setQuantityStr] = useState('1');
  const [sellPriceStr, setSellPriceStr] = useState('');
  const [feePercentStr, setFeePercentStr] = useState('0.25');
  const [alertSavedMsg, setAlertSavedMsg] = useState<string | null>(null);
  const [savingAlert, setSavingAlert] = useState(false);

  const selectedMarket = useMemo(
    () => markets.find((m) => m.baseAsset === baseAsset) || null,
    [markets, baseAsset]
  );

  const livePrice = selectedMarket
    ? quoteCurrency === 'IRT'
      ? selectedMarket.priceToman
      : selectedMarket.priceUsdt
    : 0;

  useEffect(() => {
    setBaseAsset(defaultBaseAsset || 'BTC');
    setQuoteCurrency(defaultQuoteCurrency);
    setBuyPriceStr('');
    setSellPriceStr('');
    setAlertSavedMsg(null);
  }, [defaultBaseAsset, defaultQuoteCurrency]);

  // Seed initial buy/sell sample based on current market price once loaded if empty
  useEffect(() => {
    if (livePrice > 0 && buyPriceStr === '' && sellPriceStr === '') {
      const formattedBuy =
        quoteCurrency === 'IRT'
          ? String(Math.round(livePrice))
          : String(Number(livePrice.toPrecision(6)));
      const formattedSell =
        quoteCurrency === 'IRT'
          ? String(Math.round(livePrice * 1.1))
          : String(Number((livePrice * 1.1).toPrecision(6)));
      setBuyPriceStr(formattedBuy);
      setSellPriceStr(formattedSell);
    }
  }, [livePrice, quoteCurrency, buyPriceStr, sellPriceStr]);

  const applyLiveBuyPrice = () => {
    if (livePrice <= 0) return;
    const val =
      quoteCurrency === 'IRT'
        ? String(Math.round(livePrice))
        : String(Number(livePrice.toPrecision(6)));
    setBuyPriceStr(val);
    setAlertSavedMsg(null);
  };

  const applyTargetPercent = (pct: number) => {
    const buy = Number(buyPriceStr) || livePrice;
    if (buy <= 0) return;
    const raw = buy * (1 + pct / 100);
    setSellPriceStr(
      quoteCurrency === 'IRT' ? String(Math.round(raw)) : String(Number(raw.toPrecision(6)))
    );
    setAlertSavedMsg(null);
  };

  const calc = useMemo(() => {
    const buy = Number(buyPriceStr);
    const qty = Number(quantityStr);
    const sell = Number(sellPriceStr);
    const feePct = Math.max(0, Math.min(10, Number(feePercentStr) || 0));
    const feeRate = feePct / 100;

    const valid =
      Number.isFinite(buy) &&
      buy > 0 &&
      Number.isFinite(qty) &&
      qty > 0 &&
      Number.isFinite(sell) &&
      sell >= 0;

    if (!valid) {
      return {
        valid: false,
        buyCost: 0,
        grossExit: 0,
        totalFees: 0,
        netExit: 0,
        netPnl: 0,
        roiPercent: 0,
        breakEvenPrice: 0,
        otherNetPnl: 0,
      };
    }

    const buyNotional = buy * qty;
    const buyFee = buyNotional * feeRate;
    const totalInvested = buyNotional + buyFee;

    const grossExit = sell * qty;
    const sellFee = grossExit * feeRate;
    const netExit = grossExit - sellFee;

    const totalFees = buyFee + sellFee;
    const netPnl = netExit - totalInvested;
    const roiPercent = totalInvested > 0 ? (netPnl / totalInvested) * 100 : 0;
    const breakEvenPrice = feeRate < 1 ? (buy * (1 + feeRate)) / (1 - feeRate) : buy;

    const rate = usdtTomanRate > 0 ? usdtTomanRate : 1;
    const otherNetPnl = quoteCurrency === 'IRT' ? netPnl / rate : netPnl * rate;

    return {
      valid: true,
      buyCost: totalInvested,
      grossExit,
      totalFees,
      netExit,
      netPnl,
      roiPercent,
      breakEvenPrice,
      otherNetPnl,
    };
  }, [buyPriceStr, quantityStr, sellPriceStr, feePercentStr, quoteCurrency, usdtTomanRate]);

  const handleSetTargetAlert = async () => {
    if (!onCreateAlert) return;
    const target = Number(sellPriceStr);
    if (!Number.isFinite(target) || target <= 0) return;

    setSavingAlert(true);
    setAlertSavedMsg(null);
    try {
      const condition: PriceAlertCondition =
        livePrice > 0 && target < livePrice ? 'BELOW' : 'ABOVE';
      await onCreateAlert({
        baseAsset,
        quoteCurrency,
        condition,
        targetPrice: target,
        sendTelegram: true,
        note: `هدف سود از ماشین‌حساب PnL (${calc.roiPercent >= 0 ? '+' : ''}${calc.roiPercent.toFixed(2)}%)`,
      });
      setAlertSavedMsg(
        `هشدار قیمت هدف برای ${selectedMarket?.persianName || baseAsset} ثبت شد.`
      );
    } catch (err) {
      setAlertSavedMsg(
        err instanceof Error ? err.message : 'ثبت هشدار قیمت ناموفق بود.'
      );
    } finally {
      setSavingAlert(false);
    }
  };

  const handleReset = () => {
    setQuantityStr('1');
    setFeePercentStr('0.25');
    setAlertSavedMsg(null);
    if (livePrice > 0) {
      setBuyPriceStr(
        quoteCurrency === 'IRT'
          ? String(Math.round(livePrice))
          : String(Number(livePrice.toPrecision(6)))
      );
      setSellPriceStr(
        quoteCurrency === 'IRT'
          ? String(Math.round(livePrice * 1.1))
          : String(Number((livePrice * 1.1).toPrecision(6)))
      );
    } else {
      setBuyPriceStr('');
      setSellPriceStr('');
    }
  };

  const isProfit = calc.netPnl > 0;
  const isLoss = calc.netPnl < 0;

  return (
    <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-3.5 border-b border-slate-800 bg-[#060A14]">
        <div className="flex items-center gap-2.5">
          <Calculator className="w-4 h-4 text-cyan-400" />
          <div>
            <h3 className="text-sm font-semibold text-white">
              ماشین‌حساب حرفه‌ای سود و ضرر معامله (PnL Calculator)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              قیمت خرید، تعداد و قیمت فروش هدف را با اعداد انگلیسی یا فارسی وارد کنید تا سود خالص و درصد بازده معامله با احتساب کارمزد نوبیتکس محاسبه شود
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
            <button
              type="button"
              disabled={selectedMarket ? !selectedMarket.hasIrtMarket : false}
              onClick={() => {
                setQuoteCurrency('IRT');
                setBuyPriceStr('');
                setSellPriceStr('');
                onQuoteCurrencyChange?.('IRT');
              }}
              className={`px-3 py-1 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 ${
                quoteCurrency === 'IRT'
                  ? 'bg-amber-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              تومانی (IRT)
            </button>
            <button
              type="button"
              disabled={selectedMarket ? !selectedMarket.hasUsdtMarket : false}
              onClick={() => {
                setQuoteCurrency('USDT');
                setBuyPriceStr('');
                setSellPriceStr('');
                onQuoteCurrencyChange?.('USDT');
              }}
              className={`px-3 py-1 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 ${
                quoteCurrency === 'USDT'
                  ? 'bg-cyan-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              تتری (USDT)
            </button>
          </div>

          <button
            type="button"
            onClick={handleReset}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 transition-colors whitespace-nowrap shrink-0"
            title="بازنشانی مقادیر به نرخ لحظه‌ای"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>بازنشانی</span>
          </button>
        </div>
      </div>

      {/* Content Grid */}
      <div className="p-5 grid grid-cols-1 xl:grid-cols-12 gap-5">
        {/* Left: Trade Scenario Inputs */}
        <div className="xl:col-span-7 bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">ارز دیجیتال</label>
              <CoinSearchSelect
                markets={markets}
                value={baseAsset}
                quoteCurrency={quoteCurrency}
                size="sm"
                onChange={(next) => {
                  setBaseAsset(next);
                  const m = markets.find((x) => x.baseAsset === next);
                  if (m && quoteCurrency === 'IRT' && !m.hasIrtMarket) setQuoteCurrency('USDT');
                  if (m && quoteCurrency === 'USDT' && !m.hasUsdtMarket) setQuoteCurrency('IRT');
                  setBuyPriceStr('');
                  setSellPriceStr('');
                  setAlertSavedMsg(null);
                }}
                ariaLabel="جستجو و انتخاب ارز ماشین‌حساب سود"
              />
            </div>

            <div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                <span>قیمت خرید ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})</span>
                {livePrice > 0 && (
                  <button
                    type="button"
                    onClick={applyLiveBuyPrice}
                    className="text-cyan-400 hover:underline whitespace-nowrap"
                  >
                    نرخ فعلی
                  </button>
                )}
              </div>
              <NumericInput
                value={buyPriceStr}
                onValueChange={(v) => {
                  setBuyPriceStr(v);
                  setAlertSavedMsg(null);
                }}
                placeholder={quoteCurrency === 'IRT' ? '15000000000' : '70000'}
                className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-2.5 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                تعداد / حجم ({baseAsset})
              </label>
              <NumericInput
                value={quantityStr}
                onValueChange={(v) => setQuantityStr(v)}
                placeholder="1"
                className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-2.5 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">
                قیمت فروش هدف ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})
              </label>
              <NumericInput
                value={sellPriceStr}
                onValueChange={(v) => {
                  setSellPriceStr(v);
                  setAlertSavedMsg(null);
                }}
                placeholder={quoteCurrency === 'IRT' ? '16500000000' : '77000'}
                className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-2.5 py-2 text-xs text-amber-300 placeholder:text-slate-600 focus:outline-none focus:border-amber-400"
              />
            </div>
          </div>

          {/* Target Percentage Presets & Nobitex Fee Rate */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80">
            <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
              <span className="text-slate-400">هدف سریع فروش:</span>
              {[
                { label: '-5%', val: -5 },
                { label: '+5%', val: 5 },
                { label: '+10%', val: 10 },
                { label: '+20%', val: 20 },
                { label: '+50%', val: 50 },
              ].map((preset) => (
                <button
                  key={preset.label}
                  type="button"
                  onClick={() => applyTargetPercent(preset.val)}
                  className={`px-2.5 py-1 rounded bg-[#0A101D] border border-slate-800 hover:border-cyan-500/60 font-mono-num transition-colors ${
                    preset.val < 0 ? 'text-rose-300' : 'text-emerald-300'
                  }`}
                  dir="ltr"
                >
                  {preset.label}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-2 text-[11px]">
              <span className="text-slate-400">کارمزد هر طرف (%):</span>
              <div className="flex items-center gap-1">
                {['0.25', '0.20', '0'].map((f) => (
                  <button
                    key={f}
                    type="button"
                    onClick={() => setFeePercentStr(f)}
                    className={`px-2 py-1 rounded font-mono-num transition-colors ${
                      feePercentStr === f
                        ? 'bg-cyan-500 text-slate-950 font-semibold'
                        : 'bg-[#0A101D] border border-slate-800 text-slate-300 hover:text-white'
                    }`}
                    dir="ltr"
                  >
                    {f}%
                  </button>
                ))}
                <NumericInput
                  value={feePercentStr}
                  onValueChange={(v) => setFeePercentStr(v)}
                  className="w-14 bg-[#0A101D] border border-slate-700 rounded px-2 py-1 text-[11px] text-white focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80 text-xs">
            <div className="text-[11px] text-slate-400">
              قیمت سر‌به‌سر (با احتساب کارمزد خرید و فروش):{' '}
              <span className="font-mono-num text-slate-200 font-semibold" dir="ltr">
                {calc.valid ? formatQuotePrice(calc.breakEvenPrice, quoteCurrency) : '—'}
              </span>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {onCreateAlert && (
                <button
                  type="button"
                  disabled={!calc.valid || savingAlert}
                  onClick={() => void handleSetTargetAlert()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium bg-amber-500/15 border border-amber-500/40 hover:bg-amber-500/25 text-amber-300 transition-colors disabled:opacity-40 whitespace-nowrap shrink-0"
                >
                  <BellPlus className="w-3.5 h-3.5" />
                  <span>{savingAlert ? 'در حال ثبت...' : 'ثبت هشدار قیمت فروش'}</span>
                </button>
              )}

              {onSelectForTrade && (
                <button
                  type="button"
                  onClick={() => onSelectForTrade(baseAsset, quoteCurrency)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors whitespace-nowrap shrink-0"
                >
                  <span>ورود به معامله {baseAsset}</span>
                </button>
              )}
            </div>
          </div>

          {alertSavedMsg && (
            <div className="text-xs px-3 py-2 rounded border bg-emerald-500/10 border-emerald-500/30 text-emerald-300">
              {alertSavedMsg}
            </div>
          )}
        </div>

        {/* Right: Calculated Net PnL & ROI Breakdown */}
        <div className="xl:col-span-5 bg-slate-950 border border-slate-800 rounded-lg p-4 flex flex-col justify-between gap-4">
          <div className="flex items-start justify-between gap-3 pb-3 border-b border-slate-800/90">
            <div>
              <div className="text-xs text-slate-400 mb-1">
                {isLoss ? 'زیان خالص معامله' : 'سود خالص معامله (پس از کسر کارمزد)'}
              </div>
              <div
                className={`text-xl sm:text-2xl font-bold font-mono-num ${
                  isProfit ? 'text-emerald-400' : isLoss ? 'text-rose-400' : 'text-slate-200'
                }`}
                dir="ltr"
              >
                {calc.valid
                  ? `${calc.netPnl > 0 ? '+' : ''}${formatQuoteAmount(calc.netPnl, quoteCurrency)}`
                  : '—'}
              </div>
              {calc.valid && usdtTomanRate > 0 && (
                <div className="text-xs text-slate-400 font-mono-num mt-1" dir="ltr">
                  {quoteCurrency === 'IRT'
                    ? `≈ ${calc.otherNetPnl > 0 ? '+' : ''}$${formatPrice(calc.otherNetPnl)} USDT`
                    : `≈ ${calc.otherNetPnl > 0 ? '+' : ''}${formatToman(calc.otherNetPnl)} تومان`}
                </div>
              )}
            </div>

            <div className="text-left" dir="ltr">
              <div className="text-[11px] text-slate-400 mb-1 text-right">درصد بازده (ROI)</div>
              <div
                className={`inline-flex items-center gap-1.5 text-lg font-bold font-mono-num ${
                  isProfit ? 'text-emerald-400' : isLoss ? 'text-rose-400' : 'text-slate-200'
                }`}
              >
                {isLoss ? (
                  <TrendingDown className="w-4 h-4 shrink-0" />
                ) : (
                  <TrendingUp className="w-4 h-4 shrink-0" />
                )}
                <span>{calc.valid ? formatPercent(calc.roiPercent) : '0.00%'}</span>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 text-xs">
            <div className="space-y-1">
              <div className="text-[11px] text-slate-400">سرمایه ورودی کل</div>
              <div className="font-mono-num font-semibold text-white" dir="ltr">
                {calc.valid ? formatQuoteAmount(calc.buyCost, quoteCurrency) : '—'}
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-[11px] text-slate-400">دریافتی خالص فروش</div>
              <div className="font-mono-num font-semibold text-amber-300" dir="ltr">
                {calc.valid ? formatQuoteAmount(calc.netExit, quoteCurrency) : '—'}
              </div>
            </div>

            <div className="space-y-1">
              <div className="text-[11px] text-slate-400">مجموع کارمزد صرافی</div>
              <div className="font-mono-num font-semibold text-slate-300" dir="ltr">
                {calc.valid ? formatQuoteAmount(calc.totalFees, quoteCurrency) : '—'}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
