import React, { useEffect, useState } from 'react';
import {
  BookOpen,
  ChevronDown,
  HelpCircle,
  Inbox,
  Phone,
  Send,
  ShieldCheck,
  Smartphone,
  Sparkles,
  X,
} from 'lucide-react';

export type SupportGuideTab = 'GUIDE' | 'FAQ' | 'SUPPORT';

interface SupportGuideModalProps {
  open: boolean;
  initialTab?: SupportGuideTab;
  onClose: () => void;
  supportPhone: string;
  supportTelegram?: string;
  onOpenPWAInstall: () => void;
  onOpenTelegramSettings: () => void;
  onOpenInbox: () => void;
}

const FAQ_ITEMS = [
  {
    q: 'آیا ربات بدون اجازه من معامله واقعی انجام می‌دهد؟',
    a: 'خیر. تا زمانی که کلید API صرافی را ثبت نکنید و خودتان به‌صورت صریح حالت ربات را روی «حساب واقعی (Live)» قرار ندهید و دکمه شروع را تأیید نکنید، هیچ سفارش واقعی در نوبیتکس ثبت نمی‌شود.',
  },
  {
    q: 'تفاوت «حالت نمایشی (دمو)» با «حالت آزمایشی (Paper)» چیست؟',
    a: 'حالت نمایشی (دمو) برای آزمایش کامل امکانات روی گوشی بدون نیاز به ورود یا پرداخت است و داده‌های آن با برچسب واضح دمو مشخص می‌شوند. حالت آزمایشی (Paper) مخصوص کاربران واردشده است که می‌خواهند استراتژی خود را روی حساب شخصی با موجودی شبیه‌سازی‌شده تست کنند.',
  },
  {
    q: 'چگونه گزارش معاملات و سود و زیان ربات را در تلگرام دریافت کنم؟',
    a: 'از منوی کناری وارد بخش «تنظیمات و تلگرام» شوید، توکن ربات تلگرام (ساخته‌شده در BotFather) و شناسه عددی چت را وارد کرده و نوع ارسال (دستی یا خودکار) را مشخص کنید. مقدار Realized PnL به تومان، تتر و درصد نیز همراه پیام ارسال می‌شود.',
  },
  {
    q: 'چطور پاداش ۴ روز اشتراک رایگان از طریق دعوت دوستان بگیرم؟',
    a: 'در صفحه «خرید اشتراک» یا «تنظیمات حساب»، لینک یا کد اختصاصی دعوت خود را کپی و برای دوستانتان بفرستید. به ازای هر دوستی که با لینک شما ثبت‌نام و اشتراک تهیه کند، ۴ روز اشتراک ویژه هدیه می‌گیرید.',
  },
  {
    q: 'چگونه برنامه را روی گوشی اندروید یا آیفون نصب کنم؟',
    a: 'برنامه به صورت وب‌اپلیکیشن پیشرفته (PWA) طراحی شده است. با زدن دکمه «نصب اپ روی گوشی» در منو، راهنمای گام‌به‌گام افزودن به صفحه اصلی مرورگر Chrome یا Safari را مشاهده می‌کنید.',
  },
];

export const SupportGuideModal: React.FC<SupportGuideModalProps> = ({
  open,
  initialTab = 'GUIDE',
  onClose,
  supportPhone,
  supportTelegram,
  onOpenPWAInstall,
  onOpenTelegramSettings,
  onOpenInbox,
}) => {
  const [tab, setTab] = useState<SupportGuideTab>(initialTab);
  const [openFaqIdx, setOpenFaqIdx] = useState<number>(0);

  useEffect(() => {
    if (open) setTab(initialTab);
  }, [open, initialTab]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [open, onClose]);

  if (!open) return null;

  const cleanTelegram = (supportTelegram || '').replace(/^@/, '').trim();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-md p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-labelledby="support-guide-title"
    >
      <div
        className="w-full max-w-2xl glass-panel rounded-2xl overflow-hidden shadow-2xl border-cyan-400/30"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between gap-3 px-5 py-4 border-b border-slate-800/80 bg-[#050C1B]">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center">
              <BookOpen className="w-4 h-4 text-cyan-300" />
            </div>
            <div>
              <h2 id="support-guide-title" className="text-sm sm:text-base font-bold text-white">
                مرکز راهنما، سوالات متداول و پشتیبانی AI NobiBot (ainobibot.ir)
              </h2>
              <p className="text-[11px] text-slate-400">
                آموزش کار با ربات معامله‌گر، اتصال امن نوبیتکس و ارتباط سریع با پشتیبانی
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="btn-glass btn-glass-neutral p-2 rounded-xl"
            title="بستن"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Section Tabs */}
        <div className="px-5 pt-4 flex flex-wrap gap-2">
          {(
            [
              { id: 'GUIDE', label: 'راهنمای کامل شروع', icon: BookOpen },
              { id: 'FAQ', label: 'سوالات متداول', icon: HelpCircle },
              { id: 'SUPPORT', label: 'پشتیبانی و تماس', icon: Phone },
            ] as const
          ).map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setTab(item.id)}
                className={`btn-glass inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold ${
                  tab === item.id ? 'btn-glass-primary' : 'btn-glass-neutral'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Body */}
        <div className="p-5 max-h-[68vh] overflow-y-auto space-y-4 text-xs">
          {tab === 'GUIDE' && (
            <div className="space-y-3">
              {[
                {
                  step: '۱',
                  title: 'بررسی بازار و آزمایش رایگان در حالت دمو',
                  desc: 'ابتدا می‌توانید با فعال‌سازی «حالت نمایشی (دمو)» از نوار بالا، تمامی نمودارها، ربات معامله‌گر، هشدارهای قیمت و گزارش تلگرام را بدون نیاز به سرمایه واقعی تست کنید.',
                },
                {
                  step: '۲',
                  title: 'ورود امن و اتصال کلید API نوبیتکس',
                  desc: 'در بخش «تنظیمات حساب»، با حساب گوگل وارد شوید و توکن API نوبیتکس خود را (فقط با دسترسی مشاهده و معامله، بدون دسترسی برداشت) ذخیره کنید.',
                },
                {
                  step: '۳',
                  title: 'ساخت ربات و بک‌تست استراتژی',
                  desc: 'در صفحه «ربات معامله‌گر»، جفت‌ارز تومانی یا تتری، قوانین RSI / EMA / MACD / Bollinger و حد سود و ضرر را تنظیم کرده و قبل از اجرا روی داده‌های گذشته بک‌تست بگیرید.',
                },
                {
                  step: '۴',
                  title: 'اتصال گزارش‌دهی لحظه‌ای به ربات تلگرام',
                  desc: 'از منوی «تنظیمات و تلگرام»، توکن ربات تلگرام را وصل کنید تا گزارش خرید و فروش، پایش وضعیت و محاسبه سود و زیان تحقق‌یافته (Realized PnL) به موبایل شما ارسال شود.',
                },
              ].map((s) => (
                <div
                  key={s.step}
                  className="rounded-xl border border-slate-800/80 bg-slate-950/65 p-3.5 flex items-start gap-3"
                >
                  <span className="w-7 h-7 rounded-lg bg-cyan-500/20 border border-cyan-400/40 text-cyan-200 font-bold flex items-center justify-center shrink-0">
                    {s.step}
                  </span>
                  <div className="space-y-1">
                    <div className="font-semibold text-white">{s.title}</div>
                    <p className="text-slate-300/90 leading-relaxed">{s.desc}</p>
                  </div>
                </div>
              ))}

              <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3.5 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2 text-emerald-200">
                  <Smartphone className="w-4 h-4 shrink-0" />
                  <span>می‌خواهید AI NobiBot را مثل اپلیکیشن اندروید روی گوشی نصب کنید؟</span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenPWAInstall();
                  }}
                  className="btn-glass btn-glass-buy px-3 py-1.5 rounded-lg font-semibold"
                >
                  باز کردن راهنمای نصب موبایل
                </button>
              </div>
            </div>
          )}

          {tab === 'FAQ' && (
            <div className="space-y-2.5">
              {FAQ_ITEMS.map((item, idx) => {
                const isOpen = openFaqIdx === idx;
                return (
                  <div
                    key={item.q}
                    className="rounded-xl border border-slate-800/80 bg-slate-950/70 overflow-hidden"
                  >
                    <button
                      type="button"
                      onClick={() => setOpenFaqIdx(isOpen ? -1 : idx)}
                      className="w-full px-4 py-3 flex items-center justify-between gap-3 text-right font-semibold text-white hover:bg-slate-900/60 transition-colors"
                    >
                      <span>{item.q}</span>
                      <ChevronDown
                        className={`w-4 h-4 text-cyan-300 shrink-0 transition-transform duration-200 ${
                          isOpen ? 'rotate-180' : ''
                        }`}
                      />
                    </button>
                    {isOpen && (
                      <div className="px-4 pb-3.5 text-slate-300 leading-relaxed border-t border-slate-800/60 pt-2.5">
                        {item.a}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}

          {tab === 'SUPPORT' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href={`tel:${supportPhone}`}
                  className="rounded-xl border border-cyan-500/35 bg-cyan-500/10 hover:bg-cyan-500/15 p-4 flex items-center gap-3 transition-colors"
                >
                  <div className="w-10 h-10 rounded-full bg-cyan-500/20 border border-cyan-400/50 flex items-center justify-center shrink-0">
                    <Phone className="w-4 h-4 text-cyan-300" />
                  </div>
                  <div>
                    <div className="font-semibold text-white">تماس تلفنی پشتیبانی</div>
                    <div className="font-mono-num text-cyan-300 mt-0.5" dir="ltr">
                      {supportPhone}
                    </div>
                  </div>
                </a>

                {cleanTelegram ? (
                  <a
                    href={`https://t.me/${cleanTelegram}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="rounded-xl border border-sky-500/35 bg-sky-500/10 hover:bg-sky-500/15 p-4 flex items-center gap-3 transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-sky-500/20 border border-sky-400/50 flex items-center justify-center shrink-0">
                      <Send className="w-4 h-4 text-sky-300" />
                    </div>
                    <div>
                      <div className="font-semibold text-white">پشتیبانی تلگرام</div>
                      <div className="font-mono-num text-sky-300 mt-0.5" dir="ltr">
                        @{cleanTelegram}
                      </div>
                    </div>
                  </a>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      onClose();
                      onOpenTelegramSettings();
                    }}
                    className="rounded-xl border border-sky-500/35 bg-sky-500/10 hover:bg-sky-500/15 p-4 flex items-center gap-3 text-right transition-colors"
                  >
                    <div className="w-10 h-10 rounded-full bg-sky-500/20 border border-sky-400/50 flex items-center justify-center shrink-0">
                      <Send className="w-4 h-4 text-sky-300" />
                    </div>
                    <div>
                      <div className="font-semibold text-white">تنظیم ربات تلگرام شخصی</div>
                      <div className="text-slate-300 mt-0.5">اتصال ربات گزارش‌دهی لحظه‌ای</div>
                    </div>
                  </button>
                )}
              </div>

              <div className="rounded-xl border border-slate-800/80 bg-slate-950/65 p-4 flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <Inbox className="w-4 h-4 text-amber-300 shrink-0" />
                  <span className="text-slate-200">
                    اطلاعیه‌های عمومی و پیام‌های اختصاصی مدیریت در صندوق پیام شما قابل مشاهده است.
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    onOpenInbox();
                  }}
                  className="btn-glass btn-glass-amber px-3.5 py-1.5 rounded-lg font-semibold"
                >
                  باز کردن صندوق پیام‌ها
                </button>
              </div>

              <div className="rounded-xl border border-slate-800/70 bg-slate-950/50 p-3.5 flex items-center gap-2.5 text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  نکته امنیتی: پشتیبانی هرگز رمز عبور صرافی یا کلید برداشت وجه شما را درخواست نمی‌کند.
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 border-t border-slate-800/80 bg-[#050C1B] flex items-center justify-between gap-2 text-xs">
          <span className="inline-flex items-center gap-1.5 text-slate-400">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI NobiBot — ainobibot.ir</span>
          </span>
          <button
            type="button"
            onClick={onClose}
            className="btn-glass btn-glass-neutral px-4 py-1.5 rounded-xl font-semibold"
          >
            بستن
          </button>
        </div>
      </div>
    </div>
  );
};
