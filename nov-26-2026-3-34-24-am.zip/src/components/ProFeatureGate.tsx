import React from 'react';
import { Bot, BrainCircuit, CheckCircle2, CreditCard, Eye, Lock, Send, Sparkles, TrendingUp } from 'lucide-react';
import { formatPrice, formatToman } from '../utils/format';

interface ProFeatureGateProps {
  featureTitle: string;
  featureDescription: string;
  monthlyPriceToman: number;
  monthlyPriceUsdt: number;
  isAuthenticated: boolean;
  onSignIn: () => Promise<void>;
  onOpenSubscription: () => void;
  onEnterDemoMode?: () => void;
}

export const ProFeatureGate: React.FC<ProFeatureGateProps> = ({
  featureTitle,
  featureDescription,
  monthlyPriceToman,
  monthlyPriceUsdt,
  isAuthenticated,
  onSignIn,
  onOpenSubscription,
  onEnterDemoMode,
}) => {
  return (
    <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden">
      <div className="px-6 py-5 border-b border-slate-800 bg-[#060A14] flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-amber-500/15 border border-amber-500/40 flex items-center justify-center shrink-0">
            <Lock className="w-5 h-5 text-amber-400" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-semibold text-white">{featureTitle}</h2>
            <p className="text-xs text-slate-400 mt-0.5">{featureDescription}</p>
          </div>
        </div>

        <div className="text-left" dir="ltr">
          <div className="text-base sm:text-lg font-bold font-mono-num text-amber-300">
            {formatToman(monthlyPriceToman)} تومان / ماه
          </div>
          <div className="text-[11px] font-mono-num text-cyan-300">
            ≈ ${formatPrice(monthlyPriceUsdt)} USDT
          </div>
        </div>
      </div>

      <div className="p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
        <div className="lg:col-span-7 space-y-4">
          <div className="text-xs text-slate-300 leading-relaxed">
            امکانات پایه برنامه (مشاهده قیمت‌های لحظه‌ای نوبیتکس، ماشین‌حساب سود و ضرر و هشدار قیمت مرورگر) برای عموم آزاد است. برای استفاده از ابزارهای تخصصی زیر، اشتراک حرفه‌ای ماهانه مورد نیاز است:
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 text-xs">
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 flex items-start gap-2.5">
              <TrendingUp className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-white">ترمینال معاملات و سود پرتفوی</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  خرید و فروش اسپات تومانی و تتری متصل به API نوبیتکس و محاسبه سود دارایی
                </div>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 flex items-start gap-2.5">
              <BrainCircuit className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-white">تحلیل هوش مصنوعی و اخبار</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  اسکنر چندتایم‌فریمی، نقطه ورود/خروج هوشمند و سنجش احساسات بازار
                </div>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 flex items-start gap-2.5">
              <Bot className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-white">ربات معامله‌گر خودکار و بک‌تست</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  اجرای ۲۴ ساعته استراتژی با حد سود/ضرر متحرک و تست روی تاریخچه نوبیتکس
                </div>
              </div>
            </div>

            <div className="bg-slate-950 border border-slate-800 rounded-lg p-3 flex items-start gap-2.5">
              <Send className="w-4 h-4 text-cyan-300 shrink-0 mt-0.5" />
              <div>
                <div className="font-semibold text-white">ربات تلگرام و گزارش دوره‌ای</div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  ارسال خودکار هشدار قیمت و قیمت لحظه‌ای هر X دقیقه در تلگرام شما
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-5 bg-slate-950 border border-slate-800 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <span className="text-sm font-semibold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>اشتراک ماهانه حرفه‌ای</span>
            </span>
            <span className="text-xs font-mono-num text-emerald-400 font-semibold">30 روز کامل</span>
          </div>

          <ul className="space-y-2 text-xs text-slate-300">
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span>پرداخت ریالی آنلاین (آماده اتصال به زرین‌پال): {formatToman(monthlyPriceToman)} تومان</span>
            </li>
            <li className="flex items-center gap-2">
              <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
              <span>پرداخت دلاری (تتر / USDT) به کیف پول مستقیم</span>
            </li>
          </ul>

          <div className="pt-1 flex flex-col gap-2.5">
            {!isAuthenticated && (
              <button
                type="button"
                onClick={() => void onSignIn()}
                className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-slate-800 hover:bg-slate-700 text-white transition-colors whitespace-nowrap"
              >
                ابتدا ورود با حساب گوگل
              </button>
            )}

            <button
              type="button"
              onClick={onOpenSubscription}
              className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-xs font-semibold bg-amber-500 hover:bg-amber-400 text-slate-950 transition-colors whitespace-nowrap shrink-0"
            >
              <CreditCard className="w-4 h-4" />
              <span>مشاهده پلن و خرید اشتراک ({formatToman(monthlyPriceToman)} تومان)</span>
            </button>

            {onEnterDemoMode && (
              <button
                type="button"
                onClick={onEnterDemoMode}
                className="w-full inline-flex items-center justify-center gap-2 py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500/15 border border-cyan-500/40 hover:bg-cyan-500/25 text-cyan-200 transition-colors whitespace-nowrap shrink-0"
              >
                <Eye className="w-4 h-4 text-cyan-300" />
                <span>تست کامل در حالت نمایشی (دمو رایگان بدون ثبت‌نام)</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};
