import React from 'react';
import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import type { QuoteCurrency, UnifiedMarketTicker } from '../types/trading';
import { formatPercent, formatPrice, formatToman } from '../utils/format';

interface LiveTickerTapeProps {
  markets: UnifiedMarketTicker[];
  selectedBaseAsset: string;
  quoteCurrency: QuoteCurrency;
  onQuoteCurrencyChange: (qc: QuoteCurrency) => void;
  onSelectCoin: (baseAsset: string, preferredQuote?: QuoteCurrency) => void;
}

export const LiveTickerTape: React.FC<LiveTickerTapeProps> = ({
  markets,
  selectedBaseAsset,
  quoteCurrency,
  onQuoteCurrencyChange,
  onSelectCoin,
}) => {
  const topPairs = markets
    .filter((m) => (quoteCurrency === 'IRT' ? m.hasIrtMarket : m.hasUsdtMarket))
    .slice(0, 14);

  const displayPairs = topPairs.length > 0 ? topPairs : markets.slice(0, 14);

  if (displayPairs.length === 0) {
    return (
      <div className="bg-[#0A101D] border border-slate-800/90 rounded-lg px-4 py-2.5 text-xs text-slate-400">
        در حال دریافت قیمت لحظه‌ای تومانی و تتری از صرافی نوبیتکس...
      </div>
    );
  }

  const renderItems = (keyPrefix: string) =>
    displayPairs.map((m) => {
      const isUp = m.change24hPercent >= 0;
      const isActive = m.baseAsset === selectedBaseAsset;
      const targetQuote: QuoteCurrency =
        quoteCurrency === 'IRT'
          ? m.hasIrtMarket
            ? 'IRT'
            : 'USDT'
          : m.hasUsdtMarket
            ? 'USDT'
            : 'IRT';

      return (
        <button
          key={`${keyPrefix}-${m.baseAsset}`}
          type="button"
          onClick={() => onSelectCoin(m.baseAsset, targetQuote)}
          className={`btn-glass inline-flex items-center gap-3 px-3.5 py-1.5 rounded-lg whitespace-nowrap shrink-0 ${
            isActive ? 'btn-glass-primary' : 'btn-glass-neutral'
          }`}
        >
          <span className="text-xs font-semibold font-mono-num text-white">
            {m.baseAsset}
          </span>
          {quoteCurrency === 'IRT' ? (
            <>
              <span className="text-xs font-mono-num font-semibold text-amber-300">
                {formatToman(m.priceToman)} ت
              </span>
              <span className="text-[11px] font-mono-num text-slate-400">
                ${formatPrice(m.priceUsdt)}
              </span>
            </>
          ) : (
            <>
              <span className="text-xs font-mono-num font-semibold text-cyan-300">
                ${formatPrice(m.priceUsdt)} USDT
              </span>
              <span className="text-[11px] font-mono-num text-amber-300/80">
                {formatToman(m.priceToman)} ت
              </span>
            </>
          )}
          <span
            className={`inline-flex items-center gap-0.5 text-[11px] font-mono-num font-medium ${
              isUp ? 'text-emerald-400' : 'text-rose-400'
            }`}
          >
            {isUp ? (
              <ArrowUpRight className="w-3 h-3" />
            ) : (
              <ArrowDownRight className="w-3 h-3" />
            )}
            {formatPercent(m.change24hPercent)}
          </span>
        </button>
      );
    });

  return (
    <div
      className="glass-strip rounded-xl overflow-hidden py-2 px-2.5 flex items-center gap-2.5"
      aria-label="نوار قیمت لحظه‌ای تومانی و تتری نوبیتکس"
    >
      <div className="flex items-center gap-1 bg-slate-950/80 p-1 rounded-lg border border-slate-800/80 text-[11px] shrink-0">
        <button
          type="button"
          onClick={() => onQuoteCurrencyChange('IRT')}
          className={`btn-glass px-2.5 py-1 rounded-md font-medium whitespace-nowrap shrink-0 ${
            quoteCurrency === 'IRT'
              ? 'btn-glass-amber font-semibold'
              : 'border border-transparent bg-transparent shadow-none text-slate-400 hover:text-white'
          }`}
        >
          تومانی (IRT)
        </button>
        <button
          type="button"
          onClick={() => onQuoteCurrencyChange('USDT')}
          className={`btn-glass px-2.5 py-1 rounded-md font-medium whitespace-nowrap shrink-0 ${
            quoteCurrency === 'USDT'
              ? 'btn-glass-primary font-semibold'
              : 'border border-transparent bg-transparent shadow-none text-slate-400 hover:text-white'
          }`}
        >
          تتری (USDT)
        </button>
      </div>

      <div dir="ltr" className="ticker-tape-viewport overflow-hidden flex-1">
        <div className="ticker-tape-track flex items-center gap-2.5 w-max">
          {renderItems('a')}
          {renderItems('b')}
        </div>
      </div>
    </div>
  );
};
