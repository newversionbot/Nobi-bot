import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Bot, BrainCircuit, MessageCircle, Send, Sparkles, Trash2, TrendingUp } from 'lucide-react';
import type {
  AiAskResponse,
  AiChatTurn,
  AiCoinAnalysis,
  IndicatorSnapshot,
  QuoteCurrency,
  UnifiedMarketTicker,
} from '../types/trading';
import {
  formatDateTimeShort,
  formatPercent,
  formatPrice,
  formatToman,
} from '../utils/format';
import { getFirebaseAuthHeaders } from '../firebase';
import { parseApiJson } from '../utils/api';
import {
  computeDemoAiAnalysis,
  computeDemoAskReply,
  computeDemoMultiSnapshots,
} from '../utils/demoSandbox';
import { SentimentAnalysisWidget } from './SentimentAnalysisWidget';
import { CoinSearchSelect } from './CoinSearchSelect';

interface CoinAnalysisProps {
  baseAsset: string;
  quoteCurrency: QuoteCurrency;
  onBaseAssetChange: (base: string) => void;
  onQuoteCurrencyChange: (qc: QuoteCurrency) => void;
  markets: UnifiedMarketTicker[];
  usdtTomanRate?: number;
  demoMode?: boolean;
  onGoToTrade: (baseAsset: string, quoteCurrency?: QuoteCurrency) => void;
  onGoToBot: (baseAsset: string, quoteCurrency?: QuoteCurrency) => void;
}

export const CoinAnalysis: React.FC<CoinAnalysisProps> = ({
  baseAsset,
  quoteCurrency,
  onBaseAssetChange,
  onQuoteCurrencyChange,
  markets,
  usdtTomanRate = 0,
  demoMode = false,
  onGoToTrade,
  onGoToBot,
}) => {
  const [snapshots, setSnapshots] = useState<IndicatorSnapshot[]>([]);
  const [activeTfIdx, setActiveTfIdx] = useState(1); // default 1h
  const [loadingTech, setLoadingTech] = useState(true);
  const [techError, setTechError] = useState<string | null>(null);

  const [question, setQuestion] = useState('');
  const [aiAnalysis, setAiAnalysis] = useState<AiCoinAnalysis | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);

  const [askInput, setAskInput] = useState('');
  const [chatHistory, setChatHistory] = useState<AiChatTurn[]>([]);
  const [askingBuddy, setAskingBuddy] = useState(false);
  const [askError, setAskError] = useState<string | null>(null);
  const [suggestedFollowUps, setSuggestedFollowUps] = useState<string[]>([
    'الان وقت خریده یا یه کم دیگه صبر کنم؟',
    'اگه بازار قرمز شد چیکار کنم که ضرر نکنم؟ 😅',
    'با پول کم تو نوبیتکس چطور نوسان بگیرم؟',
    'اوضاع تتر و بقیه ارزها الان چطوره؟',
  ]);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const market = useMemo(
    () => markets.find((m) => m.baseAsset === baseAsset) || null,
    [markets, baseAsset]
  );

  const effectiveQuote: QuoteCurrency = market
    ? quoteCurrency === 'IRT'
      ? market.hasIrtMarket
        ? 'IRT'
        : 'USDT'
      : market.hasUsdtMarket
        ? 'USDT'
        : 'IRT'
    : quoteCurrency;

  const preferredSymbol = market
    ? effectiveQuote === 'IRT'
      ? market.symbolIrt
      : market.symbolUsdt
    : `${baseAsset}${effectiveQuote}`;

  useEffect(() => {
    let cancelled = false;
    setLoadingTech(true);
    setTechError(null);
    setAiAnalysis(null);
    setAiError(null);

    if (demoMode) {
      fetch(`/api/market/klines?symbol=${encodeURIComponent(preferredSymbol)}&interval=1h&limit=120`)
        .then((res) => (res.ok ? res.json() : { candles: [] }))
        .then((data) => {
          if (!cancelled) {
            setSnapshots(
              computeDemoMultiSnapshots(preferredSymbol, market, data.candles || [], usdtTomanRate)
            );
          }
        })
        .catch(() => {
          if (!cancelled) {
            setSnapshots(computeDemoMultiSnapshots(preferredSymbol, market, [], usdtTomanRate));
          }
        })
        .finally(() => {
          if (!cancelled) setLoadingTech(false);
        });

      return () => {
        cancelled = true;
      };
    }

    getFirebaseAuthHeaders()
      .then((headers) =>
        fetch(`/api/market/multi-analysis?symbol=${encodeURIComponent(preferredSymbol)}`, {
          headers,
        })
      )
      .then((res) =>
        parseApiJson<IndicatorSnapshot[]>(
          res,
          'اطلاعات کندل برای این نماد در نوبیتکس یافت نشد.'
        )
      )
      .then((data) => {
        if (!cancelled) setSnapshots(data);
      })
      .catch((err) => {
        if (!cancelled) {
          setSnapshots([]);
          setTechError(err instanceof Error ? err.message : 'خطای ارتباط');
        }
      })
      .finally(() => {
        if (!cancelled) setLoadingTech(false);
      });

    return () => {
      cancelled = true;
    };
  }, [preferredSymbol, demoMode, market, usdtTomanRate]);

  const handleRunAi = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoadingAi(true);
    setAiError(null);
    if (demoMode) {
      setAiAnalysis(
        computeDemoAiAnalysis({
          symbol: preferredSymbol,
          baseAsset,
          market,
          usdtTomanRate,
          question: question.trim() || undefined,
        })
      );
      setLoadingAi(false);
      return;
    }
    try {
      const authHeaders = await getFirebaseAuthHeaders();
      const res = await fetch('/api/ai/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({
          symbol: preferredSymbol,
          question: question.trim() || undefined,
        }),
      });
      const data = await parseApiJson<AiCoinAnalysis>(res, 'تولید تحلیل هوش مصنوعی ناموفق بود.');
      setAiAnalysis(data);
    } catch (err) {
      setAiError(err instanceof Error ? err.message : 'خطا در دریافت تحلیل AI');
    } finally {
      setLoadingAi(false);
    }
  };

  useEffect(() => {
    if (chatHistory.length > 0) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }
  }, [chatHistory, askingBuddy]);

  const handleAskBuddy = async (customText?: string) => {
    const promptText = (customText ?? askInput).trim();
    if (!promptText || askingBuddy) return;

    const userTurn: AiChatTurn = {
      role: 'user',
      text: promptText,
      timestamp: Date.now(),
    };
    const nextHistory = [...chatHistory, userTurn];
    setChatHistory(nextHistory);
    if (!customText) setAskInput('');
    setAskError(null);
    setAskingBuddy(true);

    if (demoMode) {
      const demoReply = computeDemoAskReply({
        question: promptText,
        baseAsset,
        markets,
        usdtTomanRate,
      });
      setChatHistory([
        ...nextHistory,
        {
          role: 'assistant',
          text: demoReply.answer,
          timestamp: Date.now(),
        },
      ]);
      setSuggestedFollowUps(demoReply.suggestedFollowUps);
      setAskingBuddy(false);
      return;
    }

    try {
      const authHeaders = await getFirebaseAuthHeaders();
      const res = await fetch('/api/ai/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', ...authHeaders },
        body: JSON.stringify({
          symbol: preferredSymbol,
          question: promptText,
          history: chatHistory.slice(-8),
        }),
      });
      const data = await parseApiJson<AiAskResponse>(
        res,
        'الان همیار هوشمند یه لحظه حواسش پرت شد، دوباره بپرس رفیق!'
      );
      setChatHistory([
        ...nextHistory,
        {
          role: 'assistant',
          text: data.answer,
          timestamp: data.generatedAt || Date.now(),
        },
      ]);
      if (Array.isArray(data.suggestedFollowUps) && data.suggestedFollowUps.length > 0) {
        setSuggestedFollowUps(data.suggestedFollowUps);
      }
    } catch (err) {
      setAskError(
        err instanceof Error
          ? err.message
          : 'الان مغز هوش مصنوعی یه لحظه شلوغ شده، یه چند ثانیه دیگه دوباره بپرس!'
      );
    } finally {
      setAskingBuddy(false);
    }
  };

  const snap = snapshots[activeTfIdx] || snapshots[0] || null;

  const badgeTone = (action: IndicatorSnapshot['signal']['action'] | AiCoinAnalysis['stance']) => {
    if (action === 'STRONG_BUY' || action === 'BUY') return 'text-emerald-400';
    if (action === 'STRONG_SELL' || action === 'SELL') return 'text-rose-400';
    return 'text-amber-300';
  };

  const stanceBg = (stance: AiCoinAnalysis['stance']) => {
    if (stance === 'STRONG_BUY' || stance === 'BUY') {
      return 'bg-emerald-500/10 border-emerald-500/40';
    }
    if (stance === 'STRONG_SELL' || stance === 'SELL') {
      return 'bg-rose-500/10 border-rose-500/40';
    }
    return 'bg-amber-500/10 border-amber-500/40';
  };

  return (
    <div className="space-y-6">
      {/* Header & Coin Picker (with Dual Prices) */}
      <div className="glass-panel rounded-xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-4">
          <div className="flex items-center gap-3">
            <img
              src="/icon.svg"
              alt="AI NobiBot — ainobibot.ir"
              className="w-10 h-10 rounded-lg object-cover border border-cyan-500/40 bg-slate-950/80 p-1 shrink-0"
            />
            <div>
              <h2 className="text-base font-semibold text-white">
                تحلیل باحال و خودمونی + از من بپرس (نوبیتکس)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                بدون کلمات قلمبه‌سلمبه! هم ارزی که می‌خوای رو جستجو کن و هم هر سوالی داری راحت بپرس
              </p>
            </div>
          </div>
          <div className="w-56 sm:w-64">
            <CoinSearchSelect
              markets={markets}
              value={baseAsset}
              onChange={(nextBase) => onBaseAssetChange(nextBase)}
              quoteCurrency={effectiveQuote}
              showPriceInTrigger
              ariaLabel="جستجو و انتخاب ارز برای تحلیل"
            />
          </div>

          {market && (
            <div className="flex items-center gap-3 text-xs font-mono-num" dir="ltr">
              <span className="text-amber-300 font-semibold">
                {formatToman(market.priceToman)} ت
              </span>
              <span className="text-slate-300">${formatPrice(market.priceUsdt)}</span>
              <span className={market.change24hPercent >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                {formatPercent(market.change24hPercent)}
              </span>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 bg-slate-950/75 p-1 rounded-xl border border-slate-800/90 text-xs">
            <button
              type="button"
              disabled={market ? !market.hasIrtMarket : false}
              onClick={() => onQuoteCurrencyChange('IRT')}
              className={`btn-glass px-3 py-1.5 rounded-lg font-medium whitespace-nowrap shrink-0 ${
                effectiveQuote === 'IRT'
                  ? 'btn-glass-amber font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              بازار تومانی (IRT)
            </button>
            <button
              type="button"
              disabled={market ? !market.hasUsdtMarket : false}
              onClick={() => onQuoteCurrencyChange('USDT')}
              className={`btn-glass px-3 py-1.5 rounded-lg font-medium whitespace-nowrap shrink-0 ${
                effectiveQuote === 'USDT'
                  ? 'btn-glass-primary font-semibold'
                  : 'btn-glass-neutral text-slate-300'
              }`}
            >
              بازار تتری (USDT)
            </button>
          </div>

          <button
            type="button"
            onClick={() => onGoToTrade(baseAsset, effectiveQuote)}
            className="btn-glass btn-glass-buy inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0"
          >
            <TrendingUp className="w-4 h-4 text-emerald-300" />
            <span>رفتن به خرید و فروش</span>
          </button>
          <button
            type="button"
            onClick={() => onGoToBot(baseAsset, effectiveQuote)}
            className="btn-glass btn-glass-amber inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium whitespace-nowrap shrink-0"
          >
            <Bot className="w-4 h-4 text-amber-300" />
            <span>ساخت ربات</span>
          </button>
        </div>
      </div>

      {/* Interactive Smart Casual Q&A ("از من بپرس!") */}
      <div className="glass-panel rounded-xl p-5 space-y-4 border-cyan-500/30">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/90 pb-3.5">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/15 border border-cyan-400/40 flex items-center justify-center shrink-0">
              <Sparkles className="w-4 h-4 text-cyan-300" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">
                از من بپرس! (گپ خودمونی و هوشمند با AI NobiBot)
              </h3>
              <p className="text-xs text-slate-400">
                هر چی تو دلته به زبان خودمونی بپرس — از قیمت هر ارز تو نوبیتکس تا ربات سود یا حتی وقتی بازار قرمزه!
              </p>
            </div>
          </div>

          {chatHistory.length > 0 && (
            <button
              type="button"
              onClick={() => {
                setChatHistory([]);
                setAskError(null);
              }}
              className="btn-glass btn-glass-neutral inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[11px]"
            >
              <Trash2 className="w-3.5 h-3.5 text-slate-400" />
              <span>شروع گپ تازه</span>
            </button>
          )}
        </div>

        {/* Chat Thread */}
        <div className="bg-slate-950/75 border border-slate-800/90 rounded-xl p-3.5 space-y-3 max-h-80 overflow-y-auto">
          {chatHistory.length === 0 ? (
            <div className="py-3 px-2 text-xs text-slate-300 leading-relaxed space-y-2">
              <div className="font-semibold text-cyan-300">
                سلام رفیق! 👋 من همیار باحال تریدِ توم.
              </div>
              <p className="text-slate-400">
                الان چشمم به چارت <strong className="text-white">{market?.persianName || baseAsset}</strong> و کل بازار نوبیتکسه. هر سوالی داری راحت و خودمونی بپرس (مثلاً «داداش سولانا الان می‌ارزه بخرم؟» یا «با ۳ تومن چه رباتی بذارم؟»):
              </p>
            </div>
          ) : (
            chatHistory.map((turn, idx) => (
              <div
                key={`${turn.timestamp}-${idx}`}
                className={`flex ${turn.role === 'user' ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[88%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed whitespace-pre-wrap ${
                    turn.role === 'user'
                      ? 'bg-cyan-500/15 border border-cyan-400/35 text-cyan-50'
                      : 'bg-slate-900/95 border border-slate-700/80 text-slate-100'
                  }`}
                >
                  <div className="text-[10px] font-semibold mb-1 text-slate-400">
                    {turn.role === 'user' ? 'شما' : 'همیار AI NobiBot'}
                  </div>
                  <div>{turn.text}</div>
                </div>
              </div>
            ))
          )}

          {askingBuddy && (
            <div className="flex justify-end">
              <div className="rounded-2xl px-3.5 py-2.5 text-xs bg-slate-900/90 border border-cyan-500/30 text-cyan-200">
                یه ثانیه رفیق، دارم چارت و نبض نوبیتکس رو نگاه می‌کنم و قهوه می‌خورم ☕...
              </div>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Clickable Casual Quick Prompts */}
        <div className="flex flex-wrap items-center gap-2">
          {suggestedFollowUps.map((promptText, idx) => (
            <button
              key={`${promptText}-${idx}`}
              type="button"
              disabled={askingBuddy}
              onClick={() => void handleAskBuddy(promptText)}
              className="btn-glass btn-glass-neutral px-3 py-1.5 rounded-lg text-[11px] text-slate-200 hover:text-cyan-200 transition-colors"
            >
              {promptText}
            </button>
          ))}
        </div>

        {askError && (
          <div className="bg-rose-500/10 border border-rose-500/40 rounded-lg p-3 text-xs text-rose-300">
            {askError}
          </div>
        )}

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void handleAskBuddy();
          }}
          className="flex flex-col sm:flex-row gap-2.5"
        >
          <input
            type="text"
            value={askInput}
            onChange={(e) => setAskInput(e.target.value)}
            placeholder={`هر چی دلت می‌خواد به زبان خودمونی بپرس... (مثلاً: ${market?.persianName || baseAsset} الان خوبه؟)`}
            className="flex-1 bg-slate-950 border border-slate-700/90 rounded-xl px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
          />
          <button
            type="submit"
            disabled={askingBuddy || !askInput.trim()}
            className="btn-glass btn-glass-primary inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 disabled:opacity-50"
          >
            <Send className="w-3.5 h-3.5" />
            <span>{askingBuddy ? 'داره فکر می‌کنه...' : 'بپرس!'}</span>
          </button>
        </form>
      </div>

      {/* Friendly Conversational AI Analysis Box */}
      <div className="glass-panel rounded-xl p-5 space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800/90 pb-4">
          <div className="flex items-center gap-2.5">
            <BrainCircuit className="w-5 h-5 text-cyan-400" />
            <div>
              <h3 className="text-sm font-semibold text-white">
                تحلیل کامل و خودمونی هوش مصنوعی درباره {market?.persianName || baseAsset}
              </h3>
              <p className="text-xs text-slate-400">
                دکمه رو بزن تا کل داستان قیمت، نقاط ورود، تارگت و حد ضرر رو خودمونی و با یه کم طنز تحویلت بده
              </p>
            </div>
          </div>

          {aiAnalysis && (
            <span className="text-xs text-slate-400 font-mono-num" dir="ltr">
              {formatDateTimeShort(aiAnalysis.generatedAt)}
            </span>
          )}
        </div>

        <form onSubmit={handleRunAi} className="flex flex-col sm:flex-row gap-3">
          <input
            type="text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="سوال خاصت درباره این ارز رو بنویس (یا خالی بذار یه تحلیل کامل و باحال بگیر!)"
            className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3.5 py-2.5 text-xs text-white placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
          />
          <button
            type="submit"
            disabled={loadingAi}
            className="btn-glass btn-glass-ai inline-flex items-center justify-center gap-2 px-5 py-2.5 rounded-xl text-xs font-semibold whitespace-nowrap shrink-0"
          >
            <MessageCircle className="w-4 h-4" />
            <span>{loadingAi ? 'در حال برانداز کردن کندل‌ها...' : 'بگو الان بخریم یا بفروشیم؟'}</span>
          </button>
        </form>

        {aiError && (
          <div className="bg-rose-500/10 border border-rose-500/40 rounded-lg p-3.5 text-xs text-rose-300">
            {aiError}
          </div>
        )}

        {aiAnalysis && (
          <div className="space-y-4 pt-2">
            {/* Friendly Verdict Headline + Buy/Sell Advice */}
            <div className={`border rounded-lg p-4 space-y-3 ${stanceBg(aiAnalysis.stance)}`}>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className={`text-base font-bold ${badgeTone(aiAnalysis.stance)}`}>
                    {aiAnalysis.stanceLabelFa}
                  </div>
                  <div className="text-sm font-semibold text-white">
                    {aiAnalysis.verdictHeadline}
                  </div>
                </div>
                <span className="text-xs font-mono-num text-slate-200 bg-slate-950/75 px-3 py-1.5 rounded-md border border-slate-800/80">
                  اطمینان سیگنال: {aiAnalysis.confidencePercent}%
                </span>
              </div>

              <p className="text-xs text-slate-100 leading-relaxed">{aiAnalysis.friendlySummary}</p>

              <div className="bg-slate-950/80 border border-slate-800/90 rounded-lg p-3 text-xs space-y-1">
                <div className="font-semibold text-amber-300">خلاصه کلام: بخریم یا بفروشیم؟</div>
                <p className="text-slate-200 leading-relaxed">{aiAnalysis.shouldBuyOrSell}</p>
              </div>

              {aiAnalysis.customAnswer && (
                <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3 text-xs space-y-1">
                  <div className="font-semibold text-cyan-300">جواب سوال خودت:</div>
                  <p className="text-slate-100 leading-relaxed">{aiAnalysis.customAnswer}</p>
                </div>
              )}
            </div>

            {/* Dual-Currency Trade Plan + Friendly Technical Explain */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-4 space-y-3">
                <div className="font-semibold text-white pb-1.5 border-b border-slate-800">
                  قیمت‌های پیشنهادی (هم تومانی هم دلاری)
                </div>

                <div className="space-y-2.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400">محدوده خوب برای خرید:</span>
                    <div className="text-left font-mono-num" dir="ltr">
                      <div className="text-amber-300">{aiAnalysis.tradePlan.buyRangeToman}</div>
                      <div className="text-slate-400 text-[11px]">{aiAnalysis.tradePlan.buyRangeUsd}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400">هدف فروش اول (سود مطمئن‌تر):</span>
                    <div className="text-left font-mono-num" dir="ltr">
                      <div className="text-emerald-400">{aiAnalysis.tradePlan.target1Toman}</div>
                      <div className="text-slate-400 text-[11px]">{aiAnalysis.tradePlan.target1Usd}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400">هدف فروش دوم (اگر بازار قوی بود):</span>
                    <div className="text-left font-mono-num" dir="ltr">
                      <div className="text-emerald-400">{aiAnalysis.tradePlan.target2Toman}</div>
                      <div className="text-slate-400 text-[11px]">{aiAnalysis.tradePlan.target2Usd}</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-400">حد ضرر (اگر اومد پایین کجا بفروشیم):</span>
                    <div className="text-left font-mono-num" dir="ltr">
                      <div className="text-rose-400">{aiAnalysis.tradePlan.stopLossToman}</div>
                      <div className="text-slate-400 text-[11px]">{aiAnalysis.tradePlan.stopLossUsd}</div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800/90 rounded-lg p-4 space-y-3">
                <div className="font-semibold text-white pb-1.5 border-b border-slate-800">
                  نمودار به زبان ساده چی می‌گه؟
                </div>
                <p className="text-slate-200 leading-relaxed">{aiAnalysis.simpleTechnicalExplain}</p>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-800/70">
                  <div>
                    <div className="text-slate-400 mb-0.5">کف حمایتی مهم:</div>
                    <div className="text-emerald-300 font-mono-num" dir="ltr">
                      {aiAnalysis.keyLevels.support}
                    </div>
                  </div>
                  <div>
                    <div className="text-slate-400 mb-0.5">سقف مقاومتی پیش‌رو:</div>
                    <div className="text-rose-300 font-mono-num" dir="ltr">
                      {aiAnalysis.keyLevels.resistance}
                    </div>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-800/70 space-y-1">
                  <div className="text-amber-300 font-medium">نکات مهم برای حفظ سرمایه:</div>
                  {aiAnalysis.riskTips.map((tip, idx) => (
                    <div key={idx} className="text-slate-300">
                      • {tip}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Live Market News & Social Sentiment Analysis Widget */}
      <SentimentAnalysisWidget
        baseAsset={baseAsset}
        persianName={market?.persianName || baseAsset}
        symbol={preferredSymbol}
        demoMode={demoMode}
        market={market}
      />

      {/* Quantitative Multi-Timeframe Technical Indicators */}
      {loadingTech && snapshots.length === 0 ? (
        <div className="glass-panel rounded-xl p-10 text-center text-sm text-slate-400">
          در حال محاسبه اندیکاتورهای زنده نوبیتکس در ۴ بازه زمانی...
        </div>
      ) : techError ? (
        <div className="glass-panel rounded-xl p-6 text-xs text-slate-400">
          {techError}
        </div>
      ) : snap ? (
        <>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {snapshots.map((item, idx) => (
              <button
                key={item.timeframe}
                type="button"
                onClick={() => setActiveTfIdx(idx)}
                className={`btn-glass text-right p-4 rounded-xl ${
                  activeTfIdx === idx
                    ? 'btn-glass-primary'
                    : 'btn-glass-neutral'
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs font-mono-num text-slate-400">
                    بازه {item.timeframe}
                  </span>
                  <span className={`text-xs font-semibold ${badgeTone(item.signal.action)}`}>
                    {item.signal.labelFa}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-400 font-mono-num">
                  <span className="text-emerald-400">خرید: {item.signal.buyCount}</span>
                  <span>خنثی: {item.signal.neutralCount}</span>
                  <span className="text-rose-400">فروش: {item.signal.sellCount}</span>
                </div>
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            <div className="glass-panel rounded-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-800/90 bg-[#060A14]/75 text-sm font-semibold text-white">
                شاخص‌های قدرت بازار ({snap.timeframe})
              </div>
              <div className="divide-y divide-slate-800/70 text-xs">
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-slate-300">RSI (14)</span>
                  <div className="flex items-center gap-3 font-mono-num" dir="ltr">
                    <span className="text-white font-medium">{snap.rsi14.toFixed(2)}</span>
                    <span
                      className={
                        snap.rsi14 <= 35
                          ? 'text-emerald-400'
                          : snap.rsi14 >= 65
                            ? 'text-rose-400'
                            : 'text-slate-400'
                      }
                    >
                      {snap.rsi14 <= 35 ? 'اشباع فروش (مناسب خرید)' : snap.rsi14 >= 65 ? 'اشباع خرید (مراقب اصلاح)' : 'متعادل'}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-slate-300">MACD</span>
                  <span
                    className={
                      snap.macd.macdLine > snap.macd.signalLine ? 'text-emerald-400' : 'text-rose-400'
                    }
                  >
                    {snap.macd.macdLine > snap.macd.signalLine ? 'مومنتوم صعودی' : 'مومنتوم نزولی'}
                  </span>
                </div>
                <div className="flex items-center justify-between px-4 py-3">
                  <span className="text-slate-300">حجم نسبت به میانگین</span>
                  <span className="font-mono-num text-slate-200" dir="ltr">
                    {snap.volumeRatio.toFixed(2)}x
                  </span>
                </div>
              </div>
            </div>

            <div className="glass-panel rounded-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-800/90 bg-[#060A14]/75 text-sm font-semibold text-white">
                میانگین‌های متحرک ({preferredSymbol.endsWith('USDT') ? 'USDT' : 'تومان'})
              </div>
              <div className="divide-y divide-slate-800/70 text-xs">
                {[
                  { label: 'EMA 9', val: snap.ema9 },
                  { label: 'EMA 20', val: snap.ema20 },
                  { label: 'EMA 50', val: snap.ema50 },
                  { label: 'EMA 200', val: snap.ema200 },
                ].map((row) => {
                  const diffPct = row.val > 0 ? ((snap.price - row.val) / row.val) * 100 : 0;
                  return (
                    <div key={row.label} className="flex items-center justify-between px-4 py-3">
                      <span className="text-slate-300 font-mono-num">{row.label}</span>
                      <div className="flex items-center gap-3 font-mono-num" dir="ltr">
                        <span className="text-white">
                          {preferredSymbol.endsWith('USDT')
                            ? `$${formatPrice(row.val)}`
                            : `${formatToman(row.val)} ت`}
                        </span>
                        <span className={diffPct >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                          {formatPercent(diffPct)}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="glass-panel rounded-xl overflow-hidden">
              <div className="px-4 py-3 border-b border-slate-800/90 bg-[#060A14]/75 text-sm font-semibold text-white">
                جمع‌بندی خودکار اندیکاتورها
              </div>
              <ul className="p-4 space-y-2 text-xs text-slate-300">
                {snap.signal.reasons.map((r, i) => (
                  <li key={i} className="flex items-start gap-2">
                    <span className="text-cyan-400 font-mono-num">0{i + 1}.</span>
                    <span>{r}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </>
      ) : null}
    </div>
  );
};
