import React, { useEffect, useMemo, useState } from 'react';
import {
  ArrowDownRight,
  ArrowUpRight,
  Bell,
  BellRing,
  CheckCircle2,
  Clock,
  RotateCcw,
  Trash2,
} from 'lucide-react';
import type {
  PriceAlert,
  PriceAlertCondition,
  QuoteCurrency,
  UnifiedMarketTicker,
} from '../types/trading';
import { formatDateTimeShort, formatQuotePrice } from '../utils/format';
import { CoinSearchSelect } from './CoinSearchSelect';
import { NumericInput } from './NumericInput';

interface PriceAlertsWidgetProps {
  alerts: PriceAlert[];
  markets: UnifiedMarketTicker[];
  defaultBaseAsset: string;
  defaultQuoteCurrency: QuoteCurrency;
  compact?: boolean;
  telegramConnected?: boolean;
  onOpenTelegramSettings?: () => void;
  onQuoteCurrencyChange?: (qc: QuoteCurrency) => void;
  onCreateAlert: (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    condition: PriceAlertCondition;
    targetPrice: number;
    sendTelegram?: boolean;
    note?: string;
  }) => Promise<void>;
  onRearmAlert: (alertId: string) => Promise<void>;
  onDeleteAlert: (alertId: string) => Promise<void>;
  onSelectForTrade?: (baseAsset: string, quoteCurrency?: QuoteCurrency) => void;
}

export const PriceAlertsWidget: React.FC<PriceAlertsWidgetProps> = ({
  alerts,
  markets,
  defaultBaseAsset,
  defaultQuoteCurrency,
  compact = false,
  telegramConnected = false,
  onOpenTelegramSettings,
  onQuoteCurrencyChange,
  onCreateAlert,
  onRearmAlert,
  onDeleteAlert,
  onSelectForTrade,
}) => {
  const [baseAsset, setBaseAsset] = useState(defaultBaseAsset);
  const [quoteCurrency, setQuoteCurrency] = useState<QuoteCurrency>(defaultQuoteCurrency);
  const [condition, setCondition] = useState<PriceAlertCondition>('ABOVE');
  const [targetPrice, setTargetPrice] = useState('');
  const [note, setNote] = useState('');
  const [sendTelegram, setSendTelegram] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [notifPerm, setNotifPerm] = useState<NotificationPermission>(
    typeof window !== 'undefined' && 'Notification' in window
      ? Notification.permission
      : 'denied'
  );

  useEffect(() => {
    setBaseAsset(defaultBaseAsset);
    setQuoteCurrency(defaultQuoteCurrency);
    setTargetPrice('');
  }, [defaultBaseAsset, defaultQuoteCurrency]);

  const selectedMarket = useMemo(
    () => markets.find((m) => m.baseAsset === baseAsset) || null,
    [markets, baseAsset]
  );

  const livePrice = selectedMarket
    ? quoteCurrency === 'IRT'
      ? selectedMarket.priceToman
      : selectedMarket.priceUsdt
    : 0;

  const applyOffsetPreset = (pctOffset: number) => {
    if (livePrice <= 0) return;
    const raw = livePrice * (1 + pctOffset / 100);
    const formatted =
      quoteCurrency === 'IRT'
        ? String(Math.round(raw))
        : String(Number(raw.toPrecision(6)));
    setTargetPrice(formatted);
    setCondition(pctOffset >= 0 ? 'ABOVE' : 'BELOW');
  };

  const handleRequestBrowserNotifications = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) return;
    try {
      const perm = await Notification.requestPermission();
      setNotifPerm(perm);
    } catch {
      // Ignore permission rejection
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    const parsedPrice = Number(targetPrice);
    if (!Number.isFinite(parsedPrice) || parsedPrice <= 0) {
      setFeedback({ type: 'err', text: 'لطفاً قیمت هدف معتبر وارد کنید.' });
      return;
    }

    setSubmitting(true);
    try {
      await onCreateAlert({
        baseAsset,
        quoteCurrency,
        condition,
        targetPrice: parsedPrice,
        sendTelegram,
        note: note.trim() || undefined,
      });
      setTargetPrice('');
      setNote('');
      setFeedback({
        type: 'ok',
        text: `هشدار قیمت برای ${selectedMarket?.persianName || baseAsset} ثبت شد.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'ثبت هشدار قیمت ناموفق بود.',
      });
    } finally {
      setSubmitting(false);
    }
  };

  const activeCount = alerts.filter((a) => a.status === 'ACTIVE').length;
  const triggeredCount = alerts.filter((a) => a.status === 'TRIGGERED').length;

  return (
    <section
      className={
        compact
          ? 'p-4 space-y-4'
          : 'bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden'
      }
    >
      {!compact && (
        <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-3.5 border-b border-slate-800 bg-[#060A14]">
          <div className="flex items-center gap-2.5">
            <BellRing className="w-4 h-4 text-amber-400" />
            <div>
              <h3 className="text-sm font-semibold text-white">
                هشدارهای قیمت لحظه‌ای (Price Alerts)
              </h3>
              <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                <span>{activeCount} هشدار فعال در انتظار</span>
                <span aria-hidden="true">·</span>
                <span>{triggeredCount} هشدار رسیده‌شده</span>
              </div>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
              <button
                type="button"
                disabled={selectedMarket ? !selectedMarket.hasIrtMarket : false}
                onClick={() => {
                  setQuoteCurrency('IRT');
                  setTargetPrice('');
                  onQuoteCurrencyChange?.('IRT');
                }}
                className={`px-2.5 py-1 rounded font-medium transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 ${
                  quoteCurrency === 'IRT'
                    ? 'bg-amber-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                بازار تومانی (IRT)
              </button>
              <button
                type="button"
                disabled={selectedMarket ? !selectedMarket.hasUsdtMarket : false}
                onClick={() => {
                  setQuoteCurrency('USDT');
                  setTargetPrice('');
                  onQuoteCurrencyChange?.('USDT');
                }}
                className={`px-2.5 py-1 rounded font-medium transition-colors whitespace-nowrap shrink-0 disabled:opacity-40 ${
                  quoteCurrency === 'USDT'
                    ? 'bg-cyan-500 text-slate-950 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                بازار تتری (USDT)
              </button>
            </div>

            {typeof window !== 'undefined' &&
              'Notification' in window &&
              notifPerm !== 'granted' &&
              notifPerm !== 'denied' && (
                <button
                  type="button"
                  onClick={() => void handleRequestBrowserNotifications()}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-900 border border-slate-700 hover:border-cyan-500/50 text-slate-100 transition-colors whitespace-nowrap shrink-0"
                >
                  <Bell className="w-3.5 h-3.5 text-cyan-400" />
                  <span>فعال‌سازی اعلان دسکتاپ مرورگر</span>
                </button>
              )}
          </div>
        </div>
      )}

      <div className={compact ? 'space-y-4' : 'p-5 space-y-5'}>
        {/* Creation Form */}
        <form
          onSubmit={handleSubmit}
          className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-3"
        >
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            <div>
              <label className="block text-[11px] text-slate-400 mb-1">ارز دیجیتال</label>
              <CoinSearchSelect
                markets={markets}
                value={baseAsset}
                quoteCurrency={quoteCurrency}
                size="sm"
                onChange={(next) => {
                  setBaseAsset(next);
                  const m = markets.find((x) => x.baseAsset === next);
                  if (m && quoteCurrency === 'IRT' && !m.hasIrtMarket) setQuoteCurrency('USDT');
                  if (m && quoteCurrency === 'USDT' && !m.hasUsdtMarket) setQuoteCurrency('IRT');
                  setTargetPrice('');
                }}
                ariaLabel="جستجو و انتخاب ارز هشدار قیمت"
              />
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">بازار قیمت</label>
              <div className="grid grid-cols-2 gap-1 bg-[#0A101D] border border-slate-700 rounded-md p-1">
                <button
                  type="button"
                  disabled={selectedMarket ? !selectedMarket.hasIrtMarket : false}
                  onClick={() => {
                    setQuoteCurrency('IRT');
                    setTargetPrice('');
                    onQuoteCurrencyChange?.('IRT');
                  }}
                  className={`py-1.5 rounded text-xs font-medium transition-colors whitespace-nowrap disabled:opacity-40 ${
                    quoteCurrency === 'IRT'
                      ? 'bg-amber-500 text-slate-950 font-semibold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  تومانی
                </button>
                <button
                  type="button"
                  disabled={selectedMarket ? !selectedMarket.hasUsdtMarket : false}
                  onClick={() => {
                    setQuoteCurrency('USDT');
                    setTargetPrice('');
                    onQuoteCurrencyChange?.('USDT');
                  }}
                  className={`py-1.5 rounded text-xs font-medium transition-colors whitespace-nowrap disabled:opacity-40 ${
                    quoteCurrency === 'USDT'
                      ? 'bg-cyan-500 text-slate-950 font-semibold'
                      : 'text-slate-300 hover:text-white'
                  }`}
                >
                  تتری
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[11px] text-slate-400 mb-1">شرط فعال‌سازی</label>
              <select
                value={condition}
                onChange={(e) => setCondition(e.target.value as PriceAlertCondition)}
                className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-2.5 py-2 text-xs text-white focus:outline-none focus:border-cyan-400"
              >
                <option value="ABOVE">بالاتر یا مساوی (≥)</option>
                <option value="BELOW">پایین‌تر یا مساوی (≤)</option>
              </select>
            </div>

            <div>
              <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1">
                <span>قیمت هدف ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})</span>
                {livePrice > 0 && (
                  <button
                    type="button"
                    onClick={() => applyOffsetPreset(0)}
                    className="text-amber-300 hover:underline font-mono-num"
                    dir="ltr"
                  >
                    فعلی: {formatQuotePrice(livePrice, quoteCurrency)}
                  </button>
                )}
              </div>
              <NumericInput
                value={targetPrice}
                onValueChange={setTargetPrice}
                placeholder={quoteCurrency === 'IRT' ? 'مثلاً 18000000000' : 'مثلاً 70000'}
                className="w-full bg-[#0A101D] border border-slate-700 rounded-md px-2.5 py-2 text-xs text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
              />
            </div>

            <div className="flex flex-col justify-end">
              <button
                type="submit"
                disabled={submitting}
                className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-md text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                <Bell className="w-3.5 h-3.5" />
                <span>{submitting ? 'در حال ثبت...' : 'ثبت هشدار قیمت'}</span>
              </button>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
            <div className="flex flex-wrap items-center gap-1.5 text-[11px]">
              <span className="text-slate-500">هدف سریع:</span>
              {[
                { label: '-5%', val: -5 },
                { label: '-2%', val: -2 },
                { label: '+2%', val: 2 },
                { label: '+5%', val: 5 },
              ].map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => applyOffsetPreset(p.val)}
                  className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 hover:border-cyan-500/50 text-slate-200 font-mono-num transition-colors"
                  dir="ltr"
                >
                  {p.label}
                </button>
              ))}
            </div>

            <div className="flex flex-wrap items-center gap-3 flex-1 justify-end">
              <label className="inline-flex items-center gap-1.5 text-[11px] text-slate-200 cursor-pointer whitespace-nowrap">
                <input
                  type="checkbox"
                  checked={sendTelegram}
                  onChange={(e) => setSendTelegram(e.target.checked)}
                  className="accent-cyan-500"
                />
                <span>ارسال به تلگرام</span>
              </label>

              {!telegramConnected && onOpenTelegramSettings && (
                <button
                  type="button"
                  onClick={onOpenTelegramSettings}
                  className="text-[11px] text-cyan-400 hover:text-cyan-300 underline whitespace-nowrap shrink-0"
                >
                  تنظیم بات تلگرام
                </button>
              )}

              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="یادداشت کوتاه اختیاری (مثلاً: زمان مناسب خرید پله‌ای)"
                className="flex-1 min-w-[200px] max-w-md bg-[#0A101D] border border-slate-800 rounded-md px-2.5 py-1 text-[11px] text-slate-200 placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
              />
            </div>
          </div>

          {feedback && (
            <div
              className={`text-xs px-3 py-2 rounded border ${
                feedback.type === 'ok'
                  ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                  : 'bg-rose-500/10 border-rose-500/30 text-rose-300'
              }`}
            >
              {feedback.text}
            </div>
          )}
        </form>

        {/* Alerts List */}
        {alerts.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-400 border border-dashed border-slate-800 rounded-lg">
            هنوز هشداری تنظیم نکرده‌اید. قیمت هدف مورد نظرتان را در کادر بالا ثبت کنید تا به محض رسیدن بازار، به شما اطلاع داده شود.
          </div>
        ) : (
          <div className="overflow-x-auto border border-slate-800 rounded-lg">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-400 bg-[#060A14]">
                  <th className="py-2.5 px-4 font-medium">ارز / نماد</th>
                  <th className="py-2.5 px-4 font-medium">شرط</th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    قیمت هدف
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    قیمت فعلی / فاصله
                  </th>
                  <th className="py-2.5 px-4 font-medium">وضعیت</th>
                  <th className="py-2.5 px-4 font-medium text-left">عملیات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 text-xs">
                {alerts.map((alert) => {
                  const m = markets.find((x) => x.baseAsset === alert.baseAsset);
                  const curPrice = m
                    ? alert.quoteCurrency === 'IRT'
                      ? m.priceToman
                      : m.priceUsdt
                    : 0;
                  const diffPct =
                    curPrice > 0 ? ((alert.targetPrice - curPrice) / curPrice) * 100 : 0;
                  const isTriggered = alert.status === 'TRIGGERED';

                  return (
                    <tr
                      key={alert.id}
                      className={
                        isTriggered
                          ? 'bg-emerald-500/5 hover:bg-emerald-500/10 transition-colors'
                          : 'hover:bg-slate-900/60 transition-colors'
                      }
                    >
                      <td className="py-2.5 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-mono-num font-semibold text-white">
                            {alert.symbol}
                          </span>
                          <span className="text-slate-400 text-[11px]">{alert.persianName}</span>
                          {alert.sendTelegram !== false && telegramConnected && (
                            <>
                              <span aria-hidden="true" className="text-slate-700">
                                ·
                              </span>
                              <span className="text-cyan-400 text-[11px]">تلگرام</span>
                            </>
                          )}
                        </div>
                        {alert.note && (
                          <div className="text-[11px] text-slate-500 mt-0.5">{alert.note}</div>
                        )}
                      </td>

                      <td className="py-2.5 px-4">
                        <span
                          className={`inline-flex items-center gap-1 font-medium ${
                            alert.condition === 'ABOVE' ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {alert.condition === 'ABOVE' ? (
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          ) : (
                            <ArrowDownRight className="w-3.5 h-3.5" />
                          )}
                          <span>
                            {alert.condition === 'ABOVE' ? 'عبور به بالا' : 'رسیدن به پایین'}
                          </span>
                        </span>
                      </td>

                      <td className="py-2.5 px-4 text-left font-mono-num font-semibold text-amber-300" dir="ltr">
                        {formatQuotePrice(alert.targetPrice, alert.quoteCurrency)}
                      </td>

                      <td className="py-2.5 px-4 text-left font-mono-num" dir="ltr">
                        {curPrice > 0 ? (
                          <div>
                            <div className="text-slate-200">
                              {formatQuotePrice(curPrice, alert.quoteCurrency)}
                            </div>
                            <div
                              className={`text-[11px] ${
                                Math.abs(diffPct) < 1 ? 'text-amber-300' : 'text-slate-400'
                              }`}
                            >
                              {diffPct >= 0 ? '+' : ''}
                              {diffPct.toFixed(2)}% فاصله
                            </div>
                          </div>
                        ) : (
                          <span className="text-slate-500">—</span>
                        )}
                      </td>

                      <td className="py-2.5 px-4">
                        {isTriggered ? (
                          <div className="space-y-0.5">
                            <span className="inline-flex items-center gap-1 text-emerald-400 font-semibold">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>رسید به هدف</span>
                            </span>
                            {alert.triggeredAt && (
                              <div className="text-[11px] text-slate-400 font-mono-num" dir="ltr">
                                {formatDateTimeShort(alert.triggeredAt)}
                              </div>
                            )}
                          </div>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-cyan-300">
                            <Clock className="w-3.5 h-3.5" />
                            <span>در انتظار</span>
                          </span>
                        )}
                      </td>

                      <td className="py-2.5 px-4 text-left">
                        <div className="flex items-center justify-end gap-1.5">
                          {onSelectForTrade && (
                            <button
                              type="button"
                              onClick={() =>
                                onSelectForTrade(alert.baseAsset, alert.quoteCurrency)
                              }
                              className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] whitespace-nowrap shrink-0"
                            >
                              معامله
                            </button>
                          )}
                          {isTriggered && (
                            <button
                              type="button"
                              onClick={() => void onRearmAlert(alert.id)}
                              className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-amber-300"
                              title="فعال‌سازی مجدد هشدار"
                            >
                              <RotateCcw className="w-3.5 h-3.5" />
                            </button>
                          )}
                          <button
                            type="button"
                            onClick={() => void onDeleteAlert(alert.id)}
                            className="p-1.5 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-300"
                            title="حذف هشدار"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </section>
  );
};
