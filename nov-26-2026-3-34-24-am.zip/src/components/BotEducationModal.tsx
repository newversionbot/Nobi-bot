import React from 'react';
import {
  AlertTriangle,
  BookOpen,
  CheckCircle2,
  HelpCircle,
  Info,
  ShieldAlert,
  X,
} from 'lucide-react';
import type { BotType } from '../types/trading';

export type GuideBotTopic = BotType | 'AI_MANAGER';

interface BotGuideContent {
  title: string;
  subtitle: string;
  accentClass: string;
  whatItDoes: string;
  bestWhen: string;
  avoidWhen: string;
  steps: string[];
  glossary: Array<{ term: string; meaning: string }>;
  example: string;
  risks: string[];
  howToStop: string;
}

const BOT_GUIDES: Record<GuideBotTopic, BotGuideContent> = {
  AI_CYCLE_PRO: {
    title: 'ربات چرخه هوشمند (AI Cycle Pro)',
    subtitle: 'مخصوص مبتدی‌ها: فقط ارز، مبلغ سرمایه و حالت اجرا را انتخاب کن — تحلیل تا فروش و چرخه بعدی با هوش مصنوعی!',
    accentClass: 'text-cyan-300 border-cyan-500/30 bg-cyan-500/10',
    whatItDoes:
      'این ربات تمام مراحل معامله را خودکار انجام می‌دهد: روند بازار، حجم، نوسان و عمق دفتر سفارش نوبیتکس را با هوش مصنوعی Gemini بررسی می‌کند. فقط وقتی شرایط ورود مناسب باشد می‌خرد، هدف فروش را با کارمزد و لغزش واقعی حساب می‌کند، می‌فروشد و برای چرخه بعدی دوباره بازار را تحلیل می‌کند. اگر بازار مناسب نباشد، پول را نقد نگه می‌دارد.',
    bestWhen: 'وقتی می‌خواهی بدون درگیر شدن با اندیکاتورها و تحلیل دستی دفتر سفارش، چرخه‌های خرید و فروش هوشمند و کنترل‌شده داشته باشی.',
    avoidWhen: 'اگر می‌خواهی خودت قیمت خرید و فروش دقیق عددی بدهی (برای آن حالت، ربات قیمت ثابت بهتر است).',
    steps: [
      'ارز دیجیتال و بازار (تومان یا تتر) را انتخاب کن.',
      'سقف سرمایه (کل یا بخشی از سرمایه) را وارد کن.',
      'حالت اجرا (تمرینی یا واقعی · خودکار یا نیازمند تأیید دستی) را مشخص کرده و دکمه «شروع» را بزن.',
    ],
    glossary: [
      { term: 'نگهداری نقدی (Waiting Cash)', meaning: 'وقتی اسپرد، لغزش یا روند بازار مناسب نباشد، ربات نمی‌خرد تا سرمایه‌ات حفظ شود.' },
      { term: 'هدف سود خالص واقعی', meaning: 'قیمتی که پس از کسر کارمزد خرید و فروش و لغزش دفتر سفارش، سود خالص هدف را برآورده کند.' },
      { term: 'سقف زیان روزانه', meaning: 'اگر زیان بسته‌شده امروز به سقف برسد، ربات تا فردا متوقف می‌شود.' },
    ],
    example:
      'مثلاً ۱۰ میلیون تومان روی بیت‌کوین فعال می‌کنی. اگر دفتر سفارش و روند مثبت باشد خرید می‌کند، پس از محاسبه کارمزد و لغزش در هدف +۱.۸٪ می‌فروشد، سود خالص را ثبت می‌کند و دوباره بازار را برای چرخه بعدی می‌سنجد.',
    risks: [
      'در بازارهای بسیار نزولی ممکن است تا رسیدن به سیگنال مناسب مدت طولانی در حالت نقد بماند یا حد ضرر فعال شود.',
      'هوش مصنوعی تصمیم‌گیری هوشمند انجام می‌دهد اما هیچ سودی تضمین‌شده نیست.',
    ],
    howToStop:
      'با زدن دکمه «توقف»، چرخه متوقف می‌شود و خرید جدید ثبت نمی‌گردد. اگر معامله باز دارید می‌توانید آن را نگه دارید یا با «فروش دستی» همان لحظه ببندید.',
  },
  PROFIT: {
    title: 'ربات سود هدف‌محور (Profit Bot)',
    subtitle: 'خرید و فروش خودکار فقط وقتی که سود خالص بعد از کارمزد به مبلغ دلخواهت برسه',
    accentClass: 'text-emerald-300 border-emerald-500/30 bg-emerald-500/10',
    whatItDoes:
      'این ربات با پول تومانی یا تتری (یا حتی با موجودی ارزی که از قبل توی نوبیتکس داری) وارد معامله می‌شه و دقیقاً کارمزد خرید، کارمزد فروش و عمق دفتر سفارش رو حساب می‌کنه تا فقط زمانی بفروشه که سود خالص تعیین‌شده‌ات واقعاً به دست بیاد.',
    bestWhen: 'وقتی می‌خوای از نوسان‌های کوتاه‌مدت بازار یه سود مشخص (مثلاً ۲۰۰ هزار تومان یا ۵ تتر) بگیری و نمی‌خوای درگیر محاسبه کارمزد و قیمت دقیق فروش بشی.',
    avoidWhen: 'زمانی که بازار تو سقوط شدید و بی‌توقف هست؛ در اون حالت حتماً «حد ضرر» رو فعال بذار.',
    steps: [
      'ارز دیجیتال و بازار (تومان یا تتر) رو انتخاب کن.',
      'مبلغ ورود (یا درصد استفاده از ارز فعلی خودت) و سود خالص هدف رو وارد کن.',
      'حالت اجرای «خودکار» یا «با تأیید دستی» و همچنین حساب تمرینی یا واقعی رو مشخص کن.',
      'توی تب «تنظیمات پیشرفته» می‌تونی حد ضرر، حداکثر اسپرد و تکرار خودکار چرخه رو تنظیم کنی.',
    ],
    glossary: [
      { term: 'سود خالص هدف', meaning: 'سودی که بعد از کسر کامل کارمزد خرید و فروش نوبیتکس خالص برات می‌مونه.' },
      { term: 'لغزش قیمت (Slippage)', meaning: 'تفاوت جزئی بین قیمت لحظه‌ای تابلو و میانگین قیمتی که کل سفارش در دفتر سفارش پر می‌شه.' },
      { term: 'اسپرد (Spread)', meaning: 'فاصله بین بهترین قیمت خرید و بهترین قیمت فروش در بازار.' },
    ],
    example:
      'مثلاً با ۱۰ میلیون تومان بیت‌کوین می‌خره و هدف سود خالص رو ۱۵۰ هزار تومان می‌ذاری؛ ربات حدود ۵۰ هزار تومان کارمزد خرید و فروش رو هم روی قیمت فروش هدف اضافه می‌کنه و وقتی خریدار واقعی به این قیمت رسید، می‌فروشه.',
    risks: [
      'اگر قیمت بعد از خرید بریزه و حد ضرر نذاشته باشی، ربات منتظر برگشت قیمت می‌مونه.',
      'سود در هیچ بازاری تضمین‌شده نیست و تغییرات سریع بازار می‌تونه زمان انتظار رو بیشتر کنه.',
    ],
    howToStop:
      'با زدن دکمه «توقف»، بررسی‌های خودکار قطع می‌شه. اگر معامله باز داشته باشی می‌تونی انتخاب کنی که ارز رو نگه داری یا همون لحظه با قیمت بازار بفروشی.',
  },
  FIXED_PRICE: {
    title: 'ربات قیمت ثابت (Fixed Price Bot)',
    subtitle: 'خرید در قیمت دقیق هدف شما و فروش در قیمت دقیق بالایی',
    accentClass: 'text-blue-300 border-blue-500/30 bg-blue-500/10',
    whatItDoes:
      'خیلی ساده و شفاف! دو تا قیمت مشخص بهش می‌دی: «هر وقت قیمت به این عدد رسید بخر، و هر وقت به اون عدد بالا رسید بفروش». می‌تونه یه بار انجام بده یا چرخه رو تکرار کنه.',
    bestWhen: 'وقتی خودت حمایت و مقاومت یا محدوده خرید و فروش یه ارز رو از قبل می‌دونی و می‌خوای سر ساعت مشخص برات اجرا بشه.',
    avoidWhen: 'وقتی بازار روند صعودی خیلی پرشتاب داره و قیمت اصلاً به هدف خرید پایین برنمی‌گرده.',
    steps: [
      'ارز و مبلغ هر معامله رو انتخاب کن.',
      'قیمت خرید هدف و قیمت فروش هدف رو وارد کن.',
      'انتخاب کن بعد از فروش، دوباره منتظر خرید بعدی بمونه یا فقط یک بار معامله کنه.',
    ],
    glossary: [
      { term: 'تکرار چرخه', meaning: 'اگر روشن باشه، بعد از هر فروش موفق دوباره منتظر می‌مونه تا قیمت به هدف خرید برسه و تکرار کنه.' },
      { term: 'ورود با موجودی فعلی', meaning: 'به جای خرید جدید با تومان، از ارزی که الان توی کیف پولت داری برای فروش در قیمت هدف استفاده می‌کنه.' },
    ],
    example:
      'مثلاً تنظیم می‌کنی تون‌کوین رو در ۵۱۰ هزار تومان بخره و در ۵۴۵ هزار تومان بفروشه. هر بار که بازار بین این دو عدد رفت‌وبرگشت کنه، ربات برات معامله رو انجام می‌ده.',
    risks: [
      'اگر قیمت پس از خرید به زیر هدف خرید بره و برنگرده، دارایی باز می‌مونه تا زمانی که به هدف فروش برسه یا دستی ببندیش.',
    ],
    howToStop:
      'با زدن «توقف»، ربات دیگه سفارش جدید ثبت نمی‌کنه و سفارش‌های باز هم طبق انتخاب شما حفظ یا لغو می‌شن.',
  },
  GRID: {
    title: 'ربات گرید پله‌ای (Grid Bot)',
    subtitle: 'تقسیم سرمایه روی چندین پله قیمتی برای سودگرفتن از نوسان‌های رِنج',
    accentClass: 'text-amber-300 border-amber-500/30 bg-amber-500/10',
    whatItDoes:
      'یه سقف و یه کف قیمتی براش مشخص می‌کنی و می‌گی این وسط رو به مثلاً ۸ پله تقسیم کن. هر وقت قیمت میاد روی پله پایین‌تر، یه بخش می‌خره و به محض اینکه یک پله برگرده بالا، همون تیکه رو با سود مشخص می‌فروشه.',
    bestWhen: 'در بازارهای خنثی و رِنج که قیمت بین یک کف و سقف بالا و پایین می‌شه.',
    avoidWhen: 'در سقوط‌های آزاد یا صعودهای یک‌طرفه که قیمت سریع از محدوده خارج می‌شه.',
    steps: [
      'حد پایین و حد بالای محدوده قیمتی رو مشخص کن (به صورت عددی یا خودکار از کف و سقف اخیر).',
      'تعداد پله‌ها و کل سرمایه اختصاص‌یافته به گرید رو وارد کن.',
      'توصیه می‌شه «توقف خودکار در خروج از محدوده» روشن باشه تا اگر قیمت محدوده رو شکست، سرمایه در خطر نیفته.',
    ],
    glossary: [
      { term: 'گرید حسابی (Arithmetic)', meaning: 'فاصله تومانی/دلاری تمام پله‌ها یکسانه (مثلاً هر پله ۲ میلیون تومان فاصله).' },
      { term: 'گرید هندسی (Geometric)', meaning: 'فاصله درصدی پله‌ها یکسانه (مثلاً هر پله ۱.۵٪ فاصله) که برای بازه‌های بزرگ عالیه.' },
      { term: 'سود هر چرخه', meaning: 'سود خالصی که از خرید یک پله و فروش یک پله بالاتر به دست میاد بعد از کسر کارمزد.' },
    ],
    example:
      'مثلاً محدوده تون‌کوین رو ۵۰۰ تا ۵۶۰ هزار تومان با ۷ پله (فاصله ۱۰ هزار تومان) و سرمایه ۱۲ میلیون تومان می‌ذاری. هر بار قیمت از ۵۱۰ به ۵۲۰ بره و برگرده، یک چرخه سود خالص ثبت می‌شه.',
    risks: [
      'اگر قیمت به پایین محدوده سقوط کنه، پله‌های خریداری‌شده در ضرر موقت باقی می‌مونن تا قیمت برگرده.',
      'اگر تعداد پله‌ها خیلی زیاد و فاصله درصدی از ۰.۵٪ کمتر باشه، کارمزد معاملات سود هر چرخه رو می‌خوره.',
    ],
    howToStop:
      'هنگام توقف می‌تونی ربات رو متوقف کنی و ارزهای خریداری‌شده رو برای نگهداری آزاد بذاری یا در داشبورد دستی ببندی.',
  },
  DCA: {
    title: 'ربات خرید پله‌ای میانگین‌کم‌کن (DCA Bot)',
    subtitle: 'خرید مرحله‌ای در افت‌ها برای پایین آوردن میانگین خرید و فروش هوشمند',
    accentClass: 'text-sky-300 border-sky-500/30 bg-sky-500/10',
    whatItDoes:
      'به جای اینکه کل پولت رو یه جا خرید کنی، سرمایه رو به چند مرحله (مثلاً ۵ مرحله) تقسیم می‌کنه. هر بار قیمت به اندازه مشخصی اصلاح کنه (یا در بازه زمانی/سیگنال اندیکاتور)، یه پله می‌خره تا میانگین قیمت خریدت بیاد پایین و تو یک برگشت کوچیک کل پوزیشن به سود برسه.',
    bestWhen: 'در بازارهای اصلاحی یا برای ورود امن میان‌مدت به ارزهای معتبر بدون استرس پیدا کردن کف دقیق.',
    avoidWhen: 'وقتی سرمایه کافی برای پله‌های بعدی نگه نداشتی یا کل بودجه‌ات از اول قفل شده.',
    steps: [
      'کل سرمایه اختصاص‌یافته و تعداد مراحل خرید (مثلاً ۴ تا ۶ مرحله) رو تعیین کن.',
      'روش ورود پله‌ها رو انتخاب کن: در افت درصدی/قیمتی، زمان‌بندی منظم، یا سیگنال اندیکاتور.',
      'اهداف فروش پله‌ای، حد سود متحرک و حد ضرر کل رو تنظیم کن.',
    ],
    glossary: [
      { term: 'میانگین قیمت خرید', meaning: 'مجموع پولی که تو همه پله‌ها دادی تقسیم بر کل ارزی که خریدی.' },
      { term: 'فروش پله‌ای', meaning: 'به جای فروش یک‌جا، مثلاً ۵۰٪ رو در سود +۳.۵٪ و ۵۰٪ رو در +۷٪ می‌فروشه.' },
      { term: 'نگهداری بخش روند (Runner)', meaning: 'درصدی از ارز رو بعد از سود هم نگه می‌داره و حد ضررش رو میاره روی نقطه سربه‌سر.' },
    ],
    example:
      'با ۲۵ میلیون تومان اتریوم در ۵ مرحله ۵ میلیونی. اگر قیمت ۱۰٪ بریزه و ۵ پله خرید بشه، میانگین خریدت خیلی پایین‌تر میاد و فقط با ۴٪ رشد قیمت از کف، کل معامله سودده می‌شه.',
    risks: [
      'در ریزش‌های بسیار عمیق اگر حد ضرر فعال نباشه، کل سرمایه درگیر می‌شه. همیشه دکمه «توقف خرید جدید» رو می‌تونی بزنی تا فقط دارایی فعلی مدیریت بشه.',
    ],
    howToStop:
      'می‌تونی فقط «خرید جدید را متوقف کن» رو بزنی تا پله جدیدی نخره ولی دارایی خریده‌شده رو تا هدف سود مدیریت کنه، یا ربات رو کلاً متوقف کنی.',
  },
  STRATEGY: {
    title: 'ربات استراتژی هوشمند (Strategy Bot)',
    subtitle: 'ترکیب اندیکاتورها، شکست مقاومت، تایید حجم و مدیریت حرفه‌ای خروج',
    accentClass: 'text-violet-300 border-violet-500/30 bg-violet-500/10',
    whatItDoes:
      'کندل‌های زنده نوبیتکس رو لحظه‌به‌لحظه بررسی می‌کنه و فقط وقتی چند شرط مثل RSI، کراس EMA، MACD، یا شکست مقاومت با حجم بالا و فیلتر نوسان شدید تایید شد وارد معامله می‌شه.',
    bestWhen: 'برای نوسان‌گیری روزانه (Day Trading) یا شکار موج‌های میان‌مدت با تحلیل واقعی بازار.',
    avoidWhen: 'اگر تعداد زیادی شرط خیلی سخت‌گیرانه با عملگر «و (AND)» بذاری، ممکنه اصلاً معامله‌ای باز نشه؛ بهتره اول حتماً بک‌تست بگیری.',
    steps: [
      'حالت معاملات «روزانه» یا «میان‌مدت» (یا تنظیم دلخواه) رو انتخاب کن.',
      'شرایط ورود و خروج، فیلتر حجم و فیلتر نوسان شدید رو مشخص کن.',
      'دکمه «آزمایش با داده‌های گذشته (Backtest)» رو بزن تا نتیجه واقعی همراه با کارمزد و لغزش قیمت رو ببینی.',
    ],
    glossary: [
      { term: 'شکست مقاومت (Breakout)', meaning: 'وقتی قیمت از سقف کندل‌های اخیر عبور می‌کنه؛ اگر با حجم بالا همراه باشه نشونه شروع رالی صعودیه.' },
      { term: 'حد سود متحرک (Trailing TP)', meaning: 'وقتی سود از یک درصد خاص رد شد فعال می‌شه و با بالا رفتن قیمت همراهش بالا میاد تا بیشترین سود رو بگیره.' },
      { term: 'تایید حجم', meaning: 'جلوی ورود به شکست‌های فیک و کم‌رمق رو می‌گیره.' },
    ],
    example:
      'استراتژی میان‌مدت: شکست سقف ۲۰ کندل اخیر + حجم بالاتر از ۱.۳ برابر میانگین + هم‌جهت با EMA50، همراه با فروش پله‌ای در +۴٪ و +۸٪.',
    risks: [
      'نتیجه خوب در بک‌تست تاریخی تضمینی برای تکرار عین همون سود در آینده نیست.',
      'اندیکاتورها در بازار رِنج و پرنوسان گاهی سیگنال کاذب می‌دن که با فیلتر حجم و نوسان کمتر می‌شه.',
    ],
    howToStop:
      'توقف ربات باعث می‌شه پایش و سیگنال جدید اجرا نشه؛ پوزیشن باز در صورت وجود قابل بستن دستی در ترمینال یا صبر تا هدف است.',
  },
  AI_MANAGER: {
    title: 'مدیر هوشمند مرکزی (AI Bot Manager)',
    subtitle: 'تحلیل جامع بازار با هوش مصنوعی، رتبه‌بندی ارزها و جلوگیری از تداخل ربات‌ها',
    accentClass: 'text-cyan-300 border-cyan-500/30 bg-cyan-500/10',
    whatItDoes:
      'تمام بازار نوبیتکس و همه ربات‌های فعالت رو یک‌جا بررسی می‌کنه، وضعیت بازار (صعودی، نزولی، رِنج یا پرنوسان) رو تشخیص می‌ده، بهترین ارزها و ربات مناسبشون رو پیشنهاد می‌کنه و جلوی تداخل دو ربات روی یک ارز رو می‌گیره.',
    bestWhen: 'قبل از روشن کردن ربات‌های جدید یا روزی یک‌بار برای چک کردن سلامت کل سبد ربات‌هات.',
    avoidWhen: 'نکته مهم ایمنی: هوش مصنوعی هیچ‌وقت اجازه نداره بدون تایید تو، سقف سرمایه یا محدودیت ضررت رو تغییر بده.',
    steps: [
      'سقف کل بودجه ربات‌ها و سقف ضرر روزانه/کل رو در بخش مدیریت سرمایه مشترک مشخص کن.',
      'دکمه «تحلیل هوشمند بازار» رو بزن تا گزارش کامل برات ساخته بشه.',
      'در حالت تأیید دستی، درخواست‌های خرید و فروش ربات‌ها رو با قیمت، کارمزد و ریسک اینجا تأیید یا رد کن.',
    ],
    glossary: [
      { term: 'رژیم بازار (Market Regime)', meaning: 'حالت کلی بازار الان چطوره: صعودی، نزولی، رِنج یا پرنوسان.' },
      { term: 'قفل تداخل ارز', meaning: 'اجازه نمی‌ده هم‌زمان دو ربات روی یک ارز معامله باز کنن و سفارش متناقض بفرستن.' },
      { term: 'کلید توقف اضطراری (Kill Switch)', meaning: 'یک دکمه واحد که تمام ربات‌های فعال رو هم‌زمان متوقف می‌کنه.' },
    ],
    example:
      'اگر هوش مصنوعی ببینه بیت‌کوین رِنج شده و اتریوم در حال اصلاحه، پیشنهاد می‌کنه روی بیت‌کوین گرید و روی اتریوم خرید پله‌ای اجرا کنی و اگر دو ربات روی یه ارز داشتی هشدار می‌ده.',
    risks: [
      'تحلیل هوش مصنوعی یک ابزار کمکی هوشمند بر اساس داده‌های لحظه‌ایه و نباید جایگزین مدیریت ریسک شخصی بشه.',
    ],
    howToStop:
      'می‌تونی تک‌تک پیشنهادها رو نادیده بگیری یا با Kill Switch کل ربات‌ها رو یک‌جا متوقف کنی.',
  },
};

interface BotEducationModalProps {
  topic: GuideBotTopic | null;
  onClose: () => void;
}

export const BotEducationModal: React.FC<BotEducationModalProps> = ({ topic, onClose }) => {
  if (!topic) return null;
  const guide = BOT_GUIDES[topic];

  return (
    <div
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/80 backdrop-blur-sm p-0 sm:p-4"
      dir="rtl"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-2xl max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl border border-slate-700/80 bg-[#0B1220] text-slate-100 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-slate-800 bg-[#0B1220]/95 backdrop-blur px-5 py-4">
          <div className="flex items-center gap-3 min-w-0">
            <div className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${guide.accentClass}`}>
              <BookOpen className="w-5 h-5" />
            </div>
            <div className="min-w-0">
              <h3 className="text-base sm:text-lg font-extrabold text-white truncate">{guide.title}</h3>
              <p className="text-xs text-slate-400 truncate">{guide.subtitle}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="min-w-[44px] min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 flex items-center justify-center text-slate-300"
            aria-label="بستن راهنما"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-5 text-sm leading-relaxed">
          <section className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-2">
            <h4 className="font-bold text-cyan-300 flex items-center gap-2">
              <Info className="w-4 h-4 shrink-0" />
              این ربات دقیقاً چیکار می‌کنه؟
            </h4>
            <p className="text-slate-200 text-xs sm:text-sm leading-7">{guide.whatItDoes}</p>
          </section>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <section className="rounded-xl border border-emerald-500/25 bg-emerald-500/5 p-3.5 space-y-1.5">
              <h4 className="font-bold text-emerald-300 text-xs flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                چه زمانی استفاده ازش عالیه؟
              </h4>
              <p className="text-slate-300 text-xs leading-6">{guide.bestWhen}</p>
            </section>
            <section className="rounded-xl border border-rose-500/25 bg-rose-500/5 p-3.5 space-y-1.5">
              <h4 className="font-bold text-rose-300 text-xs flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                چه زمانی بهتره استفاده نشه؟
              </h4>
              <p className="text-slate-300 text-xs leading-6">{guide.avoidWhen}</p>
            </section>
          </div>

          <section className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 space-y-2.5">
            <h4 className="font-bold text-white text-xs sm:text-sm">مراحل راه‌اندازی قدم‌به‌قدم</h4>
            <ol className="space-y-2 text-xs text-slate-300">
              {guide.steps.map((s, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="w-5 h-5 rounded-md bg-cyan-500/15 border border-cyan-500/30 text-cyan-300 text-[11px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                    {idx + 1}
                  </span>
                  <span className="leading-6">{s}</span>
                </li>
              ))}
            </ol>
          </section>

          <section className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 space-y-2.5">
            <h4 className="font-bold text-white text-xs sm:text-sm flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-sky-400" />
              توضیح ساده اصطلاحات
            </h4>
            <div className="space-y-2">
              {guide.glossary.map((g, i) => (
                <div key={i} className="rounded-lg border border-slate-800/80 bg-slate-950/60 px-3 py-2 text-xs">
                  <span className="font-bold text-cyan-300">{g.term}: </span>
                  <span className="text-slate-300">{g.meaning}</span>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-xl border border-cyan-500/25 bg-cyan-500/5 p-4 space-y-1.5">
            <h4 className="font-bold text-cyan-300 text-xs">یک مثال واقعی با عدد</h4>
            <p className="text-slate-200 text-xs leading-6">{guide.example}</p>
          </section>

          <section className="rounded-xl border border-amber-500/25 bg-amber-500/5 p-4 space-y-2">
            <h4 className="font-bold text-amber-300 text-xs flex items-center gap-1.5">
              <ShieldAlert className="w-4 h-4" />
              ریسک‌ها و نکات ایمنی مهم
            </h4>
            <ul className="space-y-1.5 text-xs text-slate-300 list-disc list-inside">
              {guide.risks.map((r, i) => (
                <li key={i} className="leading-6">{r}</li>
              ))}
            </ul>
            <p className="text-[11px] text-amber-200/90 pt-1 border-t border-amber-500/20">
              <strong className="text-amber-300">نحوه توقف امن: </strong>
              {guide.howToStop}
            </p>
          </section>

          <button
            type="button"
            onClick={onClose}
            className="w-full min-h-[46px] rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-sm"
          >
            متوجه شدم، ببند
          </button>
        </div>
      </div>
    </div>
  );
};
