import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  Ban,
  Bot,
  Check,
  CheckCircle2,
  ClipboardList,
  Copy,
  CreditCard,
  Lock,
  Mail,
  Megaphone,
  Pause,
  Play,
  Pin,
  RefreshCw,
  Search,
  Send,
  Settings,
  Shield,
  Sliders,
  Trash2,
  UserCheck,
  Users,
  Wallet,
  XCircle,
} from 'lucide-react';
import type {
  AdminBillingOverview,
  AppControlConfig,
  AppFeatureFlags,
  BroadcastSeverity,
  ModuleAccessPolicy,
} from '../types/trading';
import { formatDateTimeShort, formatPrice, formatToman } from '../utils/format';
import { NumericInput } from './NumericInput';

type AdminTab = 'OVERVIEW' | 'USERS' | 'MESSAGES' | 'BILLING' | 'APP_CONTROL';
type UserFilter = 'ALL' | 'PRO' | 'FREE' | 'BANNED';

interface AdminBillingPanelProps {
  overview: AdminBillingOverview | null;
  loading: boolean;
  onRefresh: () => Promise<void>;
  onSaveConfig: (payload: {
    monthlyPriceToman: number;
    monthlyPriceUsdt: number;
    autoUsdtFromRate: boolean;
    usdtWalletAddress: string;
    usdtNetwork: string;
    usdtWalletAddress2: string;
    usdtNetwork2: string;
    zarinpalMerchantId?: string;
    clearZarinpalMerchantId?: boolean;
    zarinpalSandbox: boolean;
  }) => Promise<void>;
  onReviewPayment: (
    requestId: string,
    action: 'APPROVE' | 'REJECT',
    adminNote?: string
  ) => Promise<void>;
  onManageSubscription: (payload: {
    userId: string;
    email?: string;
    displayName?: string;
    action: 'ACTIVATE' | 'REVOKE';
    days?: number;
  }) => Promise<void>;
  onUpdateUserControl: (payload: {
    userId: string;
    isBanned?: boolean;
    banReason?: string;
    adminNote?: string;
  }) => Promise<void>;
  onCreateBroadcast: (payload: {
    title: string;
    body: string;
    severity: BroadcastSeverity;
    pinned?: boolean;
    expiresInHours?: number;
    sendTelegram?: boolean;
  }) => Promise<void>;
  onToggleBroadcast: (broadcastId: string, active: boolean, pinned?: boolean) => Promise<void>;
  onDeleteBroadcast: (broadcastId: string) => Promise<void>;
  onSendDirectMessage: (payload: {
    targetUserId: string;
    subject: string;
    body: string;
    severity: BroadcastSeverity;
  }) => Promise<void>;
  onDeleteDirectMessage: (messageId: string) => Promise<void>;
  onSaveAppControl: (
    payload: Partial<AppControlConfig> & { featurePolicies?: Partial<AppFeatureFlags> }
  ) => Promise<void>;
  onToggleSystemBotStatus: (botId: string, status: 'RUNNING' | 'PAUSED') => Promise<void>;
  onGlobalEmergencyStopBots?: () => Promise<{ stoppedCount: number }>;
}

const DEFAULT_FEATURE_POLICIES: AppFeatureFlags = {
  terminal: 'PRO',
  analysis: 'PRO',
  bots: 'PRO',
  telegram: 'PRO',
  watchers: 'PRO',
  alerts: 'FREE',
  pnlCalculator: 'FREE',
};

const FEATURE_LABELS: Array<{ key: keyof AppFeatureFlags; label: string; desc: string }> = [
  { key: 'terminal', label: 'ترمینال معاملات اسپات', desc: 'خرید و فروش تومانی/تتری و ثبت سفارش' },
  { key: 'analysis', label: 'تحلیل تکنیکال و هوش مصنوعی', desc: 'چارت چندتایم‌فریمی، اندیکاتورها و دستیار AI' },
  { key: 'bots', label: 'ربات معامله‌گر خودکار و بک‌تست', desc: 'ساخت ربات استراتژی ۲۴ ساعته و شبیه‌ساز' },
  { key: 'telegram', label: 'اتصال ربات تلگرام', desc: 'ارسال خودکار هشدارها و قیمت‌ها به تلگرام' },
  { key: 'watchers', label: 'گزارش لحظه‌ای قیمت هر X دقیقه', desc: 'ارسال دوره‌ای قیمت و وب‌هوک' },
  { key: 'alerts', label: 'هشدار رسیدن به قیمت هدف', desc: 'اعلان عبور قیمت از سقف یا کف دلخواه' },
  { key: 'pnlCalculator', label: 'ماشین‌حساب سود و زیان', desc: 'محاسبه دقیق سود تومانی و تتری قبل از معامله' },
];

const SEVERITY_OPTIONS: Array<{ value: BroadcastSeverity; label: string; textClass: string }> = [
  { value: 'INFO', label: 'اطلاعیه', textClass: 'text-cyan-300' },
  { value: 'SUCCESS', label: 'مژده / تایید', textClass: 'text-emerald-400' },
  { value: 'WARNING', label: 'هشدار', textClass: 'text-amber-300' },
  { value: 'URGENT', label: 'فوری', textClass: 'text-rose-400' },
];

const POLICY_OPTIONS: Array<{ value: ModuleAccessPolicy; label: string }> = [
  { value: 'FREE', label: 'رایگان (همه)' },
  { value: 'PRO', label: 'اشتراک حرفه‌ای' },
  { value: 'DISABLED', label: 'غیرفعال' },
];

export const AdminBillingPanel: React.FC<AdminBillingPanelProps> = ({
  overview,
  loading,
  onRefresh,
  onSaveConfig,
  onReviewPayment,
  onManageSubscription,
  onUpdateUserControl,
  onCreateBroadcast,
  onToggleBroadcast,
  onDeleteBroadcast,
  onSendDirectMessage,
  onDeleteDirectMessage,
  onSaveAppControl,
  onToggleSystemBotStatus,
  onGlobalEmergencyStopBots,
}) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('OVERVIEW');
  const [feedback, setFeedback] = useState<{ type: 'ok' | 'err'; text: string } | null>(null);
  const [busyActionId, setBusyActionId] = useState<string | null>(null);
  const [copiedUid, setCopiedUid] = useState<string | null>(null);

  // Billing Config Form
  const [priceTomanStr, setPriceTomanStr] = useState('950000');
  const [priceUsdtStr, setPriceUsdtStr] = useState('15');
  const [autoUsdt, setAutoUsdt] = useState(true);
  const [wallet1, setWallet1] = useState('');
  const [net1, setNet1] = useState('TRC20');
  const [wallet2, setWallet2] = useState('');
  const [net2, setNet2] = useState('BEP20');
  const [merchantIdInput, setMerchantIdInput] = useState('');
  const [sandboxMode, setSandboxMode] = useState(true);
  const [savingConfig, setSavingConfig] = useState(false);

  // Manual Grant Form
  const [manualUserId, setManualUserId] = useState('');
  const [manualEmail, setManualEmail] = useState('');
  const [manualDays, setManualDays] = useState('30');

  // Users Directory Filter & Editor
  const [userSearch, setUserSearch] = useState('');
  const [userFilter, setUserFilter] = useState<UserFilter>('ALL');
  const [expandedUserId, setExpandedUserId] = useState<string | null>(null);
  const [grantDaysInput, setGrantDaysInput] = useState('30');
  const [banReasonInput, setBanReasonInput] = useState('');
  const [userNoteInput, setUserNoteInput] = useState('');

  // Public Broadcast Form
  const [bcTitle, setBcTitle] = useState('');
  const [bcBody, setBcBody] = useState('');
  const [bcSeverity, setBcSeverity] = useState<BroadcastSeverity>('INFO');
  const [bcPinned, setBcPinned] = useState(false);
  const [bcExpiresHours, setBcExpiresHours] = useState('0');
  const [bcSendTelegram, setBcSendTelegram] = useState(false);
  const [sendingBroadcast, setSendingBroadcast] = useState(false);

  // Direct 1-to-1 Message Form
  const [dmTargetUserId, setDmTargetUserId] = useState('');
  const [dmCustomUid, setDmCustomUid] = useState('');
  const [dmSubject, setDmSubject] = useState('');
  const [dmBody, setDmBody] = useState('');
  const [dmSeverity, setDmSeverity] = useState<BroadcastSeverity>('INFO');
  const [sendingDm, setSendingDm] = useState(false);

  // App Control Form
  const [maintenanceMode, setMaintenanceMode] = useState(false);
  const [maintenanceMessage, setMaintenanceMessage] = useState('');
  const [promoFreeAccess, setPromoFreeAccess] = useState(false);
  const [promoBannerText, setPromoBannerText] = useState('');
  const [supportPhone, setSupportPhone] = useState('09999961279');
  const [supportTelegram, setSupportTelegram] = useState('');
  const [featurePolicies, setFeaturePolicies] = useState<AppFeatureFlags>(DEFAULT_FEATURE_POLICIES);
  const [savingAppControl, setSavingAppControl] = useState(false);

  useEffect(() => {
    if (!overview) return;
    setPriceTomanStr(String(overview.config.monthlyPriceToman));
    setPriceUsdtStr(String(overview.config.fixedUsdtPrice));
    setAutoUsdt(overview.config.autoUsdtFromRate);
    setWallet1(overview.config.usdtWalletAddress || '');
    setNet1(overview.config.usdtNetwork || 'TRC20');
    setWallet2(overview.config.usdtWalletAddress2 || '');
    setNet2(overview.config.usdtNetwork2 || 'BEP20');
    setSandboxMode(overview.config.zarinpalSandbox);

    if (overview.appControl) {
      setMaintenanceMode(overview.appControl.maintenanceMode);
      setMaintenanceMessage(overview.appControl.maintenanceMessage || '');
      setPromoFreeAccess(overview.appControl.promoFreeAccess);
      setPromoBannerText(overview.appControl.promoBannerText || '');
      setSupportPhone(overview.appControl.supportPhone || '09999961279');
      setSupportTelegram(overview.appControl.supportTelegram || '');
      setFeaturePolicies(overview.appControl.featurePolicies || DEFAULT_FEATURE_POLICIES);
    }

    if (!dmTargetUserId && overview.users && overview.users.length > 0) {
      const nonAdmin = overview.users.find((u) => !u.isAdmin) || overview.users[0];
      setDmTargetUserId(nonAdmin.uid);
    }
  }, [overview, dmTargetUserId]);

  const stats = overview?.stats || {
    totalUsers: 0,
    activeUsers24h: 0,
    activeProUsers: 0,
    bannedUsers: 0,
    pendingPayments: 0,
    totalRevenueToman: 0,
    totalRevenueUsdt: 0,
    runningBotsCount: 0,
    totalBotsCount: 0,
    activeAlertsCount: 0,
    activeWatchersCount: 0,
    ideasCount: 0,
    activeBroadcastsCount: 0,
    unreadDirectMessagesTotal: 0,
    totalReferralsCount: 0,
    convertedReferralsCount: 0,
    totalReferralBonusDaysGranted: 0,
  };

  const requests = overview?.paymentRequests || [];
  const users = overview?.users || [];
  const broadcasts = overview?.broadcasts || [];
  const directMessages = overview?.directMessages || [];
  const auditLogs = overview?.auditLogs || [];
  const systemBots = overview?.bots || [];

  const filteredUsers = useMemo(() => {
    const q = userSearch.trim().toLowerCase();
    return users.filter((u) => {
      if (userFilter === 'PRO' && !u.hasProAccess) return false;
      if (userFilter === 'FREE' && (u.hasProAccess || u.isBanned)) return false;
      if (userFilter === 'BANNED' && !u.isBanned) return false;
      if (!q) return true;
      return (
        u.displayName.toLowerCase().includes(q) ||
        u.email.toLowerCase().includes(q) ||
        u.uid.toLowerCase().includes(q)
      );
    });
  }, [users, userSearch, userFilter]);

  const copyText = (value: string) => {
    void navigator.clipboard?.writeText(value);
    setCopiedUid(value);
    setTimeout(() => setCopiedUid(null), 1600);
  };

  const openDirectMessageForUser = (uid: string) => {
    setDmTargetUserId(uid);
    setDmCustomUid('');
    setActiveTab('MESSAGES');
  };

  const handleSaveBilling = async (e: React.FormEvent) => {
    e.preventDefault();
    setFeedback(null);
    setSavingConfig(true);
    try {
      await onSaveConfig({
        monthlyPriceToman: Number(priceTomanStr) || 950_000,
        monthlyPriceUsdt: Number(priceUsdtStr) || 15,
        autoUsdtFromRate: autoUsdt,
        usdtWalletAddress: wallet1.trim(),
        usdtNetwork: net1.trim() || 'TRC20',
        usdtWalletAddress2: wallet2.trim(),
        usdtNetwork2: net2.trim() || 'BEP20',
        zarinpalMerchantId: merchantIdInput.trim() || undefined,
        zarinpalSandbox: sandboxMode,
      });
      setMerchantIdInput('');
      setFeedback({
        type: 'ok',
        text: 'تنظیمات کیف پول دلاری، تعرفه اشتراک و درگاه زرین‌پال با موفقیت ذخیره شد.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ذخیره تنظیمات مالی',
      });
    } finally {
      setSavingConfig(false);
    }
  };

  const handleClearZarinpal = async () => {
    setSavingConfig(true);
    setFeedback(null);
    try {
      await onSaveConfig({
        monthlyPriceToman: Number(priceTomanStr) || 950_000,
        monthlyPriceUsdt: Number(priceUsdtStr) || 15,
        autoUsdtFromRate: autoUsdt,
        usdtWalletAddress: wallet1.trim(),
        usdtNetwork: net1.trim() || 'TRC20',
        usdtWalletAddress2: wallet2.trim(),
        usdtNetwork2: net2.trim() || 'BEP20',
        clearZarinpalMerchantId: true,
        zarinpalSandbox: sandboxMode,
      });
      setFeedback({ type: 'ok', text: 'کد پذیرنده زرین‌پال حذف شد.' });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در حذف کد زرین‌پال',
      });
    } finally {
      setSavingConfig(false);
    }
  };

  const handleReview = async (requestId: string, action: 'APPROVE' | 'REJECT') => {
    setBusyActionId(requestId);
    setFeedback(null);
    try {
      await onReviewPayment(
        requestId,
        action,
        action === 'APPROVE' ? 'تایید واریز توسط مدیر سیستم' : 'تراکنش توسط مدیر تایید نشد'
      );
      setFeedback({
        type: 'ok',
        text:
          action === 'APPROVE'
            ? 'پرداخت تایید شد و اشتراک ۳۰ روزه کاربر فعال گردید.'
            : 'درخواست پرداخت رد شد.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در بررسی درخواست',
      });
    } finally {
      setBusyActionId(null);
    }
  };

  const handleManualGrant = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualUserId.trim()) return;
    setBusyActionId('manual');
    setFeedback(null);
    try {
      await onManageSubscription({
        userId: manualUserId.trim(),
        email: manualEmail.trim() || undefined,
        action: 'ACTIVATE',
        days: Number(manualDays) || 30,
      });
      setManualUserId('');
      setManualEmail('');
      setFeedback({
        type: 'ok',
        text: `اشتراک ${Number(manualDays) || 30} روزه کاربر با موفقیت فعال شد.`,
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در فعال‌سازی دستی اشتراک',
      });
    } finally {
      setBusyActionId(null);
    }
  };

  const handlePublishBroadcast = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!bcTitle.trim() || !bcBody.trim()) return;
    setSendingBroadcast(true);
    setFeedback(null);
    try {
      await onCreateBroadcast({
        title: bcTitle.trim(),
        body: bcBody.trim(),
        severity: bcSeverity,
        pinned: bcPinned,
        expiresInHours: Number(bcExpiresHours) > 0 ? Number(bcExpiresHours) : undefined,
        sendTelegram: bcSendTelegram,
      });
      setBcTitle('');
      setBcBody('');
      setBcPinned(false);
      setFeedback({
        type: 'ok',
        text: 'اطلاعیه عمومی منتشر شد و هم‌اکنون به همه کاربران نمایش داده می‌شود.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در انتشار پیام عمومی',
      });
    } finally {
      setSendingBroadcast(false);
    }
  };

  const handleSendDm = async (e: React.FormEvent) => {
    e.preventDefault();
    const targetId = dmCustomUid.trim() || dmTargetUserId.trim();
    if (!targetId || !dmSubject.trim() || !dmBody.trim()) return;
    setSendingDm(true);
    setFeedback(null);
    try {
      await onSendDirectMessage({
        targetUserId: targetId,
        subject: dmSubject.trim(),
        body: dmBody.trim(),
        severity: dmSeverity,
      });
      setDmSubject('');
      setDmBody('');
      setFeedback({
        type: 'ok',
        text: 'پیام اختصاصی با موفقیت به صندوق پیام کاربر ارسال شد.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ارسال پیام تکی',
      });
    } finally {
      setSendingDm(false);
    }
  };

  const handleSaveAppControlForm = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingAppControl(true);
    setFeedback(null);
    try {
      await onSaveAppControl({
        maintenanceMode,
        maintenanceMessage: maintenanceMessage.trim(),
        promoFreeAccess,
        promoBannerText: promoBannerText.trim(),
        supportPhone: supportPhone.trim(),
        supportTelegram: supportTelegram.trim(),
        featurePolicies,
      });
      setFeedback({
        type: 'ok',
        text: 'تنظیمات کلی برنامه، وضعیت دسترسی امکانات و راه‌های پشتیبانی ذخیره و اعمال شد.',
      });
    } catch (err) {
      setFeedback({
        type: 'err',
        text: err instanceof Error ? err.message : 'خطا در ذخیره تنظیمات کلی برنامه',
      });
    } finally {
      setSavingAppControl(false);
    }
  };

  return (
    <div className="space-y-5">
      {/* Control Center Header */}
      <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-cyan-500/15 border border-cyan-500/40 flex items-center justify-center shrink-0">
            <Shield className="w-5 h-5 text-cyan-400" />
          </div>
          <div>
            <h1 className="text-base sm:text-lg font-semibold text-white">
              مرکز فرماندهی و مدیریت جامع برنامه
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              مدیریت کامل کاربران، پیام‌های عمومی و تکی، تعرفه و کیف پول، کنترل امکانات و ربات‌های معاملاتی
            </p>
          </div>
        </div>

        <button
          type="button"
          onClick={() => void onRefresh()}
          disabled={loading}
          className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg text-xs font-medium bg-slate-900 border border-slate-700 hover:border-cyan-500/50 text-slate-200 transition-colors whitespace-nowrap shrink-0"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>بروزرسانی اطلاعات</span>
        </button>
      </section>

      {/* Executive 4-Card KPI Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span>کاربران ثبت‌شده</span>
            <Users className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-semibold font-mono-num text-white" dir="ltr">
            {stats.totalUsers}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            فعال در ۲۴ ساعت اخیر:{' '}
            <span className="font-mono-num text-cyan-300">{stats.activeUsers24h}</span>
          </div>
        </div>

        <div className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span>اشتراک حرفه‌ای و وضعیت</span>
            <UserCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-xl font-semibold font-mono-num text-emerald-400" dir="ltr">
            {stats.activeProUsers}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            کاربران مسدود شده:{' '}
            <span className="font-mono-num text-rose-400">{stats.bannedUsers}</span>
          </div>
        </div>

        <div className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span>مالی و فیش‌های در انتظار</span>
            <Wallet className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-base font-semibold font-mono-num text-amber-300" dir="ltr">
            {formatToman(stats.totalRevenueToman)} ت · ${formatPrice(stats.totalRevenueUsdt)}
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            در انتظار بررسی:{' '}
            <span className="font-mono-num text-amber-300 font-semibold">
              {stats.pendingPayments} فیش
            </span>
          </div>
        </div>

        <div className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-4">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1.5">
            <span>ربات‌ها و سیستم دعوت</span>
            <Activity className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-xl font-semibold font-mono-num text-white" dir="ltr">
            {stats.runningBotsCount} / {stats.totalBotsCount} ربات
          </div>
          <div className="text-[11px] text-slate-400 mt-1">
            دعوت:{' '}
            <span className="font-mono-num text-emerald-300">
              {stats.convertedReferralsCount}/{stats.totalReferralsCount}
            </span>
            <span aria-hidden="true"> · </span>
            هدیه:{' '}
            <span className="font-mono-num text-cyan-300">
              +{stats.totalReferralBonusDaysGranted} روز
            </span>
          </div>
        </div>
      </div>

      {/* Segmented Navigation Bar */}
      <div className="flex flex-wrap items-center gap-1 bg-[#0A101D] p-1.5 rounded-lg border border-slate-800/90 text-xs">
        {(
          [
            { id: 'OVERVIEW', label: 'نمای کلی و لاگ', icon: ClipboardList },
            { id: 'USERS', label: `مدیریت کاربران (${users.length})`, icon: Users },
            {
              id: 'MESSAGES',
              label: `پیام‌های عمومی و تکی (${broadcasts.length + directMessages.length})`,
              icon: Megaphone,
            },
            {
              id: 'BILLING',
              label: `مالی و فیش‌ها${stats.pendingPayments > 0 ? ` (${stats.pendingPayments})` : ''}`,
              icon: CreditCard,
            },
            { id: 'APP_CONTROL', label: 'کنترل برنامه و ربات‌ها', icon: Sliders },
          ] as const
        ).map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 ${
                isActive
                  ? 'bg-cyan-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {feedback && (
        <div
          className={`text-xs px-4 py-3 rounded-lg border ${
            feedback.type === 'ok'
              ? 'bg-emerald-500/10 border-emerald-500/35 text-emerald-300'
              : 'bg-rose-500/10 border-rose-500/35 text-rose-300'
          }`}
        >
          {feedback.text}
        </div>
      )}

      {/* TAB 1: OVERVIEW & AUDIT LOG */}
      {activeTab === 'OVERVIEW' && (
        <div className="space-y-5">
          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 space-y-4">
            <h2 className="text-sm font-semibold text-white border-b border-slate-800 pb-3">
              وضعیت لحظه‌ای پلتفرم و دسترسی سریع
            </h2>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 space-y-1.5">
                <div className="text-slate-400">حالت نگهداری و تعمیرات</div>
                <div
                  className={`font-semibold ${
                    overview?.appControl.maintenanceMode ? 'text-rose-400' : 'text-emerald-400'
                  }`}
                >
                  {overview?.appControl.maintenanceMode
                    ? 'فعال (کاربران صفحه تعمیرات می‌بینند)'
                    : 'عادی (پلتفرم برای همه باز است)'}
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('APP_CONTROL')}
                  className="text-cyan-400 hover:underline text-[11px]"
                >
                  تغییر در تنظیمات برنامه
                </button>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 space-y-1.5">
                <div className="text-slate-400">جشنواره دسترسی رایگان (همه امکانات)</div>
                <div
                  className={`font-semibold ${
                    overview?.appControl.promoFreeAccess ? 'text-amber-300' : 'text-slate-200'
                  }`}
                >
                  {overview?.appControl.promoFreeAccess
                    ? 'فعال (همه کاربران دسترسی حرفه‌ای دارند)'
                    : 'غیرفعال (محدود به خریداران اشتراک)'}
                </div>
                <button
                  type="button"
                  onClick={() => setActiveTab('APP_CONTROL')}
                  className="text-cyan-400 hover:underline text-[11px]"
                >
                  مدیریت سطوح امکانات
                </button>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 space-y-1.5">
                <div className="text-slate-400">وضعیت درگاه پرداخت و پیام‌ها</div>
                <div className="text-slate-200">
                  زرین‌پال:{' '}
                  <span
                    className={
                      overview?.config.zarinpalEnabled ? 'text-emerald-400' : 'text-amber-300'
                    }
                  >
                    {overview?.config.zarinpalEnabled ? 'متصل' : 'در انتظار Merchant ID'}
                  </span>
                  <span aria-hidden="true"> · </span>
                  پیام تکی خوانده‌نشده:{' '}
                  <span className="font-mono-num text-cyan-300">
                    {stats.unreadDirectMessagesTotal}
                  </span>
                </div>
                <div className="flex items-center gap-3 pt-0.5">
                  <button
                    type="button"
                    onClick={() => setActiveTab('BILLING')}
                    className="text-amber-300 hover:underline text-[11px]"
                  >
                    بررسی فیش‌ها ({stats.pendingPayments})
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('MESSAGES')}
                    className="text-cyan-400 hover:underline text-[11px]"
                  >
                    ارسال پیام عمومی / تکی
                  </button>
                </div>
              </div>
            </div>
          </section>

          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-800 bg-[#060A14] flex items-center justify-between">
              <h2 className="text-sm font-semibold text-white">
                گزارش اقدامات مدیر (Audit Log)
              </h2>
              <span className="text-xs text-slate-400 font-mono-num">
                {auditLogs.length} رویداد اخیر
              </span>
            </div>

            {auditLogs.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                هنوز اقدام مدیریتی ثبت نشده است.
              </div>
            ) : (
              <div className="divide-y divide-slate-800/70 text-xs max-h-96 overflow-y-auto">
                {auditLogs.map((log) => (
                  <div
                    key={log.id}
                    className="px-5 py-3 flex flex-wrap items-center justify-between gap-2"
                  >
                    <div className="space-y-0.5">
                      <div className="text-white font-medium">{log.details}</div>
                      <div className="text-[11px] text-slate-500 font-mono-num" dir="ltr">
                        {log.action} · توسط {log.actorEmail}
                        {log.target ? ` · هدف: ${log.target}` : ''}
                      </div>
                    </div>
                    <span className="text-[11px] font-mono-num text-slate-400" dir="ltr">
                      {formatDateTimeShort(log.createdAt)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {/* TAB 2: USERS MANAGEMENT */}
      {activeTab === 'USERS' && (
        <div className="space-y-5">
          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden">
            <div className="px-5 py-4 border-b border-slate-800 bg-[#060A14] flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
                {(
                  [
                    { id: 'ALL', label: `همه (${users.length})` },
                    { id: 'PRO', label: `حرفه‌ای (${users.filter((u) => u.hasProAccess).length})` },
                    {
                      id: 'FREE',
                      label: `رایگان (${users.filter((u) => !u.hasProAccess && !u.isBanned).length})`,
                    },
                    { id: 'BANNED', label: `مسدود (${users.filter((u) => u.isBanned).length})` },
                  ] as const
                ).map((f) => (
                  <button
                    key={f.id}
                    type="button"
                    onClick={() => setUserFilter(f.id)}
                    className={`px-3 py-1 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 ${
                      userFilter === f.id
                        ? 'bg-cyan-500 text-slate-950 font-semibold'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    {f.label}
                  </button>
                ))}
              </div>

              <div className="relative w-full sm:w-72">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="text"
                  value={userSearch}
                  onChange={(e) => setUserSearch(e.target.value)}
                  placeholder="جستجوی نام، ایمیل یا شناسه UID کاربر..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg pr-8 pl-3 py-1.5 text-xs text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            {filteredUsers.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                کاربری مطابق جستجوی شما یافت نشد.
              </div>
            ) : (
              <div className="divide-y divide-slate-800/80">
                {filteredUsers.map((u) => {
                  const isExpanded = expandedUserId === u.uid;
                  return (
                    <div key={u.uid} className="p-4 sm:px-5 space-y-3 text-xs">
                      <div className="flex flex-wrap items-center justify-between gap-3">
                        <div className="space-y-1 min-w-0">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-semibold text-white text-sm">
                              {u.displayName}
                            </span>
                            {u.isAdmin && (
                              <span className="text-[11px] font-semibold text-cyan-300">
                                (ادمین کل)
                              </span>
                            )}
                            {u.isBanned ? (
                              <span className="text-[11px] font-semibold text-rose-400">
                                مسدود شده
                              </span>
                            ) : u.hasProAccess ? (
                              <span className="text-[11px] font-semibold text-emerald-400">
                                اشتراک حرفه‌ای ({u.isAdmin ? 'دائمی' : `${u.daysRemaining} روز`})
                              </span>
                            ) : (
                              <span className="text-[11px] text-slate-400">کاربر رایگان</span>
                            )}
                          </div>

                          <div className="flex flex-wrap items-center gap-2 text-[11px] text-slate-400">
                            <span className="font-mono-num text-slate-300" dir="ltr">
                              {u.email || 'بدون ایمیل'}
                            </span>
                            <span aria-hidden="true">·</span>
                            <button
                              type="button"
                              onClick={() => copyText(u.uid)}
                              className="inline-flex items-center gap-1 font-mono-num text-slate-400 hover:text-cyan-300"
                              dir="ltr"
                              title="کپی UID کاربر"
                            >
                              <span>UID: {u.uid.slice(0, 12)}...</span>
                              {copiedUid === u.uid ? (
                                <Check className="w-3 h-3 text-emerald-400" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                            <span aria-hidden="true">·</span>
                            <span className="font-mono-num" dir="ltr">
                              آخرین فعالیت: {formatDateTimeShort(u.lastSeenAt)}
                            </span>
                            {u.paymentRequestsCount > 0 && (
                              <>
                                <span aria-hidden="true">·</span>
                                <span>
                                  {u.approvedPaymentsCount}/{u.paymentRequestsCount} پرداخت تاییدشده
                                </span>
                              </>
                            )}
                            <span aria-hidden="true">·</span>
                            <span className="font-mono-num text-cyan-300" dir="ltr">
                              کد دعوت: {u.referralCode}
                            </span>
                            <span aria-hidden="true">·</span>
                            <span>
                              دعوت: <span className="font-mono-num text-white">{u.invitedCount}</span>{' '}
                              (خرید موفق:{' '}
                              <span className="font-mono-num text-emerald-400">
                                {u.convertedReferralsCount}
                              </span>
                              {u.referralBonusDaysEarned > 0
                                ? ` · +${u.referralBonusDaysEarned} روز رایگان`
                                : ''}
                              )
                            </span>
                          </div>

                          {u.adminNote && (
                            <div className="text-[11px] text-amber-300/90">
                              یادداشت مدیر: {u.adminNote}
                            </div>
                          )}
                          {u.isBanned && u.banReason && (
                            <div className="text-[11px] text-rose-300">
                              علت مسدودی: {u.banReason}
                            </div>
                          )}
                        </div>

                        <div className="flex flex-wrap items-center gap-1.5 shrink-0">
                          <button
                            type="button"
                            onClick={() => openDirectMessageForUser(u.uid)}
                            className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 font-medium whitespace-nowrap"
                          >
                            <Mail className="w-3.5 h-3.5" />
                            <span>ارسال پیام تکی</span>
                          </button>

                          {!u.isAdmin && (
                            <button
                              type="button"
                              onClick={() => {
                                if (isExpanded) {
                                  setExpandedUserId(null);
                                } else {
                                  setExpandedUserId(u.uid);
                                  setGrantDaysInput('30');
                                  setBanReasonInput(u.banReason || '');
                                  setUserNoteInput(u.adminNote || '');
                                }
                              }}
                              className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded bg-slate-900 border border-slate-700 hover:border-cyan-500/50 text-slate-200 font-medium whitespace-nowrap"
                            >
                              <Settings className="w-3.5 h-3.5" />
                              <span>{isExpanded ? 'بستن مدیریت' : 'مدیریت دسترسی'}</span>
                            </button>
                          )}
                        </div>
                      </div>

                      {isExpanded && !u.isAdmin && (
                        <div className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 grid grid-cols-1 lg:grid-cols-3 gap-4">
                          {/* Subscription Controls */}
                          <div className="space-y-2">
                            <div className="text-[11px] font-semibold text-slate-300">
                              مدیریت اشتراک حرفه‌ای
                            </div>
                            <div className="flex items-center gap-2">
                              <NumericInput
                                allowDecimal={false}
                                value={grantDaysInput}
                                onValueChange={setGrantDaysInput}
                                className="w-20 bg-[#0A101D] border border-slate-700 rounded px-2.5 py-1.5 text-white"
                              />
                              <button
                                type="button"
                                disabled={busyActionId === `sub-${u.uid}`}
                                onClick={async () => {
                                  setBusyActionId(`sub-${u.uid}`);
                                  try {
                                    await onManageSubscription({
                                      userId: u.uid,
                                      email: u.email,
                                      displayName: u.displayName,
                                      action: 'ACTIVATE',
                                      days: Number(grantDaysInput) || 30,
                                    });
                                    setFeedback({
                                      type: 'ok',
                                      text: `اشتراک ${u.displayName} برای ${Number(grantDaysInput) || 30} روز فعال شد.`,
                                    });
                                  } finally {
                                    setBusyActionId(null);
                                  }
                                }}
                                className="px-3 py-1.5 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-semibold whitespace-nowrap"
                              >
                                فعال / تمدید
                              </button>
                              {u.hasProAccess && (
                                <button
                                  type="button"
                                  disabled={busyActionId === `sub-${u.uid}`}
                                  onClick={async () => {
                                    setBusyActionId(`sub-${u.uid}`);
                                    try {
                                      await onManageSubscription({
                                        userId: u.uid,
                                        action: 'REVOKE',
                                      });
                                      setFeedback({
                                        type: 'ok',
                                        text: `اشتراک کاربر ${u.displayName} لغو شد.`,
                                      });
                                    } finally {
                                      setBusyActionId(null);
                                    }
                                  }}
                                  className="px-2.5 py-1.5 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 whitespace-nowrap"
                                >
                                  لغو
                                </button>
                              )}
                            </div>
                          </div>

                          {/* Ban / Unban Control */}
                          <div className="space-y-2">
                            <div className="text-[11px] font-semibold text-slate-300">
                              مسدودسازی حساب کاربر
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={banReasonInput}
                                onChange={(e) => setBanReasonInput(e.target.value)}
                                placeholder="دلیل مسدودی (مثلاً تخلف قوانین)..."
                                className="flex-1 bg-[#0A101D] border border-slate-700 rounded px-2.5 py-1.5 text-white placeholder:text-slate-600"
                              />
                              <button
                                type="button"
                                disabled={busyActionId === `ban-${u.uid}`}
                                onClick={async () => {
                                  setBusyActionId(`ban-${u.uid}`);
                                  try {
                                    await onUpdateUserControl({
                                      userId: u.uid,
                                      isBanned: !u.isBanned,
                                      banReason: banReasonInput.trim(),
                                    });
                                    setFeedback({
                                      type: 'ok',
                                      text: !u.isBanned
                                        ? `حساب ${u.displayName} مسدود شد.`
                                        : `مسدودی حساب ${u.displayName} رفع شد.`,
                                    });
                                  } finally {
                                    setBusyActionId(null);
                                  }
                                }}
                                className={`inline-flex items-center gap-1 px-3 py-1.5 rounded font-semibold whitespace-nowrap ${
                                  u.isBanned
                                    ? 'bg-emerald-600 hover:bg-emerald-500 text-white'
                                    : 'bg-rose-600 hover:bg-rose-500 text-white'
                                }`}
                              >
                                <Ban className="w-3.5 h-3.5" />
                                <span>{u.isBanned ? 'رفع مسدودی' : 'مسدود کردن'}</span>
                              </button>
                            </div>
                          </div>

                          {/* Internal Admin Note */}
                          <div className="space-y-2">
                            <div className="text-[11px] font-semibold text-slate-300">
                              یادداشت اختصاصی مدیر (محرمانه)
                            </div>
                            <div className="flex items-center gap-2">
                              <input
                                type="text"
                                value={userNoteInput}
                                onChange={(e) => setUserNoteInput(e.target.value)}
                                placeholder="توضیحات درباره این کاربر..."
                                className="flex-1 bg-[#0A101D] border border-slate-700 rounded px-2.5 py-1.5 text-white placeholder:text-slate-600"
                              />
                              <button
                                type="button"
                                disabled={busyActionId === `note-${u.uid}`}
                                onClick={async () => {
                                  setBusyActionId(`note-${u.uid}`);
                                  try {
                                    await onUpdateUserControl({
                                      userId: u.uid,
                                      adminNote: userNoteInput.trim(),
                                    });
                                    setFeedback({
                                      type: 'ok',
                                      text: 'یادداشت مدیر برای این کاربر ذخیره شد.',
                                    });
                                  } finally {
                                    setBusyActionId(null);
                                  }
                                }}
                                className="px-3 py-1.5 rounded bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold whitespace-nowrap"
                              >
                                ذخیره
                              </button>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </section>

          {/* Manual Pre-grant by UID */}
          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 space-y-3">
            <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <h2 className="text-sm font-semibold text-white">
                فعال‌سازی دستی اشتراک با شناسه UID (برای کاربران جدید)
              </h2>
            </div>

            <form
              onSubmit={(e) => void handleManualGrant(e)}
              className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs"
            >
              <input
                type="text"
                value={manualUserId}
                onChange={(e) => setManualUserId(e.target.value)}
                placeholder="شناسه کاربر (Firebase UID)"
                dir="ltr"
                className="bg-slate-950 border border-slate-700 rounded-md px-3 py-2 font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
              />
              <input
                type="email"
                value={manualEmail}
                onChange={(e) => setManualEmail(e.target.value)}
                placeholder="ایمیل کاربر (اختیاری)"
                dir="ltr"
                className="bg-slate-950 border border-slate-700 rounded-md px-3 py-2 font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
              />
              <NumericInput
                allowDecimal={false}
                value={manualDays}
                onValueChange={setManualDays}
                placeholder="30"
                className="bg-slate-950 border border-slate-700 rounded-md px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                disabled={busyActionId === 'manual' || !manualUserId.trim()}
                className="py-2 px-4 rounded-md font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors disabled:opacity-50 whitespace-nowrap"
              >
                فعال‌سازی اشتراک ({manualDays || 30} روز)
              </button>
            </form>
          </section>
        </div>
      )}

      {/* TAB 3: PUBLIC BROADCASTS & 1-TO-1 DIRECT MESSAGES */}
      {activeTab === 'MESSAGES' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 items-start">
          {/* Public Broadcasts */}
          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-800 bg-[#060A14] flex items-center gap-2">
              <Megaphone className="w-4 h-4 text-amber-400" />
              <h2 className="text-sm font-semibold text-white">
                پیام‌های عمومی به همه کاربران (بنر بالای برنامه)
              </h2>
            </div>

            <form
              onSubmit={(e) => void handlePublishBroadcast(e)}
              className="p-5 space-y-3 text-xs border-b border-slate-800"
            >
              <div>
                <label className="block text-slate-400 mb-1">عنوان اطلاعیه عمومی</label>
                <input
                  type="text"
                  value={bcTitle}
                  onChange={(e) => setBcTitle(e.target.value)}
                  placeholder="مثلاً: تخفیف ویژه یا بروزرسانی ربات نوبیتکس"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">متن کامل پیام عمومی</label>
                <textarea
                  rows={3}
                  value={bcBody}
                  onChange={(e) => setBcBody(e.target.value)}
                  placeholder="متنی که به تمام کاربران در بالای برنامه و صندوق پیام نمایش داده می‌شود..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 mb-1">نوع پیام</label>
                  <div className="grid grid-cols-4 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                    {SEVERITY_OPTIONS.map((opt) => (
                      <button
                        key={opt.value}
                        type="button"
                        onClick={() => setBcSeverity(opt.value)}
                        className={`py-1 rounded text-[11px] font-medium transition-colors ${
                          bcSeverity === opt.value
                            ? 'bg-cyan-500 text-slate-950 font-semibold'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">مدت نمایش</label>
                  <select
                    value={bcExpiresHours}
                    onChange={(e) => setBcExpiresHours(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-amber-400"
                  >
                    <option value="0">دائمی (تا زمان حذف توسط مدیر)</option>
                    <option value="12">۱۲ ساعت</option>
                    <option value="24">۲۴ ساعت (۱ روز)</option>
                    <option value="72">۷۲ ساعت (۳ روز)</option>
                    <option value="168">۱ هفته</option>
                  </select>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4 pt-1">
                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={bcPinned}
                    onChange={(e) => setBcPinned(e.target.checked)}
                    className="accent-amber-500"
                  />
                  <span>سنجاق دائمی (کاربر نتواند بنر را ببندد)</span>
                </label>

                <label className="flex items-center gap-2 text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={bcSendTelegram}
                    onChange={(e) => setBcSendTelegram(e.target.checked)}
                    className="accent-cyan-500"
                  />
                  <span>ارسال همزمان به ربات تلگرام متصل</span>
                </label>
              </div>

              <button
                type="submit"
                disabled={sendingBroadcast || !bcTitle.trim() || !bcBody.trim()}
                className="w-full inline-flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-semibold transition-colors disabled:opacity-50"
              >
                <Megaphone className="w-4 h-4" />
                <span>{sendingBroadcast ? 'در حال انتشار...' : 'انتشار پیام عمومی برای همه'}</span>
              </button>
            </form>

            {/* Broadcasts List */}
            {broadcasts.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500">
                هنوز پیام عمومی منتشر نشده است.
              </div>
            ) : (
              <div className="divide-y divide-slate-800/80 max-h-96 overflow-y-auto text-xs">
                {broadcasts.map((b) => (
                  <div key={b.id} className="p-4 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-semibold ${
                            SEVERITY_OPTIONS.find((s) => s.value === b.severity)?.textClass ||
                            'text-cyan-300'
                          }`}
                        >
                          {SEVERITY_OPTIONS.find((s) => s.value === b.severity)?.label}
                        </span>
                        <span className="font-semibold text-white">{b.title}</span>
                        {b.pinned && <Pin className="w-3.5 h-3.5 text-amber-400" />}
                      </div>

                      <span className={b.active ? 'text-emerald-400' : 'text-slate-500'}>
                        {b.active ? 'فعال' : 'متوقف'}
                      </span>
                    </div>

                    <p className="text-slate-300 leading-relaxed">{b.body}</p>

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-1 text-[11px] text-slate-500">
                      <span className="font-mono-num" dir="ltr">
                        {formatDateTimeShort(b.createdAt)}
                      </span>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => void onToggleBroadcast(b.id, !b.active, b.pinned)}
                          className="px-2.5 py-1 rounded bg-slate-900 border border-slate-700 hover:border-cyan-500/50 text-slate-200"
                        >
                          {b.active ? 'توقف نمایش' : 'فعال‌سازی'}
                        </button>
                        <button
                          type="button"
                          onClick={() => void onDeleteBroadcast(b.id)}
                          className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-300"
                        >
                          <Trash2 className="w-3 h-3" />
                          <span>حذف</span>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>

          {/* Direct 1-to-1 Messaging */}
          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-800 bg-[#060A14] flex items-center gap-2">
              <Mail className="w-4 h-4 text-cyan-400" />
              <h2 className="text-sm font-semibold text-white">
                ارسال پیام تکی و اختصاصی به یک کاربر
              </h2>
            </div>

            <form
              onSubmit={(e) => void handleSendDm(e)}
              className="p-5 space-y-3 text-xs border-b border-slate-800"
            >
              <div>
                <label className="block text-slate-400 mb-1">انتخاب کاربر گیرنده</label>
                <select
                  value={dmTargetUserId}
                  onChange={(e) => setDmTargetUserId(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                >
                  <option value="">-- کاربر مورد نظر را انتخاب کنید --</option>
                  {users.map((u) => (
                    <option key={u.uid} value={u.uid}>
                      {u.displayName} ({u.email || u.uid})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] text-slate-500 mb-1">
                  یا وارد کردن دستی UID کاربر (در صورت انتخاب از لیست خالی بگذارید)
                </label>
                <input
                  type="text"
                  value={dmCustomUid}
                  onChange={(e) => setDmCustomUid(e.target.value)}
                  placeholder="Firebase UID (اختیاری)"
                  dir="ltr"
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">موضوع پیام تکی</label>
                <input
                  type="text"
                  value={dmSubject}
                  onChange={(e) => setDmSubject(e.target.value)}
                  placeholder="مثلاً: تایید حساب / راهنمایی واریز / هدیه اشتراک"
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">متن پیام اختصاصی</label>
                <textarea
                  rows={3}
                  value={dmBody}
                  onChange={(e) => setDmBody(e.target.value)}
                  placeholder="متن پیام فقط در صندوق پیام همین کاربر نمایش داده می‌شود..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1">اولویت پیام</label>
                <div className="grid grid-cols-4 gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
                  {SEVERITY_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      type="button"
                      onClick={() => setDmSeverity(opt.value)}
                      className={`py-1 rounded text-[11px] font-medium transition-colors ${
                        dmSeverity === opt.value
                          ? 'bg-cyan-500 text-slate-950 font-semibold'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              <button
                type="submit"
                disabled={
                  sendingDm ||
                  !(dmCustomUid.trim() || dmTargetUserId.trim()) ||
                  !dmSubject.trim() ||
                  !dmBody.trim()
                }
                className="w-full inline-flex items-center justify-center gap-1.5 py-2.5 px-4 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold transition-colors disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                <span>{sendingDm ? 'در حال ارسال...' : 'ارسال پیام به کاربر انتخاب‌شده'}</span>
              </button>
            </form>

            {/* Sent Direct Messages */}
            {directMessages.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-500">
                هنوز پیام تکی برای کاربری ارسال نشده است.
              </div>
            ) : (
              <div className="divide-y divide-slate-800/80 max-h-96 overflow-y-auto text-xs">
                {directMessages.map((dm) => (
                  <div key={dm.id} className="p-4 space-y-2">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <span className="font-semibold text-white">{dm.subject}</span>
                        <div className="text-[11px] text-slate-400 font-mono-num" dir="ltr">
                          به: {dm.targetUserName} ({dm.targetUserEmail || dm.targetUserId})
                        </div>
                      </div>
                      <span
                        className={dm.readByUser ? 'text-emerald-400' : 'text-amber-300'}
                      >
                        {dm.readByUser ? 'خوانده شده' : 'در انتظار مشاهده'}
                      </span>
                    </div>

                    <p className="text-slate-300 leading-relaxed">{dm.body}</p>

                    <div className="flex items-center justify-between pt-1 text-[11px] text-slate-500">
                      <span className="font-mono-num" dir="ltr">
                        {formatDateTimeShort(dm.createdAt)}
                        {dm.readAt ? ` · مطالعه: ${formatDateTimeShort(dm.readAt)}` : ''}
                      </span>
                      <button
                        type="button"
                        onClick={() => void onDeleteDirectMessage(dm.id)}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-rose-500/15 hover:bg-rose-500/25 text-rose-300"
                      >
                        <Trash2 className="w-3 h-3" />
                        <span>حذف</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {/* TAB 4: BILLING, CRYPTO WALLETS, ZARINPAL & RECEIPTS */}
      {activeTab === 'BILLING' && (
        <div className="space-y-5">
          <form
            onSubmit={(e) => void handleSaveBilling(e)}
            className="grid grid-cols-1 lg:grid-cols-2 gap-5"
          >
            {/* Dollar Wallet & Pricing */}
            <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 space-y-4">
              <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                <Wallet className="w-4 h-4 text-cyan-400" />
                <h2 className="text-sm font-semibold text-white">
                  تنظیمات کیف پول دلاری (USDT) و مبلغ اشتراک
                </h2>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="block text-slate-400 mb-1">مبلغ ماهانه (تومان)</label>
                  <NumericInput
                    allowDecimal={false}
                    value={priceTomanStr}
                    onValueChange={setPriceTomanStr}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 mb-1">مبلغ دلاری ثابت (USDT)</label>
                  <NumericInput
                    disabled={autoUsdt}
                    value={priceUsdtStr}
                    onValueChange={setPriceUsdtStr}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-cyan-300 disabled:opacity-45 focus:outline-none focus:border-cyan-400"
                  />
                </div>
              </div>

              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={autoUsdt}
                  onChange={(e) => setAutoUsdt(e.target.checked)}
                  className="accent-cyan-500"
                />
                <span>
                  محاسبه خودکار مبلغ تتر (USDT) معادل{' '}
                  {formatToman(Number(priceTomanStr) || 950000)} تومان با نرخ لحظه‌ای نوبیتکس
                </span>
              </label>

              <div className="pt-2 border-t border-slate-800/80 space-y-3 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">شبکه کیف پول اول</label>
                    <input
                      type="text"
                      value={net1}
                      onChange={(e) => setNet1(e.target.value)}
                      placeholder="TRC20"
                      dir="ltr"
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 font-mono-num text-white"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] text-slate-400 mb-1">
                      آدرس کیف پول دلاری اول (نمایش به کاربران)
                    </label>
                    <input
                      type="text"
                      value={wallet1}
                      onChange={(e) => setWallet1(e.target.value)}
                      placeholder="آدرس والت TRC20 یا BEP20 خود را وارد کنید"
                      dir="ltr"
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 font-mono-num text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <div>
                    <label className="block text-[11px] text-slate-400 mb-1">
                      شبکه کیف پول دوم (اختیاری)
                    </label>
                    <input
                      type="text"
                      value={net2}
                      onChange={(e) => setNet2(e.target.value)}
                      placeholder="BEP20"
                      dir="ltr"
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 font-mono-num text-white"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-[11px] text-slate-400 mb-1">
                      آدرس کیف پول دلاری دوم (اختیاری)
                    </label>
                    <input
                      type="text"
                      value={wallet2}
                      onChange={(e) => setWallet2(e.target.value)}
                      placeholder="آدرس جایگزین مثلاً شبکه BEP20 یا TON"
                      dir="ltr"
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 font-mono-num text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>
              </div>
            </section>

            {/* ZarinPal Gateway Settings */}
            <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 space-y-4 flex flex-col justify-between">
              <div className="space-y-4">
                <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-amber-400" />
                    <h2 className="text-sm font-semibold text-white">
                      اتصال درگاه زرین‌پال (ZarinPal)
                    </h2>
                  </div>
                  <span
                    className={`text-[11px] font-medium ${
                      overview?.config.zarinpalEnabled ? 'text-emerald-400' : 'text-amber-300'
                    }`}
                  >
                    {overview?.config.zarinpalEnabled ? 'متصل' : 'آماده اتصال'}
                  </span>
                </div>

                <div className="text-xs text-slate-300 leading-relaxed bg-slate-950 border border-slate-800 rounded-lg p-3">
                  هر زمان درگاه زرین‌پال را روی دامنه خود دریافت کردید، کد پذیرنده ۳۶ کاراکتری (Merchant ID) را اینجا وارد و ذخیره کنید تا پرداخت کارت بانکی شتاب به‌صورت خودکار فعال شود.
                </div>

                {overview?.config.maskedMerchantId && (
                  <div className="flex items-center justify-between text-xs bg-slate-950 border border-slate-800 rounded-lg px-3 py-2">
                    <span className="text-slate-400">کد پذیرنده ذخیره شده:</span>
                    <div className="flex items-center gap-3">
                      <span className="font-mono-num text-emerald-300" dir="ltr">
                        {overview.config.maskedMerchantId}
                      </span>
                      <button
                        type="button"
                        onClick={() => void handleClearZarinpal()}
                        className="text-rose-400 hover:underline text-[11px]"
                      >
                        حذف
                      </button>
                    </div>
                  </div>
                )}

                <div className="text-xs">
                  <label className="block text-slate-400 mb-1">
                    کد پذیرنده جدید زرین‌پال (Merchant ID)
                  </label>
                  <input
                    type="text"
                    value={merchantIdInput}
                    onChange={(e) => setMerchantIdInput(e.target.value)}
                    placeholder="xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
                    dir="ltr"
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-amber-400"
                  />
                </div>

                <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={sandboxMode}
                    onChange={(e) => setSandboxMode(e.target.checked)}
                    className="accent-amber-500"
                  />
                  <span>
                    استفاده از محیط آزمایشی زرین‌پال (Sandbox) — برای درگاه واقعی تیک را بردارید
                  </span>
                </label>
              </div>

              <button
                type="submit"
                disabled={savingConfig}
                className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors disabled:opacity-50"
              >
                {savingConfig ? 'در حال ذخیره...' : 'ذخیره تنظیمات کیف پول و زرین‌پال'}
              </button>
            </section>
          </form>

          {/* Payment Requests Queue */}
          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-800 bg-[#060A14] flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-sm font-semibold text-white">
                فیش‌های پرداخت اشتراک کاربران ({stats.pendingPayments} در انتظار تایید)
              </h2>
              <span className="text-xs text-slate-400">
                با تایید هر واریز دلاری، اشتراک کاربر ۳۰ روز فعال می‌شود
              </span>
            </div>

            {requests.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                هنوز درخواست پرداختی توسط کاربران ثبت نشده است.
              </div>
            ) : (
              <div className="divide-y divide-slate-800/70">
                {requests.map((req) => (
                  <div
                    key={req.id}
                    className="px-5 py-3.5 flex flex-wrap items-center justify-between gap-3 text-xs"
                  >
                    <div className="space-y-1 min-w-0">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-semibold text-white">{req.userDisplayName}</span>
                        <span className="font-mono-num text-slate-400" dir="ltr">
                          ({req.userEmail || req.userId})
                        </span>
                        <span className="font-mono-num text-amber-300 font-semibold" dir="ltr">
                          {req.method === 'USDT'
                            ? `$${formatPrice(req.amountUsdt)} USDT (${req.network || 'USDT'})`
                            : `${formatToman(req.amountToman)} تومان (زرین‌پال)`}
                        </span>
                      </div>
                      {(req.txHash || req.authority) && (
                        <div className="text-[11px] font-mono-num text-cyan-300 break-all" dir="ltr">
                          TXID / Ref: {req.txHash || req.authority}
                        </div>
                      )}
                      {req.note && (
                        <div className="text-[11px] text-slate-400">یادداشت: {req.note}</div>
                      )}
                      <div className="text-[11px] font-mono-num text-slate-500" dir="ltr">
                        {formatDateTimeShort(req.createdAt)} · UID: {req.userId}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {req.status === 'PENDING' ? (
                        <>
                          <button
                            type="button"
                            disabled={busyActionId === req.id}
                            onClick={() => void handleReview(req.id, 'APPROVE')}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors whitespace-nowrap"
                          >
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>تایید و فعال‌سازی ۳۰ روز</span>
                          </button>
                          <button
                            type="button"
                            disabled={busyActionId === req.id}
                            onClick={() => void handleReview(req.id, 'REJECT')}
                            className="inline-flex items-center gap-1 px-3 py-1.5 rounded-md text-xs font-medium bg-rose-500/15 border border-rose-500/40 hover:bg-rose-500/25 text-rose-300 transition-colors whitespace-nowrap"
                          >
                            <XCircle className="w-3.5 h-3.5" />
                            <span>رد</span>
                          </button>
                        </>
                      ) : (
                        <span
                          className={`text-xs font-medium ${
                            req.status === 'APPROVED' ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {req.status === 'APPROVED' ? 'تایید شده' : 'رد شده'}
                        </span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}

      {/* TAB 5: APP CONTROL, FEATURE POLICIES & SYSTEM BOTS */}
      {activeTab === 'APP_CONTROL' && (
        <div className="space-y-5">
          <form onSubmit={(e) => void handleSaveAppControlForm(e)} className="space-y-5">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
              {/* Maintenance & Promo Free Mode */}
              <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 space-y-4">
                <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                  <Lock className="w-4 h-4 text-rose-400" />
                  <h2 className="text-sm font-semibold text-white">
                    حالت تعمیرات، جشنواره رایگان و پشتیبانی
                  </h2>
                </div>

                <div className="space-y-4 text-xs">
                  <label className="flex items-center justify-between gap-3 bg-slate-950 border border-slate-800 rounded-lg p-3 cursor-pointer">
                    <div>
                      <div className="font-semibold text-white">فعال‌سازی حالت تعمیرات (Maintenance Mode)</div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        کاربران صفحه اطلاع‌رسانی تعمیرات می‌بینند (حساب مدیر بدون محدودیت باز می‌ماند)
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={maintenanceMode}
                      onChange={(e) => setMaintenanceMode(e.target.checked)}
                      className="accent-rose-500 w-4 h-4 shrink-0"
                    />
                  </label>

                  <div>
                    <label className="block text-slate-400 mb-1">پیام صفحه تعمیرات</label>
                    <textarea
                      rows={2}
                      value={maintenanceMessage}
                      onChange={(e) => setMaintenanceMessage(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <label className="flex items-center justify-between gap-3 bg-slate-950 border border-slate-800 rounded-lg p-3 cursor-pointer">
                    <div>
                      <div className="font-semibold text-emerald-300">
                        باز کردن رایگان تمام امکانات حرفه‌ای (جشنواره موقت)
                      </div>
                      <div className="text-[11px] text-slate-400 mt-0.5">
                        با تیک زدن، همه کاربران حتی بدون اشتراک به تمام بخش‌های غیرمسدود دسترسی دارند
                      </div>
                    </div>
                    <input
                      type="checkbox"
                      checked={promoFreeAccess}
                      onChange={(e) => setPromoFreeAccess(e.target.checked)}
                      className="accent-emerald-500 w-4 h-4 shrink-0"
                    />
                  </label>

                  <div>
                    <label className="block text-slate-400 mb-1">متن بنر جشنواره رایگان</label>
                    <input
                      type="text"
                      value={promoBannerText}
                      onChange={(e) => setPromoBannerText(e.target.value)}
                      placeholder="مثلاً: دسترسی رایگان جشنواره تا پایان هفته برای همه کاربران باز شد!"
                      className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-slate-400 mb-1">شماره تماس پشتیبانی</label>
                      <input
                        type="text"
                        value={supportPhone}
                        onChange={(e) => setSupportPhone(e.target.value)}
                        dir="ltr"
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 font-mono-num text-white focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-400 mb-1">آیدی تلگرام پشتیبانی (اختیاری)</label>
                      <input
                        type="text"
                        value={supportTelegram}
                        onChange={(e) => setSupportTelegram(e.target.value)}
                        placeholder="@admin_support"
                        dir="ltr"
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 font-mono-num text-white placeholder:text-slate-600 focus:outline-none focus:border-cyan-400"
                      />
                    </div>
                  </div>
                </div>
              </section>

              {/* Feature Access Policies */}
              <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-5 space-y-4 flex flex-col justify-between">
                <div className="space-y-3">
                  <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
                    <Sliders className="w-4 h-4 text-cyan-400" />
                    <h2 className="text-sm font-semibold text-white">
                      ماتریس سطح دسترسی امکانات (رایگان / اشتراک / غیرفعال)
                    </h2>
                  </div>

                  <div className="divide-y divide-slate-800/80 border border-slate-800 rounded-lg bg-slate-950 overflow-hidden text-xs">
                    {FEATURE_LABELS.map((feat) => {
                      const current = featurePolicies[feat.key];
                      return (
                        <div
                          key={feat.key}
                          className="p-3 flex flex-wrap items-center justify-between gap-2"
                        >
                          <div>
                            <div className="font-medium text-white">{feat.label}</div>
                            <div className="text-[11px] text-slate-500">{feat.desc}</div>
                          </div>

                          <div className="flex items-center gap-1 bg-[#0A101D] p-1 rounded border border-slate-800 shrink-0">
                            {POLICY_OPTIONS.map((opt) => (
                              <button
                                key={opt.value}
                                type="button"
                                onClick={() =>
                                  setFeaturePolicies((prev) => ({
                                    ...prev,
                                    [feat.key]: opt.value,
                                  }))
                                }
                                className={`px-2 py-1 rounded text-[11px] font-medium transition-colors whitespace-nowrap ${
                                  current === opt.value
                                    ? opt.value === 'FREE'
                                      ? 'bg-emerald-500 text-slate-950 font-semibold'
                                      : opt.value === 'PRO'
                                        ? 'bg-cyan-500 text-slate-950 font-semibold'
                                        : 'bg-rose-500 text-white font-semibold'
                                    : 'text-slate-400 hover:text-white'
                                }`}
                              >
                                {opt.label}
                              </button>
                            ))}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={savingAppControl}
                  className="w-full py-2.5 px-4 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors disabled:opacity-50"
                >
                  {savingAppControl ? 'در حال ذخیره...' : 'ذخیره تنظیمات کلی برنامه و امکانات'}
                </button>
              </section>
            </div>
          </form>

          {/* System Trading Bots Monitor & Emergency Stop */}
          <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden">
            <div className="px-5 py-3.5 border-b border-slate-800 bg-[#060A14] flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Bot className="w-4 h-4 text-amber-400" />
                <h2 className="text-sm font-semibold text-white">
                  نظارت بر تمام ربات‌های معامله‌گر پلتفرم ({systemBots.length} ربات)
                </h2>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs text-slate-400">
                  امکان توقف اضطراری یا شروع مجدد هر ربات توسط مدیر
                </span>
                {onGlobalEmergencyStopBots && (
                  <button
                    type="button"
                    disabled={busyActionId === 'global-emergency-stop'}
                    onClick={async () => {
                      setBusyActionId('global-emergency-stop');
                      try {
                        const res = await onGlobalEmergencyStopBots();
                        setFeedback({
                          type: 'ok',
                          text: `توقف اضطراری انجام شد (${res.stoppedCount} ربات فعال متوقف شد).`,
                        });
                      } catch (err) {
                        setFeedback({
                          type: 'err',
                          text:
                            err instanceof Error
                              ? err.message
                              : 'خطا در توقف اضطراری همه ربات‌ها',
                        });
                      } finally {
                        setBusyActionId(null);
                      }
                    }}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-rose-500/20 hover:bg-rose-500/30 border border-rose-500/40 text-rose-200 transition-colors whitespace-nowrap disabled:opacity-50"
                  >
                    <Pause className="w-3.5 h-3.5" />
                    <span>
                      {busyActionId === 'global-emergency-stop'
                        ? 'در حال توقف...'
                        : 'توقف اضطراری همه ربات‌ها'}
                    </span>
                  </button>
                )}
              </div>
            </div>

            {systemBots.length === 0 ? (
              <div className="p-8 text-center text-xs text-slate-500">
                در حال حاضر رباتی روی سیستم ساخته نشده است.
              </div>
            ) : (
              <div className="divide-y divide-slate-800/70 text-xs">
                {systemBots.map((bot) => (
                  <div
                    key={bot.id}
                    className="px-5 py-3.5 flex flex-wrap items-center justify-between gap-3"
                  >
                    <div className="space-y-0.5">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-semibold text-white">{bot.name}</span>
                        <span className="font-mono-num text-cyan-300" dir="ltr">
                          {bot.symbol} · {bot.timeframe}
                        </span>
                        <span
                          className={
                            bot.mode === 'live' ? 'text-amber-300 font-medium' : 'text-slate-400'
                          }
                        >
                          ({bot.mode === 'live' ? 'حساب واقعی' : 'حالت تمرینی'})
                        </span>
                      </div>
                      <div className="text-[11px] font-mono-num text-slate-500" dir="ltr">
                        تعداد معاملات: {bot.stats.totalTrades} · سود/زیان کل:{' '}
                        {bot.quoteCurrency === 'IRT'
                          ? `${formatToman(bot.stats.realizedPnl)} ت`
                          : `$${formatPrice(bot.stats.realizedPnl)}`}
                        {bot.ownerId ? ` · Owner: ${bot.ownerId.slice(0, 10)}...` : ''}
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <span
                        className={
                          bot.status === 'RUNNING'
                            ? 'text-emerald-400 font-medium'
                            : 'text-amber-300 font-medium'
                        }
                      >
                        {bot.status === 'RUNNING' ? 'در حال اجرا' : 'متوقف'}
                      </span>

                      <button
                        type="button"
                        disabled={busyActionId === `bot-${bot.id}`}
                        onClick={async () => {
                          setBusyActionId(`bot-${bot.id}`);
                          try {
                            await onToggleSystemBotStatus(
                              bot.id,
                              bot.status === 'RUNNING' ? 'PAUSED' : 'RUNNING'
                            );
                            setFeedback({
                              type: 'ok',
                              text:
                                bot.status === 'RUNNING'
                                  ? `ربات ${bot.name} متوقف شد.`
                                  : `ربات ${bot.name} فعال شد.`,
                            });
                          } finally {
                            setBusyActionId(null);
                          }
                        }}
                        className={`inline-flex items-center gap-1 px-3 py-1.5 rounded font-medium transition-colors whitespace-nowrap ${
                          bot.status === 'RUNNING'
                            ? 'bg-rose-500/15 hover:bg-rose-500/25 text-rose-300'
                            : 'bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300'
                        }`}
                      >
                        {bot.status === 'RUNNING' ? (
                          <>
                            <Pause className="w-3.5 h-3.5" />
                            <span>توقف اضطراری</span>
                          </>
                        ) : (
                          <>
                            <Play className="w-3.5 h-3.5" />
                            <span>اجرا</span>
                          </>
                        )}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
};
