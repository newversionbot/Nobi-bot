import React, { useMemo, useState } from 'react';
import {
  Activity,
  FlaskConical,
  Hand,
  Layers,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Shield,
  Trash2,
} from 'lucide-react';
import type {
  BacktestResult,
  BotExecutionConfirmationMode,
  DcaBotConfig,
  DcaStepUnit,
  DcaTriggerMode,
  ExecutionMode,
  PendingBotConfirmation,
  QuoteCurrency,
  SharedBotRiskSettings,
  SpotBalance,
  TakeProfitTarget,
  UnifiedMarketTicker,
} from '../types/trading';
import { formatDateTimeShort, formatQuoteAmount, formatQuotePrice } from '../utils/format';
import { CoinSearchSelect } from './CoinSearchSelect';
import { NumericInput } from './NumericInput';
import {
  BotPageShell,
  ExecutionEnvironmentSelector,
  StopBotSafetyModal,
  type DedicatedBotTabId,
} from './BotPageShell';
import type { GuideBotTopic } from './BotEducationModal';

interface DcaBotPageProps {
  defaultBaseAsset: string;
  defaultQuoteCurrency: QuoteCurrency;
  markets: UnifiedMarketTicker[];
  balances: SpotBalance[];
  hasExchangeKeys: boolean;
  isAuthenticated: boolean;
  riskSettings: SharedBotRiskSettings;
  dcaBots: DcaBotConfig[];
  pendingConfirmations: PendingBotConfirmation[];
  onBack: () => void;
  onOpenGuide: (topic: GuideBotTopic) => void;
  onRequireAuth: () => void;
  onCreateDcaBot: (payload: Record<string, unknown>) => Promise<void>;
  onUpdateDcaBot: (botId: string, payload: Record<string, unknown>) => Promise<void>;
  onStartDcaBot: (botId: string, confirmLive?: boolean) => Promise<void>;
  onStopDcaBot: (botId: string) => Promise<void>;
  onEvaluateDcaBot: (botId: string) => Promise<void>;
  onDeleteDcaBot: (botId: string) => Promise<void>;
  onRunBacktest: (payload: Record<string, unknown>) => Promise<BacktestResult>;
  onResolveConfirmation: (conf: PendingBotConfirmation, decision: 'APPROVE' | 'REJECT') => Promise<void>;
}

export const DcaBotPage: React.FC<DcaBotPageProps> = ({
  defaultBaseAsset,
  defaultQuoteCurrency,
  markets,
  balances,
  hasExchangeKeys,
  isAuthenticated,
  riskSettings,
  dcaBots,
  pendingConfirmations,
  onBack,
  onOpenGuide,
  onRequireAuth,
  onCreateDcaBot,
  onUpdateDcaBot,
  onStartDcaBot,
  onStopDcaBot,
  onEvaluateDcaBot,
  onDeleteDcaBot,
  onRunBacktest,
  onResolveConfirmation,
}) => {
  const [activeTab, setActiveTab] = useState<DedicatedBotTabId>('OVERVIEW');
  const [baseAsset, setBaseAsset] = useState(defaultBaseAsset || 'ETH');
  const [quoteCurrency, setQuoteCurrency] = useState<QuoteCurrency>(defaultQuoteCurrency);
  const [name, setName] = useState('');
  const [totalCapital, setTotalCapital] = useState(quoteCurrency === 'IRT' ? 25_000_000 : 400);
  const [totalStages, setTotalStages] = useState(5);
  const [stepUnit, setStepUnit] = useState<DcaStepUnit>('PERCENT');
  const [stepValue, setStepValue] = useState(2.5);
  const [triggerMode, setTriggerMode] = useState<DcaTriggerMode>('MARKET_DROP');
  const [intervalMinutes, setIntervalMinutes] = useState(180);
  const [stopLossPercent, setStopLossPercent] = useState(8);
  const [takeProfitTargets, setTakeProfitTargets] = useState<TakeProfitTarget[]>([
    { id: 'tp-1', risePercent: 3.5, sellPercent: 50 },
    { id: 'tp-2', risePercent: 7.5, sellPercent: 50 },
  ]);
  const [trailingTpEnabled, setTrailingTpEnabled] = useState(true);
  const [trailingTpActivation, setTrailingTpActivation] = useState(4);
  const [trailingTpCallback, setTrailingTpCallback] = useState(1.2);
  const [keepRunnerPercent, setKeepRunnerPercent] = useState(10);
  const [executionMode, setExecutionMode] = useState<ExecutionMode>('paper');
  const [confirmationMode, setConfirmationMode] = useState<BotExecutionConfirmationMode>('AUTO');
  const [liveConfirmed, setLiveConfirmed] = useState(false);
  const [notifyTelegram, setNotifyTelegram] = useState(true);
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [backtestBusy, setBacktestBusy] = useState(false);
  const [backtestResult, setBacktestResult] = useState<BacktestResult | null>(null);
  const [stopTarget, setStopTarget] = useState<DcaBotConfig | null>(null);

  const selectedMarket = useMemo(
    () => markets.find((m) => m.baseAsset === baseAsset.toUpperCase()) || null,
    [markets, baseAsset]
  );
  const livePrice = useMemo(() => {
    if (!selectedMarket) return 0;
    return quoteCurrency === 'IRT' ? selectedMarket.priceToman : selectedMarket.priceUsdt;
  }, [selectedMarket, quoteCurrency]);

  const capitalPerStage = totalStages > 0 ? totalCapital / totalStages : totalCapital;
  const freeQuote = balances.find((b) => b.asset === quoteCurrency)?.free ?? 0;
  const activeCount = dcaBots.filter((d) => d.isActive).length;
  const totalNetProfit = dcaBots.reduce((s, d) => s + d.stats.realizedNetProfitQuote, 0);
  const totalInvested = dcaBots.reduce((s, d) => s + d.state.totalInvestedQuote, 0);
  const dcaPendingConfirmations = pendingConfirmations.filter(
    (c) => c.botType === 'DCA' && c.status === 'PENDING'
  );

  const handleSubmit = async (startImmediately: boolean) => {
    if (!isAuthenticated) {
      onRequireAuth();
      return;
    }
    setFeedback(null);
    if (executionMode === 'live' && !liveConfirmed) {
      setFeedback('برای اجرای ربات خرید پله‌ای روی حساب واقعی نوبیتکس، ابتدا تیک تأیید معامله واقعی را بزن.');
      return;
    }
    setBusy(true);
    try {
      await onCreateDcaBot({
        name: name.trim() || `خرید پله‌ای ${baseAsset}/${quoteCurrency === 'IRT' ? 'تومان' : 'تتر'}`,
        baseAsset,
        quoteCurrency,
        mode: executionMode,
        confirmLive: executionMode === 'live' ? liveConfirmed : false,
        startImmediately,
        totalCapital,
        stagesCount: totalStages,
        stepValue,
        stepUnit,
        triggerMode,
        intervalMinutes,
        stopLossPercent,
        takeProfitTargets,
        trailingTakeProfitEnabled: trailingTpEnabled,
        trailingTakeProfitActivationPercent: trailingTpActivation,
        trailingTakeProfitCallbackPercent: trailingTpCallback,
        keepRunnerPercent,
        maxCapitalInvolved: totalCapital,
        executionConfirmationMode: confirmationMode,
        notifyTelegram,
      });
      setFeedback(startImmediately ? 'ربات خرید پله‌ای ساخته و فعال شد!' : 'ربات خرید پله‌ای ذخیره شد.');
      setActiveTab('OVERVIEW');
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'خطا در ایجاد ربات خرید پله‌ای');
    } finally {
      setBusy(false);
    }
  };

  const handleBacktest = async () => {
    setBacktestBusy(true);
    setFeedback(null);
    try {
      const res = await onRunBacktest({
        botType: 'DCA',
        baseAsset,
        quoteCurrency,
        symbol: `${baseAsset}${quoteCurrency}`,
        timeframe: '1h',
        totalCapital,
        totalStages,
        stepValue,
        stepUnit,
        triggerMode,
        stopLossPercent,
        takeProfitTargets,
        trailingTakeProfitEnabled: trailingTpEnabled,
        trailingTakeProfitActivationPercent: trailingTpActivation,
        trailingTakeProfitCallbackPercent: trailingTpCallback,
        keepRunnerPercent,
        estimatedSlippagePercent: 0.15,
      });
      setBacktestResult(res);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'خطا در اجرای بک‌تست ربات پله‌ای');
    } finally {
      setBacktestBusy(false);
    }
  };

  return (
    <BotPageShell
      topic="DCA"
      title="ربات خرید پله‌ای (DCA Bot)"
      subtitle="خرید مرحله‌ای برای کاهش میانگین قیمت و فروش پله‌ای در چند هدف سود"
      icon={<Layers className="w-5 h-5 text-sky-400" />}
      accentGradient="from-sky-400 via-emerald-400 to-cyan-500"
      statusLabel={activeCount > 0 ? `${activeCount} ربات فعال` : 'آماده تنظیم'}
      statusTone={activeCount > 0 ? 'active' : 'paused'}
      kpis={[
        {
          label: 'سود تحقق‌یافته خالص',
          value: `${totalNetProfit >= 0 ? '+' : ''}${formatQuoteAmount(totalNetProfit, quoteCurrency)}`,
          tone: totalNetProfit >= 0 ? 'positive' : 'negative',
        },
        {
          label: 'سرمایه درگیر فعلی',
          value: formatQuoteAmount(totalInvested, quoteCurrency),
          tone: 'accent',
        },
        {
          label: 'مبلغ هر پله خرید',
          value: formatQuoteAmount(capitalPerStage, quoteCurrency),
          subtext: `${totalStages} مرحله · هر افت ${stepValue}${stepUnit === 'PERCENT' ? '٪' : ''}`,
        },
        {
          label: 'موجودی آزاد حساب',
          value: formatQuoteAmount(freeQuote, quoteCurrency),
        },
      ]}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      onBack={onBack}
      onOpenGuide={onOpenGuide}
      pendingConfirmations={dcaPendingConfirmations}
      onApproveConfirmation={(c) => void onResolveConfirmation(c, 'APPROVE')}
      onRejectConfirmation={(c) => void onResolveConfirmation(c, 'REJECT')}
    >
      {feedback && (
        <div className="mb-4 rounded-xl border border-sky-500/35 bg-sky-500/10 px-4 py-3 text-xs text-sky-100 flex items-center justify-between gap-2">
          <span>{feedback}</span>
          <button type="button" onClick={() => setFeedback(null)} className="font-bold text-sky-300">
            بستن
          </button>
        </div>
      )}

      {activeTab === 'OVERVIEW' && (
        <div className="space-y-4">
          {/* Isolated Stair-Step DCA Visualizer */}
          <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-extrabold text-white">پیش‌نمایش پله‌های کاهش میانگین خرید</h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  قیمت لحظه‌ای {baseAsset}:{' '}
                  <span className="font-mono-num text-sky-300 font-bold">
                    {livePrice > 0 ? formatQuotePrice(livePrice, quoteCurrency) : '—'}
                  </span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('SETTINGS')}
                className="min-h-[44px] px-4 rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                ساخت ربات DCA جدید
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
              {Array.from({ length: Math.min(5, totalStages) }, (_, idx) => {
                const stepPrice =
                  livePrice > 0
                    ? stepUnit === 'PERCENT'
                      ? livePrice * Math.pow(1 - stepValue / 100, idx)
                      : Math.max(0, livePrice - stepValue * idx)
                    : 0;
                return (
                  <div key={idx} className="rounded-xl border border-slate-800 bg-slate-900/60 p-2.5 text-center">
                    <div className="text-[10px] text-sky-300 font-bold">پله {idx + 1}</div>
                    <div className="font-mono-num text-xs font-extrabold text-white mt-1">
                      {stepPrice > 0 ? formatQuotePrice(stepPrice, quoteCurrency) : '—'}
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono-num mt-0.5">
                      {formatQuoteAmount(capitalPerStage, quoteCurrency)}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {dcaBots.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-slate-700 bg-[#0A101D] p-8 text-center space-y-2">
              <Layers className="w-10 h-10 text-sky-400/70 mx-auto" />
              <p className="text-sm font-bold text-white">هنوز ربات خرید پله‌ای فعالی نداری</p>
              <p className="text-xs text-slate-400">از تب «تنظیمات» اولین ربات پله‌ای خودت را بساز.</p>
            </div>
          ) : (
            dcaBots.map((bot) => {
              const progressPct = Math.min(
                100,
                Math.round((bot.state.stagesCompleted / Math.max(1, bot.stagesCount)) * 100)
              );
              const unrealizedPct =
                bot.state.avgBuyPrice > 0 && bot.lastPrice > 0
                  ? ((bot.lastPrice - bot.state.avgBuyPrice) / bot.state.avgBuyPrice) * 100
                  : 0;
              return (
                <div key={bot.id} className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 space-y-3">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="flex flex-wrap items-center gap-2">
                        <h4 className="font-extrabold text-white text-sm sm:text-base">{bot.name}</h4>
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                            bot.isActive
                              ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/35'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {bot.isActive ? 'فعال' : 'متوقف'}
                        </span>
                        {bot.pauseNewBuys && (
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold border border-amber-500/40 bg-amber-500/15 text-amber-200">
                            خرید جدید متوقف (مدیریت فروش فعال)
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-400 mt-1">{bot.lastStatusReason}</p>
                    </div>
                    <div className="text-left font-mono-num">
                      <div className="text-[11px] text-slate-400">میانگین خرید / وضعیت لحظه‌ای</div>
                      <div className="text-xs font-extrabold text-white">
                        {bot.state.avgBuyPrice > 0
                          ? formatQuotePrice(bot.state.avgBuyPrice, bot.quoteCurrency)
                          : 'در انتظار اولین پله'}
                        {bot.state.netOwnedQty > 0 && (
                          <span
                            className={`mr-2 ${unrealizedPct >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}
                          >
                            ({unrealizedPct >= 0 ? '+' : ''}
                            {unrealizedPct.toFixed(2)}٪)
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Stage progress */}
                  <div className="space-y-1">
                    <div className="flex items-center justify-between text-[11px] text-slate-400">
                      <span>مراحل خرید انجام‌شده: {bot.state.stagesCompleted} از {bot.stagesCount}</span>
                      <span className="font-mono-num text-sky-300">{progressPct}٪</span>
                    </div>
                    <div className="h-2 rounded-full bg-slate-900 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-l from-sky-400 to-emerald-400"
                        style={{ width: `${progressPct}%` }}
                      />
                    </div>
                  </div>

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {bot.isActive ? (
                      <button
                        type="button"
                        onClick={() => setStopTarget(bot)}
                        className="min-h-[44px] px-4 rounded-xl bg-amber-600/20 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center gap-1.5"
                      >
                        <Pause className="w-4 h-4" />
                        توقف ربات
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => void onStartDcaBot(bot.id, bot.mode === 'live')}
                        className="min-h-[44px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5"
                      >
                        <Play className="w-4 h-4" />
                        شروع ربات
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={() => void onUpdateDcaBot(bot.id, { pauseNewBuys: !bot.pauseNewBuys })}
                      className={`min-h-[44px] px-3.5 rounded-xl border text-xs font-bold ${
                        bot.pauseNewBuys
                          ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-200'
                          : 'border-amber-500/35 bg-amber-500/10 text-amber-200'
                      }`}
                    >
                      {bot.pauseNewBuys ? 'ادامه خریدهای جدید' : 'توقف خریدهای جدید'}
                    </button>

                    <button
                      type="button"
                      onClick={() => void onEvaluateDcaBot(bot.id)}
                      className="min-h-[44px] px-3.5 rounded-xl border border-slate-700 bg-slate-900 text-slate-200 text-xs font-bold flex items-center gap-1.5"
                    >
                      <RefreshCw className="w-4 h-4" />
                      بررسی فوری
                    </button>

                    <button
                      type="button"
                      onClick={() => void onDeleteDcaBot(bot.id)}
                      className="min-h-[44px] px-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-xs font-bold flex items-center gap-1.5 mr-auto"
                    >
                      <Trash2 className="w-4 h-4" />
                      حذف
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      )}

      {activeTab === 'SETTINGS' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">انتخاب ارز دیجیتال</label>
              <CoinSearchSelect
                markets={markets}
                value={baseAsset}
                onChange={setBaseAsset}
                quoteCurrency={quoteCurrency}
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">بازار</label>
              <div className="grid grid-cols-2 gap-2">
                {(['IRT', 'USDT'] as QuoteCurrency[]).map((qc) => (
                  <button
                    key={qc}
                    type="button"
                    onClick={() => {
                      setQuoteCurrency(qc);
                      setTotalCapital(qc === 'IRT' ? 25_000_000 : 400);
                    }}
                    className={`min-h-[44px] rounded-xl border text-xs font-bold ${
                      quoteCurrency === qc
                        ? 'border-sky-400 bg-sky-500/15 text-sky-200'
                        : 'border-slate-700 bg-slate-900 text-slate-400'
                    }`}
                  >
                    {qc === 'IRT' ? 'تومان (IRT)' : 'تتر (USDT)'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">سرمایه کل DCA</label>
              <NumericInput value={totalCapital} onValueChange={(v) => setTotalCapital(Number(v || 0))} />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">تعداد مراحل خرید</label>
              <NumericInput value={totalStages} onValueChange={(v) => setTotalStages(Math.max(2, Math.min(25, Math.round(Number(v || 2)))))} />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">روش تریگر پله‌ها</label>
              <select
                value={triggerMode}
                onChange={(e) => setTriggerMode(e.target.value as DcaTriggerMode)}
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-xs text-white"
              >
                <option value="MARKET_DROP">بر اساس افت قیمت از پله قبل</option>
                <option value="TIME">بر اساس بازه زمانی منظم</option>
                <option value="INDICATOR">بر اساس سیگنال RSI (اشباع فروش)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">فاصله هر پله ({stepUnit === 'PERCENT' ? 'درصد' : quoteCurrency})</label>
              <NumericInput value={stepValue} onValueChange={(v) => setStepValue(Number(v || 0))} />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">واحد فاصله</label>
              <select
                value={stepUnit}
                onChange={(e) => setStepUnit(e.target.value as DcaStepUnit)}
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-xs text-white"
              >
                <option value="PERCENT">درصدی (%)</option>
                <option value="PRICE">مقدار قیمتی ثابت</option>
              </select>
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">حد ضرر کل (٪)</label>
              <NumericInput value={stopLossPercent} onValueChange={(v) => setStopLossPercent(Number(v || 0))} />
            </div>
          </div>

          {/* Staged Multi-TP & Runner & Trailing TP */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-extrabold text-emerald-300">مدیریت هوشمند فروش (فروش پله‌ای + حد سود متحرک)</h4>
              <button
                type="button"
                onClick={() =>
                  setTakeProfitTargets((prev) =>
                    prev.length < 4
                      ? [...prev, { id: `tp-${Date.now()}`, risePercent: 10, sellPercent: 25 }]
                      : prev
                  )
                }
                className="text-[11px] font-bold text-cyan-300 hover:underline"
              >
                + افزودن هدف فروش
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              {takeProfitTargets.map((tp, idx) => (
                <div key={tp.id || idx} className="rounded-lg border border-slate-800 bg-slate-950/60 p-2.5 flex items-center gap-2 text-xs">
                  <span className="text-slate-400 shrink-0">هدف {idx + 1}: +</span>
                  <NumericInput
                    value={tp.risePercent}
                    onValueChange={(v) =>
                      setTakeProfitTargets((prev) =>
                        prev.map((item, i) => (i === idx ? { ...item, risePercent: Number(v || 0) } : item))
                      )
                    }
                  />
                  <span className="text-slate-400 shrink-0">٪ · فروش</span>
                  <NumericInput
                    value={tp.sellPercent}
                    onValueChange={(v) =>
                      setTakeProfitTargets((prev) =>
                        prev.map((item, i) => (i === idx ? { ...item, sellPercent: Number(v || 0) } : item))
                      )
                    }
                  />
                  <span className="text-slate-400">٪</span>
                </div>
              ))}
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1 text-xs">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={trailingTpEnabled}
                  onChange={(e) => setTrailingTpEnabled(e.target.checked)}
                  className="w-4 h-4 accent-emerald-500"
                />
                <span>حد سود متحرک (Trailing TP)</span>
              </label>
              <div className="flex items-center gap-2">
                <span className="text-slate-400 shrink-0">فعالسازی بعد از +٪:</span>
                <NumericInput value={trailingTpActivation} onValueChange={(v) => setTrailingTpActivation(Number(v || 0))} />
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-400 shrink-0">نگهداری برای ادامه روند ٪:</span>
                <NumericInput value={keepRunnerPercent} onValueChange={(v) => setKeepRunnerPercent(Math.min(50, Math.max(0, Number(v || 0))))} />
              </div>
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs text-slate-300">بک‌تست پله‌ای روی کندل‌های واقعی نوبیتکس (با کارمزد و لغزش)</span>
              <button
                type="button"
                disabled={backtestBusy}
                onClick={() => void handleBacktest()}
                className="min-h-[44px] px-4 rounded-xl border border-cyan-500/40 bg-cyan-500/10 text-cyan-200 text-xs font-bold flex items-center gap-1.5"
              >
                <FlaskConical className="w-4 h-4" />
                {backtestBusy ? 'در حال محاسبه...' : 'اجرای بک‌تست DCA'}
              </button>
            </div>
            {backtestResult && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800 text-xs">
                <div>بازده خالص: <strong className="font-mono-num text-emerald-300">{backtestResult.netProfitPercent}٪</strong></div>
                <div>چرخه‌ها: <strong className="font-mono-num text-white">{backtestResult.totalTrades}</strong></div>
                <div>کارمزد: <strong className="font-mono-num text-amber-300">{formatQuoteAmount(backtestResult.totalFeesPaidQuote || 0, quoteCurrency)}</strong></div>
                <div>افت سرمایه (DD): <strong className="font-mono-num text-rose-300">{backtestResult.maxDrawdownPercent}٪</strong></div>
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
            <button
              type="button"
              disabled={busy}
              onClick={() => void handleSubmit(true)}
              className="flex-1 min-h-[48px] rounded-xl bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4" />
              ساخت و شروع فوری ربات DCA
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => void handleSubmit(false)}
              className="min-h-[48px] px-5 rounded-xl border border-slate-700 bg-slate-900 text-white font-bold text-xs"
            >
              ذخیره موقت
            </button>
          </div>
        </div>
      )}

      {activeTab === 'EXECUTION' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <button
              type="button"
              onClick={() => setConfirmationMode('AUTO')}
              className={`min-h-[60px] rounded-xl border p-3.5 text-right ${
                confirmationMode === 'AUTO'
                  ? 'border-sky-400 bg-sky-500/10 text-white'
                  : 'border-slate-800 bg-slate-900/50 text-slate-400'
              }`}
            >
              <div className="text-xs font-extrabold flex items-center gap-2">
                <Activity className="w-4 h-4 text-sky-400" />
                اجرای خودکار
              </div>
              <p className="text-[11px] text-slate-400 mt-1">هر پله طبق شروط و محدودیت بودجه شما خودکار خریداری می‌شود.</p>
            </button>

            <button
              type="button"
              onClick={() => setConfirmationMode('MANUAL_CONFIRM')}
              className={`min-h-[60px] rounded-xl border p-3.5 text-right ${
                confirmationMode === 'MANUAL_CONFIRM'
                  ? 'border-cyan-400 bg-cyan-500/10 text-white'
                  : 'border-slate-800 bg-slate-900/50 text-slate-400'
              }`}
            >
              <div className="text-xs font-extrabold flex items-center gap-2">
                <Hand className="w-4 h-4 text-cyan-400" />
                اجرا با تأیید دستی شما
              </div>
              <p className="text-[11px] text-slate-400 mt-1">قبل از خرید هر پله یا فروش هدف، جزئیات نمایش داده و تأیید گرفته می‌شود.</p>
            </button>
          </div>

          <ExecutionEnvironmentSelector
            executionMode={executionMode}
            hasExchangeKeys={hasExchangeKeys}
            liveConfirmed={liveConfirmed}
            onChangeExecutionMode={setExecutionMode}
            onToggleLiveConfirm={setLiveConfirmed}
          />
        </div>
      )}

      {activeTab === 'HISTORY' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
          <h3 className="text-sm font-extrabold text-white">تاریخچه عملکرد ربات‌های DCA</h3>
          {dcaBots.length === 0 ? (
            <p className="text-xs text-slate-400">موردی ثبت نشده است.</p>
          ) : (
            dcaBots.map((bot) => (
              <div key={bot.id} className="rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 text-xs space-y-1.5">
                <div className="flex justify-between font-bold text-white">
                  <span>{bot.name}</span>
                  <span className="text-slate-400">{formatDateTimeShort(bot.updatedAt)}</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-[11px]">
                  <div>چرخه‌های بسته‌شده: <strong className="font-mono-num text-emerald-300">{bot.stats.completedCycles}</strong></div>
                  <div>سود خالص کل: <strong className="font-mono-num text-cyan-300">{formatQuoteAmount(bot.stats.realizedNetProfitQuote, bot.quoteCurrency)}</strong></div>
                  <div>کارمزدها: <strong className="font-mono-num text-amber-300">{formatQuoteAmount(bot.stats.totalFeesPaidQuote, bot.quoteCurrency)}</strong></div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      <StopBotSafetyModal
        open={Boolean(stopTarget)}
        botName={stopTarget?.name || ''}
        hasOpenPosition={Boolean(stopTarget && stopTarget.state.netOwnedQty > 0)}
        holdingSummary={
          stopTarget && stopTarget.state.netOwnedQty > 0
            ? `مقدار ${stopTarget.state.netOwnedQty.toFixed(6)} ${stopTarget.baseAsset} با میانگین ${formatQuotePrice(
                stopTarget.state.avgBuyPrice,
                stopTarget.quoteCurrency
              )} در کیف پول شما نگهداری می‌شود.`
            : undefined
        }
        onConfirmStopOnly={() => {
          if (stopTarget) void onStopDcaBot(stopTarget.id);
          setStopTarget(null);
        }}
        onCancel={() => setStopTarget(null)}
      />
    </BotPageShell>
  );
};
