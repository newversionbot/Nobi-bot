import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity,
  BarChart3,
  CheckCircle2,
  FlaskConical,
  Grid,
  Hand,
  Pause,
  Play,
  Plus,
  RefreshCw,
  Shield,
  Trash2,
} from 'lucide-react';
import type {
  BacktestResult,
  BotExecutionConfirmationMode,
  ExecutionMode,
  GridBotConfig,
  GridStepMode,
  PendingBotConfirmation,
  QuoteCurrency,
  SharedBotRiskSettings,
  SpotBalance,
  UnifiedMarketTicker,
} from '../types/trading';
import { formatDateTimeShort, formatQuoteAmount, formatQuotePrice } from '../utils/format';
import { getMinimumOrderNotional } from '../utils/profitBotMath';
import { CoinSearchSelect } from './CoinSearchSelect';
import { NumericInput } from './NumericInput';
import {
  BotPageShell,
  ExecutionEnvironmentSelector,
  StopBotSafetyModal,
  type DedicatedBotTabId,
} from './BotPageShell';
import type { GuideBotTopic } from './BotEducationModal';

interface GridBotPageProps {
  defaultBaseAsset: string;
  defaultQuoteCurrency: QuoteCurrency;
  markets: UnifiedMarketTicker[];
  balances: SpotBalance[];
  hasExchangeKeys: boolean;
  isAuthenticated: boolean;
  riskSettings: SharedBotRiskSettings;
  gridBots: GridBotConfig[];
  pendingConfirmations: PendingBotConfirmation[];
  onBack: () => void;
  onOpenGuide: (topic: GuideBotTopic) => void;
  onRequireAuth: () => void;
  onCreateGridBot: (payload: Record<string, unknown>) => Promise<void>;
  onStartGridBot: (botId: string, confirmLive?: boolean) => Promise<void>;
  onStopGridBot: (botId: string) => Promise<void>;
  onEvaluateGridBot: (botId: string) => Promise<void>;
  onDeleteGridBot: (botId: string) => Promise<void>;
  onRunBacktest: (payload: Record<string, unknown>) => Promise<BacktestResult>;
  onResolveConfirmation: (conf: PendingBotConfirmation, decision: 'APPROVE' | 'REJECT') => Promise<void>;
}

export const GridBotPage: React.FC<GridBotPageProps> = ({
  defaultBaseAsset,
  defaultQuoteCurrency,
  markets,
  balances,
  hasExchangeKeys,
  isAuthenticated,
  riskSettings,
  gridBots,
  pendingConfirmations,
  onBack,
  onOpenGuide,
  onRequireAuth,
  onCreateGridBot,
  onStartGridBot,
  onStopGridBot,
  onEvaluateGridBot,
  onDeleteGridBot,
  onRunBacktest,
  onResolveConfirmation,
}) => {
  const [activeTab, setActiveTab] = useState<DedicatedBotTabId>('OVERVIEW');
  const [baseAsset, setBaseAsset] = useState(defaultBaseAsset || 'TON');
  const [quoteCurrency, setQuoteCurrency] = useState<QuoteCurrency>(defaultQuoteCurrency);
  const [name, setName] = useState('');
  const [lowerPrice, setLowerPrice] = useState(0);
  const [upperPrice, setUpperPrice] = useState(0);
  const [gridLevels, setGridLevels] = useState(8);
  const [stepMode, setStepMode] = useState<GridStepMode>('ARITHMETIC');
  const [totalCapital, setTotalCapital] = useState(
    quoteCurrency === 'IRT' ? 12_000_000 : 180
  );
  const [stopOnBreakout, setStopOnBreakout] = useState(true);
  const [alertOnBreakout, setAlertOnBreakout] = useState(true);
  const [executionMode, setExecutionMode] = useState<ExecutionMode>('paper');
  const [confirmationMode, setConfirmationMode] = useState<BotExecutionConfirmationMode>('AUTO');
  const [liveConfirmed, setLiveConfirmed] = useState(false);
  const [notifyTelegram, setNotifyTelegram] = useState(true);
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [backtestBusy, setBacktestBusy] = useState(false);
  const [backtestResult, setBacktestResult] = useState<BacktestResult | null>(null);
  const [stopTarget, setStopTarget] = useState<GridBotConfig | null>(null);

  const selectedMarket = useMemo(
    () => markets.find((m) => m.baseAsset === baseAsset.toUpperCase()) || null,
    [markets, baseAsset]
  );

  const livePrice = useMemo(() => {
    if (!selectedMarket) return 0;
    return quoteCurrency === 'IRT' ? selectedMarket.priceToman : selectedMarket.priceUsdt;
  }, [selectedMarket, quoteCurrency]);

  useEffect(() => {
    if (livePrice > 0 && (lowerPrice <= 0 || upperPrice <= lowerPrice)) {
      const decimals = livePrice >= 1000 ? 0 : livePrice >= 10 ? 2 : 4;
      setLowerPrice(Number((livePrice * 0.94).toFixed(decimals)));
      setUpperPrice(Number((livePrice * 1.06).toFixed(decimals)));
    }
  }, [livePrice, baseAsset, quoteCurrency]);

  const previewLevels = useMemo(() => {
    if (!(lowerPrice > 0) || !(upperPrice > lowerPrice) || gridLevels < 3) return [];
    const prices: number[] = [];
    for (let i = 0; i < gridLevels; i += 1) {
      if (stepMode === 'GEOMETRIC') {
        const ratio = Math.pow(upperPrice / lowerPrice, i / (gridLevels - 1));
        prices.push(lowerPrice * ratio);
      } else {
        prices.push(lowerPrice + ((upperPrice - lowerPrice) * i) / (gridLevels - 1));
      }
    }
    return prices;
  }, [lowerPrice, upperPrice, gridLevels, stepMode]);

  const profitPerCyclePct = useMemo(() => {
    if (previewLevels.length < 2 || previewLevels[0] <= 0) return 0;
    const grossPct = ((previewLevels[1] - previewLevels[0]) / previewLevels[0]) * 100;
    return grossPct - 0.5; // round-trip 0.25% buy + 0.25% sell fees
  }, [previewLevels]);

  const capitalPerLevel = gridLevels > 1 ? totalCapital / (gridLevels - 1) : totalCapital;
  const freeQuote = balances.find((b) => b.asset === quoteCurrency)?.free ?? 0;
  const activeGridCount = gridBots.filter((g) => g.isActive).length;
  const totalNetProfit = gridBots.reduce((s, g) => s + g.stats.totalNetProfitQuote, 0);
  const totalCycles = gridBots.reduce((s, g) => s + g.stats.completedCycles, 0);
  const gridPendingConfirmations = pendingConfirmations.filter(
    (c) => c.botType === 'GRID' && c.status === 'PENDING'
  );

  const handleApplyAutoRange = (pct: number) => {
    if (livePrice <= 0) return;
    const decimals = livePrice >= 1000 ? 0 : livePrice >= 10 ? 2 : 4;
    setLowerPrice(Number((livePrice * (1 - pct / 100)).toFixed(decimals)));
    setUpperPrice(Number((livePrice * (1 + pct / 100)).toFixed(decimals)));
  };

  const handleSubmit = async (startImmediately: boolean) => {
    if (!isAuthenticated) {
      onRequireAuth();
      return;
    }
    setFeedback(null);
    if (executionMode === 'live' && !liveConfirmed) {
      setFeedback('برای فعال‌سازی ربات گرید روی حساب واقعی نوبیتکس، ابتدا تیک تأیید معامله واقعی را بزن.');
      return;
    }
    const minNotional = getMinimumOrderNotional(quoteCurrency);
    if (capitalPerLevel + 1e-6 < minNotional) {
      setFeedback(
        `سرمایه هر پله (${formatQuoteAmount(capitalPerLevel, quoteCurrency)}) از حداقل سفارش نوبیتکس کمتر است. سرمایه کل را افزایش بده یا تعداد پله‌ها را کمتر کن.`
      );
      return;
    }
    setBusy(true);
    try {
      await onCreateGridBot({
        name: name.trim() || `گرید ${baseAsset}/${quoteCurrency === 'IRT' ? 'تومان' : 'تتر'}`,
        baseAsset,
        quoteCurrency,
        mode: executionMode,
        confirmLive: executionMode === 'live' ? liveConfirmed : false,
        startImmediately,
        lowerPrice,
        upperPrice,
        gridLevels,
        stepMode,
        totalCapital,
        maxCapitalInvolved: totalCapital,
        stopOnBreakout,
        alertOnBreakout,
        executionConfirmationMode: confirmationMode,
        notifyTelegram,
      });
      setFeedback(startImmediately ? 'ربات گرید با موفقیت ساخته و فعال شد!' : 'ربات گرید ذخیره شد و آماده شروع است.');
      setActiveTab('OVERVIEW');
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'خطا در ایجاد ربات گرید');
    } finally {
      setBusy(false);
    }
  };

  const handleBacktest = async () => {
    setBacktestBusy(true);
    setFeedback(null);
    try {
      const res = await onRunBacktest({
        botType: 'GRID',
        baseAsset,
        quoteCurrency,
        symbol: `${baseAsset}${quoteCurrency}`,
        timeframe: '1h',
        lowerPrice,
        upperPrice,
        gridLevels,
        stepMode,
        totalCapital,
        stopOnBreakout,
        estimatedSlippagePercent: 0.15,
      });
      setBacktestResult(res);
    } catch (err) {
      setFeedback(err instanceof Error ? err.message : 'خطا در اجرای بک‌تست گرید');
    } finally {
      setBacktestBusy(false);
    }
  };

  return (
    <BotPageShell
      topic="GRID"
      title="ربات گرید پله‌ای (Grid Bot)"
      subtitle="تقسیم سرمایه بین پله‌های قیمتی · خرید در محدوده پایین و فروش در پله بالاتر"
      icon={<Grid className="w-5 h-5 text-amber-400" />}
      accentGradient="from-amber-400 via-orange-500 to-amber-500"
      statusLabel={activeGridCount > 0 ? `${activeGridCount} ربات فعال` : 'آماده تنظیم'}
      statusTone={activeGridCount > 0 ? 'active' : 'paused'}
      kpis={[
        {
          label: 'سود خالص ثبت‌شده گرید',
          value: `${totalNetProfit >= 0 ? '+' : ''}${formatQuoteAmount(totalNetProfit, quoteCurrency)}`,
          tone: totalNetProfit >= 0 ? 'positive' : 'negative',
        },
        {
          label: 'چرخه‌های تکمیل‌شده',
          value: `${totalCycles.toLocaleString('fa-IR')} چرخه`,
          tone: 'accent',
        },
        {
          label: 'سود تخمینی هر پله (خالص)',
          value: `${profitPerCyclePct >= 0 ? '+' : ''}${profitPerCyclePct.toFixed(2)}٪`,
          subtext: profitPerCyclePct < 0.2 ? 'هشدار: فاصله پله‌ها کم است' : 'پس از کسر کارمزد ۰.۵٪',
          tone: profitPerCyclePct >= 0.3 ? 'positive' : 'negative',
        },
        {
          label: 'سرمایه هر پله',
          value: formatQuoteAmount(capitalPerLevel, quoteCurrency),
          subtext: `موجودی آزاد: ${formatQuoteAmount(freeQuote, quoteCurrency)}`,
        },
      ]}
      activeTab={activeTab}
      onTabChange={setActiveTab}
      onBack={onBack}
      onOpenGuide={onOpenGuide}
      pendingConfirmations={gridPendingConfirmations}
      onApproveConfirmation={(c) => void onResolveConfirmation(c, 'APPROVE')}
      onRejectConfirmation={(c) => void onResolveConfirmation(c, 'REJECT')}
    >
      {feedback && (
        <div className="mb-4 rounded-xl border border-amber-500/35 bg-amber-500/10 px-4 py-3 text-xs text-amber-200 flex items-center justify-between gap-2">
          <span>{feedback}</span>
          <button type="button" onClick={() => setFeedback(null)} className="text-amber-300 font-bold">
            بستن
          </button>
        </div>
      )}

      {activeTab === 'OVERVIEW' && (
        <div className="space-y-4">
          {/* Isolated Grid Ladder Visualizer SVG */}
          <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
                  <BarChart3 className="w-4 h-4 text-amber-400" />
                  نقشه پله‌های قیمتی ({baseAsset}/{quoteCurrency === 'IRT' ? 'تومان' : 'تتر'})
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  قیمت لحظه‌ای:{' '}
                  <span className="font-mono-num text-amber-300 font-bold">
                    {livePrice > 0 ? formatQuotePrice(livePrice, quoteCurrency) : '—'}
                  </span>
                </p>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('SETTINGS')}
                className="min-h-[44px] px-4 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-xs flex items-center gap-1.5"
              >
                <Plus className="w-4 h-4" />
                ساخت ربات گرید جدید
              </button>
            </div>

            {previewLevels.length > 0 && (
              <div className="rounded-xl border border-slate-800/80 bg-slate-950/70 p-3">
                <svg viewBox="0 0 600 180" className="w-full h-44">
                  {previewLevels.map((lvl, idx) => {
                    const ratio = (lvl - lowerPrice) / Math.max(1e-9, upperPrice - lowerPrice);
                    const y = 160 - ratio * 135;
                    const isBuyZone = livePrice > 0 ? lvl <= livePrice : idx < previewLevels.length - 1;
                    return (
                      <g key={idx}>
                        <line
                          x1="75"
                          y1={y}
                          x2="585"
                          y2={y}
                          stroke={isBuyZone ? 'rgba(16,185,129,0.45)' : 'rgba(245,158,11,0.5)'}
                          strokeDasharray="4 4"
                          strokeWidth="1.2"
                        />
                        <text
                          x="68"
                          y={y + 4}
                          textAnchor="end"
                          fill={isBuyZone ? '#6ee7b7' : '#fcd34d'}
                          fontSize="10"
                          fontFamily="monospace"
                        >
                          پله {idx + 1} · {lvl >= 1000 ? Math.round(lvl).toLocaleString('en-US') : lvl.toFixed(2)}
                        </text>
                      </g>
                    );
                  })}
                  {livePrice >= lowerPrice && livePrice <= upperPrice && (
                    <g>
                      {(() => {
                        const yNow = 160 - ((livePrice - lowerPrice) / (upperPrice - lowerPrice)) * 135;
                        return (
                          <>
                            <line x1="75" y1={yNow} x2="585" y2={yNow} stroke="#22d3ee" strokeWidth="2.2" />
                            <circle cx="578" cy={yNow} r="4.5" fill="#22d3ee" />
                          </>
                        );
                      })()}
                    </g>
                  )}
                </svg>
              </div>
            )}
          </div>

          {/* Active & Saved Grid Bots */}
          <div className="space-y-3">
            {gridBots.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-slate-700 bg-[#0A101D] p-8 text-center space-y-3">
                <Grid className="w-10 h-10 text-amber-400/70 mx-auto" />
                <p className="text-sm font-bold text-slate-200">هنوز ربات گریدی نساختی!</p>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  توی تب «تنظیمات» کف و سقف قیمت و تعداد پله‌ها رو مشخص کن و اول روی حساب تمرینی امتحانش کن.
                </p>
              </div>
            ) : (
              gridBots.map((bot) => {
                const holdingLevels = bot.allocatedLevels.filter((l) => l.status === 'HOLDING').length;
                return (
                  <div
                    key={bot.id}
                    className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 space-y-3"
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="font-extrabold text-white text-sm sm:text-base">{bot.name}</h4>
                          <span
                            className={`px-2 py-0.5 rounded-md text-[10px] font-bold border ${
                              bot.isActive
                                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/35'
                                : 'bg-slate-800 text-slate-400 border-slate-700'
                            }`}
                          >
                            {bot.isActive ? 'فعال' : 'متوقف'}
                          </span>
                          <span className="px-2 py-0.5 rounded-md text-[10px] font-bold border border-slate-700 bg-slate-900 text-amber-300">
                            {bot.mode === 'live' ? 'واقعی' : 'تمرینی'}
                          </span>
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{bot.lastStatusReason}</p>
                      </div>
                      <div className="text-left font-mono-num">
                        <div className="text-[11px] text-slate-400">سود خالص کل</div>
                        <div
                          className={`text-sm font-extrabold ${
                            bot.stats.totalNetProfitQuote >= 0 ? 'text-emerald-300' : 'text-rose-300'
                          }`}
                        >
                          {bot.stats.totalNetProfitQuote >= 0 ? '+' : ''}
                          {formatQuoteAmount(bot.stats.totalNetProfitQuote, bot.quoteCurrency)}
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
                      <div className="rounded-lg bg-slate-900/70 border border-slate-800 px-3 py-2">
                        <div className="text-[10px] text-slate-400">بازه قیمت</div>
                        <div className="font-mono-num font-bold text-white mt-0.5">
                          {formatQuotePrice(bot.lowerPrice, bot.quoteCurrency)} تا{' '}
                          {formatQuotePrice(bot.upperPrice, bot.quoteCurrency)}
                        </div>
                      </div>
                      <div className="rounded-lg bg-slate-900/70 border border-slate-800 px-3 py-2">
                        <div className="text-[10px] text-slate-400">پله‌های درگیر</div>
                        <div className="font-mono-num font-bold text-amber-300 mt-0.5">
                          {holdingLevels} از {bot.gridLevels} پله
                        </div>
                      </div>
                      <div className="rounded-lg bg-slate-900/70 border border-slate-800 px-3 py-2">
                        <div className="text-[10px] text-slate-400">سرمایه درگیر فعلی</div>
                        <div className="font-mono-num font-bold text-cyan-200 mt-0.5">
                          {formatQuoteAmount(bot.stats.currentCapitalInvolved, bot.quoteCurrency)}
                        </div>
                      </div>
                      <div className="rounded-lg bg-slate-900/70 border border-slate-800 px-3 py-2">
                        <div className="text-[10px] text-slate-400">نحوه تأیید</div>
                        <div className="font-bold text-slate-200 mt-0.5">
                          {bot.executionConfirmationMode === 'MANUAL_CONFIRM' ? 'تأیید دستی' : 'خودکار'}
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      {bot.isActive ? (
                        <button
                          type="button"
                          onClick={() => setStopTarget(bot)}
                          className="min-h-[44px] px-4 rounded-xl bg-amber-600/20 border border-amber-500/40 text-amber-200 text-xs font-bold flex items-center gap-1.5"
                        >
                          <Pause className="w-4 h-4" />
                          توقف ربات
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => void onStartGridBot(bot.id, bot.mode === 'live')}
                          className="min-h-[44px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5"
                        >
                          <Play className="w-4 h-4" />
                          شروع ربات
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => void onEvaluateGridBot(bot.id)}
                        className="min-h-[44px] px-3.5 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-slate-200 text-xs font-bold flex items-center gap-1.5"
                      >
                        <RefreshCw className="w-4 h-4" />
                        بررسی لحظه‌ای
                      </button>
                      <button
                        type="button"
                        onClick={() => void onDeleteGridBot(bot.id)}
                        className="min-h-[44px] px-3 rounded-xl border border-rose-500/30 bg-rose-500/10 text-rose-300 text-xs font-bold flex items-center gap-1.5 mr-auto"
                      >
                        <Trash2 className="w-4 h-4" />
                        حذف
                      </button>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {activeTab === 'SETTINGS' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">انتخاب ارز دیجیتال</label>
              <CoinSearchSelect
                markets={markets}
                value={baseAsset}
                onChange={setBaseAsset}
                quoteCurrency={quoteCurrency}
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-slate-300">بازار معامله</label>
              <div className="grid grid-cols-2 gap-2">
                {(['IRT', 'USDT'] as QuoteCurrency[]).map((qc) => (
                  <button
                    key={qc}
                    type="button"
                    onClick={() => {
                      setQuoteCurrency(qc);
                      setTotalCapital(qc === 'IRT' ? 12_000_000 : 180);
                    }}
                    className={`min-h-[44px] rounded-xl border text-xs font-bold ${
                      quoteCurrency === qc
                        ? 'border-amber-400 bg-amber-500/15 text-amber-200'
                        : 'border-slate-700 bg-slate-900 text-slate-400'
                    }`}
                  >
                    {qc === 'IRT' ? 'تومانی (IRT)' : 'تتری (USDT)'}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <label className="text-xs font-bold text-slate-300">محدوده نوسان قیمت</label>
              <div className="flex items-center gap-1.5">
                {[4, 8, 12].map((pct) => (
                  <button
                    key={pct}
                    type="button"
                    onClick={() => handleApplyAutoRange(pct)}
                    className="px-2.5 py-1 rounded-lg border border-slate-700 bg-slate-900 hover:border-amber-400/50 text-[11px] text-amber-200"
                  >
                    ±{pct}٪ از قیمت فعلی
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-[11px] text-slate-400">حد پایین محدوده (کف خرید)</label>
                <NumericInput value={lowerPrice} onValueChange={(v) => setLowerPrice(Number(v || 0))} />
              </div>
              <div className="space-y-1">
                <label className="text-[11px] text-slate-400">حد بالای محدوده (سقف فروش)</label>
                <NumericInput value={upperPrice} onValueChange={(v) => setUpperPrice(Number(v || 0))} />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">تعداد پله‌ها (۳ تا ۳۰)</label>
              <NumericInput value={gridLevels} onValueChange={(v) => setGridLevels(Math.max(3, Math.min(30, Math.round(Number(v || 3)))))} />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">
                سرمایه کل ({quoteCurrency === 'IRT' ? 'تومان' : 'USDT'})
              </label>
              <NumericInput value={totalCapital} onValueChange={(v) => setTotalCapital(Number(v || 0))} />
            </div>
            <div className="space-y-1">
              <label className="text-xs font-bold text-slate-300">نوع فاصله پله‌ها</label>
              <select
                value={stepMode}
                onChange={(e) => setStepMode(e.target.value as GridStepMode)}
                className="w-full min-h-[44px] rounded-xl border border-slate-700 bg-slate-900 px-3 text-xs text-white"
              >
                <option value="ARITHMETIC">فاصله ثابت عددی (Arithmetic)</option>
                <option value="GEOMETRIC">فاصله درصدی (Geometric)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 text-xs">
            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={stopOnBreakout}
                onChange={(e) => setStopOnBreakout(e.target.checked)}
                className="w-4 h-4 accent-amber-500"
              />
              <span>توقف خودکار در زمان خروج قیمت از محدوده</span>
            </label>
            <label className="flex items-center gap-2.5 cursor-pointer">
              <input
                type="checkbox"
                checked={alertOnBreakout}
                onChange={(e) => setAlertOnBreakout(e.target.checked)}
                className="w-4 h-4 accent-amber-500"
              />
              <span>ارسال هشدار هنگام شکست سقف یا کف محدوده</span>
            </label>
          </div>

          {/* Backtest Box */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-4 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="text-xs text-slate-300">
                <strong className="text-white">آزمایش روی داده‌های گذشته (Backtest):</strong> نتیجه دقیق با احتساب کارمزد نوبیتکس و لغزش قیمت
              </div>
              <button
                type="button"
                disabled={backtestBusy}
                onClick={() => void handleBacktest()}
                className="min-h-[44px] px-4 rounded-xl border border-cyan-500/40 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-200 text-xs font-bold flex items-center gap-1.5"
              >
                <FlaskConical className="w-4 h-4" />
                {backtestBusy ? 'در حال محاسبه...' : 'اجرای بک‌تست گرید'}
              </button>
            </div>
            {backtestResult && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2 border-t border-slate-800 text-xs">
                <div>
                  <span className="text-slate-400">بازده خالص:</span>{' '}
                  <strong className={`font-mono-num ${backtestResult.netProfitQuote >= 0 ? 'text-emerald-300' : 'text-rose-300'}`}>
                    {backtestResult.netProfitPercent >= 0 ? '+' : ''}
                    {backtestResult.netProfitPercent}٪
                  </strong>
                </div>
                <div>
                  <span className="text-slate-400">چرخه‌ها:</span>{' '}
                  <strong className="font-mono-num text-white">{backtestResult.totalTrades}</strong>
                </div>
                <div>
                  <span className="text-slate-400">کارمزد کل:</span>{' '}
                  <strong className="font-mono-num text-amber-300">
                    {formatQuoteAmount(backtestResult.totalFeesPaidQuote || 0, quoteCurrency)}
                  </strong>
                </div>
                <div>
                  <span className="text-slate-400">لغزش تخمینی:</span>{' '}
                  <strong className="font-mono-num text-slate-200">
                    {formatQuoteAmount(backtestResult.estimatedSlippageQuote || 0, quoteCurrency)}
                  </strong>
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row gap-2.5 pt-2">
            <button
              type="button"
              disabled={busy}
              onClick={() => void handleSubmit(true)}
              className="flex-1 min-h-[48px] rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-extrabold text-sm flex items-center justify-center gap-2"
            >
              <Play className="w-4 h-4" />
              ساخت و شروع فوری ربات گرید
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => void handleSubmit(false)}
              className="min-h-[48px] px-5 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs"
            >
              فقط ذخیره کن
            </button>
          </div>
        </div>
      )}

      {activeTab === 'EXECUTION' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-5">
          <div className="space-y-2">
            <h3 className="text-sm font-extrabold text-white">حالت تأیید معاملات</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setConfirmationMode('AUTO')}
                className={`min-h-[60px] rounded-xl border p-3.5 text-right ${
                  confirmationMode === 'AUTO'
                    ? 'border-amber-400 bg-amber-500/10 text-white'
                    : 'border-slate-800 bg-slate-900/50 text-slate-400'
                }`}
              >
                <div className="text-xs font-extrabold flex items-center gap-2">
                  <Activity className="w-4 h-4 text-amber-400" />
                  اجرای خودکار
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  ربات طبق تنظیمات و سقف بودجه مشترک خودکار خرید و فروش می‌کند.
                </p>
              </button>

              <button
                type="button"
                onClick={() => setConfirmationMode('MANUAL_CONFIRM')}
                className={`min-h-[60px] rounded-xl border p-3.5 text-right ${
                  confirmationMode === 'MANUAL_CONFIRM'
                    ? 'border-cyan-400 bg-cyan-500/10 text-white'
                    : 'border-slate-800 bg-slate-900/50 text-slate-400'
                }`}
              >
                <div className="text-xs font-extrabold flex items-center gap-2">
                  <Hand className="w-4 h-4 text-cyan-400" />
                  نیازمند تأیید دستی کاربر
                </div>
                <p className="text-[11px] text-slate-400 mt-1">
                  قبل از هر معامله، قیمت، مبلغ، دلیل و کارمزد نمایش داده می‌شود و منتظر تأیید شما می‌ماند.
                </p>
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="text-sm font-extrabold text-white">محیط اجرا (تمرینی یا واقعی)</h3>
            <ExecutionEnvironmentSelector
              executionMode={executionMode}
              hasExchangeKeys={hasExchangeKeys}
              liveConfirmed={liveConfirmed}
              onChangeExecutionMode={setExecutionMode}
              onToggleLiveConfirm={setLiveConfirmed}
            />
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 text-xs text-slate-300 flex items-start gap-2.5">
            <Shield className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <strong>حفاظت مشترک ریسک فعال است:</strong> حداکثر بودجه ربات‌های تومانی{' '}
              <span className="font-mono-num text-white">
                {riskSettings.totalBotsBudgetIrt.toLocaleString('en-US')}
              </span>{' '}
              تومان و قفل جلوگیری از تداخل دو ربات روی یک ارز{' '}
              <strong className={riskSettings.enableSymbolConflictLock ? 'text-emerald-300' : 'text-amber-300'}>
                {riskSettings.enableSymbolConflictLock ? 'روشن' : 'خاموش'}
              </strong>{' '}
              است.
            </div>
          </div>
        </div>
      )}

      {activeTab === 'HISTORY' && (
        <div className="rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 space-y-3">
          <h3 className="text-sm font-extrabold text-white">وضعیت پله‌ها و آمار چرخه‌های گرید</h3>
          {gridBots.length === 0 ? (
            <p className="text-xs text-slate-400">هنوز سابقه‌ای برای ربات گرید ثبت نشده است.</p>
          ) : (
            gridBots.map((bot) => (
              <div key={bot.id} className="rounded-xl border border-slate-800 bg-slate-900/50 p-3.5 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-white">{bot.name}</span>
                  <span className="text-slate-400">{formatDateTimeShort(bot.updatedAt)}</span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-[11px]">
                  <div>چرخه‌های موفق: <strong className="font-mono-num text-emerald-300">{bot.stats.completedCycles}</strong></div>
                  <div>کارمزد پرداختی: <strong className="font-mono-num text-amber-300">{formatQuoteAmount(bot.stats.totalFeesPaidQuote, bot.quoteCurrency)}</strong></div>
                  <div>سود هر چرخه: <strong className="font-mono-num text-cyan-300">{bot.stats.netProfitPerCyclePercent}٪</strong></div>
                </div>
              </div>
            ))
          )}
        </div>
      )}

      <StopBotSafetyModal
        open={Boolean(stopTarget)}
        botName={stopTarget?.name || ''}
        hasOpenPosition={Boolean(stopTarget && stopTarget.allocatedLevels.some((l) => l.status === 'HOLDING'))}
        holdingSummary={
          stopTarget
            ? `${stopTarget.allocatedLevels.filter((l) => l.status === 'HOLDING').length} پله دارای موجودی باز در کیف پول باقی می‌ماند.`
            : undefined
        }
        onConfirmStopOnly={() => {
          if (stopTarget) {
            void onStopGridBot(stopTarget.id);
          }
          setStopTarget(null);
        }}
        onCancel={() => setStopTarget(null)}
      />
    </BotPageShell>
  );
};
