import React, { useState } from 'react';
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  Pencil,
  RotateCcw,
  TrendingUp,
  X,
} from 'lucide-react';
import type {
  CostBasisSource,
  PortfolioAssetPerformance,
  PortfolioPerformanceSummary,
  QuoteCurrency,
} from '../types/trading';
import { formatPercent, formatPrice, formatQty, formatToman } from '../utils/format';
import { NumericInput } from './NumericInput';

interface PortfolioPerformanceWidgetProps {
  performance: PortfolioPerformanceSummary | null;
  loading: boolean;
  quoteCurrency?: QuoteCurrency;
  onQuoteCurrencyChange?: (qc: QuoteCurrency) => void;
  onSaveCostBasis: (asset: string, price: number, quoteCurrency: QuoteCurrency) => Promise<void>;
  onResetCostBasis: (asset: string) => Promise<void>;
  onStartTrade: (baseAsset: string, quoteCurrency?: QuoteCurrency) => void;
}

export const PortfolioPerformanceWidget: React.FC<PortfolioPerformanceWidgetProps> = ({
  performance,
  loading,
  quoteCurrency = 'IRT',
  onQuoteCurrencyChange,
  onSaveCostBasis,
  onResetCostBasis,
  onStartTrade,
}) => {
  const [displayCurrency, setDisplayCurrency] = useState<QuoteCurrency>(quoteCurrency);
  const [editingAsset, setEditingAsset] = useState<string | null>(null);
  const [editPrice, setEditPrice] = useState('');
  const [editQuote, setEditQuote] = useState<QuoteCurrency>(quoteCurrency);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  React.useEffect(() => {
    setDisplayCurrency(quoteCurrency);
  }, [quoteCurrency]);

  const handleSelectCurrency = (qc: QuoteCurrency) => {
    setDisplayCurrency(qc);
    onQuoteCurrencyChange?.(qc);
  };

  const sourceLabel = (src: CostBasisSource) => {
    if (src === 'ORDERS') return 'میانگین سفارش‌های خرید';
    if (src === 'MANUAL') return 'ثبت دستی شما';
    return 'تخمینی ۲۴ ساعته';
  };

  const beginEdit = (row: PortfolioAssetPerformance) => {
    setEditingAsset(row.asset);
    setEditQuote(displayCurrency);
    setEditPrice(
      displayCurrency === 'IRT'
        ? String(Math.round(row.avgBuyPriceToman))
        : String(Number(row.avgBuyPriceUsdt.toFixed(6)))
    );
    setError(null);
  };

  const handleSave = async (asset: string) => {
    const parsed = Number(editPrice);
    if (!Number.isFinite(parsed) || parsed <= 0) {
      setError('لطفاً قیمت خرید اولیه معتبر وارد کنید.');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await onSaveCostBasis(asset, parsed, editQuote);
      setEditingAsset(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'خطا در ذخیره قیمت خرید');
    } finally {
      setSaving(false);
    }
  };

  const isToman = displayCurrency === 'IRT';
  const totalCostPrimary = performance
    ? isToman
      ? performance.cryptoCostBasisToman
      : performance.cryptoCostBasisUsdt
    : 0;
  const totalCurrentPrimary = performance
    ? isToman
      ? performance.cryptoCurrentToman
      : performance.cryptoCurrentUsdt
    : 0;
  const totalPnlPrimary = performance
    ? isToman
      ? performance.cryptoPnlToman
      : performance.cryptoPnlUsdt
    : 0;
  const totalPnlSecondary = performance
    ? isToman
      ? performance.cryptoPnlUsdt
      : performance.cryptoPnlToman
    : 0;
  const totalPct = performance
    ? isToman
      ? performance.cryptoPnlPercentToman
      : performance.cryptoPnlPercentUsdt
    : 0;
  const isProfit = totalPnlPrimary >= 0;

  return (
    <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg overflow-hidden">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 px-5 py-3.5 border-b border-slate-800 bg-[#060A14]">
        <div>
          <h3 className="text-sm font-semibold text-white">
            عملکرد سبد دارایی نسبت به قیمت خرید اولیه
          </h3>
          <div className="flex flex-wrap items-center gap-2 text-xs text-slate-400 mt-0.5">
            <span>
              {performance?.mode === 'live' ? 'حساب واقعی نوبیتکس' : 'کیف پول تمرینی'}
            </span>
            <span aria-hidden="true">·</span>
            <span>{performance?.assets.length ?? 0} رمزارز فعال در سبد</span>
            {performance && performance.cashToman > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span className="font-mono-num" dir="ltr">
                  نقد آزاد: {formatToman(performance.cashToman)} ت (${performance.cashUsdt.toFixed(2)})
                </span>
              </>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            type="button"
            onClick={() => handleSelectCurrency('IRT')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              isToman ? 'bg-amber-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            بازار تومانی (IRT)
          </button>
          <button
            type="button"
            onClick={() => handleSelectCurrency('USDT')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
              !isToman ? 'bg-cyan-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-slate-100'
            }`}
          >
            بازار تتری (USDT)
          </button>
        </div>
      </div>

      {/* Loading skeleton */}
      {loading && !performance ? (
        <div className="p-8 text-center text-xs text-slate-400">
          در حال محاسبه بازده سبد دارایی نسبت به قیمت خرید اولیه...
        </div>
      ) : !performance || performance.assets.length === 0 ? (
        /* Empty state: only IRT / USDT cash held */
        <div className="p-6 flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1 max-w-2xl">
            <div className="text-sm font-medium text-slate-200">
              هنوز رمزارزی در سبد دارایی شما وجود ندارد
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              در حال حاضر کل موجودی شما به صورت نقدی (
              <span className="font-mono-num text-amber-300" dir="ltr">
                {formatToman(performance?.cashToman ?? 0)} تومان
              </span>{' '}
              و{' '}
              <span className="font-mono-num text-slate-200" dir="ltr">
                ${(performance?.cashUsdt ?? 0).toFixed(2)} USDT
              </span>
              ) است. به محض خرید دستی یا فعال‌سازی ربات، سود و زیان مبلغی و درصدی هر ارز نسبت به قیمت خرید اولیه در اینجا محاسبه می‌شود.
            </p>
          </div>
          <button
            type="button"
            onClick={() => onStartTrade('BTC', displayCurrency)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-semibold bg-cyan-500 hover:bg-cyan-400 text-slate-950 transition-colors whitespace-nowrap shrink-0"
          >
            <TrendingUp className="w-4 h-4" />
            <span>خرید اولین ارز در ترمینال</span>
          </button>
        </div>
      ) : (
        <>
          {/* 4-Column Summary Strip separated by hairline dividers */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 divide-y sm:divide-y-0 sm:divide-x sm:divide-x-reverse divide-slate-800 border-b border-slate-800">
            <div className="p-4 space-y-1">
              <div className="text-xs text-slate-400">بهای خرید اولیه دارایی‌ها</div>
              <div className="text-base font-semibold font-mono-num text-white" dir="ltr">
                {isToman
                  ? `${formatToman(totalCostPrimary)} ت`
                  : `$${totalCostPrimary.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
              </div>
              <div className="text-[11px] text-slate-400 font-mono-num" dir="ltr">
                {isToman
                  ? `≈ $${performance.cryptoCostBasisUsdt.toFixed(2)} USDT`
                  : `≈ ${formatToman(performance.cryptoCostBasisToman)} تومان`}
              </div>
            </div>

            <div className="p-4 space-y-1">
              <div className="text-xs text-slate-400">ارزش فعلی سبد رمزارزها</div>
              <div className="text-base font-semibold font-mono-num text-amber-300" dir="ltr">
                {isToman
                  ? `${formatToman(totalCurrentPrimary)} ت`
                  : `$${totalCurrentPrimary.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
              </div>
              <div className="text-[11px] text-slate-400 font-mono-num" dir="ltr">
                {isToman
                  ? `≈ $${performance.cryptoCurrentUsdt.toFixed(2)} USDT`
                  : `≈ ${formatToman(performance.cryptoCurrentToman)} تومان`}
              </div>
            </div>

            <div className="p-4 space-y-1">
              <div className="flex items-center justify-between text-xs text-slate-400">
                <span>سود / زیان مبلغی کل</span>
                <span className={isProfit ? 'text-emerald-400' : 'text-rose-400'}>
                  {isProfit ? 'در سود' : 'در زیان'}
                </span>
              </div>
              <div
                className={`text-base font-semibold font-mono-num ${
                  isProfit ? 'text-emerald-400' : 'text-rose-400'
                }`}
                dir="ltr"
              >
                {totalPnlPrimary >= 0 ? '+' : '-'}
                {isToman
                  ? `${formatToman(Math.abs(totalPnlPrimary))} ت`
                  : `$${Math.abs(totalPnlPrimary).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`}
              </div>
              <div className="text-[11px] text-slate-400 font-mono-num" dir="ltr">
                {totalPnlSecondary >= 0 ? '+' : '-'}
                {isToman
                  ? `$${Math.abs(totalPnlSecondary).toFixed(2)} USDT`
                  : `${formatToman(Math.abs(totalPnlSecondary))} تومان`}
              </div>
            </div>

            <div className="p-4 space-y-1">
              <div className="text-xs text-slate-400">بازده درصدی سبد</div>
              <div
                className={`inline-flex items-center gap-1 text-lg font-bold font-mono-num ${
                  totalPct >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
                dir="ltr"
              >
                {totalPct >= 0 ? (
                  <ArrowUpRight className="w-4 h-4" />
                ) : (
                  <ArrowDownRight className="w-4 h-4" />
                )}
                <span>{formatPercent(totalPct)}</span>
              </div>
              <div className="text-[11px] text-slate-500">
                نسبت به میانگین قیمت خرید اولیه
              </div>
            </div>
          </div>

          {error && (
            <div className="px-5 py-2.5 bg-rose-500/10 border-b border-rose-500/30 text-xs text-rose-300">
              {error}
            </div>
          )}

          {/* Per-Asset Breakdown Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse">
              <thead>
                <tr className="border-b border-slate-800 text-xs text-slate-400 bg-[#060A14]">
                  <th className="py-2.5 px-4 font-medium">ارز</th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    مقدار
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    قیمت خرید اولیه
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    قیمت فعلی
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    سود / زیان مبلغی
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left" dir="ltr">
                    درصد عملکرد
                  </th>
                  <th className="py-2.5 px-4 font-medium text-left">تنظیم قیمت خرید</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/70 text-xs">
                {performance.assets.map((row) => {
                  const rowPnlPrimary = isToman ? row.pnlToman : row.pnlUsdt;
                  const rowPnlSecondary = isToman ? row.pnlUsdt : row.pnlToman;
                  const rowPct = isToman ? row.pnlPercentToman : row.pnlPercentUsdt;
                  const rowUp = rowPnlPrimary >= 0;
                  const isEditing = editingAsset === row.asset;

                  return (
                    <tr key={row.asset} className="hover:bg-slate-900/60 transition-colors">
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          <span className="font-mono-num font-semibold text-white">
                            {row.asset}
                          </span>
                          <span className="text-slate-400 text-[11px]">{row.persianName}</span>
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {sourceLabel(row.source)}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-left font-mono-num text-slate-200" dir="ltr">
                        {formatQty(row.quantity)}
                      </td>

                      <td className="py-3 px-4 text-left font-mono-num" dir="ltr">
                        {isEditing ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <NumericInput
                              value={editPrice}
                              onValueChange={setEditPrice}
                              className="w-28 bg-slate-950 border border-cyan-500 rounded px-2 py-1 text-xs text-white focus:outline-none"
                              placeholder="قیمت خرید"
                            />
                            <select
                              value={editQuote}
                              onChange={(e) => setEditQuote(e.target.value as QuoteCurrency)}
                              className="bg-slate-950 border border-slate-700 rounded px-1.5 py-1 text-[11px] text-slate-200"
                            >
                              <option value="IRT">تومان</option>
                              <option value="USDT">USDT</option>
                            </select>
                          </div>
                        ) : (
                          <div>
                            <div className="text-slate-200">
                              {isToman
                                ? `${formatToman(row.avgBuyPriceToman)} ت`
                                : `$${formatPrice(row.avgBuyPriceUsdt)}`}
                            </div>
                            <div className="text-[11px] text-slate-500">
                              {isToman
                                ? `$${formatPrice(row.avgBuyPriceUsdt)}`
                                : `${formatToman(row.avgBuyPriceToman)} ت`}
                            </div>
                          </div>
                        )}
                      </td>

                      <td className="py-3 px-4 text-left font-mono-num" dir="ltr">
                        <div className="text-amber-300">
                          {isToman
                            ? `${formatToman(row.currentPriceToman)} ت`
                            : `$${formatPrice(row.currentPriceUsdt)}`}
                        </div>
                        <div className="text-[11px] text-slate-500">
                          {isToman
                            ? `$${formatPrice(row.currentPriceUsdt)}`
                            : `${formatToman(row.currentPriceToman)} ت`}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-left font-mono-num" dir="ltr">
                        <div className={rowUp ? 'text-emerald-400 font-semibold' : 'text-rose-400 font-semibold'}>
                          {rowPnlPrimary >= 0 ? '+' : '-'}
                          {isToman
                            ? `${formatToman(Math.abs(rowPnlPrimary))} ت`
                            : `$${Math.abs(rowPnlPrimary).toFixed(2)}`}
                        </div>
                        <div className="text-[11px] text-slate-400">
                          {rowPnlSecondary >= 0 ? '+' : '-'}
                          {isToman
                            ? `$${Math.abs(rowPnlSecondary).toFixed(2)}`
                            : `${formatToman(Math.abs(rowPnlSecondary))} ت`}
                        </div>
                      </td>

                      <td className="py-3 px-4 text-left font-mono-num" dir="ltr">
                        <span
                          className={`inline-flex items-center gap-0.5 font-semibold ${
                            rowUp ? 'text-emerald-400' : 'text-rose-400'
                          }`}
                        >
                          {rowUp ? (
                            <ArrowUpRight className="w-3.5 h-3.5" />
                          ) : (
                            <ArrowDownRight className="w-3.5 h-3.5" />
                          )}
                          {formatPercent(rowPct)}
                        </span>
                      </td>

                      <td className="py-3 px-4 text-left">
                        {isEditing ? (
                          <div className="flex items-center justify-end gap-1">
                            <button
                              type="button"
                              disabled={saving}
                              onClick={() => handleSave(row.asset)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-emerald-600 hover:bg-emerald-500 text-white text-[11px] font-medium whitespace-nowrap shrink-0 disabled:opacity-50"
                            >
                              <Check className="w-3 h-3" />
                              <span>ذخیره</span>
                            </button>
                            <button
                              type="button"
                              onClick={() => setEditingAsset(null)}
                              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300"
                              title="انصراف"
                            >
                              <X className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        ) : (
                          <div className="flex items-center justify-end gap-1">
                            <button
                              type="button"
                              onClick={() => beginEdit(row)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 text-[11px] whitespace-nowrap shrink-0"
                            >
                              <Pencil className="w-3 h-3" />
                              <span>ویرایش قیمت خرید</span>
                            </button>
                            {row.source === 'MANUAL' && (
                              <button
                                type="button"
                                onClick={() => void onResetCostBasis(row.asset)}
                                className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-amber-300"
                                title="بازگشت به محاسبه خودکار"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </div>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </>
      )}
    </section>
  );
};
