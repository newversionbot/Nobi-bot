import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  CheckCheck,
  CheckCircle2,
  Inbox,
  Info,
  Mail,
  Megaphone,
  Pin,
  X,
} from 'lucide-react';
import type {
  BroadcastMessage,
  BroadcastSeverity,
  DirectMessageRecord,
} from '../types/trading';
import { formatDateTimeShort } from '../utils/format';

interface UserInboxModalProps {
  open: boolean;
  onClose: () => void;
  broadcasts: BroadcastMessage[];
  directMessages: DirectMessageRecord[];
  unreadDirectCount: number;
  isAuthenticated: boolean;
  onSignIn: () => Promise<void>;
  onMarkRead: (messageId: string) => Promise<void>;
  onMarkAllRead: () => Promise<void>;
}

const SEVERITY_META: Record<
  BroadcastSeverity,
  { label: string; textClass: string; Icon: React.ComponentType<{ className?: string }> }
> = {
  INFO: { label: 'اطلاعیه', textClass: 'text-cyan-300', Icon: Info },
  SUCCESS: { label: 'مژده / تایید', textClass: 'text-emerald-400', Icon: CheckCircle2 },
  WARNING: { label: 'هشدار مهم', textClass: 'text-amber-300', Icon: AlertTriangle },
  URGENT: { label: 'فوری', textClass: 'text-rose-400', Icon: AlertTriangle },
};

export const UserInboxModal: React.FC<UserInboxModalProps> = ({
  open,
  onClose,
  broadcasts,
  directMessages,
  unreadDirectCount,
  isAuthenticated,
  onSignIn,
  onMarkRead,
  onMarkAllRead,
}) => {
  const [tab, setTab] = useState<'ALL' | 'DIRECT' | 'BROADCAST'>('ALL');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [markingAll, setMarkingAll] = useState(false);

  useEffect(() => {
    if (!open) return;
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, onClose]);

  if (!open) return null;

  const handleMarkSingle = async (id: string) => {
    setBusyId(id);
    try {
      await onMarkRead(id);
    } finally {
      setBusyId(null);
    }
  };

  const handleMarkAll = async () => {
    setMarkingAll(true);
    try {
      await onMarkAllRead();
    } finally {
      setMarkingAll(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label="صندوق پیام‌ها و اطلاعیه‌های مدیر"
    >
      <div
        className="w-full max-w-2xl max-h-[88vh] bg-[#0A101D] border border-slate-800 rounded-xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 bg-[#060A14] flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-lg bg-cyan-500/15 border border-cyan-500/35 flex items-center justify-center shrink-0">
              <Inbox className="w-4 h-4 text-cyan-400" />
            </div>
            <div>
              <h2 className="text-sm sm:text-base font-semibold text-white">
                صندوق پیام‌ها و اطلاعیه‌های سیستم
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                پیام‌های اختصاصی مدیر برای شما و اطلاعیه‌های عمومی پلتفرم
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
            title="بستن"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Filter Bar */}
        <div className="px-5 py-3 border-b border-slate-800 flex flex-wrap items-center justify-between gap-3 text-xs bg-[#080D18]">
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              type="button"
              onClick={() => setTab('ALL')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 ${
                tab === 'ALL'
                  ? 'bg-cyan-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              همه ({directMessages.length + broadcasts.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('DIRECT')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 ${
                tab === 'DIRECT'
                  ? 'bg-cyan-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              پیام‌های تکی ({directMessages.length})
            </button>
            <button
              type="button"
              onClick={() => setTab('BROADCAST')}
              className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap shrink-0 ${
                tab === 'BROADCAST'
                  ? 'bg-cyan-500 text-slate-950 font-semibold'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              اطلاعیه‌های عمومی ({broadcasts.length})
            </button>
          </div>

          {isAuthenticated && unreadDirectCount > 0 && (
            <button
              type="button"
              disabled={markingAll}
              onClick={() => void handleMarkAll()}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-emerald-500/15 border border-emerald-500/40 hover:bg-emerald-500/25 text-emerald-300 font-medium transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
            >
              <CheckCheck className="w-3.5 h-3.5" />
              <span>{markingAll ? 'در حال ثبت...' : `علامت‌گذاری همه (${unreadDirectCount})`}</span>
            </button>
          )}
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-800/80">
          {/* Direct Messages Section */}
          {(tab === 'ALL' || tab === 'DIRECT') && (
            <section className="p-5 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="inline-flex items-center gap-1.5 font-semibold text-white">
                  <Mail className="w-3.5 h-3.5 text-cyan-400" />
                  <span>پیام‌های اختصاصی مدیر به حساب شما</span>
                </span>
                {unreadDirectCount > 0 && (
                  <span className="text-amber-300 font-medium">
                    {unreadDirectCount} پیام خوانده‌نشده
                  </span>
                )}
              </div>

              {!isAuthenticated ? (
                <div className="py-5 px-4 bg-slate-950 border border-slate-800 rounded-lg flex flex-wrap items-center justify-between gap-3 text-xs">
                  <span className="text-slate-400">
                    برای مشاهده پیام‌های اختصاصی ارسال‌شده از طرف مدیر به حساب کاربری خود، وارد شوید.
                  </span>
                  <button
                    type="button"
                    onClick={() => void onSignIn()}
                    className="px-3.5 py-1.5 rounded-md bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold whitespace-nowrap shrink-0"
                  >
                    ورود با گوگل
                  </button>
                </div>
              ) : directMessages.length === 0 ? (
                <div className="py-5 text-center text-xs text-slate-500">
                  هنوز پیام اختصاصی برای شما ارسال نشده است.
                </div>
              ) : (
                <div className="divide-y divide-slate-800 border border-slate-800 rounded-lg bg-slate-950 overflow-hidden">
                  {directMessages.map((dm) => {
                    const meta = SEVERITY_META[dm.severity] || SEVERITY_META.INFO;
                    const SevIcon = meta.Icon;
                    return (
                      <div
                        key={dm.id}
                        className={`p-4 space-y-2 text-xs ${
                          dm.readByUser ? 'opacity-80' : 'bg-cyan-500/5'
                        }`}
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <SevIcon className={`w-3.5 h-3.5 shrink-0 ${meta.textClass}`} />
                            <span className={`font-semibold ${meta.textClass}`}>{meta.label}</span>
                            <span aria-hidden="true" className="text-slate-600">
                              ·
                            </span>
                            <span className="font-semibold text-white">{dm.subject}</span>
                            {!dm.readByUser && (
                              <span className="text-[11px] font-semibold text-amber-300">
                                (جدید)
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] font-mono-num text-slate-500" dir="ltr">
                            {formatDateTimeShort(dm.createdAt)}
                          </span>
                        </div>

                        <p className="text-slate-200 leading-relaxed whitespace-pre-line">
                          {dm.body}
                        </p>

                        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                          <span className="text-[11px] text-slate-500 font-mono-num" dir="ltr">
                            از طرف مدیریت ({dm.senderEmail})
                          </span>
                          {dm.readByUser ? (
                            <span className="inline-flex items-center gap-1 text-[11px] text-emerald-400">
                              <CheckCircle2 className="w-3.5 h-3.5" />
                              <span>خوانده شده</span>
                            </span>
                          ) : (
                            <button
                              type="button"
                              disabled={busyId === dm.id}
                              onClick={() => void handleMarkSingle(dm.id)}
                              className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-cyan-500/15 hover:bg-cyan-500/25 text-cyan-300 font-medium transition-colors"
                            >
                              <CheckCheck className="w-3.5 h-3.5" />
                              <span>{busyId === dm.id ? 'در حال ثبت...' : 'خوانده شد'}</span>
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>
          )}

          {/* Public Broadcasts Section */}
          {(tab === 'ALL' || tab === 'BROADCAST') && (
            <section className="p-5 space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="inline-flex items-center gap-1.5 font-semibold text-white">
                  <Megaphone className="w-3.5 h-3.5 text-amber-400" />
                  <span>اطلاعیه‌های عمومی پلتفرم</span>
                </span>
                <span className="text-slate-400">{broadcasts.length} اطلاعیه فعال</span>
              </div>

              {broadcasts.length === 0 ? (
                <div className="py-5 text-center text-xs text-slate-500">
                  در حال حاضر اطلاعیه عمومی فعالی وجود ندارد.
                </div>
              ) : (
                <div className="divide-y divide-slate-800 border border-slate-800 rounded-lg bg-slate-950 overflow-hidden">
                  {broadcasts.map((b) => {
                    const meta = SEVERITY_META[b.severity] || SEVERITY_META.INFO;
                    const SevIcon = meta.Icon;
                    return (
                      <div key={b.id} className="p-4 space-y-2 text-xs">
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex flex-wrap items-center gap-2">
                            <SevIcon className={`w-3.5 h-3.5 shrink-0 ${meta.textClass}`} />
                            <span className={`font-semibold ${meta.textClass}`}>{meta.label}</span>
                            <span aria-hidden="true" className="text-slate-600">
                              ·
                            </span>
                            <span className="font-semibold text-white">{b.title}</span>
                            {b.pinned && (
                              <span className="inline-flex items-center gap-1 text-[11px] text-amber-300 font-medium">
                                <Pin className="w-3 h-3" />
                                <span>سنجاق‌شده</span>
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] font-mono-num text-slate-500" dir="ltr">
                            {formatDateTimeShort(b.createdAt)}
                          </span>
                        </div>
                        <p className="text-slate-200 leading-relaxed whitespace-pre-line">
                          {b.body}
                        </p>
                      </div>
                    );
                  })}
                </div>
              )}
            </section>
          )}
        </div>
      </div>
    </div>
  );
};
