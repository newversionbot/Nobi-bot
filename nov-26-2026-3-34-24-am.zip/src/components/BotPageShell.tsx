import React from 'react';
import {
  AlertTriangle,
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Hand,
  ShieldAlert,
  Sparkles,
  X,
} from 'lucide-react';
import type { PendingBotConfirmation } from '../types/trading';
import type { GuideBotTopic } from './BotEducationModal';

export type DedicatedBotTabId = 'OVERVIEW' | 'SETTINGS' | 'EXECUTION' | 'HISTORY';

export interface BotPageKpi {
  label: string;
  value: string;
  subtext?: string;
  tone?: 'neutral' | 'positive' | 'negative' | 'accent';
}

interface BotPageShellProps {
  topic: GuideBotTopic;
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  accentGradient: string;
  statusLabel: string;
  statusTone: 'active' | 'waiting' | 'paused' | 'error';
  kpis: BotPageKpi[];
  activeTab: DedicatedBotTabId;
  onTabChange: (tab: DedicatedBotTabId) => void;
  onBack: () => void;
  onOpenGuide: (topic: GuideBotTopic) => void;
  pendingConfirmations?: PendingBotConfirmation[];
  onApproveConfirmation?: (conf: PendingBotConfirmation) => void;
  onRejectConfirmation?: (conf: PendingBotConfirmation) => void;
  children: React.ReactNode;
}

export const BotPageShell: React.FC<BotPageShellProps> = ({
  topic,
  title,
  subtitle,
  icon,
  accentGradient,
  statusLabel,
  statusTone,
  kpis,
  activeTab,
  onTabChange,
  onBack,
  onOpenGuide,
  pendingConfirmations = [],
  onApproveConfirmation,
  onRejectConfirmation,
  children,
}) => {
  const statusBadgeClass =
    statusTone === 'active'
      ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/35'
      : statusTone === 'waiting'
        ? 'bg-amber-500/15 text-amber-300 border-amber-500/35'
        : statusTone === 'error'
          ? 'bg-rose-500/15 text-rose-300 border-rose-500/35'
          : 'bg-slate-800 text-slate-300 border-slate-700';

  const tabs: Array<{ id: DedicatedBotTabId; label: string }> = [
    { id: 'OVERVIEW', label: 'نمای کلی' },
    { id: 'SETTINGS', label: 'تنظیمات' },
    { id: 'EXECUTION', label: 'نحوه اجرا' },
    { id: 'HISTORY', label: 'تاریخچه' },
  ];

  return (
    <div className="space-y-4 sm:space-y-5" dir="rtl">
      {/* Section 1: Clean Header */}
      <div className={`rounded-2xl border border-slate-800 bg-[#0A101D] p-4 sm:p-5 relative overflow-hidden`}>
        <div className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-l ${accentGradient}`} />
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start sm:items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={onBack}
              className="min-w-[44px] min-h-[44px] rounded-xl border border-slate-700/80 bg-slate-900 hover:bg-slate-800 text-slate-200 flex items-center justify-center shrink-0 transition"
              title="بازگشت به رباتهای معاملاتی من"
            >
              <ArrowRight className="w-5 h-5" />
            </button>
            <div className="w-11 h-11 rounded-xl border border-slate-700/80 bg-slate-900 flex items-center justify-center shrink-0">
              {icon}
            </div>
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-white truncate">{title}</h2>
                <span className={`px-2.5 py-0.5 rounded-lg border text-[11px] font-bold ${statusBadgeClass}`}>
                  {statusLabel}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5 line-clamp-2">{subtitle}</p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => onOpenGuide(topic)}
              className="min-h-[44px] px-3.5 rounded-xl border border-cyan-500/35 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-200 text-xs font-bold flex items-center gap-2 transition"
            >
              <BookOpen className="w-4 h-4" />
              راهنمای استفاده
            </button>
          </div>
        </div>

        {/* Section 2: Quick Performance KPIs */}
        {kpis.length > 0 && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 mt-4">
            {kpis.map((kpi, idx) => {
              const toneClass =
                kpi.tone === 'positive'
                  ? 'text-emerald-300'
                  : kpi.tone === 'negative'
                    ? 'text-rose-300'
                    : kpi.tone === 'accent'
                      ? 'text-cyan-300'
                      : 'text-white';
              return (
                <div
                  key={idx}
                  className="rounded-xl border border-slate-800/90 bg-slate-900/60 px-3 py-2.5"
                >
                  <div className="text-[11px] text-slate-400 truncate">{kpi.label}</div>
                  <div className={`text-sm sm:text-base font-extrabold font-mono-num mt-0.5 truncate ${toneClass}`}>
                    {kpi.value}
                  </div>
                  {kpi.subtext && (
                    <div className="text-[10px] text-slate-500 mt-0.5 truncate">{kpi.subtext}</div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Pending Manual Confirmations Banner for this bot */}
      {pendingConfirmations.length > 0 && (
        <div className="rounded-2xl border border-amber-500/40 bg-amber-500/10 p-4 space-y-3">
          <div className="flex items-center gap-2 text-amber-200 text-xs sm:text-sm font-bold">
            <Hand className="w-4 h-4 text-amber-400 shrink-0" />
            سفارش در انتظار تأیید دستی شما ({pendingConfirmations.length})
          </div>
          <div className="space-y-2.5">
            {pendingConfirmations.map((conf) => (
              <div
                key={conf.id}
                className="rounded-xl border border-amber-500/30 bg-[#0A101D]/90 p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
              >
                <div className="space-y-1 text-xs">
                  <div className="font-bold text-white">
                    {conf.side === 'BUY' ? 'خرید پیشنهادی' : 'فروش پیشنهادی'} {conf.symbol} ·{' '}
                    <span className="font-mono-num text-cyan-300">
                      {conf.suggestedPrice.toLocaleString('en-US')}
                    </span>
                  </div>
                  <div className="text-slate-300">{conf.reasonFa}</div>
                  <div className="text-[11px] text-slate-400">
                    کارمزد تخمینی:{' '}
                    <span className="font-mono-num">{Math.round(conf.estimatedFeeQuote).toLocaleString('en-US')}</span>{' '}
                    · {conf.riskSummaryFa}
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {onApproveConfirmation && (
                    <button
                      type="button"
                      onClick={() => onApproveConfirmation(conf)}
                      className="min-h-[44px] px-4 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      تأیید و اجرا
                    </button>
                  )}
                  {onRejectConfirmation && (
                    <button
                      type="button"
                      onClick={() => onRejectConfirmation(conf)}
                      className="min-h-[44px] px-3 rounded-xl border border-rose-500/40 bg-rose-500/10 hover:bg-rose-500/20 text-rose-200 text-xs font-bold flex items-center gap-1.5"
                    >
                      <X className="w-4 h-4" />
                      رد کردن
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Isolated Mobile-Friendly Tabs */}
      <div className="grid grid-cols-4 gap-1.5 p-1 rounded-xl border border-slate-800 bg-[#0A101D]">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => onTabChange(tab.id)}
              className={`min-h-[44px] rounded-lg text-xs sm:text-sm font-bold transition ${
                isActive
                  ? 'bg-cyan-600/20 text-cyan-200 border border-cyan-500/40 shadow-inner'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
              }`}
            >
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Main Content */}
      <div>{children}</div>
    </div>
  );
};

interface StopBotSafetyModalProps {
  open: boolean;
  botName: string;
  hasOpenPosition: boolean;
  holdingSummary?: string;
  onConfirmStopOnly: () => void;
  onCancel: () => void;
}

export const StopBotSafetyModal: React.FC<StopBotSafetyModalProps> = ({
  open,
  botName,
  hasOpenPosition,
  holdingSummary,
  onConfirmStopOnly,
  onCancel,
}) => {
  if (!open) return null;
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4"
      dir="rtl"
      onClick={onCancel}
    >
      <div
        className="w-full max-w-md rounded-2xl border border-slate-700 bg-[#0B1220] p-5 space-y-4 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 text-amber-300 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-extrabold text-white">تأیید توقف «{botName}»</h3>
            <p className="text-xs text-slate-400 mt-1 leading-6">
              با توقف ربات، دیگر هیچ سفارش خرید جدیدی ثبت نمی‌شود.
              {hasOpenPosition
                ? ' این ربات در حال حاضر دارایی/پوزیشن باز دارد؛ با توقف، دارایی در کیف پول شما حفظ می‌شود و خودکار فروخته نمی‌شود.'
                : ''}
            </p>
            {holdingSummary && (
              <div className="mt-2 rounded-lg border border-slate-800 bg-slate-900/70 px-3 py-2 text-xs text-cyan-200">
                {holdingSummary}
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center gap-2 pt-1">
          <button
            type="button"
            onClick={onConfirmStopOnly}
            className="flex-1 min-h-[44px] rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold"
          >
            بله، ربات را متوقف کن
          </button>
          <button
            type="button"
            onClick={onCancel}
            className="min-h-[44px] px-4 rounded-xl border border-slate-700 bg-slate-900 text-slate-300 text-xs font-bold"
          >
            انصراف
          </button>
        </div>
      </div>
    </div>
  );
};

interface LiveConfirmationBannerProps {
  executionMode: 'paper' | 'live';
  hasExchangeKeys: boolean;
  liveConfirmed: boolean;
  onChangeExecutionMode: (mode: 'paper' | 'live') => void;
  onToggleLiveConfirm: (checked: boolean) => void;
}

export const ExecutionEnvironmentSelector: React.FC<LiveConfirmationBannerProps> = ({
  executionMode,
  hasExchangeKeys,
  liveConfirmed,
  onChangeExecutionMode,
  onToggleLiveConfirm,
}) => {
  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={() => onChangeExecutionMode('paper')}
          className={`min-h-[52px] rounded-xl border p-3 text-right transition ${
            executionMode === 'paper'
              ? 'border-cyan-500/60 bg-cyan-500/10 text-white'
              : 'border-slate-800 bg-slate-900/50 text-slate-400'
          }`}
        >
          <div className="text-xs font-extrabold flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            حساب تمرینی (Paper)
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">بدون ریسک سرمایه واقعی · عالی برای تست</div>
        </button>

        <button
          type="button"
          onClick={() => onChangeExecutionMode('live')}
          className={`min-h-[52px] rounded-xl border p-3 text-right transition ${
            executionMode === 'live'
              ? 'border-rose-500/60 bg-rose-500/10 text-white'
              : 'border-slate-800 bg-slate-900/50 text-slate-400'
          }`}
        >
          <div className="text-xs font-extrabold flex items-center gap-1.5">
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            حساب واقعی (نوبیتکس)
          </div>
          <div className="text-[11px] text-slate-400 mt-0.5">معامله با موجودی واقعی شما</div>
        </button>
      </div>

      {executionMode === 'live' && (
        <div className="rounded-xl border border-rose-500/40 bg-rose-500/10 p-3.5 space-y-2.5">
          {!hasExchangeKeys && (
            <div className="text-xs text-rose-200 font-bold">
              هشدار: کلید API نوبیتکس شما هنوز ثبت نشده است. برای معاملات واقعی ابتدا API را در تنظیمات حساب وارد کنید.
            </div>
          )}
          <label className="flex items-start gap-2.5 cursor-pointer text-xs text-rose-100">
            <input
              type="checkbox"
              checked={liveConfirmed}
              onChange={(e) => onToggleLiveConfirm(e.target.checked)}
              className="mt-0.5 w-4 h-4 rounded accent-rose-500 shrink-0"
            />
            <span>
              تأیید می‌کنم که ربات با <strong className="text-white">سرمایه واقعی نوبیتکس</strong> معامله می‌کند و هیچ تضمینی برای سود وجود ندارد.
            </span>
          </label>
        </div>
      )}
    </div>
  );
};
