import { initializeApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut,
  type User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  getDocs,
  getFirestore,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import type {
  AdminReferralRecord,
  AppApiKeySummary,
  AppControlConfig,
  BillingPublicConfig,
  BroadcastMessage,
  DirectMessageRecord,
  PaymentRequestRecord,
  UserSubscriptionSummary,
} from './types/trading';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export async function getFirebaseAuthHeaders(): Promise<Record<string, string>> {
  const current = auth.currentUser;
  if (!current) return {};
  try {
    const token = await current.getIdToken();
    return { Authorization: `Bearer ${token}` };
  } catch {
    return {};
  }
}

export type OperationType = 'create' | 'update' | 'delete' | 'list' | 'get' | 'write';

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

export async function testFirestoreConnection(): Promise<boolean> {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
    return true;
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
      return false;
    }
    return true;
  }
}

void testFirestoreConnection();

export function formatFirebaseAuthError(error: unknown): string {
  const code =
    typeof error === 'object' && error !== null && 'code' in error
      ? String((error as { code?: unknown }).code || '')
      : '';
  const msg = error instanceof Error ? error.message : String(error || '');

  if (code === 'auth/unauthorized-domain' || msg.includes('auth/unauthorized-domain')) {
    const host = typeof window !== 'undefined' ? window.location.hostname : '';
    return host
      ? `دامنه فعلی (${host}) در فهرست دامنه‌های مجاز Firebase Authentication ثبت نشده است. لطفاً این دامنه را در Firebase Console > Authentication > Settings > Authorized domains اضافه کنید یا پروژه Firebase متعلق به خودتان را تنظیم کنید. در حال حاضر می‌توانید از حالت دمو استفاده کنید.`
      : 'دامنه فعلی در فهرست دامنه‌های مجاز Firebase Authentication ثبت نشده است. در حال حاضر می‌توانید از حالت دمو استفاده کنید.';
  }
  if (code === 'auth/popup-blocked' || msg.includes('auth/popup-blocked')) {
    return 'پنجره ورود گوگل توسط مرورگر مسدود شد. لطفاً اجازه باز شدن پنجره پاپ‌آپ (Popup) را بدهید و دوباره تلاش کنید.';
  }
  if (
    code === 'auth/popup-closed-by-user' ||
    code === 'auth/cancelled-popup-request' ||
    msg.includes('auth/popup-closed-by-user')
  ) {
    return 'پنجره ورود با گوگل قبل از تکمیل بسته شد.';
  }
  if (code === 'auth/network-request-failed' || msg.includes('auth/network-request-failed')) {
    return 'خطا در اتصال به سرویس احراز هویت گوگل. لطفاً اتصال اینترنت خود را بررسی کنید.';
  }
  return msg || 'ورود با حساب گوگل انجام نشد.';
}

export async function loginWithGoogle(): Promise<User> {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    await syncUserProfileToFirestore(result.user);
    return result.user;
  } catch (error) {
    throw new Error(formatFirebaseAuthError(error));
  }
}

const inFlightProfileSyncs = new Map<string, Promise<void>>();
const syncedProfileSignatures = new Map<string, string>();

export async function logoutUser(): Promise<void> {
  syncedProfileSignatures.clear();
  await signOut(auth);
}

function isSignedInUser(expectedUid?: string): boolean {
  const current = auth.currentUser;
  if (!current || !current.emailVerified) return false;
  if (expectedUid && current.uid !== expectedUid) return false;
  return true;
}

export async function syncUserProfileToFirestore(user: User): Promise<void> {
  if (!user?.uid || !user.emailVerified || !isSignedInUser(user.uid)) return;
  const path = `users/${user.uid}`;
  const safeEmail = (user.email || 'user@nobitex.local').trim().slice(0, 254);
  const safeDisplayName =
    (user.displayName || safeEmail || 'Trader').trim().slice(0, 100) || 'Trader';
  const signature = `${safeEmail}|${safeDisplayName}`;

  if (syncedProfileSignatures.get(user.uid) === signature) {
    return;
  }

  const existingTask = inFlightProfileSyncs.get(user.uid);
  if (existingTask) {
    await existingTask;
    return;
  }

  const task = (async () => {
    try {
      // Ensure auth token is ready for Firestore security rules evaluation
      await user.getIdToken();
      if (!isSignedInUser(user.uid)) return;

      const userRef = doc(db, 'users', user.uid);
      const snap = await getDocFromServer(userRef).catch(() => getDoc(userRef));
      if (!isSignedInUser(user.uid)) return;

      if (!snap.exists()) {
        try {
          await setDoc(userRef, {
            uid: user.uid,
            email: safeEmail,
            displayName: safeDisplayName,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (createErr) {
          if (!isSignedInUser(user.uid)) return;
          // If another tab/process created the profile concurrently, fall back to update if needed
          const retrySnap = await getDocFromServer(userRef).catch(() => null);
          if (!isSignedInUser(user.uid)) return;
          if (retrySnap?.exists()) {
            const existingData = retrySnap.data() as {
              email?: string;
              displayName?: string;
            };
            if (
              existingData.email !== safeEmail ||
              existingData.displayName !== safeDisplayName
            ) {
              await updateDoc(userRef, {
                email: safeEmail,
                displayName: safeDisplayName,
                updatedAt: serverTimestamp(),
              });
            }
          } else {
            throw createErr;
          }
        }
      } else {
        const existingData = snap.data() as {
          email?: string;
          displayName?: string;
        };
        if (
          existingData.email !== safeEmail ||
          existingData.displayName !== safeDisplayName
        ) {
          await updateDoc(userRef, {
            email: safeEmail,
            displayName: safeDisplayName,
            updatedAt: serverTimestamp(),
          });
        }
      }

      syncedProfileSignatures.set(user.uid, signature);
    } catch (error) {
      if (!isSignedInUser(user.uid)) {
        return;
      }
      try {
        handleFirestoreError(error, 'write', path);
      } catch {
        // Non-fatal fallback
      }
    } finally {
      inFlightProfileSyncs.delete(user.uid);
    }
  })();

  inFlightProfileSyncs.set(user.uid, task);
  await task;
}

export async function syncApiKeyMetadataToFirestore(
  user: User,
  record: AppApiKeySummary
): Promise<void> {
  if (!isSignedInUser(user.uid)) return;
  const path = `users/${user.uid}/apiKeys/${record.id}`;
  try {
    await setDoc(doc(collection(db, 'users', user.uid, 'apiKeys'), record.id), {
      id: record.id,
      userId: user.uid,
      label: record.label,
      keyPrefix: record.keyPrefix,
      keyKind: 'APP_TOKEN',
      scopes: record.scopes,
      status: record.status,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser(user.uid)) return;
    try {
      handleFirestoreError(error, 'create', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function markApiKeyRevokedInFirestore(
  user: User,
  keyId: string
): Promise<void> {
  if (!isSignedInUser(user.uid)) return;
  const path = `users/${user.uid}/apiKeys/${keyId}`;
  try {
    await updateDoc(doc(db, 'users', user.uid, 'apiKeys', keyId), {
      status: 'REVOKED',
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser(user.uid)) return;
    try {
      handleFirestoreError(error, 'update', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function syncBillingConfigToFirestore(
  config: BillingPublicConfig
): Promise<void> {
  if (!isSignedInUser()) return;
  const path = 'appConfig/billing';
  try {
    await setDoc(doc(db, 'appConfig', 'billing'), {
      monthlyPriceToman: config.monthlyPriceToman,
      monthlyPriceUsdt: config.fixedUsdtPrice,
      autoUsdtFromRate: config.autoUsdtFromRate,
      usdtWalletAddress: config.usdtWalletAddress.slice(0, 200),
      usdtNetwork: config.usdtNetwork.slice(0, 40),
      usdtWalletAddress2: (config.usdtWalletAddress2 || '').slice(0, 200),
      usdtNetwork2: (config.usdtNetwork2 || '').slice(0, 40),
      zarinpalEnabled: config.zarinpalEnabled,
      zarinpalSandbox: config.zarinpalSandbox,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, 'write', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function syncPaymentRequestToFirestore(
  req: PaymentRequestRecord
): Promise<void> {
  if (!isSignedInUser(req.userId)) return;
  const path = `paymentRequests/${req.id}`;
  try {
    await setDoc(doc(db, 'paymentRequests', req.id), {
      id: req.id,
      userId: req.userId,
      userEmail: req.userEmail,
      userDisplayName: req.userDisplayName.slice(0, 100),
      method: req.method,
      status: 'PENDING',
      amountToman: req.amountToman,
      amountUsdt: req.amountUsdt,
      network: (req.network || '').slice(0, 40),
      walletAddress: (req.walletAddress || '').slice(0, 200),
      txHash: (req.txHash || '').slice(0, 200),
      authority: (req.authority || '').slice(0, 128),
      note: (req.note || '').slice(0, 300),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser(req.userId)) return;
    try {
      handleFirestoreError(error, 'create', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function syncPaymentReviewToFirestore(
  requestId: string,
  status: 'APPROVED' | 'REJECTED',
  adminNote?: string
): Promise<void> {
  if (!isSignedInUser()) return;
  const path = `paymentRequests/${requestId}`;
  try {
    await updateDoc(doc(db, 'paymentRequests', requestId), {
      status,
      adminNote: (adminNote || '').slice(0, 300),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, 'update', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function syncSubscriptionToFirestore(
  sub: UserSubscriptionSummary
): Promise<void> {
  if (!isSignedInUser()) return;
  const path = `subscriptions/${sub.userId}`;
  try {
    await setDoc(doc(db, 'subscriptions', sub.userId), {
      userId: sub.userId,
      email: sub.email.slice(0, 254),
      displayName: sub.displayName.slice(0, 100),
      plan: sub.plan,
      status: sub.status,
      paymentMethod: sub.paymentMethod,
      startAt: Timestamp.fromMillis(sub.startAt),
      expiresAt: Timestamp.fromMillis(sub.expiresAt),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, 'write', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function syncAppControlToFirestore(config: AppControlConfig): Promise<void> {
  if (!isSignedInUser()) return;
  const path = 'appConfig/appControl';
  try {
    await setDoc(doc(db, 'appConfig', 'appControl'), {
      maintenanceMode: config.maintenanceMode,
      maintenanceMessage: config.maintenanceMessage.slice(0, 500),
      promoFreeAccess: config.promoFreeAccess,
      promoBannerText: config.promoBannerText.slice(0, 300),
      supportPhone: config.supportPhone.slice(0, 40),
      supportTelegram: config.supportTelegram.slice(0, 100),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, 'write', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function syncBroadcastToFirestore(
  msg: BroadcastMessage,
  isUpdate = false
): Promise<void> {
  if (!isSignedInUser()) return;
  const path = `broadcasts/${msg.id}`;
  try {
    if (isUpdate) {
      await updateDoc(doc(db, 'broadcasts', msg.id), {
        title: msg.title.slice(0, 150),
        body: msg.body.slice(0, 2000),
        severity: msg.severity,
        active: msg.active,
        pinned: msg.pinned,
        updatedAt: serverTimestamp(),
      });
    } else {
      await setDoc(doc(db, 'broadcasts', msg.id), {
        id: msg.id,
        title: msg.title.slice(0, 150),
        body: msg.body.slice(0, 2000),
        severity: msg.severity,
        active: msg.active,
        pinned: msg.pinned,
        createdByEmail: msg.createdByEmail.slice(0, 254),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
    }
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, isUpdate ? 'update' : 'create', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function deleteBroadcastFromFirestore(broadcastId: string): Promise<void> {
  if (!isSignedInUser()) return;
  const path = `broadcasts/${broadcastId}`;
  try {
    await deleteDoc(doc(db, 'broadcasts', broadcastId));
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, 'delete', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function syncDirectMessageToFirestore(dm: DirectMessageRecord): Promise<void> {
  if (!isSignedInUser()) return;
  const path = `directMessages/${dm.id}`;
  try {
    await setDoc(doc(db, 'directMessages', dm.id), {
      id: dm.id,
      targetUserId: dm.targetUserId,
      targetUserEmail: dm.targetUserEmail.slice(0, 254),
      subject: dm.subject.slice(0, 150),
      body: dm.body.slice(0, 2000),
      severity: dm.severity,
      readByUser: false,
      senderEmail: dm.senderEmail.slice(0, 254),
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, 'create', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function markDirectMessageReadInFirestore(messageId: string): Promise<void> {
  if (!isSignedInUser()) return;
  const path = `directMessages/${messageId}`;
  try {
    await updateDoc(doc(db, 'directMessages', messageId), {
      readByUser: true,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, 'update', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function deleteDirectMessageFromFirestore(messageId: string): Promise<void> {
  if (!isSignedInUser()) return;
  const path = `directMessages/${messageId}`;
  try {
    await deleteDoc(doc(db, 'directMessages', messageId));
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, 'delete', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function fetchAllUsersFromFirestoreForAdmin(): Promise<
  Array<{ uid: string; email: string; displayName: string }>
> {
  if (!isSignedInUser()) return [];
  const path = 'users';
  try {
    const snap = await getDocs(collection(db, path));
    const list: Array<{ uid: string; email: string; displayName: string }> = [];
    snap.forEach((d) => {
      const data = d.data() as { uid?: string; email?: string; displayName?: string };
      if (data.uid || d.id) {
        list.push({
          uid: data.uid || d.id,
          email: data.email || '',
          displayName: data.displayName || data.email || 'کاربر',
        });
      }
    });
    return list;
  } catch (error) {
    if (!isSignedInUser()) return [];
    try {
      handleFirestoreError(error, 'list', path);
    } catch {
      // Non-fatal fallback
    }
    return [];
  }
}

export async function syncReferralRecordToFirestore(
  rec: AdminReferralRecord
): Promise<void> {
  if (!isSignedInUser(rec.referredUserUid)) return;
  const path = `referrals/${rec.id}`;
  try {
    await setDoc(doc(db, 'referrals', rec.id), {
      id: rec.id,
      referrerUid: rec.referrerUid,
      referredUserUid: rec.referredUserUid,
      referralCode: rec.referralCode.slice(0, 32),
      status: 'REGISTERED',
      rewardDays: 4,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser(rec.referredUserUid)) return;
    try {
      handleFirestoreError(error, 'create', path);
    } catch {
      // Non-fatal fallback
    }
  }
}

export async function syncReferralRewardedInFirestore(referralId: string): Promise<void> {
  if (!isSignedInUser()) return;
  const path = `referrals/${referralId}`;
  try {
    await updateDoc(doc(db, 'referrals', referralId), {
      status: 'REWARDED',
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    if (!isSignedInUser()) return;
    try {
      handleFirestoreError(error, 'update', path);
    } catch {
      // Non-fatal fallback
    }
  }
}
