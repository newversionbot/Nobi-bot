import type { QuoteCurrency } from '../types/trading';

export function formatPrice(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '—';
  const abs = Math.abs(value);
  if (abs === 0) return '0.00';
  if (abs >= 1000) {
    return value.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    });
  }
  if (abs >= 1) {
    return value.toLocaleString('en-US', {
      minimumFractionDigits: 2,
      maximumFractionDigits: 4,
    });
  }
  if (abs >= 0.01) {
    return value.toLocaleString('en-US', {
      minimumFractionDigits: 4,
      maximumFractionDigits: 6,
    });
  }
  if (abs >= 0.0001) {
    return value.toLocaleString('en-US', {
      minimumFractionDigits: 6,
      maximumFractionDigits: 8,
    });
  }
  return value.toLocaleString('en-US', {
    minimumFractionDigits: 8,
    maximumFractionDigits: 10,
  });
}

export function formatRawDecimalPrice(value: number | null | undefined): string {
  if (value === null || value === undefined || !Number.isFinite(value) || value <= 0) return '';
  const abs = Math.abs(value);
  const decimals =
    abs >= 100_000 ? 2 : abs >= 100 ? 4 : abs >= 1 ? 6 : abs >= 0.001 ? 8 : 10;
  return value.toFixed(decimals).replace(/\.?0+$/, '');
}

export function formatToman(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '—';
  const abs = Math.abs(value);
  if (abs === 0) return '0';
  if (abs >= 100) {
    return Math.round(value).toLocaleString('en-US');
  }
  if (abs >= 1) {
    return value.toLocaleString('en-US', { maximumFractionDigits: 2 });
  }
  return value.toLocaleString('en-US', { maximumFractionDigits: 4 });
}

export function normalizeEnglishNumberInput(raw: string, allowDecimal = true): string {
  if (!raw) return '';
  const ascii = raw
    .replace(/[\u06F0-\u06F9]/g, (d) => String(d.charCodeAt(0) - 0x06f0))
    .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[٫/]/g, '.')
    .replace(/[,٬\s]/g, '');

  let cleaned = ascii.replace(allowDecimal ? /[^0-9.]/g : /[^0-9]/g, '');
  if (allowDecimal) {
    const firstDot = cleaned.indexOf('.');
    if (firstDot !== -1) {
      cleaned =
        cleaned.slice(0, firstDot + 1) + cleaned.slice(firstDot + 1).replace(/\./g, '');
    }
  }
  return cleaned;
}

export function formatCompactToman(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '0 تومان';
  const abs = Math.abs(value);
  if (abs >= 1_000_000_000) return `${(value / 1_000_000_000).toFixed(2)} همت`;
  if (abs >= 1_000_000) return `${(value / 1_000_000).toFixed(1)} میلیون ت`;
  if (abs >= 1_000) return `${(value / 1_000).toFixed(0)} هزار ت`;
  return `${Math.round(value).toLocaleString('en-US')} ت`;
}

export function formatQuotePrice(value: number | null | undefined, quote: QuoteCurrency): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '—';
  if (quote === 'IRT') {
    const abs = Math.abs(value);
    const maxDecimals = abs >= 1000 ? 2 : abs >= 1 ? 4 : abs >= 0.001 ? 6 : 8;
    return `${value.toLocaleString('en-US', { maximumFractionDigits: maxDecimals })} ت`;
  }
  return `$${formatPrice(value)}`;
}

export function formatQuoteAmount(value: number | null | undefined, quote: QuoteCurrency): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '—';
  if (quote === 'IRT') return `${formatToman(value)} تومان`;
  return `${value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} USDT`;
}

export function formatQty(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '—';
  if (Math.abs(value) >= 1000) {
    return value.toLocaleString('en-US', { maximumFractionDigits: 2 });
  }
  if (Math.abs(value) >= 1) {
    return value.toLocaleString('en-US', { maximumFractionDigits: 4 });
  }
  return value.toLocaleString('en-US', { maximumFractionDigits: 6 });
}

export function formatCompactUsd(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '$0';
  const abs = Math.abs(value);
  if (abs >= 1_000_000_000) return `$${(value / 1_000_000_000).toFixed(2)}B`;
  if (abs >= 1_000_000) return `$${(value / 1_000_000).toFixed(2)}M`;
  if (abs >= 1_000) return `$${(value / 1_000).toFixed(1)}K`;
  return `$${value.toFixed(2)}`;
}

export function formatPercent(value: number | null | undefined): string {
  if (value === null || value === undefined || Number.isNaN(value)) return '0.00%';
  const sign = value > 0 ? '+' : '';
  return `${sign}${value.toFixed(2)}%`;
}

export function formatTimeShort(ts: number): string {
  return new Date(ts).toLocaleTimeString('fa-IR-u-nu-latn', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
    hour12: false,
  });
}

export function formatDateTimeShort(ts: number): string {
  return new Date(ts).toLocaleString('fa-IR-u-nu-latn', {
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  });
}
