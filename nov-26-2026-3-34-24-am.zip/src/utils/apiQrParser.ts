export type QrScanTarget = 'AUTO' | 'API_KEY' | 'SECRET_KEY' | 'TOKEN';

export interface ParsedQrCredentials {
  apiKey?: string;
  secretKey?: string;
  apiToken?: string;
  summary: string;
}

const API_KEY_ALIASES = new Set([
  'apikey',
  'api_key',
  'api-key',
  'nobitexkey',
  'nobitex_key',
  'nobitex-key',
  'accesskey',
  'access_key',
  'publickey',
  'public_key',
  'key',
]);

const SECRET_KEY_ALIASES = new Set([
  'secretkey',
  'secret_key',
  'secret-key',
  'privatekey',
  'private_key',
  'private-key',
  'ed25519privatekey',
  'ed25519_private_key',
  'nobitexsecret',
  'nobitex_secret',
  'secret',
]);

const TOKEN_ALIASES = new Set([
  'apitoken',
  'api_token',
  'api-token',
  'legacytoken',
  'legacy_token',
  'authtoken',
  'auth_token',
  'token',
  'authorization',
]);

function normalizeFieldKey(key: string): string {
  return key.trim().toLowerCase().replace(/\s+/g, '_');
}

function cleanScalarValue(raw: string): string {
  const trimmed = raw.trim();
  if (
    trimmed.length >= 2 &&
    ((trimmed.startsWith('"') && trimmed.endsWith('"')) ||
      (trimmed.startsWith("'") && trimmed.endsWith("'")))
  ) {
    return trimmed.slice(1, -1).trim();
  }
  return trimmed;
}

function isPemPrivateKey(text: string): boolean {
  return /-----BEGIN[\sA-Z0-9_-]*PRIVATE KEY-----/i.test(text);
}

function safePercentDecode(value: string): string {
  if (!/%[0-9A-Fa-f]{2}/.test(value)) {
    return value;
  }
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

function assignByAlias(
  rawKey: string,
  rawVal: unknown,
  out: { apiKey?: string; secretKey?: string; apiToken?: string }
): boolean {
  if (typeof rawVal !== 'string' && typeof rawVal !== 'number') return false;
  const val = cleanScalarValue(String(rawVal));
  if (!val) return false;
  const normalized = normalizeFieldKey(rawKey);
  if (API_KEY_ALIASES.has(normalized) && !out.apiKey) {
    out.apiKey = val;
    return true;
  }
  if (SECRET_KEY_ALIASES.has(normalized) && !out.secretKey) {
    out.secretKey = val;
    return true;
  }
  if (TOKEN_ALIASES.has(normalized) && !out.apiToken) {
    out.apiToken = val;
    return true;
  }
  return false;
}

function extractFromObject(
  obj: Record<string, unknown>,
  out: { apiKey?: string; secretKey?: string; apiToken?: string },
  depth = 0
): void {
  if (depth > 3) return;
  for (const [k, v] of Object.entries(obj)) {
    if (v && typeof v === 'object' && !Array.isArray(v)) {
      extractFromObject(v as Record<string, unknown>, out, depth + 1);
    } else {
      assignByAlias(k, v, out);
    }
  }
}

function tryParseStructuredJson(
  text: string
): { apiKey?: string; secretKey?: string; apiToken?: string } | null {
  const trimmed = text.trim();
  if (!trimmed.startsWith('{')) return null;
  try {
    const parsed = JSON.parse(trimmed) as unknown;
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) return null;
    const out: { apiKey?: string; secretKey?: string; apiToken?: string } = {};
    extractFromObject(parsed as Record<string, unknown>, out);
    if (out.apiKey || out.secretKey || out.apiToken) {
      return out;
    }
  } catch {
    return null;
  }
  return null;
}

function tryParseQueryOrUrl(
  text: string
): { apiKey?: string; secretKey?: string; apiToken?: string } | null {
  const trimmed = text.trim();
  let queryPart = '';

  const qIdx = trimmed.indexOf('?');
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(trimmed)) {
    if (qIdx === -1) return null;
    queryPart = trimmed.slice(qIdx + 1);
  } else if (trimmed.startsWith('?')) {
    queryPart = trimmed.slice(1);
  } else if (trimmed.includes('&') && trimmed.includes('=')) {
    queryPart = trimmed;
  } else {
    return null;
  }

  const hashIdx = queryPart.indexOf('#');
  if (hashIdx >= 0) {
    queryPart = queryPart.slice(0, hashIdx);
  }

  const out: { apiKey?: string; secretKey?: string; apiToken?: string } = {};
  for (const part of queryPart.split('&')) {
    const eqIdx = part.indexOf('=');
    if (eqIdx <= 0) continue;
    const rawKey = safePercentDecode(part.slice(0, eqIdx)).trim();
    const rawVal = safePercentDecode(part.slice(eqIdx + 1));
    assignByAlias(rawKey, rawVal, out);
  }

  if (out.apiKey || out.secretKey || out.apiToken) {
    return out;
  }
  return null;
}

function tryParseLabeledLines(
  text: string
): { apiKey?: string; secretKey?: string; apiToken?: string } | null {
  const out: { apiKey?: string; secretKey?: string; apiToken?: string } = {};

  // Extract multiline PEM block if embedded in labeled text
  const pemMatch = text.match(
    /-----BEGIN[\sA-Z0-9_-]*PRIVATE KEY-----[\s\S]+?-----END[\sA-Z0-9_-]*PRIVATE KEY-----/i
  );
  let remaining = text;
  if (pemMatch) {
    out.secretKey = pemMatch[0].trim();
    remaining = text.replace(pemMatch[0], '');
  }

  const normalizedRemaining = remaining.replace(/\r\n?/g, '\n');
  const segments = normalizedRemaining
    .split(/[\n;|]+/)
    .map((s) => s.trim())
    .filter(Boolean);

  for (const segment of segments) {
    const match = segment.match(/^([A-Za-z0-9_\-\s]{2,32})\s*[:=]\s*(.+)$/);
    if (!match) continue;
    const [, label, value] = match;
    assignByAlias(label, value, out);
  }

  if (out.apiKey || out.secretKey || out.apiToken) {
    return out;
  }
  return null;
}

function buildSummary(res: { apiKey?: string; secretKey?: string; apiToken?: string }): string {
  if (res.apiKey && res.secretKey) {
    return 'هر دو مقدار API Key و Secret Key با موفقیت از بارکد/QR استخراج و جای‌گذاری شدند.';
  }
  if (res.apiKey) {
    return 'کلید API (API Key) با موفقیت از بارکد/QR خوانده شد.';
  }
  if (res.secretKey) {
    return 'کلید مخفی (Secret Key) با موفقیت از بارکد/QR خوانده شد.';
  }
  if (res.apiToken) {
    return 'توکن نوبیتکس با موفقیت از بارکد/QR خوانده شد.';
  }
  return 'محتوای بارکد/QR خوانده شد.';
}

export function parseScannedCredentialsPayload(
  rawText: string,
  target: QrScanTarget,
  existing?: { apiKey?: string; secretKey?: string }
): ParsedQrCredentials {
  const cleaned = cleanScalarValue(rawText.replace(/\r\n?/g, '\n'));
  if (!cleaned) {
    throw new Error('بارکد یا QR اسکن‌شده خالی است.');
  }

  // 1) Structured JSON (supports filling both API Key + Secret Key together regardless of target)
  const jsonResult = tryParseStructuredJson(cleaned);
  if (jsonResult) {
    return {
      ...jsonResult,
      summary: buildSummary(jsonResult),
    };
  }

  // 2) Query string / URL
  const queryResult = tryParseQueryOrUrl(cleaned);
  if (queryResult) {
    return {
      ...queryResult,
      summary: buildSummary(queryResult),
    };
  }

  // 3) Labeled key:value lines (with optional embedded PEM block)
  const labeledResult = tryParseLabeledLines(cleaned);
  if (labeledResult && (labeledResult.apiKey || labeledResult.secretKey || labeledResult.apiToken)) {
    return {
      ...labeledResult,
      summary: buildSummary(labeledResult),
    };
  }

  // 4) Pure PEM private key -> always Secret Key
  if (isPemPrivateKey(cleaned)) {
    const res = { secretKey: cleaned };
    return { ...res, summary: buildSummary(res) };
  }

  // 5) Two-line raw pair (line 1 = API Key, line 2 = Secret Key)
  const lines = cleaned
    .split('\n')
    .map((l) => cleanScalarValue(l))
    .filter(Boolean);
  if (lines.length === 2 && (target === 'AUTO' || target === 'API_KEY' || target === 'SECRET_KEY')) {
    const res = { apiKey: lines[0], secretKey: lines[1] };
    return { ...res, summary: buildSummary(res) };
  }

  // 6) Single raw string assignment based on target
  const singleValue = lines.length === 1 ? lines[0] : cleaned;
  if (target === 'API_KEY') {
    const res = { apiKey: singleValue };
    return { ...res, summary: buildSummary(res) };
  }
  if (target === 'SECRET_KEY') {
    const res = { secretKey: singleValue };
    return { ...res, summary: buildSummary(res) };
  }
  if (target === 'TOKEN') {
    const res = { apiToken: singleValue };
    return { ...res, summary: buildSummary(res) };
  }

  // AUTO target for single raw string: fill missing API Key first, otherwise Secret Key
  if (!existing?.apiKey?.trim()) {
    const res = { apiKey: singleValue };
    return { ...res, summary: buildSummary(res) };
  }
  if (!existing?.secretKey?.trim()) {
    const res = { secretKey: singleValue };
    return { ...res, summary: buildSummary(res) };
  }
  const res = { apiKey: singleValue };
  return { ...res, summary: buildSummary(res) };
}
