import type {
  BotFundingMode,
  OrderBookLevel,
  OrderBookSnapshot,
  ProfitBotMarketPreview,
  ProfitBotStatus,
  QuoteCurrency,
} from '../types/trading';

export const DEFAULT_NOBITEX_FEE_RATE = 0.0025; // 0.25%

export interface ProfitBotStatusMeta {
  status: ProfitBotStatus;
  labelFa: string;
  shortDescFa: string;
  tone: 'cyan' | 'emerald' | 'amber' | 'rose' | 'slate';
}

export const PROFIT_BOT_STATUS_META: Record<ProfitBotStatus, ProfitBotStatusMeta> = {
  READY_TO_BUY: {
    status: 'READY_TO_BUY',
    labelFa: 'آماده خرید',
    shortDescFa: 'ربات تنظیم شده و آماده شروع بررسی بازار است.',
    tone: 'cyan',
  },
  CHECKING_MARKET: {
    status: 'CHECKING_MARKET',
    labelFa: 'در حال بررسی بازار',
    shortDescFa: 'دریافت دفتر سفارش و بررسی کارمزد، اسپرد و نقدینگی.',
    tone: 'cyan',
  },
  PLACING_BUY: {
    status: 'PLACING_BUY',
    labelFa: 'در حال ثبت سفارش خرید',
    shortDescFa: 'سفارش خرید ثبت شده و در انتظار تکمیل در صرافی است.',
    tone: 'amber',
  },
  BUY_FILLED: {
    status: 'BUY_FILLED',
    labelFa: 'خرید تکمیل شد',
    shortDescFa: 'خرید قطعی شد و قیمت میانگین و مقدار خالص ثبت گردید.',
    tone: 'emerald',
  },
  WAITING_FOR_PROFIT: {
    status: 'WAITING_FOR_PROFIT',
    labelFa: 'در انتظار رسیدن به سود',
    shortDescFa: 'پایش لحظه‌ای دفتر سفارش برای رسیدن به سود خالص هدف.',
    tone: 'cyan',
  },
  PROFIT_TARGET_REACHED: {
    status: 'PROFIT_TARGET_REACHED',
    labelFa: 'هدف سود محقق شد',
    shortDescFa: 'نقدینگی خریداران و قیمت فروش پس از کسر کارمزد به هدف رسید.',
    tone: 'emerald',
  },
  PLACING_SELL: {
    status: 'PLACING_SELL',
    labelFa: 'در حال ثبت سفارش فروش',
    shortDescFa: 'سفارش فروش ثبت شده و در انتظار تسویه نهایی است.',
    tone: 'amber',
  },
  SELL_FILLED: {
    status: 'SELL_FILLED',
    labelFa: 'فروش تکمیل شد',
    shortDescFa: 'معامله بسته شد و سود خالص واقعی در تاریخچه ثبت گردید.',
    tone: 'emerald',
  },
  STOPPED: {
    status: 'STOPPED',
    labelFa: 'معامله متوقف شد',
    shortDescFa: 'ربات به دستور کاربر یا پایان چرخه متوقف شده است.',
    tone: 'slate',
  },
  CONNECTION_ERROR: {
    status: 'CONNECTION_ERROR',
    labelFa: 'خطای اتصال',
    shortDescFa: 'اختلال موقت در اتصال صرافی؛ بدون ثبت سفارش تکراری منتظر بازیابی.',
    tone: 'rose',
  },
  PARTIAL_ORDER: {
    status: 'PARTIAL_ORDER',
    labelFa: 'سفارش ناقص',
    shortDescFa: 'بخشی از سفارش تکمیل شده؛ فقط مقدار واقعی مدیریت می‌شود.',
    tone: 'amber',
  },
  NEEDS_USER_REVIEW: {
    status: 'NEEDS_USER_REVIEW',
    labelFa: 'نیازمند بررسی کاربر',
    shortDescFa: 'زمان انتظار پایان یافته یا شرایط غیرعادی رخ داده است.',
    tone: 'rose',
  },
};

export function getProfitBotStatusMeta(status: ProfitBotStatus): ProfitBotStatusMeta {
  return PROFIT_BOT_STATUS_META[status] || PROFIT_BOT_STATUS_META.READY_TO_BUY;
}

export function getMinimumOrderNotional(quoteCurrency: QuoteCurrency): number {
  return quoteCurrency === 'IRT' ? 50_000 : 0.5;
}

export function roundQuoteValue(value: number, quoteCurrency: QuoteCurrency): number {
  if (!Number.isFinite(value)) return 0;
  return quoteCurrency === 'IRT' ? Math.round(value) : Number(value.toFixed(4));
}

export function getStepDecimals(step: number): number {
  if (!Number.isFinite(step) || step <= 0) return 6;
  if (step >= 1) return 0;
  const s = step.toString();
  if (s.includes('e-')) {
    const exp = Number(s.split('e-')[1]);
    return Number.isFinite(exp) ? Math.min(8, Math.max(0, exp)) : 6;
  }
  const dotIdx = s.indexOf('.');
  return dotIdx >= 0 ? Math.min(8, s.length - dotIdx - 1) : 6;
}

export function roundQuantityToStep(
  rawQty: number,
  step = 1e-6,
  mode: 'floor' | 'ceil' = 'floor'
): number {
  if (!Number.isFinite(rawQty) || rawQty <= 0) return 0;
  const safeStep = Number.isFinite(step) && step > 0 ? step : 1e-6;
  const decimals = getStepDecimals(safeStep);
  const ratio = rawQty / safeStep;
  const snappedUnits =
    mode === 'ceil' ? Math.ceil(ratio - 1e-9) : Math.floor(ratio + 1e-9);
  const qty = Math.max(0, snappedUnits) * safeStep;
  return Number(qty.toFixed(decimals));
}

export interface ResolvedOrderQuantityResult {
  ok: boolean;
  quantity: number;
  notional: number;
  bumpedForMinNotional: boolean;
  reason?: string;
}

export function resolveOrderQuantityForNotional(params: {
  entryAmount: number;
  buyPrice: number;
  minNotional: number;
  step?: number;
  freeQuote?: number;
  maxCapitalHeadroom?: number;
}): ResolvedOrderQuantityResult {
  const step = Number.isFinite(params.step) && (params.step ?? 0) > 0 ? Number(params.step) : 1e-6;
  const { entryAmount, buyPrice, minNotional } = params;
  if (!Number.isFinite(entryAmount) || !Number.isFinite(buyPrice) || entryAmount <= 0 || buyPrice <= 0) {
    return {
      ok: false,
      quantity: 0,
      notional: 0,
      bumpedForMinNotional: false,
      reason: 'قیمت یا مبلغ ورود نامعتبر است.',
    };
  }

  const rawQty = entryAmount / buyPrice;
  const floorQty = roundQuantityToStep(rawQty, step, 'floor');
  const floorNotional = floorQty * buyPrice;

  if (floorQty > 0 && floorNotional + 1e-6 >= minNotional) {
    return {
      ok: true,
      quantity: floorQty,
      notional: floorNotional,
      bumpedForMinNotional: false,
    };
  }

  // Only downward step rounding pushed a valid entryAmount below minNotional:
  // safely round up by 1 market step if wallet & capital headroom allow it within tolerance.
  const ceilQty = roundQuantityToStep(rawQty, step, 'ceil');
  const ceilNotional = ceilQty * buyPrice;
  const freeQuote = params.freeQuote ?? Infinity;
  const maxCapitalHeadroom = params.maxCapitalHeadroom ?? Infinity;
  const maxAllowedBump = Math.max(entryAmount * 1.25, minNotional * 1.25);

  if (
    entryAmount + 1e-6 >= minNotional &&
    ceilQty > 0 &&
    ceilNotional + 1e-6 >= minNotional &&
    ceilNotional <= freeQuote + 1e-6 &&
    ceilNotional <= maxCapitalHeadroom + step * buyPrice + 1e-6 &&
    ceilNotional <= maxAllowedBump + 1e-6
  ) {
    return {
      ok: true,
      quantity: ceilQty,
      notional: ceilNotional,
      bumpedForMinNotional: true,
    };
  }

  return {
    ok: false,
    quantity: floorQty,
    notional: floorNotional,
    bumpedForMinNotional: false,
  };
}

export interface ExistingBalanceAllocationResult {
  ok: boolean;
  freeBase: number;
  percent: number;
  rawQty: number;
  allocatedQty: number;
  referencePrice: number;
  notionalQuote: number;
  minNotional: number;
  reason?: string;
}

export function computeExistingBalanceAllocation(params: {
  freeBase: number;
  percent: number;
  referencePrice: number;
  minNotional: number;
  step?: number;
  maxCapitalQuote?: number | null;
  baseAsset?: string;
  quoteCurrency?: QuoteCurrency;
}): ExistingBalanceAllocationResult {
  const safeFree = Math.max(0, Number(params.freeBase) || 0);
  const clampedPct = Math.min(100, Math.max(1, Number(params.percent) || 0));
  const safePrice = Math.max(0, Number(params.referencePrice) || 0);
  const safeMinNotional = Math.max(0, Number(params.minNotional) || 0);
  const step = Number.isFinite(params.step) && (params.step ?? 0) > 0 ? Number(params.step) : 1e-6;
  const assetLabel = params.baseAsset || 'ارز';
  const qc = params.quoteCurrency === 'USDT' ? 'USDT' : 'تومان';

  if (safePrice <= 0) {
    return {
      ok: false,
      freeBase: safeFree,
      percent: clampedPct,
      rawQty: 0,
      allocatedQty: 0,
      referencePrice: safePrice,
      notionalQuote: 0,
      minNotional: safeMinNotional,
      reason: 'قیمت لحظه‌ای بازار برای ارزش‌گذاری موجودی فعلی در دسترس نیست.',
    };
  }

  if (safeFree <= 0) {
    return {
      ok: false,
      freeBase: 0,
      percent: clampedPct,
      rawQty: 0,
      allocatedQty: 0,
      referencePrice: safePrice,
      notionalQuote: 0,
      minNotional: safeMinNotional,
      reason: `موجودی آزاد ${assetLabel} در کیف پول شما صفر است.`,
    };
  }

  let rawQty = safeFree * (clampedPct / 100);
  if (params.maxCapitalQuote && params.maxCapitalQuote > 0) {
    const capQty = params.maxCapitalQuote / safePrice;
    if (capQty < rawQty) rawQty = capQty;
  }

  const allocatedQty = roundQuantityToStep(rawQty, step, 'floor');
  const notionalQuote = allocatedQty * safePrice;

  if (allocatedQty <= 0 || notionalQuote + 1e-6 < safeMinNotional) {
    const minStr =
      params.quoteCurrency === 'USDT'
        ? `${safeMinNotional} USDT`
        : `${Math.round(safeMinNotional).toLocaleString('en-US')} ${qc}`;
    const actualStr =
      params.quoteCurrency === 'USDT'
        ? `${Number(notionalQuote.toFixed(4))} USDT`
        : `${Math.round(notionalQuote).toLocaleString('en-US')} ${qc}`;
    return {
      ok: false,
      freeBase: safeFree,
      percent: clampedPct,
      rawQty,
      allocatedQty,
      referencePrice: safePrice,
      notionalQuote,
      minNotional: safeMinNotional,
      reason: `مقدار تخصیص‌یافته از موجودی ${assetLabel} (${allocatedQty} ≈ ${actualStr}) کمتر از حداقل مجاز سفارش نوبیتکس (${minStr}) است؛ درصد استفاده یا موجودی را افزایش دهید.`,
    };
  }

  return {
    ok: true,
    freeBase: safeFree,
    percent: clampedPct,
    rawQty,
    allocatedQty,
    referencePrice: safePrice,
    notionalQuote,
    minNotional: safeMinNotional,
  };
}

export interface OrderBookBuySimulation {
  bestAsk: number;
  canFillFull: boolean;
  fillableQuote: number;
  grossQty: number;
  avgBuyPrice: number;
  slippagePercent: number;
  estimatedBuyFeeQuote: number;
  netQtyReceived: number;
  /** Total quote outlay required from wallet (buy fee is already accounted for in netQtyReceived). */
  totalBuyCostQuote: number;
  spread: number;
  spreadPercent: number;
}

export function simulateOrderBookBuy(
  orderBook: Pick<OrderBookSnapshot, 'asks' | 'bids' | 'spread' | 'spreadPercent'>,
  quoteBudget: number,
  feeRate = DEFAULT_NOBITEX_FEE_RATE
): OrderBookBuySimulation {
  const safeBudget = Math.max(0, Number(quoteBudget) || 0);
  const safeFeeRate = Math.min(0.05, Math.max(0, Number(feeRate) || 0));

  const sortedAsks: OrderBookLevel[] = [...(orderBook.asks || [])]
    .filter((lvl) => Number(lvl.price) > 0 && Number(lvl.quantity) > 0)
    .sort((a, b) => a.price - b.price);

  const sortedBids: OrderBookLevel[] = [...(orderBook.bids || [])]
    .filter((lvl) => Number(lvl.price) > 0 && Number(lvl.quantity) > 0)
    .sort((a, b) => b.price - a.price);

  const bestAsk = sortedAsks[0]?.price || 0;
  const bestBid = sortedBids[0]?.price || 0;
  const spread = bestAsk > 0 && bestBid > 0 ? Math.max(0, bestAsk - bestBid) : Math.max(0, orderBook.spread || 0);
  const spreadPercent = bestAsk > 0 ? (spread / bestAsk) * 100 : Math.max(0, orderBook.spreadPercent || 0);

  if (safeBudget <= 0 || sortedAsks.length === 0 || bestAsk <= 0) {
    return {
      bestAsk,
      canFillFull: false,
      fillableQuote: 0,
      grossQty: 0,
      avgBuyPrice: 0,
      slippagePercent: 0,
      estimatedBuyFeeQuote: 0,
      netQtyReceived: 0,
      totalBuyCostQuote: 0,
      spread,
      spreadPercent,
    };
  }

  let remainingQuote = safeBudget;
  let fillableQuote = 0;
  let grossQty = 0;

  for (const level of sortedAsks) {
    if (remainingQuote <= 1e-8) break;
    const levelQuoteCapacity = level.price * level.quantity;
    if (levelQuoteCapacity <= remainingQuote) {
      fillableQuote += levelQuoteCapacity;
      grossQty += level.quantity;
      remainingQuote -= levelQuoteCapacity;
    } else {
      const takeQty = remainingQuote / level.price;
      fillableQuote += remainingQuote;
      grossQty += takeQty;
      remainingQuote = 0;
      break;
    }
  }

  const canFillFull = remainingQuote <= Math.max(1e-6, safeBudget * 1e-6);
  const avgBuyPrice = grossQty > 0 ? fillableQuote / grossQty : 0;
  const slippagePercent =
    bestAsk > 0 && avgBuyPrice > 0 ? Math.max(0, ((avgBuyPrice - bestAsk) / bestAsk) * 100) : 0;
  const estimatedBuyFeeQuote = fillableQuote * safeFeeRate;
  const netQtyReceived = grossQty * (1 - safeFeeRate);

  return {
    bestAsk,
    canFillFull,
    fillableQuote,
    grossQty,
    avgBuyPrice,
    slippagePercent,
    estimatedBuyFeeQuote,
    netQtyReceived,
    totalBuyCostQuote: fillableQuote,
    spread,
    spreadPercent,
  };
}

export interface OrderBookSellSimulation {
  bestBid: number;
  hasSufficientDepth: boolean;
  fillableQty: number;
  executableAvgSellPrice: number;
  slippagePercent: number;
  grossProceedsQuote: number;
  sellFeeQuote: number;
  otherFeesQuote: number;
  netProceedsAfterSellFeeQuote: number;
  /** Exact realizable net profit when selling FULL netOwnedQty into orderbook bids. When depth is insufficient, uses covered bid proceeds minus proportional/total cost conservatively so target cannot fire prematurely. */
  netProfitQuote: number;
  /** Extrapolated net profit if full qty sold at avg bid price (for informational UI display only, NEVER for triggering sell). */
  indicativeNetProfitQuote: number;
  requiredSellPrice: number;
  canTriggerTarget: boolean;
  spread: number;
  spreadPercent: number;
}

/**
 * Simulates selling exact `netOwnedQty` across live order book `bids` (highest price first).
 *
 * CRITICAL ACCOUNTING INVARIANT:
 * `totalBuyCostQuote` MUST already represent full quote spent including any buy fee
 * (since `netOwnedQty` is already after Nobitex base-asset buy fee deduction).
 * Therefore `netProfitQuote = grossSellProceedsQuote - totalBuyCostQuote - sellFeeQuote - otherFeesQuote`
 * without double-counting the buy fee.
 */
export function simulateOrderBookSell(
  orderBook: Pick<OrderBookSnapshot, 'asks' | 'bids' | 'spread' | 'spreadPercent'>,
  netOwnedQty: number,
  totalBuyCostQuote: number,
  targetNetProfit: number,
  feeRate = DEFAULT_NOBITEX_FEE_RATE,
  otherFeesQuote = 0,
  customTargetSellPrice?: number | null
): OrderBookSellSimulation {
  const safeQty = Math.max(0, Number(netOwnedQty) || 0);
  const safeBuyCost = Math.max(0, Number(totalBuyCostQuote) || 0);
  const safeTarget = Math.max(0, Number(targetNetProfit) || 0);
  const safeFeeRate = Math.min(0.05, Math.max(0, Number(feeRate) || 0));
  const safeOtherFees = Math.max(0, Number(otherFeesQuote) || 0);
  const safeCustomSell =
    customTargetSellPrice && Number.isFinite(customTargetSellPrice) && customTargetSellPrice > 0
      ? Number(customTargetSellPrice)
      : null;

  const sortedBids: OrderBookLevel[] = [...(orderBook.bids || [])]
    .filter((lvl) => Number(lvl.price) > 0 && Number(lvl.quantity) > 0)
    .sort((a, b) => b.price - a.price);

  const sortedAsks: OrderBookLevel[] = [...(orderBook.asks || [])]
    .filter((lvl) => Number(lvl.price) > 0 && Number(lvl.quantity) > 0)
    .sort((a, b) => a.price - b.price);

  const bestBid = sortedBids[0]?.price || 0;
  const bestAsk = sortedAsks[0]?.price || 0;
  const spread = bestAsk > 0 && bestBid > 0 ? Math.max(0, bestAsk - bestBid) : Math.max(0, orderBook.spread || 0);
  const spreadPercent = bestAsk > 0 ? (spread / bestAsk) * 100 : Math.max(0, orderBook.spreadPercent || 0);
  const computedReqSellPrice = computeRequiredSellPrice(
    safeQty,
    safeBuyCost,
    safeTarget,
    safeFeeRate,
    safeOtherFees
  );
  const requiredSellPrice = safeCustomSell ?? computedReqSellPrice;

  if (safeQty <= 0 || sortedBids.length === 0 || bestBid <= 0) {
    return {
      bestBid,
      hasSufficientDepth: false,
      fillableQty: 0,
      executableAvgSellPrice: 0,
      slippagePercent: 0,
      grossProceedsQuote: 0,
      sellFeeQuote: 0,
      otherFeesQuote: safeOtherFees,
      netProceedsAfterSellFeeQuote: 0,
      netProfitQuote: -safeBuyCost - safeOtherFees,
      indicativeNetProfitQuote: -safeBuyCost - safeOtherFees,
      requiredSellPrice,
      canTriggerTarget: false,
      spread,
      spreadPercent,
    };
  }

  let remainingQty = safeQty;
  let fillableQty = 0;
  let grossProceedsQuote = 0;

  for (const level of sortedBids) {
    if (remainingQty <= 1e-10) break;
    const takeQty = Math.min(remainingQty, level.quantity);
    fillableQty += takeQty;
    grossProceedsQuote += takeQty * level.price;
    remainingQty -= takeQty;
  }

  const hasSufficientDepth = remainingQty <= Math.max(1e-9, safeQty * 1e-6);
  const executableAvgSellPrice = fillableQty > 0 ? grossProceedsQuote / fillableQty : 0;
  const slippagePercent =
    bestBid > 0 && executableAvgSellPrice > 0
      ? Math.max(0, ((bestBid - executableAvgSellPrice) / bestBid) * 100)
      : 0;

  const sellFeeQuote = grossProceedsQuote * safeFeeRate;
  const netProceedsAfterSellFeeQuote = grossProceedsQuote - sellFeeQuote - safeOtherFees;
  const netProfitQuote = netProceedsAfterSellFeeQuote - safeBuyCost;

  const fullIndicativeGross = safeQty * executableAvgSellPrice;
  const fullIndicativeSellFee = fullIndicativeGross * safeFeeRate;
  const indicativeNetProfitQuote =
    fullIndicativeGross - fullIndicativeSellFee - safeOtherFees - safeBuyCost;

  const canTriggerTarget = safeCustomSell
    ? hasSufficientDepth && executableAvgSellPrice + 1e-9 >= safeCustomSell
    : hasSufficientDepth && netProfitQuote >= safeTarget - Math.max(1e-6, safeTarget * 1e-6);

  return {
    bestBid,
    hasSufficientDepth,
    fillableQty,
    executableAvgSellPrice,
    slippagePercent,
    grossProceedsQuote,
    sellFeeQuote,
    otherFeesQuote: safeOtherFees,
    netProceedsAfterSellFeeQuote,
    netProfitQuote,
    indicativeNetProfitQuote,
    requiredSellPrice,
    canTriggerTarget,
    spread,
    spreadPercent,
  };
}

export function computeRequiredSellPrice(
  netOwnedQty: number,
  totalBuyCostQuote: number,
  targetNetProfit: number,
  feeRate = DEFAULT_NOBITEX_FEE_RATE,
  otherFeesQuote = 0
): number {
  const denom = netOwnedQty * Math.max(0.5, 1 - Math.max(0, feeRate));
  if (!Number.isFinite(denom) || denom <= 0) return 0;
  const numerator =
    Math.max(0, totalBuyCostQuote) +
    Math.max(0, targetNetProfit) +
    Math.max(0, otherFeesQuote);
  return numerator / denom;
}

export function computeProfitProgressPercent(
  currentNetProfitQuote: number,
  targetNetProfit: number
): number {
  if (!Number.isFinite(currentNetProfitQuote) || !Number.isFinite(targetNetProfit) || targetNetProfit <= 0) {
    return currentNetProfitQuote > 0 ? 100 : 0;
  }
  const raw = (currentNetProfitQuote / targetNetProfit) * 100;
  return Math.max(0, Math.min(100, raw));
}

export interface ProfitBotTargetProgress {
  currentPrice: number;
  targetSellPrice: number;
  priceGapQuote: number;
  distanceToTargetPercent: number;
  priceProgressPercent: number;
  profitProgressPercent: number;
  visualBarPercent: number;
  isPriceReached: boolean;
}

export function computeProfitBotTargetProgress(params: {
  actualBuyAvgPrice?: number | null;
  currentPrice: number;
  targetSellPrice: number;
  currentNetProfitQuote: number;
  targetNetProfit: number;
  hasActivePosition: boolean;
  isSellCompleted?: boolean;
}): ProfitBotTargetProgress {
  const currentPrice = Math.max(0, Number(params.currentPrice) || 0);
  const targetSellPrice = Math.max(0, Number(params.targetSellPrice) || 0);
  const actualBuyPrice = Math.max(0, Number(params.actualBuyAvgPrice) || 0);

  const profitProgressPercent = params.hasActivePosition
    ? computeProfitProgressPercent(params.currentNetProfitQuote, params.targetNetProfit)
    : params.isSellCompleted
      ? 100
      : 0;

  const priceGapQuote =
    targetSellPrice > 0 && currentPrice > 0 ? Math.max(0, targetSellPrice - currentPrice) : 0;
  const distanceToTargetPercent =
    targetSellPrice > 0 && currentPrice > 0
      ? Math.max(0, ((targetSellPrice - currentPrice) / currentPrice) * 100)
      : 0;
  const isPriceReached =
    params.hasActivePosition && targetSellPrice > 0 && currentPrice >= targetSellPrice;

  let priceProgressPercent = 0;
  if (params.hasActivePosition && targetSellPrice > 0 && currentPrice > 0) {
    if (currentPrice >= targetSellPrice) {
      priceProgressPercent = 100;
    } else if (actualBuyPrice > 0 && targetSellPrice > actualBuyPrice) {
      const ratio = ((currentPrice - actualBuyPrice) / (targetSellPrice - actualBuyPrice)) * 100;
      priceProgressPercent = Math.max(0, Math.min(100, ratio));
    } else {
      priceProgressPercent = Math.max(0, Math.min(100, (currentPrice / targetSellPrice) * 100));
    }
  } else if (params.isSellCompleted) {
    priceProgressPercent = 100;
  }

  // Visual bar prioritizes realized/live net profit progress once positive,
  // and blends price-climb progress before fee breakeven so movement toward Target Sell Price stays visible.
  const visualBarPercent = params.hasActivePosition
    ? profitProgressPercent > 0
      ? profitProgressPercent
      : Math.min(25, priceProgressPercent * 0.4)
    : params.isSellCompleted
      ? 100
      : 0;

  return {
    currentPrice,
    targetSellPrice,
    priceGapQuote,
    distanceToTargetPercent,
    priceProgressPercent,
    profitProgressPercent,
    visualBarPercent,
    isPriceReached,
  };
}

export function buildProfitBotMarketPreview(
  orderBook: OrderBookSnapshot,
  entryAmount: number,
  targetNetProfit: number,
  feeRate = DEFAULT_NOBITEX_FEE_RATE,
  otherFeesQuote = 0,
  options?: {
    fundingMode?: BotFundingMode;
    freeBaseBalance?: number;
    existingBalancePercent?: number;
    existingEntryPrice?: number | null;
    amountStep?: number;
    minNotional?: number;
  }
): ProfitBotMarketPreview {
  const baseAsset = orderBook.symbol.replace(/(IRT|USDT|RLS)$/i, '') || 'BTC';
  const fundingMode = options?.fundingMode || 'QUOTE_BUY';
  const sortedBids = [...(orderBook.bids || [])]
    .filter((lvl) => Number(lvl.price) > 0 && Number(lvl.quantity) > 0)
    .sort((a, b) => b.price - a.price);
  const sortedAsks = [...(orderBook.asks || [])]
    .filter((lvl) => Number(lvl.price) > 0 && Number(lvl.quantity) > 0)
    .sort((a, b) => a.price - b.price);
  const bestBid = sortedBids[0]?.price || orderBook.lastTradePrice || 0;
  const bestAsk = sortedAsks[0]?.price || orderBook.lastTradePrice || 0;

  if (fundingMode !== 'QUOTE_BUY') {
    const refEntryPrice =
      options?.existingEntryPrice && options.existingEntryPrice > 0
        ? options.existingEntryPrice
        : bestBid || bestAsk;
    const minNotional = options?.minNotional ?? getMinimumOrderNotional(orderBook.quoteCurrency);
    const alloc = computeExistingBalanceAllocation({
      freeBase: options?.freeBaseBalance ?? 0,
      percent: options?.existingBalancePercent ?? 50,
      referencePrice: refEntryPrice,
      minNotional,
      step: options?.amountStep ?? 1e-6,
      baseAsset,
      quoteCurrency: orderBook.quoteCurrency,
    });

    if (alloc.ok || fundingMode === 'EXISTING_ASSET') {
      const qty = alloc.allocatedQty;
      const totalBuyCostQuote = qty * refEntryPrice;
      const reqSellPrice = computeRequiredSellPrice(
        qty,
        totalBuyCostQuote,
        targetNetProfit,
        feeRate,
        otherFeesQuote
      );
      const sellSim = simulateOrderBookSell(
        orderBook,
        qty,
        totalBuyCostQuote,
        targetNetProfit,
        feeRate,
        otherFeesQuote
      );
      const risePct =
        refEntryPrice > 0 && reqSellPrice > 0
          ? ((reqSellPrice - refEntryPrice) / refEntryPrice) * 100
          : 0;
      const spread = bestAsk > 0 && bestBid > 0 ? Math.max(0, bestAsk - bestBid) : Math.max(0, orderBook.spread || 0);
      const spreadPercent = bestAsk > 0 ? (spread / bestAsk) * 100 : Math.max(0, orderBook.spreadPercent || 0);

      return {
        symbol: orderBook.symbol,
        baseAsset,
        quoteCurrency: orderBook.quoteCurrency,
        bestBid: sellSim.bestBid || bestBid,
        bestAsk,
        spread,
        spreadPercent,
        buySimulation: {
          canFillFull: alloc.ok,
          fillableQuote: totalBuyCostQuote,
          avgBuyPrice: refEntryPrice,
          slippagePercent: 0,
          grossQty: qty,
          estimatedBuyFeeQuote: 0,
          netQtyReceived: qty,
          totalBuyCostQuote,
        },
        estimatedRequiredSellPrice: reqSellPrice,
        estimatedRequiredRisePercent: risePct,
        sellAtCurrentBook: {
          hasSufficientDepth: sellSim.hasSufficientDepth,
          fillableQty: sellSim.fillableQty,
          executableAvgSellPrice: sellSim.executableAvgSellPrice,
          grossProceedsQuote: sellSim.grossProceedsQuote,
          estimatedSellFeeQuote: sellSim.sellFeeQuote,
          netProfitQuote: sellSim.netProfitQuote,
        },
      };
    }
  }

  const buySim = simulateOrderBookBuy(orderBook, entryAmount, feeRate);
  const reqSellPrice = computeRequiredSellPrice(
    buySim.netQtyReceived,
    buySim.totalBuyCostQuote,
    targetNetProfit,
    feeRate,
    otherFeesQuote
  );
  const sellSim = simulateOrderBookSell(
    orderBook,
    buySim.netQtyReceived,
    buySim.totalBuyCostQuote,
    targetNetProfit,
    feeRate,
    otherFeesQuote
  );
  const risePct =
    buySim.avgBuyPrice > 0 && reqSellPrice > 0
      ? ((reqSellPrice - buySim.avgBuyPrice) / buySim.avgBuyPrice) * 100
      : 0;

  return {
    symbol: orderBook.symbol,
    baseAsset,
    quoteCurrency: orderBook.quoteCurrency,
    bestBid: sellSim.bestBid,
    bestAsk: buySim.bestAsk,
    spread: buySim.spread,
    spreadPercent: buySim.spreadPercent,
    buySimulation: {
      canFillFull: buySim.canFillFull,
      fillableQuote: buySim.fillableQuote,
      avgBuyPrice: buySim.avgBuyPrice,
      slippagePercent: buySim.slippagePercent,
      grossQty: buySim.grossQty,
      estimatedBuyFeeQuote: buySim.estimatedBuyFeeQuote,
      netQtyReceived: buySim.netQtyReceived,
      totalBuyCostQuote: buySim.totalBuyCostQuote,
    },
    estimatedRequiredSellPrice: reqSellPrice,
    estimatedRequiredRisePercent: risePct,
    sellAtCurrentBook: {
      hasSufficientDepth: sellSim.hasSufficientDepth,
      fillableQty: sellSim.fillableQty,
      executableAvgSellPrice: sellSim.executableAvgSellPrice,
      grossProceedsQuote: sellSim.grossProceedsQuote,
      estimatedSellFeeQuote: sellSim.sellFeeQuote,
      netProfitQuote: sellSim.netProfitQuote,
    },
  };
}
