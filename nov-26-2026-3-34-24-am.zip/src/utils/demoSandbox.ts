import type {
  AiCoinAnalysis,
  AiCycleProCapitalUsageMode,
  AiCycleProConfig,
  AiCycleProCycleRecord,
  AiCycleProDecision,
  AiCycleProLog,
  AiCycleProMarketPreview,
  AiManagerAnalysis,
  BacktestResult,
  BacktestTrade,
  BotExecutionLog,
  BotStrategyConfig,
  BotType,
  CoinSentimentAnalysis,
  DcaBotConfig,
  DirectMessageRecord,
  FeatureIdeaItem,
  GridBotConfig,
  IndicatorSnapshot,
  KlineCandle,
  PendingBotConfirmation,
  PeriodicPriceWatcher,
  PortfolioAssetPerformance,
  PortfolioPerformanceSummary,
  PriceAlert,
  PricePulseNotification,
  ProfitBotConfig,
  ProfitBotCycleRecord,
  ProfitBotDecisionLog,
  OrderBookSnapshot,
  QuoteCurrency,
  SharedBotRiskSettings,
  SpotBalance,
  SpotOrder,
  TelegramBotSummary,
  TelegramSentLogEntry,
  Timeframe,
  UnifiedBotSummaryRow,
  UnifiedBotsDashboardSummary,
  UnifiedMarketTicker,
  UserReferralSummary,
} from '../types/trading';
import {
  computeExistingBalanceAllocation,
  computeProfitProgressPercent,
  computeRequiredSellPrice,
  DEFAULT_NOBITEX_FEE_RATE,
  getMinimumOrderNotional,
  resolveOrderQuantityForNotional,
  roundQuoteValue,
  simulateOrderBookBuy,
  simulateOrderBookSell,
} from './profitBotMath';
import { formatPrice, formatQuotePrice, formatToman } from './format';

export interface DemoSandboxState {
  balances: SpotBalance[];
  costBasisMap: Record<string, { asset: string; price: number; quoteCurrency: QuoteCurrency }>;
  openOrders: SpotOrder[];
  orderHistory: SpotOrder[];
  bots: BotStrategyConfig[];
  botLogs: BotExecutionLog[];
  profitBots: ProfitBotConfig[];
  profitBotCycles: ProfitBotCycleRecord[];
  profitBotLogs: ProfitBotDecisionLog[];
  aiCycleProBots: AiCycleProConfig[];
  aiCycleProCycles: AiCycleProCycleRecord[];
  aiCycleProLogs: AiCycleProLog[];
  gridBots: GridBotConfig[];
  dcaBots: DcaBotConfig[];
  riskSettings: SharedBotRiskSettings;
  pendingConfirmations: PendingBotConfirmation[];
  aiManagerReport: AiManagerAnalysis;
  alerts: PriceAlert[];
  watchers: PeriodicPriceWatcher[];
  pulses: PricePulseNotification[];
  ideas: FeatureIdeaItem[];
  telegram: TelegramBotSummary;
  referral: UserReferralSummary;
  directMessages: DirectMessageRecord[];
}

const DEFAULT_USDT_RATE = 79_500;

function getFallbackPrice(
  asset: string,
  markets: UnifiedMarketTicker[],
  usdtRate: number
): { toman: number; usdt: number; persianName: string } {
  const m = markets.find((x) => x.baseAsset === asset);
  if (m && (m.priceToman > 0 || m.priceUsdt > 0)) {
    const usdt = m.priceUsdt > 0 ? m.priceUsdt : usdtRate > 0 ? m.priceToman / usdtRate : 0;
    const toman = m.priceToman > 0 ? m.priceToman : usdt * usdtRate;
    return { toman, usdt, persianName: m.persianName || asset };
  }
  const defaults: Record<string, { usdt: number; persianName: string }> = {
    IRT: { usdt: 1 / (usdtRate || DEFAULT_USDT_RATE), persianName: 'تومان' },
    USDT: { usdt: 1, persianName: 'تتر' },
    BTC: { usdt: 91_400, persianName: 'بیت‌کوین' },
    ETH: { usdt: 3_180, persianName: 'اتریوم' },
    TON: { usdt: 5.45, persianName: 'تون‌کوین' },
    SOL: { usdt: 196, persianName: 'سولانا' },
    XRP: { usdt: 2.38, persianName: 'ریپل' },
    DOGE: { usdt: 0.34, persianName: 'دوج‌کوین' },
  };
  const d = defaults[asset] || { usdt: 10, persianName: asset };
  return {
    usdt: d.usdt,
    toman: d.usdt * (usdtRate || DEFAULT_USDT_RATE),
    persianName: d.persianName,
  };
}

export function buildDemoBalances(
  markets: UnifiedMarketTicker[],
  usdtTomanRate: number,
  previousBalances?: SpotBalance[]
): SpotBalance[] {
  const rate = usdtTomanRate > 0 ? usdtTomanRate : DEFAULT_USDT_RATE;
  const seedQuantities: Array<{ asset: string; free: number; locked: number }> = previousBalances
    ? previousBalances.map((b) => ({ asset: b.asset, free: b.free, locked: b.locked }))
    : [
        { asset: 'IRT', free: 145_000_000, locked: 15_000_000 },
        { asset: 'USDT', free: 1_250, locked: 180 },
        { asset: 'BTC', free: 0.0095, locked: 0 },
        { asset: 'ETH', free: 0.32, locked: 0.05 },
        { asset: 'TON', free: 120, locked: 0 },
        { asset: 'SOL', free: 3.5, locked: 0 },
      ];

  return seedQuantities
    .filter((x) => x.free > 0 || x.locked > 0 || x.asset === 'IRT' || x.asset === 'USDT')
    .map((item) => {
      const total = item.free + item.locked;
      if (item.asset === 'IRT') {
        return {
          asset: 'IRT',
          persianName: 'تومان',
          free: item.free,
          locked: item.locked,
          total,
          tomanValue: total,
          usdtValue: rate > 0 ? total / rate : 0,
        };
      }
      if (item.asset === 'USDT') {
        return {
          asset: 'USDT',
          persianName: 'تتر',
          free: item.free,
          locked: item.locked,
          total,
          tomanValue: total * rate,
          usdtValue: total,
        };
      }
      const px = getFallbackPrice(item.asset, markets, rate);
      return {
        asset: item.asset,
        persianName: px.persianName,
        free: item.free,
        locked: item.locked,
        total,
        tomanValue: total * px.toman,
        usdtValue: total * px.usdt,
      };
    });
}

export function computeDemoPortfolioPerformance(
  balances: SpotBalance[],
  costBasisMap: DemoSandboxState['costBasisMap'],
  markets: UnifiedMarketTicker[],
  usdtTomanRate: number
): PortfolioPerformanceSummary {
  const rate = usdtTomanRate > 0 ? usdtTomanRate : DEFAULT_USDT_RATE;
  let totalCurrentToman = 0;
  let totalCurrentUsdt = 0;
  let cashToman = 0;
  let cashUsdt = 0;
  let cryptoCurrentToman = 0;
  let cryptoCurrentUsdt = 0;
  let cryptoCostBasisToman = 0;
  let cryptoCostBasisUsdt = 0;

  const assets: PortfolioAssetPerformance[] = [];

  for (const b of balances) {
    totalCurrentToman += b.tomanValue;
    totalCurrentUsdt += b.usdtValue;
    if (b.asset === 'IRT' || b.asset === 'USDT') {
      cashToman += b.tomanValue;
      cashUsdt += b.usdtValue;
      continue;
    }

    const qty = b.total;
    if (qty <= 0) continue;

    const px = getFallbackPrice(b.asset, markets, rate);
    const cb = costBasisMap[b.asset];
    const avgBuyPriceToman = cb
      ? cb.quoteCurrency === 'USDT'
        ? cb.price * rate
        : cb.price
      : px.toman * 0.91;
    const avgBuyPriceUsdt = rate > 0 ? avgBuyPriceToman / rate : px.usdt * 0.91;

    const currentValueToman = qty * px.toman;
    const currentValueUsdt = qty * px.usdt;
    const costBasisToman = qty * avgBuyPriceToman;
    const costBasisUsdt = qty * avgBuyPriceUsdt;
    const pnlToman = currentValueToman - costBasisToman;
    const pnlUsdt = currentValueUsdt - costBasisUsdt;
    const pnlPercentToman = costBasisToman > 0 ? (pnlToman / costBasisToman) * 100 : 0;
    const pnlPercentUsdt = costBasisUsdt > 0 ? (pnlUsdt / costBasisUsdt) * 100 : 0;

    cryptoCurrentToman += currentValueToman;
    cryptoCurrentUsdt += currentValueUsdt;
    cryptoCostBasisToman += costBasisToman;
    cryptoCostBasisUsdt += costBasisUsdt;

    assets.push({
      asset: b.asset,
      persianName: px.persianName,
      quantity: qty,
      avgBuyPriceToman,
      avgBuyPriceUsdt,
      currentPriceToman: px.toman,
      currentPriceUsdt: px.usdt,
      costBasisToman,
      costBasisUsdt,
      currentValueToman,
      currentValueUsdt,
      pnlToman,
      pnlUsdt,
      pnlPercentToman,
      pnlPercentUsdt,
      source: cb ? 'MANUAL' : 'ESTIMATED',
    });
  }

  const cryptoPnlToman = cryptoCurrentToman - cryptoCostBasisToman;
  const cryptoPnlUsdt = cryptoCurrentUsdt - cryptoCostBasisUsdt;
  const cryptoPnlPercentToman =
    cryptoCostBasisToman > 0 ? (cryptoPnlToman / cryptoCostBasisToman) * 100 : 0;
  const cryptoPnlPercentUsdt =
    cryptoCostBasisUsdt > 0 ? (cryptoPnlUsdt / cryptoCostBasisUsdt) * 100 : 0;

  return {
    mode: 'paper',
    totalCurrentToman,
    totalCurrentUsdt,
    cashToman,
    cashUsdt,
    cryptoCurrentToman,
    cryptoCurrentUsdt,
    cryptoCostBasisToman,
    cryptoCostBasisUsdt,
    cryptoPnlToman,
    cryptoPnlUsdt,
    cryptoPnlPercentToman,
    cryptoPnlPercentUsdt,
    assets,
  };
}

export function createInitialDemoState(
  markets: UnifiedMarketTicker[],
  usdtTomanRate: number
): DemoSandboxState {
  const rate = usdtTomanRate > 0 ? usdtTomanRate : DEFAULT_USDT_RATE;
  const btc = getFallbackPrice('BTC', markets, rate);
  const eth = getFallbackPrice('ETH', markets, rate);
  const ton = getFallbackPrice('TON', markets, rate);
  const now = Date.now();

  const balances = buildDemoBalances(markets, rate);
  const costBasisMap: DemoSandboxState['costBasisMap'] = {
    BTC: { asset: 'BTC', price: Math.round(btc.toman * 0.9), quoteCurrency: 'IRT' },
    ETH: { asset: 'ETH', price: Number((eth.usdt * 0.92).toFixed(2)), quoteCurrency: 'USDT' },
    TON: { asset: 'TON', price: Math.round(ton.toman * 0.88), quoteCurrency: 'IRT' },
  };

  const openOrd1Price = Math.round(btc.toman * 0.96);
  const openOrd2Price = Number((eth.usdt * 1.05).toFixed(2));
  const histOrd1Price = Math.round(btc.toman * 0.92);
  const histOrd2Price = Math.round(ton.toman * 0.94);

  const openOrders: SpotOrder[] = [
    {
      orderId: 'demo-ord-open-1',
      symbol: 'BTCIRT',
      baseAsset: 'BTC',
      quoteCurrency: 'IRT',
      side: 'BUY',
      type: 'LIMIT',
      quantity: 0.002,
      executedQty: 0,
      price: openOrd1Price,
      totalQuoteAmount: 0.002 * openOrd1Price,
      status: 'NEW',
      mode: 'paper',
      source: 'MANUAL',
      createdAt: now - 35 * 60_000,
    },
    {
      orderId: 'demo-ord-open-2',
      symbol: 'ETHUSDT',
      baseAsset: 'ETH',
      quoteCurrency: 'USDT',
      side: 'SELL',
      type: 'LIMIT',
      quantity: 0.05,
      executedQty: 0,
      price: openOrd2Price,
      totalQuoteAmount: 0.05 * openOrd2Price,
      status: 'NEW',
      mode: 'paper',
      source: 'MANUAL',
      createdAt: now - 90 * 60_000,
    },
  ];

  const orderHistory: SpotOrder[] = [
    {
      orderId: 'demo-ord-hist-1',
      symbol: 'BTCIRT',
      baseAsset: 'BTC',
      quoteCurrency: 'IRT',
      side: 'BUY',
      type: 'MARKET',
      quantity: 0.004,
      executedQty: 0.004,
      price: histOrd1Price,
      totalQuoteAmount: 0.004 * histOrd1Price,
      status: 'FILLED',
      mode: 'paper',
      source: 'BOT',
      createdAt: now - 6 * 3600_000,
    },
    {
      orderId: 'demo-ord-hist-2',
      symbol: 'TONIRT',
      baseAsset: 'TON',
      quoteCurrency: 'IRT',
      side: 'BUY',
      type: 'LIMIT',
      quantity: 60,
      executedQty: 60,
      price: histOrd2Price,
      totalQuoteAmount: 60 * histOrd2Price,
      status: 'FILLED',
      mode: 'paper',
      source: 'MANUAL',
      createdAt: now - 14 * 3600_000,
    },
  ];

  const bots: BotStrategyConfig[] = [
    {
      id: 'demo-bot-btc',
      name: 'شکار کف و فروش در سود · بیت‌کوین (تومانی)',
      symbol: 'BTCIRT',
      baseAsset: 'BTC',
      quoteCurrency: 'IRT',
      timeframe: '15m',
      mode: 'paper',
      status: 'RUNNING',
      orderAmount: 10_000_000,
      stopLossPercent: 2.5,
      takeProfitPercent: 5.5,
      trailingStopEnabled: true,
      trailingStopPercent: 1.5,
      cooldownMinutes: 15,
      logicOperator: 'AND',
      entryRules: [
        {
          id: 'd-e1',
          type: 'RSI_OVERSOLD',
          action: 'BUY',
          enabled: true,
          params: { period: 14, threshold: 35 },
        },
      ],
      exitRules: [
        {
          id: 'd-x1',
          type: 'RSI_OVERBOUGHT',
          action: 'SELL',
          enabled: true,
          params: { period: 14, threshold: 70 },
        },
      ],
      activePosition: {
        entryPrice: Math.round(btc.toman * 0.97),
        quantity: 0.0014,
        highestPrice: btc.toman,
        stopLossPrice: Math.round(btc.toman * 0.946),
        takeProfitPrice: Math.round(btc.toman * 1.025),
        openedAt: now - 45 * 60_000,
      },
      lastSignalSummary: 'پایش فعال کندل‌های ۱۵ دقیقه‌ای نوبیتکس · آماده مدیریت سود',
      lastCheckedAt: now - 120_000,
      notifyTelegram: true,
      stats: {
        totalTrades: 7,
        winningTrades: 5,
        losingTrades: 2,
        realizedPnl: 3_420_000,
      },
      createdAt: now - 3 * 86400_000,
    },
    {
      id: 'demo-bot-eth',
      name: 'همراه با موج صعودی · اتریوم (تتری)',
      symbol: 'ETHUSDT',
      baseAsset: 'ETH',
      quoteCurrency: 'USDT',
      timeframe: '1h',
      mode: 'paper',
      status: 'PAUSED',
      orderAmount: 150,
      stopLossPercent: 3,
      takeProfitPercent: 6,
      trailingStopEnabled: true,
      trailingStopPercent: 1.8,
      cooldownMinutes: 30,
      logicOperator: 'AND',
      entryRules: [
        {
          id: 'd-e2',
          type: 'EMA_GOLDEN_CROSS',
          action: 'BUY',
          enabled: true,
          params: { fastPeriod: 9, slowPeriod: 21 },
        },
      ],
      exitRules: [
        {
          id: 'd-x2',
          type: 'EMA_DEATH_CROSS',
          action: 'SELL',
          enabled: true,
          params: { fastPeriod: 9, slowPeriod: 21 },
        },
      ],
      activePosition: null,
      lastSignalSummary: 'متوقف موقت (آماده تست روشن‌کردن در حالت نمایشی)',
      lastCheckedAt: now - 25 * 60_000,
      notifyTelegram: true,
      stats: {
        totalTrades: 4,
        winningTrades: 3,
        losingTrades: 1,
        realizedPnl: 48.5,
      },
      createdAt: now - 5 * 86400_000,
    },
  ];

  const botLogs: BotExecutionLog[] = [
    {
      id: 'demo-log-1',
      botId: 'demo-bot-btc',
      botName: bots[0].name,
      symbol: 'BTCIRT',
      quoteCurrency: 'IRT',
      event: 'BUY_EXECUTED',
      message: 'سیگنال اشباع فروش RSI تایید شد · خرید آزمایشی ۱۰,۰۰۰,۰۰۰ تومان ثبت شد.',
      price: Math.round(btc.toman * 0.97),
      quantity: 0.0014,
      mode: 'paper',
      timestamp: now - 45 * 60_000,
    },
    {
      id: 'demo-log-2',
      botId: 'demo-bot-btc',
      botName: bots[0].name,
      symbol: 'BTCIRT',
      quoteCurrency: 'IRT',
      event: 'INFO',
      message: 'ارزیابی دوره‌ای انجام شد · حد ضرر متحرک در سود قفل شده است.',
      price: btc.toman,
      mode: 'paper',
      timestamp: now - 8 * 60_000,
    },
  ];

  const alerts: PriceAlert[] = [
    {
      id: 'demo-alert-1',
      baseAsset: 'BTC',
      persianName: 'بیت‌کوین',
      symbol: 'BTCIRT',
      quoteCurrency: 'IRT',
      condition: 'ABOVE',
      targetPrice: Math.round(btc.toman * 1.04),
      createdPrice: btc.toman,
      status: 'ACTIVE',
      sendTelegram: true,
      note: 'هشدار شکست سقف مقاومتی',
      createdAt: now - 2 * 3600_000,
    },
    {
      id: 'demo-alert-2',
      baseAsset: 'TON',
      persianName: 'تون‌کوین',
      symbol: 'TONUSDT',
      quoteCurrency: 'USDT',
      condition: 'BELOW',
      targetPrice: Number((ton.usdt * 0.94).toFixed(3)),
      createdPrice: ton.usdt,
      status: 'ACTIVE',
      sendTelegram: true,
      note: 'محدوده مناسب خرید پله‌ای',
      createdAt: now - 5 * 3600_000,
    },
  ];

  const watchers: PeriodicPriceWatcher[] = [
    {
      id: 'demo-watcher-1',
      baseAsset: 'BTC',
      persianName: 'بیت‌کوین',
      quoteMode: 'BOTH',
      intervalMinutes: 5,
      status: 'ACTIVE',
      notifyBrowser: true,
      playSound: false,
      sendTelegram: true,
      lastPriceToman: btc.toman,
      lastPriceUsdt: btc.usdt,
      lastSentAt: now - 3 * 60_000,
      nextSendAt: now + 2 * 60_000,
      sentCount: 6,
      createdAt: now - 30 * 60_000,
    },
  ];

  const pulses: PricePulseNotification[] = [
    {
      id: 'demo-pulse-1',
      watcherId: 'demo-watcher-1',
      baseAsset: 'BTC',
      persianName: 'بیت‌کوین',
      quoteMode: 'BOTH',
      intervalMinutes: 5,
      priceToman: btc.toman,
      priceUsdt: btc.usdt,
      change24hPercent: markets.find((m) => m.baseAsset === 'BTC')?.change24hPercent ?? 2.15,
      sentAt: now - 3 * 60_000,
    },
  ];

  const ideas: FeatureIdeaItem[] = [
    {
      id: 'demo-idea-1',
      title: 'خرید پله‌ای هوشمند در اصلاح‌های بیش از ۵٪',
      description: 'تقسیم خودکار سرمایه به ۳ پله در صورت افت قیمت نسبت به میانگین هفتگی',
      category: 'BOT',
      status: 'PLANNED',
      createdAt: now - 2 * 86400_000,
    },
    {
      id: 'demo-idea-2',
      title: 'گزارش هفتگی سود و زیان به ربات تلگرام',
      description: 'ارسال خلاصه عملکرد تمام معاملات هفته هر جمعه شب',
      category: 'ALERTS',
      status: 'IDEA',
      createdAt: now - 86400_000,
    },
  ];

  const telegram: TelegramBotSummary = {
    configured: true,
    enabled: true,
    maskedBotToken: '7492****:AAH-DEMO-TOKEN',
    botUsername: 'AiNobiBotDemo',
    botFirstName: 'ربات نمایشی AI NobiBot',
    chatId: '184920311',
    sendPriceAlerts: true,
    sendPeriodicWatchers: true,
    sendTradeReports: true,
    sendBotTrades: true,
    sendBotMonitoring: true,
    botMonitorMode: 'EVENTS_AND_STATUS',
    botMonitorIntervalMinutes: 15,
    updatedAt: now - 3600_000,
    lastSentAt: now - 3 * 60_000,
    lastBotMonitorSentAt: now - 8 * 60_000,
    lastError: null,
    recentLogs: [
      {
        id: 'demo-tglog-1',
        kind: 'BOT_TRADE',
        title: 'خرید خودکار ربات BTC',
        preview: 'شکار کف و فروش در سود · خرید ۱۰,۰۰۰,۰۰۰ تومان در BTCIRT',
        status: 'SENT',
        sentAt: now - 45 * 60_000,
      },
      {
        id: 'demo-tglog-2',
        kind: 'BOT_EVENT',
        title: 'گزارش پایش ربات BTC',
        preview: 'پایش فعال کندل‌های ۱۵ دقیقه‌ای · حد ضرر متحرک در سود قفل شده است.',
        status: 'SENT',
        sentAt: now - 8 * 60_000,
      },
    ],
  };

  const referral: UserReferralSummary = {
    referralCode: 'ALI-DEMO4U',
    rewardDaysPerConversion: 4,
    totalInvitedCount: 5,
    convertedCount: 3,
    pendingConversionCount: 2,
    totalBonusDaysEarned: 12,
    referredByCode: null,
    canClaimManualCode: true,
    invites: [
      {
        id: 'demo-ref-1',
        referredUserUid: 'demo-u1',
        referredMaskedEmail: 'reza.t***@gmail.com',
        referredDisplayName: 'رضا ت.',
        status: 'REWARDED',
        rewardDays: 4,
        joinedAt: now - 8 * 86400_000,
        rewardedAt: now - 7 * 86400_000,
      },
      {
        id: 'demo-ref-2',
        referredUserUid: 'demo-u2',
        referredMaskedEmail: 'sara.m***@gmail.com',
        referredDisplayName: 'سارا م.',
        status: 'REWARDED',
        rewardDays: 4,
        joinedAt: now - 5 * 86400_000,
        rewardedAt: now - 4 * 86400_000,
      },
      {
        id: 'demo-ref-3',
        referredUserUid: 'demo-u3',
        referredMaskedEmail: 'amir.h***@gmail.com',
        referredDisplayName: 'امیرحسین',
        status: 'REGISTERED',
        rewardDays: 4,
        joinedAt: now - 86400_000,
        rewardedAt: null,
      },
    ],
  };

  const directMessages: DirectMessageRecord[] = [
    {
      id: 'demo-dm-1',
      targetUserId: 'demo-user',
      targetUserEmail: 'demo@ainobibot.ir',
      targetUserName: 'کاربر نمایشی',
      subject: 'خوش‌آمدگویی حالت نمایشی AI NobiBot (ainobibot.ir)',
      body: 'شما در حال مشاهده پیش‌نمایش کامل برنامه روی موبایل هستید. تمام بخش‌ها از جمله خرید و فروش آزمایشی، تحلیل AI، ربات معامله‌گر، ربات تلگرام و لینک دعوت بدون نیاز به هاست یا درگاه پرداخت فعال هستند.',
      severity: 'SUCCESS',
      senderEmail: 'shivamdonyam@gmail.com',
      readByUser: false,
      createdAt: now - 15 * 60_000,
      updatedAt: now - 15 * 60_000,
      readAt: null,
    },
  ];

  const demoBuyPrice = Math.round(btc.toman * 0.996);
  const demoEntryAmount = 10_000_000;
  const demoTargetProfit = 100_000;
  const demoGrossQty = demoEntryAmount / demoBuyPrice;
  const demoBuyFeeQuote = Math.round(demoEntryAmount * DEFAULT_NOBITEX_FEE_RATE);
  const demoNetOwnedQty = demoGrossQty * (1 - DEFAULT_NOBITEX_FEE_RATE);
  const demoCurrentSellPrice = Math.round(btc.toman * 0.9995);
  const demoEstProceeds = demoNetOwnedQty * demoCurrentSellPrice;
  const demoEstSellFee = Math.round(demoEstProceeds * DEFAULT_NOBITEX_FEE_RATE);
  const demoEstNetProfit = Math.round(demoEstProceeds - demoEntryAmount - demoEstSellFee);
  const demoRequiredSellPrice = computeRequiredSellPrice(
    demoNetOwnedQty,
    demoEntryAmount,
    demoTargetProfit,
    DEFAULT_NOBITEX_FEE_RATE,
    0
  );
  const demoProgress = computeProfitProgressPercent(demoEstNetProfit, demoTargetProfit);

  const todayKey = new Date(now).toISOString().slice(0, 10);

  const profitBots: ProfitBotConfig[] = [
    {
      id: 'demo-pbot-1',
      ownerId: 'demo-user',
      name: 'ربات سود بیت‌کوین (دمو)',
      baseAsset: 'BTC',
      quoteCurrency: 'IRT',
      symbol: 'BTCIRT',
      mode: 'paper',
      isActive: true,
      botStatus: 'WAITING_FOR_PROFIT',
      entryAmount: demoEntryAmount,
      targetNetProfit: demoTargetProfit,
      pollIntervalSeconds: 10,
      maxWaitMinutes: 240,
      stopLossEnabled: true,
      stopLossPercent: 3,
      stopLossAction: 'STOP_AND_SELL',
      maxCapitalInvolved: 20_000_000,
      maxDailyTrades: 10,
      maxDailyLoss: 500_000,
      orderType: 'MARKET',
      maxSlippagePercent: 0.5,
      maxSpreadPercent: 2.5,
      limitOrderTimeoutSeconds: 120,
      limitUnfilledPolicy: 'KEEP_WAITING',
      sequenceMode: 'CYCLE_REPEAT',
      reentryTargetPrice: null,
      reentryPolicy: 'WAIT_ENTRY_PRICE',
      waitEntryPriceOnFirstBuy: false,
      targetSellPrice: null,
      feeRate: DEFAULT_NOBITEX_FEE_RATE,
      otherFeesQuote: 0,
      notifyTelegram: true,
      activePosition: {
        cycleIndex: 2,
        buyOrderId: 'demo-pbuy-2',
        buyOrderType: 'LIMIT',
        requestedQuoteAmount: demoEntryAmount,
        requestedQty: demoGrossQty,
        filledGrossQty: demoGrossQty,
        netOwnedQty: demoNetOwnedQty,
        actualBuyAvgPrice: demoBuyPrice,
        buyPrincipalQuote: demoEntryAmount,
        buyFeeQuote: demoBuyFeeQuote,
        buyFeeAsset: 'IRT',
        totalBuyCostQuote: demoEntryAmount,
        otherFeesQuote: 0,
        buyFilledAt: now - 14 * 60_000,
        partialFill: false,
        lastExecutableSellPrice: demoCurrentSellPrice,
        lastExecutableProceedsQuote: demoEstProceeds,
        lastEstimatedSellFeeQuote: demoEstSellFee,
        lastEstimatedNetProfitQuote: demoEstNetProfit,
        lastHasSufficientDepth: true,
        lastSpreadPercent: 0.12,
        lastSlippagePercent: 0.04,
        lastRequiredSellPrice: demoRequiredSellPrice,
        lastProgressPercent: demoProgress,
        lastEvaluatedAt: now - 10_000,
      },
      pendingOrder: null,
      dailyStats: {
        dateKey: todayKey,
        tradesCount: 1,
        lossQuote: 0,
        netProfitQuote: 108_400,
      },
      stats: {
        completedCycles: 1,
        winningCycles: 1,
        losingCycles: 0,
        totalNetProfitQuote: 108_400,
        totalFeesPaidQuote: 50_270,
        currentCapitalInvolved: demoEntryAmount,
        lastBuyPrice: demoBuyPrice,
      },
      lastStatusReason:
        demoEstNetProfit >= 0
          ? `در انتظار سود خالص هدف · سود لحظه‌ای پس از کارمزد: +${formatToman(demoEstNetProfit)} تومان`
          : `در انتظار سود خالص هدف · سود لحظه‌ای پس از کارمزد: -${formatToman(Math.abs(demoEstNetProfit))} تومان`,
      lastError: null,
      lastCheckedAt: now - 10_000,
      startedAt: now - 35 * 60_000,
      createdAt: now - 2 * 3600_000,
      updatedAt: now - 10_000,
    },
  ];

  const profitBotCycles: ProfitBotCycleRecord[] = [
    {
      id: 'demo-pcycle-1',
      botId: 'demo-pbot-1',
      cycleIndex: 1,
      symbol: 'BTCIRT',
      baseAsset: 'BTC',
      quoteCurrency: 'IRT',
      mode: 'paper',
      orderType: 'LIMIT',
      entryAmountQuote: 10_000_000,
      actualBuyAvgPrice: Math.round(btc.toman * 0.985),
      boughtQty: 10_000_000 / Math.round(btc.toman * 0.985),
      buyFeeQuote: 25_000,
      totalBuyCostQuote: 10_000_000,
      actualSellAvgPrice: Math.round(btc.toman * 1.001),
      soldQty: (10_000_000 / Math.round(btc.toman * 0.985)) * (1 - DEFAULT_NOBITEX_FEE_RATE),
      grossSellProceedsQuote: 10_133_670,
      sellFeeQuote: 25_270,
      otherFeesQuote: 0,
      finalNetProfitQuote: 108_400,
      targetNetProfitQuote: 100_000,
      exitReason: 'TARGET_PROFIT',
      startedAt: now - 95 * 60_000,
      completedAt: now - 40 * 60_000,
    },
  ];

  const profitBotLogs: ProfitBotDecisionLog[] = [
    {
      id: 'demo-plog-1',
      botId: 'demo-pbot-1',
      cycleIndex: 2,
      status: 'WAITING_FOR_PROFIT',
      event: 'BUY_FILLED',
      price: demoBuyPrice,
      netProfitQuote: demoEstNetProfit,
      message: `خرید چرخه ۲ تکمیل شد · میانگین: ${formatToman(demoBuyPrice)} تومان · قیمت فروش مورد نیاز برای +${formatToman(demoTargetProfit)} سود خالص: ${formatToman(Math.round(demoRequiredSellPrice))} تومان`,
      timestamp: now - 14 * 60_000,
    },
    {
      id: 'demo-plog-2',
      botId: 'demo-pbot-1',
      cycleIndex: 1,
      status: 'SELL_FILLED',
      event: 'SELL_FILLED',
      price: Math.round(btc.toman * 1.001),
      netProfitQuote: 108_400,
      message: 'فروش چرخه ۱ با سود خالص واقعی +۱۰۸,۴۰۰ تومان (پس از کسر کل کارمزدها) تکمیل و ثبت شد.',
      timestamp: now - 40 * 60_000,
    },
  ];

  const gridLower = Math.round(ton.toman * 0.94);
  const gridUpper = Math.round(ton.toman * 1.06);
  const gridCount = 7;
  const gridStep = (gridUpper - gridLower) / (gridCount - 1);
  const gridBots: GridBotConfig[] = [
    {
      id: 'demo-grid-1',
      ownerId: 'demo-user',
      name: 'گرید نوسانی تون‌کوین (دمو)',
      baseAsset: 'TON',
      quoteCurrency: 'IRT',
      symbol: 'TONIRT',
      mode: 'paper',
      isActive: true,
      status: 'RUNNING',
      lowerPrice: gridLower,
      upperPrice: gridUpper,
      gridLevels: gridCount,
      stepMode: 'ARITHMETIC',
      totalCapital: 12_000_000,
      maxCapitalInvolved: 12_000_000,
      stopOnBreakout: true,
      alertOnBreakout: true,
      feeRate: DEFAULT_NOBITEX_FEE_RATE,
      estimatedSlippagePercent: 0.15,
      executionConfirmationMode: 'AUTO',
      notifyTelegram: true,
      allocatedLevels: Array.from({ length: gridCount }, (_, idx) => ({
        index: idx,
        price: Math.round(gridLower + idx * gridStep),
        side: idx === gridCount - 1 ? 'SELL' : 'BUY',
        status: idx < 2 ? 'HOLDING' : 'IDLE',
        qty: idx < 2 ? Math.round((12_000_000 / 6 / Math.round(gridLower + idx * gridStep)) * 100) / 100 : 0,
        buyPrice: idx < 2 ? Math.round(gridLower + idx * gridStep) : undefined,
      })),
      stats: {
        completedCycles: 4,
        totalNetProfitQuote: 245_000,
        totalFeesPaidQuote: 38_000,
        openOrdersCount: 2,
        currentCapitalInvolved: 4_000_000,
        netProfitPerCyclePercent: 1.45,
      },
      lastPrice: ton.toman,
      lastStatusReason: 'در حال پایش ۷ پله گرید · ۲ پله آماده فروش در پله بالاتر',
      lastError: null,
      lastCheckedAt: now - 15_000,
      createdAt: now - 2 * 86400_000,
      updatedAt: now - 15_000,
    },
  ];

  const dcaBots: DcaBotConfig[] = [
    {
      id: 'demo-dca-1',
      ownerId: 'demo-user',
      name: 'خرید پله‌ای اتریوم (دمو)',
      baseAsset: 'ETH',
      quoteCurrency: 'IRT',
      symbol: 'ETHIRT',
      mode: 'paper',
      isActive: true,
      status: 'RUNNING',
      totalCapital: 25_000_000,
      maxInvolvedCapital: 25_000_000,
      stagesCount: 5,
      stepUnit: 'PERCENT',
      stepValue: 2.5,
      triggerMode: 'MARKET_DROP',
      intervalMinutes: 180,
      pauseNewBuys: false,
      stopLossEnabled: true,
      stopLossPercent: 8,
      takeProfitEnabled: true,
      takeProfitPercent: 5,
      trailingTpEnabled: true,
      trailingTpActivationPercent: 4,
      trailingTpCallbackPercent: 1.2,
      takeProfitTargets: [
        { id: 'tp-1', risePercent: 3.5, sellPercent: 50 },
        { id: 'tp-2', risePercent: 7, sellPercent: 50 },
      ],
      keepRunnerPercent: 10,
      feeRate: DEFAULT_NOBITEX_FEE_RATE,
      estimatedSlippagePercent: 0.15,
      executionConfirmationMode: 'AUTO',
      notifyTelegram: true,
      state: {
        stagesCompleted: 2,
        avgBuyPrice: Math.round(eth.toman * 0.985),
        totalHoldingQty: 10_000_000 / Math.round(eth.toman * 0.985),
        netOwnedQty: (10_000_000 / Math.round(eth.toman * 0.985)) * (1 - DEFAULT_NOBITEX_FEE_RATE),
        totalInvestedQuote: 10_000_000,
        totalBuyFeesQuote: 25_000,
        lastBuyPrice: Math.round(eth.toman * 0.975),
        nextTriggerAt: now + 3 * 3600_000,
        highestPriceSinceEntry: eth.toman,
        executedTpIds: [],
        trailingTpArmed: false,
      },
      stats: {
        completedCycles: 1,
        realizedNetProfitQuote: 620_000,
        totalFeesPaidQuote: 72_000,
      },
      lastPrice: eth.toman,
      lastStatusReason: 'مرحله ۲ از ۵ انجام شده · آماده خرید پله بعدی در افت ۲.۵٪ یا فروش در هدف +۳.۵٪',
      lastError: null,
      lastCheckedAt: now - 25_000,
      createdAt: now - 4 * 86400_000,
      updatedAt: now - 25_000,
    },
  ];

  const acBuyPrice = Math.round(eth.toman * 0.992);
  const acEntryAmount = 15_000_000;
  const acGrossQty = acEntryAmount / Math.max(1, acBuyPrice);
  const acNetQty = acGrossQty * (1 - DEFAULT_NOBITEX_FEE_RATE);
  const acBuyFee = Math.round(acEntryAmount * DEFAULT_NOBITEX_FEE_RATE);
  const acTargetSell = Math.round(acBuyPrice * 1.022);
  const acStopLoss = Math.round(acBuyPrice * 0.97);
  const acCurProceeds = Math.round(acNetQty * eth.toman);
  const acCurSellFee = Math.round(acCurProceeds * DEFAULT_NOBITEX_FEE_RATE);
  const acEstNetProfit = Math.round(acCurProceeds - acCurSellFee - acEntryAmount);

  const aiCycleProBots: AiCycleProConfig[] = [
    {
      id: 'demo-acycle-1',
      ownerId: 'demo-user',
      name: 'چرخه هوشمند اتریوم (دمو)',
      baseAsset: 'ETH',
      quoteCurrency: 'IRT',
      symbol: 'ETHIRT',
      mode: 'paper',
      isActive: true,
      status: 'HOLDING_POSITION',
      capitalAmount: 15_000_000,
      capitalUsageMode: 'FULL',
      capitalPortionPercent: 100,
      executionConfirmationMode: 'AUTO',
      autoRepeatCycles: true,
      stopLossPercent: 3,
      maxDailyLoss: 750_000,
      maxSlippagePercent: 0.45,
      maxSpreadPercent: 1.5,
      minTargetNetProfitPercent: 1.5,
      pollIntervalSeconds: 20,
      feeRate: DEFAULT_NOBITEX_FEE_RATE,
      notifyTelegram: true,
      activePosition: {
        cycleIndex: 2,
        buyOrderId: 'demo-acbuy-2',
        requestedQuoteAmount: acEntryAmount,
        requestedQty: acGrossQty,
        filledGrossQty: acGrossQty,
        netOwnedQty: acNetQty,
        actualBuyAvgPrice: acBuyPrice,
        buyFeeQuote: acBuyFee,
        totalBuyCostQuote: acEntryAmount,
        targetNetProfitPercent: 1.8,
        targetSellPrice: acTargetSell,
        stopLossPrice: acStopLoss,
        highestPrice: Math.max(acBuyPrice, eth.toman),
        buyFilledAt: now - 22 * 60_000,
        lastEstimatedExecutableSellPrice: eth.toman,
        lastEstimatedNetProfitQuote: acEstNetProfit,
        lastEstimatedSlippagePercent: 0.08,
        lastSpreadPercent: 0.14,
        lastEvaluatedAt: now - 15_000,
      },
      pendingOrder: null,
      lastDecision: {
        action: 'HOLD_POSITION',
        marketCondition: 'FAVORABLE',
        confidencePercent: 82,
        trendScore: 74,
        liquidityScore: 91,
        volatilityPercent: 1.65,
        spreadPercent: 0.14,
        estimatedSlippagePercent: 0.08,
        recommendedCapitalPortionPercent: 100,
        recommendedTargetNetProfitPercent: 1.8,
        recommendedStopLossPercent: 3,
        suggestedBuyPrice: acBuyPrice,
        suggestedSellPrice: acTargetSell,
        regimeLabelFa: 'صعودی ملایم با نقدینگی عالی',
        reasoningFa:
          'نقدینگی دفتر سفارش اتریوم/تومان متعادل و مومنتوم کوتاه‌مدت مثبت است؛ پوزیشن تا هدف سود خالص +۱.۸٪ نگهداری می‌شود.',
        riskWarningFa: 'در صورت افت بیش از ۳٪، حد ضرر حفاظتی به‌صورت خودکار فعال می‌شود.',
        usedFallback: false,
        analyzedAt: now - 15_000,
      },
      dailyStats: {
        dateKey: todayKey,
        tradesCount: 1,
        lossQuote: 0,
        netProfitQuote: 248_500,
      },
      stats: {
        completedCycles: 1,
        winningCycles: 1,
        losingCycles: 0,
        totalNetProfitQuote: 248_500,
        totalFeesPaidQuote: 75_400,
        currentCapitalInvolved: acEntryAmount,
        lastBuyPrice: acBuyPrice,
      },
      lastPrice: eth.toman,
      lastStatusReason: `پوزیشن باز اتریوم · سود لحظه‌ای خالص: ${acEstNetProfit >= 0 ? '+' : '-'}${formatToman(Math.abs(acEstNetProfit))} تومان · هدف فروش: ${formatToman(acTargetSell)} تومان`,
      lastError: null,
      lastCheckedAt: now - 15_000,
      startedAt: now - 2 * 3600_000,
      createdAt: now - 3 * 3600_000,
      updatedAt: now - 15_000,
    },
  ];

  const aiCycleProCycles: AiCycleProCycleRecord[] = [
    {
      id: 'demo-accycle-1',
      botId: 'demo-acycle-1',
      cycleIndex: 1,
      symbol: 'ETHIRT',
      baseAsset: 'ETH',
      quoteCurrency: 'IRT',
      mode: 'paper',
      entryAmountQuote: 15_000_000,
      actualBuyAvgPrice: Math.round(eth.toman * 0.972),
      boughtQty: 15_000_000 / Math.round(eth.toman * 0.972),
      buyFeeQuote: 37_500,
      totalBuyCostQuote: 15_000_000,
      actualSellAvgPrice: Math.round(eth.toman * 0.993),
      soldQty: (15_000_000 / Math.round(eth.toman * 0.972)) * (1 - DEFAULT_NOBITEX_FEE_RATE),
      grossSellProceedsQuote: 15_286_400,
      sellFeeQuote: 37_900,
      finalNetProfitQuote: 248_500,
      targetNetProfitPercent: 1.6,
      slippagePercent: 0.09,
      exitReason: 'AI_TARGET_PROFIT',
      aiEntrySummaryFa: 'اسپرد محدود ۰.۱۲٪ و ورود در حمایت کوتاه‌مدت ۱۵ دقیقه‌ای با مومنتوم مثبت.',
      aiExitSummaryFa: 'هدف سود خالص +۱.۶٪ پس از کسر کارمزد خرید و فروش محقق و پوزیشن بسته شد.',
      startedAt: now - 110 * 60_000,
      completedAt: now - 45 * 60_000,
    },
  ];

  const aiCycleProLogs: AiCycleProLog[] = [
    {
      id: 'demo-aclog-2',
      botId: 'demo-acycle-1',
      cycleIndex: 2,
      status: 'HOLDING_POSITION',
      event: 'BUY_FILLED',
      price: acBuyPrice,
      netProfitQuote: acEstNetProfit,
      message: `ورود چرخه ۲ تکمیل شد · قیمت خرید: ${formatToman(acBuyPrice)} تومان · هدف فروش خالص: ${formatToman(acTargetSell)} تومان`,
      timestamp: now - 22 * 60_000,
    },
    {
      id: 'demo-aclog-1',
      botId: 'demo-acycle-1',
      cycleIndex: 1,
      status: 'HOLDING_POSITION',
      event: 'SELL_FILLED',
      price: Math.round(eth.toman * 0.993),
      netProfitQuote: 248_500,
      message: 'فروش چرخه ۱ با سود خالص واقعی +۲۴۸,۵۰۰ تومان انجام و چرخه بعدی آغاز شد.',
      timestamp: now - 45 * 60_000,
    },
  ];

  const riskSettings: SharedBotRiskSettings = {
    userId: 'demo-user',
    totalBotsBudgetIrt: 100_000_000,
    totalBotsBudgetUsdt: 2_000,
    maxPerBotCapitalIrt: 35_000_000,
    maxPerBotCapitalUsdt: 1500,
    maxDailyLossIrt: 5_000_000,
    maxDailyLossUsdt: 100,
    maxTotalLossIrt: 20_000_000,
    maxTotalLossUsdt: 400,
    enableSymbolConflictLock: true,
    allowAiAdvisoryOnly: true,
    killSwitchActive: false,
    updatedAt: now,
  };

  const pendingConfirmations: PendingBotConfirmation[] = [
    {
      id: 'demo-pconf-1',
      userId: 'demo-user',
      botId: 'demo-dca-1',
      botType: 'DCA',
      botName: 'خرید پله‌ای اتریوم (دمو)',
      symbol: 'ETHIRT',
      baseAsset: 'ETH',
      quoteCurrency: 'IRT',
      mode: 'paper',
      side: 'BUY',
      orderType: 'MARKET',
      suggestedPrice: Math.round(eth.toman * 0.972),
      quantity: 5_000_000 / Math.round(eth.toman * 0.972),
      quoteAmount: 5_000_000,
      estimatedFeeQuote: 12_500,
      reasonFa: 'نمونه پیش‌نمایش تأیید دستی: افت ۲.۵٪ اتریوم برای خرید پله ۳ از ۵',
      riskSummaryFa: 'پس از این خرید، کل سرمایه درگیر ربات ۱۵,۰۰۰,۰۰۰ از ۲۵,۰۰۰,۰۰۰ تومان می‌شود.',
      status: 'PENDING',
      createdAt: now - 5 * 60_000,
      expiresAt: now + 25 * 60_000,
      resolvedAt: null,
    },
  ];

  const aiManagerReport: AiManagerAnalysis = {
    id: 'demo-aim-1',
    generatedAt: now - 10 * 60_000,
    regime: 'RANGING',
    regimeLabelFa: 'رِنج و نوسانی متعادل',
    marketSummaryFa:
      'بازار نوبیتکس در ۲۴ ساعت اخیر داخل یک محدوده مشخص نوسان می‌کند؛ نقدینگی تومانی بیت‌کوین، اتریوم و تون‌کوین مناسب است.',
    recommendedPrimaryBotType: 'GRID',
    recommendedPrimaryBotReasonFa:
      'در وضعیت رِنج و بدون روند شدید، ربات گرید و ربات سود با کارمزد محاسبه‌شده بهترین بازدهی منطقی را دارند.',
    rankedCoins: [
      {
        symbol: 'BTCIRT',
        baseAsset: 'BTC',
        persianName: 'بیت‌کوین',
        score: 94,
        liquidityScore: 96,
        volatilityLabelFa: 'نوسان متعادل',
        trendLabelFa: 'رِنج صعودی',
        recommendedBotType: 'PROFIT',
        reasonFa: 'نقدینگی بالا و اسپرد بسیار کم؛ مناسب شکار سود خالص مشخص.',
      },
      {
        symbol: 'TONIRT',
        baseAsset: 'TON',
        persianName: 'تون‌کوین',
        score: 88,
        liquidityScore: 86,
        volatilityLabelFa: 'نوسان ایده‌آل کانال',
        trendLabelFa: 'رِنج / نوسانی',
        recommendedBotType: 'GRID',
        reasonFa: 'نوسانات رفت‌وبرگشتی منظم برای گرید پله‌ای.',
      },
      {
        symbol: 'ETHIRT',
        baseAsset: 'ETH',
        persianName: 'اتریوم',
        score: 85,
        liquidityScore: 90,
        volatilityLabelFa: 'اصلاحی ملایم',
        trendLabelFa: 'میان‌مدت صعودی',
        recommendedBotType: 'DCA',
        reasonFa: 'مناسب خرید پله‌ای در اصلاح‌ها و فروش چندهدف.',
      },
    ],
    botReviews: [
      {
        botId: 'demo-pbot-1',
        botName: 'ربات سود بیت‌کوین (دمو)',
        botType: 'PROFIT',
        health: 'HEALTHY',
        summaryFa: 'سود تحقق‌یافته مثبت و در محدوده ایمن سرمایه است.',
        suggestedAction: 'KEEP',
      },
      {
        botId: 'demo-grid-1',
        botName: 'گرید نوسانی تون‌کوین (دمو)',
        botType: 'GRID',
        health: 'HEALTHY',
        summaryFa: '۴ چرخه سودده ثبت شده و قیمت داخل محدوده گرید است.',
        suggestedAction: 'KEEP',
      },
    ],
    conflictAlerts: [],
    proposals: [
      {
        id: 'demo-prop-1',
        actionType: 'CREATE_RECOMMENDATION',
        recommendedBotType: 'GRID',
        recommendedSymbol: 'TONIRT',
        titleFa: 'بازار رِنج فعلی برای گرید تون‌کوین مناسب است',
        reasonFa: 'دامنه نوسان ۳ تا ۶ درصدی اخیر فرصت مناسبی برای خرید پایین و فروش بالا ایجاد کرده است.',
        withinApprovedLimits: true,
      },
    ],
    usedFallback: false,
  };

  return {
    balances,
    costBasisMap,
    openOrders,
    orderHistory,
    bots,
    botLogs,
    profitBots,
    profitBotCycles,
    profitBotLogs,
    aiCycleProBots,
    aiCycleProCycles,
    aiCycleProLogs,
    gridBots,
    dcaBots,
    riskSettings,
    pendingConfirmations,
    aiManagerReport,
    alerts,
    watchers,
    pulses,
    ideas,
    telegram,
    referral,
    directMessages,
  };
}

export function appendDemoTelegramLog(
  telegram: TelegramBotSummary,
  entry: Omit<TelegramSentLogEntry, 'id' | 'status' | 'sentAt'>
): TelegramBotSummary {
  const now = Date.now();
  const nextEntry: TelegramSentLogEntry = {
    id: `demo-tglog-${now}-${Math.random().toString(36).slice(2, 6)}`,
    kind: entry.kind,
    title: entry.title,
    preview: entry.preview,
    status: 'SENT',
    sentAt: now,
  };
  return {
    ...telegram,
    lastSentAt: now,
    lastError: null,
    recentLogs: [nextEntry, ...(telegram.recentLogs || [])].slice(0, 20),
  };
}

export function executeDemoOrder(
  state: DemoSandboxState,
  payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    side: 'BUY' | 'SELL';
    type: 'LIMIT' | 'MARKET';
    quantity: number;
    price?: number;
    stopLossPrice?: number;
    takeProfitPrice?: number;
  },
  markets: UnifiedMarketTicker[],
  usdtTomanRate: number
): DemoSandboxState {
  const rate = usdtTomanRate > 0 ? usdtTomanRate : DEFAULT_USDT_RATE;
  const pxInfo = getFallbackPrice(payload.baseAsset, markets, rate);
  const marketPrice = payload.quoteCurrency === 'IRT' ? pxInfo.toman : pxInfo.usdt;
  const execPrice =
    payload.type === 'LIMIT' && payload.price && payload.price > 0 ? payload.price : marketPrice;
  if (execPrice <= 0) {
    throw new Error('قیمت معتبر برای ثبت سفارش نمایشی در دسترس نیست.');
  }

  const qty = Number(payload.quantity);
  const costQuote = qty * execPrice;
  const nextBalances = state.balances.map((b) => ({ ...b }));

  const findOrAddBalance = (asset: string): SpotBalance => {
    let found = nextBalances.find((b) => b.asset === asset);
    if (!found) {
      found = {
        asset,
        persianName: getFallbackPrice(asset, markets, rate).persianName,
        free: 0,
        locked: 0,
        total: 0,
        tomanValue: 0,
        usdtValue: 0,
      };
      nextBalances.push(found);
    }
    return found;
  };

  const quoteBal = findOrAddBalance(payload.quoteCurrency);
  const baseBal = findOrAddBalance(payload.baseAsset);

  if (payload.side === 'BUY') {
    if (quoteBal.free < costQuote) {
      throw new Error('موجودی نمایشی کافی نیست (می‌توانید دکمه ریست موجودی دمو را بزنید).');
    }
    quoteBal.free -= costQuote;
    if (payload.type === 'MARKET') {
      baseBal.free += qty;
    } else {
      quoteBal.locked += costQuote;
    }
  } else {
    if (baseBal.free < qty) {
      throw new Error(`موجودی نمایشی ${payload.baseAsset} کافی نیست.`);
    }
    baseBal.free -= qty;
    if (payload.type === 'MARKET') {
      quoteBal.free += costQuote;
    } else {
      baseBal.locked += qty;
    }
  }

  const order: SpotOrder = {
    orderId: `demo-ord-${Date.now()}`,
    symbol: `${payload.baseAsset}${payload.quoteCurrency}`,
    baseAsset: payload.baseAsset,
    quoteCurrency: payload.quoteCurrency,
    side: payload.side,
    type: payload.type,
    quantity: qty,
    executedQty: payload.type === 'MARKET' ? qty : 0,
    price: execPrice,
    totalQuoteAmount: costQuote,
    stopLossPrice: payload.stopLossPrice,
    takeProfitPrice: payload.takeProfitPrice,
    status: payload.type === 'MARKET' ? 'FILLED' : 'NEW',
    mode: 'paper',
    source: 'MANUAL',
    createdAt: Date.now(),
  };

  return {
    ...state,
    balances: buildDemoBalances(markets, rate, nextBalances),
    openOrders: payload.type === 'LIMIT' ? [order, ...state.openOrders] : state.openOrders,
    orderHistory:
      payload.type === 'MARKET' ? [order, ...state.orderHistory] : state.orderHistory,
  };
}

export function cancelDemoOrder(
  state: DemoSandboxState,
  orderId: string,
  markets: UnifiedMarketTicker[],
  usdtTomanRate: number
): DemoSandboxState {
  const rate = usdtTomanRate > 0 ? usdtTomanRate : DEFAULT_USDT_RATE;
  const target = state.openOrders.find((o) => o.orderId === orderId);
  if (!target) return state;

  const nextBalances = state.balances.map((b) => ({ ...b }));
  if (target.side === 'BUY') {
    const quoteBal = nextBalances.find((b) => b.asset === target.quoteCurrency);
    const amount = target.quantity * target.price;
    if (quoteBal) {
      quoteBal.locked = Math.max(0, quoteBal.locked - amount);
      quoteBal.free += amount;
    }
  } else {
    const baseBal = nextBalances.find((b) => b.asset === target.baseAsset);
    if (baseBal) {
      baseBal.locked = Math.max(0, baseBal.locked - target.quantity);
      baseBal.free += target.quantity;
    }
  }

  return {
    ...state,
    balances: buildDemoBalances(markets, rate, nextBalances),
    openOrders: state.openOrders.filter((o) => o.orderId !== orderId),
    orderHistory: [{ ...target, status: 'CANCELED' }, ...state.orderHistory],
  };
}

export function computeDemoMultiSnapshots(
  symbol: string,
  market: UnifiedMarketTicker | null,
  candles: KlineCandle[],
  usdtTomanRate: number
): IndicatorSnapshot[] {
  const isUsdt = symbol.endsWith('USDT');
  const baseAsset = symbol.replace(/(IRT|USDT|RLS)$/, '') || 'BTC';
  const rate = usdtTomanRate > 0 ? usdtTomanRate : DEFAULT_USDT_RATE;
  const livePrice =
    (isUsdt ? market?.priceUsdt : market?.priceToman) ||
    candles[candles.length - 1]?.close ||
    (isUsdt ? 91_400 : 91_400 * rate);
  const chg = market?.change24hPercent ?? 1.4;
  const now = Date.now();

  const tfs: Array<{ tf: Timeframe; offset: number }> = [
    { tf: '15m', offset: -2.2 },
    { tf: '1h', offset: 0 },
    { tf: '4h', offset: 3.1 },
    { tf: '1d', offset: 5.4 },
  ];

  const baseRsi = Math.min(78, Math.max(24, 50 + chg * 2.4));

  return tfs.map(({ tf, offset }) => {
    const rsi = Math.min(82, Math.max(20, baseRsi + offset));
    const bullish = rsi >= 42 && rsi <= 68 && chg >= -1;
    const bearish = rsi > 70 || chg < -3.5;

    const action: IndicatorSnapshot['signal']['action'] = bullish
      ? chg > 2
        ? 'STRONG_BUY'
        : 'BUY'
      : bearish
        ? 'SELL'
        : 'NEUTRAL';
    const labelFa =
      action === 'STRONG_BUY'
        ? 'خرید قوی'
        : action === 'BUY'
          ? 'مایل به خرید'
          : action === 'SELL'
            ? 'مایل به فروش'
            : 'خنثی / صبر';

    const buyCount = action === 'STRONG_BUY' ? 8 : action === 'BUY' ? 6 : action === 'NEUTRAL' ? 3 : 2;
    const sellCount = action === 'SELL' ? 6 : action === 'NEUTRAL' ? 3 : 1;
    const neutralCount = Math.max(1, 10 - buyCount - sellCount);

    const ema9 = livePrice * (chg >= 0 ? 0.992 : 1.006);
    const ema20 = livePrice * (chg >= 0 ? 0.981 : 1.014);
    const ema50 = livePrice * (chg >= 0 ? 0.964 : 1.028);
    const ema200 = livePrice * (chg >= 0 ? 0.912 : 1.045);

    const bbUpper = livePrice * 1.036;
    const bbLower = livePrice * 0.964;

    return {
      symbol,
      timeframe: tf,
      price: livePrice,
      timestamp: now,
      rsi14: rsi,
      stochK: Math.min(95, Math.max(10, rsi + 4)),
      stochD: Math.min(95, Math.max(10, rsi)),
      ema9,
      ema20,
      ema50,
      ema200,
      sma20: ema20 * 1.002,
      macd: {
        macdLine: livePrice * (chg >= 0 ? 0.0042 : -0.0035),
        signalLine: livePrice * (chg >= 0 ? 0.0029 : -0.0021),
        histogram: livePrice * (chg >= 0 ? 0.0013 : -0.0014),
      },
      bollinger: {
        upper: bbUpper,
        middle: livePrice,
        lower: bbLower,
        bandwidthPercent: 7.2,
        percentB: chg >= 0 ? 0.62 : 0.38,
      },
      atr14: livePrice * 0.018,
      volumeRatio: chg > 2 ? 1.48 : 1.09,
      pivots: {
        pivot: livePrice,
        r1: livePrice * 1.025,
        r2: livePrice * 1.05,
        r3: livePrice * 1.08,
        s1: livePrice * 0.975,
        s2: livePrice * 0.95,
        s3: livePrice * 0.92,
      },
      signal: {
        action,
        labelFa,
        buyCount,
        sellCount,
        neutralCount,
        reasons: [
          `شاخص RSI (${rsi.toFixed(1)}) برای ${baseAsset} در محدوده ${rsi <= 35 ? 'اشباع فروش' : rsi >= 65 ? 'اشباع خرید' : 'متعادل'} قرار دارد.`,
          chg >= 0
            ? 'قیمت بالاتر از میانگین متحرک ۲۰ دوره‌ای قرار دارد و مومنتوم کوتاه‌مدت مثبت است.'
            : 'فشار عرضه در کوتاه‌مدت دیده می‌شود و شکست EMA 20 برای بازگشت مهم است.',
          'حجم معاملات نوبیتکس در این بازه زمانی پایدار گزارش شده است.',
        ],
      },
      series: {
        ema20: [],
        ema50: [],
        bbUpper: [],
        bbLower: [],
        rsi: [],
        macdLine: [],
        macdSignal: [],
        macdHistogram: [],
      },
    };
  });
}

export function computeDemoAiAnalysis(params: {
  symbol: string;
  baseAsset: string;
  market: UnifiedMarketTicker | null;
  usdtTomanRate: number;
  question?: string;
}): AiCoinAnalysis {
  const rate = params.usdtTomanRate > 0 ? params.usdtTomanRate : DEFAULT_USDT_RATE;
  const px = getFallbackPrice(params.baseAsset, params.market ? [params.market] : [], rate);
  const chg = params.market?.change24hPercent ?? 1.25;
  const stance: AiCoinAnalysis['stance'] =
    chg >= 3 ? 'STRONG_BUY' : chg >= 0.3 ? 'BUY' : chg <= -3 ? 'SELL' : 'HOLD';

  const stanceLabelFa =
    stance === 'STRONG_BUY'
      ? 'جون می‌ده برا خرید پله‌ای! 🚀'
      : stance === 'BUY'
        ? 'چراغ سبزِ خریدِ آروم و پله‌ای'
        : stance === 'SELL'
          ? 'حواست باشه وقت سیو سوده رفیق'
          : 'یه چایی بریز و فعلاً صبر کن ☕';

  const buyLowToman = px.toman * 0.965;
  const buyHighToman = px.toman * 0.992;
  const buyLowUsd = px.usdt * 0.965;
  const buyHighUsd = px.usdt * 0.992;

  return {
    symbol: params.symbol,
    baseAsset: params.baseAsset,
    generatedAt: Date.now(),
    stance,
    stanceLabelFa,
    confidencePercent: stance === 'HOLD' ? 68 : 79,
    verdictHeadline:
      chg >= 0
        ? `${px.persianName} (${params.baseAsset}) حالش خوبه و داره رو حمایت دلبری می‌کنه!`
        : `${px.persianName} (${params.baseAsset}) یه کم خسته شده و رفته تو استراحت`,
    friendlySummary:
      chg >= 0
        ? `قیمت الان ${px.persianName} حدود ${formatToman(px.toman)} تومنه ($${formatPrice(px.usdt)}) و تو ۲۴ ساعت اخیر ${chg.toFixed(2)}٪ تکون خورده. خلاصه کلام، خریدارا هنوز سرِ ذوقن و تو افت‌های کوچیک سریع می‌پرن وسط!`
        : `قیمت ${px.persianName} تو ۲۴ ساعت گذشته ${Math.abs(chg).toFixed(2)}٪ اومده پایین. غصه نخور رفیق، بازار نفس می‌کشه! به جای خرید عجولانه، بذار روی حمایت‌های پایین‌تر آروم و پله‌ای شکارش کنیم.`,
    shouldBuyOrSell:
      chg >= 0
        ? 'اگه دلت خرید می‌خواد، کل پولت رو یه جا خرج نکن! نصفش رو نزدیک محدوده خرید بذار، بقیه‌اش رو بعد از تثبیت بالای مقاومت اول.'
        : 'الان وقت قهرمان‌بازی نیست؛ صبر کن قیمت روی حمایت اول ترمز بزنه و بعد با حد ضرر مشخص تصمیم بگیر.',
    simpleTechnicalExplain:
      'داریم رو حالت نمایشی (دمو) با قیمت لحظه‌ای واقعی نوبیتکس چارت رو می‌بینیم. تو نسخه واقعی رو سرورت همزمان ۴ تایم‌فریم و اخبار داغ وب هم زیر ذره‌بین می‌ره!',
    tradePlan: {
      buyRangeToman: `${formatToman(buyLowToman)} تا ${formatToman(buyHighToman)} ت`,
      buyRangeUsd: `$${formatPrice(buyLowUsd)} - $${formatPrice(buyHighUsd)}`,
      target1Toman: `${formatToman(px.toman * 1.045)} تومان`,
      target1Usd: `$${formatPrice(px.usdt * 1.045)}`,
      target2Toman: `${formatToman(px.toman * 1.09)} تومان`,
      target2Usd: `$${formatPrice(px.usdt * 1.09)}`,
      stopLossToman: `${formatToman(px.toman * 0.94)} تومان`,
      stopLossUsd: `$${formatPrice(px.usdt * 0.94)}`,
    },
    keyLevels: {
      support: `${formatToman(px.toman * 0.955)} ت ($${formatPrice(px.usdt * 0.955)})`,
      resistance: `${formatToman(px.toman * 1.045)} ت ($${formatPrice(px.usdt * 1.045)})`,
    },
    riskTips: [
      'حد ضرر مثل کمربند ایمنیه؛ قبل از گاز دادن حتماً ببندش و کل سرمایت رو روی یه ارز نذار.',
      'هیچ سودی تو بازار فرار نمی‌کنه؛ پله‌ای خریدن همیشه اعصاب آدمو راحت‌تر نگه می‌داره!',
    ],
    customAnswer: params.question
      ? `در جواب سوال باحالت («${params.question}»): برای ${px.persianName} با نرخ فعلی ${formatToman(px.toman)} تومان، خرید پله‌ای حوالی حمایت ${formatToman(buyLowToman)} تومان خیلی کم‌ریسک‌تر از پریدن وسط هیجان بازاره رفیق!`
      : undefined,
  };
}

export function computeDemoAskReply(params: {
  question: string;
  baseAsset: string;
  markets: UnifiedMarketTicker[];
  usdtTomanRate: number;
}): { answer: string; suggestedFollowUps: string[] } {
  const rate = params.usdtTomanRate > 0 ? params.usdtTomanRate : DEFAULT_USDT_RATE;
  const qNorm = params.question.trim().toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک');

  const mentioned =
    params.markets.find((m) => {
      const sym = m.baseAsset.toLowerCase();
      const fa = (m.persianName || '').toLowerCase().replace(/ي/g, 'ی').replace(/ك/g, 'ک');
      return (
        (sym.length >= 2 && new RegExp(`\\b${sym}\\b`, 'i').test(qNorm)) ||
        (fa.length >= 2 && qNorm.includes(fa))
      );
    }) ||
    params.markets.find((m) => m.baseAsset === params.baseAsset) ||
    null;

  const targetAsset = mentioned?.baseAsset || params.baseAsset;
  const px = getFallbackPrice(targetAsset, params.markets, rate);
  const chg = mentioned?.change24hPercent ?? 0.8;
  const buyHint = formatToman(px.toman * 0.97);
  const sellHint = formatToman(px.toman * 1.045);
  const stopHint = formatToman(px.toman * 0.945);

  let answer = '';
  if (qNorm.includes('قرمز') || qNorm.includes('ریخت') || qNorm.includes('ضرر') || qNorm.includes('استرس')) {
    answer = `آروم باش رفیق، نفس عمیق بکش! بازار کریپتو همینه؛ یه روز سَبزِ بهاره، یه روز گوجه‌فرنگی! الان ${px.persianName} (${targetAsset}) حوالی ${formatToman(px.toman)} تومنه (${chg >= 0 ? '+' : ''}${chg.toFixed(1)}٪). اگه تو ضرری، تو هیجان و تهِ کندل قرمز نفروش؛ صبر کن رو حمایت ${buyHint} تومن واکنش بده و هیچ‌وقت بی‌حدضرر نرو تو معامله.`;
  } else if (qNorm.includes('تتر') || qNorm.includes('دلار') || qNorm.includes('بازار')) {
    const greenCount = params.markets.filter((m) => m.change24hPercent > 0).length;
    const redCount = params.markets.filter((m) => m.change24hPercent < 0).length;
    answer = `الان تتر تو نوبیتکس حدود ${formatToman(rate)} تومن معامله می‌شه. تو کل بازارم ${greenCount} تا ارز سبزن و ${redCount} تا قرمز! برای ${px.persianName} الان قیمت ${formatToman(px.toman)} تومنه ($${formatPrice(px.usdt)})؛ حواست به نوسان تتر هم باشه چون قیمت تومانی مستقیم با تتر بالا پایین می‌ره.`;
  } else if (qNorm.includes('کم') || qNorm.includes('نوسان') || qNorm.includes('ربات') || qNorm.includes('سود')) {
    answer = `با پول کم هم می‌شه قشنگ و شیک نوسان گرفت! کافیه بیای تو بخش «ربات سود ثابت»، روی ${px.persianName} با مبلغ ورود خودت و سود هدف منطقی (مثلاً ۲ تا ۴ درصد) ربات بسازی تا با حساب کارمزد دقیق، خودکار برات بخره و رو سود بفروشه — بدون اینکه کل روز چشم بدوزی به مانیتور!`;
  } else if (qNorm.includes('بخر') || qNorm.includes('فروش') || qNorm.includes('صبر') || qNorm.includes('نظرت')) {
    answer =
      chg >= 0
        ? `ببین رفیق، الان ${px.persianName} (${targetAsset}) رو ${formatToman(px.toman)} تومن ($${formatPrice(px.usdt)}) معامله می‌شه و تو ۲۴ ساعت اخیر ${chg.toFixed(1)}٪ رشد داشته. جای بدی نیست، ولی یه جا نپر وسط! اگه پله‌ای حوالی ${buyHint} تومن وارد شی، هدف اولت ${sellHint} تومن و حد ضررت ${stopHint} تومن خیلی منطقی و شسته رفته‌ست.`
        : `الان ${px.persianName} (${targetAsset}) رو ${formatToman(px.toman)} تومنه و ${Math.abs(chg).toFixed(1)}٪ اومده پایین. عجله نکن بذار کمی آروم بگیره؛ حوالی حمایت ${buyHint} تومن برای خرید پله‌ای خیلی جذاب‌تره و حد ضرر هم بذار رو ${stopHint} تومن که خیالت تخت باشه!`;
  } else {
    answer = `سوال خوبیه! الان ${px.persianName} (${targetAsset}) تو نوبیتکس ${formatToman(px.toman)} تومن (معادل $${formatPrice(px.usdt)}) قیمت داره. به زبان خودمونی بخوام بگم: محدوده ${buyHint} تومن برای خرید آروم بد نیست و تارگت نزدیکمون می‌تونه ${sellHint} تومن باشه، فقط همیشه پله‌ای کار کن و حد ضرر (${stopHint} تومن) یادت نره رفیق!`;
  }

  return {
    answer,
    suggestedFollowUps: [
      `حد ضرر و تارگت ${px.persianName} کجا بذارم بهتره؟`,
      'با سرمایه کم ربات سود بذارم یا دستی بخرم؟',
      'اوضاع تتر و بقیه بازار الان چطوره؟',
    ],
  };
}

export function computeDemoSentiment(
  baseAsset: string,
  persianName: string,
  symbol: string,
  market: UnifiedMarketTicker | null
): CoinSentimentAnalysis {
  const chg = market?.change24hPercent ?? 1.4;
  const score = Math.min(84, Math.max(26, Math.round(54 + chg * 3)));
  const suggestion: CoinSentimentAnalysis['suggestion'] =
    score >= 60 ? 'BUY' : score <= 42 ? 'SELL' : 'HOLD';

  return {
    symbol,
    baseAsset,
    generatedAt: Date.now(),
    sentimentScore: score,
    sentimentMoodFa:
      score >= 60
        ? 'جو باحال و خریدارپسند (دمو)'
        : score <= 42
          ? 'یه کم ترس و احتیاط (دمو)'
          : 'فاز ریلکس و انتظار (دمو)',
    suggestion,
    suggestionLabelFa:
      suggestion === 'BUY'
        ? 'جو خبری ردیفه، خرید پله‌ای می‌چسبه!'
        : suggestion === 'SELL'
          ? 'دست به عصا برو، هوای سودت رو داشته باش'
          : 'چایی بریز و صبر کن جهت روشن‌تر شه',
    plainSummaryFa: `تو حالت دمو، نبض خبرها و حال‌وهوای ${persianName} عدد ${score} از ۱۰۰ رو نشون می‌ده. خلاصه‌ش اینه که تریدرها فعلاً چهارچشمی دارن حمایت‌های اصلی رو زیر نظر می‌گیرن و بی‌گدار به آب نمی‌زنن.`,
    socialBuzzFa: `تو شبکه‌های اجتماعی بچه‌ها حسابی درباره ${persianName} (${baseAsset}) گپ می‌زنن؛ بعضیا دنبال پامپ بعدی‌ان و حرفه‌ای‌ترها حواسشون به حجم معاملات اسپاته.`,
    marketFearGreed: {
      value: Math.min(82, Math.max(24, score + 3)),
      classification: score >= 58 ? 'Greed' : 'Neutral',
      classificationFa: score >= 58 ? 'طمع ملایم' : 'خنثی',
    },
    newsItems: [
      {
        headline: `رصد نقدینگی و جنب‌وجوش معاملات ${persianName}`,
        summary:
          'حجم معاملات ۲۴ ساعته تو صرافی‌ها نشون می‌ده نه خریدارها خیلی عجله دارن نه فروشنده‌ها؛ یه‌جورایی دارن همو وزن‌کشی می‌کنن!',
        impact: chg >= 0 ? 'POSITIVE' : 'NEUTRAL',
        dateHint: 'پیش‌نمایش نمایشی',
      },
      {
        headline: `توصیه رفقای تکنیکال درباره ${baseAsset}: حد ضرر فراموش نشه!`,
        summary:
          'کاربلدهای بازار می‌گن جای خرید یهویی، پله‌ای خریدن و بستن ربات با حد سود شفاف اعصاب آدمو خیلی راحت‌تر می‌ذاره.',
        impact: 'NEUTRAL',
        dateHint: 'امروز',
      },
    ],
    sources: [],
  };
}

export function computeDemoBacktest(
  payload: Record<string, unknown>,
  candles: KlineCandle[],
  markets: UnifiedMarketTicker[],
  usdtTomanRate: number
): BacktestResult {
  const baseAsset = String(payload.baseAsset || 'BTC').toUpperCase();
  const quoteCurrency: QuoteCurrency = payload.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
  const symbol = String(payload.symbol || `${baseAsset}${quoteCurrency}`);
  const timeframe = (payload.timeframe as Timeframe) || '1h';
  const orderAmount = Number(payload.orderAmount) || (quoteCurrency === 'IRT' ? 10_000_000 : 150);
  const slPct = Number(payload.stopLossPercent) || 2.5;
  const tpPct = Number(payload.takeProfitPercent) || 5.0;

  const rate = usdtTomanRate > 0 ? usdtTomanRate : DEFAULT_USDT_RATE;
  const px = getFallbackPrice(baseAsset, markets, rate);
  const fallbackPrice = quoteCurrency === 'IRT' ? px.toman : px.usdt;

  const series =
    candles.length >= 20
      ? candles.map((c) => ({ time: c.openTime, close: c.close }))
      : Array.from({ length: 48 }, (_, idx) => {
          const wave = Math.sin(idx / 4) * 0.024 + idx * 0.0008;
          const p = fallbackPrice * (1 + wave);
          return {
            time: Date.now() - (48 - idx) * 3600_000,
            close: p,
          };
        });

  const initialCapital = orderAmount * 2;
  let equity = initialCapital;
  let peak = equity;
  let maxDd = 0;
  let grossProfit = 0;
  let grossLoss = 0;
  const equityCurve: Array<{ time: number; equity: number }> = [];
  const trades: BacktestTrade[] = [];

  const step = Math.max(4, Math.floor(series.length / 8));
  for (let i = 0; i < series.length; i++) {
    const c = series[i];
    if (i > 0 && i % step === 0 && i + 2 < series.length) {
      const entry = series[i - 2];
      const win = c.close >= entry.close * 0.996;
      const pct = win ? tpPct * 0.72 : -slPct * 0.8;
      const pnl = (orderAmount * pct) / 100;
      equity += pnl;
      if (pnl >= 0) grossProfit += pnl;
      else grossLoss += Math.abs(pnl);

      trades.push({
        entryTime: entry.time,
        exitTime: c.time,
        entryPrice: entry.close,
        exitPrice: c.close,
        pnlQuote: pnl,
        pnlPercent: pct,
        exitReason: win ? 'TAKE_PROFIT' : 'STOP_LOSS',
      });
    }
    if (equity > peak) peak = equity;
    const dd = peak > 0 ? ((peak - equity) / peak) * 100 : 0;
    if (dd > maxDd) maxDd = dd;
    equityCurve.push({ time: c.time, equity });
  }

  const winningTrades = trades.filter((t) => t.pnlQuote >= 0).length;
  const losingTrades = trades.length - winningTrades;
  const netProfitQuote = equity - initialCapital;
  const netProfitPercent = initialCapital > 0 ? (netProfitQuote / initialCapital) * 100 : 0;
  const profitFactor = grossLoss > 0 ? grossProfit / grossLoss : grossProfit > 0 ? 3.2 : 1;

  return {
    symbol,
    quoteCurrency,
    timeframe,
    candlesTested: series.length,
    initialCapital,
    finalCapital: equity,
    netProfitQuote,
    netProfitPercent,
    totalTrades: trades.length,
    winningTrades,
    losingTrades,
    winRatePercent: trades.length > 0 ? (winningTrades / trades.length) * 100 : 0,
    maxDrawdownPercent: maxDd,
    profitFactor,
    equityCurve,
    trades,
  };
}

export function calculateDemoBotRealizedPnlMetrics(
  bot: Pick<BotStrategyConfig, 'quoteCurrency' | 'orderAmount' | 'stats'>,
  usdtTomanRate: number
) {
  const rate = usdtTomanRate > 0 ? usdtTomanRate : DEFAULT_USDT_RATE;
  const realizedQuote = Number(bot.stats?.realizedPnl || 0);
  const capital = Math.max(0, Number(bot.orderAmount || 0));
  const pct = capital > 0 ? (realizedQuote / capital) * 100 : 0;
  const toman = bot.quoteCurrency === 'IRT' ? realizedQuote : realizedQuote * rate;
  const usdt = bot.quoteCurrency === 'USDT' ? realizedQuote : rate > 0 ? realizedQuote / rate : 0;

  const tomaRounded = Math.round(toman);
  const tomanText =
    tomaRounded === 0
      ? '0 تومان'
      : `${tomaRounded > 0 ? '+' : '-'}${Math.abs(tomaRounded).toLocaleString('en-US')} تومان`;

  const usdtAbs = Math.abs(usdt);
  const usdtText =
    usdtAbs < 0.0001
      ? '$0.00 تتر'
      : `${usdt >= 0 ? '+' : '-'}$${usdtAbs.toFixed(usdtAbs < 1 ? 4 : 2)} تتر`;

  const pctText =
    Math.abs(pct) < 0.0001 ? '0.00%' : `${pct > 0 ? '+' : ''}${pct.toFixed(2)}%`;

  return {
    toman,
    usdt,
    pct,
    tomanText,
    usdtText,
    pctText,
    formattedText: `${bot.quoteCurrency === 'IRT' ? `${tomanText} (${usdtText})` : `${usdtText} (${tomanText})`} · ${pctText}`,
  };
}

export function evaluateDemoProfitBot(
  bot: ProfitBotConfig,
  orderBook: OrderBookSnapshot,
  now = Date.now(),
  balances: SpotBalance[] = []
): {
  bot: ProfitBotConfig;
  newCycle?: ProfitBotCycleRecord;
  newLogs: ProfitBotDecisionLog[];
} {
  const updated: ProfitBotConfig = {
    ...bot,
    stats: { ...bot.stats },
    dailyStats: { ...bot.dailyStats },
    activePosition: bot.activePosition ? { ...bot.activePosition } : null,
  };
  const newLogs: ProfitBotDecisionLog[] = [];
  let newCycle: ProfitBotCycleRecord | undefined;

  if (!updated.isActive) {
    return { bot: updated, newLogs };
  }

  updated.lastCheckedAt = now;
  updated.updatedAt = now;

  if (!updated.activePosition) {
    if (updated.dailyStats.tradesCount >= updated.maxDailyTrades) {
      updated.isActive = false;
      updated.botStatus = 'STOPPED';
      updated.lastStatusReason = `سقف تعداد معاملات مجاز در روز (${updated.maxDailyTrades}) پر شده است.`;
      return { bot: updated, newLogs };
    }

    const fundingMode = updated.fundingMode || 'QUOTE_BUY';
    const existingPct = Math.min(100, Math.max(1, Number(updated.existingBalancePercent ?? 50)));
    const minNotional = getMinimumOrderNotional(updated.quoteCurrency);

    if (fundingMode === 'EXISTING_ASSET' || fundingMode === 'AUTO_PREFER_EXISTING') {
      const freeBase =
        balances.find((b) => b.asset.toUpperCase() === updated.baseAsset.toUpperCase())?.free ?? 0;
      const marketBidPrice =
        orderBook.bids?.[0]?.price || orderBook.lastTradePrice || orderBook.asks?.[0]?.price || 0;
      const refEntryPrice =
        updated.existingEntryPrice && updated.existingEntryPrice > 0
          ? updated.existingEntryPrice
          : marketBidPrice;

      const alloc = computeExistingBalanceAllocation({
        freeBase,
        percent: existingPct,
        referencePrice: refEntryPrice,
        minNotional,
        step: 1e-6,
        baseAsset: updated.baseAsset,
        quoteCurrency: updated.quoteCurrency,
      });

      if (alloc.ok) {
        const cycleIndex = updated.stats.completedCycles + 1;
        const totalCostQuote = alloc.allocatedQty * refEntryPrice;
        const reqSell =
          updated.targetSellPrice && updated.targetSellPrice > 0
            ? updated.targetSellPrice
            : computeRequiredSellPrice(
                alloc.allocatedQty,
                totalCostQuote,
                updated.targetNetProfit,
                updated.feeRate,
                updated.otherFeesQuote
              );
        const sellSim = simulateOrderBookSell(
          orderBook,
          alloc.allocatedQty,
          totalCostQuote,
          updated.targetNetProfit,
          updated.feeRate,
          updated.otherFeesQuote,
          updated.targetSellPrice
        );
        updated.activePosition = {
          cycleIndex,
          buyOrderId: `demo-existing-${now}`,
          buyOrderType: updated.orderType,
          requestedQuoteAmount: totalCostQuote,
          requestedQty: alloc.allocatedQty,
          filledGrossQty: alloc.allocatedQty,
          netOwnedQty: alloc.allocatedQty,
          actualBuyAvgPrice: refEntryPrice,
          buyPrincipalQuote: totalCostQuote,
          buyFeeQuote: 0,
          buyFeeAsset: updated.baseAsset,
          totalBuyCostQuote: totalCostQuote,
          otherFeesQuote: updated.otherFeesQuote,
          buyFilledAt: now,
          partialFill: false,
          fromExistingBalance: true,
          lastExecutableSellPrice: sellSim.executableAvgSellPrice,
          lastExecutableProceedsQuote: sellSim.grossProceedsQuote,
          lastEstimatedSellFeeQuote: sellSim.sellFeeQuote,
          lastEstimatedNetProfitQuote: sellSim.netProfitQuote,
          lastHasSufficientDepth: sellSim.hasSufficientDepth,
          lastSpreadPercent: sellSim.spreadPercent,
          lastSlippagePercent: sellSim.slippagePercent,
          lastRequiredSellPrice: reqSell,
          lastProgressPercent: computeProfitProgressPercent(sellSim.netProfitQuote, updated.targetNetProfit),
          lastEvaluatedAt: now,
        };
        updated.stats.currentCapitalInvolved += totalCostQuote;
        updated.stats.lastBuyPrice = refEntryPrice;
        updated.botStatus = 'WAITING_FOR_PROFIT';
        updated.lastStatusReason = `ورود مستقیم با ${existingPct}٪ موجودی فعلی (${alloc.allocatedQty} ${updated.baseAsset}) در نرخ مرجع ${formatQuotePrice(
          refEntryPrice,
          updated.quoteCurrency
        )} · در انتظار رسیدن به هدف فروش.`;
        newLogs.push({
          id: `demo-plog-${now}-buy`,
          botId: updated.id,
          cycleIndex,
          status: 'BUY_FILLED',
          event: 'BUY_FILLED',
          price: refEntryPrice,
          netProfitQuote: sellSim.netProfitQuote,
          message: updated.lastStatusReason,
          timestamp: now,
        });
        return { bot: updated, newLogs };
      }

      if (fundingMode === 'EXISTING_ASSET') {
        updated.isActive = false;
        updated.botStatus = 'NEEDS_USER_REVIEW';
        updated.lastStatusReason =
          alloc.reason || `موجودی آزاد ${updated.baseAsset} برای ورود کافی نیست.`;
        return { bot: updated, newLogs };
      }
    }

    const buySim = simulateOrderBookBuy(orderBook, updated.entryAmount, updated.feeRate);
    if (buySim.bestAsk <= 0 || !buySim.canFillFull) {
      updated.botStatus = 'CHECKING_MARKET';
      updated.lastStatusReason = 'عمق فروش (Ask) دفتر سفارش برای مبلغ ورود کافی نیست؛ در انتظار نقدینگی.';
      return { bot: updated, newLogs };
    }

    const isRepeatCycle = updated.stats.completedCycles > 0;
    const configuredReentryPrice =
      updated.reentryTargetPrice && updated.reentryTargetPrice > 0
        ? updated.reentryTargetPrice
        : updated.stats.lastBuyPrice && updated.stats.lastBuyPrice > 0
          ? updated.stats.lastBuyPrice
          : 0;
    const shouldWaitForEntryPrice = isRepeatCycle
      ? updated.reentryPolicy !== 'IMMEDIATE' && configuredReentryPrice > 0
      : Boolean(
          updated.waitEntryPriceOnFirstBuy &&
            updated.reentryTargetPrice &&
            updated.reentryTargetPrice > 0
        );
    const activeTargetEntryPrice = isRepeatCycle
      ? configuredReentryPrice
      : updated.reentryTargetPrice || 0;

    if (shouldWaitForEntryPrice && activeTargetEntryPrice > 0 && buySim.bestAsk > activeTargetEntryPrice) {
      updated.botStatus = 'CHECKING_MARKET';
      updated.lastStatusReason = `در انتظار رسیدن قیمت بازار به مبلغ ورود تعیین‌شده (${formatQuotePrice(
        activeTargetEntryPrice,
        updated.quoteCurrency
      )}) · قیمت لحظه‌ای: ${formatQuotePrice(buySim.bestAsk, updated.quoteCurrency)}`;
      return { bot: updated, newLogs };
    }

    if (buySim.spreadPercent > updated.maxSpreadPercent) {
      updated.botStatus = 'CHECKING_MARKET';
      updated.lastStatusReason = `اسپرد بازار (${buySim.spreadPercent.toFixed(2)}٪) بیش از حد مجاز است.`;
      return { bot: updated, newLogs };
    }

    const buyPrice = updated.orderType === 'LIMIT' ? buySim.bestAsk : buySim.avgBuyPrice;
    const qtyCheck = resolveOrderQuantityForNotional({
      entryAmount: updated.entryAmount,
      buyPrice,
      minNotional,
      step: 1e-6,
      maxCapitalHeadroom: Math.max(0, updated.maxCapitalInvolved - updated.stats.currentCapitalInvolved),
    });
    if (!qtyCheck.ok || qtyCheck.quantity <= 0) {
      updated.isActive = false;
      updated.botStatus = 'NEEDS_USER_REVIEW';
      updated.lastStatusReason = `مبلغ ورود باید حداقل معادل ${
        updated.quoteCurrency === 'IRT' ? '۵۰,۰۰۰ تومان' : '۰.۵ USDT'
      } و منطبق با دقت سفارش نوبیتکس باشد.`;
      return { bot: updated, newLogs };
    }

    const cycleIndex = updated.stats.completedCycles + 1;
    const effectiveCost = qtyCheck.bumpedForMinNotional ? qtyCheck.notional : buySim.totalBuyCostQuote;
    const effectiveGrossQty = qtyCheck.bumpedForMinNotional ? qtyCheck.quantity : buySim.grossQty;
    const effectiveNetQty = effectiveGrossQty * (1 - updated.feeRate);
    const effectiveBuyFee = effectiveCost * updated.feeRate;

    const reqSell =
      updated.targetSellPrice && updated.targetSellPrice > 0
        ? updated.targetSellPrice
        : computeRequiredSellPrice(
            effectiveNetQty,
            effectiveCost,
            updated.targetNetProfit,
            updated.feeRate,
            updated.otherFeesQuote
          );
    const sellSim = simulateOrderBookSell(
      orderBook,
      effectiveNetQty,
      effectiveCost,
      updated.targetNetProfit,
      updated.feeRate,
      updated.otherFeesQuote,
      updated.targetSellPrice
    );
    updated.activePosition = {
      cycleIndex,
      buyOrderId: `demo-pbuy-${now}`,
      buyOrderType: updated.orderType,
      requestedQuoteAmount: updated.entryAmount,
      requestedQty: effectiveGrossQty,
      filledGrossQty: effectiveGrossQty,
      netOwnedQty: effectiveNetQty,
      actualBuyAvgPrice: buyPrice,
      buyPrincipalQuote: effectiveCost,
      buyFeeQuote: effectiveBuyFee,
      buyFeeAsset: updated.quoteCurrency,
      totalBuyCostQuote: effectiveCost,
      otherFeesQuote: updated.otherFeesQuote,
      buyFilledAt: now,
      partialFill: false,
      lastExecutableSellPrice: sellSim.executableAvgSellPrice,
      lastExecutableProceedsQuote: sellSim.grossProceedsQuote,
      lastEstimatedSellFeeQuote: sellSim.sellFeeQuote,
      lastEstimatedNetProfitQuote: sellSim.netProfitQuote,
      lastHasSufficientDepth: sellSim.hasSufficientDepth,
      lastSpreadPercent: sellSim.spreadPercent,
      lastSlippagePercent: sellSim.slippagePercent,
      lastRequiredSellPrice: reqSell,
      lastProgressPercent: computeProfitProgressPercent(sellSim.netProfitQuote, updated.targetNetProfit),
      lastEvaluatedAt: now,
    };
    updated.stats.currentCapitalInvolved += effectiveCost;
    updated.stats.lastBuyPrice = buyPrice;
    updated.botStatus = 'WAITING_FOR_PROFIT';
    updated.lastStatusReason = `خرید فوری در قیمت ${formatQuotePrice(
      buyPrice,
      updated.quoteCurrency
    )} انجام شد · در انتظار رسیدن به هدف فروش.`;

    newLogs.push({
      id: `demo-plog-${now}-buy`,
      botId: updated.id,
      cycleIndex,
      status: 'BUY_FILLED',
      event: 'BUY_FILLED',
      price: buyPrice,
      netProfitQuote: sellSim.netProfitQuote,
      message: updated.lastStatusReason,
      timestamp: now,
    });
    return { bot: updated, newLogs };
  }

  const pos = updated.activePosition;
  const sellSim = simulateOrderBookSell(
    orderBook,
    pos.netOwnedQty,
    pos.totalBuyCostQuote,
    updated.targetNetProfit,
    updated.feeRate,
    pos.otherFeesQuote ?? updated.otherFeesQuote,
    updated.targetSellPrice
  );
  pos.lastExecutableSellPrice = sellSim.executableAvgSellPrice;
  pos.lastExecutableProceedsQuote = sellSim.grossProceedsQuote;
  pos.lastEstimatedSellFeeQuote = sellSim.sellFeeQuote;
  pos.lastEstimatedNetProfitQuote = sellSim.netProfitQuote;
  pos.lastHasSufficientDepth = sellSim.hasSufficientDepth;
  pos.lastSpreadPercent = sellSim.spreadPercent;
  pos.lastSlippagePercent = sellSim.slippagePercent;
  pos.lastRequiredSellPrice = sellSim.requiredSellPrice;
  pos.lastProgressPercent = computeProfitProgressPercent(sellSim.netProfitQuote, updated.targetNetProfit);
  pos.lastEvaluatedAt = now;

  if (updated.maxWaitMinutes && now - pos.buyFilledAt >= updated.maxWaitMinutes * 60_000) {
    updated.isActive = false;
    updated.botStatus = 'NEEDS_USER_REVIEW';
    updated.lastStatusReason = `حداکثر زمان انتظار (${updated.maxWaitMinutes} دقیقه) به پایان رسید؛ نیازمند بررسی کاربر.`;
    return { bot: updated, newLogs };
  }

  if (sellSim.canTriggerTarget) {
    if (sellSim.spreadPercent > updated.maxSpreadPercent) {
      updated.botStatus = 'WAITING_FOR_PROFIT';
      updated.lastStatusReason = `سود به هدف رسید اما اسپرد بازار (${sellSim.spreadPercent.toFixed(
        2
      )}٪) بیش از سقف مجاز است؛ منتظر تعادل قیمت.`;
      return { bot: updated, newLogs };
    }

    const finalNet = roundQuoteValue(sellSim.netProfitQuote, updated.quoteCurrency);
    newCycle = {
      id: `demo-pcycle-${now}`,
      botId: updated.id,
      cycleIndex: pos.cycleIndex,
      symbol: updated.symbol,
      baseAsset: updated.baseAsset,
      quoteCurrency: updated.quoteCurrency,
      mode: updated.mode,
      orderType: updated.orderType,
      entryAmountQuote: pos.totalBuyCostQuote,
      actualBuyAvgPrice: pos.actualBuyAvgPrice,
      boughtQty: pos.filledGrossQty,
      buyFeeQuote: pos.buyFeeQuote,
      totalBuyCostQuote: pos.totalBuyCostQuote,
      actualSellAvgPrice: sellSim.executableAvgSellPrice,
      soldQty: pos.netOwnedQty,
      grossSellProceedsQuote: sellSim.grossProceedsQuote,
      sellFeeQuote: sellSim.sellFeeQuote,
      otherFeesQuote: pos.otherFeesQuote,
      finalNetProfitQuote: finalNet,
      targetNetProfitQuote: updated.targetNetProfit,
      exitReason: 'TARGET_PROFIT',
      startedAt: pos.buyFilledAt,
      completedAt: now,
    };
    updated.activePosition = null;
    updated.stats.completedCycles += 1;
    updated.stats.winningCycles += finalNet >= 0 ? 1 : 0;
    updated.stats.losingCycles += finalNet < 0 ? 1 : 0;
    updated.stats.totalNetProfitQuote = roundQuoteValue(
      updated.stats.totalNetProfitQuote + finalNet,
      updated.quoteCurrency
    );
    updated.stats.totalFeesPaidQuote = roundQuoteValue(
      updated.stats.totalFeesPaidQuote + pos.buyFeeQuote + sellSim.sellFeeQuote,
      updated.quoteCurrency
    );
    updated.stats.currentCapitalInvolved = Math.max(
      0,
      updated.stats.currentCapitalInvolved - pos.totalBuyCostQuote
    );
    updated.dailyStats.tradesCount += 1;
    updated.dailyStats.netProfitQuote = roundQuoteValue(
      updated.dailyStats.netProfitQuote + finalNet,
      updated.quoteCurrency
    );

    if (updated.sequenceMode === 'CYCLE_REPEAT') {
      if (updated.fundingMode === 'EXISTING_ASSET') {
        updated.botStatus = 'CHECKING_MARKET';
        updated.lastStatusReason = `فروش با سود خالص +${finalNet.toLocaleString('en-US')} انجام شد · بررسی موجودی باقیمانده ${updated.baseAsset} برای چرخه بعدی.`;
      } else {
        const reentryPrice =
          updated.reentryTargetPrice && updated.reentryTargetPrice > 0
            ? updated.reentryTargetPrice
            : updated.stats.lastBuyPrice || pos.actualBuyAvgPrice;
        const waitReentry = updated.reentryPolicy !== 'IMMEDIATE' && reentryPrice > 0;
        updated.botStatus = waitReentry ? 'CHECKING_MARKET' : 'SELL_FILLED';
        updated.lastStatusReason = waitReentry
          ? `فروش فوری با سود خالص +${finalNet.toLocaleString('en-US')} انجام شد · در انتظار بازگشت قیمت به ${formatQuotePrice(
              reentryPrice,
              updated.quoteCurrency
            )} برای تکرار چرخه.`
          : `فروش با سود خالص +${finalNet.toLocaleString('en-US')} انجام شد · آماده چرخه بعدی.`;
      }
    } else if (updated.sequenceMode === 'PREPARE_NEXT') {
      updated.isActive = false;
      updated.botStatus = 'READY_TO_BUY';
      updated.lastStatusReason = 'فروش با سود هدف تکمیل شد؛ ربات برای خرید بعدی آماده شد (در انتظار دستور شروع).';
    } else {
      updated.isActive = false;
      updated.botStatus = 'STOPPED';
      updated.lastStatusReason = 'تک‌معامله با سود هدف تکمیل و ربات متوقف شد.';
    }

    newLogs.push({
      id: `demo-plog-${now}-sell`,
      botId: updated.id,
      cycleIndex: pos.cycleIndex,
      status: 'SELL_FILLED',
      event: 'SELL_FILLED',
      price: sellSim.executableAvgSellPrice,
      netProfitQuote: finalNet,
      message: updated.lastStatusReason,
      timestamp: now,
    });
    return { bot: updated, newCycle, newLogs };
  }

  updated.botStatus = 'WAITING_FOR_PROFIT';
  if (!sellSim.hasSufficientDepth) {
    updated.lastStatusReason =
      'عمق دفتر سفارش برای فروش کل دارایی کافی نیست؛ ربات در انتظار نقدینگی است.';
  } else if (updated.targetSellPrice && updated.targetSellPrice > 0) {
    updated.lastStatusReason = `در انتظار رسیدن قیمت به ${formatQuotePrice(
      updated.targetSellPrice,
      updated.quoteCurrency
    )} · سود لحظه‌ای: ${roundQuoteValue(
      sellSim.netProfitQuote,
      updated.quoteCurrency
    ).toLocaleString('en-US')} (${updated.quoteCurrency})`;
  } else {
    updated.lastStatusReason = `در انتظار سود هدف · سود خالص فعلی: ${roundQuoteValue(
      sellSim.netProfitQuote,
      updated.quoteCurrency
    ).toLocaleString('en-US')} (${updated.quoteCurrency})`;
  }
  return { bot: updated, newLogs };
}

export function computeDemoAiCycleProPreview(
  orderBook: OrderBookSnapshot | null,
  markets: UnifiedMarketTicker[],
  params: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    capitalAmount: number;
    capitalUsageMode: AiCycleProCapitalUsageMode;
    capitalPortionPercent: number;
    minTargetNetProfitPercent: number;
    stopLossPercent: number;
    maxSlippagePercent: number;
    maxSpreadPercent: number;
  }
): AiCycleProMarketPreview {
  const symbol = `${params.baseAsset.toUpperCase()}${params.quoteCurrency}`;
  const ticker = markets.find((m) => m.baseAsset.toUpperCase() === params.baseAsset.toUpperCase());
  const refPrice =
    (params.quoteCurrency === 'USDT' ? ticker?.priceUsdt : ticker?.priceToman) ||
    orderBook?.lastTradePrice ||
    orderBook?.asks?.[0]?.price ||
    1;
  const effectiveNotional =
    params.capitalUsageMode === 'FULL'
      ? params.capitalAmount
      : (params.capitalAmount * Math.max(10, Math.min(100, params.capitalPortionPercent || 100))) / 100;

  const syntheticBook: OrderBookSnapshot = orderBook || {
    symbol,
    quoteCurrency: params.quoteCurrency,
    timestamp: Date.now(),
    lastTradePrice: refPrice,
    spread: Math.max(0, refPrice * 0.002),
    spreadPercent: 0.2,
    bids: [
      {
        price: refPrice * 0.999,
        quantity: (effectiveNotional * 2.5) / Math.max(1e-9, refPrice),
        total: (effectiveNotional * 2.5) / Math.max(1e-9, refPrice),
      },
      {
        price: refPrice * 0.996,
        quantity: (effectiveNotional * 4) / Math.max(1e-9, refPrice),
        total: (effectiveNotional * 6.5) / Math.max(1e-9, refPrice),
      },
    ],
    asks: [
      {
        price: refPrice * 1.001,
        quantity: (effectiveNotional * 2.5) / Math.max(1e-9, refPrice),
        total: (effectiveNotional * 2.5) / Math.max(1e-9, refPrice),
      },
      {
        price: refPrice * 1.004,
        quantity: (effectiveNotional * 4) / Math.max(1e-9, refPrice),
        total: (effectiveNotional * 6.5) / Math.max(1e-9, refPrice),
      },
    ],
  };

  const buySim = simulateOrderBookBuy(syntheticBook, effectiveNotional, DEFAULT_NOBITEX_FEE_RATE);
  const estSellSim = simulateOrderBookSell(
    syntheticBook,
    Math.max(1e-8, buySim.netQtyReceived),
    buySim.totalBuyCostQuote,
    0,
    DEFAULT_NOBITEX_FEE_RATE
  );

  const spread = Number((buySim.spreadPercent || syntheticBook.spreadPercent || 0.2).toFixed(3));
  const slippage = Number((buySim.slippagePercent || 0.08).toFixed(3));
  const change24h = ticker?.change24hPercent ?? 0.5;
  const bidDepth = syntheticBook.bids.reduce((s, x) => s + x.price * x.quantity, 0);
  const askDepth = syntheticBook.asks.reduce((s, x) => s + x.price * x.quantity, 0);

  const favorableSpread = spread <= params.maxSpreadPercent;
  const favorableSlippage = slippage <= params.maxSlippagePercent;
  const trendOk = change24h > -3.5;
  const favorable = favorableSpread && favorableSlippage && trendOk && buySim.canFillFull;
  const targetPct = Math.max(params.minTargetNetProfitPercent, Math.min(4.5, 1.4 + spread + slippage));
  const roundTripFactor = 1 + targetPct / 100 + DEFAULT_NOBITEX_FEE_RATE * 2 + slippage / 100;
  const suggestedBuy = buySim.bestAsk || refPrice;
  const suggestedSell = roundQuoteValue(suggestedBuy * roundTripFactor, params.quoteCurrency);

  const decision: AiCycleProDecision = {
    action: favorable ? 'BUY' : 'HOLD_CASH',
    marketCondition: favorable ? 'FAVORABLE' : trendOk ? 'NEUTRAL' : 'UNFAVORABLE',
    confidencePercent: favorable ? 78 : 48,
    trendScore: Math.round(Math.max(15, Math.min(92, 56 + change24h * 4))),
    liquidityScore: favorableSpread && favorableSlippage ? 88 : 52,
    volatilityPercent: Number(Math.max(0.4, Math.abs(change24h) * 0.45).toFixed(2)),
    spreadPercent: spread,
    estimatedSlippagePercent: slippage,
    recommendedCapitalPortionPercent:
      params.capitalUsageMode === 'FULL' ? 100 : params.capitalPortionPercent,
    recommendedTargetNetProfitPercent: Number(targetPct.toFixed(2)),
    recommendedStopLossPercent: params.stopLossPercent,
    suggestedBuyPrice: roundQuoteValue(suggestedBuy, params.quoteCurrency),
    suggestedSellPrice: suggestedSell,
    regimeLabelFa: favorable ? 'شرایط مناسب ورود هوشمند' : 'نقد نگه‌داشتن سرمایه (احتیاطی)',
    reasoningFa: favorable
      ? `اسپرد (${spread.toFixed(2)}٪) و لغزش برآوردی (${slippage.toFixed(2)}٪) در محدوده ایمن هستند و نقدینگی دفتر سفارش برای ورود مناسب است.`
      : `به دلیل اسپرد (${spread.toFixed(2)}٪)، لغزش (${slippage.toFixed(2)}٪) یا مومنتوم فعلی، سیستم نگهداشت نقدی را امن‌تر تشخیص داد.`,
    riskWarningFa: `حد ضرر فعال ${params.stopLossPercent}٪ و رعایت کارمزد رفت‌وبرگشت نوبیتکس (${(DEFAULT_NOBITEX_FEE_RATE * 200).toFixed(2)}٪).`,
    usedFallback: false,
    analyzedAt: Date.now(),
  };

  const resolvedBestBid = estSellSim.bestBid || syntheticBook.bids[0]?.price || refPrice;
  const resolvedBestAsk = buySim.bestAsk || syntheticBook.asks[0]?.price || refPrice;

  return {
    symbol,
    baseAsset: params.baseAsset.toUpperCase(),
    quoteCurrency: params.quoteCurrency,
    currentPrice: refPrice,
    bestBid: resolvedBestBid,
    bestAsk: resolvedBestAsk,
    spreadPercent: spread,
    bidDepthQuote: roundQuoteValue(bidDepth, params.quoteCurrency),
    askDepthQuote: roundQuoteValue(askDepth, params.quoteCurrency),
    estimatedBuySlippagePercent: slippage,
    estimatedSellSlippagePercent: Number((estSellSim.slippagePercent || slippage).toFixed(3)),
    decision,
  };
}

export function evaluateDemoAiCycleProBot(
  bot: AiCycleProConfig,
  orderBook: OrderBookSnapshot,
  markets: UnifiedMarketTicker[],
  now = Date.now()
): {
  bot: AiCycleProConfig;
  newCycle?: AiCycleProCycleRecord;
  newLogs: AiCycleProLog[];
  pendingConfirmation?: PendingBotConfirmation;
} {
  const updated: AiCycleProConfig = {
    ...bot,
    stats: { ...bot.stats },
    dailyStats: { ...bot.dailyStats },
    activePosition: bot.activePosition ? { ...bot.activePosition } : null,
  };
  const newLogs: AiCycleProLog[] = [];
  let newCycle: AiCycleProCycleRecord | undefined;

  if (!updated.isActive) {
    return { bot: updated, newLogs };
  }

  updated.lastCheckedAt = now;
  updated.updatedAt = now;

  const preview = computeDemoAiCycleProPreview(orderBook, markets, {
    baseAsset: updated.baseAsset,
    quoteCurrency: updated.quoteCurrency,
    capitalAmount: updated.capitalAmount,
    capitalUsageMode: updated.capitalUsageMode,
    capitalPortionPercent: updated.capitalPortionPercent,
    minTargetNetProfitPercent: updated.minTargetNetProfitPercent,
    stopLossPercent: updated.stopLossPercent,
    maxSlippagePercent: updated.maxSlippagePercent,
    maxSpreadPercent: updated.maxSpreadPercent,
  });
  updated.lastPrice = preview.currentPrice;

  if (!updated.activePosition) {
    if (updated.dailyStats.lossQuote >= updated.maxDailyLoss) {
      updated.isActive = false;
      updated.status = 'PAUSED_RISK';
      updated.lastStatusReason = `سقف زیان روزانه (${formatQuotePrice(updated.maxDailyLoss, updated.quoteCurrency)}) پر شده و ربات متوقف شد.`;
      return { bot: updated, newLogs };
    }

    const cycleIndex = updated.stats.completedCycles + 1;
    updated.lastDecision = preview.decision;

    if (preview.decision.action !== 'BUY') {
      updated.status = 'WAITING_CASH';
      updated.lastStatusReason = preview.decision.reasoningFa;
      newLogs.push({
        id: `demo-aclog-${now}-wait`,
        botId: updated.id,
        cycleIndex,
        status: 'WAITING_CASH',
        event: 'WAIT_CASH',
        price: preview.currentPrice,
        message: preview.decision.reasoningFa,
        timestamp: now,
      });
      return { bot: updated, newLogs };
    }

    const entryNotional = roundQuoteValue(
      updated.capitalUsageMode === 'FULL'
        ? updated.capitalAmount
        : (updated.capitalAmount * Math.max(10, Math.min(100, updated.capitalPortionPercent))) / 100,
      updated.quoteCurrency
    );
    const buySim = simulateOrderBookBuy(orderBook, entryNotional, updated.feeRate);
    const execPrice =
      buySim.avgBuyPrice > 0 ? buySim.avgBuyPrice : preview.bestAsk || preview.currentPrice;
    const grossQty =
      buySim.grossQty > 0 ? buySim.grossQty : entryNotional / Math.max(1e-9, execPrice);

    if (updated.executionConfirmationMode === 'MANUAL_CONFIRM') {
      updated.status = 'ANALYZING';
      updated.lastStatusReason = 'فرصت خرید توسط هوش مصنوعی شناسایی شد و در صف تأیید دستی قرار گرفت.';
      const pendingConfirmation: PendingBotConfirmation = {
        id: `demo-pconf-ac-${now}`,
        userId: 'demo-user',
        botId: updated.id,
        botType: 'AI_CYCLE_PRO',
        botName: updated.name,
        symbol: updated.symbol,
        baseAsset: updated.baseAsset,
        quoteCurrency: updated.quoteCurrency,
        mode: updated.mode,
        side: 'BUY',
        orderType: 'MARKET',
        suggestedPrice: execPrice,
        quantity: grossQty,
        quoteAmount: entryNotional,
        estimatedFeeQuote: roundQuoteValue(entryNotional * updated.feeRate, updated.quoteCurrency),
        reasonFa: preview.decision.reasoningFa,
        riskSummaryFa: `سقف سرمایه: ${formatQuotePrice(updated.capitalAmount, updated.quoteCurrency)} · حد ضرر: ${updated.stopLossPercent}٪`,
        status: 'PENDING',
        createdAt: now,
        expiresAt: now + 30 * 60_000,
        resolvedAt: null,
      };
      newLogs.push({
        id: `demo-aclog-${now}-mconf`,
        botId: updated.id,
        cycleIndex,
        status: 'ANALYZING',
        event: 'MANUAL_CONFIRM',
        price: execPrice,
        message: updated.lastStatusReason,
        timestamp: now,
      });
      return { bot: updated, newLogs, pendingConfirmation };
    }

    const netQty = grossQty * (1 - updated.feeRate);
    const buyFee = roundQuoteValue(entryNotional * updated.feeRate, updated.quoteCurrency);
    const targetPct = Math.max(
      updated.minTargetNetProfitPercent,
      preview.decision.recommendedTargetNetProfitPercent
    );
    const reqSell = computeRequiredSellPrice(
      netQty,
      entryNotional,
      entryNotional * (targetPct / 100),
      updated.feeRate
    );
    const slPrice = roundQuoteValue(
      execPrice * (1 - updated.stopLossPercent / 100),
      updated.quoteCurrency
    );

    updated.activePosition = {
      cycleIndex,
      buyOrderId: `demo-acbuy-${now}`,
      requestedQuoteAmount: entryNotional,
      requestedQty: grossQty,
      filledGrossQty: grossQty,
      netOwnedQty: netQty,
      actualBuyAvgPrice: execPrice,
      buyFeeQuote: buyFee,
      totalBuyCostQuote: entryNotional,
      targetNetProfitPercent: targetPct,
      targetSellPrice: reqSell,
      stopLossPrice: slPrice,
      highestPrice: execPrice,
      buyFilledAt: now,
      lastEstimatedExecutableSellPrice: preview.bestBid || execPrice,
      lastEstimatedNetProfitQuote: roundQuoteValue(-buyFee * 2, updated.quoteCurrency),
      lastEstimatedSlippagePercent: buySim.slippagePercent,
      lastSpreadPercent: preview.spreadPercent,
      lastEvaluatedAt: now,
    };
    updated.stats.currentCapitalInvolved = entryNotional;
    updated.stats.lastBuyPrice = execPrice;
    updated.status = 'HOLDING_POSITION';
    updated.lastStatusReason = `خرید هوشمند چرخه ${cycleIndex} در قیمت ${formatQuotePrice(
      execPrice,
      updated.quoteCurrency
    )} انجام شد · هدف فروش خالص: ${formatQuotePrice(reqSell, updated.quoteCurrency)}`;

    newLogs.push({
      id: `demo-aclog-${now}-buy`,
      botId: updated.id,
      cycleIndex,
      status: 'HOLDING_POSITION',
      event: 'BUY_FILLED',
      price: execPrice,
      message: updated.lastStatusReason,
      timestamp: now,
    });
    return { bot: updated, newLogs };
  }

  const pos = updated.activePosition;
  const targetProfitQuote = pos.totalBuyCostQuote * (pos.targetNetProfitPercent / 100);
  const sellSim = simulateOrderBookSell(
    orderBook,
    pos.netOwnedQty,
    pos.totalBuyCostQuote,
    targetProfitQuote,
    updated.feeRate
  );
  const curExecPrice =
    sellSim.executableAvgSellPrice > 0
      ? sellSim.executableAvgSellPrice
      : preview.bestBid || preview.currentPrice;
  const estNetQuote = roundQuoteValue(sellSim.netProfitQuote, updated.quoteCurrency);
  pos.highestPrice = Math.max(pos.highestPrice, curExecPrice);
  pos.lastEstimatedExecutableSellPrice = curExecPrice;
  pos.lastEstimatedNetProfitQuote = estNetQuote;
  pos.lastEstimatedSlippagePercent = sellSim.slippagePercent;
  pos.lastSpreadPercent = sellSim.spreadPercent;
  pos.lastEvaluatedAt = now;

  const hitStopLoss = updated.stopLossPercent > 0 && curExecPrice <= pos.stopLossPrice;
  const hitTarget = sellSim.canTriggerTarget || curExecPrice >= pos.targetSellPrice;

  updated.lastDecision = {
    ...preview.decision,
    action: hitStopLoss || hitTarget ? 'SELL' : 'HOLD_POSITION',
  };

  if (hitStopLoss || hitTarget) {
    const finalNet = estNetQuote;
    const exitReason: AiCycleProCycleRecord['exitReason'] = hitStopLoss
      ? 'STOP_LOSS'
      : 'AI_TARGET_PROFIT';

    newCycle = {
      id: `demo-accycle-${now}`,
      botId: updated.id,
      cycleIndex: pos.cycleIndex,
      symbol: updated.symbol,
      baseAsset: updated.baseAsset,
      quoteCurrency: updated.quoteCurrency,
      mode: updated.mode,
      entryAmountQuote: pos.totalBuyCostQuote,
      actualBuyAvgPrice: pos.actualBuyAvgPrice,
      boughtQty: pos.filledGrossQty,
      buyFeeQuote: pos.buyFeeQuote,
      totalBuyCostQuote: pos.totalBuyCostQuote,
      actualSellAvgPrice: curExecPrice,
      soldQty: pos.netOwnedQty,
      grossSellProceedsQuote: sellSim.grossProceedsQuote,
      sellFeeQuote: sellSim.sellFeeQuote,
      finalNetProfitQuote: finalNet,
      targetNetProfitPercent: pos.targetNetProfitPercent,
      slippagePercent: sellSim.slippagePercent,
      exitReason,
      aiEntrySummaryFa: preview.decision.reasoningFa,
      aiExitSummaryFa:
        exitReason === 'STOP_LOSS'
          ? `خروج حفاظتی حد ضرر در قیمت ${formatQuotePrice(curExecPrice, updated.quoteCurrency)}`
          : `فروش در هدف سود خالص (+${pos.targetNetProfitPercent.toFixed(2)}٪) تکمیل شد.`,
      startedAt: pos.buyFilledAt,
      completedAt: now,
    };

    updated.activePosition = null;
    updated.stats.completedCycles += 1;
    updated.stats.winningCycles += finalNet >= 0 ? 1 : 0;
    updated.stats.losingCycles += finalNet < 0 ? 1 : 0;
    updated.stats.totalNetProfitQuote = roundQuoteValue(
      updated.stats.totalNetProfitQuote + finalNet,
      updated.quoteCurrency
    );
    updated.stats.totalFeesPaidQuote = roundQuoteValue(
      updated.stats.totalFeesPaidQuote + pos.buyFeeQuote + sellSim.sellFeeQuote,
      updated.quoteCurrency
    );
    updated.stats.currentCapitalInvolved = 0;
    updated.dailyStats.tradesCount += 1;
    updated.dailyStats.netProfitQuote = roundQuoteValue(
      updated.dailyStats.netProfitQuote + finalNet,
      updated.quoteCurrency
    );
    if (finalNet < 0) {
      updated.dailyStats.lossQuote = roundQuoteValue(
        updated.dailyStats.lossQuote + Math.abs(finalNet),
        updated.quoteCurrency
      );
    }

    const dailyCapHit = updated.dailyStats.lossQuote >= updated.maxDailyLoss;
    if (dailyCapHit) {
      updated.isActive = false;
      updated.status = 'PAUSED_RISK';
      updated.lastStatusReason = 'سقف زیان روزانه پر شد و چرخه بعدی متوقف گردید.';
    } else if (updated.autoRepeatCycles) {
      updated.status = 'ANALYZING';
      updated.lastStatusReason = `فروش چرخه ${pos.cycleIndex} تکمیل شد (سود خالص: ${finalNet >= 0 ? '+' : '-'}${Math.abs(
        finalNet
      ).toLocaleString('en-US')}) · آماده تحلیل چرخه بعدی.`;
    } else {
      updated.isActive = false;
      updated.status = 'STOPPED';
      updated.lastStatusReason = 'تک‌چرخه تکمیل و ذخیره شد.';
    }

    newLogs.push({
      id: `demo-aclog-${now}-sell`,
      botId: updated.id,
      cycleIndex: pos.cycleIndex,
      status: updated.status,
      event: exitReason === 'STOP_LOSS' ? 'STOP_LOSS' : 'SELL_FILLED',
      price: curExecPrice,
      netProfitQuote: finalNet,
      message: updated.lastStatusReason,
      timestamp: now,
    });
    return { bot: updated, newCycle, newLogs };
  }

  updated.status = 'HOLDING_POSITION';
  updated.lastStatusReason = `پایش پوزیشن باز · سود/زیان لحظه‌ای خالص: ${
    estNetQuote >= 0 ? '+' : '-'
  }${Math.abs(estNetQuote).toLocaleString('en-US')} · هدف فروش: ${formatQuotePrice(
    pos.targetSellPrice,
    updated.quoteCurrency
  )}`;
  return { bot: updated, newLogs };
}

export function computeDemoUnifiedDashboard(
  state: DemoSandboxState,
  markets: UnifiedMarketTicker[]
): UnifiedBotsDashboardSummary {
  const rows: UnifiedBotSummaryRow[] = [];
  let realizedIrt = 0;
  let realizedUsdt = 0;
  let unrealizedIrt = 0;
  let unrealizedUsdt = 0;
  let committedIrt = 0;
  let committedUsdt = 0;
  let feesIrt = 0;
  let feesUsdt = 0;
  let wins = 0;
  let losses = 0;
  let openCount = 0;
  let closedCount = 0;

  const pxFor = (_sym: string, base: string, qc: QuoteCurrency): number => {
    const m = markets.find((x) => x.baseAsset === base.toUpperCase());
    if (!m) return 0;
    return qc === 'USDT' ? m.priceUsdt : m.priceToman;
  };

  for (const s of state.bots) {
    const botType: BotType = s.strategyKind === 'FIXED_PRICE' ? 'FIXED_PRICE' : 'STRATEGY';
    const livePx = pxFor(s.symbol, s.baseAsset, s.quoteCurrency);
    const committed = s.activePosition ? s.orderAmount : 0;
    const unreal =
      s.activePosition && livePx > 0
        ? (livePx - s.activePosition.entryPrice) * s.activePosition.quantity
        : 0;
    const totalTrades = s.stats.totalTrades;
    const winRate = totalTrades > 0 ? (s.stats.winningTrades / totalTrades) * 100 : 0;

    if (s.quoteCurrency === 'IRT') {
      realizedIrt += s.stats.realizedPnl;
      unrealizedIrt += unreal;
      committedIrt += committed;
    } else {
      realizedUsdt += s.stats.realizedPnl;
      unrealizedUsdt += unreal;
      committedUsdt += committed;
    }
    wins += s.stats.winningTrades;
    losses += s.stats.losingTrades;
    if (s.activePosition) openCount += 1;
    closedCount += totalTrades;

    rows.push({
      id: s.id,
      name: s.name,
      botType,
      symbol: s.symbol,
      baseAsset: s.baseAsset,
      quoteCurrency: s.quoteCurrency,
      mode: s.mode,
      isActive: s.status === 'RUNNING',
      statusLabelFa: s.status === 'RUNNING' ? 'فعال' : 'متوقف',
      allocatedCapitalQuote: s.orderAmount,
      committedCapitalQuote: committed,
      realizedPnlQuote: s.stats.realizedPnl,
      unrealizedPnlQuote: unreal,
      feesPaidQuote: 0,
      tradesCount: totalTrades,
      winRatePercent: Number(winRate.toFixed(1)),
      lastUpdatedAt: s.createdAt,
    });
  }

  for (const p of state.profitBots) {
    const committed = p.stats.currentCapitalInvolved || 0;
    const unreal = p.activePosition?.lastEstimatedNetProfitQuote || 0;
    const winRate =
      p.stats.completedCycles > 0 ? (p.stats.winningCycles / p.stats.completedCycles) * 100 : 0;
    if (p.quoteCurrency === 'IRT') {
      realizedIrt += p.stats.totalNetProfitQuote;
      unrealizedIrt += unreal;
      committedIrt += committed;
      feesIrt += p.stats.totalFeesPaidQuote;
    } else {
      realizedUsdt += p.stats.totalNetProfitQuote;
      unrealizedUsdt += unreal;
      committedUsdt += committed;
      feesUsdt += p.stats.totalFeesPaidQuote;
    }
    wins += p.stats.winningCycles;
    losses += p.stats.losingCycles;
    if (p.activePosition) openCount += 1;
    closedCount += p.stats.completedCycles;

    rows.push({
      id: p.id,
      name: p.name,
      botType: 'PROFIT',
      symbol: p.symbol,
      baseAsset: p.baseAsset,
      quoteCurrency: p.quoteCurrency,
      mode: p.mode,
      isActive: p.isActive,
      statusLabelFa: p.isActive ? 'فعال' : 'متوقف',
      allocatedCapitalQuote: p.maxCapitalInvolved || p.entryAmount,
      committedCapitalQuote: committed,
      realizedPnlQuote: p.stats.totalNetProfitQuote,
      unrealizedPnlQuote: unreal,
      feesPaidQuote: p.stats.totalFeesPaidQuote,
      tradesCount: p.stats.completedCycles,
      winRatePercent: Number(winRate.toFixed(1)),
      lastUpdatedAt: p.updatedAt || p.createdAt,
    });
  }

  for (const g of state.gridBots) {
    const committed = g.stats.currentCapitalInvolved || 0;
    const livePx = pxFor(g.symbol, g.baseAsset, g.quoteCurrency) || g.lastPrice;
    let unreal = 0;
    for (const lv of g.allocatedLevels) {
      if (lv.status === 'HOLDING' && lv.qty > 0 && lv.buyPrice) {
        unreal += (livePx - lv.buyPrice) * lv.qty;
      }
    }
    if (g.quoteCurrency === 'IRT') {
      realizedIrt += g.stats.totalNetProfitQuote;
      unrealizedIrt += unreal;
      committedIrt += committed;
      feesIrt += g.stats.totalFeesPaidQuote;
    } else {
      realizedUsdt += g.stats.totalNetProfitQuote;
      unrealizedUsdt += unreal;
      committedUsdt += committed;
      feesUsdt += g.stats.totalFeesPaidQuote;
    }
    wins += g.stats.completedCycles;
    if (g.stats.openOrdersCount > 0) openCount += 1;
    closedCount += g.stats.completedCycles;

    rows.push({
      id: g.id,
      name: g.name,
      botType: 'GRID',
      symbol: g.symbol,
      baseAsset: g.baseAsset,
      quoteCurrency: g.quoteCurrency,
      mode: g.mode,
      isActive: g.isActive,
      statusLabelFa: g.isActive ? 'فعال' : 'متوقف',
      allocatedCapitalQuote: g.totalCapital,
      committedCapitalQuote: committed,
      realizedPnlQuote: g.stats.totalNetProfitQuote,
      unrealizedPnlQuote: unreal,
      feesPaidQuote: g.stats.totalFeesPaidQuote,
      tradesCount: g.stats.completedCycles,
      winRatePercent: g.stats.completedCycles > 0 ? 100 : 0,
      lastUpdatedAt: g.updatedAt || g.createdAt,
    });
  }

  for (const d of state.dcaBots) {
    const committed = d.state.totalInvestedQuote || 0;
    const livePx = pxFor(d.symbol, d.baseAsset, d.quoteCurrency) || d.lastPrice;
    const unreal =
      d.state.netOwnedQty > 0 && d.state.avgBuyPrice > 0
        ? (livePx - d.state.avgBuyPrice) * d.state.netOwnedQty
        : 0;
    if (d.quoteCurrency === 'IRT') {
      realizedIrt += d.stats.realizedNetProfitQuote;
      unrealizedIrt += unreal;
      committedIrt += committed;
      feesIrt += d.stats.totalFeesPaidQuote;
    } else {
      realizedUsdt += d.stats.realizedNetProfitQuote;
      unrealizedUsdt += unreal;
      committedUsdt += committed;
      feesUsdt += d.stats.totalFeesPaidQuote;
    }
    if (d.stats.realizedNetProfitQuote >= 0 && d.stats.completedCycles > 0) {
      wins += d.stats.completedCycles;
    } else if (d.stats.completedCycles > 0) {
      losses += d.stats.completedCycles;
    }
    if (d.state.netOwnedQty > 0) openCount += 1;
    closedCount += d.stats.completedCycles;

    rows.push({
      id: d.id,
      name: d.name,
      botType: 'DCA',
      symbol: d.symbol,
      baseAsset: d.baseAsset,
      quoteCurrency: d.quoteCurrency,
      mode: d.mode,
      isActive: d.isActive,
      statusLabelFa: d.isActive ? 'فعال' : 'متوقف',
      allocatedCapitalQuote: d.totalCapital,
      committedCapitalQuote: committed,
      realizedPnlQuote: d.stats.realizedNetProfitQuote,
      unrealizedPnlQuote: unreal,
      feesPaidQuote: d.stats.totalFeesPaidQuote,
      tradesCount: d.stats.completedCycles,
      winRatePercent: d.stats.completedCycles > 0 ? 100 : 0,
      lastUpdatedAt: d.updatedAt || d.createdAt,
    });
  }

  for (const ac of state.aiCycleProBots || []) {
    const committed = ac.stats.currentCapitalInvolved || 0;
    const unreal = ac.activePosition?.lastEstimatedNetProfitQuote || 0;
    const winRate =
      ac.stats.completedCycles > 0 ? (ac.stats.winningCycles / ac.stats.completedCycles) * 100 : 0;
    if (ac.quoteCurrency === 'IRT') {
      realizedIrt += ac.stats.totalNetProfitQuote;
      unrealizedIrt += unreal;
      committedIrt += committed;
      feesIrt += ac.stats.totalFeesPaidQuote;
    } else {
      realizedUsdt += ac.stats.totalNetProfitQuote;
      unrealizedUsdt += unreal;
      committedUsdt += committed;
      feesUsdt += ac.stats.totalFeesPaidQuote;
    }
    wins += ac.stats.winningCycles;
    losses += ac.stats.losingCycles;
    if (ac.activePosition) openCount += 1;
    closedCount += ac.stats.completedCycles;

    rows.push({
      id: ac.id,
      name: ac.name,
      botType: 'AI_CYCLE_PRO',
      symbol: ac.symbol,
      baseAsset: ac.baseAsset,
      quoteCurrency: ac.quoteCurrency,
      mode: ac.mode,
      isActive: ac.isActive,
      statusLabelFa: ac.isActive ? 'فعال' : 'متوقف',
      allocatedCapitalQuote: ac.capitalAmount,
      committedCapitalQuote: committed,
      realizedPnlQuote: ac.stats.totalNetProfitQuote,
      unrealizedPnlQuote: unreal,
      feesPaidQuote: ac.stats.totalFeesPaidQuote,
      tradesCount: ac.stats.completedCycles,
      winRatePercent: Number(winRate.toFixed(1)),
      lastUpdatedAt: ac.updatedAt || ac.createdAt,
    });
  }

  const symbolCounts = new Map<string, number>();
  for (const r of rows) {
    if (r.isActive) {
      symbolCounts.set(r.symbol, (symbolCounts.get(r.symbol) || 0) + 1);
    }
  }
  const activeConflictSymbols = Array.from(symbolCounts.entries())
    .filter(([, count]) => count > 1)
    .map(([sym]) => sym);

  const sortedByPnl = [...rows].sort((a, b) => b.realizedPnlQuote - a.realizedPnlQuote);
  const totalTrades = wins + losses;
  const winRate = totalTrades > 0 ? (wins / totalTrades) * 100 : 0;

  return {
    totalBudgetIrt: state.riskSettings.totalBotsBudgetIrt,
    totalBudgetUsdt: state.riskSettings.totalBotsBudgetUsdt,
    committedCapitalIrt: committedIrt,
    committedCapitalUsdt: committedUsdt,
    freeBudgetIrt: Math.max(0, state.riskSettings.totalBotsBudgetIrt - committedIrt),
    freeBudgetUsdt: Math.max(0, state.riskSettings.totalBotsBudgetUsdt - committedUsdt),
    realizedPnlDailyIrt: Math.round(realizedIrt * 0.35),
    realizedPnlWeeklyIrt: Math.round(realizedIrt * 0.8),
    realizedPnlMonthlyIrt: realizedIrt,
    unrealizedPnlIrt: unrealizedIrt,
    totalFeesPaidIrt: feesIrt,
    realizedPnlDailyUsdt: Number((realizedUsdt * 0.35).toFixed(4)),
    unrealizedPnlUsdt: unrealizedUsdt,
    totalFeesPaidUsdt: feesUsdt,
    openPositionsCount: openCount,
    closedTradesCount: closedCount,
    overallWinRatePercent: Number(winRate.toFixed(1)),
    avgPnlPerTradeIrt: closedCount > 0 ? Math.round(realizedIrt / closedCount) : 0,
    bestBot: sortedByPnl[0] || null,
    worstBot: sortedByPnl.length > 1 ? sortedByPnl[sortedByPnl.length - 1] : null,
    activeConflictSymbols,
    pendingConfirmationsCount: state.pendingConfirmations.filter((c) => c.status === 'PENDING').length,
    rows,
  };
}

export function runDemoExtendedBacktest(
  candles: KlineCandle[],
  params: {
    botType?: 'STRATEGY' | 'GRID' | 'DCA';
    symbol: string;
    quoteCurrency: QuoteCurrency;
    timeframe: Timeframe;
    totalCapital?: number;
    orderAmount?: number;
    lowerPrice?: number;
    upperPrice?: number;
    gridLevels?: number;
    totalStages?: number;
    stepValue?: number;
    estimatedSlippagePercent?: number;
    feeRate?: number;
  }
): BacktestResult {
  const feeRate = params.feeRate ?? DEFAULT_NOBITEX_FEE_RATE;
  const slip = (params.estimatedSlippagePercent ?? 0.15) / 100;
  const cap = Number(params.totalCapital || params.orderAmount || 10_000_000);
  const firstPx = candles[0]?.close || 1;
  const lastPx = candles[candles.length - 1]?.close || firstPx;
  const trades: BacktestTrade[] = [];
  const equityCurve: { time: number; equity: number }[] = [];

  if (params.botType === 'GRID') {
    const lo = params.lowerPrice && params.lowerPrice > 0 ? params.lowerPrice : firstPx * 0.94;
    const hi = params.upperPrice && params.upperPrice > lo ? params.upperPrice : firstPx * 1.06;
    const n = Math.max(3, params.gridLevels || 8);
    const step = (hi - lo) / (n - 1);
    const perLvl = cap / (n - 1);
    let netProfit = 0;
    let totalFees = 0;
    const holdings = new Map<number, number>();
    for (const c of candles) {
      for (let i = 0; i < n - 1; i += 1) {
        const buyP = lo + i * step;
        const sellP = lo + (i + 1) * step;
        if (!holdings.has(i) && c.low <= buyP && buyP <= hi) {
          const effBuy = buyP * (1 + slip);
          holdings.set(i, (perLvl / effBuy) * (1 - feeRate));
        } else if (holdings.has(i) && c.high >= sellP) {
          const qty = holdings.get(i)!;
          holdings.delete(i);
          const effSell = sellP * (1 - slip);
          const gross = qty * effSell;
          const fee = gross * feeRate + perLvl * feeRate;
          const pnl = gross * (1 - feeRate) - perLvl;
          netProfit += pnl;
          totalFees += fee;
          trades.push({
            entryTime: c.openTime,
            exitTime: c.openTime,
            entryPrice: buyP,
            exitPrice: sellP,
            pnlQuote: pnl,
            pnlPercent: (pnl / perLvl) * 100,
            feeQuote: fee,
            slippageQuote: perLvl * slip * 2,
            exitReason: 'GRID_CYCLE',
          });
        }
      }
      equityCurve.push({ time: c.openTime, equity: cap + netProfit });
    }
    const returnPct = (netProfit / cap) * 100;
    const winsList = trades.filter((t) => t.pnlQuote >= 0);
    const lossList = trades.filter((t) => t.pnlQuote < 0);
    const grossWins = winsList.reduce((s, t) => s + t.pnlQuote, 0);
    const grossLoss = Math.abs(lossList.reduce((s, t) => s + t.pnlQuote, 0));
    return {
      symbol: params.symbol,
      quoteCurrency: params.quoteCurrency,
      timeframe: params.timeframe,
      botType: 'GRID',
      candlesTested: candles.length,
      initialCapital: cap,
      finalCapital: cap + netProfit,
      netProfitQuote: netProfit,
      netProfitPercent: Number(returnPct.toFixed(2)),
      totalFeesPaidQuote: Number(totalFees.toFixed(2)),
      estimatedSlippageQuote: Number((trades.length * perLvl * slip * 2).toFixed(2)),
      avgWinQuote: winsList.length > 0 ? grossWins / winsList.length : 0,
      avgLossQuote: lossList.length > 0 ? grossLoss / lossList.length : 0,
      totalTrades: trades.length,
      winningTrades: winsList.length,
      losingTrades: lossList.length,
      winRatePercent: trades.length > 0 ? Number(((winsList.length / trades.length) * 100).toFixed(1)) : 0,
      maxDrawdownPercent: 3.2,
      profitFactor: grossLoss > 0 ? Number((grossWins / grossLoss).toFixed(2)) : winsList.length > 0 ? 99 : 0,
      equityCurve,
      trades,
    };
  }

  // DCA or fallback simulation
  const stages = Math.max(2, params.totalStages || 5);
  const perStage = cap / stages;
  const stepPct = Math.max(0.5, params.stepValue || 2.5) / 100;
  let invested = 0;
  let netQty = 0;
  let lastBuy = 0;
  let done = 0;
  let realized = 0;
  let fees = 0;
  for (const c of candles) {
    if (done === 0 || (done < stages && c.close <= lastBuy * (1 - stepPct))) {
      const px = c.close * (1 + slip);
      invested += perStage;
      fees += perStage * feeRate;
      netQty += (perStage / px) * (1 - feeRate);
      lastBuy = px;
      done += 1;
    } else if (netQty > 0) {
      const avg = invested / netQty;
      if (c.close >= avg * 1.045) {
        const gross = netQty * c.close * (1 - slip);
        fees += gross * feeRate;
        const pnl = gross * (1 - feeRate) - invested;
        realized += pnl;
        trades.push({
          entryTime: candles[0].openTime,
          exitTime: c.openTime,
          entryPrice: avg,
          exitPrice: c.close,
          pnlQuote: pnl,
          pnlPercent: (pnl / invested) * 100,
          feeQuote: gross * feeRate,
          slippageQuote: gross * slip,
          exitReason: 'DCA_EXIT',
        });
        invested = 0;
        netQty = 0;
        done = 0;
      }
    }
    equityCurve.push({ time: c.openTime, equity: cap + realized });
  }
  const openVal = netQty * lastPx * (1 - feeRate);
  const totalNet = realized + (openVal - invested);
  const winsList = trades.filter((t) => t.pnlQuote >= 0);
  const lossList = trades.filter((t) => t.pnlQuote < 0);
  const grossWins = winsList.reduce((s, t) => s + t.pnlQuote, 0);
  const grossLoss = Math.abs(lossList.reduce((s, t) => s + t.pnlQuote, 0));
  return {
    symbol: params.symbol,
    quoteCurrency: params.quoteCurrency,
    timeframe: params.timeframe,
    botType: 'DCA',
    candlesTested: candles.length,
    initialCapital: cap,
    finalCapital: cap + totalNet,
    netProfitQuote: totalNet,
    netProfitPercent: Number(((totalNet / cap) * 100).toFixed(2)),
    totalFeesPaidQuote: Number(fees.toFixed(2)),
    estimatedSlippageQuote: Number((cap * slip).toFixed(2)),
    avgWinQuote: winsList.length > 0 ? grossWins / winsList.length : 0,
    avgLossQuote: lossList.length > 0 ? grossLoss / lossList.length : 0,
    totalTrades: trades.length,
    winningTrades: winsList.length,
    losingTrades: lossList.length,
    winRatePercent: trades.length > 0 ? Number(((winsList.length / trades.length) * 100).toFixed(1)) : 0,
    maxDrawdownPercent: 4.5,
    profitFactor: grossLoss > 0 ? Number((grossWins / grossLoss).toFixed(2)) : winsList.length > 0 ? 99 : 0,
    equityCurve,
    trades,
  };
}



