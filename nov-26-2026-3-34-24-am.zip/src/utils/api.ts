export async function parseApiJson<T = Record<string, unknown>>(
  res: Response,
  fallbackError: string
): Promise<T> {
  const text = await res.text();
  let parsed: unknown = null;

  if (text.trim().length > 0) {
    try {
      parsed = JSON.parse(text);
    } catch {
      const looksLikeHtml = /^\s*</.test(text);
      if (looksLikeHtml) {
        if (res.status === 502 || res.status === 503 || res.status === 504) {
          throw new Error(
            `سرور موقتاً در دسترس نیست یا در حال راه‌اندازی مجدد است (HTTP ${res.status}). چند لحظه بعد دوباره تلاش کنید.`
          );
        }
        throw new Error(
          `پاسخ غیرمنتظره (HTML) به جای JSON از سرور دریافت شد (HTTP ${res.status}). لطفاً صفحه را رفرش کنید و در صورت فعال بودن کش قدیمی مرورگر، یک‌بار صفحه را Ctrl+Shift+R بزنید.`
        );
      }
      throw new Error(`${fallbackError} (HTTP ${res.status})`);
    }
  }

  if (!res.ok) {
    const errObj = (parsed && typeof parsed === 'object' ? parsed : {}) as {
      error?: string;
      message?: string;
    };
    throw new Error(errObj.error || errObj.message || `${fallbackError} (HTTP ${res.status})`);
  }

  return (parsed ?? {}) as T;
}
