import {
  bigint,
  boolean,
  doublePrecision,
  integer,
  jsonb,
  pgTable,
  serial,
  text,
  uniqueIndex,
} from 'drizzle-orm/pg-core';

// 1. users
export const users = pgTable('users', {
  uid: text('uid').primaryKey(),
  email: text('email').notNull().default(''),
  displayName: text('display_name').notNull().default('کاربر'),
  isBanned: boolean('is_banned').notNull().default(false),
  banReason: text('ban_reason'),
  adminNote: text('admin_note'),
  referralCode: text('referral_code').notNull(),
  referredByUid: text('referred_by_uid'),
  referredByCode: text('referred_by_code'),
  referredAt: bigint('referred_at', { mode: 'number' }),
  referralBonusDaysEarned: integer('referral_bonus_days_earned').notNull().default(0),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  lastSeenAt: bigint('last_seen_at', { mode: 'number' }).notNull(),
});

// 2. exchange_credentials
export const exchangeCredentials = pgTable('exchange_credentials', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  label: text('label').notNull(),
  maskedApiKey: text('masked_api_key').notNull(),
  keyId: text('key_id').notNull().default('v1'),
  encryptedToken: text('encrypted_token').notNull(),
  iv: text('iv').notNull(),
  authTag: text('auth_tag').notNull(),
  status: text('status').notNull().default('ACTIVE'),
  lastVerifiedAt: bigint('last_verified_at', { mode: 'number' }),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  revokedAt: bigint('revoked_at', { mode: 'number' }),
});

// 3. telegram_configurations
export const telegramConfigurations = pgTable('telegram_configurations', {
  userId: text('user_id')
    .primaryKey()
    .references(() => users.uid, { onDelete: 'cascade' }),
  keyId: text('key_id').notNull().default('v1'),
  encryptedBotToken: text('encrypted_bot_token').notNull(),
  iv: text('iv').notNull(),
  authTag: text('auth_tag').notNull(),
  maskedBotToken: text('masked_bot_token').notNull(),
  botUsername: text('bot_username').notNull().default(''),
  botFirstName: text('bot_first_name').notNull().default(''),
  chatId: text('chat_id').notNull(),
  enabled: boolean('enabled').notNull().default(true),
  sendPriceAlerts: boolean('send_price_alerts').notNull().default(true),
  sendPeriodicWatchers: boolean('send_periodic_watchers').notNull().default(true),
  sendTradeReports: boolean('send_trade_reports').notNull().default(true),
  sendBotTrades: boolean('send_bot_trades').notNull().default(true),
  sendBotMonitoring: boolean('send_bot_monitoring').notNull().default(true),
  botMonitorMode: text('bot_monitor_mode').notNull().default('EVENTS_AND_STATUS'),
  botMonitorIntervalMinutes: integer('bot_monitor_interval_minutes').notNull().default(15),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
  lastSentAt: bigint('last_sent_at', { mode: 'number' }),
  lastBotMonitorSentAt: bigint('last_bot_monitor_sent_at', { mode: 'number' }),
  lastError: text('last_error'),
  recentLogsJson: jsonb('recent_logs_json').notNull().default([]),
});

// 4. trading_bots
export const tradingBots = pgTable('trading_bots', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  symbol: text('symbol').notNull(),
  timeframe: text('timeframe').notNull(),
  mode: text('mode').notNull().default('paper'),
  status: text('status').notNull().default('PAUSED'),
  orderAmount: doublePrecision('order_amount').notNull(),
  activePositionJson: jsonb('active_position_json'),
  statsJson: jsonb('stats_json').notNull(),
  lastCheckedAt: bigint('last_checked_at', { mode: 'number' }),
  lastSignalSummary: text('last_signal_summary').notNull().default(''),
  notifyTelegram: boolean('notify_telegram').notNull().default(true),
  consecutiveFailures: integer('consecutive_failures').notNull().default(0),
  nextRetryAt: bigint('next_retry_at', { mode: 'number' }),
  lastError: text('last_error'),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 5. bot_configurations
export const botConfigurations = pgTable('bot_configurations', {
  botId: text('bot_id')
    .primaryKey()
    .references(() => tradingBots.id, { onDelete: 'cascade' }),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  stopLossPercent: doublePrecision('stop_loss_percent').notNull().default(2.5),
  takeProfitPercent: doublePrecision('take_profit_percent').notNull().default(5.0),
  trailingStopEnabled: boolean('trailing_stop_enabled').notNull().default(false),
  trailingStopPercent: doublePrecision('trailing_stop_percent').notNull().default(1.5),
  cooldownMinutes: integer('cooldown_minutes').notNull().default(15),
  logicOperator: text('logic_operator').notNull().default('AND'),
  entryRulesJson: jsonb('entry_rules_json').notNull().default([]),
  exitRulesJson: jsonb('exit_rules_json').notNull().default([]),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 6. orders
export const orders = pgTable('orders', {
  orderId: text('order_id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  botId: text('bot_id'),
  exchangeOrderId: text('exchange_order_id'),
  idempotencyKey: text('idempotency_key'),
  symbol: text('symbol').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  side: text('side').notNull(),
  type: text('type').notNull(),
  price: doublePrecision('price').notNull(),
  quantity: doublePrecision('quantity').notNull(),
  executedQty: doublePrecision('executed_qty').notNull().default(0),
  totalQuoteAmount: doublePrecision('total_quote_amount').notNull(),
  feeAmount: doublePrecision('fee_amount').notNull().default(0),
  status: text('status').notNull(),
  stopLossPrice: doublePrecision('stop_loss_price'),
  takeProfitPrice: doublePrecision('take_profit_price'),
  mode: text('mode').notNull(),
  source: text('source').notNull(),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 7. trades
export const trades = pgTable('trades', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  orderId: text('order_id').notNull(),
  botId: text('bot_id'),
  symbol: text('symbol').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  side: text('side').notNull(),
  price: doublePrecision('price').notNull(),
  quantity: doublePrecision('quantity').notNull(),
  quoteAmount: doublePrecision('quote_amount').notNull(),
  feeAmount: doublePrecision('fee_amount').notNull().default(0),
  realizedPnlQuote: doublePrecision('realized_pnl_quote'),
  mode: text('mode').notNull(),
  executedAt: bigint('executed_at', { mode: 'number' }).notNull(),
});

// 8. trading_logs
export const tradingLogs = pgTable('trading_logs', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  botId: text('bot_id').notNull(),
  botName: text('bot_name').notNull(),
  symbol: text('symbol').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  event: text('event').notNull(),
  price: doublePrecision('price').notNull().default(0),
  quantity: doublePrecision('quantity'),
  pnlQuote: doublePrecision('pnl_quote'),
  message: text('message').notNull(),
  mode: text('mode').notNull(),
  timestamp: bigint('timestamp', { mode: 'number' }).notNull(),
});

// 9. paper_trading_balances
export const paperTradingBalances = pgTable(
  'paper_trading_balances',
  {
    id: serial('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => users.uid, { onDelete: 'cascade' }),
    asset: text('asset').notNull(),
    balance: doublePrecision('balance').notNull().default(0),
    updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
  },
  (table) => [uniqueIndex('paper_balances_user_asset_idx').on(table.userId, table.asset)]
);

// 10. price_alerts
export const priceAlerts = pgTable('price_alerts', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  baseAsset: text('base_asset').notNull(),
  persianName: text('persian_name').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  symbol: text('symbol').notNull(),
  condition: text('condition').notNull(),
  targetPrice: doublePrecision('target_price').notNull(),
  createdPrice: doublePrecision('created_price').notNull(),
  status: text('status').notNull().default('ACTIVE'),
  sendTelegram: boolean('send_telegram').notNull().default(true),
  note: text('note'),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  triggeredAt: bigint('triggered_at', { mode: 'number' }),
  triggeredPrice: doublePrecision('triggered_price'),
});

// 11. price_watchers
export const priceWatchers = pgTable('price_watchers', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  baseAsset: text('base_asset').notNull(),
  persianName: text('persian_name').notNull(),
  quoteMode: text('quote_mode').notNull().default('BOTH'),
  intervalMinutes: integer('interval_minutes').notNull(),
  status: text('status').notNull().default('ACTIVE'),
  notifyBrowser: boolean('notify_browser').notNull().default(true),
  playSound: boolean('play_sound').notNull().default(true),
  sendTelegram: boolean('send_telegram').notNull().default(true),
  webhookUrl: text('webhook_url'),
  lastPriceToman: doublePrecision('last_price_toman'),
  lastPriceUsdt: doublePrecision('last_price_usdt'),
  lastChange24h: doublePrecision('last_change_24h'),
  sentCount: integer('sent_count').notNull().default(0),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  lastSentAt: bigint('last_sent_at', { mode: 'number' }),
  nextSendAt: bigint('next_send_at', { mode: 'number' }).notNull(),
});

// 12. notifications
export const notifications = pgTable('notifications', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  watcherId: text('watcher_id').notNull(),
  kind: text('kind').notNull().default('PRICE_PULSE'),
  baseAsset: text('base_asset').notNull(),
  persianName: text('persian_name').notNull(),
  quoteMode: text('quote_mode').notNull().default('BOTH'),
  priceToman: doublePrecision('price_toman').notNull().default(0),
  priceUsdt: doublePrecision('price_usdt').notNull().default(0),
  change24hPercent: doublePrecision('change24h_percent').notNull().default(0),
  intervalMinutes: integer('interval_minutes').notNull().default(5),
  title: text('title'),
  message: text('message'),
  sentAt: bigint('sent_at', { mode: 'number' }).notNull(),
});

// 13. subscriptions
export const subscriptions = pgTable('subscriptions', {
  userId: text('user_id')
    .primaryKey()
    .references(() => users.uid, { onDelete: 'cascade' }),
  email: text('email').notNull().default(''),
  displayName: text('display_name').notNull().default('کاربر'),
  plan: text('plan').notNull().default('FREE'),
  status: text('status').notNull().default('EXPIRED'),
  paymentMethod: text('payment_method').notNull().default('ADMIN_GRANT'),
  startAt: bigint('start_at', { mode: 'number' }).notNull(),
  expiresAt: bigint('expires_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 14. payments
export const payments = pgTable('payments', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  userEmail: text('user_email').notNull().default(''),
  userDisplayName: text('user_display_name').notNull().default('کاربر'),
  method: text('method').notNull(),
  status: text('status').notNull().default('PENDING'),
  amountToman: doublePrecision('amount_toman').notNull(),
  amountUsdt: doublePrecision('amount_usdt').notNull(),
  network: text('network'),
  walletAddress: text('wallet_address'),
  txHash: text('tx_hash'),
  authority: text('authority'),
  refId: text('ref_id'),
  note: text('note'),
  adminNote: text('admin_note'),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
  reviewedAt: bigint('reviewed_at', { mode: 'number' }),
});

// 15. referrals
export const referrals = pgTable(
  'referrals',
  {
    id: text('id').primaryKey(),
    referrerUid: text('referrer_uid')
      .notNull()
      .references(() => users.uid, { onDelete: 'cascade' }),
    referrerEmail: text('referrer_email').notNull().default(''),
    referrerDisplayName: text('referrer_display_name').notNull().default('کاربر'),
    referredUserUid: text('referred_user_uid')
      .notNull()
      .references(() => users.uid, { onDelete: 'cascade' }),
    referredUserEmail: text('referred_user_email').notNull().default(''),
    referredUserDisplayName: text('referred_user_display_name').notNull().default('کاربر'),
    referralCode: text('referral_code').notNull(),
    status: text('status').notNull().default('REGISTERED'),
    rewardDays: integer('reward_days').notNull().default(4),
    createdAt: bigint('created_at', { mode: 'number' }).notNull(),
    updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
    rewardedAt: bigint('rewarded_at', { mode: 'number' }),
  },
  (table) => [uniqueIndex('referrals_referred_uid_idx').on(table.referredUserUid)]
);

// 16. admin_settings
export const adminSettings = pgTable('admin_settings', {
  id: text('id').primaryKey(),
  monthlyPriceToman: integer('monthly_price_toman').notNull().default(950000),
  monthlyPriceUsdt: doublePrecision('monthly_price_usdt').notNull().default(15),
  autoUsdtFromRate: boolean('auto_usdt_from_rate').notNull().default(true),
  usdtWalletAddress: text('usdt_wallet_address').notNull().default(''),
  usdtNetwork: text('usdt_network').notNull().default('TRC20'),
  usdtWalletAddress2: text('usdt_wallet_address2').notNull().default(''),
  usdtNetwork2: text('usdt_network2').notNull().default('BEP20'),
  zarinpalSandbox: boolean('zarinpal_sandbox').notNull().default(true),
  merchantKeyId: text('merchant_key_id').notNull().default('v1'),
  encryptedMerchantJson: jsonb('encrypted_merchant_json'),
  maskedMerchantId: text('masked_merchant_id').notNull().default(''),
  maintenanceMode: boolean('maintenance_mode').notNull().default(false),
  maintenanceMessage: text('maintenance_message').notNull().default(''),
  promoFreeAccess: boolean('promo_free_access').notNull().default(false),
  promoBannerText: text('promo_banner_text').notNull().default(''),
  supportPhone: text('support_phone').notNull().default('09999961279'),
  supportTelegram: text('support_telegram').notNull().default(''),
  featurePoliciesJson: jsonb('feature_policies_json').notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 17. audit_logs
export const auditLogs = pgTable('audit_logs', {
  id: text('id').primaryKey(),
  actorEmail: text('actor_email').notNull(),
  actorUserId: text('actor_user_id'),
  action: text('action').notNull(),
  target: text('target'),
  details: text('details').notNull(),
  ipAddress: text('ip_address'),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
});

// Supporting tables for full existing feature parity & concurrency locks
export const appApiKeys = pgTable('app_api_keys', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  label: text('label').notNull(),
  keyPrefix: text('key_prefix').notNull(),
  keyHash: text('key_hash').notNull(),
  scopesJson: jsonb('scopes_json').notNull().default([]),
  status: text('status').notNull().default('ACTIVE'),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  revokedAt: bigint('revoked_at', { mode: 'number' }),
  lastUsedAt: bigint('last_used_at', { mode: 'number' }),
});

export const costBasisOverrides = pgTable(
  'cost_basis_overrides',
  {
    id: serial('id').primaryKey(),
    userId: text('user_id')
      .notNull()
      .references(() => users.uid, { onDelete: 'cascade' }),
    mode: text('mode').notNull(),
    asset: text('asset').notNull(),
    priceToman: doublePrecision('price_toman').notNull(),
    priceUsdt: doublePrecision('price_usdt').notNull(),
    updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
  },
  (table) => [
    uniqueIndex('cost_basis_user_mode_asset_idx').on(table.userId, table.mode, table.asset),
  ]
);

export const featureIdeas = pgTable('feature_ideas', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  title: text('title').notNull(),
  description: text('description').notNull().default(''),
  category: text('category').notNull().default('GENERAL'),
  status: text('status').notNull().default('IDEA'),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
});

export const broadcasts = pgTable('broadcasts', {
  id: text('id').primaryKey(),
  title: text('title').notNull(),
  body: text('body').notNull(),
  severity: text('severity').notNull().default('INFO'),
  active: boolean('active').notNull().default(true),
  pinned: boolean('pinned').notNull().default(false),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
  expiresAt: bigint('expires_at', { mode: 'number' }),
  createdByEmail: text('created_by_email').notNull(),
});

export const directMessages = pgTable('direct_messages', {
  id: text('id').primaryKey(),
  targetUserId: text('target_user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  targetUserEmail: text('target_user_email').notNull().default(''),
  targetUserName: text('target_user_name').notNull().default(''),
  subject: text('subject').notNull(),
  body: text('body').notNull(),
  severity: text('severity').notNull().default('INFO'),
  readByUser: boolean('read_by_user').notNull().default(false),
  readAt: bigint('read_at', { mode: 'number' }),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
  senderEmail: text('sender_email').notNull(),
});

export const workerLocks = pgTable('worker_locks', {
  lockName: text('lock_name').primaryKey(),
  ownerId: text('owner_id').notNull(),
  acquiredAt: bigint('acquired_at', { mode: 'number' }).notNull(),
  expiresAt: bigint('expires_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 18. profit_bots (Dedicated standalone Profit Bot persistence)
export const profitBots = pgTable('profit_bots', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  symbol: text('symbol').notNull(),
  mode: text('mode').notNull().default('paper'),
  isActive: boolean('is_active').notNull().default(false),
  botStatus: text('bot_status').notNull().default('READY_TO_BUY'),
  entryAmount: doublePrecision('entry_amount').notNull(),
  targetNetProfit: doublePrecision('target_net_profit').notNull(),
  pollIntervalSeconds: integer('poll_interval_seconds').notNull().default(10),
  maxWaitMinutes: integer('max_wait_minutes'),
  stopLossEnabled: boolean('stop_loss_enabled').notNull().default(false),
  stopLossPercent: doublePrecision('stop_loss_percent').notNull().default(3),
  stopLossAction: text('stop_loss_action').notNull().default('STOP_AND_SELL'),
  maxCapitalInvolved: doublePrecision('max_capital_involved').notNull(),
  maxDailyTrades: integer('max_daily_trades').notNull().default(10),
  maxDailyLoss: doublePrecision('max_daily_loss').notNull().default(0),
  orderType: text('order_type').notNull().default('LIMIT'),
  maxSlippagePercent: doublePrecision('max_slippage_percent').notNull().default(0.5),
  maxSpreadPercent: doublePrecision('max_spread_percent').notNull().default(1.5),
  limitOrderTimeoutSeconds: integer('limit_order_timeout_seconds').notNull().default(120),
  limitUnfilledPolicy: text('limit_unfilled_policy').notNull().default('KEEP_WAITING'),
  sequenceMode: text('sequence_mode').notNull().default('SINGLE'),
  feeRate: doublePrecision('fee_rate').notNull().default(0.0025),
  otherFeesQuote: doublePrecision('other_fees_quote').notNull().default(0),
  notifyTelegram: boolean('notify_telegram').notNull().default(true),
  activePositionJson: jsonb('active_position_json'),
  pendingOrderJson: jsonb('pending_order_json'),
  dailyStatsJson: jsonb('daily_stats_json').notNull(),
  statsJson: jsonb('stats_json').notNull(),
  lastStatusReason: text('last_status_reason').notNull().default(''),
  consecutiveFailures: integer('consecutive_failures').notNull().default(0),
  nextRetryAt: bigint('next_retry_at', { mode: 'number' }),
  lastError: text('last_error'),
  lastCheckedAt: bigint('last_checked_at', { mode: 'number' }),
  startedAt: bigint('started_at', { mode: 'number' }),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 19. profit_bot_cycles
export const profitBotCycles = pgTable('profit_bot_cycles', {
  id: text('id').primaryKey(),
  botId: text('bot_id')
    .notNull()
    .references(() => profitBots.id, { onDelete: 'cascade' }),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  cycleIndex: integer('cycle_index').notNull(),
  symbol: text('symbol').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  mode: text('mode').notNull().default('paper'),
  orderType: text('order_type').notNull().default('LIMIT'),
  entryAmountQuote: doublePrecision('entry_amount_quote').notNull(),
  actualBuyAvgPrice: doublePrecision('actual_buy_avg_price').notNull(),
  boughtQty: doublePrecision('bought_qty').notNull(),
  buyFeeQuote: doublePrecision('buy_fee_quote').notNull(),
  totalBuyCostQuote: doublePrecision('total_buy_cost_quote').notNull(),
  actualSellAvgPrice: doublePrecision('actual_sell_avg_price').notNull(),
  soldQty: doublePrecision('sold_qty').notNull(),
  grossSellProceedsQuote: doublePrecision('gross_sell_proceeds_quote').notNull(),
  sellFeeQuote: doublePrecision('sell_fee_quote').notNull(),
  otherFeesQuote: doublePrecision('other_fees_quote').notNull().default(0),
  finalNetProfitQuote: doublePrecision('final_net_profit_quote').notNull(),
  targetNetProfitQuote: doublePrecision('target_net_profit_quote').notNull(),
  exitReason: text('exit_reason').notNull(),
  startedAt: bigint('started_at', { mode: 'number' }).notNull(),
  completedAt: bigint('completed_at', { mode: 'number' }).notNull(),
});

// 20. profit_bot_logs
export const profitBotLogs = pgTable('profit_bot_logs', {
  id: text('id').primaryKey(),
  botId: text('bot_id')
    .notNull()
    .references(() => profitBots.id, { onDelete: 'cascade' }),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  cycleIndex: integer('cycle_index').notNull().default(0),
  status: text('status').notNull(),
  event: text('event').notNull(),
  price: doublePrecision('price').notNull().default(0),
  netProfitQuote: doublePrecision('net_profit_quote'),
  message: text('message').notNull(),
  timestamp: bigint('timestamp', { mode: 'number' }).notNull(),
});

// 21. bot_risk_settings (Shared capital governance & limits per user)
export const botRiskSettings = pgTable('bot_risk_settings', {
  userId: text('user_id')
    .primaryKey()
    .references(() => users.uid, { onDelete: 'cascade' }),
  totalBotsBudgetIrt: doublePrecision('total_bots_budget_irt').notNull().default(100_000_000),
  totalBotsBudgetUsdt: doublePrecision('total_bots_budget_usdt').notNull().default(2000),
  maxPerBotCapitalIrt: doublePrecision('max_per_bot_capital_irt').notNull().default(35_000_000),
  maxPerBotCapitalUsdt: doublePrecision('max_per_bot_capital_usdt').notNull().default(1500),
  maxDailyLossIrt: doublePrecision('max_daily_loss_irt').notNull().default(5_000_000),
  maxDailyLossUsdt: doublePrecision('max_daily_loss_usdt').notNull().default(100),
  maxTotalLossIrt: doublePrecision('max_total_loss_irt').notNull().default(20_000_000),
  maxTotalLossUsdt: doublePrecision('max_total_loss_usdt').notNull().default(400),
  enableSymbolConflictLock: boolean('enable_symbol_conflict_lock').notNull().default(true),
  allowAiAdvisoryOnly: boolean('allow_ai_advisory_only').notNull().default(true),
  killSwitchActive: boolean('kill_switch_active').notNull().default(false),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 22. grid_bots
export const gridBots = pgTable('grid_bots', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  symbol: text('symbol').notNull(),
  mode: text('mode').notNull().default('paper'),
  isActive: boolean('is_active').notNull().default(false),
  status: text('status').notNull().default('PAUSED'),
  lowerPrice: doublePrecision('lower_price').notNull(),
  upperPrice: doublePrecision('upper_price').notNull(),
  gridLevels: integer('grid_levels').notNull().default(8),
  stepMode: text('step_mode').notNull().default('ARITHMETIC'),
  totalCapital: doublePrecision('total_capital').notNull(),
  maxCapitalInvolved: doublePrecision('max_capital_involved').notNull(),
  stopOnBreakout: boolean('stop_on_breakout').notNull().default(true),
  alertOnBreakout: boolean('alert_on_breakout').notNull().default(true),
  feeRate: doublePrecision('fee_rate').notNull().default(0.0025),
  estimatedSlippagePercent: doublePrecision('estimated_slippage_percent').notNull().default(0.15),
  executionConfirmationMode: text('execution_confirmation_mode').notNull().default('AUTO'),
  notifyTelegram: boolean('notify_telegram').notNull().default(true),
  allocatedLevelsJson: jsonb('allocated_levels_json').notNull(),
  statsJson: jsonb('stats_json').notNull(),
  lastPrice: doublePrecision('last_price').notNull().default(0),
  lastStatusReason: text('last_status_reason').notNull().default(''),
  lastError: text('last_error'),
  lastCheckedAt: bigint('last_checked_at', { mode: 'number' }),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 23. dca_bots
export const dcaBots = pgTable('dca_bots', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  symbol: text('symbol').notNull(),
  mode: text('mode').notNull().default('paper'),
  isActive: boolean('is_active').notNull().default(false),
  status: text('status').notNull().default('PAUSED'),
  totalCapital: doublePrecision('total_capital').notNull(),
  maxInvolvedCapital: doublePrecision('max_involved_capital').notNull(),
  stagesCount: integer('stages_count').notNull().default(5),
  stepUnit: text('step_unit').notNull().default('PERCENT'),
  stepValue: doublePrecision('step_value').notNull().default(2.5),
  triggerMode: text('trigger_mode').notNull().default('MARKET_DROP'),
  intervalMinutes: integer('interval_minutes').notNull().default(60),
  pauseNewBuys: boolean('pause_new_buys').notNull().default(false),
  stopLossEnabled: boolean('stop_loss_enabled').notNull().default(false),
  stopLossPercent: doublePrecision('stop_loss_percent').notNull().default(8),
  takeProfitEnabled: boolean('take_profit_enabled').notNull().default(true),
  takeProfitPercent: doublePrecision('take_profit_percent').notNull().default(6),
  trailingTpEnabled: boolean('trailing_tp_enabled').notNull().default(false),
  trailingTpActivationPercent: doublePrecision('trailing_tp_activation_percent').notNull().default(5),
  trailingTpCallbackPercent: doublePrecision('trailing_tp_callback_percent').notNull().default(1.2),
  takeProfitTargetsJson: jsonb('take_profit_targets_json').notNull(),
  keepRunnerPercent: doublePrecision('keep_runner_percent').notNull().default(0),
  feeRate: doublePrecision('fee_rate').notNull().default(0.0025),
  estimatedSlippagePercent: doublePrecision('estimated_slippage_percent').notNull().default(0.15),
  executionConfirmationMode: text('execution_confirmation_mode').notNull().default('AUTO'),
  notifyTelegram: boolean('notify_telegram').notNull().default(true),
  stateJson: jsonb('state_json').notNull(),
  statsJson: jsonb('stats_json').notNull(),
  lastPrice: doublePrecision('last_price').notNull().default(0),
  lastStatusReason: text('last_status_reason').notNull().default(''),
  lastError: text('last_error'),
  lastCheckedAt: bigint('last_checked_at', { mode: 'number' }),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 24. pending_bot_confirmations (Manual Confirmation Queue across all bots)
export const pendingBotConfirmations = pgTable('pending_bot_confirmations', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  botId: text('bot_id').notNull(),
  botType: text('bot_type').notNull(),
  botName: text('bot_name').notNull(),
  symbol: text('symbol').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  mode: text('mode').notNull().default('paper'),
  side: text('side').notNull(),
  orderType: text('order_type').notNull().default('MARKET'),
  suggestedPrice: doublePrecision('suggested_price').notNull(),
  quantity: doublePrecision('quantity').notNull(),
  quoteAmount: doublePrecision('quote_amount').notNull(),
  estimatedFeeQuote: doublePrecision('estimated_fee_quote').notNull(),
  reasonFa: text('reason_fa').notNull(),
  riskSummaryFa: text('risk_summary_fa').notNull(),
  metaJson: jsonb('meta_json'),
  status: text('status').notNull().default('PENDING'),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  expiresAt: bigint('expires_at', { mode: 'number' }).notNull(),
  resolvedAt: bigint('resolved_at', { mode: 'number' }),
});

// 25. ai_manager_reports (Saved Central AI Bot Manager analyses)
export const aiManagerReports = pgTable('ai_manager_reports', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  reportJson: jsonb('report_json').notNull(),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
});

// 26. ai_cycle_pro_bots (AI Cycle Pro | ربات چرخه هوشمند)
export const aiCycleProBots = pgTable('ai_cycle_pro_bots', {
  id: text('id').primaryKey(),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  name: text('name').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  symbol: text('symbol').notNull(),
  mode: text('mode').notNull().default('paper'),
  isActive: boolean('is_active').notNull().default(false),
  status: text('status').notNull().default('IDLE'),
  capitalAmount: doublePrecision('capital_amount').notNull(),
  capitalUsageMode: text('capital_usage_mode').notNull().default('FULL'),
  capitalPortionPercent: doublePrecision('capital_portion_percent').notNull().default(100),
  executionConfirmationMode: text('execution_confirmation_mode').notNull().default('AUTO'),
  autoRepeatCycles: boolean('auto_repeat_cycles').notNull().default(true),
  stopLossPercent: doublePrecision('stop_loss_percent').notNull().default(3.0),
  maxDailyLoss: doublePrecision('max_daily_loss').notNull().default(0),
  maxSlippagePercent: doublePrecision('max_slippage_percent').notNull().default(0.6),
  maxSpreadPercent: doublePrecision('max_spread_percent').notNull().default(2.5),
  minTargetNetProfitPercent: doublePrecision('min_target_net_profit_percent').notNull().default(1.2),
  pollIntervalSeconds: integer('poll_interval_seconds').notNull().default(15),
  feeRate: doublePrecision('fee_rate').notNull().default(0.0025),
  notifyTelegram: boolean('notify_telegram').notNull().default(true),
  activePositionJson: jsonb('active_position_json'),
  pendingOrderJson: jsonb('pending_order_json'),
  lastDecisionJson: jsonb('last_decision_json'),
  dailyStatsJson: jsonb('daily_stats_json').notNull(),
  statsJson: jsonb('stats_json').notNull(),
  lastPrice: doublePrecision('last_price').notNull().default(0),
  lastStatusReason: text('last_status_reason').notNull().default(''),
  lastError: text('last_error'),
  lastCheckedAt: bigint('last_checked_at', { mode: 'number' }),
  startedAt: bigint('started_at', { mode: 'number' }),
  createdAt: bigint('created_at', { mode: 'number' }).notNull(),
  updatedAt: bigint('updated_at', { mode: 'number' }).notNull(),
});

// 27. ai_cycle_pro_cycles
export const aiCycleProCycles = pgTable('ai_cycle_pro_cycles', {
  id: text('id').primaryKey(),
  botId: text('bot_id')
    .notNull()
    .references(() => aiCycleProBots.id, { onDelete: 'cascade' }),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  cycleIndex: integer('cycle_index').notNull(),
  symbol: text('symbol').notNull(),
  baseAsset: text('base_asset').notNull(),
  quoteCurrency: text('quote_currency').notNull(),
  mode: text('mode').notNull().default('paper'),
  entryAmountQuote: doublePrecision('entry_amount_quote').notNull(),
  actualBuyAvgPrice: doublePrecision('actual_buy_avg_price').notNull(),
  boughtQty: doublePrecision('bought_qty').notNull(),
  buyFeeQuote: doublePrecision('buy_fee_quote').notNull(),
  totalBuyCostQuote: doublePrecision('total_buy_cost_quote').notNull(),
  actualSellAvgPrice: doublePrecision('actual_sell_avg_price').notNull(),
  soldQty: doublePrecision('sold_qty').notNull(),
  grossSellProceedsQuote: doublePrecision('gross_sell_proceeds_quote').notNull(),
  sellFeeQuote: doublePrecision('sell_fee_quote').notNull(),
  finalNetProfitQuote: doublePrecision('final_net_profit_quote').notNull(),
  targetNetProfitPercent: doublePrecision('target_net_profit_percent').notNull(),
  slippagePercent: doublePrecision('slippage_percent').notNull().default(0),
  exitReason: text('exit_reason').notNull(),
  aiEntrySummaryFa: text('ai_entry_summary_fa').notNull().default(''),
  aiExitSummaryFa: text('ai_exit_summary_fa').notNull().default(''),
  startedAt: bigint('started_at', { mode: 'number' }).notNull(),
  completedAt: bigint('completed_at', { mode: 'number' }).notNull(),
});

// 28. ai_cycle_pro_logs
export const aiCycleProLogs = pgTable('ai_cycle_pro_logs', {
  id: text('id').primaryKey(),
  botId: text('bot_id')
    .notNull()
    .references(() => aiCycleProBots.id, { onDelete: 'cascade' }),
  userId: text('user_id')
    .notNull()
    .references(() => users.uid, { onDelete: 'cascade' }),
  cycleIndex: integer('cycle_index').notNull().default(0),
  status: text('status').notNull(),
  event: text('event').notNull(),
  price: doublePrecision('price').notNull().default(0),
  netProfitQuote: doublePrecision('net_profit_quote'),
  message: text('message').notNull(),
  timestamp: bigint('timestamp', { mode: 'number' }).notNull(),
});

