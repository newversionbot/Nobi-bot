import { useCallback, useEffect, useRef, useState } from 'react';
import {
  AlertTriangle,
  Ban,
  Bell,
  BellRing,
  BookOpen,
  Bot,
  BrainCircuit,
  CandlestickChart as CandleIcon,
  CheckCircle2,
  Clock,
  CreditCard,
  Eye,
  Gift,
  Headphones,
  History,
  Inbox,
  LayoutDashboard,
  LogIn,
  LogOut,
  Megaphone,
  Menu,
  Phone,
  RotateCcw,
  Send,
  Shield,
  SlidersHorizontal,
  Smartphone,
  Sparkles,
  Target,
  TrendingUp,
  UserCog,
  Wallet,
  Wrench,
  X,
} from 'lucide-react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  auth,
  deleteBroadcastFromFirestore,
  deleteDirectMessageFromFirestore,
  fetchAllUsersFromFirestoreForAdmin,
  formatFirebaseAuthError,
  loginWithGoogle,
  logoutUser,
  markApiKeyRevokedInFirestore,
  markDirectMessageReadInFirestore,
  syncApiKeyMetadataToFirestore,
  syncAppControlToFirestore,
  syncBillingConfigToFirestore,
  syncBroadcastToFirestore,
  syncDirectMessageToFirestore,
  syncPaymentRequestToFirestore,
  syncPaymentReviewToFirestore,
  syncReferralRecordToFirestore,
  syncReferralRewardedInFirestore,
  syncSubscriptionToFirestore,
  syncUserProfileToFirestore,
} from './firebase';
import type {
  AdminBillingOverview,
  AdminReferralRecord,
  AiCycleProCapitalUsageMode,
  AiCycleProConfig,
  AiCycleProCycleRecord,
  AiCycleProLog,
  AiCycleProMarketPreview,
  ApiConnectionStatus,
  AiManagerAnalysis,
  AppApiKeySummary,
  AppControlConfig,
  AppFeatureFlags,
  BacktestResult,
  BillingPublicConfig,
  BillingStatusResponse,
  BotExecutionConfirmationMode,
  BotExecutionLog,
  BotFundingMode,
  BotMonitoringTelegramMode,
  BotStrategyConfig,
  BroadcastMessage,
  BroadcastSeverity,
  DcaBotConfig,
  DcaStepUnit,
  DcaTriggerMode,
  DirectMessageRecord,
  ExchangeLinkSummary,
  ExecutionMode,
  FeatureIdeaCategory,
  FeatureIdeaItem,
  FeatureIdeaStatus,
  GridBotConfig,
  GridStepMode,
  IndicatorSnapshot,
  KlineCandle,
  NobitexAuthType,
  OrderBookSnapshot,
  PaymentRequestRecord,
  PendingBotConfirmation,
  PeriodicPriceWatcher,
  PortfolioPerformanceSummary,
  PriceAlert,
  PriceAlertCondition,
  PricePulseNotification,
  PriceReporterQuoteMode,
  ProfitBotConfig,
  ProfitBotCycleRecord,
  ProfitBotDecisionLog,
  ProfitBotLimitUnfilledPolicy,
  ProfitBotMarketPreview,
  ProfitBotOrderType,
  ProfitBotReentryPolicy,
  ProfitBotSequenceMode,
  ProfitBotStopLossAction,
  QuoteCurrency,
  RecentTrade,
  SharedBotRiskSettings,
  SpotBalance,
  SpotOrder,
  StrategyStyleMode,
  TakeProfitTarget,
  TelegramBotSummary,
  TelegramDiscoveredChat,
  TelegramManualReportKind,
  Timeframe,
  UnifiedBotsDashboardSummary,
  UnifiedMarketTicker,
  UserEntitlement,
  UserReferralSummary,
  UserSubscriptionSummary,
} from './types/trading';
import { formatPercent, formatPrice, formatQuotePrice, formatToman } from './utils/format';
import { parseApiJson } from './utils/api';
import {
  DEFAULT_NOBITEX_FEE_RATE,
  buildProfitBotMarketPreview,
  computeExistingBalanceAllocation,
  computeProfitProgressPercent,
  computeRequiredSellPrice,
  getMinimumOrderNotional,
  roundQuoteValue,
  simulateOrderBookSell,
} from './utils/profitBotMath';
import {
  appendDemoTelegramLog,
  buildDemoBalances,
  calculateDemoBotRealizedPnlMetrics,
  cancelDemoOrder,
  computeDemoAiCycleProPreview,
  computeDemoBacktest,
  computeDemoPortfolioPerformance,
  computeDemoUnifiedDashboard,
  createInitialDemoState,
  evaluateDemoAiCycleProBot,
  evaluateDemoProfitBot,
  executeDemoOrder,
  runDemoExtendedBacktest,
  type DemoSandboxState,
} from './utils/demoSandbox';
import { MarketOverview } from './components/MarketOverview';
import { TradingTerminal } from './components/TradingTerminal';
import { CoinAnalysis } from './components/CoinAnalysis';
import { TradingBotModule } from './components/TradingBotModule';
import { AuthAndKeysPanel } from './components/AuthAndKeysPanel';
import { FeaturesHub } from './components/FeaturesHub';
import { ProFeatureGate } from './components/ProFeatureGate';
import { SubscriptionModal } from './components/SubscriptionModal';
import { AdminBillingPanel } from './components/AdminBillingPanel';
import { UserInboxModal } from './components/UserInboxModal';
import { OfflineIndicator, PWAInstallModal } from './components/PWAInstallModal';
import { StartupSplash } from './components/StartupSplash';
import {
  AliTraderLogo,
  SidebarPromoCard,
  USER_BRAND_LOGO_SRC,
} from './components/AliTraderBrand';
import { SupportGuideModal, type SupportGuideTab } from './components/SupportGuideModal';
import { useOnlineStatus, usePWAInstall } from './hooks/usePWAInstall';

type ActiveView =
  | 'DASHBOARD'
  | 'TERMINAL'
  | 'ANALYSIS'
  | 'BOTS'
  | 'FEATURES'
  | 'SECURITY'
  | 'ADMIN';

export default function App() {
  const [view, setView] = useState<ActiveView>('DASHBOARD');
  const [activeNavId, setActiveNavId] = useState<string>('DASHBOARD');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [terminalTabRequest, setTerminalTabRequest] = useState<{
    tab: 'OPEN' | 'HISTORY' | 'BALANCES' | 'ALERTS';
    nonce: number;
  } | null>(null);
  const [featuresSectionRequest, setFeaturesSectionRequest] = useState<{
    section: 'ALL' | 'TELEGRAM' | 'ALERTS' | 'INTERVAL' | 'IDEAS';
    nonce: number;
  } | null>(null);
  const [botTabRequest, setBotTabRequest] = useState<{
    mode:
      | 'HUB'
      | 'AI_CYCLE_PRO'
      | 'PROFIT_BOT'
      | 'BEGINNER'
      | 'FIXED_PRICE'
      | 'ADVANCED'
      | 'GRID'
      | 'DCA'
      | 'AI_MANAGER'
      | 'UNIFIED_DASHBOARD';
    nonce: number;
  } | null>(null);
  const [selectedBaseAsset, setSelectedBaseAsset] = useState<string>('BTC');
  const [selectedQuoteCurrency, setSelectedQuoteCurrency] = useState<QuoteCurrency>('IRT');
  const [timeframe, setTimeframe] = useState<Timeframe>('1h');

  const selectedSymbol = `${selectedBaseAsset}${selectedQuoteCurrency}`;

  const [showSplash, setShowSplash] = useState(true);
  const [installModalOpen, setInstallModalOpen] = useState(false);
  const [guideModalOpen, setGuideModalOpen] = useState(false);
  const [guideModalTab, setGuideModalTab] = useState<SupportGuideTab>('GUIDE');
  const [subscriptionModalOpen, setSubscriptionModalOpen] = useState(false);
  const [subscriptionModalTab, setSubscriptionModalTab] = useState<
    'ZARINPAL' | 'USDT' | 'REFERRAL'
  >('ZARINPAL');
  const [inboxModalOpen, setInboxModalOpen] = useState(false);
  const { isInstalled } = usePWAInstall();
  const isOnline = useOnlineStatus();

  const [demoMode, setDemoMode] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    try {
      const params = new URLSearchParams(window.location.search);
      const q = params.get('demo');
      if (q === '1' || q === 'true') return true;
      return localStorage.getItem('nobitex_demo_mode') === '1';
    } catch {
      return false;
    }
  });
  const [demoState, setDemoState] = useState<DemoSandboxState | null>(null);

  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);

  const [billingConfig, setBillingConfig] = useState<BillingPublicConfig>({
    monthlyPriceToman: 950_000,
    monthlyPriceUsdt: 15,
    fixedUsdtPrice: 15,
    autoUsdtFromRate: true,
    usdtWalletAddress: '',
    usdtNetwork: 'TRC20',
    usdtWalletAddress2: '',
    usdtNetwork2: 'BEP20',
    zarinpalEnabled: false,
    zarinpalSandbox: true,
    updatedAt: Date.now(),
  });
  const [entitlement, setEntitlement] = useState<UserEntitlement>({
    isAuthenticated: false,
    isAdmin: false,
    hasProAccess: false,
    isBanned: false,
    promoFreeAccess: false,
    plan: 'FREE',
    status: 'NONE',
    expiresAt: null,
    daysRemaining: 0,
    subscription: null,
  });
  const [appControl, setAppControl] = useState<AppControlConfig>({
    maintenanceMode: false,
    maintenanceMessage:
      'سامانه در حال بروزرسانی فنی است. لطفاً دقایقی دیگر مجدداً تلاش کنید.',
    promoFreeAccess: false,
    promoBannerText: '',
    supportPhone: '09999961279',
    supportTelegram: '',
    featurePolicies: {
      terminal: 'PRO',
      analysis: 'PRO',
      bots: 'PRO',
      telegram: 'PRO',
      watchers: 'PRO',
      alerts: 'FREE',
      pnlCalculator: 'FREE',
    },
    updatedAt: Date.now(),
  });
  const [broadcasts, setBroadcasts] = useState<BroadcastMessage[]>([]);
  const [dismissedBroadcastIds, setDismissedBroadcastIds] = useState<string[]>([]);
  const [directMessages, setDirectMessages] = useState<DirectMessageRecord[]>([]);
  const [unreadDirectCount, setUnreadDirectCount] = useState(0);
  const [referralSummary, setReferralSummary] = useState<UserReferralSummary | null>(null);
  const [referralBanner, setReferralBanner] = useState<{
    type: 'ok' | 'info' | 'err';
    text: string;
  } | null>(null);
  const [myRequests, setMyRequests] = useState<PaymentRequestRecord[]>([]);
  const [adminOverview, setAdminOverview] = useState<AdminBillingOverview | null>(null);
  const [loadingAdmin, setLoadingAdmin] = useState(false);
  const importedUsersOnceRef = useRef(false);
  const [zarinpalBanner, setZarinpalBanner] = useState<{
    type: 'ok' | 'err';
    text: string;
  } | null>(null);
  const zarinpalHandledRef = useRef(false);
  const [authError, setAuthError] = useState<string | null>(null);

  const [connectionStatus, setConnectionStatus] = useState<ApiConnectionStatus | null>(null);
  const [executionMode, setExecutionMode] = useState<ExecutionMode>('paper');

  const [markets, setMarkets] = useState<UnifiedMarketTicker[]>([]);
  const [usdtTomanRate, setUsdtTomanRate] = useState<number>(0);
  const [loadingMarkets, setLoadingMarkets] = useState(true);

  const [candles, setCandles] = useState<KlineCandle[]>([]);
  const [analysis, setAnalysis] = useState<IndicatorSnapshot | null>(null);
  const [loadingChart, setLoadingChart] = useState(true);

  const [orderBook, setOrderBook] = useState<OrderBookSnapshot | null>(null);
  const [recentTrades, setRecentTrades] = useState<RecentTrade[]>([]);

  const [balances, setBalances] = useState<SpotBalance[]>([]);
  const [openOrders, setOpenOrders] = useState<SpotOrder[]>([]);
  const [orderHistory, setOrderHistory] = useState<SpotOrder[]>([]);
  const [portfolioPerformance, setPortfolioPerformance] =
    useState<PortfolioPerformanceSummary | null>(null);

  const [bots, setBots] = useState<BotStrategyConfig[]>([]);
  const [botLogs, setBotLogs] = useState<BotExecutionLog[]>([]);
  const [profitBots, setProfitBots] = useState<ProfitBotConfig[]>([]);
  const [profitBotCycles, setProfitBotCycles] = useState<ProfitBotCycleRecord[]>([]);
  const [profitBotLogs, setProfitBotLogs] = useState<ProfitBotDecisionLog[]>([]);
  const [aiCycleProBots, setAiCycleProBots] = useState<AiCycleProConfig[]>([]);
  const [aiCycleProCycles, setAiCycleProCycles] = useState<AiCycleProCycleRecord[]>([]);
  const [aiCycleProLogs, setAiCycleProLogs] = useState<AiCycleProLog[]>([]);
  const [gridBots, setGridBots] = useState<GridBotConfig[]>([]);
  const [dcaBots, setDcaBots] = useState<DcaBotConfig[]>([]);
  const [riskSettings, setRiskSettings] = useState<SharedBotRiskSettings | undefined>(undefined);
  const [pendingConfirmations, setPendingConfirmations] = useState<PendingBotConfirmation[]>([]);
  const [aiManagerReport, setAiManagerReport] = useState<AiManagerAnalysis | null>(null);
  const [unifiedDashboard, setUnifiedDashboard] = useState<UnifiedBotsDashboardSummary | null>(
    null
  );
  const [alerts, setAlerts] = useState<PriceAlert[]>([]);
  const [activeNotifications, setActiveNotifications] = useState<PriceAlert[]>([]);
  const alertsInitializedRef = useRef(false);
  const seenTriggeredIdsRef = useRef<Set<string>>(new Set());

  const [watchers, setWatchers] = useState<PeriodicPriceWatcher[]>([]);
  const [pulses, setPulses] = useState<PricePulseNotification[]>([]);
  const [activePulseNotifications, setActivePulseNotifications] = useState<PricePulseNotification[]>(
    []
  );
  const pulsesInitializedRef = useRef(false);
  const seenPulseIdsRef = useRef<Set<string>>(new Set());
  const [ideas, setIdeas] = useState<FeatureIdeaItem[]>([]);
  const [telegram, setTelegram] = useState<TelegramBotSummary>({
    configured: false,
    enabled: false,
    maskedBotToken: '',
    botUsername: '',
    botFirstName: '',
    chatId: '',
    sendPriceAlerts: true,
    sendPeriodicWatchers: true,
    sendTradeReports: true,
    sendBotTrades: true,
    sendBotMonitoring: true,
    botMonitorMode: 'EVENTS_AND_STATUS',
    botMonitorIntervalMinutes: 15,
    updatedAt: null,
    lastSentAt: null,
    lastBotMonitorSentAt: null,
    lastError: null,
    recentLogs: [],
  });

  const [appKeys, setAppKeys] = useState<AppApiKeySummary[]>([]);
  const [exchangeLinks, setExchangeLinks] = useState<ExchangeLinkSummary[]>([]);
  const [hasEnvFallback, setHasEnvFallback] = useState(false);

  const notifyTriggeredAlerts = useCallback((list: PriceAlert[]) => {
    const newlyTriggered: PriceAlert[] = [];
    for (const alert of list) {
      if (alert.status === 'TRIGGERED' && !seenTriggeredIdsRef.current.has(alert.id)) {
        seenTriggeredIdsRef.current.add(alert.id);
        if (alertsInitializedRef.current) {
          newlyTriggered.push(alert);
        }
      }
    }
    if (!alertsInitializedRef.current) {
      alertsInitializedRef.current = true;
      return;
    }
    if (newlyTriggered.length > 0) {
      setActiveNotifications((prev) => {
        const existingIds = new Set(prev.map((p) => p.id));
        const additions = newlyTriggered.filter((n) => !existingIds.has(n.id));
        return [...additions, ...prev].slice(0, 5);
      });
      // Subtle Web Audio chime
      try {
        const AudioCtx =
          window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        if (AudioCtx) {
          const ctx = new AudioCtx();
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(880, ctx.currentTime);
          gain.gain.setValueAtTime(0.08, ctx.currentTime);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.35);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start();
          osc.stop(ctx.currentTime + 0.35);
        }
      } catch {
        // Ignore audio blocked errors
      }
      // Browser Notification API if granted
      if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
        for (const a of newlyTriggered) {
          const dirLabel = a.condition === 'ABOVE' ? 'بالاتر از' : 'پایین‌تر از';
          try {
            new Notification(`هشدار قیمت ${a.persianName} (${a.symbol})`, {
              body: `قیمت به ${dirLabel} هدف ${formatQuotePrice(a.targetPrice, a.quoteCurrency)} رسید.`,
            });
          } catch {
            // Ignore notification errors inside sandboxed iframes
          }
        }
      }
    }
  }, []);

  const notifyNewPulses = useCallback(
    (pulseList: PricePulseNotification[], watcherList: PeriodicPriceWatcher[]) => {
      const newlyEmitted: PricePulseNotification[] = [];
      for (const p of pulseList) {
        if (!seenPulseIdsRef.current.has(p.id)) {
          seenPulseIdsRef.current.add(p.id);
          if (pulsesInitializedRef.current) {
            newlyEmitted.push(p);
          }
        }
      }
      if (!pulsesInitializedRef.current) {
        pulsesInitializedRef.current = true;
        return;
      }
      if (newlyEmitted.length === 0) return;

      setActivePulseNotifications((prev) => {
        const existingIds = new Set(prev.map((x) => x.id));
        const additions = newlyEmitted.filter((n) => !existingIds.has(n.id));
        return [...additions, ...prev].slice(0, 5);
      });

      const watcherMap = new Map(watcherList.map((w) => [w.id, w]));
      const shouldPlaySound = newlyEmitted.some((p) => watcherMap.get(p.watcherId)?.playSound !== false);
      if (shouldPlaySound) {
        try {
          const AudioCtx =
            window.AudioContext ||
            (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
          if (AudioCtx) {
            const ctx = new AudioCtx();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(740, ctx.currentTime);
            gain.gain.setValueAtTime(0.06, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.28);
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 0.28);
          }
        } catch {
          // Ignore audio blocked errors
        }
      }

      if (
        typeof window !== 'undefined' &&
        'Notification' in window &&
        Notification.permission === 'granted'
      ) {
        for (const p of newlyEmitted) {
          const w = watcherMap.get(p.watcherId);
          if (w && !w.notifyBrowser) continue;
          const priceStr =
            p.quoteMode === 'IRT'
              ? `${formatToman(p.priceToman)} تومان`
              : p.quoteMode === 'USDT'
                ? `$${formatPrice(p.priceUsdt)} USDT`
                : `${formatToman(p.priceToman)} تومان ($${formatPrice(p.priceUsdt)})`;
          try {
            new Notification(`قیمت لحظه‌ای ${p.persianName} (${p.baseAsset})`, {
              body: `${priceStr} · تغییر ۲۴h: ${formatPercent(p.change24hPercent)}`,
            });
          } catch {
            // Ignore sandboxed notification errors
          }
        }
      }
    },
    []
  );

  const getAuthHeaders = useCallback(async (): Promise<Record<string, string>> => {
    const current = auth.currentUser;
    if (!current) return {};
    try {
      const token = await current.getIdToken();
      return { Authorization: `Bearer ${token}` };
    } catch {
      return {};
    }
  }, []);

  const refreshStatusAndKeys = useCallback(async () => {
    const headers = await getAuthHeaders();
    try {
      const statusRes = await fetch('/api/status', { headers });
      if (statusRes.ok) {
        const st = (await statusRes.json()) as ApiConnectionStatus;
        setConnectionStatus(st);
      }
    } catch {
      // Ignore transient network errors
    }

    if (auth.currentUser) {
      try {
        const keysRes = await fetch('/api/keys', { headers });
        if (keysRes.ok) {
          const data = (await keysRes.json()) as {
            appKeys: AppApiKeySummary[];
            exchangeLinks: ExchangeLinkSummary[];
            hasEnvFallback: boolean;
          };
          setAppKeys(data.appKeys || []);
          setExchangeLinks(data.exchangeLinks || []);
          setHasEnvFallback(Boolean(data.hasEnvFallback));
        }
      } catch {
        // Ignore transient network errors
      }
    } else {
      setAppKeys([]);
      setExchangeLinks([]);
    }
  }, [getAuthHeaders]);

  const refreshMarkets = useCallback(async () => {
    try {
      const headers = auth.currentUser ? await getAuthHeaders() : {};
      const res = await fetch('/api/market/tickers', { headers });
      if (res.ok) {
        const data = (await res.json()) as {
          usdtTomanRate: number;
          markets: UnifiedMarketTicker[];
        };
        setUsdtTomanRate(data.usdtTomanRate || 0);
        setMarkets(data.markets || []);
      }
    } catch {
      // Ignore transient network errors during polling
    } finally {
      setLoadingMarkets(false);
    }
  }, [getAuthHeaders]);

  const refreshSymbolMarketData = useCallback(async () => {
    try {
      const [kSettled, dSettled, tSettled] = await Promise.allSettled([
        fetch(
          `/api/market/klines?symbol=${encodeURIComponent(selectedSymbol)}&interval=${timeframe}&limit=160`
        ),
        fetch(`/api/market/depth?symbol=${encodeURIComponent(selectedSymbol)}&limit=16`),
        fetch(`/api/market/trades?symbol=${encodeURIComponent(selectedSymbol)}&limit=25`),
      ]);
      if (kSettled.status === 'fulfilled' && kSettled.value.ok) {
        const kData = (await kSettled.value.json()) as {
          candles: KlineCandle[];
          analysis: IndicatorSnapshot;
        };
        setCandles(kData.candles || []);
        setAnalysis(kData.analysis || null);
      }
      if (dSettled.status === 'fulfilled' && dSettled.value.ok) {
        setOrderBook((await dSettled.value.json()) as OrderBookSnapshot);
      }
      if (tSettled.status === 'fulfilled' && tSettled.value.ok) {
        setRecentTrades((await tSettled.value.json()) as RecentTrade[]);
      }
    } catch {
      // Ignore transient network errors during polling
    } finally {
      setLoadingChart(false);
    }
  }, [selectedSymbol, timeframe]);

  const refreshAccount = useCallback(async () => {
    if (!auth.currentUser) {
      setBalances([]);
      setOpenOrders([]);
      setOrderHistory([]);
      setPortfolioPerformance(null);
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch(
        `/api/account?mode=${executionMode}&symbol=${encodeURIComponent(selectedSymbol)}`,
        { headers }
      );
      if (res.ok) {
        const data = (await res.json()) as {
          balances: SpotBalance[];
          openOrders: SpotOrder[];
          orderHistory: SpotOrder[];
          portfolioPerformance?: PortfolioPerformanceSummary | null;
        };
        setBalances(data.balances || []);
        setOpenOrders(data.openOrders || []);
        setOrderHistory(data.orderHistory || []);
        setPortfolioPerformance(data.portfolioPerformance || null);
      }
    } catch {
      // Ignore transient network errors
    }
  }, [executionMode, selectedSymbol, getAuthHeaders]);

  const refreshBots = useCallback(async () => {
    if (!auth.currentUser) {
      setBots([]);
      setBotLogs([]);
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/bots', { headers });
      if (res.ok) {
        const data = (await res.json()) as {
          bots: BotStrategyConfig[];
          logs: BotExecutionLog[];
        };
        setBots(data.bots || []);
        setBotLogs(data.logs || []);
      }
    } catch {
      // Ignore
    }
  }, [getAuthHeaders]);

  const refreshProfitBots = useCallback(async () => {
    if (!auth.currentUser) {
      setProfitBots([]);
      setProfitBotCycles([]);
      setProfitBotLogs([]);
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/profit-bots', { headers });
      if (res.ok) {
        const data = (await res.json()) as {
          bots: ProfitBotConfig[];
          cycles: ProfitBotCycleRecord[];
          logs: ProfitBotDecisionLog[];
        };
        setProfitBots(data.bots || []);
        setProfitBotCycles(data.cycles || []);
        setProfitBotLogs(data.logs || []);
      }
    } catch {
      // Ignore
    }
  }, [getAuthHeaders]);

  const refreshAiCycleProBots = useCallback(async () => {
    if (!auth.currentUser) {
      setAiCycleProBots([]);
      setAiCycleProCycles([]);
      setAiCycleProLogs([]);
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/ai-cycle-pro', { headers });
      if (res.ok) {
        const data = (await res.json()) as {
          bots?: AiCycleProConfig[];
          cycles?: AiCycleProCycleRecord[];
          logs?: AiCycleProLog[];
        };
        setAiCycleProBots(data.bots || []);
        setAiCycleProCycles(data.cycles || []);
        setAiCycleProLogs(data.logs || []);
      }
    } catch {
      // Ignore
    }
  }, [getAuthHeaders]);

  const refreshSmartBots = useCallback(
    async (includeHeavy = true) => {
      if (!auth.currentUser) {
        setGridBots([]);
        setDcaBots([]);
        setRiskSettings(undefined);
        setPendingConfirmations([]);
        setAiManagerReport(null);
        setUnifiedDashboard(null);
        return;
      }
      try {
        const headers = await getAuthHeaders();
        const [gridRes, dcaRes, confRes, riskRes, aiRes, dashRes] = await Promise.all([
          fetch('/api/grid-bots', { headers }),
          fetch('/api/dca-bots', { headers }),
          fetch('/api/bots/pending-confirmations', { headers }),
          includeHeavy ? fetch('/api/bots/risk-settings', { headers }) : Promise.resolve(null),
          includeHeavy ? fetch('/api/ai/bot-manager', { headers }) : Promise.resolve(null),
          includeHeavy ? fetch('/api/bots/unified-dashboard', { headers }) : Promise.resolve(null),
        ]);
        if (gridRes.ok) {
          const d = (await gridRes.json()) as { bots?: GridBotConfig[] };
          setGridBots(d.bots || []);
        }
        if (dcaRes.ok) {
          const d = (await dcaRes.json()) as { bots?: DcaBotConfig[] };
          setDcaBots(d.bots || []);
        }
        if (confRes.ok) {
          const d = (await confRes.json()) as { items?: PendingBotConfirmation[] };
          setPendingConfirmations(d.items || []);
        }
        if (riskRes && riskRes.ok) {
          const d = (await riskRes.json()) as SharedBotRiskSettings;
          setRiskSettings(d);
        }
        if (aiRes && aiRes.ok) {
          const d = (await aiRes.json()) as { latest?: AiManagerAnalysis | null };
          setAiManagerReport(d.latest || null);
        }
        if (dashRes && dashRes.ok) {
          const d = (await dashRes.json()) as UnifiedBotsDashboardSummary;
          setUnifiedDashboard(d);
        }
      } catch {
        // Ignore transient network errors
      }
    },
    [getAuthHeaders]
  );

  const refreshAlerts = useCallback(async () => {
    if (!auth.currentUser) {
      setAlerts([]);
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/alerts', { headers });
      if (res.ok) {
        const data = (await res.json()) as { alerts: PriceAlert[] };
        const list = data.alerts || [];
        setAlerts(list);
        notifyTriggeredAlerts(list);
      }
    } catch {
      // Ignore
    }
  }, [getAuthHeaders, notifyTriggeredAlerts]);

  const refreshWatchers = useCallback(async () => {
    if (!auth.currentUser) {
      setWatchers([]);
      setPulses([]);
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/features/watchers', { headers });
      if (res.ok) {
        const data = (await res.json()) as {
          watchers: PeriodicPriceWatcher[];
          pulses: PricePulseNotification[];
        };
        const wList = data.watchers || [];
        const pList = data.pulses || [];
        setWatchers(wList);
        setPulses(pList);
        notifyNewPulses(pList, wList);
      }
    } catch {
      // Ignore
    }
  }, [getAuthHeaders, notifyNewPulses]);

  const refreshIdeas = useCallback(async () => {
    if (!auth.currentUser) {
      setIdeas([]);
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/features/ideas', { headers });
      if (res.ok) {
        const data = (await res.json()) as { ideas: FeatureIdeaItem[] };
        setIdeas(data.ideas || []);
      }
    } catch {
      // Ignore
    }
  }, [getAuthHeaders]);

  const refreshTelegram = useCallback(async () => {
    if (!auth.currentUser) {
      return;
    }
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/features/telegram', { headers });
      if (res.ok) {
        const data = (await res.json()) as { telegram: TelegramBotSummary };
        if (data.telegram) setTelegram(data.telegram);
      }
    } catch {
      // Ignore
    }
  }, [getAuthHeaders]);

  const refreshBilling = useCallback(async () => {
    try {
      const headers = await getAuthHeaders();
      const res = await fetch('/api/billing/status', { headers });
      if (res.ok) {
        const data = (await res.json()) as BillingStatusResponse;
        if (data.config) setBillingConfig(data.config);
        if (data.entitlement) setEntitlement(data.entitlement);
        if (data.appControl) setAppControl(data.appControl);
        setMyRequests(data.myRequests || []);
        setBroadcasts(data.broadcasts || []);
        setDirectMessages(data.directMessages || []);
        setUnreadDirectCount(data.unreadDirectCount || 0);
        setReferralSummary(data.referral || null);
      }
    } catch {
      // Ignore transient network errors
    }
  }, [getAuthHeaders]);

  const refreshAdminOverview = useCallback(async () => {
    if (!auth.currentUser) {
      setAdminOverview(null);
      return;
    }
    setLoadingAdmin(true);
    try {
      const headers = await getAuthHeaders();
      if (!importedUsersOnceRef.current) {
        importedUsersOnceRef.current = true;
        const firestoreUsers = await fetchAllUsersFromFirestoreForAdmin();
        if (firestoreUsers.length > 0) {
          await fetch('/api/billing/admin/users/import', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              ...headers,
            },
            body: JSON.stringify({ users: firestoreUsers }),
          });
        }
      }
      const res = await fetch('/api/billing/admin/overview', { headers });
      if (res.ok) {
        const data = (await res.json()) as AdminBillingOverview;
        setAdminOverview(data);
        if (data.appControl) setAppControl(data.appControl);
      }
    } catch {
      // Ignore
    } finally {
      setLoadingAdmin(false);
    }
  }, [getAuthHeaders]);

  const authRefreshRef = useRef({
    refreshStatusAndKeys,
    refreshAccount,
    refreshBilling,
    refreshBots,
    refreshProfitBots,
    refreshAiCycleProBots,
    refreshSmartBots,
    refreshAlerts,
    refreshWatchers,
    refreshIdeas,
    refreshTelegram,
  });
  authRefreshRef.current = {
    refreshStatusAndKeys,
    refreshAccount,
    refreshBilling,
    refreshBots,
    refreshProfitBots,
    refreshAiCycleProBots,
    refreshSmartBots,
    refreshAlerts,
    refreshWatchers,
    refreshIdeas,
    refreshTelegram,
  };

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (u) => {
      setUser(u);
      setAuthLoading(false);
      if (u) {
        void syncUserProfileToFirestore(u);
      } else {
        setAdminOverview(null);
        setDirectMessages([]);
        setUnreadDirectCount(0);
        setReferralSummary(null);
        setBots([]);
        setBotLogs([]);
        setProfitBots([]);
        setProfitBotCycles([]);
        setProfitBotLogs([]);
        setAiCycleProBots([]);
        setAiCycleProCycles([]);
        setAiCycleProLogs([]);
        setGridBots([]);
        setDcaBots([]);
        setRiskSettings(undefined);
        setPendingConfirmations([]);
        setAiManagerReport(null);
        setUnifiedDashboard(null);
        setAlerts([]);
        setWatchers([]);
        setPulses([]);
        setIdeas([]);
        setBalances([]);
        setOpenOrders([]);
        setOrderHistory([]);
        setPortfolioPerformance(null);
        setActiveNotifications([]);
        setActivePulseNotifications([]);
        importedUsersOnceRef.current = false;
      }
      const r = authRefreshRef.current;
      void r.refreshStatusAndKeys();
      void r.refreshAccount();
      void r.refreshBilling();
      void r.refreshBots();
      void r.refreshProfitBots();
      void r.refreshAiCycleProBots();
      void r.refreshSmartBots();
      void r.refreshAlerts();
      void r.refreshWatchers();
      void r.refreshIdeas();
      void r.refreshTelegram();
    });
    return () => unsub();
  }, []);

  const handleClaimReferralCode = useCallback(
    async (code: string) => {
      const headers = {
        'Content-Type': 'application/json',
        ...(await getAuthHeaders()),
      };
      const res = await fetch('/api/referrals/claim', {
        method: 'POST',
        headers,
        body: JSON.stringify({ code }),
      });
      const data = await parseApiJson<{
        claimed?: boolean;
        alreadyLinked?: boolean;
        message?: string;
        error?: string;
        referral?: AdminReferralRecord;
        summary?: UserReferralSummary;
      }>(res, 'خطا در ثبت کد دعوت');
      if (data.claimed && data.referral) {
        void syncReferralRecordToFirestore(data.referral);
      }
      if (data.summary) {
        setReferralSummary(data.summary);
      }
      try {
        localStorage.removeItem('nobitex_pending_ref');
      } catch {
        // Ignore storage errors
      }
      await refreshBilling();
      return {
        claimed: Boolean(data.claimed),
        alreadyLinked: Boolean(data.alreadyLinked),
        message: data.message || 'کد دعوت ثبت شد.',
      };
    },
    [getAuthHeaders, refreshBilling]
  );

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    let urlChanged = false;

    const demoParam = params.get('demo');
    if (demoParam === '1' || demoParam === 'true') {
      setDemoMode(true);
      try {
        localStorage.setItem('nobitex_demo_mode', '1');
      } catch {
        // Ignore storage errors
      }
      params.delete('demo');
      urlChanged = true;
    }

    const refParam = params.get('ref');
    if (refParam) {
      const cleanRef = refParam.trim().toUpperCase().slice(0, 32);
      if (cleanRef.length >= 4) {
        try {
          localStorage.setItem('nobitex_pending_ref', cleanRef);
        } catch {
          // Ignore storage errors
        }
      }
      params.delete('ref');
      urlChanged = true;
    }

    if (urlChanged) {
      const nextSearch = params.toString();
      const nextUrl = `${window.location.pathname}${nextSearch ? `?${nextSearch}` : ''}`;
      window.history.replaceState({}, '', nextUrl);
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('nobitex_demo_mode', demoMode ? '1' : '0');
    } catch {
      // Ignore storage errors
    }
    if (demoMode && !demoState) {
      setDemoState(createInitialDemoState(markets, usdtTomanRate));
    }
  }, [demoMode, demoState, markets, usdtTomanRate]);

  const toggleDemoMode = useCallback(
    (next?: boolean) => {
      setDemoMode((prev) => {
        const target = typeof next === 'boolean' ? next : !prev;
        if (target && !demoState) {
          setDemoState(createInitialDemoState(markets, usdtTomanRate));
        }
        return target;
      });
    },
    [demoState, markets, usdtTomanRate]
  );

  const handleResetDemoSandbox = useCallback(() => {
    setDemoState(createInitialDemoState(markets, usdtTomanRate));
  }, [markets, usdtTomanRate]);

  useEffect(() => {
    if (authLoading || !user) return;
    let pendingRef = '';
    try {
      pendingRef = localStorage.getItem('nobitex_pending_ref') || '';
    } catch {
      pendingRef = '';
    }
    if (!pendingRef) return;

    void (async () => {
      try {
        const res = await handleClaimReferralCode(pendingRef);
        if (res.claimed) {
          setReferralBanner({
            type: 'ok',
            text: res.message,
          });
        }
      } catch {
        try {
          localStorage.removeItem('nobitex_pending_ref');
        } catch {
          // Ignore
        }
      }
    })();
  }, [authLoading, user, handleClaimReferralCode]);

  useEffect(() => {
    if (entitlement.isAdmin) {
      void refreshAdminOverview();
    } else {
      setAdminOverview(null);
      if (view === 'ADMIN') {
        setView('DASHBOARD');
      }
    }
  }, [entitlement.isAdmin, view, refreshAdminOverview]);

  useEffect(() => {
    if (authLoading || zarinpalHandledRef.current) return;
    const params = new URLSearchParams(window.location.search);
    if (params.get('zarinpal') !== 'callback') return;

    const authority = params.get('Authority') || params.get('authority') || '';
    const status = params.get('Status') || params.get('status') || 'NOK';
    if (!authority) {
      window.history.replaceState({}, '', window.location.pathname);
      return;
    }

    if (!user) {
      setZarinpalBanner({
        type: 'err',
        text: 'برای تکمیل و تایید پرداخت زرین‌پال، لطفاً ابتدا از بخش حساب کاربری با گوگل وارد شوید.',
      });
      return;
    }

    zarinpalHandledRef.current = true;
    window.history.replaceState({}, '', window.location.pathname);

    void (async () => {
      try {
        const headers = {
          'Content-Type': 'application/json',
          ...(await getAuthHeaders()),
        };
        const res = await fetch('/api/billing/zarinpal/verify', {
          method: 'POST',
          headers,
          body: JSON.stringify({ authority, status }),
        });
        const data = await parseApiJson<{
          verified?: boolean;
          refId?: string;
          message?: string;
          error?: string;
          subscription?: UserSubscriptionSummary;
          referralReward?: {
            referral: AdminReferralRecord;
            rewardedSubscription: UserSubscriptionSummary;
          } | null;
        }>(res, 'خطا در تایید پرداخت زرین‌پال');
        if (data.verified) {
          setZarinpalBanner({
            type: 'ok',
            text: `${data.message || 'اشتراک حرفه‌ای شما با موفقیت فعال شد.'}${
              data.refId ? ` (کد پیگیری: ${data.refId})` : ''
            }`,
          });
          const isClientAdmin =
            entitlement.isAdmin ||
            user.email?.trim().toLowerCase() === 'shivamdonyam@gmail.com';
          if (isClientAdmin) {
            if (data.subscription) {
              void syncSubscriptionToFirestore(data.subscription);
            }
            if (data.referralReward) {
              void syncSubscriptionToFirestore(data.referralReward.rewardedSubscription);
              void syncReferralRewardedInFirestore(data.referralReward.referral.id);
            }
          }
        } else {
          setZarinpalBanner({
            type: 'err',
            text: data.message || data.error || 'تراکنش زرین‌پال تایید نشد.',
          });
        }
      } catch {
        setZarinpalBanner({
          type: 'err',
          text: 'خطا در ارتباط با سرور برای تایید تراکنش زرین‌پال.',
        });
      } finally {
        await refreshBilling();
      }
    })();
  }, [authLoading, user, getAuthHeaders, refreshBilling]);

  useEffect(() => {
    void refreshMarkets();
    void refreshBots();
    void refreshProfitBots();
    void refreshAiCycleProBots();
    void refreshSmartBots();
    void refreshAlerts();
    void refreshWatchers();
    void refreshIdeas();
    void refreshTelegram();
    void refreshBilling();
    const tTimer = setInterval(() => {
      void refreshMarkets();
      void refreshAlerts();
      void refreshWatchers();
      void refreshTelegram();
      void refreshBilling();
    }, 7000);
    const bTimer = setInterval(() => {
      void refreshBots();
      void refreshProfitBots();
      void refreshAiCycleProBots();
      void refreshSmartBots();
    }, 10000);
    return () => {
      clearInterval(tTimer);
      clearInterval(bTimer);
    };
  }, [
    refreshMarkets,
    refreshBots,
    refreshProfitBots,
    refreshAiCycleProBots,
    refreshSmartBots,
    refreshAlerts,
    refreshWatchers,
    refreshIdeas,
    refreshTelegram,
    refreshBilling,
  ]);

  useEffect(() => {
    setLoadingChart(true);
    void refreshSymbolMarketData();
    void refreshAccount();
    const accountPollMs = executionMode === 'live' ? 9000 : 5000;
    const sTimer = setInterval(() => {
      void refreshSymbolMarketData();
      void refreshAccount();
    }, accountPollMs);
    return () => clearInterval(sTimer);
  }, [refreshSymbolMarketData, refreshAccount, executionMode]);

  const hasRunningFixedBots = (demoMode ? demoState?.bots || [] : bots).some(
    (b) => b.status === 'RUNNING' && b.strategyKind === 'FIXED_PRICE'
  );
  const hasActiveProfitBots = (demoMode ? demoState?.profitBots || [] : profitBots).some(
    (b) => b.isActive
  );
  const hasActiveAiCycleProBots = (
    demoMode ? demoState?.aiCycleProBots || [] : aiCycleProBots
  ).some((b) => b.isActive);
  const hasActiveSmartBots =
    (demoMode ? demoState?.gridBots || [] : gridBots).some((b) => b.isActive) ||
    (demoMode ? demoState?.dcaBots || [] : dcaBots).some((b) => b.isActive);

  useEffect(() => {
    if (
      demoMode ||
      !auth.currentUser ||
      (!hasRunningFixedBots &&
        !hasActiveProfitBots &&
        !hasActiveAiCycleProBots &&
        !hasActiveSmartBots)
    )
      return;
    const fastTimer = setInterval(() => {
      if (hasRunningFixedBots) void refreshBots();
      if (hasActiveProfitBots) void refreshProfitBots();
      if (hasActiveAiCycleProBots) void refreshAiCycleProBots();
      if (hasActiveSmartBots) void refreshSmartBots(false);
    }, 5000);
    return () => clearInterval(fastTimer);
  }, [
    demoMode,
    hasRunningFixedBots,
    hasActiveProfitBots,
    hasActiveAiCycleProBots,
    hasActiveSmartBots,
    refreshBots,
    refreshProfitBots,
    refreshAiCycleProBots,
    refreshSmartBots,
  ]);

  // Demo mode Profit Bot evaluator using live Nobitex orderbook depth
  const demoProfitBotsRef = useRef<ProfitBotConfig[]>([]);
  demoProfitBotsRef.current = demoState?.profitBots || [];

  useEffect(() => {
    if (!demoMode || !hasActiveProfitBots) return;
    let running = false;
    const timer = setInterval(() => {
      if (running) return;
      const now = Date.now();
      const dueBots = demoProfitBotsRef.current.filter((b) => {
        if (!b.isActive) return false;
        const intervalMs = Math.max(2000, (b.pollIntervalSeconds || 10) * 1000);
        return !b.lastCheckedAt || now - b.lastCheckedAt >= intervalMs - 250;
      });
      if (dueBots.length === 0) return;

      running = true;
      void (async () => {
        try {
          const uniqueSymbols = Array.from(new Set(dueBots.map((b) => b.symbol)));
          const bookMap = new Map<string, OrderBookSnapshot>();
          await Promise.all(
            uniqueSymbols.map(async (sym) => {
              try {
                const res = await fetch(`/api/market/depth?symbol=${encodeURIComponent(sym)}&limit=30`);
                if (res.ok) {
                  bookMap.set(sym, (await res.json()) as OrderBookSnapshot);
                }
              } catch {
                // Keep absent on network error
              }
            })
          );

          const evalTime = Date.now();
          setDemoState((prev) => {
            if (!prev) return prev;
            const addedCycles: ProfitBotCycleRecord[] = [];
            const addedLogs: ProfitBotDecisionLog[] = [];
            const nextBots = prev.profitBots.map((b) => {
              if (!dueBots.some((d) => d.id === b.id)) return b;
              const book = bookMap.get(b.symbol);
              if (!book) {
                return {
                  ...b,
                  botStatus: 'CONNECTION_ERROR' as const,
                  lastError: 'خطا در دریافت دفتر سفارش لحظه‌ای نوبیتکس',
                  lastStatusReason: 'خطای اتصال به دفتر سفارش نوبیتکس؛ ثبت سفارش جدید متوقف شد.',
                  lastCheckedAt: evalTime,
                  updatedAt: evalTime,
                };
              }
              const result = evaluateDemoProfitBot(b, book, evalTime, prev.balances);
              if (result.newCycle) addedCycles.unshift(result.newCycle);
              if (result.newLogs.length > 0) addedLogs.unshift(...result.newLogs);
              return result.bot;
            });

            return {
              ...prev,
              profitBots: nextBots,
              profitBotCycles: [...addedCycles, ...prev.profitBotCycles].slice(0, 60),
              profitBotLogs: [...addedLogs, ...prev.profitBotLogs].slice(0, 120),
            };
          });
        } finally {
          running = false;
        }
      })();
    }, 2500);
    return () => clearInterval(timer);
  }, [demoMode, hasActiveProfitBots]);

  // Demo mode AI Cycle Pro evaluator using live Nobitex orderbook depth
  const demoAiCycleProBotsRef = useRef<AiCycleProConfig[]>([]);
  demoAiCycleProBotsRef.current = demoState?.aiCycleProBots || [];
  const demoMarketsRef = useRef<UnifiedMarketTicker[]>([]);
  demoMarketsRef.current = markets;

  useEffect(() => {
    if (!demoMode || !hasActiveAiCycleProBots) return;
    let running = false;
    const timer = setInterval(() => {
      if (running) return;
      const now = Date.now();
      const dueBots = demoAiCycleProBotsRef.current.filter((b) => {
        if (!b.isActive) return false;
        const intervalMs = Math.max(4000, (b.pollIntervalSeconds || 20) * 1000);
        return !b.lastCheckedAt || now - b.lastCheckedAt >= intervalMs - 250;
      });
      if (dueBots.length === 0) return;

      running = true;
      void (async () => {
        try {
          const uniqueSymbols = Array.from(new Set(dueBots.map((b) => b.symbol)));
          const bookMap = new Map<string, OrderBookSnapshot>();
          await Promise.all(
            uniqueSymbols.map(async (sym) => {
              try {
                const res = await fetch(`/api/market/depth?symbol=${encodeURIComponent(sym)}&limit=30`);
                if (res.ok) {
                  bookMap.set(sym, (await res.json()) as OrderBookSnapshot);
                }
              } catch {
                // Keep absent on network error
              }
            })
          );

          const evalTime = Date.now();
          setDemoState((prev) => {
            if (!prev) return prev;
            const addedCycles: AiCycleProCycleRecord[] = [];
            const addedLogs: AiCycleProLog[] = [];
            const addedConfirmations: PendingBotConfirmation[] = [];
            const nextBots = (prev.aiCycleProBots || []).map((b) => {
              if (!dueBots.some((d) => d.id === b.id)) return b;
              const book = bookMap.get(b.symbol);
              if (!book) {
                return {
                  ...b,
                  lastError: 'خطا در دریافت دفتر سفارش لحظه‌ای نوبیتکس',
                  lastCheckedAt: evalTime,
                  updatedAt: evalTime,
                };
              }
              const res = evaluateDemoAiCycleProBot(b, book, demoMarketsRef.current, evalTime);
              if (res.newCycle) addedCycles.unshift(res.newCycle);
              if (res.newLogs.length > 0) addedLogs.unshift(...res.newLogs);
              if (res.pendingConfirmation) addedConfirmations.unshift(res.pendingConfirmation);
              return res.bot;
            });

            return {
              ...prev,
              aiCycleProBots: nextBots,
              aiCycleProCycles: [...addedCycles, ...(prev.aiCycleProCycles || [])].slice(0, 60),
              aiCycleProLogs: [...addedLogs, ...(prev.aiCycleProLogs || [])].slice(0, 120),
              pendingConfirmations:
                addedConfirmations.length > 0
                  ? [...addedConfirmations, ...(prev.pendingConfirmations || [])]
                  : prev.pendingConfirmations,
            };
          });
        } finally {
          running = false;
        }
      })();
    }, 3000);
    return () => clearInterval(timer);
  }, [demoMode, hasActiveAiCycleProBots]);

  // Demo mode client-side fast fixed-price cycle evaluator against live Nobitex prices
  useEffect(() => {
    if (!demoMode || !hasRunningFixedBots || markets.length === 0) return;
    const timer = setInterval(() => {
      const now = Date.now();
      setDemoState((prev) => {
        if (!prev) return prev;
        let changed = false;
        const nextBots = prev.bots.map((b) => {
          if (b.status !== 'RUNNING' || b.strategyKind !== 'FIXED_PRICE') return b;
          const intervalMs = Math.max(2000, (b.pollIntervalSeconds || 5) * 1000);
          if (b.lastCheckedAt && now - b.lastCheckedAt < intervalMs - 250) return b;
          const m = markets.find((x) => x.baseAsset === b.baseAsset);
          const px =
            b.quoteCurrency === 'IRT'
              ? m?.priceToman || m?.bestSellToman || 0
              : m?.priceUsdt || m?.bestSellUsdt || 0;
          if (px <= 0) return b;
          changed = true;
          const buyTarget = b.targetBuyPrice || 0;
          const sellTarget = b.targetSellPrice || 0;

          if (b.activePosition) {
            if (sellTarget > 0 && px >= sellTarget) {
              const grossExit = b.activePosition.quantity * px * (1 - 0.0025);
              const entryCost = b.activePosition.quantity * b.activePosition.entryPrice;
              const pnlQuote = Number(
                (grossExit - entryCost).toFixed(b.quoteCurrency === 'IRT' ? 0 : 2)
              );
              const totalTrades = b.stats.totalTrades + 1;
              const reachedMax = Boolean(b.maxCycles && totalTrades >= b.maxCycles);
              const keepRunning = b.repeatCycle !== false && !reachedMax;
              return {
                ...b,
                status: keepRunning ? ('RUNNING' as const) : ('PAUSED' as const),
                activePosition: null,
                stats: {
                  totalTrades,
                  winningTrades: b.stats.winningTrades + (pnlQuote >= 0 ? 1 : 0),
                  losingTrades: b.stats.losingTrades + (pnlQuote < 0 ? 1 : 0),
                  realizedPnl: Number(
                    (b.stats.realizedPnl + pnlQuote).toFixed(b.quoteCurrency === 'IRT' ? 0 : 2)
                  ),
                },
                lastCheckedAt: now,
                lastSignalSummary: keepRunning
                  ? `چرخه ${totalTrades} با فروش تکمیل شد · آماده خرید بعدی`
                  : `فروش انجام شد و چرخه پایان یافت`,
              };
            }
            return {
              ...b,
              lastCheckedAt: now,
              lastSignalSummary: `خرید انجام شد · منتظر رسیدن به قیمت فروش هدف`,
            };
          }

          const fundingMode = b.fundingMode || 'QUOTE_BUY';
          if (fundingMode === 'EXISTING_ASSET' || fundingMode === 'AUTO_PREFER_EXISTING') {
            const freeBase =
              prev.balances.find((bal) => bal.asset.toUpperCase() === b.baseAsset.toUpperCase())
                ?.free ?? 0;
            const alloc = computeExistingBalanceAllocation({
              freeBase,
              percent: b.existingBalancePercent ?? 50,
              referencePrice: px,
              minNotional: getMinimumOrderNotional(b.quoteCurrency),
              step: 1e-6,
              baseAsset: b.baseAsset,
              quoteCurrency: b.quoteCurrency,
            });
            if (alloc.ok) {
              return {
                ...b,
                activePosition: {
                  entryPrice: px,
                  quantity: alloc.allocatedQty,
                  highestPrice: px,
                  stopLossPrice: 0,
                  takeProfitPrice: sellTarget,
                  openedAt: now,
                  fromExistingBalance: true,
                },
                lastCheckedAt: now,
                lastSignalSummary: `ورود با ${b.existingBalancePercent ?? 50}٪ موجودی فعلی (${alloc.allocatedQty} ${b.baseAsset}) · منتظر قیمت فروش هدف`,
              };
            }
            if (fundingMode === 'EXISTING_ASSET') {
              return {
                ...b,
                status: 'PAUSED' as const,
                lastCheckedAt: now,
                lastSignalSummary: alloc.reason || `موجودی آزاد ${b.baseAsset} کافی نیست`,
              };
            }
          }

          if (buyTarget > 0 && px <= buyTarget) {
            const qty = (b.orderAmount / px) * (1 - 0.0025);
            return {
              ...b,
              activePosition: {
                entryPrice: px,
                quantity: qty,
                highestPrice: px,
                stopLossPrice: 0,
                takeProfitPrice: sellTarget,
                openedAt: now,
              },
              lastCheckedAt: now,
              lastSignalSummary: `خرید قیمتی انجام شد · منتظر قیمت فروش هدف`,
            };
          }

          return {
            ...b,
            lastCheckedAt: now,
            lastSignalSummary: `پایش سریع نمایشی · منتظر رسیدن قیمت به محدوده خرید`,
          };
        });
        return changed ? { ...prev, bots: nextBots } : prev;
      });
    }, 2500);
    return () => clearInterval(timer);
  }, [demoMode, hasRunningFixedBots, markets]);

  const selectCoinPair = (baseAsset: string, preferredQuote?: QuoteCurrency) => {
    const m = markets.find((x) => x.baseAsset === baseAsset);
    let nextQuote = preferredQuote || selectedQuoteCurrency;
    if (m) {
      if (nextQuote === 'IRT' && !m.hasIrtMarket && m.hasUsdtMarket) nextQuote = 'USDT';
      if (nextQuote === 'USDT' && !m.hasUsdtMarket && m.hasIrtMarket) nextQuote = 'IRT';
    }
    setSelectedBaseAsset(baseAsset);
    setSelectedQuoteCurrency(nextQuote);
  };

  const handleQuoteCurrencyChange = (nextQuote: QuoteCurrency) => {
    const curMarket = markets.find((x) => x.baseAsset === selectedBaseAsset);
    if (curMarket) {
      if (nextQuote === 'IRT' && !curMarket.hasIrtMarket) {
        const fallback = markets.find((x) => x.hasIrtMarket);
        if (fallback) setSelectedBaseAsset(fallback.baseAsset);
      } else if (nextQuote === 'USDT' && !curMarket.hasUsdtMarket) {
        const fallback = markets.find((x) => x.hasUsdtMarket);
        if (fallback) setSelectedBaseAsset(fallback.baseAsset);
      }
    }
    setSelectedQuoteCurrency(nextQuote);
  };

  const handleSignIn = async () => {
    setAuthError(null);
    try {
      await loginWithGoogle();
      await refreshStatusAndKeys();
      await refreshAccount();
      await refreshBilling();
    } catch (err) {
      setAuthError(formatFirebaseAuthError(err));
    }
  };

  const handleSignOut = async () => {
    await logoutUser();
    setExecutionMode('paper');
    setAdminOverview(null);
    setDirectMessages([]);
    setUnreadDirectCount(0);
    setReferralSummary(null);
    setBots([]);
    setBotLogs([]);
    setProfitBots([]);
    setProfitBotCycles([]);
    setProfitBotLogs([]);
    setAlerts([]);
    setWatchers([]);
    setPulses([]);
    setIdeas([]);
    setBalances([]);
    setOpenOrders([]);
    setOrderHistory([]);
    setPortfolioPerformance(null);
    setActiveNotifications([]);
    setActivePulseNotifications([]);
    importedUsersOnceRef.current = false;
    if (view === 'ADMIN') setView('DASHBOARD');
    await refreshStatusAndKeys();
    await refreshAccount();
    await refreshBilling();
  };

  const handlePlaceOrder = async (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    side: 'BUY' | 'SELL';
    type: 'LIMIT' | 'MARKET';
    quantity: number;
    price?: number;
    stopLossPrice?: number;
    takeProfitPrice?: number;
    confirmLive?: boolean;
  }) => {
    if (demoMode) {
      setDemoState((prev) => {
        const next = executeDemoOrder(
          prev || createInitialDemoState(markets, usdtTomanRate),
          payload,
          markets,
          usdtTomanRate
        );
        if (next.telegram.configured && next.telegram.enabled && next.telegram.sendTradeReports) {
          return {
            ...next,
            telegram: appendDemoTelegramLog(next.telegram, {
              kind: 'TRADE',
              title: `${payload.side === 'BUY' ? 'خرید' : 'فروش'} دستی ${payload.baseAsset}${payload.quoteCurrency}`,
              preview: `سفارش ${payload.type === 'MARKET' ? 'آنی' : 'لیمیت'} به مقدار ${payload.quantity} ${payload.baseAsset} ثبت شد.`,
            }),
          };
        }
        return next;
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/orders', {
      method: 'POST',
      headers,
      body: JSON.stringify({
        ...payload,
        mode: executionMode,
        confirmLive: executionMode === 'live' ? Boolean(payload.confirmLive) : undefined,
      }),
    });
    await parseApiJson(res, 'خطا در ثبت سفارش');
    await refreshAccount();
  };

  const handleCancelOrder = async (orderId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const target = base.openOrders.find((o) => o.orderId === orderId);
        const next = cancelDemoOrder(base, orderId, markets, usdtTomanRate);
        if (
          target &&
          next.telegram.configured &&
          next.telegram.enabled &&
          next.telegram.sendTradeReports
        ) {
          return {
            ...next,
            telegram: appendDemoTelegramLog(next.telegram, {
              kind: 'TRADE',
              title: `لغو سفارش ${target.symbol}`,
              preview: `سفارش ${target.side === 'BUY' ? 'خرید' : 'فروش'} ${target.quantity} ${target.baseAsset} لغو شد.`,
            }),
          };
        }
        return next;
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(
      `/api/orders/${encodeURIComponent(orderId)}?mode=${executionMode}`,
      { method: 'DELETE', headers }
    );
    await parseApiJson(res, 'خطا در لغو سفارش');
    await refreshAccount();
  };

  const handleResetPaperWallet = async () => {
    if (demoMode) {
      handleResetDemoSandbox();
      return;
    }
    const headers = await getAuthHeaders();
    await fetch('/api/account/paper-reset', { method: 'POST', headers });
    await refreshAccount();
  };

  const handleSaveCostBasis = async (
    asset: string,
    price: number,
    quoteCurrency: QuoteCurrency
  ) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          costBasisMap: {
            ...base.costBasisMap,
            [asset]: { asset, price, quoteCurrency },
          },
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/account/cost-basis', {
      method: 'POST',
      headers,
      body: JSON.stringify({ asset, price, quoteCurrency, mode: executionMode }),
    });
    await parseApiJson(res, 'خطا در ذخیره قیمت خرید اولیه');
    await refreshAccount();
  };

  const handleResetCostBasis = async (asset: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const nextMap = { ...base.costBasisMap };
        delete nextMap[asset];
        return { ...base, costBasisMap: nextMap };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(
      `/api/account/cost-basis/${encodeURIComponent(asset)}?mode=${executionMode}`,
      { method: 'DELETE', headers }
    );
    await parseApiJson(res, 'خطا در بازنشانی قیمت خرید اولیه');
    await refreshAccount();
  };

  const handleCreateAlert = async (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    condition: PriceAlertCondition;
    targetPrice: number;
    sendTelegram?: boolean;
    note?: string;
  }) => {
    if (demoMode) {
      const m = markets.find((x) => x.baseAsset === payload.baseAsset);
      const currentPx = m
        ? payload.quoteCurrency === 'IRT'
          ? m.priceToman
          : m.priceUsdt
        : payload.targetPrice;
      const newAlert: PriceAlert = {
        id: `demo-alert-${Date.now()}`,
        baseAsset: payload.baseAsset,
        persianName: m?.persianName || payload.baseAsset,
        symbol: `${payload.baseAsset}${payload.quoteCurrency}`,
        quoteCurrency: payload.quoteCurrency,
        condition: payload.condition,
        targetPrice: payload.targetPrice,
        createdPrice: currentPx,
        status: 'ACTIVE',
        sendTelegram: payload.sendTelegram !== false,
        note: payload.note,
        createdAt: Date.now(),
      };
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return { ...base, alerts: [newAlert, ...base.alerts] };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/alerts', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ثبت هشدار قیمت');
    await refreshAlerts();
  };

  const handleRearmAlert = async (alertId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          alerts: base.alerts.map((a) =>
            a.id === alertId ? { ...a, status: 'ACTIVE', triggeredAt: undefined } : a
          ),
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/alerts/${encodeURIComponent(alertId)}/rearm`, {
      method: 'POST',
      headers,
    });
    if (!res.ok) throw new Error('خطا در فعال‌سازی مجدد هشدار');
    seenTriggeredIdsRef.current.delete(alertId);
    setActiveNotifications((prev) => prev.filter((a) => a.id !== alertId));
    await refreshAlerts();
  };

  const handleDeleteAlert = async (alertId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return { ...base, alerts: base.alerts.filter((a) => a.id !== alertId) };
      });
      return;
    }
    const headers = await getAuthHeaders();
    await fetch(`/api/alerts/${encodeURIComponent(alertId)}`, { method: 'DELETE', headers });
    setActiveNotifications((prev) => prev.filter((a) => a.id !== alertId));
    await refreshAlerts();
  };

  const handleCreateWatcher = async (payload: {
    baseAsset: string;
    quoteMode: PriceReporterQuoteMode;
    intervalMinutes: number;
    notifyBrowser: boolean;
    playSound: boolean;
    sendTelegram?: boolean;
    webhookUrl?: string;
  }) => {
    if (demoMode) {
      const m = markets.find((x) => x.baseAsset === payload.baseAsset);
      const now = Date.now();
      const newWatcher: PeriodicPriceWatcher = {
        id: `demo-watcher-${now}`,
        baseAsset: payload.baseAsset,
        persianName: m?.persianName || payload.baseAsset,
        quoteMode: payload.quoteMode,
        intervalMinutes: payload.intervalMinutes,
        status: 'ACTIVE',
        notifyBrowser: payload.notifyBrowser,
        playSound: payload.playSound,
        sendTelegram: payload.sendTelegram !== false,
        webhookUrl: payload.webhookUrl,
        lastPriceToman: m?.priceToman ?? 0,
        lastPriceUsdt: m?.priceUsdt ?? 0,
        lastSentAt: now,
        nextSendAt: now + payload.intervalMinutes * 60_000,
        sentCount: 1,
        createdAt: now,
      };
      const newPulse: PricePulseNotification = {
        id: `demo-pulse-${now}`,
        watcherId: newWatcher.id,
        baseAsset: payload.baseAsset,
        persianName: m?.persianName || payload.baseAsset,
        quoteMode: payload.quoteMode,
        intervalMinutes: payload.intervalMinutes,
        priceToman: m?.priceToman ?? 0,
        priceUsdt: m?.priceUsdt ?? 0,
        change24hPercent: m?.change24hPercent ?? 0,
        sentAt: now,
      };
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          watchers: [newWatcher, ...base.watchers],
          pulses: [newPulse, ...base.pulses],
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/features/watchers', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ثبت ارسال دوره‌ای قیمت');
    await refreshWatchers();
  };

  const handleToggleWatcherStatus = async (
    watcherId: string,
    status: 'ACTIVE' | 'PAUSED'
  ) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          watchers: base.watchers.map((w) => (w.id === watcherId ? { ...w, status } : w)),
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/features/watchers/${encodeURIComponent(watcherId)}/status`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ status }),
    });
    await parseApiJson(res, 'خطا در تغییر وضعیت ارسال دوره‌ای');
    await refreshWatchers();
  };

  const handleSendWatcherNow = async (watcherId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const target = base.watchers.find((w) => w.id === watcherId);
        if (!target) return base;
        const m = markets.find((x) => x.baseAsset === target.baseAsset);
        const now = Date.now();
        const pulse: PricePulseNotification = {
          id: `demo-pulse-${now}`,
          watcherId: target.id,
          baseAsset: target.baseAsset,
          persianName: target.persianName,
          quoteMode: target.quoteMode,
          intervalMinutes: target.intervalMinutes,
          priceToman: m?.priceToman ?? target.lastPriceToman ?? 0,
          priceUsdt: m?.priceUsdt ?? target.lastPriceUsdt ?? 0,
          change24hPercent: m?.change24hPercent ?? 0,
          sentAt: now,
        };
        return {
          ...base,
          watchers: base.watchers.map((w) =>
            w.id === watcherId
              ? {
                  ...w,
                  sentCount: w.sentCount + 1,
                  lastSentAt: now,
                  lastPriceToman: pulse.priceToman,
                  lastPriceUsdt: pulse.priceUsdt,
                }
              : w
          ),
          pulses: [pulse, ...base.pulses],
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/features/watchers/${encodeURIComponent(watcherId)}/send-now`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'ارسال فوری قیمت ناموفق بود');
    await refreshWatchers();
  };

  const handleDeleteWatcher = async (watcherId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          watchers: base.watchers.filter((w) => w.id !== watcherId),
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    await fetch(`/api/features/watchers/${encodeURIComponent(watcherId)}`, {
      method: 'DELETE',
      headers,
    });
    setActivePulseNotifications((prev) => prev.filter((p) => p.watcherId !== watcherId));
    await refreshWatchers();
  };

  const handleCreateIdea = async (payload: {
    title: string;
    description: string;
    category: FeatureIdeaCategory;
  }) => {
    if (demoMode) {
      const newIdea: FeatureIdeaItem = {
        id: `demo-idea-${Date.now()}`,
        title: payload.title,
        description: payload.description,
        category: payload.category,
        status: 'IDEA',
        createdAt: Date.now(),
      };
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return { ...base, ideas: [newIdea, ...base.ideas] };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/features/ideas', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ثبت ایده');
    await refreshIdeas();
  };

  const handleUpdateIdeaStatus = async (ideaId: string, status: FeatureIdeaStatus) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          ideas: base.ideas.map((i) => (i.id === ideaId ? { ...i, status } : i)),
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/features/ideas/${encodeURIComponent(ideaId)}/status`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ status }),
    });
    if (!res.ok) throw new Error('خطا در تغییر وضعیت ایده');
    await refreshIdeas();
  };

  const handleDeleteIdea = async (ideaId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return { ...base, ideas: base.ideas.filter((i) => i.id !== ideaId) };
      });
      return;
    }
    const headers = await getAuthHeaders();
    await fetch(`/api/features/ideas/${encodeURIComponent(ideaId)}`, {
      method: 'DELETE',
      headers,
    });
    await refreshIdeas();
  };

  const handleSaveTelegramConfig = async (payload: {
    botToken?: string;
    chatId: string;
    enabled: boolean;
    sendPriceAlerts: boolean;
    sendPeriodicWatchers: boolean;
    sendTradeReports?: boolean;
    sendBotTrades?: boolean;
    sendBotMonitoring?: boolean;
    botMonitorMode?: BotMonitoringTelegramMode;
    botMonitorIntervalMinutes?: number;
  }) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          telegram: {
            ...base.telegram,
            configured: true,
            chatId: payload.chatId,
            enabled: payload.enabled,
            sendPriceAlerts: payload.sendPriceAlerts,
            sendPeriodicWatchers: payload.sendPeriodicWatchers,
            sendTradeReports: payload.sendTradeReports ?? base.telegram.sendTradeReports,
            sendBotTrades: payload.sendBotTrades ?? base.telegram.sendBotTrades,
            sendBotMonitoring: payload.sendBotMonitoring ?? base.telegram.sendBotMonitoring,
            botMonitorMode: payload.botMonitorMode ?? base.telegram.botMonitorMode,
            botMonitorIntervalMinutes:
              payload.botMonitorIntervalMinutes ?? base.telegram.botMonitorIntervalMinutes,
            updatedAt: Date.now(),
          },
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/features/telegram', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    const data = await parseApiJson<{ telegram?: TelegramBotSummary }>(
      res,
      'خطا در ذخیره تنظیمات ربات تلگرام'
    );
    if (data.telegram) setTelegram(data.telegram);
  };

  const handleDetectTelegramChats = async (botToken?: string) => {
    if (demoMode) {
      return [
        {
          chatId: '184920311',
          title: 'چت شخصی پیش‌نمایش (حالت دمو)',
          username: 'AliDemoUser',
          type: 'private',
        },
      ];
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/features/telegram/detect-chat', {
      method: 'POST',
      headers,
      body: JSON.stringify({ botToken }),
    });
    const data = await parseApiJson<{ chats?: TelegramDiscoveredChat[] }>(
      res,
      'خطا در دریافت لیست چت‌های تلگرام'
    );
    return (data.chats || []) as TelegramDiscoveredChat[];
  };

  const handleSendTelegramTest = async (botToken?: string, chatId?: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          telegram: appendDemoTelegramLog(base.telegram, {
            kind: 'TEST',
            title: 'پیام آزمایشی ربات تلگرام',
            preview: 'تست اتصال و دریافت گزارش‌های خرید و فروش و پایش ربات در حالت نمایشی.',
          }),
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/features/telegram/test', {
      method: 'POST',
      headers,
      body: JSON.stringify({ botToken, chatId }),
    });
    const data = await parseApiJson<{ telegram?: TelegramBotSummary }>(
      res,
      'ارسال پیام تست به تلگرام ناموفق بود'
    );
    if (data.telegram) setTelegram(data.telegram);
  };

  const handleUpdateTelegramPreferences = async (payload: {
    enabled?: boolean;
    sendPriceAlerts?: boolean;
    sendPeriodicWatchers?: boolean;
    sendTradeReports?: boolean;
    sendBotTrades?: boolean;
    sendBotMonitoring?: boolean;
    botMonitorMode?: BotMonitoringTelegramMode;
    botMonitorIntervalMinutes?: number;
  }) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          telegram: {
            ...base.telegram,
            ...payload,
            updatedAt: Date.now(),
          },
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/features/telegram/preferences', {
      method: 'PATCH',
      headers,
      body: JSON.stringify(payload),
    });
    const data = await parseApiJson<{ telegram?: TelegramBotSummary }>(
      res,
      'خطا در به‌روزرسانی تنظیمات تلگرام'
    );
    if (data.telegram) setTelegram(data.telegram);
  };

  const handleDisconnectTelegram = async () => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          telegram: {
            configured: false,
            enabled: false,
            maskedBotToken: '',
            botUsername: '',
            botFirstName: '',
            chatId: '',
            sendPriceAlerts: true,
            sendPeriodicWatchers: true,
            sendTradeReports: true,
            sendBotTrades: true,
            sendBotMonitoring: true,
            botMonitorMode: 'EVENTS_AND_STATUS',
            botMonitorIntervalMinutes: 15,
            updatedAt: null,
            lastSentAt: null,
            lastBotMonitorSentAt: null,
            lastError: null,
            recentLogs: [],
          },
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch('/api/features/telegram', { method: 'DELETE', headers });
    const data = await parseApiJson<{ telegram?: TelegramBotSummary }>(
      res,
      'خطا در قطع اتصال ربات تلگرام'
    );
    if (data.telegram) setTelegram(data.telegram);
  };

  const handleSendTelegramReport = async (
    kind: TelegramManualReportKind,
    botId?: string
  ): Promise<{ title?: string; preview?: string }> => {
    if (demoMode) {
      const base = demoState || createInitialDemoState(markets, usdtTomanRate);
      if (!base.telegram.configured) {
        throw new Error('ابتدا در بخش امکانات ← ربات تلگرام، توکن ربات و Chat ID را ثبت کنید.');
      }
      const targetBot = botId ? base.bots.find((b) => b.id === botId) : null;
      const singleBotPnl = targetBot
        ? calculateDemoBotRealizedPnlMetrics(targetBot, usdtTomanRate)
        : null;
      const botsAggregatePnl = (() => {
        if (base.bots.length === 0) return '0 تومان ($0.00 تتر) · 0.00%';
        const tomanSum = base.bots.reduce(
          (acc, b) => acc + calculateDemoBotRealizedPnlMetrics(b, usdtTomanRate).toman,
          0
        );
        const capSum = base.bots.reduce(
          (acc, b) =>
            acc + (b.quoteCurrency === 'IRT' ? b.orderAmount : b.orderAmount * (usdtTomanRate || 79_500)),
          0
        );
        const pct = capSum > 0 ? (tomanSum / capSum) * 100 : 0;
        const rate = usdtTomanRate || 79_500;
        const usdtSum = rate > 0 ? tomanSum / rate : 0;
        return `${tomanSum >= 0 ? '+' : '-'}${Math.abs(Math.round(tomanSum)).toLocaleString('en-US')} تومان (${usdtSum >= 0 ? '+' : '-'}$${Math.abs(usdtSum).toFixed(2)} تتر) · ${pct >= 0 ? '+' : ''}${pct.toFixed(2)}%`;
      })();
      const title =
        kind === 'TRADES'
          ? 'گزارش خرید و فروش‌ها (دستی)'
          : kind === 'BOTS_MONITOR'
            ? 'گزارش پایش همه ربات‌ها'
            : kind === 'PORTFOLIO'
              ? 'گزارش کیف پول و پرتفوی'
              : kind === 'SINGLE_BOT'
                ? `گزارش ربات ${targetBot?.name || ''}`
                : 'گزارش جامع کامل';
      const preview =
        kind === 'TRADES'
          ? `${base.openOrders.length} سفارش باز و ${base.orderHistory.length} معامله اخیر ارسال شد.`
          : kind === 'BOTS_MONITOR'
            ? `وضعیت ${base.bots.length} ربات (${base.bots.filter((b) => b.status === 'RUNNING').length} فعال) · Realized PnL کل: ${botsAggregatePnl}`
            : kind === 'PORTFOLIO'
              ? `موجودی ${base.balances.length} دارایی و ارزش کل پرتفوی ارسال شد.`
              : kind === 'SINGLE_BOT'
                ? `${targetBot?.symbol || ''} · Realized PnL: ${singleBotPnl?.formattedText || '0.00%'}`
                : `خلاصه سبد، سفارش‌ها و ربات‌ها · Realized PnL ربات‌ها: ${botsAggregatePnl}`;

      const logKind =
        kind === 'BOTS_MONITOR' || kind === 'SINGLE_BOT' ? 'BOT_MONITOR' : 'MANUAL_REPORT';
      setDemoState((prev) => {
        const cur = prev || createInitialDemoState(markets, usdtTomanRate);
        const nextTg = appendDemoTelegramLog(cur.telegram, {
          kind: logKind,
          title,
          preview,
        });
        if (logKind === 'BOT_MONITOR') {
          nextTg.lastBotMonitorSentAt = Date.now();
        }
        return { ...cur, telegram: nextTg };
      });
      return { title, preview };
    }

    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/features/telegram/send-report', {
      method: 'POST',
      headers,
      body: JSON.stringify({ kind, botId, mode: executionMode }),
    });
    const data = await parseApiJson<{
      telegram?: TelegramBotSummary;
      title?: string;
      preview?: string;
    }>(res, 'ارسال گزارش به ربات تلگرام ناموفق بود');
    if (data.telegram) setTelegram(data.telegram);
    return { title: String(data.title || ''), preview: String(data.preview || '') };
  };

  const handleCreateBot = async (payload: Record<string, unknown>) => {
    if (demoMode) {
      const now = Date.now();
      const baseAsset = String(payload.baseAsset || 'BTC').toUpperCase();
      const quoteCurrency: QuoteCurrency = payload.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
      const status = payload.status === 'PAUSED' ? 'PAUSED' : 'RUNNING';
      const notifyTelegram = payload.notifyTelegram !== false;
      const isFixed =
        payload.strategyKind === 'FIXED_PRICE' ||
        (Array.isArray(payload.entryRules) &&
          (payload.entryRules as BotStrategyConfig['entryRules']).some(
            (r) => r.type === 'FIXED_BUY_PRICE'
          ));
      const newBot: BotStrategyConfig = {
        id: `demo-bot-${now}`,
        name: String(payload.name || `ربات ${baseAsset}`),
        strategyKind: isFixed ? 'FIXED_PRICE' : 'INDICATOR',
        targetBuyPrice: isFixed ? Number(payload.targetBuyPrice || 0) : undefined,
        targetSellPrice: isFixed ? Number(payload.targetSellPrice || 0) : undefined,
        repeatCycle: isFixed ? payload.repeatCycle !== false : undefined,
        maxCycles:
          isFixed && typeof payload.maxCycles === 'number' ? payload.maxCycles : null,
        pollIntervalSeconds: isFixed ? Number(payload.pollIntervalSeconds || 5) : undefined,
        fundingMode:
          payload.fundingMode === 'EXISTING_ASSET' || payload.fundingMode === 'AUTO_PREFER_EXISTING'
            ? (payload.fundingMode as BotFundingMode)
            : 'QUOTE_BUY',
        existingBalancePercent: Number(payload.existingBalancePercent ?? 50),
        baseAsset,
        quoteCurrency,
        symbol: String(payload.symbol || `${baseAsset}${quoteCurrency}`),
        timeframe: (payload.timeframe as Timeframe) || '15m',
        mode: 'paper',
        status,
        orderAmount:
          payload.fundingMode === 'EXISTING_ASSET'
            ? Number(payload.orderAmount || 0)
            : Number(payload.orderAmount) || 10_000_000,
        stopLossPercent: isFixed ? 0 : Number(payload.stopLossPercent) || 3,
        takeProfitPercent: isFixed ? 0 : Number(payload.takeProfitPercent) || 6,
        trailingStopEnabled: isFixed ? false : Boolean(payload.trailingStopEnabled),
        trailingStopPercent: Number(payload.trailingStopPercent) || 1.5,
        trailingTakeProfitEnabled: isFixed ? false : Boolean(payload.trailingTakeProfitEnabled),
        trailingTakeProfitActivationPercent:
          Number(payload.trailingTakeProfitActivationPercent) || 2.5,
        trailingTakeProfitCallbackPercent:
          Number(payload.trailingTakeProfitCallbackPercent) || 0.8,
        takeProfitTargets: Array.isArray(payload.takeProfitTargets)
          ? (payload.takeProfitTargets as TakeProfitTarget[])
          : undefined,
        keepRunnerPercent: Number(payload.keepRunnerPercent || 0),
        strategyStyle: (payload.strategyStyle as StrategyStyleMode) || 'MEDIUM_TERM',
        volumeConfirmationEnabled: Boolean(payload.volumeConfirmationEnabled ?? payload.requireVolumeConfirmation),
        volatilityFilterEnabled: Boolean(payload.volatilityFilterEnabled ?? true),
        volatilityFilterMaxAtrPercent:
          payload.volatilityFilterMaxAtrPercent !== undefined
            ? Number(payload.volatilityFilterMaxAtrPercent)
            : Number(payload.volatilityFilterPercent ?? 8),
        minSignalScore: Number(payload.minSignalScore || 1),
        executionConfirmationMode:
          (payload.executionConfirmationMode as BotExecutionConfirmationMode) || 'AUTO',
        cooldownMinutes: isFixed ? 0 : Number(payload.cooldownMinutes) || 15,
        logicOperator: payload.logicOperator === 'OR' ? 'OR' : 'AND',
        entryRules: Array.isArray(payload.entryRules)
          ? (payload.entryRules as BotStrategyConfig['entryRules'])
          : [],
        exitRules: Array.isArray(payload.exitRules)
          ? (payload.exitRules as BotStrategyConfig['exitRules'])
          : [],
        activePosition: null,
        stats: { totalTrades: 0, winningTrades: 0, losingTrades: 0, realizedPnl: 0 },
        lastCheckedAt: now,
        lastSignalSummary:
          status === 'RUNNING'
            ? isFixed
              ? `ربات قیمتی فعال شد و هر ${Number(payload.pollIntervalSeconds || 5)} ثانیه بازار نوبیتکس را رصد می‌کند`
              : 'ربات آزمایشی فعال شد و کندل‌های نوبیتکس را رصد می‌کند'
            : 'ذخیره در حالت نمایشی',
        notifyTelegram,
        createdAt: now,
      };
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const shouldNotify =
          notifyTelegram &&
          base.telegram.configured &&
          base.telegram.enabled &&
          base.telegram.sendBotMonitoring &&
          base.telegram.botMonitorMode !== 'MANUAL_ONLY';
        return {
          ...base,
          bots: [newBot, ...base.bots],
          telegram: shouldNotify
            ? appendDemoTelegramLog(base.telegram, {
                kind: 'BOT_EVENT',
                title: `ساخت ربات جدید: ${newBot.name}`,
                preview: `نماد ${newBot.symbol} (${newBot.timeframe}) · وضعیت: ${status === 'RUNNING' ? 'فعال' : 'متوقف'}`,
              })
            : base.telegram,
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/bots', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ساخت ربات');
    await refreshBots();
  };

  const handleUpdateBotFixedTargets = async (
    botId: string,
    updates: {
      targetBuyPrice?: number;
      targetSellPrice: number;
      orderAmount?: number;
      repeatCycle?: boolean;
      maxCycles?: number | null;
      pollIntervalSeconds?: number;
      fundingMode?: BotFundingMode;
      existingBalancePercent?: number;
    }
  ) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          bots: base.bots.map((b) =>
            b.id === botId
              ? {
                  ...b,
                  targetBuyPrice:
                    updates.targetBuyPrice !== undefined ? updates.targetBuyPrice : b.targetBuyPrice,
                  targetSellPrice: updates.targetSellPrice,
                  orderAmount: updates.orderAmount ?? b.orderAmount,
                  repeatCycle:
                    updates.repeatCycle !== undefined ? updates.repeatCycle : b.repeatCycle,
                  maxCycles:
                    updates.maxCycles !== undefined ? updates.maxCycles : b.maxCycles,
                  pollIntervalSeconds:
                    updates.pollIntervalSeconds ?? b.pollIntervalSeconds ?? 5,
                  fundingMode: updates.fundingMode ?? b.fundingMode,
                  existingBalancePercent:
                    updates.existingBalancePercent ?? b.existingBalancePercent,
                  lastSignalSummary: 'تنظیمات ربات قیمتی در حالت نمایشی به‌روزرسانی شد',
                }
              : b
          ),
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/bots/${encodeURIComponent(botId)}/fixed-targets`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify(updates),
    });
    await parseApiJson(res, 'خطا در ویرایش قیمت‌های هدف');
    await refreshBots();
  };

  const handleToggleBotStatus = async (botId: string, nextStatus: 'RUNNING' | 'PAUSED') => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const target = base.bots.find((b) => b.id === botId);
        const shouldNotify =
          target &&
          target.notifyTelegram !== false &&
          base.telegram.configured &&
          base.telegram.enabled &&
          base.telegram.sendBotMonitoring &&
          base.telegram.botMonitorMode !== 'MANUAL_ONLY';
        return {
          ...base,
          bots: base.bots.map((b) =>
            b.id === botId
              ? {
                  ...b,
                  status: nextStatus,
                  lastCheckedAt: Date.now(),
                  lastSignalSummary:
                    nextStatus === 'RUNNING'
                      ? 'فعال‌سازی در حالت نمایشی'
                      : 'توقف موقت در حالت نمایشی',
                }
              : b
          ),
          telegram: shouldNotify
            ? appendDemoTelegramLog(base.telegram, {
                kind: 'BOT_EVENT',
                title: `${nextStatus === 'RUNNING' ? 'شروع' : 'توقف'} ربات: ${target.name}`,
                preview: `وضعیت ربات ${target.symbol} تغییر یافت.`,
              })
            : base.telegram,
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/bots/${encodeURIComponent(botId)}/status`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ status: nextStatus }),
    });
    await parseApiJson(res, 'خطا در تغییر وضعیت ربات');
    await refreshBots();
    await refreshAccount();
  };

  const handleToggleBotMode = async (
    botId: string,
    nextMode: ExecutionMode,
    confirmLive?: boolean
  ) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          bots: base.bots.map((b) => (b.id === botId ? { ...b, mode: nextMode } : b)),
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/bots/${encodeURIComponent(botId)}/mode`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({
        mode: nextMode,
        confirmLive: nextMode === 'live' ? Boolean(confirmLive) : undefined,
      }),
    });
    await parseApiJson(res, 'خطا در تغییر حالت ربات');
    await refreshBots();
  };

  const handleToggleBotTelegram = async (botId: string, notifyTelegram: boolean) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          bots: base.bots.map((b) => (b.id === botId ? { ...b, notifyTelegram } : b)),
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/bots/${encodeURIComponent(botId)}/telegram`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify({ notifyTelegram }),
    });
    await parseApiJson(res, 'خطا در تغییر تنظیمات تلگرام ربات');
    await refreshBots();
  };

  const handleEvaluateBotNow = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const target = base.bots.find((b) => b.id === botId);
        if (!target) return base;
        const m = markets.find((x) => x.baseAsset === target.baseAsset);
        const px = target.quoteCurrency === 'IRT' ? m?.priceToman ?? 0 : m?.priceUsdt ?? 0;
        const now = Date.now();
        const newLog: BotExecutionLog = {
          id: `demo-log-${now}`,
          botId: target.id,
          botName: target.name,
          symbol: target.symbol,
          quoteCurrency: target.quoteCurrency,
          event: 'INFO',
          price: px,
          mode: 'paper',
          message: 'ارزیابی فوری نمایشی انجام شد · اندیکاتورها در وضعیت پایش عادی هستند.',
          timestamp: now,
        };
        const shouldNotify =
          target.notifyTelegram !== false &&
          base.telegram.configured &&
          base.telegram.enabled &&
          base.telegram.sendBotMonitoring &&
          base.telegram.botMonitorMode !== 'MANUAL_ONLY';
        return {
          ...base,
          bots: base.bots.map((b) =>
            b.id === botId
              ? { ...b, lastCheckedAt: now, lastSignalSummary: 'آخرین پایش فوری موفق (حالت نمایشی)' }
              : b
          ),
          botLogs: [newLog, ...base.botLogs],
          telegram: shouldNotify
            ? appendDemoTelegramLog(base.telegram, {
                kind: 'BOT_MONITOR',
                title: `پایش فوری ربات: ${target.name}`,
                preview: `${target.symbol} · ارزیابی فوری اندیکاتورها در وضعیت پایش عادی`,
              })
            : base.telegram,
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/bots/${encodeURIComponent(botId)}/evaluate`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در ارزیابی فوری ربات');
    await refreshBots();
    await refreshAccount();
  };

  const handleDeleteBot = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const target = base.bots.find((b) => b.id === botId);
        const shouldNotify =
          target &&
          target.notifyTelegram !== false &&
          base.telegram.configured &&
          base.telegram.enabled &&
          base.telegram.sendBotMonitoring &&
          base.telegram.botMonitorMode !== 'MANUAL_ONLY';
        return {
          ...base,
          bots: base.bots.filter((b) => b.id !== botId),
          telegram: shouldNotify
            ? appendDemoTelegramLog(base.telegram, {
                kind: 'BOT_EVENT',
                title: `حذف ربات: ${target.name}`,
                preview: `ربات ${target.symbol} حذف شد.`,
              })
            : base.telegram,
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    await fetch(`/api/bots/${encodeURIComponent(botId)}`, {
      method: 'DELETE',
      headers,
    });
    await refreshBots();
  };

  const handleRunBacktest = async (payload: Record<string, unknown>): Promise<BacktestResult> => {
    if (demoMode) {
      if (payload.botType === 'GRID' || payload.botType === 'DCA') {
        return runDemoExtendedBacktest(
          candles,
          payload as Parameters<typeof runDemoExtendedBacktest>[1]
        );
      }
      return computeDemoBacktest(payload, candles, markets, usdtTomanRate);
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/bots/backtest', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    return parseApiJson<BacktestResult>(res, 'خطا در اجرای بک‌تست');
  };

  // =========================================================================
  // Profit Bot (ربات سود خالص مستقل) Handlers
  // =========================================================================
  const handleFetchProfitBotPreview = async (params: {
    symbol: string;
    entryAmount: number;
    targetNetProfit: number;
    feeRate: number;
    otherFeesQuote: number;
    fundingMode?: BotFundingMode;
    existingQty?: number;
    existingBalancePercent?: number;
    existingEntryPrice?: number | null;
  }): Promise<ProfitBotMarketPreview> => {
    if (demoMode || !auth.currentUser) {
      const res = await fetch(
        `/api/market/depth?symbol=${encodeURIComponent(params.symbol)}&limit=40`
      );
      const book = (await parseApiJson<OrderBookSnapshot>(res, 'خطا در دریافت دفتر سفارش')) as OrderBookSnapshot;
      return buildProfitBotMarketPreview(
        book,
        params.entryAmount,
        params.targetNetProfit,
        params.feeRate,
        params.otherFeesQuote,
        {
          fundingMode: params.fundingMode,
          freeBaseBalance: params.existingQty,
          existingBalancePercent: params.existingBalancePercent,
          existingEntryPrice: params.existingEntryPrice,
        }
      );
    }
    const headers = await getAuthHeaders();
    const qs = new URLSearchParams({
      symbol: params.symbol,
      entryAmount: String(params.entryAmount),
      targetNetProfit: String(params.targetNetProfit),
      feeRate: String(params.feeRate),
      otherFeesQuote: String(params.otherFeesQuote),
    });
    if (params.fundingMode) qs.set('fundingMode', params.fundingMode);
    if (params.existingQty !== undefined) qs.set('existingQty', String(params.existingQty));
    if (params.existingBalancePercent !== undefined) {
      qs.set('existingBalancePercent', String(params.existingBalancePercent));
    }
    if (params.existingEntryPrice && params.existingEntryPrice > 0) {
      qs.set('existingEntryPrice', String(params.existingEntryPrice));
    }
    const res = await fetch(`/api/profit-bots/preview?${qs.toString()}`, { headers });
    return parseApiJson<ProfitBotMarketPreview>(res, 'خطا در دریافت پیش‌نمایش ربات سود');
  };

  const handleCreateProfitBot = async (payload: Record<string, unknown>) => {
    if (demoMode) {
      const now = Date.now();
      const baseAsset = String(payload.baseAsset || 'BTC').toUpperCase();
      const quoteCurrency: QuoteCurrency = payload.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
      const fundingMode: BotFundingMode =
        payload.fundingMode === 'EXISTING_ASSET' || payload.fundingMode === 'AUTO_PREFER_EXISTING'
          ? (payload.fundingMode as BotFundingMode)
          : 'QUOTE_BUY';
      const existingBalancePercent = Math.min(
        100,
        Math.max(1, Number(payload.existingBalancePercent ?? 50))
      );
      const existingEntryPrice =
        payload.existingEntryPrice && Number(payload.existingEntryPrice) > 0
          ? Number(payload.existingEntryPrice)
          : null;
      const entryAmount =
        fundingMode === 'EXISTING_ASSET'
          ? Number(payload.entryAmount || 0)
          : Number(payload.entryAmount || (quoteCurrency === 'IRT' ? 10_000_000 : 100));
      const targetNetProfit = Number(
        payload.targetNetProfit || (quoteCurrency === 'IRT' ? 100_000 : 5)
      );
      const feeRate = Number(payload.feeRate ?? DEFAULT_NOBITEX_FEE_RATE);
      const otherFeesQuote = Number(payload.otherFeesQuote ?? 0);
      const startImmediately = Boolean(payload.startImmediately);
      const symbol = String(payload.symbol || `${baseAsset}${quoteCurrency}`);
      const todayKey = new Date(now).toISOString().slice(0, 10);

      let newBot: ProfitBotConfig = {
        id: `demo-pbot-${now}`,
        name: String(payload.name || `ربات سود ${baseAsset}/${quoteCurrency}`),
        baseAsset,
        quoteCurrency,
        symbol,
        mode: 'paper',
        isActive: startImmediately,
        botStatus: startImmediately ? 'CHECKING_MARKET' : 'READY_TO_BUY',
        fundingMode,
        existingBalancePercent,
        existingEntryPrice,
        entryAmount,
        targetNetProfit,
        pollIntervalSeconds: Number(payload.pollIntervalSeconds || 10),
        maxWaitMinutes:
          payload.maxWaitMinutes === null || payload.maxWaitMinutes === undefined
            ? null
            : Number(payload.maxWaitMinutes),
        stopLossEnabled: Boolean(payload.stopLossEnabled),
        stopLossPercent: Number(payload.stopLossPercent || 3),
        stopLossAction: (payload.stopLossAction as ProfitBotStopLossAction) || 'STOP_AND_SELL',
        maxCapitalInvolved: Number(payload.maxCapitalInvolved || entryAmount * 2 || (quoteCurrency === 'IRT' ? 20_000_000 : 200)),
        maxDailyTrades: Number(payload.maxDailyTrades || 10),
        maxDailyLoss: Number(
          payload.maxDailyLoss ?? (quoteCurrency === 'IRT' ? 500_000 : 15)
        ),
        orderType: (payload.orderType as ProfitBotOrderType) || 'MARKET',
        maxSlippagePercent: Number(payload.maxSlippagePercent || 0.5),
        maxSpreadPercent: Number(payload.maxSpreadPercent || 2.5),
        limitOrderTimeoutSeconds: Number(payload.limitOrderTimeoutSeconds || 120),
        limitUnfilledPolicy:
          (payload.limitUnfilledPolicy as ProfitBotLimitUnfilledPolicy) || 'KEEP_WAITING',
        sequenceMode: (payload.sequenceMode as ProfitBotSequenceMode) || 'CYCLE_REPEAT',
        reentryTargetPrice:
          payload.reentryTargetPrice && Number(payload.reentryTargetPrice) > 0
            ? Number(payload.reentryTargetPrice)
            : null,
        reentryPolicy:
          (payload.reentryPolicy as ProfitBotReentryPolicy) || 'WAIT_ENTRY_PRICE',
        waitEntryPriceOnFirstBuy: Boolean(payload.waitEntryPriceOnFirstBuy),
        targetSellPrice:
          payload.targetSellPrice && Number(payload.targetSellPrice) > 0
            ? Number(payload.targetSellPrice)
            : null,
        feeRate,
        otherFeesQuote,
        executionConfirmationMode:
          (payload.executionConfirmationMode as BotExecutionConfirmationMode) || 'AUTO',
        trailingTakeProfitEnabled: Boolean(payload.trailingTakeProfitEnabled),
        trailingTakeProfitActivationPercent:
          payload.trailingTakeProfitActivationPercent !== undefined
            ? Number(payload.trailingTakeProfitActivationPercent)
            : 2.5,
        trailingTakeProfitCallbackPercent:
          Number(payload.trailingTakeProfitCallbackPercent || 0.8),
        keepRunnerPercent: Number(payload.keepRunnerPercent || 0),
        takeProfitTargets: Array.isArray(payload.takeProfitTargets)
          ? (payload.takeProfitTargets as TakeProfitTarget[])
          : undefined,
        notifyTelegram: payload.notifyTelegram !== false,
        activePosition: null,
        pendingOrder: null,
        dailyStats: { dateKey: todayKey, tradesCount: 0, lossQuote: 0, netProfitQuote: 0 },
        stats: {
          completedCycles: 0,
          winningCycles: 0,
          losingCycles: 0,
          totalNetProfitQuote: 0,
          totalFeesPaidQuote: 0,
          currentCapitalInvolved: 0,
          lastBuyPrice: null,
        },
        lastStatusReason: startImmediately
          ? fundingMode === 'EXISTING_ASSET'
            ? `ربات سود فعال شد و از ${existingBalancePercent}٪ موجودی فعلی ${baseAsset} استفاده می‌کند.`
            : 'ربات سود در حالت دمو فعال شد و در حال خرید و بررسی دفتر سفارش نوبیتکس است.'
          : 'ربات سود ذخیره شد و آماده شروع است.',
        lastError: null,
        lastCheckedAt: now,
        startedAt: startImmediately ? now : null,
        createdAt: now,
        updatedAt: now,
      };

      const addedLogs: ProfitBotDecisionLog[] = [];
      if (startImmediately) {
        try {
          const depthRes = await fetch(
            `/api/market/depth?symbol=${encodeURIComponent(symbol)}&limit=30`
          );
          if (depthRes.ok) {
            const book = (await depthRes.json()) as OrderBookSnapshot;
            const evalRes = evaluateDemoProfitBot(newBot, book, Date.now(), effectiveBalances);
            newBot = evalRes.bot;
            addedLogs.push(...evalRes.newLogs);
          }
        } catch {
          // Keep CHECKING_MARKET
        }
      }

      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          profitBots: [newBot, ...base.profitBots],
          profitBotLogs: [...addedLogs, ...base.profitBotLogs].slice(0, 120),
        };
      });
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/profit-bots', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ایجاد ربات سود');
    await refreshProfitBots();
  };

  const handleUpdateProfitBot = async (botId: string, payload: Record<string, unknown>) => {
    if (demoMode) {
      const now = Date.now();
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          profitBots: base.profitBots.map((b) =>
            b.id === botId
              ? {
                  ...b,
                  name: typeof payload.name === 'string' ? payload.name : b.name,
                  entryAmount: Number(payload.entryAmount ?? b.entryAmount),
                  targetNetProfit: Number(payload.targetNetProfit ?? b.targetNetProfit),
                  pollIntervalSeconds: Number(payload.pollIntervalSeconds ?? b.pollIntervalSeconds),
                  maxWaitMinutes:
                    payload.maxWaitMinutes === undefined
                      ? b.maxWaitMinutes
                      : (payload.maxWaitMinutes as number | null),
                  stopLossEnabled:
                    typeof payload.stopLossEnabled === 'boolean'
                      ? payload.stopLossEnabled
                      : b.stopLossEnabled,
                  stopLossPercent: Number(payload.stopLossPercent ?? b.stopLossPercent),
                  stopLossAction:
                    (payload.stopLossAction as ProfitBotStopLossAction) ?? b.stopLossAction,
                  maxCapitalInvolved: Number(payload.maxCapitalInvolved ?? b.maxCapitalInvolved),
                  maxDailyTrades: Number(payload.maxDailyTrades ?? b.maxDailyTrades),
                  maxDailyLoss: Number(payload.maxDailyLoss ?? b.maxDailyLoss),
                  orderType: (payload.orderType as ProfitBotOrderType) ?? b.orderType,
                  maxSlippagePercent: Number(payload.maxSlippagePercent ?? b.maxSlippagePercent),
                  maxSpreadPercent: Number(payload.maxSpreadPercent ?? b.maxSpreadPercent),
                  limitOrderTimeoutSeconds: Number(
                    payload.limitOrderTimeoutSeconds ?? b.limitOrderTimeoutSeconds
                  ),
                  limitUnfilledPolicy:
                    (payload.limitUnfilledPolicy as ProfitBotLimitUnfilledPolicy) ??
                    b.limitUnfilledPolicy,
                  sequenceMode: (payload.sequenceMode as ProfitBotSequenceMode) ?? b.sequenceMode,
                  reentryTargetPrice:
                    payload.reentryTargetPrice === undefined
                      ? b.reentryTargetPrice
                      : payload.reentryTargetPrice && Number(payload.reentryTargetPrice) > 0
                        ? Number(payload.reentryTargetPrice)
                        : null,
                  reentryPolicy:
                    (payload.reentryPolicy as ProfitBotReentryPolicy) ??
                    b.reentryPolicy ??
                    'WAIT_ENTRY_PRICE',
                  waitEntryPriceOnFirstBuy:
                    typeof payload.waitEntryPriceOnFirstBuy === 'boolean'
                      ? payload.waitEntryPriceOnFirstBuy
                      : b.waitEntryPriceOnFirstBuy,
                  targetSellPrice:
                    payload.targetSellPrice === undefined
                      ? b.targetSellPrice
                      : payload.targetSellPrice && Number(payload.targetSellPrice) > 0
                        ? Number(payload.targetSellPrice)
                        : null,
                  fundingMode:
                    payload.fundingMode === undefined
                      ? b.fundingMode
                      : (payload.fundingMode as BotFundingMode),
                  existingBalancePercent:
                    payload.existingBalancePercent === undefined
                      ? b.existingBalancePercent
                      : Math.min(100, Math.max(1, Number(payload.existingBalancePercent))),
                  existingEntryPrice:
                    payload.existingEntryPrice === undefined
                      ? b.existingEntryPrice
                      : payload.existingEntryPrice && Number(payload.existingEntryPrice) > 0
                        ? Number(payload.existingEntryPrice)
                        : null,
                  feeRate: Number(payload.feeRate ?? b.feeRate),
                  otherFeesQuote: Number(payload.otherFeesQuote ?? b.otherFeesQuote),
                  notifyTelegram:
                    typeof payload.notifyTelegram === 'boolean'
                      ? payload.notifyTelegram
                      : b.notifyTelegram,
                  updatedAt: now,
                  lastStatusReason: 'تنظیمات ربات سود به‌روزرسانی شد.',
                }
              : b
          ),
        };
      });
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/profit-bots/${encodeURIComponent(botId)}`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ویرایش تنظیمات ربات سود');
    await refreshProfitBots();
  };

  const handleStartProfitBot = async (botId: string, confirmLive?: boolean) => {
    if (demoMode) {
      const target = (demoState?.profitBots || []).find((b) => b.id === botId);
      if (!target) return;
      const now = Date.now();
      let startedBot: ProfitBotConfig = {
        ...target,
        isActive: true,
        botStatus: target.activePosition ? 'WAITING_FOR_PROFIT' : 'CHECKING_MARKET',
        startedAt: target.startedAt || now,
        lastError: null,
        lastStatusReason: 'ربات سود فعال شد و بررسی بازار آغاز گردید.',
        updatedAt: now,
      };
      const addedCycles: ProfitBotCycleRecord[] = [];
      const addedLogs: ProfitBotDecisionLog[] = [];
      try {
        const depthRes = await fetch(
          `/api/market/depth?symbol=${encodeURIComponent(target.symbol)}&limit=30`
        );
        if (depthRes.ok) {
          const book = (await depthRes.json()) as OrderBookSnapshot;
          const evalRes = evaluateDemoProfitBot(startedBot, book, Date.now(), effectiveBalances);
          startedBot = evalRes.bot;
          if (evalRes.newCycle) addedCycles.push(evalRes.newCycle);
          addedLogs.push(...evalRes.newLogs);
        }
      } catch {
        // Ignore transient fetch
      }
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          profitBots: base.profitBots.map((b) => (b.id === botId ? startedBot : b)),
          profitBotCycles: [...addedCycles, ...base.profitBotCycles].slice(0, 60),
          profitBotLogs: [...addedLogs, ...base.profitBotLogs].slice(0, 120),
        };
      });
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/profit-bots/${encodeURIComponent(botId)}/start`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ confirmLive: Boolean(confirmLive) }),
    });
    await parseApiJson(res, 'خطا در شروع ربات سود');
    await refreshProfitBots();
    await refreshAccount();
  };

  const handleStopProfitBot = async (botId: string) => {
    if (demoMode) {
      const now = Date.now();
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const target = base.profitBots.find((b) => b.id === botId);
        const stopLog: ProfitBotDecisionLog | null = target
          ? {
              id: `demo-plog-${now}-stop`,
              botId: target.id,
              cycleIndex: target.activePosition?.cycleIndex || target.stats.completedCycles + 1,
              status: 'STOPPED',
              event: 'STOPPED',
              price: target.activePosition?.lastExecutableSellPrice || 0,
              message: 'توقف فوری ربات سود توسط کاربر در حالت دمو اعمال شد.',
              timestamp: now,
            }
          : null;
        return {
          ...base,
          profitBots: base.profitBots.map((b) =>
            b.id === botId
              ? {
                  ...b,
                  isActive: false,
                  botStatus: 'STOPPED',
                  pendingOrder: null,
                  lastStatusReason: 'توقف فوری ربات با درخواست کاربر انجام شد.',
                  updatedAt: now,
                }
              : b
          ),
          profitBotLogs: stopLog ? [stopLog, ...base.profitBotLogs].slice(0, 120) : base.profitBotLogs,
        };
      });
      return;
    }

    const headers = await getAuthHeaders();
    const res = await fetch(`/api/profit-bots/${encodeURIComponent(botId)}/stop`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در توقف ربات سود');
    await refreshProfitBots();
  };

  const handleEvaluateProfitBot = async (botId: string) => {
    if (demoMode) {
      const target = (demoState?.profitBots || []).find((b) => b.id === botId);
      if (!target) return;
      const now = Date.now();
      const depthRes = await fetch(
        `/api/market/depth?symbol=${encodeURIComponent(target.symbol)}&limit=30`
      );
      if (!depthRes.ok) {
        throw new Error('خطا در دریافت دفتر سفارش لحظه‌ای نوبیتکس.');
      }
      const book = (await depthRes.json()) as OrderBookSnapshot;

      if (!target.isActive && target.activePosition) {
        // Refresh current position telemetry without placing an order
        const pos = target.activePosition;
        const sellSim = simulateOrderBookSell(
          book,
          pos.netOwnedQty,
          pos.totalBuyCostQuote,
          target.targetNetProfit,
          target.feeRate,
          pos.otherFeesQuote ?? target.otherFeesQuote
        );
        const reqSell = computeRequiredSellPrice(
          pos.netOwnedQty,
          pos.totalBuyCostQuote,
          target.targetNetProfit,
          target.feeRate,
          pos.otherFeesQuote ?? target.otherFeesQuote
        );
        setDemoState((prev) => {
          if (!prev) return prev;
          return {
            ...prev,
            profitBots: prev.profitBots.map((b) =>
              b.id === botId && b.activePosition
                ? {
                    ...b,
                    lastCheckedAt: now,
                    updatedAt: now,
                    activePosition: {
                      ...b.activePosition,
                      lastExecutableSellPrice: sellSim.executableAvgSellPrice,
                      lastExecutableProceedsQuote: sellSim.grossProceedsQuote,
                      lastEstimatedSellFeeQuote: sellSim.sellFeeQuote,
                      lastEstimatedNetProfitQuote: sellSim.netProfitQuote,
                      lastHasSufficientDepth: sellSim.hasSufficientDepth,
                      lastSpreadPercent: sellSim.spreadPercent,
                      lastSlippagePercent: sellSim.slippagePercent,
                      lastRequiredSellPrice: reqSell,
                      lastProgressPercent: computeProfitProgressPercent(
                        sellSim.netProfitQuote,
                        b.targetNetProfit
                      ),
                      lastEvaluatedAt: now,
                    },
                  }
                : b
            ),
          };
        });
        return;
      }

      const evalRes = evaluateDemoProfitBot(
        { ...target, isActive: true },
        book,
        now,
        effectiveBalances
      );
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          profitBots: base.profitBots.map((b) => (b.id === botId ? evalRes.bot : b)),
          profitBotCycles: evalRes.newCycle
            ? [evalRes.newCycle, ...base.profitBotCycles].slice(0, 60)
            : base.profitBotCycles,
          profitBotLogs:
            evalRes.newLogs.length > 0
              ? [...evalRes.newLogs, ...base.profitBotLogs].slice(0, 120)
              : base.profitBotLogs,
        };
      });
      return;
    }

    const headers = await getAuthHeaders();
    const res = await fetch(`/api/profit-bots/${encodeURIComponent(botId)}/evaluate`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در بررسی فوری ربات سود');
    await refreshProfitBots();
    await refreshAccount();
  };

  const handleManualSellProfitBot = async (botId: string) => {
    if (demoMode) {
      const target = (demoState?.profitBots || []).find((b) => b.id === botId);
      if (!target || !target.activePosition) {
        throw new Error('پوزیشن بازی برای فروش وجود ندارد.');
      }
      const depthRes = await fetch(
        `/api/market/depth?symbol=${encodeURIComponent(target.symbol)}&limit=30`
      );
      if (!depthRes.ok) {
        throw new Error('اتصال به دفتر سفارش نوبیتکس برقرار نشد.');
      }
      const book = (await depthRes.json()) as OrderBookSnapshot;
      const pos = target.activePosition;
      const sellSim = simulateOrderBookSell(
        book,
        pos.netOwnedQty,
        pos.totalBuyCostQuote,
        target.targetNetProfit,
        target.feeRate,
        pos.otherFeesQuote ?? target.otherFeesQuote
      );
      if (sellSim.executableAvgSellPrice <= 0 || !sellSim.hasSufficientDepth) {
        throw new Error('عمق دفتر سفارش برای فروش کل دارایی کافی نیست.');
      }
      const now = Date.now();
      const finalNet = roundQuoteValue(sellSim.netProfitQuote, target.quoteCurrency);
      const cycle: ProfitBotCycleRecord = {
        id: `demo-pcycle-${now}`,
        botId: target.id,
        cycleIndex: pos.cycleIndex,
        symbol: target.symbol,
        baseAsset: target.baseAsset,
        quoteCurrency: target.quoteCurrency,
        mode: target.mode,
        orderType: target.orderType,
        entryAmountQuote: pos.totalBuyCostQuote,
        actualBuyAvgPrice: pos.actualBuyAvgPrice,
        boughtQty: pos.filledGrossQty,
        buyFeeQuote: pos.buyFeeQuote,
        totalBuyCostQuote: pos.totalBuyCostQuote,
        actualSellAvgPrice: sellSim.executableAvgSellPrice,
        soldQty: pos.netOwnedQty,
        grossSellProceedsQuote: sellSim.grossProceedsQuote,
        sellFeeQuote: sellSim.sellFeeQuote,
        otherFeesQuote: pos.otherFeesQuote,
        finalNetProfitQuote: finalNet,
        targetNetProfitQuote: target.targetNetProfit,
        exitReason: 'MANUAL_SELL',
        startedAt: pos.buyFilledAt,
        completedAt: now,
      };
      const sellLog: ProfitBotDecisionLog = {
        id: `demo-plog-${now}-msell`,
        botId: target.id,
        cycleIndex: pos.cycleIndex,
        status: 'SELL_FILLED',
        event: 'SELL_FILLED',
        price: sellSim.executableAvgSellPrice,
        netProfitQuote: finalNet,
        message: `فروش دستی پوزیشن در قیمت ${roundQuoteValue(
          sellSim.executableAvgSellPrice,
          target.quoteCurrency
        ).toLocaleString('en-US')} انجام و در تاریخچه ثبت شد.`,
        timestamp: now,
      };
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          profitBots: base.profitBots.map((b) =>
            b.id === botId
              ? {
                  ...b,
                  isActive: false,
                  botStatus: 'STOPPED',
                  activePosition: null,
                  stats: {
                    ...b.stats,
                    completedCycles: b.stats.completedCycles + 1,
                    winningCycles: b.stats.winningCycles + (finalNet >= 0 ? 1 : 0),
                    losingCycles: b.stats.losingCycles + (finalNet < 0 ? 1 : 0),
                    totalNetProfitQuote: roundQuoteValue(
                      b.stats.totalNetProfitQuote + finalNet,
                      b.quoteCurrency
                    ),
                    totalFeesPaidQuote: roundQuoteValue(
                      b.stats.totalFeesPaidQuote + pos.buyFeeQuote + sellSim.sellFeeQuote,
                      b.quoteCurrency
                    ),
                    currentCapitalInvolved: Math.max(
                      0,
                      b.stats.currentCapitalInvolved - pos.totalBuyCostQuote
                    ),
                  },
                  dailyStats: {
                    ...b.dailyStats,
                    tradesCount: b.dailyStats.tradesCount + 1,
                    netProfitQuote: roundQuoteValue(
                      b.dailyStats.netProfitQuote + finalNet,
                      b.quoteCurrency
                    ),
                    lossQuote:
                      finalNet < 0
                        ? roundQuoteValue(b.dailyStats.lossQuote + Math.abs(finalNet), b.quoteCurrency)
                        : b.dailyStats.lossQuote,
                  },
                  lastStatusReason: sellLog.message,
                  updatedAt: now,
                }
              : b
          ),
          profitBotCycles: [cycle, ...base.profitBotCycles].slice(0, 60),
          profitBotLogs: [sellLog, ...base.profitBotLogs].slice(0, 120),
        };
      });
      return;
    }

    const headers = await getAuthHeaders();
    const res = await fetch(`/api/profit-bots/${encodeURIComponent(botId)}/manual-sell`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در فروش دستی پوزیشن ربات سود');
    await refreshProfitBots();
    await refreshAccount();
  };

  const handleDeleteProfitBot = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          profitBots: base.profitBots.filter((b) => b.id !== botId),
          profitBotCycles: base.profitBotCycles.filter((c) => c.botId !== botId),
          profitBotLogs: base.profitBotLogs.filter((l) => l.botId !== botId),
        };
      });
      return;
    }

    const headers = await getAuthHeaders();
    const res = await fetch(`/api/profit-bots/${encodeURIComponent(botId)}`, {
      method: 'DELETE',
      headers,
    });
    await parseApiJson(res, 'خطا در حذف ربات سود');
    await refreshProfitBots();
  };

  // =========================================================================
  // AI Cycle Pro | ربات چرخه هوشمند
  // =========================================================================
  const handlePreviewAiCycleProMarket = async (payload: {
    baseAsset: string;
    quoteCurrency: QuoteCurrency;
    capitalAmount: number;
    capitalUsageMode: AiCycleProCapitalUsageMode;
    capitalPortionPercent: number;
    minTargetNetProfitPercent: number;
    stopLossPercent: number;
    maxSlippagePercent: number;
    maxSpreadPercent: number;
  }): Promise<AiCycleProMarketPreview> => {
    if (demoMode) {
      let book: OrderBookSnapshot | null = null;
      const sym = `${payload.baseAsset.toUpperCase()}${payload.quoteCurrency}`;
      try {
        const res = await fetch(`/api/market/depth?symbol=${encodeURIComponent(sym)}&limit=30`);
        if (res.ok) book = (await res.json()) as OrderBookSnapshot;
      } catch {
        // fallback to ticker
      }
      return computeDemoAiCycleProPreview(book, markets, payload);
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/ai-cycle-pro/preview', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    return parseApiJson<AiCycleProMarketPreview>(res, 'خطا در تحلیل هوش مصنوعی AI Cycle Pro');
  };

  const handleCreateAiCycleProBot = async (payload: Record<string, unknown>) => {
    if (demoMode) {
      const now = Date.now();
      const baseAsset = String(payload.baseAsset || selectedBaseAsset).toUpperCase();
      const quoteCurrency: QuoteCurrency = payload.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
      const symbol = String(payload.symbol || `${baseAsset}${quoteCurrency}`);
      const capitalAmount = Number(
        payload.capitalAmount || (quoteCurrency === 'IRT' ? 10_000_000 : 100)
      );
      const capitalUsageMode: AiCycleProCapitalUsageMode =
        payload.capitalUsageMode === 'PARTIAL' ? 'PARTIAL' : 'FULL';
      const capitalPortionPercent = Math.min(
        100,
        Math.max(10, Number(payload.capitalPortionPercent ?? 100))
      );
      const startImmediately = Boolean(payload.startImmediately);
      const todayKey = new Date(now).toISOString().slice(0, 10);

      let newBot: AiCycleProConfig = {
        id: `demo-acycle-${now}`,
        ownerId: 'demo-user',
        name: String(payload.name || `چرخه هوشمند ${baseAsset}/${quoteCurrency}`),
        baseAsset,
        quoteCurrency,
        symbol,
        mode: 'paper',
        isActive: startImmediately,
        status: startImmediately ? 'ANALYZING' : 'IDLE',
        capitalAmount,
        capitalUsageMode,
        capitalPortionPercent,
        executionConfirmationMode:
          (payload.executionConfirmationMode as BotExecutionConfirmationMode) || 'AUTO',
        autoRepeatCycles: payload.autoRepeatCycles !== false,
        stopLossPercent: Number(payload.stopLossPercent ?? 3),
        maxDailyLoss: Number(
          payload.maxDailyLoss ?? (quoteCurrency === 'IRT' ? 500_000 : 15)
        ),
        maxSlippagePercent: Number(payload.maxSlippagePercent ?? 0.5),
        maxSpreadPercent: Number(payload.maxSpreadPercent ?? 1.5),
        minTargetNetProfitPercent: Number(payload.minTargetNetProfitPercent ?? 1.2),
        pollIntervalSeconds: Number(payload.pollIntervalSeconds ?? 20),
        feeRate: Number(payload.feeRate ?? DEFAULT_NOBITEX_FEE_RATE),
        notifyTelegram: payload.notifyTelegram !== false,
        activePosition: null,
        pendingOrder: null,
        lastDecision: null,
        dailyStats: { dateKey: todayKey, tradesCount: 0, lossQuote: 0, netProfitQuote: 0 },
        stats: {
          completedCycles: 0,
          winningCycles: 0,
          losingCycles: 0,
          totalNetProfitQuote: 0,
          totalFeesPaidQuote: 0,
          currentCapitalInvolved: 0,
          lastBuyPrice: null,
        },
        lastPrice: 0,
        lastStatusReason: startImmediately
          ? 'ربات AI Cycle Pro در حالت دمو فعال شد و تحلیل هوشمند بازار آغاز گردید.'
          : 'ربات ذخیره شد و آماده شروع است.',
        lastError: null,
        lastCheckedAt: now,
        startedAt: startImmediately ? now : null,
        createdAt: now,
        updatedAt: now,
      };

      const addedLogs: AiCycleProLog[] = [];
      const addedConfs: PendingBotConfirmation[] = [];
      if (startImmediately) {
        try {
          const depthRes = await fetch(`/api/market/depth?symbol=${encodeURIComponent(symbol)}&limit=30`);
          if (depthRes.ok) {
            const book = (await depthRes.json()) as OrderBookSnapshot;
            const evalRes = evaluateDemoAiCycleProBot(newBot, book, markets, Date.now());
            newBot = evalRes.bot;
            addedLogs.push(...evalRes.newLogs);
            if (evalRes.pendingConfirmation) addedConfs.push(evalRes.pendingConfirmation);
          }
        } catch {
          // keep ANALYZING
        }
      }

      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          aiCycleProBots: [newBot, ...(base.aiCycleProBots || [])],
          aiCycleProLogs: [...addedLogs, ...(base.aiCycleProLogs || [])].slice(0, 120),
          pendingConfirmations:
            addedConfs.length > 0
              ? [...addedConfs, ...(base.pendingConfirmations || [])]
              : base.pendingConfirmations,
        };
      });
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/ai-cycle-pro', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ایجاد ربات AI Cycle Pro');
    await Promise.all([refreshAiCycleProBots(), refreshSmartBots(false)]);
  };

  const handleUpdateAiCycleProBot = async (botId: string, payload: Record<string, unknown>) => {
    if (demoMode) {
      const now = Date.now();
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          aiCycleProBots: (base.aiCycleProBots || []).map((b) =>
            b.id === botId
              ? {
                  ...b,
                  name: typeof payload.name === 'string' ? payload.name : b.name,
                  capitalAmount: Number(payload.capitalAmount ?? b.capitalAmount),
                  capitalUsageMode:
                    (payload.capitalUsageMode as AiCycleProCapitalUsageMode) ?? b.capitalUsageMode,
                  capitalPortionPercent: Number(
                    payload.capitalPortionPercent ?? b.capitalPortionPercent
                  ),
                  executionConfirmationMode:
                    (payload.executionConfirmationMode as BotExecutionConfirmationMode) ??
                    b.executionConfirmationMode,
                  autoRepeatCycles:
                    typeof payload.autoRepeatCycles === 'boolean'
                      ? payload.autoRepeatCycles
                      : b.autoRepeatCycles,
                  stopLossPercent: Number(payload.stopLossPercent ?? b.stopLossPercent),
                  maxDailyLoss: Number(payload.maxDailyLoss ?? b.maxDailyLoss),
                  maxSlippagePercent: Number(payload.maxSlippagePercent ?? b.maxSlippagePercent),
                  maxSpreadPercent: Number(payload.maxSpreadPercent ?? b.maxSpreadPercent),
                  minTargetNetProfitPercent: Number(
                    payload.minTargetNetProfitPercent ?? b.minTargetNetProfitPercent
                  ),
                  pollIntervalSeconds: Number(payload.pollIntervalSeconds ?? b.pollIntervalSeconds),
                  notifyTelegram:
                    typeof payload.notifyTelegram === 'boolean'
                      ? payload.notifyTelegram
                      : b.notifyTelegram,
                  updatedAt: now,
                  lastStatusReason: 'تنظیمات ربات چرخه هوشمند به‌روزرسانی شد.',
                }
              : b
          ),
        };
      });
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/ai-cycle-pro/${encodeURIComponent(botId)}`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ویرایش تنظیمات AI Cycle Pro');
    await refreshAiCycleProBots();
  };

  const handleStartAiCycleProBot = async (botId: string, confirmLive?: boolean) => {
    if (demoMode) {
      const target = (demoState?.aiCycleProBots || []).find((b) => b.id === botId);
      if (!target) return;
      const now = Date.now();
      let startedBot: AiCycleProConfig = {
        ...target,
        isActive: true,
        status: target.activePosition ? 'HOLDING_POSITION' : 'ANALYZING',
        startedAt: target.startedAt || now,
        lastError: null,
        lastStatusReason: 'ربات AI Cycle Pro فعال شد و بررسی هوشمند بازار آغاز گردید.',
        updatedAt: now,
      };
      const addedCycles: AiCycleProCycleRecord[] = [];
      const addedLogs: AiCycleProLog[] = [];
      const addedConfs: PendingBotConfirmation[] = [];
      try {
        const depthRes = await fetch(
          `/api/market/depth?symbol=${encodeURIComponent(target.symbol)}&limit=30`
        );
        if (depthRes.ok) {
          const book = (await depthRes.json()) as OrderBookSnapshot;
          const evalRes = evaluateDemoAiCycleProBot(startedBot, book, markets, Date.now());
          startedBot = evalRes.bot;
          if (evalRes.newCycle) addedCycles.push(evalRes.newCycle);
          addedLogs.push(...evalRes.newLogs);
          if (evalRes.pendingConfirmation) addedConfs.push(evalRes.pendingConfirmation);
        }
      } catch {
        // keep startedBot
      }
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          aiCycleProBots: (base.aiCycleProBots || []).map((b) => (b.id === botId ? startedBot : b)),
          aiCycleProCycles: [...addedCycles, ...(base.aiCycleProCycles || [])].slice(0, 60),
          aiCycleProLogs: [...addedLogs, ...(base.aiCycleProLogs || [])].slice(0, 120),
          pendingConfirmations:
            addedConfs.length > 0
              ? [...addedConfs, ...(base.pendingConfirmations || [])]
              : base.pendingConfirmations,
        };
      });
      return;
    }

    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/ai-cycle-pro/${encodeURIComponent(botId)}/start`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ confirmLive: Boolean(confirmLive) }),
    });
    await parseApiJson(res, 'خطا در شروع ربات AI Cycle Pro');
    await Promise.all([refreshAiCycleProBots(), refreshSmartBots(false), refreshAccount()]);
  };

  const handleStopAiCycleProBot = async (botId: string) => {
    if (demoMode) {
      const now = Date.now();
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const target = (base.aiCycleProBots || []).find((b) => b.id === botId);
        const stopLog: AiCycleProLog | null = target
          ? {
              id: `demo-aclog-${now}-stop`,
              botId: target.id,
              cycleIndex: target.activePosition?.cycleIndex || target.stats.completedCycles + 1,
              status: 'STOPPED',
              event: 'STOPPED',
              price: target.lastPrice || 0,
              message: 'توقف فوری ربات چرخه هوشمند توسط کاربر در حالت دمو اعمال شد.',
              timestamp: now,
            }
          : null;
        return {
          ...base,
          aiCycleProBots: (base.aiCycleProBots || []).map((b) =>
            b.id === botId
              ? {
                  ...b,
                  isActive: false,
                  status: 'STOPPED',
                  pendingOrder: null,
                  lastStatusReason: 'توقف فوری ربات با درخواست کاربر انجام شد.',
                  updatedAt: now,
                }
              : b
          ),
          aiCycleProLogs: stopLog
            ? [stopLog, ...(base.aiCycleProLogs || [])].slice(0, 120)
            : base.aiCycleProLogs,
        };
      });
      return;
    }

    const headers = await getAuthHeaders();
    const res = await fetch(`/api/ai-cycle-pro/${encodeURIComponent(botId)}/stop`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در توقف ربات AI Cycle Pro');
    await refreshAiCycleProBots();
  };

  const handleEvaluateAiCycleProBot = async (botId: string) => {
    if (demoMode) {
      const target = (demoState?.aiCycleProBots || []).find((b) => b.id === botId);
      if (!target) return;
      const now = Date.now();
      const depthRes = await fetch(
        `/api/market/depth?symbol=${encodeURIComponent(target.symbol)}&limit=30`
      );
      if (!depthRes.ok) {
        throw new Error('خطا در دریافت دفتر سفارش لحظه‌ای نوبیتکس.');
      }
      const book = (await depthRes.json()) as OrderBookSnapshot;
      const evalRes = evaluateDemoAiCycleProBot({ ...target, isActive: true }, book, markets, now);
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          aiCycleProBots: (base.aiCycleProBots || []).map((b) => (b.id === botId ? evalRes.bot : b)),
          aiCycleProCycles: evalRes.newCycle
            ? [evalRes.newCycle, ...(base.aiCycleProCycles || [])].slice(0, 60)
            : base.aiCycleProCycles,
          aiCycleProLogs:
            evalRes.newLogs.length > 0
              ? [...evalRes.newLogs, ...(base.aiCycleProLogs || [])].slice(0, 120)
              : base.aiCycleProLogs,
          pendingConfirmations: evalRes.pendingConfirmation
            ? [evalRes.pendingConfirmation, ...(base.pendingConfirmations || [])]
            : base.pendingConfirmations,
        };
      });
      return;
    }

    const headers = await getAuthHeaders();
    const res = await fetch(`/api/ai-cycle-pro/${encodeURIComponent(botId)}/evaluate`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در تحلیل و بررسی فوری AI Cycle Pro');
    await Promise.all([refreshAiCycleProBots(), refreshSmartBots(false), refreshAccount()]);
  };

  const handleManualSellAiCycleProBot = async (botId: string) => {
    if (demoMode) {
      const target = (demoState?.aiCycleProBots || []).find((b) => b.id === botId);
      if (!target || !target.activePosition) {
        throw new Error('پوزیشن بازی برای فروش وجود ندارد.');
      }
      const depthRes = await fetch(
        `/api/market/depth?symbol=${encodeURIComponent(target.symbol)}&limit=30`
      );
      if (!depthRes.ok) {
        throw new Error('اتصال به دفتر سفارش نوبیتکس برقرار نشد.');
      }
      const book = (await depthRes.json()) as OrderBookSnapshot;
      const pos = target.activePosition;
      const sellSim = simulateOrderBookSell(
        book,
        pos.netOwnedQty,
        pos.totalBuyCostQuote,
        0,
        target.feeRate
      );
      if (sellSim.executableAvgSellPrice <= 0 || !sellSim.hasSufficientDepth) {
        throw new Error('عمق دفتر سفارش برای فروش کل دارایی کافی نیست.');
      }
      const now = Date.now();
      const finalNet = roundQuoteValue(sellSim.netProfitQuote, target.quoteCurrency);
      const cycle: AiCycleProCycleRecord = {
        id: `demo-accycle-${now}`,
        botId: target.id,
        cycleIndex: pos.cycleIndex,
        symbol: target.symbol,
        baseAsset: target.baseAsset,
        quoteCurrency: target.quoteCurrency,
        mode: target.mode,
        entryAmountQuote: pos.totalBuyCostQuote,
        actualBuyAvgPrice: pos.actualBuyAvgPrice,
        boughtQty: pos.filledGrossQty,
        buyFeeQuote: pos.buyFeeQuote,
        totalBuyCostQuote: pos.totalBuyCostQuote,
        actualSellAvgPrice: sellSim.executableAvgSellPrice,
        soldQty: pos.netOwnedQty,
        grossSellProceedsQuote: sellSim.grossProceedsQuote,
        sellFeeQuote: sellSim.sellFeeQuote,
        finalNetProfitQuote: finalNet,
        targetNetProfitPercent: pos.targetNetProfitPercent,
        slippagePercent: sellSim.slippagePercent,
        exitReason: 'MANUAL_SELL',
        aiEntrySummaryFa: target.lastDecision?.reasoningFa || 'ورود هوشمند AI Cycle Pro',
        aiExitSummaryFa: 'خروج دستی کاربر بر اساس عمق دفتر سفارش نوبیتکس',
        startedAt: pos.buyFilledAt,
        completedAt: now,
      };
      const sellLog: AiCycleProLog = {
        id: `demo-aclog-${now}-msell`,
        botId: target.id,
        cycleIndex: pos.cycleIndex,
        status: 'STOPPED',
        event: 'SELL_FILLED',
        price: sellSim.executableAvgSellPrice,
        netProfitQuote: finalNet,
        message: `فروش دستی پوزیشن در قیمت ${roundQuoteValue(
          sellSim.executableAvgSellPrice,
          target.quoteCurrency
        ).toLocaleString('en-US')} انجام و ثبت شد.`,
        timestamp: now,
      };
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          aiCycleProBots: (base.aiCycleProBots || []).map((b) =>
            b.id === botId
              ? {
                  ...b,
                  isActive: false,
                  status: 'STOPPED',
                  activePosition: null,
                  stats: {
                    ...b.stats,
                    completedCycles: b.stats.completedCycles + 1,
                    winningCycles: b.stats.winningCycles + (finalNet >= 0 ? 1 : 0),
                    losingCycles: b.stats.losingCycles + (finalNet < 0 ? 1 : 0),
                    totalNetProfitQuote: roundQuoteValue(
                      b.stats.totalNetProfitQuote + finalNet,
                      b.quoteCurrency
                    ),
                    totalFeesPaidQuote: roundQuoteValue(
                      b.stats.totalFeesPaidQuote + pos.buyFeeQuote + sellSim.sellFeeQuote,
                      b.quoteCurrency
                    ),
                    currentCapitalInvolved: 0,
                  },
                  dailyStats: {
                    ...b.dailyStats,
                    tradesCount: b.dailyStats.tradesCount + 1,
                    netProfitQuote: roundQuoteValue(
                      b.dailyStats.netProfitQuote + finalNet,
                      b.quoteCurrency
                    ),
                    lossQuote:
                      finalNet < 0
                        ? roundQuoteValue(b.dailyStats.lossQuote + Math.abs(finalNet), b.quoteCurrency)
                        : b.dailyStats.lossQuote,
                  },
                  lastStatusReason: sellLog.message,
                  updatedAt: now,
                }
              : b
          ),
          aiCycleProCycles: [cycle, ...(base.aiCycleProCycles || [])].slice(0, 60),
          aiCycleProLogs: [sellLog, ...(base.aiCycleProLogs || [])].slice(0, 120),
        };
      });
      return;
    }

    const headers = await getAuthHeaders();
    const res = await fetch(`/api/ai-cycle-pro/${encodeURIComponent(botId)}/manual-sell`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در فروش دستی پوزیشن AI Cycle Pro');
    await Promise.all([refreshAiCycleProBots(), refreshAccount()]);
  };

  const handleDeleteAiCycleProBot = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          aiCycleProBots: (base.aiCycleProBots || []).filter((b) => b.id !== botId),
          aiCycleProCycles: (base.aiCycleProCycles || []).filter((c) => c.botId !== botId),
          aiCycleProLogs: (base.aiCycleProLogs || []).filter((l) => l.botId !== botId),
        };
      });
      return;
    }

    const headers = await getAuthHeaders();
    const res = await fetch(`/api/ai-cycle-pro/${encodeURIComponent(botId)}`, {
      method: 'DELETE',
      headers,
    });
    await parseApiJson(res, 'خطا در حذف ربات AI Cycle Pro');
    await refreshAiCycleProBots();
  };

  // =========================================================================
  // Grid Bot, DCA Bot, Shared Risk, Kill Switch, Confirmations & AI Manager
  // =========================================================================
  const handleCreateGridBot = async (payload: Record<string, unknown>) => {
    if (demoMode) {
      const now = Date.now();
      const baseAsset = String(payload.baseAsset || selectedBaseAsset).toUpperCase();
      const quoteCurrency: QuoteCurrency =
        payload.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
      const symbol = `${baseAsset}${quoteCurrency}`;
      const lowerPrice = Number(payload.lowerPrice) || 1;
      const upperPrice = Math.max(lowerPrice * 1.01, Number(payload.upperPrice) || lowerPrice * 1.1);
      const gridLevels = Math.max(2, Math.min(30, Number(payload.gridLevels) || 6));
      const stepMode: GridStepMode =
        payload.stepMode === 'GEOMETRIC' ? 'GEOMETRIC' : 'ARITHMETIC';
      const totalCapital = Math.max(0, Number(payload.totalCapital) || 10_000_000);
      const m = markets.find((x) => x.baseAsset === baseAsset);
      const livePx = quoteCurrency === 'USDT' ? m?.priceUsdt ?? lowerPrice : m?.priceToman ?? lowerPrice;
      const ratio = stepMode === 'GEOMETRIC' ? Math.pow(upperPrice / lowerPrice, 1 / (gridLevels - 1)) : 0;
      const step = (upperPrice - lowerPrice) / (gridLevels - 1);
      const allocatedLevels = Array.from({ length: gridLevels }, (_, idx) => {
        const px =
          stepMode === 'GEOMETRIC'
            ? lowerPrice * Math.pow(ratio, idx)
            : lowerPrice + idx * step;
        return {
          index: idx,
          price: roundQuoteValue(px, quoteCurrency),
          side: (px <= livePx ? 'BUY' : 'SELL') as 'BUY' | 'SELL',
          status: 'IDLE' as const,
          qty: 0,
        };
      });
      const stepPct = ((upperPrice - lowerPrice) / lowerPrice / Math.max(1, gridLevels - 1)) * 100;
      const feeRate = Number(payload.feeRate ?? DEFAULT_NOBITEX_FEE_RATE);
      const startImmediately = payload.startImmediately !== false;
      const newGrid: GridBotConfig = {
        id: `demo-grid-${now}`,
        ownerId: 'demo-user',
        name: String(payload.name || `گرید ${baseAsset}`),
        baseAsset,
        quoteCurrency,
        symbol,
        mode: 'paper',
        isActive: startImmediately,
        status: startImmediately ? 'RUNNING' : 'PAUSED',
        lowerPrice,
        upperPrice,
        gridLevels,
        stepMode,
        totalCapital,
        maxCapitalInvolved: Number(payload.maxCapitalInvolved || totalCapital),
        stopOnBreakout: payload.stopOnBreakout !== false,
        alertOnBreakout: payload.alertOnBreakout !== false,
        feeRate,
        estimatedSlippagePercent: Number(payload.estimatedSlippagePercent ?? 0.15),
        executionConfirmationMode:
          (payload.executionConfirmationMode as BotExecutionConfirmationMode) || 'AUTO',
        notifyTelegram: payload.notifyTelegram !== false,
        allocatedLevels,
        stats: {
          completedCycles: 0,
          totalNetProfitQuote: 0,
          totalFeesPaidQuote: 0,
          openOrdersCount: 0,
          currentCapitalInvolved: 0,
          netProfitPerCyclePercent: Number(Math.max(0, stepPct - feeRate * 200).toFixed(2)),
        },
        lastPrice: livePx,
        lastStatusReason: startImmediately
          ? 'ربات گرید دمو فعال شد و پله‌ها آماده نوسان‌گیری هستند.'
          : 'ربات گرید دمو ذخیره شد.',
        lastError: null,
        lastCheckedAt: now,
        createdAt: now,
        updatedAt: now,
      };
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return { ...base, gridBots: [newGrid, ...(base.gridBots || [])] };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/grid-bots', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ساخت ربات گرید');
    await refreshSmartBots();
  };

  const handleStartGridBot = async (botId: string, confirmLive?: boolean) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          gridBots: (base.gridBots || []).map((b) =>
            b.id === botId
              ? {
                  ...b,
                  isActive: true,
                  status: 'RUNNING',
                  lastStatusReason: 'ربات گرید در حالت دمو فعال شد.',
                  updatedAt: Date.now(),
                }
              : b
          ),
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/grid-bots/${encodeURIComponent(botId)}/start`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ confirmLive: Boolean(confirmLive) }),
    });
    await parseApiJson(res, 'خطا در شروع ربات گرید');
    await refreshSmartBots();
  };

  const handleStopGridBot = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          gridBots: (base.gridBots || []).map((b) =>
            b.id === botId
              ? {
                  ...b,
                  isActive: false,
                  status: 'STOPPED',
                  lastStatusReason: 'ربات گرید توسط کاربر متوقف شد.',
                  updatedAt: Date.now(),
                }
              : b
          ),
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/grid-bots/${encodeURIComponent(botId)}/stop`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در توقف ربات گرید');
    await refreshSmartBots();
  };

  const handleEvaluateGridBot = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          gridBots: (base.gridBots || []).map((b) => {
            if (b.id !== botId) return b;
            const m = markets.find((x) => x.baseAsset === b.baseAsset);
            const livePx = b.quoteCurrency === 'USDT' ? m?.priceUsdt ?? b.lastPrice : m?.priceToman ?? b.lastPrice;
            const outOfRange = livePx > 0 && (livePx < b.lowerPrice || livePx > b.upperPrice);
            return {
              ...b,
              lastPrice: livePx,
              status: outOfRange ? 'OUT_OF_RANGE' : b.isActive ? 'RUNNING' : b.status,
              lastCheckedAt: Date.now(),
              lastStatusReason: outOfRange
                ? 'هشدار: قیمت از محدوده گرید خارج شده است.'
                : 'بررسی لحظه‌ای پله‌های گرید انجام شد.',
              updatedAt: Date.now(),
            };
          }),
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/grid-bots/${encodeURIComponent(botId)}/evaluate`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در پایش ربات گرید');
    await refreshSmartBots();
  };

  const handleDeleteGridBot = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return { ...base, gridBots: (base.gridBots || []).filter((b) => b.id !== botId) };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/grid-bots/${encodeURIComponent(botId)}`, {
      method: 'DELETE',
      headers,
    });
    await parseApiJson(res, 'خطا در حذف ربات گرید');
    await refreshSmartBots();
  };

  const handleCreateDcaBot = async (payload: Record<string, unknown>) => {
    if (demoMode) {
      const now = Date.now();
      const baseAsset = String(payload.baseAsset || selectedBaseAsset).toUpperCase();
      const quoteCurrency: QuoteCurrency =
        payload.quoteCurrency === 'USDT' ? 'USDT' : 'IRT';
      const symbol = `${baseAsset}${quoteCurrency}`;
      const m = markets.find((x) => x.baseAsset === baseAsset);
      const livePx = quoteCurrency === 'USDT' ? m?.priceUsdt ?? 0 : m?.priceToman ?? 0;
      const totalCapital = Math.max(0, Number(payload.totalCapital) || 20_000_000);
      const startImmediately = payload.startImmediately !== false;
      const newDca: DcaBotConfig = {
        id: `demo-dca-${now}`,
        ownerId: 'demo-user',
        name: String(payload.name || `خرید پله‌ای ${baseAsset}`),
        baseAsset,
        quoteCurrency,
        symbol,
        mode: 'paper',
        isActive: startImmediately,
        status: startImmediately ? 'RUNNING' : 'PAUSED',
        totalCapital,
        maxInvolvedCapital: Number(payload.maxInvolvedCapital || totalCapital),
        stagesCount: Math.max(2, Math.min(30, Number(payload.stagesCount) || 5)),
        stepUnit: (payload.stepUnit as DcaStepUnit) === 'PRICE' ? 'PRICE' : 'PERCENT',
        stepValue: Math.max(0.1, Number(payload.stepValue) || 2.5),
        triggerMode: (payload.triggerMode as DcaTriggerMode) || 'MARKET_DROP',
        intervalMinutes: Math.max(5, Number(payload.intervalMinutes) || 120),
        pauseNewBuys: false,
        stopLossEnabled: payload.stopLossEnabled !== false,
        stopLossPercent: Number(payload.stopLossPercent || 8),
        takeProfitEnabled: payload.takeProfitEnabled !== false,
        takeProfitPercent: Number(payload.takeProfitPercent || 5),
        trailingTpEnabled: Boolean(payload.trailingTpEnabled),
        trailingTpActivationPercent: Number(payload.trailingTpActivationPercent || 3.5),
        trailingTpCallbackPercent: Number(payload.trailingTpCallbackPercent || 1),
        takeProfitTargets: Array.isArray(payload.takeProfitTargets)
          ? (payload.takeProfitTargets as TakeProfitTarget[])
          : [],
        keepRunnerPercent: Number(payload.keepRunnerPercent || 0),
        feeRate: Number(payload.feeRate ?? DEFAULT_NOBITEX_FEE_RATE),
        estimatedSlippagePercent: Number(payload.estimatedSlippagePercent ?? 0.15),
        executionConfirmationMode:
          (payload.executionConfirmationMode as BotExecutionConfirmationMode) || 'AUTO',
        notifyTelegram: payload.notifyTelegram !== false,
        state: {
          stagesCompleted: 0,
          totalHoldingQty: 0,
          netOwnedQty: 0,
          avgBuyPrice: 0,
          totalInvestedQuote: 0,
          totalBuyFeesQuote: 0,
          highestPriceSinceEntry: livePx,
          trailingTpArmed: false,
          lastBuyPrice: 0,
          nextTriggerAt: startImmediately ? now : null,
          executedTpIds: [],
        },
        stats: {
          completedCycles: 0,
          realizedNetProfitQuote: 0,
          totalFeesPaidQuote: 0,
        },
        lastPrice: livePx,
        lastStatusReason: startImmediately
          ? 'ربات خرید پله‌ای دمو فعال شد و آماده اجرای مرحله اول است.'
          : 'ربات خرید پله‌ای دمو ذخیره شد.',
        lastError: null,
        lastCheckedAt: now,
        createdAt: now,
        updatedAt: now,
      };
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return { ...base, dcaBots: [newDca, ...(base.dcaBots || [])] };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/dca-bots', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ساخت ربات خرید پله‌ای');
    await refreshSmartBots();
  };

  const handleUpdateDcaBot = async (botId: string, payload: Record<string, unknown>) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          dcaBots: (base.dcaBots || []).map((b) => {
            if (b.id !== botId) return b;
            const nextPause =
              payload.pauseNewBuys !== undefined ? Boolean(payload.pauseNewBuys) : b.pauseNewBuys;
            return {
              ...b,
              ...payload,
              pauseNewBuys: nextPause,
              status: nextPause ? 'PAUSED_BUYS' : b.isActive ? 'RUNNING' : b.status,
              lastStatusReason: nextPause
                ? 'خریدهای جدید متوقف شد؛ فقط مدیریت فروش و حد سود/ضرر ادامه دارد.'
                : 'تنظیمات ربات خرید پله‌ای به‌روزرسانی شد.',
              updatedAt: Date.now(),
            } as DcaBotConfig;
          }),
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/dca-bots/${encodeURIComponent(botId)}`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در ویرایش ربات خرید پله‌ای');
    await refreshSmartBots();
  };

  const handleStartDcaBot = async (botId: string, confirmLive?: boolean) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          dcaBots: (base.dcaBots || []).map((b) =>
            b.id === botId
              ? {
                  ...b,
                  isActive: true,
                  status: b.pauseNewBuys ? 'PAUSED_BUYS' : 'RUNNING',
                  lastStatusReason: 'ربات خرید پله‌ای دمو فعال شد.',
                  updatedAt: Date.now(),
                }
              : b
          ),
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/dca-bots/${encodeURIComponent(botId)}/start`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ confirmLive: Boolean(confirmLive) }),
    });
    await parseApiJson(res, 'خطا در شروع ربات خرید پله‌ای');
    await refreshSmartBots();
  };

  const handleStopDcaBot = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          dcaBots: (base.dcaBots || []).map((b) =>
            b.id === botId
              ? {
                  ...b,
                  isActive: false,
                  status: 'STOPPED',
                  lastStatusReason: 'ربات خرید پله‌ای متوقف شد.',
                  updatedAt: Date.now(),
                }
              : b
          ),
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/dca-bots/${encodeURIComponent(botId)}/stop`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در توقف ربات خرید پله‌ای');
    await refreshSmartBots();
  };

  const handleEvaluateDcaBot = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          dcaBots: (base.dcaBots || []).map((b) => {
            if (b.id !== botId) return b;
            const m = markets.find((x) => x.baseAsset === b.baseAsset);
            const livePx = b.quoteCurrency === 'USDT' ? m?.priceUsdt ?? b.lastPrice : m?.priceToman ?? b.lastPrice;
            return {
              ...b,
              lastPrice: livePx,
              lastCheckedAt: Date.now(),
              lastStatusReason: 'بررسی لحظه‌ای پله‌ها و میانگین خرید در حالت دمو انجام شد.',
              updatedAt: Date.now(),
            };
          }),
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/dca-bots/${encodeURIComponent(botId)}/evaluate`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در بررسی ربات خرید پله‌ای');
    await refreshSmartBots();
  };

  const handleDeleteDcaBot = async (botId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return { ...base, dcaBots: (base.dcaBots || []).filter((b) => b.id !== botId) };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/dca-bots/${encodeURIComponent(botId)}`, {
      method: 'DELETE',
      headers,
    });
    await parseApiJson(res, 'خطا در حذف ربات خرید پله‌ای');
    await refreshSmartBots();
  };

  const handleUpdateRiskSettings = async (updates: Partial<SharedBotRiskSettings>) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          riskSettings: {
            ...base.riskSettings,
            ...updates,
            updatedAt: Date.now(),
          },
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/bots/risk-settings', {
      method: 'PUT',
      headers,
      body: JSON.stringify(updates),
    });
    await parseApiJson(res, 'خطا در ذخیره تنظیمات سرمایه و ریسک مشترک');
    await refreshSmartBots();
  };

  const handleToggleKillSwitch = async (active: boolean) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          riskSettings: {
            ...base.riskSettings,
            killSwitchActive: active,
            updatedAt: Date.now(),
          },
          bots: active
            ? base.bots.map((b) => ({ ...b, status: 'PAUSED' }))
            : base.bots,
          profitBots: active
            ? base.profitBots.map((b) => ({ ...b, isActive: false, botStatus: 'STOPPED' }))
            : base.profitBots,
          aiCycleProBots: active
            ? (base.aiCycleProBots || []).map((b) => ({
                ...b,
                isActive: false,
                status: 'STOPPED',
              }))
            : base.aiCycleProBots,
          gridBots: active
            ? (base.gridBots || []).map((b) => ({ ...b, isActive: false, status: 'STOPPED' }))
            : base.gridBots,
          dcaBots: active
            ? (base.dcaBots || []).map((b) => ({ ...b, isActive: false, status: 'STOPPED' }))
            : base.dcaBots,
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/bots/kill-switch', {
      method: 'POST',
      headers,
      body: JSON.stringify({ active }),
    });
    await parseApiJson(res, 'خطا در اجرای کلید توقف اضطراری');
    await Promise.all([
      refreshBots(),
      refreshProfitBots(),
      refreshAiCycleProBots(),
      refreshSmartBots(),
    ]);
  };

  const handleResolveConfirmation = async (
    conf: PendingBotConfirmation,
    decision: 'APPROVE' | 'REJECT'
  ) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const now = Date.now();
        return {
          ...base,
          pendingConfirmations: (base.pendingConfirmations || []).map((item) =>
            item.id === conf.id
              ? {
                  ...item,
                  status: decision === 'APPROVE' ? 'APPROVED' : 'REJECTED',
                  resolvedAt: now,
                }
              : item
          ),
          aiCycleProBots:
            decision === 'APPROVE' && conf.botType === 'AI_CYCLE_PRO'
              ? (base.aiCycleProBots || []).map((ac) => {
                  if (ac.id !== conf.botId) return ac;
                  if (conf.side === 'BUY') {
                    const grossQty = conf.quantity;
                    const netQty = grossQty * (1 - ac.feeRate);
                    const targetPct = Math.max(
                      ac.minTargetNetProfitPercent,
                      ac.lastDecision?.recommendedTargetNetProfitPercent ?? ac.minTargetNetProfitPercent
                    );
                    const reqSell = computeRequiredSellPrice(
                      netQty,
                      conf.quoteAmount,
                      conf.quoteAmount * (targetPct / 100),
                      ac.feeRate
                    );
                    return {
                      ...ac,
                      status: 'HOLDING_POSITION',
                      activePosition: {
                        cycleIndex: ac.stats.completedCycles + 1,
                        buyOrderId: `demo-acbuy-${now}`,
                        requestedQuoteAmount: conf.quoteAmount,
                        requestedQty: grossQty,
                        filledGrossQty: grossQty,
                        netOwnedQty: netQty,
                        actualBuyAvgPrice: conf.suggestedPrice,
                        buyFeeQuote: conf.estimatedFeeQuote,
                        totalBuyCostQuote: conf.quoteAmount,
                        targetNetProfitPercent: targetPct,
                        targetSellPrice: reqSell,
                        stopLossPrice: roundQuoteValue(
                          conf.suggestedPrice * (1 - ac.stopLossPercent / 100),
                          ac.quoteCurrency
                        ),
                        highestPrice: conf.suggestedPrice,
                        buyFilledAt: now,
                        lastEstimatedExecutableSellPrice: conf.suggestedPrice,
                        lastEstimatedNetProfitQuote: -conf.estimatedFeeQuote * 2,
                        lastEvaluatedAt: now,
                      },
                      stats: {
                        ...ac.stats,
                        currentCapitalInvolved: conf.quoteAmount,
                        lastBuyPrice: conf.suggestedPrice,
                      },
                      lastStatusReason: `سفارش خرید چرخه هوشمند با تأیید دستی در قیمت ${formatQuotePrice(
                        conf.suggestedPrice,
                        conf.quoteCurrency
                      )} ثبت شد.`,
                      updatedAt: now,
                    };
                  }
                  return ac;
                })
              : base.aiCycleProBots,
          dcaBots:
            decision === 'APPROVE' && conf.botType === 'DCA'
              ? (base.dcaBots || []).map((d) =>
                  d.id === conf.botId && conf.side === 'BUY'
                    ? {
                        ...d,
                        state: {
                          ...d.state,
                          stagesCompleted: d.state.stagesCompleted + 1,
                          totalHoldingQty: d.state.totalHoldingQty + conf.quantity,
                          netOwnedQty:
                            d.state.netOwnedQty + conf.quantity * (1 - d.feeRate),
                          totalInvestedQuote: d.state.totalInvestedQuote + conf.quoteAmount,
                          totalBuyFeesQuote:
                            d.state.totalBuyFeesQuote + conf.estimatedFeeQuote,
                          avgBuyPrice:
                            (d.state.totalInvestedQuote + conf.quoteAmount) /
                            Math.max(1e-8, d.state.totalHoldingQty + conf.quantity),
                          lastBuyPrice: conf.suggestedPrice,
                        },
                        lastStatusReason: `سفارش تأیید دستی (${conf.side}) در قیمت ${formatQuotePrice(
                          conf.suggestedPrice,
                          conf.quoteCurrency
                        )} در حالت دمو اجرا شد.`,
                        updatedAt: now,
                      }
                    : d
                )
              : base.dcaBots,
        };
      });
      return;
    }
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(
      `/api/bots/pending-confirmations/${encodeURIComponent(conf.id)}/resolve`,
      {
        method: 'POST',
        headers,
        body: JSON.stringify({ decision, confirmLive: conf.mode === 'live' }),
      }
    );
    await parseApiJson(res, 'خطا در ثبت تصمیم سفارش');
    await Promise.all([
      refreshBots(),
      refreshProfitBots(),
      refreshAiCycleProBots(),
      refreshSmartBots(),
      refreshAccount(),
    ]);
  };

  const handleRunAiManagerAnalysis = async () => {
    if (demoMode) {
      const now = Date.now();
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        const topIrt = [...markets]
          .filter((m) => m.priceToman > 0)
          .sort((a, b) => Math.abs(b.change24hPercent) - Math.abs(a.change24hPercent));
        const btcM = markets.find((m) => m.baseAsset === 'BTC');
        const chg = btcM?.change24hPercent ?? 0;
        const regime: AiManagerAnalysis['regime'] =
          chg > 2.5 ? 'BULLISH' : chg < -2.5 ? 'BEARISH' : Math.abs(chg) > 4 ? 'VOLATILE' : 'RANGING';
        const regimeLabelFa =
          regime === 'BULLISH'
            ? 'صعودی'
            : regime === 'BEARISH'
              ? 'نزولی'
              : regime === 'VOLATILE'
                ? 'پرنوسان'
                : 'رِنج و متعادل';
        return {
          ...base,
          aiManagerReport: {
            ...base.aiManagerReport,
            id: `demo-aim-${now}`,
            generatedAt: now,
            regime,
            regimeLabelFa,
            recommendedPrimaryBotType:
              regime === 'RANGING' ? 'GRID' : regime === 'BEARISH' ? 'DCA' : 'STRATEGY',
            rankedCoins: topIrt.slice(0, 5).map((m, idx) => ({
              symbol: m.symbolIrt || `${m.baseAsset}IRT`,
              baseAsset: m.baseAsset,
              persianName: m.persianName || m.baseAsset,
              score: Math.max(60, 95 - idx * 6),
              liquidityScore: Math.max(70, 94 - idx * 4),
              volatilityLabelFa: Math.abs(m.change24hPercent) > 4 ? 'نوسان بالا' : 'نوسان متعادل',
              trendLabelFa: m.change24hPercent >= 0 ? 'مثبت ۲۴ ساعته' : 'اصلاحی ۲۴ ساعته',
              recommendedBotType: Math.abs(m.change24hPercent) > 4 ? 'GRID' : m.change24hPercent < -2 ? 'DCA' : 'PROFIT',
              reasonFa: `تغییر ۲۴ ساعته ${m.change24hPercent.toFixed(1)}٪ در بازار نوبیتکس`,
            })),
          },
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch('/api/ai/bot-manager', {
      method: 'POST',
      headers,
    });
    const data = await parseApiJson<{
      report?: AiManagerAnalysis;
      dashboard?: UnifiedBotsDashboardSummary;
    }>(res, 'خطا در تحلیل مدیر هوشمند مرکزی');
    if (data.report) setAiManagerReport(data.report);
    if (data.dashboard) setUnifiedDashboard(data.dashboard);
    await refreshSmartBots();
  };

  const handleGenerateAppKey = async (label: string, scopes: string[]) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/keys/app', {
      method: 'POST',
      headers,
      body: JSON.stringify({ label, scopes }),
    });
    const data = await parseApiJson<{ rawKey: string; record?: AppApiKeySummary }>(
      res,
      'خطا در تولید کلید API'
    );
    if (auth.currentUser && data.record) {
      void syncApiKeyMetadataToFirestore(auth.currentUser, data.record);
    }
    await refreshStatusAndKeys();
    return { rawKey: data.rawKey };
  };

  const handleRevokeAppKey = async (keyId: string) => {
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/keys/app/${encodeURIComponent(keyId)}/revoke`, {
      method: 'POST',
      headers,
    });
    await parseApiJson(res, 'خطا در لغو کلید');
    if (auth.currentUser) {
      void markApiKeyRevokedInFirestore(auth.currentUser, keyId);
    }
    await refreshStatusAndKeys();
  };

  const handleSaveExchangeKey = async (payload: {
    label: string;
    authType?: NobitexAuthType;
    apiToken?: string;
    apiKey?: string;
    secretKey?: string;
    verifyFirst: boolean;
  }) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/keys/exchange', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    const data = await parseApiJson<{ verified?: boolean }>(
      res,
      'خطا در اتصال کلیدهای نوبیتکس'
    );
    setExecutionMode('live');
    await refreshStatusAndKeys();
    await refreshAccount();
    return { verified: Boolean(data.verified) };
  };

  const handleTestExchangeKey = async () => {
    const headers = await getAuthHeaders();
    const res = await fetch('/api/keys/exchange/test', {
      method: 'POST',
      headers,
    });
    return parseApiJson<{
      canTrade: boolean;
      balancesCount: number;
      authType?: NobitexAuthType;
    }>(res, 'تست اتصال ناموفق بود');
  };

  const handleRevokeExchangeKey = async (credId: string) => {
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/keys/exchange/${encodeURIComponent(credId)}`, {
      method: 'DELETE',
      headers,
    });
    await parseApiJson(res, 'خطا در لغو اتصال نوبیتکس');
    setExecutionMode('paper');
    await refreshStatusAndKeys();
    await refreshAccount();
  };

  const handleRequestZarinpal = async () => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/billing/zarinpal/request', {
      method: 'POST',
      headers,
    });
    const data = await parseApiJson<{
      mode: 'GATEWAY_REDIRECT' | 'READY_NOT_CONFIGURED';
      paymentUrl?: string;
      message: string;
      request: PaymentRequestRecord;
    }>(res, 'خطا در اتصال به درگاه زرین‌پال');
    if (data.request) {
      void syncPaymentRequestToFirestore(data.request);
    }
    await refreshBilling();
    return data;
  };

  const handleSubmitCryptoPayment = async (payload: {
    txHash: string;
    network: string;
    walletAddress: string;
    note?: string;
  }) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/billing/crypto/submit', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    const data = await parseApiJson<{ request: PaymentRequestRecord }>(
      res,
      'خطا در ثبت پرداخت دلاری'
    );
    const reqRecord = data.request;
    if (reqRecord) {
      void syncPaymentRequestToFirestore(reqRecord);
    }
    await refreshBilling();
    return reqRecord;
  };

  const handleSaveAdminConfig = async (payload: {
    monthlyPriceToman: number;
    monthlyPriceUsdt: number;
    autoUsdtFromRate: boolean;
    usdtWalletAddress: string;
    usdtNetwork: string;
    usdtWalletAddress2: string;
    usdtNetwork2: string;
    zarinpalMerchantId?: string;
    clearZarinpalMerchantId?: boolean;
    zarinpalSandbox: boolean;
  }) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/billing/admin/config', {
      method: 'PUT',
      headers,
      body: JSON.stringify(payload),
    });
    const overview = await parseApiJson<AdminBillingOverview>(
      res,
      'خطا در ذخیره تنظیمات پنل مدیریت'
    );
    setAdminOverview(overview);
    setBillingConfig(overview.config);
    void syncBillingConfigToFirestore(overview.config);
    await refreshBilling();
  };

  const handleReviewPayment = async (
    requestId: string,
    action: 'APPROVE' | 'REJECT',
    adminNote?: string
  ) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(
      `/api/billing/admin/payments/${encodeURIComponent(requestId)}/review`,
      {
        method: 'POST',
        headers,
        body: JSON.stringify({ action, adminNote }),
      }
    );
    const data = await parseApiJson<{
      subscription?: UserSubscriptionSummary;
      referralReward?: {
        referral: AdminReferralRecord;
        rewardedSubscription: UserSubscriptionSummary;
      };
    }>(res, 'خطا در بررسی فیش پرداخت');
    void syncPaymentReviewToFirestore(
      requestId,
      action === 'APPROVE' ? 'APPROVED' : 'REJECTED',
      adminNote
    );
    if (data.subscription) {
      void syncSubscriptionToFirestore(data.subscription as UserSubscriptionSummary);
    }
    if (data.referralReward) {
      const reward = data.referralReward as {
        referral: AdminReferralRecord;
        rewardedSubscription: UserSubscriptionSummary;
      };
      void syncSubscriptionToFirestore(reward.rewardedSubscription);
      void syncReferralRewardedInFirestore(reward.referral.id);
    }
    await refreshAdminOverview();
    await refreshBilling();
  };

  const handleManageSubscription = async (payload: {
    userId: string;
    email?: string;
    displayName?: string;
    action: 'ACTIVATE' | 'REVOKE';
    days?: number;
  }) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/billing/admin/subscriptions/manage', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    const data = await parseApiJson<{ subscription?: UserSubscriptionSummary }>(
      res,
      'خطا در مدیریت اشتراک کاربر'
    );
    if (data.subscription) {
      void syncSubscriptionToFirestore(data.subscription as UserSubscriptionSummary);
    }
    await refreshAdminOverview();
    await refreshBilling();
  };

  const handleMarkMessageRead = async (messageId: string) => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          directMessages: base.directMessages.map((m) =>
            m.id === messageId ? { ...m, readByUser: true, readAt: Date.now() } : m
          ),
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/messages/${encodeURIComponent(messageId)}/read`, {
      method: 'POST',
      headers,
    });
    if (res.ok) {
      void markDirectMessageReadInFirestore(messageId);
      await refreshBilling();
    }
  };

  const handleMarkAllMessagesRead = async () => {
    if (demoMode) {
      setDemoState((prev) => {
        const base = prev || createInitialDemoState(markets, usdtTomanRate);
        return {
          ...base,
          directMessages: base.directMessages.map((m) => ({
            ...m,
            readByUser: true,
            readAt: m.readAt || Date.now(),
          })),
        };
      });
      return;
    }
    const headers = await getAuthHeaders();
    const res = await fetch('/api/messages/read-all', {
      method: 'POST',
      headers,
    });
    if (res.ok) {
      directMessages
        .filter((m) => !m.readByUser)
        .forEach((m) => void markDirectMessageReadInFirestore(m.id));
      await refreshBilling();
    }
  };

  const handleUpdateUserControl = async (payload: {
    userId: string;
    isBanned?: boolean;
    banReason?: string;
    adminNote?: string;
  }) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/billing/admin/users/${encodeURIComponent(payload.userId)}`, {
      method: 'PATCH',
      headers,
      body: JSON.stringify(payload),
    });
    await parseApiJson(res, 'خطا در بروزرسانی وضعیت کاربر');
    await refreshAdminOverview();
    await refreshBilling();
  };

  const handleCreateBroadcast = async (payload: {
    title: string;
    body: string;
    severity: BroadcastSeverity;
    pinned?: boolean;
    expiresInHours?: number;
    sendTelegram?: boolean;
  }) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/billing/admin/broadcasts', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    const data = await parseApiJson<{ broadcast?: BroadcastMessage }>(
      res,
      'خطا در انتشار اطلاعیه عمومی'
    );
    if (data.broadcast) {
      void syncBroadcastToFirestore(data.broadcast, false);
    }
    await refreshAdminOverview();
    await refreshBilling();
  };

  const handleToggleBroadcast = async (
    broadcastId: string,
    active: boolean,
    pinned?: boolean
  ) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(
      `/api/billing/admin/broadcasts/${encodeURIComponent(broadcastId)}`,
      {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ active, pinned }),
      }
    );
    const data = await parseApiJson<{ broadcast?: BroadcastMessage }>(
      res,
      'خطا در ویرایش اطلاعیه عمومی'
    );
    if (data.broadcast) {
      void syncBroadcastToFirestore(data.broadcast, true);
    }
    await refreshAdminOverview();
    await refreshBilling();
  };

  const handleDeleteBroadcast = async (broadcastId: string) => {
    const headers = await getAuthHeaders();
    const res = await fetch(
      `/api/billing/admin/broadcasts/${encodeURIComponent(broadcastId)}`,
      {
        method: 'DELETE',
        headers,
      }
    );
    if (!res.ok) throw new Error('خطا در حذف اطلاعیه عمومی');
    void deleteBroadcastFromFirestore(broadcastId);
    await refreshAdminOverview();
    await refreshBilling();
  };

  const handleSendDirectMessage = async (payload: {
    targetUserId: string;
    subject: string;
    body: string;
    severity: BroadcastSeverity;
  }) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/billing/admin/messages', {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });
    const data = await parseApiJson<{ message?: DirectMessageRecord }>(
      res,
      'خطا در ارسال پیام تکی به کاربر'
    );
    if (data.message) {
      void syncDirectMessageToFirestore(data.message);
    }
    await refreshAdminOverview();
    await refreshBilling();
  };

  const handleDeleteDirectMessage = async (messageId: string) => {
    const headers = await getAuthHeaders();
    const res = await fetch(`/api/billing/admin/messages/${encodeURIComponent(messageId)}`, {
      method: 'DELETE',
      headers,
    });
    if (!res.ok) throw new Error('خطا در حذف پیام کاربر');
    void deleteDirectMessageFromFirestore(messageId);
    await refreshAdminOverview();
    await refreshBilling();
  };

  const handleSaveAppControl = async (
    payload: Partial<AppControlConfig> & { featurePolicies?: Partial<AppFeatureFlags> }
  ) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch('/api/billing/admin/app-control', {
      method: 'PUT',
      headers,
      body: JSON.stringify(payload),
    });
    const data = await parseApiJson<{ appControl?: AppControlConfig }>(
      res,
      'خطا در ذخیره تنظیمات کلی برنامه'
    );
    if (data.appControl) {
      const updatedControl = data.appControl as AppControlConfig;
      setAppControl(updatedControl);
      void syncAppControlToFirestore(updatedControl);
    }
    await refreshAdminOverview();
    await refreshBilling();
  };

  const handleToggleSystemBotStatus = async (
    botId: string,
    status: 'RUNNING' | 'PAUSED'
  ) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(await getAuthHeaders()),
    };
    const res = await fetch(`/api/billing/admin/bots/${encodeURIComponent(botId)}/status`, {
      method: 'POST',
      headers,
      body: JSON.stringify({ status }),
    });
    await parseApiJson(res, 'خطا در تغییر وضعیت ربات توسط مدیر');
    await refreshBots();
    await refreshAdminOverview();
  };

  const handleGlobalEmergencyStopBots = async (): Promise<{ stoppedCount: number }> => {
    const headers = await getAuthHeaders();
    const res = await fetch('/api/billing/admin/bots/emergency-stop', {
      method: 'POST',
      headers,
    });
    const data = await parseApiJson<{ stoppedCount?: number }>(
      res,
      'خطا در توقف اضطراری ربات‌ها'
    );
    await refreshBots();
    await refreshAdminOverview();
    return { stoppedCount: Number(data.stoppedCount || 0) };
  };

  const computeModuleUnlocked = (moduleKey: keyof AppFeatureFlags): boolean => {
    if (entitlement.isAdmin) return true;
    if (demoMode) return true;
    if (entitlement.isBanned) return false;
    const policy = appControl.featurePolicies?.[moduleKey] || 'PRO';
    if (policy === 'DISABLED') return false;
    if (policy === 'FREE') return true;
    if (appControl.promoFreeAccess || entitlement.promoFreeAccess) return true;
    return entitlement.hasProAccess;
  };

  const terminalPolicy = appControl.featurePolicies?.terminal || 'PRO';
  const analysisPolicy = appControl.featurePolicies?.analysis || 'PRO';
  const botsPolicy = appControl.featurePolicies?.bots || 'PRO';
  const telegramPolicy = appControl.featurePolicies?.telegram || 'PRO';
  const watchersPolicy = appControl.featurePolicies?.watchers || 'PRO';
  const alertsPolicy = appControl.featurePolicies?.alerts || 'FREE';
  const pnlPolicy = appControl.featurePolicies?.pnlCalculator || 'FREE';

  const canUseTerminal = computeModuleUnlocked('terminal');
  const canUseAnalysis = computeModuleUnlocked('analysis');
  const canUseBots = computeModuleUnlocked('bots');
  const canUseTelegram = computeModuleUnlocked('telegram');
  const canUseWatchers = computeModuleUnlocked('watchers');
  const canUseAlerts = computeModuleUnlocked('alerts');
  const canUsePnlCalculator = computeModuleUnlocked('pnlCalculator');

  const activeDemoState = demoMode ? demoState : null;
  const effectiveBalances = activeDemoState
    ? buildDemoBalances(markets, usdtTomanRate, activeDemoState.balances)
    : balances;
  const effectivePortfolioPerformance = activeDemoState
    ? computeDemoPortfolioPerformance(
        effectiveBalances,
        activeDemoState.costBasisMap,
        markets,
        usdtTomanRate
      )
    : portfolioPerformance;
  const effectiveOpenOrders = activeDemoState ? activeDemoState.openOrders : openOrders;
  const effectiveOrderHistory = activeDemoState ? activeDemoState.orderHistory : orderHistory;
  const effectiveBots = activeDemoState ? activeDemoState.bots : bots;
  const effectiveBotLogs = activeDemoState ? activeDemoState.botLogs : botLogs;
  const effectiveProfitBots = activeDemoState ? activeDemoState.profitBots || [] : profitBots;
  const effectiveProfitBotCycles = activeDemoState
    ? activeDemoState.profitBotCycles || []
    : profitBotCycles;
  const effectiveProfitBotLogs = activeDemoState
    ? activeDemoState.profitBotLogs || []
    : profitBotLogs;
  const effectiveAiCycleProBots = activeDemoState
    ? activeDemoState.aiCycleProBots || []
    : aiCycleProBots;
  const effectiveAiCycleProCycles = activeDemoState
    ? activeDemoState.aiCycleProCycles || []
    : aiCycleProCycles;
  const effectiveAiCycleProLogs = activeDemoState
    ? activeDemoState.aiCycleProLogs || []
    : aiCycleProLogs;
  const effectiveGridBots = activeDemoState ? activeDemoState.gridBots || [] : gridBots;
  const effectiveDcaBots = activeDemoState ? activeDemoState.dcaBots || [] : dcaBots;
  const effectiveRiskSettings = activeDemoState
    ? activeDemoState.riskSettings
    : riskSettings;
  const effectivePendingConfirmations = activeDemoState
    ? activeDemoState.pendingConfirmations || []
    : pendingConfirmations;
  const effectiveAiManagerReport = activeDemoState
    ? activeDemoState.aiManagerReport
    : aiManagerReport;
  const effectiveUnifiedDashboard = activeDemoState
    ? computeDemoUnifiedDashboard(activeDemoState, markets)
    : unifiedDashboard;
  const effectiveAlerts = activeDemoState ? activeDemoState.alerts : alerts;
  const effectiveWatchers = activeDemoState ? activeDemoState.watchers : watchers;
  const effectivePulses = activeDemoState ? activeDemoState.pulses : pulses;
  const effectiveIdeas = activeDemoState ? activeDemoState.ideas : ideas;
  const effectiveTelegram = activeDemoState ? activeDemoState.telegram : telegram;
  const effectiveReferral = activeDemoState && !user ? activeDemoState.referral : referralSummary;
  const effectiveDirectMessages =
    activeDemoState && !user ? activeDemoState.directMessages : directMessages;
  const effectiveUnreadDirectCount =
    activeDemoState && !user
      ? activeDemoState.directMessages.filter((m) => !m.readByUser).length
      : unreadDirectCount;

  const visibleBroadcasts = broadcasts.filter(
    (b) => b.pinned || !dismissedBroadcastIds.includes(b.id)
  );
  const supportPhone = appControl.supportPhone || '09999961279';
  const supportTelegramClean = (appControl.supportTelegram || '').replace(/^@/, '').trim();

  const hasExchangeKeys =
    exchangeLinks.some((l) => l.status === 'ACTIVE') ||
    hasEnvFallback ||
    Boolean(connectionStatus?.hasPersonalCredentials);

  const navigateTo = (
    nextView: ActiveView,
    options?: {
      navId?: string;
      terminalTab?: 'OPEN' | 'HISTORY' | 'BALANCES' | 'ALERTS';
      featuresSection?: 'ALL' | 'TELEGRAM' | 'ALERTS' | 'INTERVAL' | 'IDEAS';
      botMode?:
        | 'HUB'
        | 'AI_CYCLE_PRO'
        | 'PROFIT_BOT'
        | 'BEGINNER'
        | 'FIXED_PRICE'
        | 'ADVANCED'
        | 'GRID'
        | 'DCA'
        | 'AI_MANAGER'
        | 'UNIFIED_DASHBOARD';
    }
  ) => {
    setView(nextView);
    setActiveNavId(options?.navId || nextView);
    if (options?.terminalTab) {
      setTerminalTabRequest({ tab: options.terminalTab, nonce: Date.now() });
    }
    if (options?.featuresSection) {
      setFeaturesSectionRequest({ section: options.featuresSection, nonce: Date.now() });
    }
    if (options?.botMode) {
      setBotTabRequest({ mode: options.botMode, nonce: Date.now() });
    }
    setMobileSidebarOpen(false);
  };

  const openGuideModal = (tab: SupportGuideTab) => {
    setGuideModalTab(tab);
    setGuideModalOpen(true);
    setMobileSidebarOpen(false);
  };

  const activeSectionTitle = (() => {
    if (activeNavId === 'HISTORY') return 'تاریخچه معاملات';
    if (activeNavId === 'WALLET') return 'کیف پول و دارایی‌ها';
    if (activeNavId === 'AI_CYCLE_PRO') return 'AI Cycle Pro | چرخه هوشمند';
    if (activeNavId === 'PROFIT_BOT') return 'ربات سود (Profit Bot)';
    if (activeNavId === 'FIXED_TRADER') return 'معامله خودکار قیمتی';
    switch (view) {
      case 'DASHBOARD':
        return 'داشبورد';
      case 'BOTS':
        return 'ربات معامله‌گر';
      case 'TERMINAL':
        return 'ترمینال معاملات';
      case 'ANALYSIS':
        return 'تحلیل و هوش مصنوعی';
      case 'FEATURES':
        return 'تنظیمات و تلگرام';
      case 'SECURITY':
        return 'تنظیمات حساب و API';
      case 'ADMIN':
        return 'پنل مدیریت';
      default:
        return 'داشبورد';
    }
  })();

  const totalAlertsBadge = effectiveUnreadDirectCount + broadcasts.length;
  const userDisplayLabel = user?.displayName
    ? user.displayName
    : user?.email
      ? user.email.split('@')[0]
      : demoMode
        ? 'کاربر دمو'
        : 'کاربر مهمان';
  const userRoleLabel = entitlement.isAdmin
    ? 'مدیر و کاربر ویژه'
    : entitlement.hasProAccess
      ? 'کاربر ویژه'
      : demoMode
        ? 'حالت نمایشی (دمو)'
        : user
          ? 'طرح رایگان'
          : 'ورود به حساب';

  const sidebarItems: {
    id: string;
    label: string;
    icon: React.ComponentType<{ className?: string }>;
    onClick: () => void;
    badge?: string;
  }[] = [
    {
      id: 'DASHBOARD',
      label: 'داشبورد',
      icon: LayoutDashboard,
      onClick: () => navigateTo('DASHBOARD', { navId: 'DASHBOARD' }),
    },
    {
      id: 'AI_CYCLE_PRO',
      label: 'چرخه هوشمند AI',
      icon: Sparkles,
      onClick: () => navigateTo('BOTS', { navId: 'AI_CYCLE_PRO', botMode: 'AI_CYCLE_PRO' }),
      badge:
        effectiveAiCycleProBots.filter((b) => b.isActive).length > 0
          ? `${effectiveAiCycleProBots.filter((b) => b.isActive).length} فعال`
          : undefined,
    },
    {
      id: 'PROFIT_BOT',
      label: 'ربات سود',
      icon: TrendingUp,
      onClick: () => navigateTo('BOTS', { navId: 'PROFIT_BOT', botMode: 'PROFIT_BOT' }),
      badge:
        effectiveProfitBots.filter((b) => b.isActive).length > 0
          ? `${effectiveProfitBots.filter((b) => b.isActive).length} فعال`
          : undefined,
    },
    {
      id: 'FIXED_TRADER',
      label: 'معامله خودکار قیمتی',
      icon: Target,
      onClick: () => navigateTo('BOTS', { navId: 'FIXED_TRADER', botMode: 'FIXED_PRICE' }),
      badge:
        effectiveBots.filter(
          (b) => b.status === 'RUNNING' && b.strategyKind === 'FIXED_PRICE'
        ).length > 0
          ? `${
              effectiveBots.filter(
                (b) => b.status === 'RUNNING' && b.strategyKind === 'FIXED_PRICE'
              ).length
            } فعال`
          : undefined,
    },
    {
      id: 'BOTS',
      label: 'رباتهای معاملاتی من',
      icon: Bot,
      onClick: () => navigateTo('BOTS', { navId: 'BOTS', botMode: 'HUB' }),
      badge: (() => {
        const activeCount =
          effectiveBots.filter((b) => b.status === 'RUNNING').length +
          effectiveProfitBots.filter((b) => b.isActive).length +
          effectiveAiCycleProBots.filter((b) => b.isActive).length +
          effectiveGridBots.filter((b) => b.isActive).length +
          effectiveDcaBots.filter((b) => b.isActive).length;
        return activeCount > 0 ? `${activeCount} فعال` : undefined;
      })(),
    },
    {
      id: 'TERMINAL',
      label: 'ترمینال معاملات',
      icon: CandleIcon,
      onClick: () => navigateTo('TERMINAL', { navId: 'TERMINAL', terminalTab: 'OPEN' }),
    },
    {
      id: 'HISTORY',
      label: 'تاریخچه معاملات',
      icon: History,
      onClick: () => navigateTo('TERMINAL', { navId: 'HISTORY', terminalTab: 'HISTORY' }),
    },
    {
      id: 'WALLET',
      label: 'کیف پول و واریز',
      icon: Wallet,
      onClick: () => navigateTo('TERMINAL', { navId: 'WALLET', terminalTab: 'BALANCES' }),
    },
    {
      id: 'ANALYSIS',
      label: 'تحلیل و از من بپرس',
      icon: BrainCircuit,
      onClick: () => navigateTo('ANALYSIS', { navId: 'ANALYSIS' }),
    },
    {
      id: 'FEATURES',
      label: 'تنظیمات و تلگرام',
      icon: SlidersHorizontal,
      onClick: () => navigateTo('FEATURES', { navId: 'FEATURES', featuresSection: 'ALL' }),
    },
    {
      id: 'SUPPORT',
      label: 'پشتیبانی',
      icon: Headphones,
      onClick: () => openGuideModal('SUPPORT'),
    },
    {
      id: 'GUIDE',
      label: 'آموزش و راهنما',
      icon: BookOpen,
      onClick: () => openGuideModal('GUIDE'),
    },
    {
      id: 'SECURITY',
      label: 'تنظیمات حساب',
      icon: UserCog,
      onClick: () => navigateTo('SECURITY', { navId: 'SECURITY' }),
    },
    ...(entitlement.isAdmin
      ? [
          {
            id: 'ADMIN',
            label: 'پنل مدیریت',
            icon: Shield,
            onClick: () => navigateTo('ADMIN', { navId: 'ADMIN' }),
          },
        ]
      : []),
  ];

  const renderSidebarBody = () => (
    <div className="flex flex-col h-full justify-between gap-4 p-3.5 overflow-y-auto">
      <div className="space-y-3">
        {/* Mobile Drawer Header */}
        <div className="flex lg:hidden items-center justify-between gap-2 pb-3 border-b border-cyan-500/15">
          <button
            type="button"
            onClick={() => navigateTo('DASHBOARD', { navId: 'DASHBOARD' })}
            className="text-right"
          >
            <AliTraderLogo />
          </button>
          <button
            type="button"
            onClick={() => setMobileSidebarOpen(false)}
            className="btn-glass btn-glass-neutral p-1.5 rounded-xl"
            aria-label="بستن منو"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Navigation Links */}
        <nav aria-label="منوی اصلی داشبورد" className="space-y-1">
          {sidebarItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeNavId === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={item.onClick}
                className={`w-full flex items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-xl text-xs sm:text-[13px] font-medium transition-all duration-150 ${
                  isActive
                    ? 'sidebar-item-active font-semibold'
                    : 'border border-transparent text-slate-300 hover:text-white hover:bg-slate-800/45'
                }`}
              >
                <span className="flex items-center gap-2.5 min-w-0">
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-cyan-300' : 'text-slate-400'
                    }`}
                  />
                  <span className="truncate">{item.label}</span>
                </span>
                {item.badge && (
                  <span className="px-1.5 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-400/35 text-[10px] text-emerald-300 shrink-0">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Auth Action */}
        <div className="pt-2 border-t border-slate-800/70">
          {user ? (
            <button
              type="button"
              onClick={() => void handleSignOut()}
              className="w-full flex items-center gap-2.5 px-3.5 py-2 rounded-xl text-xs font-medium text-rose-300 hover:text-rose-200 hover:bg-rose-500/10 border border-transparent hover:border-rose-500/25 transition-colors"
            >
              <LogOut className="w-4 h-4 shrink-0" />
              <span>خروج از حساب</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={() => navigateTo('SECURITY', { navId: 'SECURITY' })}
              className="w-full btn-glass btn-glass-primary flex items-center justify-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold"
            >
              <LogIn className="w-4 h-4 shrink-0" />
              <span>ورود به حساب کاربری</span>
            </button>
          )}
        </div>
      </div>

      {/* Bottom Cyber Bot Promo Card */}
      <div className="pt-1">
        <SidebarPromoCard onClick={() => navigateTo('BOTS', { navId: 'BOTS' })} />
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-[#030816] text-slate-100 flex flex-col">
      {showSplash && <StartupSplash onComplete={() => setShowSplash(false)} />}

      {/* Full-Width Top Header Matching Reference Screenshot (Visual Right: Profile + Bell + Online + Tools | Visual Left: Main Photo + ALI Trader Logo) */}
      <header className="sticky top-0 z-30 glass-header px-3 sm:px-6 h-16 flex items-center justify-between gap-2.5 border-b border-cyan-500/20">
        {/* Visual Right in RTL: Profile Pill + Notification Bell + Online Pill + Compact Utilities */}
        <div className="flex items-center gap-2 min-w-0">
          <button
            type="button"
            onClick={() => setMobileSidebarOpen(true)}
            className="lg:hidden btn-glass btn-glass-neutral p-2 rounded-xl shrink-0"
            aria-label="باز کردن منو"
          >
            <Menu className="w-5 h-5 text-cyan-300" />
          </button>

          {/* User Profile Capsule (Uses User Photo Logo Fallback) */}
          <button
            type="button"
            onClick={() => navigateTo('SECURITY', { navId: 'SECURITY' })}
            className="btn-glass btn-glass-neutral inline-flex items-center gap-2 px-2 sm:px-3 py-1.5 rounded-full text-right shrink-0"
            title="حساب کاربری و کلیدهای API"
          >
            <img
              src={user?.photoURL || USER_BRAND_LOGO_SRC}
              alt={userDisplayLabel}
              referrerPolicy="no-referrer"
              className="w-7 h-7 sm:w-8 sm:h-8 rounded-full object-cover object-top border border-cyan-400/60 shrink-0"
            />
            <div className="hidden sm:block leading-tight">
              <div className="text-xs font-semibold text-white max-w-[115px] truncate">
                {userDisplayLabel}
              </div>
              <div
                className={`text-[10px] font-medium ${
                  entitlement.hasProAccess
                    ? 'text-emerald-300'
                    : demoMode
                      ? 'text-cyan-300'
                      : 'text-slate-400'
                }`}
              >
                {userRoleLabel}
              </div>
            </div>
          </button>

          {/* Notification Bell -> UserInboxModal */}
          <button
            type="button"
            onClick={() => setInboxModalOpen(true)}
            className="relative btn-glass btn-glass-neutral p-2.5 rounded-full shrink-0"
            title="صندوق پیام‌ها و اطلاعیه‌ها"
            aria-label="صندوق پیام‌ها و اطلاعیه‌ها"
          >
            <Bell className="w-4 h-4 text-slate-200" />
            {totalAlertsBadge > 0 && (
              <span className="absolute -top-1 -left-1 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-mono-num font-bold flex items-center justify-center shadow">
                {totalAlertsBadge > 9 ? '9+' : totalAlertsBadge}
              </span>
            )}
          </button>

          {/* Real Online / Demo Pill */}
          <div
            className={`hidden sm:inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-medium ${
              demoMode
                ? 'bg-cyan-500/15 border-cyan-400/40 text-cyan-200'
                : isOnline && connectionStatus?.publicFeedReachable !== false
                  ? 'bg-emerald-500/10 border-emerald-400/35 text-emerald-200'
                  : 'bg-amber-500/15 border-amber-400/40 text-amber-200'
            }`}
          >
            <span
              className={`w-2 h-2 rounded-full ${
                demoMode
                  ? 'bg-cyan-400'
                  : isOnline && connectionStatus?.publicFeedReachable !== false
                    ? 'bg-emerald-400 shadow-[0_0_8px_#34d399]'
                    : 'bg-amber-400'
              }`}
            />
            <span>{demoMode ? 'حالت دمو' : isOnline ? 'آنلاین' : 'آفلاین'}</span>
          </div>

          {/* Compact Header Utility Controls */}
          <div className="hidden md:flex items-center gap-1.5 mr-1">
            <div className="flex items-center gap-0.5 bg-slate-950/80 p-0.5 rounded-full border border-slate-800/80 text-[11px]">
              <button
                type="button"
                onClick={() => handleQuoteCurrencyChange('IRT')}
                className={`px-2.5 py-1 rounded-full font-medium transition-colors ${
                  selectedQuoteCurrency === 'IRT'
                    ? 'bg-amber-500/25 text-amber-200 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                تومانی
              </button>
              <button
                type="button"
                onClick={() => handleQuoteCurrencyChange('USDT')}
                className={`px-2.5 py-1 rounded-full font-medium transition-colors ${
                  selectedQuoteCurrency === 'USDT'
                    ? 'bg-cyan-500/25 text-cyan-200 font-semibold'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                تتری
              </button>
            </div>

            <button
              type="button"
              onClick={() => toggleDemoMode()}
              className={`btn-glass inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full text-[11px] font-semibold ${
                demoMode ? 'btn-glass-buy' : 'btn-glass-primary'
              }`}
              title="حالت نمایشی (دمو)"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{demoMode ? 'خروج دمو' : 'دمو'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                setSubscriptionModalTab('REFERRAL');
                setSubscriptionModalOpen(true);
              }}
              className="btn-glass btn-glass-buy hidden xl:inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full text-[11px] font-medium"
              title="دعوت و ۴ روز اشتراک رایگان"
            >
              <Gift className="w-3.5 h-3.5" />
              <span>دعوت ({effectiveReferral?.totalInvitedCount || 0})</span>
            </button>

            <button
              type="button"
              onClick={() => setInstallModalOpen(true)}
              className="btn-glass btn-glass-telegram hidden xl:inline-flex items-center gap-1 px-2.5 py-1.5 rounded-full text-[11px] font-medium"
              title="نصب اپ روی گوشی (PWA)"
            >
              <Smartphone className="w-3.5 h-3.5 text-cyan-300" />
              <span>{isInstalled ? 'نصب‌شده' : 'نصب اپ'}</span>
            </button>
          </div>
        </div>

        {/* Visual Left in RTL: Brand Logo — AI NobiBot (ainobibot.ir) */}
        <button
          type="button"
          onClick={() => navigateTo('DASHBOARD', { navId: 'DASHBOARD' })}
          className="shrink-0 transition-transform hover:scale-[1.02]"
          aria-label="AI NobiBot — ainobibot.ir"
        >
          <AliTraderLogo />
        </button>
      </header>

      {/* Mobile Slide-Over Drawer */}
      {mobileSidebarOpen && (
        <div
          className="fixed inset-0 z-50 lg:hidden flex bg-slate-950/75 backdrop-blur-sm"
          onClick={() => setMobileSidebarOpen(false)}
        >
          <aside
            className="w-[276px] max-w-[85vw] h-full glass-sidebar border-l border-cyan-500/25 shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            {renderSidebarBody()}
          </aside>
        </div>
      )}

      {/* Workspace Body: In RTL, <main> First = Visual Right, <aside> Second = Visual Left (Matching Reference Screenshot!) */}
      <div className="flex-1 flex min-h-0">
        <main className="flex-1 min-w-0 max-w-[1440px] mx-auto px-3 sm:px-5 py-4 sm:py-5 space-y-4">
          {/* Mobile Compact Quick Actions Strip */}
          <div className="md:hidden glass-strip rounded-xl px-3 py-2 flex flex-wrap items-center justify-between gap-2 text-[11px]">
            <div className="flex items-center gap-1 bg-slate-950/85 p-0.5 rounded-lg border border-slate-800">
              <button
                type="button"
                onClick={() => handleQuoteCurrencyChange('IRT')}
                className={`px-2 py-1 rounded-md font-medium ${
                  selectedQuoteCurrency === 'IRT' ? 'bg-amber-500/25 text-amber-200' : 'text-slate-400'
                }`}
              >
                تومانی
              </button>
              <button
                type="button"
                onClick={() => handleQuoteCurrencyChange('USDT')}
                className={`px-2 py-1 rounded-md font-medium ${
                  selectedQuoteCurrency === 'USDT' ? 'bg-cyan-500/25 text-cyan-200' : 'text-slate-400'
                }`}
              >
                تتری
              </button>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => toggleDemoMode()}
                className={`btn-glass px-2.5 py-1 rounded-lg font-semibold ${
                  demoMode ? 'btn-glass-buy' : 'btn-glass-primary'
                }`}
              >
                {demoMode ? 'خروج دمو' : 'حالت دمو'}
              </button>
              <button
                type="button"
                onClick={() => setInstallModalOpen(true)}
                className="btn-glass btn-glass-telegram px-2.5 py-1 rounded-lg font-medium"
              >
                نصب اپ
              </button>
            </div>
          </div>

        {/* Showcase / Demo Mode Banner */}
        {demoMode && (
          <div className="glass-panel rounded-xl px-4 py-3 border-cyan-500/40 text-cyan-100 text-xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <Eye className="w-4 h-4 text-cyan-300 shrink-0 mt-0.5" />
              <div className="space-y-0.5">
                <div className="font-semibold text-white">
                  حالت تمرینی و دمو روی پلتفرم AI NobiBot (ainobibot.ir) بازه!
                </div>
                <div className="text-cyan-100/85 leading-relaxed">
                  همه‌چیز از خرید و فروش تستی گرفته تا تحلیل خودمونی، «از من بپرس» و ربات‌ها با قیمت زنده نوبیتکس برات آماده‌ست تا با خیال راحت تست کنی.
                </div>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() => setInstallModalOpen(true)}
                className="btn-glass btn-glass-primary inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-semibold whitespace-nowrap shrink-0"
              >
                <Smartphone className="w-3.5 h-3.5" />
                <span>نصب روی گوشی</span>
              </button>
              <button
                type="button"
                onClick={handleResetDemoSandbox}
                className="btn-glass btn-glass-sync inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium whitespace-nowrap shrink-0"
              >
                <RotateCcw className="w-3.5 h-3.5 text-amber-300" />
                <span>ریست موجودی دمو</span>
              </button>
              <button
                type="button"
                onClick={() => toggleDemoMode(false)}
                className="btn-glass btn-glass-sell px-3 py-1.5 rounded-lg font-medium whitespace-nowrap shrink-0"
              >
                خروج از دمو
              </button>
            </div>
          </div>
        )}

        {/* Maintenance Banner for Admin Preview */}
        {appControl.maintenanceMode && entitlement.isAdmin && (
          <div className="rounded-lg px-4 py-2.5 border bg-rose-500/15 border-rose-500/40 text-rose-200 text-xs flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Wrench className="w-4 h-4 shrink-0 text-rose-400" />
              <span>
                حالت تعمیرات هم‌اکنون فعال است (شما به عنوان مدیر بدون محدودیت وارد شده‌اید).
              </span>
            </div>
            <button
              type="button"
              onClick={() => setView('ADMIN')}
              className="btn-glass btn-glass-sell px-3 py-1 rounded-lg font-medium"
            >
              تغییر در پنل مدیریت
            </button>
          </div>
        )}

        {/* Banned Account Notice */}
        {entitlement.isBanned && (
          <div className="rounded-lg px-4 py-3 border bg-rose-500/15 border-rose-500/40 text-rose-200 text-xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Ban className="w-4 h-4 text-rose-400 shrink-0" />
              <div>
                <span className="font-semibold">دسترسی حساب کاربری شما محدود شده است.</span>
                {entitlement.banReason && (
                  <span className="mr-2 text-rose-300">علت: {entitlement.banReason}</span>
                )}
              </div>
            </div>
            <a
              href={`tel:${supportPhone}`}
              className="btn-glass btn-glass-sell px-3 py-1 rounded-lg font-medium"
            >
              تماس با پشتیبانی
            </a>
          </div>
        )}

        {/* Promo Free-Access Banner */}
        {appControl.promoFreeAccess && appControl.promoBannerText && !entitlement.isBanned && (
          <div className="rounded-lg px-4 py-2.5 border bg-emerald-500/15 border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{appControl.promoBannerText}</span>
          </div>
        )}

        {/* Public Broadcast Banners from Admin */}
        {visibleBroadcasts.length > 0 && (
          <div className="space-y-2">
            {visibleBroadcasts.map((bc) => {
              const colorClass =
                bc.severity === 'URGENT'
                  ? 'bg-rose-500/15 border-rose-500/40 text-rose-100'
                  : bc.severity === 'WARNING'
                    ? 'bg-amber-500/15 border-amber-500/40 text-amber-100'
                    : bc.severity === 'SUCCESS'
                      ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-100'
                      : 'bg-cyan-500/15 border-cyan-500/40 text-cyan-100';
              return (
                <div
                  key={bc.id}
                  className={`rounded-lg px-4 py-3 border flex flex-wrap items-center justify-between gap-3 text-xs ${colorClass}`}
                >
                  <div className="flex items-start gap-2.5 min-w-0">
                    {bc.severity === 'URGENT' || bc.severity === 'WARNING' ? (
                      <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    ) : (
                      <Megaphone className="w-4 h-4 shrink-0 mt-0.5" />
                    )}
                    <div className="space-y-0.5">
                      <div className="font-semibold">{bc.title}</div>
                      <div className="opacity-90 leading-relaxed">{bc.body}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      type="button"
                      onClick={() => setInboxModalOpen(true)}
                      className="btn-glass btn-glass-neutral px-3 py-1 rounded-lg font-medium whitespace-nowrap"
                    >
                      مشاهده همه پیام‌ها
                    </button>
                    {!bc.pinned && (
                      <button
                        type="button"
                        onClick={() =>
                          setDismissedBroadcastIds((prev) => [...prev, bc.id])
                        }
                        className="btn-glass btn-glass-neutral p-1 rounded-lg"
                        title="بستن"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Unread Direct Messages Notice */}
        {unreadDirectCount > 0 && (
          <div className="glass-strip rounded-xl px-4 py-2.5 border-cyan-500/40 text-cyan-100 text-xs flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Inbox className="w-4 h-4 text-cyan-300 shrink-0" />
              <span>
                شما <strong className="font-mono-num">{unreadDirectCount}</strong> پیام اختصاصی جدید از طرف مدیر دارید.
              </span>
            </div>
            <button
              type="button"
              onClick={() => setInboxModalOpen(true)}
              className="btn-glass btn-glass-primary px-3 py-1 rounded-lg font-semibold whitespace-nowrap"
            >
              باز کردن صندوق پیام
            </button>
          </div>
        )}
        {referralBanner && (
          <div
            className={`rounded-lg px-4 py-3 border flex items-center justify-between gap-3 text-xs ${
              referralBanner.type === 'ok'
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-200'
                : referralBanner.type === 'info'
                  ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-200'
                  : 'bg-rose-500/15 border-rose-500/40 text-rose-200'
            }`}
          >
            <div className="flex items-center gap-2">
              <Gift className="w-4 h-4 shrink-0 text-emerald-300" />
              <span>{referralBanner.text}</span>
            </div>
            <button
              type="button"
              onClick={() => setReferralBanner(null)}
              className="p-1 rounded hover:bg-slate-800/60"
              title="بستن"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
        {authError && (
          <div
            role="alert"
            className="fixed top-4 left-1/2 -translate-x-1/2 z-[90] w-[min(92vw,42rem)] bg-rose-950/95 border border-rose-500/50 text-rose-100 rounded-lg px-4 py-3 flex items-start justify-between gap-3 text-xs shadow-2xl backdrop-blur-md"
          >
            <span className="leading-relaxed">{authError}</span>
            <button
              type="button"
              onClick={() => setAuthError(null)}
              className="p-1 rounded hover:bg-rose-900/60 shrink-0"
              title="بستن"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
        {zarinpalBanner && (
          <div
            className={`rounded-lg px-4 py-3 border flex items-center justify-between gap-3 text-xs ${
              zarinpalBanner.type === 'ok'
                ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-200'
                : 'bg-rose-500/15 border-rose-500/40 text-rose-200'
            }`}
          >
            <span>{zarinpalBanner.text}</span>
            <button
              type="button"
              onClick={() => setZarinpalBanner(null)}
              className="p-1 rounded hover:bg-slate-800/60"
              title="بستن"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        )}
        {/* Live Triggered Price Alert Notifications */}
        {activeNotifications.length > 0 && (
          <div className="space-y-2">
            {activeNotifications.map((alert) => (
              <div
                key={alert.id}
                className="bg-emerald-500/15 border border-emerald-500/40 rounded-lg px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2.5 text-emerald-100">
                  <BellRing className="w-4 h-4 text-emerald-400 shrink-0" />
                  <div>
                    <span className="font-semibold">
                      هشدار قیمت {alert.persianName} ({alert.symbol}) فعال شد:
                    </span>{' '}
                    <span>
                      قیمت{' '}
                      {alert.condition === 'ABOVE' ? 'از هدف بالاتر رفت' : 'به هدف یا پایین‌تر رسید'}{' '}
                      (هدف:{' '}
                      <span className="font-mono-num text-amber-300" dir="ltr">
                        {formatQuotePrice(alert.targetPrice, alert.quoteCurrency)}
                      </span>
                      {alert.triggeredPrice ? (
                        <>
                          {' '}
                          · لحظه‌ای:{' '}
                          <span className="font-mono-num text-white" dir="ltr">
                            {formatQuotePrice(alert.triggeredPrice, alert.quoteCurrency)}
                          </span>
                        </>
                      ) : null}
                      )
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      selectCoinPair(alert.baseAsset, alert.quoteCurrency);
                      setView('TERMINAL');
                      setActiveNotifications((prev) => prev.filter((x) => x.id !== alert.id));
                    }}
                    className="btn-glass btn-glass-buy px-3 py-1 rounded-lg font-medium whitespace-nowrap shrink-0"
                  >
                    رفتن به معامله
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setActiveNotifications((prev) => prev.filter((x) => x.id !== alert.id))
                    }
                    className="p-1 rounded hover:bg-emerald-500/20 text-emerald-200"
                    title="بستن اعلان"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Live Periodic Price Pulse Notifications */}
        {activePulseNotifications.length > 0 && (
          <div className="space-y-2">
            {activePulseNotifications.map((pulse) => (
              <div
                key={pulse.id}
                className="bg-cyan-500/15 border border-cyan-500/40 rounded-lg px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs"
              >
                <div className="flex items-center gap-2.5 text-cyan-100">
                  <Clock className="w-4 h-4 text-cyan-400 shrink-0" />
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="font-semibold">
                      گزارش لحظه‌ای {pulse.persianName} ({pulse.baseAsset}) · هر {pulse.intervalMinutes} دقیقه:
                    </span>
                    {(pulse.quoteMode === 'IRT' || pulse.quoteMode === 'BOTH') && (
                      <span className="font-mono-num text-amber-300 font-semibold" dir="ltr">
                        {formatToman(pulse.priceToman)} تومان
                      </span>
                    )}
                    {(pulse.quoteMode === 'USDT' || pulse.quoteMode === 'BOTH') && (
                      <span className="font-mono-num text-white font-semibold" dir="ltr">
                        ${formatPrice(pulse.priceUsdt)} USDT
                      </span>
                    )}
                    <span
                      className={`font-mono-num ${
                        pulse.change24hPercent >= 0 ? 'text-emerald-300' : 'text-rose-300'
                      }`}
                      dir="ltr"
                    >
                      ({formatPercent(pulse.change24hPercent)})
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      selectCoinPair(
                        pulse.baseAsset,
                        pulse.quoteMode === 'USDT' ? 'USDT' : 'IRT'
                      );
                      setView('TERMINAL');
                      setActivePulseNotifications((prev) =>
                        prev.filter((x) => x.id !== pulse.id)
                      );
                    }}
                    className="btn-glass btn-glass-primary px-3 py-1 rounded-lg font-semibold whitespace-nowrap shrink-0"
                  >
                    مشاهده و معامله
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setActivePulseNotifications((prev) =>
                        prev.filter((x) => x.id !== pulse.id)
                      )
                    }
                    className="p-1 rounded hover:bg-cyan-500/20 text-cyan-200"
                    title="بستن اعلان"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {appControl.maintenanceMode && !entitlement.isAdmin && view !== 'SECURITY' ? (
          <section className="glass-panel rounded-xl p-8 text-center space-y-4 max-w-2xl mx-auto my-8">
            <div className="w-14 h-14 rounded-xl bg-amber-500/15 border border-amber-500/40 flex items-center justify-center mx-auto">
              <Wrench className="w-7 h-7 text-amber-400" />
            </div>
            <h1 className="text-lg font-bold text-white">سامانه موقتاً در حال بروزرسانی است</h1>
            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {appControl.maintenanceMessage ||
                'پلتفرم موقتاً در حال انجام تعمیرات فنی و ارتقاء است. لطفاً دقایقی دیگر مجدداً مراجعه کنید.'}
            </p>
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2 text-xs">
              <a
                href={`tel:${supportPhone}`}
                className="btn-glass btn-glass-neutral inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-cyan-300"
              >
                <Phone className="w-3.5 h-3.5" />
                <span>پشتیبانی: {supportPhone}</span>
              </a>
              <button
                type="button"
                onClick={() => setView('SECURITY')}
                className="btn-glass btn-glass-primary px-4 py-2 rounded-lg font-semibold"
              >
                ورود مدیر / حساب کاربری
              </button>
            </div>
          </section>
        ) : (
          <>
            {view === 'DASHBOARD' && (
              <MarketOverview
                markets={markets}
                usdtTomanRate={usdtTomanRate}
                selectedBaseAsset={selectedBaseAsset}
                selectedQuoteCurrency={selectedQuoteCurrency}
                loading={loadingMarkets}
                balances={effectiveBalances}
                portfolioPerformance={effectivePortfolioPerformance}
                alerts={effectiveAlerts}
                recentOrders={[...effectiveOpenOrders, ...effectiveOrderHistory]}
                recentMarketTrades={recentTrades}
                bots={effectiveBots}
                botLogs={effectiveBotLogs}
                executionMode={executionMode}
                isAuthenticated={Boolean(user)}
                candles={candles}
                analysis={analysis}
                timeframe={timeframe}
                onTimeframeChange={setTimeframe}
                loadingChart={loadingChart}
                onSelectPair={(base, qc) => selectCoinPair(base, qc)}
                onToggleBotStatus={handleToggleBotStatus}
                demoMode={demoMode}
                hasProAccess={entitlement.hasProAccess || demoMode}
                daysRemaining={entitlement.daysRemaining}
                supportTelegram={appControl.supportTelegram}
                onOpenGuide={(tab) => openGuideModal(tab)}
                onOpenHistory={() =>
                  navigateTo('TERMINAL', { navId: 'HISTORY', terminalTab: 'HISTORY' })
                }
                onOpenWallet={() =>
                  navigateTo('TERMINAL', { navId: 'WALLET', terminalTab: 'BALANCES' })
                }
                onSaveCostBasis={handleSaveCostBasis}
                onResetCostBasis={handleResetCostBasis}
                onCreateAlert={handleCreateAlert}
                onRearmAlert={handleRearmAlert}
                onDeleteAlert={handleDeleteAlert}
                onQuoteCurrencyChange={handleQuoteCurrencyChange}
                onSelectForTrade={(base, qc) => {
                  selectCoinPair(base, qc);
                  navigateTo('TERMINAL', { navId: 'TERMINAL', terminalTab: 'OPEN' });
                }}
                onSelectForAnalysis={(base) => {
                  selectCoinPair(base);
                  navigateTo('ANALYSIS', { navId: 'ANALYSIS' });
                }}
                onSelectForBot={(base, qc) => {
                  selectCoinPair(base, qc);
                  navigateTo('BOTS', { navId: 'BOTS' });
                }}
                onOpenSecurity={() => navigateTo('SECURITY', { navId: 'SECURITY' })}
                telegramConnected={
                  effectiveTelegram.configured &&
                  effectiveTelegram.enabled &&
                  effectiveTelegram.sendPriceAlerts
                }
                onOpenTelegramSettings={() =>
                  navigateTo('FEATURES', { navId: 'FEATURES', featuresSection: 'TELEGRAM' })
                }
                supportPhone={supportPhone}
                isAdmin={entitlement.isAdmin}
                pnlCalculatorUnlocked={canUsePnlCalculator}
                alertsUnlocked={canUseAlerts}
                pnlPolicy={pnlPolicy}
                alertsPolicy={alertsPolicy}
                monthlyPriceToman={billingConfig.monthlyPriceToman}
                monthlyPriceUsdt={billingConfig.monthlyPriceUsdt}
                onSignIn={handleSignIn}
                onOpenSubscription={() => {
                  setSubscriptionModalTab('ZARINPAL');
                  setSubscriptionModalOpen(true);
                }}
                onEnterDemoMode={() => toggleDemoMode(true)}
              />
            )}

            {view === 'TERMINAL' &&
              (terminalPolicy === 'DISABLED' && !entitlement.isAdmin && !demoMode ? (
                <section className="glass-panel rounded-2xl p-6 text-center text-xs text-slate-300">
                  بخش ترمینال معاملات موقتاً توسط مدیریت غیرفعال شده است.
                </section>
              ) : canUseTerminal ? (
                <TradingTerminal
                  baseAsset={selectedBaseAsset}
                  quoteCurrency={selectedQuoteCurrency}
                  onSelectPair={selectCoinPair}
                  timeframe={timeframe}
                  onTimeframeChange={setTimeframe}
                  markets={markets}
                  usdtTomanRate={usdtTomanRate}
                  candles={candles}
                  analysis={analysis}
                  orderBook={orderBook}
                  recentTrades={recentTrades}
                  balances={effectiveBalances}
                  openOrders={effectiveOpenOrders}
                  orderHistory={effectiveOrderHistory}
                  alerts={effectiveAlerts}
                  executionMode={demoMode ? 'paper' : executionMode}
                  isAuthenticated={Boolean(user) || demoMode}
                  loadingChart={loadingChart}
                  onRequireAuth={() => navigateTo('SECURITY', { navId: 'SECURITY' })}
                  onPlaceOrder={handlePlaceOrder}
                  onCancelOrder={handleCancelOrder}
                  onResetPaperWallet={handleResetPaperWallet}
                  onCreateAlert={handleCreateAlert}
                  onRearmAlert={handleRearmAlert}
                  onDeleteAlert={handleDeleteAlert}
                  telegramConnected={
                    effectiveTelegram.configured &&
                    effectiveTelegram.enabled &&
                    effectiveTelegram.sendPriceAlerts
                  }
                  onOpenTelegramSettings={() =>
                    navigateTo('FEATURES', { navId: 'FEATURES', featuresSection: 'TELEGRAM' })
                  }
                  onSendTradesReportToTelegram={() => handleSendTelegramReport('TRADES')}
                  requestedBottomTab={terminalTabRequest?.tab}
                  requestedBottomTabNonce={terminalTabRequest?.nonce}
                />
              ) : (
                <ProFeatureGate
                  featureTitle="ترمینال معاملات اسپات و مدیریت پرتفوی (امکانات تخصصی)"
                  featureDescription="ثبت سفارش‌های خرید و فروش تومانی و تتری، اتصال مستقیم به حساب نوبیتکس و گزارش سود و زیان پرتفوی"
                  monthlyPriceToman={billingConfig.monthlyPriceToman}
                  monthlyPriceUsdt={billingConfig.monthlyPriceUsdt}
                  isAuthenticated={Boolean(user)}
                  onSignIn={handleSignIn}
                  onOpenSubscription={() => {
                    setSubscriptionModalTab('ZARINPAL');
                    setSubscriptionModalOpen(true);
                  }}
                  onEnterDemoMode={() => toggleDemoMode(true)}
                />
              ))}

            {view === 'ANALYSIS' &&
              (analysisPolicy === 'DISABLED' && !entitlement.isAdmin && !demoMode ? (
                <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-6 text-center text-xs text-slate-300">
                  بخش تحلیل تکنیکال و هوش مصنوعی موقتاً توسط مدیریت غیرفعال شده است.
                </section>
              ) : canUseAnalysis ? (
                <CoinAnalysis
                  baseAsset={selectedBaseAsset}
                  quoteCurrency={selectedQuoteCurrency}
                  onBaseAssetChange={(base) => selectCoinPair(base)}
                  onQuoteCurrencyChange={handleQuoteCurrencyChange}
                  markets={markets}
                  usdtTomanRate={usdtTomanRate}
                  demoMode={demoMode}
                  onGoToTrade={(base, qc) => {
                    selectCoinPair(base, qc);
                    setView('TERMINAL');
                  }}
                  onGoToBot={(base, qc) => {
                    selectCoinPair(base, qc);
                    setView('BOTS');
                  }}
                />
              ) : (
                <ProFeatureGate
                  featureTitle="تحلیل تکنیکال چندتایم‌فریمی، هوش مصنوعی و اخبار بازار (امکانات تخصصی)"
                  featureDescription="بررسی هم‌زمان تایم‌فریم‌های ۱۵ دقیقه تا روزانه، دستیار هوشمند Gemini AI و سنجش احساسات لحظه‌ای بازار"
                  monthlyPriceToman={billingConfig.monthlyPriceToman}
                  monthlyPriceUsdt={billingConfig.monthlyPriceUsdt}
                  isAuthenticated={Boolean(user)}
                  onSignIn={handleSignIn}
                  onOpenSubscription={() => {
                    setSubscriptionModalTab('ZARINPAL');
                    setSubscriptionModalOpen(true);
                  }}
                  onEnterDemoMode={() => toggleDemoMode(true)}
                />
              ))}

            {view === 'BOTS' &&
              (botsPolicy === 'DISABLED' && !entitlement.isAdmin && !demoMode ? (
                <section className="bg-[#0A101D] border border-slate-800/90 rounded-lg p-6 text-center text-xs text-slate-300">
                  بخش ربات معامله‌گر خودکار موقتاً توسط مدیریت غیرفعال شده است.
                </section>
              ) : canUseBots ? (
                <TradingBotModule
                  defaultBaseAsset={selectedBaseAsset}
                  defaultQuoteCurrency={selectedQuoteCurrency}
                  onQuoteCurrencyChange={handleQuoteCurrencyChange}
                  markets={markets}
                  usdtTomanRate={usdtTomanRate}
                  balances={effectiveBalances}
                  bots={effectiveBots}
                  logs={effectiveBotLogs}
                  hasExchangeKeys={hasExchangeKeys}
                  isAuthenticated={Boolean(user) || demoMode}
                  onRequireAuth={() => setView('SECURITY')}
                  onCreateBot={handleCreateBot}
                  onToggleBotStatus={handleToggleBotStatus}
                  onToggleBotMode={handleToggleBotMode}
                  onEvaluateBotNow={handleEvaluateBotNow}
                  onDeleteBot={handleDeleteBot}
                  onRunBacktest={handleRunBacktest}
                  telegram={effectiveTelegram}
                  onToggleBotTelegram={handleToggleBotTelegram}
                  onSendBotReportToTelegram={(botId) =>
                    handleSendTelegramReport(botId ? 'SINGLE_BOT' : 'BOTS_MONITOR', botId)
                  }
                  onOpenTelegramSettings={() => setView('FEATURES')}
                  onUpdateFixedTargets={handleUpdateBotFixedTargets}
                  requestedMode={botTabRequest?.mode}
                  requestedModeNonce={botTabRequest?.nonce}
                  demoMode={demoMode}
                  aiCycleProBots={effectiveAiCycleProBots}
                  aiCycleProCycles={effectiveAiCycleProCycles}
                  aiCycleProLogs={effectiveAiCycleProLogs}
                  onCreateAiCycleProBot={handleCreateAiCycleProBot}
                  onUpdateAiCycleProBot={handleUpdateAiCycleProBot}
                  onStartAiCycleProBot={handleStartAiCycleProBot}
                  onStopAiCycleProBot={handleStopAiCycleProBot}
                  onEvaluateAiCycleProBot={handleEvaluateAiCycleProBot}
                  onManualSellAiCycleProBot={handleManualSellAiCycleProBot}
                  onDeleteAiCycleProBot={handleDeleteAiCycleProBot}
                  onPreviewAiCycleProMarket={handlePreviewAiCycleProMarket}
                  profitBots={effectiveProfitBots}
                  profitBotCycles={effectiveProfitBotCycles}
                  profitBotLogs={effectiveProfitBotLogs}
                  onCreateProfitBot={handleCreateProfitBot}
                  onUpdateProfitBot={handleUpdateProfitBot}
                  onStartProfitBot={handleStartProfitBot}
                  onStopProfitBot={handleStopProfitBot}
                  onEvaluateProfitBot={handleEvaluateProfitBot}
                  onManualSellProfitBot={handleManualSellProfitBot}
                  onDeleteProfitBot={handleDeleteProfitBot}
                  onFetchProfitBotPreview={handleFetchProfitBotPreview}
                  gridBots={effectiveGridBots}
                  dcaBots={effectiveDcaBots}
                  riskSettings={effectiveRiskSettings}
                  pendingConfirmations={effectivePendingConfirmations}
                  aiManagerReport={effectiveAiManagerReport}
                  unifiedDashboard={effectiveUnifiedDashboard}
                  onCreateGridBot={handleCreateGridBot}
                  onStartGridBot={handleStartGridBot}
                  onStopGridBot={handleStopGridBot}
                  onEvaluateGridBot={handleEvaluateGridBot}
                  onDeleteGridBot={handleDeleteGridBot}
                  onCreateDcaBot={handleCreateDcaBot}
                  onUpdateDcaBot={handleUpdateDcaBot}
                  onStartDcaBot={handleStartDcaBot}
                  onStopDcaBot={handleStopDcaBot}
                  onEvaluateDcaBot={handleEvaluateDcaBot}
                  onDeleteDcaBot={handleDeleteDcaBot}
                  onUpdateRiskSettings={handleUpdateRiskSettings}
                  onToggleKillSwitch={handleToggleKillSwitch}
                  onResolveConfirmation={handleResolveConfirmation}
                  onRunAiManagerAnalysis={handleRunAiManagerAnalysis}
                />
              ) : (
                <ProFeatureGate
                  featureTitle="ربات معامله‌گر خودکار و شبیه‌ساز بک‌تست (امکانات تخصصی)"
                  featureDescription="اجرای ۲۴ ساعته استراتژی معاملاتی روی جفت‌ارزهای نوبیتکس با حد سود و ضرر هوشمند و بک‌تست تاریخی"
                  monthlyPriceToman={billingConfig.monthlyPriceToman}
                  monthlyPriceUsdt={billingConfig.monthlyPriceUsdt}
                  isAuthenticated={Boolean(user)}
                  onSignIn={handleSignIn}
                  onOpenSubscription={() => {
                    setSubscriptionModalTab('ZARINPAL');
                    setSubscriptionModalOpen(true);
                  }}
                  onEnterDemoMode={() => toggleDemoMode(true)}
                />
              ))}

            {view === 'FEATURES' && (
              <FeaturesHub
                markets={markets}
                defaultBaseAsset={selectedBaseAsset}
                defaultQuoteCurrency={selectedQuoteCurrency}
                alerts={effectiveAlerts}
                watchers={effectiveWatchers}
                pulses={effectivePulses}
                ideas={effectiveIdeas}
                telegram={effectiveTelegram}
                hasProAccess={entitlement.hasProAccess || demoMode}
                isAdmin={entitlement.isAdmin}
                telegramUnlocked={canUseTelegram}
                watchersUnlocked={canUseWatchers}
                alertsUnlocked={canUseAlerts}
                telegramPolicy={demoMode ? 'FREE' : telegramPolicy}
                watchersPolicy={demoMode ? 'FREE' : watchersPolicy}
                alertsPolicy={demoMode ? 'FREE' : alertsPolicy}
                monthlyPriceToman={billingConfig.monthlyPriceToman}
                monthlyPriceUsdt={billingConfig.monthlyPriceUsdt}
                isAuthenticated={Boolean(user)}
                onSignIn={handleSignIn}
                onOpenSubscription={() => {
                  setSubscriptionModalTab('ZARINPAL');
                  setSubscriptionModalOpen(true);
                }}
                onEnterDemoMode={() => toggleDemoMode(true)}
                onQuoteCurrencyChange={handleQuoteCurrencyChange}
                onSelectForTrade={(base, qc) => {
                  selectCoinPair(base, qc);
                  setView('TERMINAL');
                }}
                onCreateAlert={handleCreateAlert}
                onRearmAlert={handleRearmAlert}
                onDeleteAlert={handleDeleteAlert}
                onCreateWatcher={handleCreateWatcher}
                onToggleWatcherStatus={handleToggleWatcherStatus}
                onSendWatcherNow={handleSendWatcherNow}
                onDeleteWatcher={handleDeleteWatcher}
                onCreateIdea={handleCreateIdea}
                onUpdateIdeaStatus={handleUpdateIdeaStatus}
                onDeleteIdea={handleDeleteIdea}
                onSaveTelegramConfig={handleSaveTelegramConfig}
                onDetectTelegramChats={handleDetectTelegramChats}
                onSendTelegramTest={handleSendTelegramTest}
                onUpdateTelegramPreferences={handleUpdateTelegramPreferences}
                onDisconnectTelegram={handleDisconnectTelegram}
                onSendTelegramReport={handleSendTelegramReport}
                requestedSection={featuresSectionRequest?.section}
                requestedSectionNonce={featuresSectionRequest?.nonce}
              />
            )}

            {view === 'SECURITY' && (
              <AuthAndKeysPanel
                user={user}
                authLoading={authLoading}
                connectionStatus={connectionStatus}
                executionMode={executionMode}
                onChangeExecutionMode={setExecutionMode}
                appKeys={appKeys}
                exchangeLinks={exchangeLinks}
                hasEnvFallback={hasEnvFallback}
                onSignIn={handleSignIn}
                onSignOut={handleSignOut}
                onGenerateAppKey={handleGenerateAppKey}
                onRevokeAppKey={handleRevokeAppKey}
                onSaveExchangeKey={handleSaveExchangeKey}
                onTestExchangeKey={handleTestExchangeKey}
                onRevokeExchangeKey={handleRevokeExchangeKey}
                referral={effectiveReferral}
                onClaimReferralCode={handleClaimReferralCode}
              />
            )}

            {view === 'ADMIN' && entitlement.isAdmin && (
              <AdminBillingPanel
                overview={adminOverview}
                loading={loadingAdmin}
                onRefresh={refreshAdminOverview}
                onSaveConfig={handleSaveAdminConfig}
                onReviewPayment={handleReviewPayment}
                onManageSubscription={handleManageSubscription}
                onUpdateUserControl={handleUpdateUserControl}
                onCreateBroadcast={handleCreateBroadcast}
                onToggleBroadcast={handleToggleBroadcast}
                onDeleteBroadcast={handleDeleteBroadcast}
                onSendDirectMessage={handleSendDirectMessage}
                onDeleteDirectMessage={handleDeleteDirectMessage}
                onSaveAppControl={handleSaveAppControl}
                onToggleSystemBotStatus={handleToggleSystemBotStatus}
                onGlobalEmergencyStopBots={handleGlobalEmergencyStopBots}
              />
            )}
          </>
        )}
        </main>

        {/* Desktop Sidebar (In RTL, second child of flex row sits on the Visual Left matching the reference mockup) */}
        <aside className="hidden lg:block w-[248px] shrink-0 sticky top-16 h-[calc(100vh-4rem)] glass-sidebar border-r border-cyan-500/20 z-20">
          {renderSidebarBody()}
        </aside>
      </div>

      {/* AI NobiBot (ainobibot.ir) Sleek Navy Footer */}
      <footer className="border-t border-cyan-500/15 bg-[#040917]/95 px-4 sm:px-6 py-4">
        <div className="max-w-[1440px] mx-auto flex flex-col md:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex flex-wrap items-center gap-2.5">
            <img
              src={USER_BRAND_LOGO_SRC}
              alt="لوگوی AI NobiBot — ainobibot.ir"
              referrerPolicy="no-referrer"
              className="w-7 h-7 rounded-lg object-cover object-top border border-cyan-400/50 shrink-0"
            />
            <a
              href="https://ainobibot.ir"
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono-num text-cyan-300 hover:text-cyan-200 font-semibold transition-colors"
              dir="ltr"
            >
              AI NobiBot · ainobibot.ir
            </a>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span className="text-amber-300 font-medium">امتیاز و مدیریت: علی اسمعیلی</span>
          </div>

          <div className="flex items-center gap-3 text-cyan-300/90 font-medium">
            <span className="hidden sm:block w-12 h-px bg-gradient-to-l from-cyan-400/70 to-transparent" />
            <span>معامله هوشمند در نوبیتکس، آینده روشن‌تر</span>
            <span className="hidden sm:block w-12 h-px bg-gradient-to-r from-cyan-400/70 to-transparent" />
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3">
            <button
              type="button"
              onClick={() => openGuideModal('GUIDE')}
              className="text-cyan-300 hover:text-cyan-200 font-medium transition-colors"
            >
              راهنمای استفاده
            </button>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <a
              href={`tel:${supportPhone}`}
              className="inline-flex items-center gap-1 text-cyan-300 hover:text-cyan-200 font-medium transition-colors"
            >
              <Phone className="w-3.5 h-3.5" />
              <span className="font-mono-num" dir="ltr">
                {supportPhone}
              </span>
            </a>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span className="text-slate-500 font-mono-num" dir="ltr">© 2025–2026 ainobibot.ir</span>
          </div>
        </div>
      </footer>

      <UserInboxModal
        open={inboxModalOpen}
        onClose={() => setInboxModalOpen(false)}
        broadcasts={broadcasts}
        directMessages={effectiveDirectMessages}
        unreadDirectCount={effectiveUnreadDirectCount}
        isAuthenticated={Boolean(user) || demoMode}
        onSignIn={handleSignIn}
        onMarkRead={handleMarkMessageRead}
        onMarkAllRead={handleMarkAllMessagesRead}
      />
      <SubscriptionModal
        open={subscriptionModalOpen}
        initialTab={subscriptionModalTab}
        onClose={() => setSubscriptionModalOpen(false)}
        config={billingConfig}
        entitlement={entitlement}
        myRequests={myRequests}
        referral={effectiveReferral}
        isAuthenticated={Boolean(user)}
        onSignIn={handleSignIn}
        onRequestZarinpal={handleRequestZarinpal}
        onSubmitCryptoPayment={handleSubmitCryptoPayment}
        onClaimReferralCode={handleClaimReferralCode}
      />
      <SupportGuideModal
        open={guideModalOpen}
        initialTab={guideModalTab}
        onClose={() => setGuideModalOpen(false)}
        supportPhone={supportPhone}
        supportTelegram={appControl.supportTelegram}
        onOpenPWAInstall={() => setInstallModalOpen(true)}
        onOpenTelegramSettings={() =>
          navigateTo('FEATURES', { navId: 'FEATURES', featuresSection: 'TELEGRAM' })
        }
        onOpenInbox={() => setInboxModalOpen(true)}
      />
      <PWAInstallModal
        open={installModalOpen}
        onClose={() => setInstallModalOpen(false)}
        demoMode={demoMode}
        onToggleDemoMode={() => toggleDemoMode()}
      />
      <OfflineIndicator />
    </div>
  );
}
